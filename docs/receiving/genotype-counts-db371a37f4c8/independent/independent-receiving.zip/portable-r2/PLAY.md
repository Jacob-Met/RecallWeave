# Genotype counts — local lesson and unanswered worksheet

Unzip this folder intact. Open `demo.html` in an installed desktop browser. Under **Bring your own lesson**, choose `courses/genotype-counts.json`, inspect the preview, then choose **Start this deck**. The course has fourteen original questions. Its ordinary review, missed-item practice and explicit study-notes download use the unchanged RecallWeave learner.

Open `courses/genotype-counts-worksheet.html` for the unanswered six-group worksheet. It is a static page with no scripts or saved answers. Use browser Print to create a paper copy or PDF. `courses/genotype-counts.md` is a separate full worked guide and contains the answers; keep it separate during an unanswered exercise.

The examples concern hypothetical diploid plants at one autosomal locus. They distinguish observed counts, allele-copy accounting and stipulated independent-gamete-union expectations. They provide no real genetic data, statistical test, clinical interpretation or inference of a biological cause.

The bundled learner is the exact original RecallWeave standalone file from commit ec07bf3989132130759e5c00c6cb02eef19709d3. No install, server, account, network request or external asset is needed. Files are used locally, and starting a new lesson changes the tab's session only after the explicit start action. Keep the actual downloaded notes if you want a durable copy.

MANIFEST.json gives the exact bytes and SHA256 of the other five members. This source package is the author qualification input; final acceptance is recorded separately in the receiving evidence. Original lesson/worksheet/guide wording was authored with Codex AI assistance; cited sources retain their own terms.
