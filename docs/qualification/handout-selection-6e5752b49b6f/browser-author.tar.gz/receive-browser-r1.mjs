#!/usr/bin/env node
// Focused handout-selection receiving; native Node22+ and an installed browser.
// CDP transport follows the maintained handout receiver; new assertions are scoped to issue170.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import {createReadStream} from 'node:fs';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir,mkdtemp,rm,readdir} from 'node:fs/promises';
import {join,resolve,relative,isAbsolute,extname,basename} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const args=process.argv.slice(2);
const option=name=>{const i=args.indexOf(name);assert.ok(i>=0&&args[i+1],name);return args[i+1];};
const project=resolve(option('--root')),executable=option('--browser'),output=resolve(option('--output'));
await mkdir(output); // An existing output directory is refused.
const downloadPath=join(output,'downloads');await mkdir(downloadPath);
const profile=await mkdtemp(join(output,'profile-'));
const hash=x=>createHash('sha256').update(x).digest('hex');
const report={format:'recallweave-handout-selection-browser/1',status:'running',source:'35ba3fe7a611395016fc5c808604ea1a815dc81b',node:process.version,checks:[],artifacts:[],faultInjection:'Named real File.text reads may be delayed or rejected; product state is never accessed.',printBoundary:'Calls original window.print; retains Chrome printToPDF. No physical printer claim.'};
const sourcePaths=['handout/index.html','handout/handout.css','handout.html','src/course-handout.mjs','src/course-handout-ui.mjs','src/deck.mjs'];
const sourceBefore=Object.fromEntries(await Promise.all(sourcePaths.map(async p=>[p,hash(await readFile(join(project,p)))])));
report.sourceSha256=sourceBefore;
const expected=JSON.parse(await readFile(option('--manifest'),'utf8'));
assert.deepEqual(sourceBefore,expected.sources,'Exact handed-off source admission');
async function hashFile(path){const h=createHash('sha256');for await(const part of createReadStream(path))h.update(part);return h.digest('hex');}
const runtimeBefore={};
for(const [name,value] of Object.entries(expected.runtime)){
 runtimeBefore[name]={path:value.path,sha256:await hashFile(value.path)};
 assert.equal(runtimeBefore[name].sha256,value.sha256,'Admitted '+name);
}
report.runtimeBefore=runtimeBefore;
const receiverPath=fileURLToPath(import.meta.url),receiverBefore=await hashFile(receiverPath);
report.receiverSha256=receiverBefore;
const fixture={
  "title": "A short activity <literal> 日本語",
  "attribution": "Original receiving fixture\nTeacher & group",
  "license": "Synthetic test content; retain this credit.",
  "concepts": [
    "First concept",
    "Second concept",
    "Unselected concept"
  ],
  "items": [
    {
      "id": "q-first",
      "concept": "First concept",
      "prerequisites": [],
      "prompt": "FIRST_PUBLIC_PROMPT",
      "options": [
        "A first",
        "B first"
      ],
      "answer": 1,
      "explanation": "FIRST_PRIVATE_EXPLANATION",
      "transfer": "FIRST_TRANSFER"
    },
    {
      "id": " q spaced ",
      "concept": "Second concept",
      "prerequisites": [
        "First concept"
      ],
      "prompt": "SECOND_PUBLIC_PROMPT <script>literal</script>\nNew line",
      "options": [
        "A second",
        "B second",
        "C second"
      ],
      "answer": 2,
      "explanation": "SECOND_PRIVATE_EXPLANATION",
      "transfer": "SECOND_TRANSFER"
    },
    {
      "id": "__proto__",
      "concept": "First concept",
      "prerequisites": [],
      "prompt": "THIRD_PUBLIC_PROMPT",
      "options": [
        "A third",
        "B third"
      ],
      "answer": 0,
      "explanation": "THIRD_PRIVATE_EXPLANATION",
      "transfer": "THIRD_TRANSFER"
    },
    {
      "id": "constructor",
      "concept": "Unselected concept",
      "prerequisites": [],
      "prompt": "FOURTH_EXCLUDED_PROMPT",
      "options": [
        "FOURTH_EXCLUDED_OPTION_A",
        "FOURTH_EXCLUDED_OPTION_B"
      ],
      "answer": 1,
      "explanation": "FOURTH_PRIVATE_EXPLANATION",
      "transfer": "FOURTH_EXCLUDED_TRANSFER"
    }
  ]
};
const fixturePath=join(output,'fixture.json');await writeFile(fixturePath,JSON.stringify(fixture,null,2)+'\n');
const replacement=structuredClone(fixture);replacement.title='Replacement checked lesson';replacement.items=replacement.items.slice(0,2);replacement.concepts=replacement.concepts.slice(0,2);
const replacementPath=join(output,'replacement.json'),slowPath=join(output,'slow.json'),invalidPath=join(output,'invalid.json');
await writeFile(replacementPath,JSON.stringify(replacement));await writeFile(slowPath,JSON.stringify(replacement));await writeFile(invalidPath,'{"title":}');
const downloads=new Map(),chooserEvents=[],pageErrors=[],allRequests=[];
let pageRequests=[],browser,socket,sessionId,browserLog='',sequence=0;
const pending=new Map();
const sleep=ms=>new Promise(resolve_=>setTimeout(resolve_,ms));
const server=createServer(async(req,res)=>{
 try{
  const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  const file=resolve(project,'.'+pathname),rel=relative(project,file);
  if(rel.startsWith('..')||isAbsolute(rel)){res.writeHead(403).end();return;}
  const content=await readFile(file),mime={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.json':'application/json'}[extname(file)]??'application/octet-stream';
  res.writeHead(200,{'Content-Type':mime+'; charset=utf-8'}).end(content);
 }catch{res.writeHead(404).end();}
});
await new Promise(resolve_=>server.listen(0,'127.0.0.1',resolve_));
const base='http://127.0.0.1:'+server.address().port;
const passed=name=>{report.checks.push(name);console.log('PASS '+name);};
async function waitFor(check, label, attempts = 120) {
  let lastError;
  for (let step = 0; step < attempts; step++) {
    try { if (await check()) return; } catch (error) { lastError = error; }
    await sleep(100);
  }
  throw new Error('Timed out: ' + label + (lastError ? ' (' + lastError.message + ')' : ''));
}
function command(method, params = {}, scoped = true) {
  const id = ++sequence;
  return new Promise((resolve_, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id); reject(new Error('CDP timeout: ' + method));
    }, 15000);
    pending.set(id, {resolve: resolve_, reject, timer});
    socket.send(JSON.stringify({id, method, params, ...(scoped && sessionId ? {sessionId} : {})}));
  });
}
async function evaluate(expression) {
  const result = await command('Runtime.evaluate', {expression, returnByValue: true, awaitPromise: true});
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description
    ?? result.exceptionDetails.text);
  return result.result.value;
}
async function key(key_, code, virtualKey, modifiers = 0) {
  for (const type of ['keyDown', 'keyUp']) {
    await command('Input.dispatchKeyEvent', {type, key: key_, code,
      windowsVirtualKeyCode: virtualKey, nativeVirtualKeyCode: virtualKey, modifiers,
      ...(key_ === 'Enter' && type === 'keyDown' ? {text: '\r', unmodifiedText: '\r'} : {})});
  }
}
async function activate(selector) {
  const exists = await evaluate('(() => { const node = document.querySelector(' +
    JSON.stringify(selector) + '); if (!node || node.matches(":disabled") || !node.getClientRects().length) return false; ' +
    'node.scrollIntoView({block:"center"}); node.focus(); return true; })()');
  assert.ok(exists, 'Available keyboard control: ' + selector);
  await key('Enter', 'Enter', 13);
}
async function click(selector) {
  const box = await evaluate('(() => { const node = document.querySelector(' +
    JSON.stringify(selector) + '); if (!node || node.matches(":disabled")) return null; ' +
    'node.scrollIntoView({block:"center"}); const b = node.getBoundingClientRect(); ' +
    'return {x:b.x+b.width/2,y:b.y+b.height/2,width:b.width,height:b.height}; })()');
  assert.ok(box && box.width > 0 && box.height > 0, 'Visible pointer control: ' + selector);
  for (const type of ['mousePressed', 'mouseReleased']) {
    await command('Input.dispatchMouseEvent', {type, x: box.x, y: box.y,
      button: 'left', clickCount: 1});
  }
}
async function textInput(selector, value) {
  await evaluate('(() => {const node=document.querySelector(' + JSON.stringify(selector) +
    '); if(!node) throw new Error("Missing input"); node.scrollIntoView({block:"center"}); node.focus();})()');
  await key('a', 'KeyA', 65, 2);
  await command('Input.insertText', {text: value});
  assert.equal(await evaluate('document.querySelector(' + JSON.stringify(selector) + ').value'), value);
}
async function navigate(url, readySelector, width = 1280, height = 1000) {
  await command('Emulation.setEmulatedMedia', {media: ''});
  await command('Emulation.setDeviceMetricsOverride', {width, height, deviceScaleFactor: 1, mobile: false});
  pageRequests = [];
  await command('Page.navigate', {url});
  await waitFor(() => evaluate('document.URL === ' + JSON.stringify(url) +
    ' && document.readyState === "complete" && !!document.querySelector(' +
    JSON.stringify(readySelector) + ')'), 'actual page ' + url);
}
async function saveArtifact(name, bytes, details = {}) {
  const buffer = Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes);
  assert.ok(buffer.length <= 2 * 1024 * 1024, 'Bounded artifact: ' + name);
  await writeFile(join(output, name), buffer);
  const value = {name, bytes: buffer.length, sha256: hash(buffer), ...details};
  report.artifacts.push(value);
  return value;
}
async function screenshot(name, selector = null) {
  if (selector) await evaluate('document.querySelector(' + JSON.stringify(selector) +
    ').scrollIntoView({block:"start"})');
  const {data} = await command('Page.captureScreenshot', {format: 'png', captureBeyondViewport: false});
  return saveArtifact(name, Buffer.from(data, 'base64'), {kind: 'actual Chrome screenshot'});
}
async function screenshotLastQuestion(name) {
  await evaluate('[...document.querySelectorAll(".handout-question")].at(-1).scrollIntoView({block:"start"})');
  return screenshot(name);
}
async function downloaded(button, name) {
  const prior = new Set(downloads.keys());
  await activate(button);
  let actual;
  await waitFor(() => {
    actual = [...downloads.values()].find(value => !prior.has(value.guid) && value.state === 'completed');
    return !!actual;
  }, 'actual download ' + name);
  const bytes = await readFile(join(downloadPath, actual.guid));
  await saveArtifact(name, bytes, {kind: 'actual browser download',
    suggestedFilename: actual.suggestedFilename});
  return {bytes, file: join(output, name), suggestedFilename: actual.suggestedFilename};
}
async function chooseFile(file) {
  const count = chooserEvents.length;
  await activate('#choose-handout-file');
  await waitFor(() => chooserEvents.length > count, 'native handout file chooser');
  const event = chooserEvents.at(-1);
  assert.equal(event.mode, 'selectSingle');
  let identity = {backendNodeId: event.backendNodeId};
  if (!event.backendNodeId) {
    const {root} = await command('DOM.getDocument');
    const {nodeId} = await command('DOM.querySelector', {nodeId: root.nodeId, selector: '#handout-file'});
    identity = {nodeId};
  }
  const {node} = await command('DOM.describeNode', identity);
  const attributes = Object.fromEntries(Array.from({length: node.attributes.length / 2},
    (_, index) => node.attributes.slice(index * 2, index * 2 + 2)));
  assert.equal(attributes.id, 'handout-file');
  assert.equal(attributes.type, 'file');
  await command('DOM.setFileInputFiles', {files: file ? [file] : [], ...identity});
}
async function stagedFile(file) {
  await chooseFile(file);
  await waitFor(() => evaluate('!document.querySelector("#handout-preview").hidden && ' +
    '!document.querySelector("#use-handout-deck").matches(":disabled")'), 'validated pending preview');
}
async function holdRead(file) {
  await evaluate('(() => { const original=File.prototype.text; const state=' +
    'window.__handoutReceiverRead={original,pending:false,release:null}; ' +
    'File.prototype.text=function(){const actual=original.call(this); if(this.name!==' +
    JSON.stringify(basename(file)) + ') return actual; state.pending=true; ' +
    'return new Promise((resolve,reject)=>{state.release=async(mode)=>{' +
    'const text=await actual; state.pending=false; if(mode==="reject") ' +
    'reject(new Error("Independent delayed read refusal")); else resolve(text);};});};})()');
}
async function releaseRead(mode = 'resolve') {
  await evaluate('window.__handoutReceiverRead.release(' + JSON.stringify(mode) + ')');
  await evaluate('File.prototype.text=window.__handoutReceiverRead.original');
  await sleep(100);
}
async function observePrint() {
  await evaluate('(() => {if(window.__handoutReceiverPrint) return; ' +
    'const original=window.print; const state=window.__handoutReceiverPrint={requests:[],before:0,after:0}; ' +
    'addEventListener("beforeprint",()=>state.before++); addEventListener("afterprint",()=>state.after++); ' +
    'window.print=function(...args){state.requests.push(document.querySelector("#handout-paper")?.dataset.handoutKind??null); ' +
    'return original.apply(window,args);};})()');
}
async function numbers(){
 return evaluate('[...document.querySelectorAll(".handout-question")].map(q=>Number(q.dataset.questionNumber))');
}
async function space(selector){
 const focused=await evaluate('(()=>{const n=document.querySelector('+JSON.stringify(selector)+');if(!n||n.matches(":disabled"))return false;n.scrollIntoView({block:"center"});n.focus();return document.activeElement===n;})()');
 assert.ok(focused,selector);await key(' ','Space',32);
}
async function assertSelection(expected){
 assert.deepEqual(await numbers(),expected);
 const selected=await evaluate('[...document.querySelectorAll("#handout-question-list input")].flatMap((q,i)=>q.checked?[i+1]:[])');
 assert.deepEqual(selected,expected);
 assert.equal(await evaluate('document.querySelector("#selected-handout-controls").disabled'),expected.length===0);
 assert.equal(await evaluate('document.querySelector("#handout-paper").hidden'),expected.length===0);
}
function dataOf(bytes){const text=bytes.toString('utf8');const start='<script id="handout-data" type="application/json">';return JSON.parse(text.slice(text.indexOf(start)+start.length,text.indexOf('</script>',text.indexOf(start))));}
function checkCopy(bytes,kind,chosen){
 const data=dataOf(bytes);
 assert.equal(data.kind,kind);
 assert.deepEqual(data.questions.map(q=>q.number),chosen);
 assert.deepEqual(data.questions.map(q=>q.id),chosen.map(n=>fixture.items[n-1].id));
 const concepts=new Set(chosen.map(n=>fixture.items[n-1].concept));
 assert.deepEqual(data.concepts,fixture.concepts.filter(c=>concepts.has(c)));
 assert.equal(data.attribution,fixture.attribution);assert.equal(data.license,fixture.license);
 data.questions.forEach((q,i)=>{
  const source=fixture.items[chosen[i]-1];assert.equal(q.prompt,source.prompt);assert.deepEqual(q.options,source.options);assert.equal(q.transfer,source.transfer);
  if(kind==='worksheet'){assert.equal(Object.hasOwn(q,'answer'),false);assert.equal(Object.hasOwn(q,'explanation'),false);}
  else{assert.equal(q.answer,source.answer);assert.equal(q.explanation,source.explanation);}
 });
 for(let i=0;i<fixture.items.length;i++){
  const q=fixture.items[i];
  if(!chosen.includes(i+1)){assert.equal(bytes.includes(Buffer.from(q.prompt)),false);assert.equal(bytes.includes(Buffer.from(q.transfer)),false);}
  if(kind==='worksheet'||!chosen.includes(i+1))assert.equal(bytes.includes(Buffer.from(q.explanation)),false);
 }
 return data;
}
async function noOverflow(){
 assert.equal(await evaluate('document.documentElement.scrollWidth>innerWidth+1'),false);
 assert.equal(await evaluate('document.querySelectorAll("iframe").length'),0);
 assert.equal(await evaluate('typeof globalThis.leaked'), 'undefined');
}
async function printCopy(button,name,kind){
 await observePrint();const before=await evaluate('window.__handoutReceiverPrint.requests.length');
 await activate(button);await waitFor(()=>evaluate('window.__handoutReceiverPrint.requests.length>'+before),'real print request');
 assert.equal(await evaluate('window.__handoutReceiverPrint.requests.at(-1)'),kind);
 const pdf=await command('Page.printToPDF',{printBackground:true,preferCSSPageSize:true});
 const b=Buffer.from(pdf.data,'base64');assert.equal(b.subarray(0,4).toString(),'%PDF');
 await saveArtifact(name,b,{kind:'Chrome printToPDF after original window.print'});
}
try {
  assert.ok(typeof WebSocket === 'function', 'Use Node 22 or newer with built-in WebSocket');
  browser = spawn(executable, [
    '--headless=new', '--disable-gpu',
    '--disable-background-networking', '--disable-component-update', '--disable-sync',
    '--no-first-run', '--no-default-browser-check',
    '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0',
    '--user-data-dir=' + profile, 'about:blank'
  ], {stdio: ['ignore', 'ignore', 'pipe']});
  let launchError;
  browser.on('error', error => { launchError = error; });
  browser.stderr.on('data', data => { browserLog = (browserLog + data).slice(-6000); });
  let port;
  let endpoint;
  await waitFor(async () => {
    if (launchError) throw launchError;
    if (browser.exitCode !== null) throw new Error('Browser exited: ' + browserLog);
    [port, endpoint] = (await readFile(join(profile, 'DevToolsActivePort'), 'utf8')).trim().split('\n');
    return !!(port && endpoint);
  }, 'installed browser startup');
  socket = new WebSocket('ws://127.0.0.1:' + port + endpoint);
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id) {
      const request = pending.get(message.id);
      if (!request) return;
      pending.delete(message.id);
      clearTimeout(request.timer);
      if (message.error) request.reject(new Error(message.error.message));
      else request.resolve(message.result);
    } else if (message.method === 'Browser.downloadWillBegin' ||
               message.method === 'Browser.downloadProgress') {
      const value = message.params;
      downloads.set(value.guid, {...downloads.get(value.guid), ...value});
    } else if (message.method === 'Page.fileChooserOpened') {
      chooserEvents.push(message.params);
    } else if (message.method === 'Runtime.exceptionThrown') {
      pageErrors.push(message.params.exceptionDetails.exception?.description
        ?? message.params.exceptionDetails.text);
    } else if (message.method === 'Network.requestWillBeSent') {
      pageRequests.push(message.params.request.url); allRequests.push(message.params.request.url);
    }
  });
  await new Promise((resolve_, reject) => {
    socket.addEventListener('open', resolve_, {once: true});
    socket.addEventListener('error', reject, {once: true});
  });
  report.browser = await command('Browser.getVersion', {}, false);
  await command('Browser.setDownloadBehavior', {behavior: 'allowAndName', downloadPath, eventsEnabled: true}, false);
  const {targetId} = await command('Target.createTarget', {url: 'about:blank'}, false);
  ({sessionId} = await command('Target.attachToTarget', {targetId, flatten: true}, false));
  await command('Page.enable');
  await command('Runtime.enable');
  await command('Network.enable');
  await command('Page.setInterceptFileChooserDialog', {enabled: true});


  for(const [label,url,width,height] of [['modular',base+'/handout/index.html',1280,960],['standalone',pathToFileURL(join(project,'handout.html')).href,390,844]]){
    await navigate(url,'#choose-handout-file',width,height);
    await stagedFile(fixturePath);await activate('#use-handout-deck');
    await assertSelection([1,2,3,4]);
    assert.equal(await evaluate('document.activeElement.classList.contains("paper-title")'),true);
    const allCopy=await downloaded('#save-worksheet',label+'-all-worksheet.html');
    assert.equal(hash(allCopy.bytes),'5af58ee687c3f4c6c51d6e0a2e2a6b4c24b7217f31a3e65fead1f25dd85c0a24');
    await activate('#clear-handout-questions');await assertSelection([]);
    for(const id of ['print-worksheet','print-answer-key','save-worksheet','save-answer-key'])
      assert.equal(await evaluate('document.querySelector("#'+id+'").matches(":disabled")'),true);
    await key('Tab','Tab',9);
    assert.equal(await evaluate('document.activeElement.id'),'handout-question-0');
    await key('Tab','Tab',9);await key(' ','Space',32);
    await key('Tab','Tab',9);await key(' ','Space',32);
    await assertSelection([2,3]);await noOverflow();
    await screenshot(label+'-selected.png','#handout-question-controls');
    const worksheet=await downloaded('#save-worksheet',label+'-selected-worksheet.html');
    const answerKey=await downloaded('#save-answer-key',label+'-selected-answer-key.html');
    checkCopy(worksheet.bytes,'worksheet',[2,3]);checkCopy(answerKey.bytes,'answer-key',[2,3]);
    passed(label+': actual keyboard selection, empty guard, original numbering and three real downloads');
    await chooseFile(null);await assertSelection([2,3]);
    await chooseFile(invalidPath);await waitFor(()=>evaluate('document.querySelector("#handout-status").textContent.includes("not valid JSON")'),'invalid file refused');await assertSelection([2,3]);
    await stagedFile(replacementPath);await activate('#cancel-handout-preview');await assertSelection([2,3]);
    await stagedFile(replacementPath);await space('#handout-question-0');await assertSelection([1,2,3]);
    assert.equal(await evaluate('document.querySelector("#handout-preview").hidden'),true);
    await space('#handout-question-0');await assertSelection([2,3]);
    await holdRead(slowPath);await chooseFile(slowPath);await waitFor(()=>evaluate('window.__handoutReceiverRead.pending'),'real read held');
    await space('#handout-question-0');await releaseRead();await assertSelection([1,2,3]);
    assert.equal(await evaluate('document.querySelector("#handout-preview").hidden'),true);
    await space('#handout-question-0');await assertSelection([2,3]);
    passed(label+': cancel/reject preserve selection and actual edits retire staged/late replacement');
    await printCopy('#print-worksheet',label+'-worksheet.pdf','worksheet');await assertSelection([2,3]);
    assert.equal(await evaluate('document.querySelectorAll(".question-explanation,.correct-option").length'),0);
    await printCopy('#print-answer-key',label+'-answer-key.pdf','answer-key');
    assert.deepEqual(await numbers(),[2,3]);
    passed(label+': original print actions use current worksheet/key and produce separate native PDFs');
    await activate('#select-all-handout-questions');await assertSelection([1,2,3,4]);
    const allKey=await downloaded('#save-answer-key',label+'-all-answer-key.html');
    assert.equal(hash(allKey.bytes),'369e2722d7a2934177efd6442e0eaaa96a2e718ffc2cb2f47dc0b5e931f869fd');
    await stagedFile(replacementPath);await activate('#use-handout-deck');await assertSelection([1,2]);
    assert.equal(await evaluate('document.querySelector("#selected-handout-title").textContent'),replacement.title);
    passed(label+': all-selection parity and explicit new-deck reset');
    for(const [kind,copy] of [['worksheet',worksheet],['answer-key',answerKey]]){
      await navigate(pathToFileURL(copy.file).href,'#print-handout',width,height);
      assert.deepEqual(await numbers(),[2,3]);await noOverflow();
      assert.equal(await evaluate('document.querySelectorAll(".question-explanation").length'),kind==='worksheet'?0:2);
      assert.deepEqual(await evaluate('[...document.querySelectorAll(".paper-concepts li")].map(n=>n.textContent)'),['First concept','Second concept']);
      assert.ok(pageRequests.every(v=>v.startsWith('file:')||v.startsWith('blob:')));
      if(kind==='worksheet')await screenshot(label+'-reopened-worksheet.png');
    }
    passed(label+': exact saved selected copies reopen offline with separate answer data');
  }
  assert.deepEqual(pageErrors,[]);
  assert.ok(allRequests.every(u=>u.startsWith(base+'/')||u.startsWith('file:')||u.startsWith('blob:')));
  report.status='passed';
}catch(error){
 report.status='failed';report.error=error.stack??String(error);report.browserLog=browserLog;process.exitCode=1;
 try{report.lastPage=await evaluate('({url:location.href,focus:document.activeElement?.outerHTML,text:document.body?.innerText.slice(0,6000)})');await screenshot('failure.png');}catch{}
 console.error(report.error);
}finally{
 if(socket?.readyState===WebSocket.OPEN){try{await command('Browser.close',{},false);}catch{}}
 socket?.close();for(const p of pending.values())clearTimeout(p.timer);
 if(browser&&browser.exitCode===null)await Promise.race([new Promise(r=>browser.once('exit',r)),sleep(3000)]);
 if(browser&&browser.exitCode===null)browser.kill();
 server.closeAllConnections();await new Promise(r=>server.close(r));
 await rm(profile,{recursive:true,force:true,maxRetries:5,retryDelay:300});
 const after=Object.fromEntries(await Promise.all(sourcePaths.map(async p=>[p,hash(await readFile(join(project,p)))])));
 report.sourceUnchanged=JSON.stringify(sourceBefore)===JSON.stringify(after);
 const runtimeAfter={};
 for(const [name,value] of Object.entries(expected.runtime))runtimeAfter[name]={path:value.path,sha256:await hashFile(value.path)};
 report.runtimeAfter=runtimeAfter;report.runtimeUnchanged=JSON.stringify(runtimeAfter)===JSON.stringify(runtimeBefore);
 report.receiverUnchanged=receiverBefore===await hashFile(receiverPath);
 if(!report.runtimeUnchanged||!report.receiverUnchanged){report.status='failed';process.exitCode=1;}
 if(!report.sourceUnchanged){report.status='failed';process.exitCode=1;}
 report.pageErrors=pageErrors;report.requests=allRequests;report.fileChoosers=chooserEvents.length;report.browserExit=browser?.exitCode;report.profileRemoved=true;report.serverClosed=true;
 await writeFile(join(output,'receiving.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({status:report.status,checks:report.checks.length,artifacts:report.artifacts.length,sourceUnchanged:report.sourceUnchanged}));
}
