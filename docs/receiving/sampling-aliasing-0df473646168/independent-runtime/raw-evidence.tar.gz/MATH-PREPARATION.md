# Independent sampling review: mathematical preparation

Status: preparation only. No RecallWeave candidate has been executed by this receiver. The implementation and twelve-question course remain owned by estate_product; existing course/importer/Deck studio source remains outside this scope. Native execution will wait for the author freeze and a fixed receiving script.

## Primary basis

Alan V. Oppenheim, *Signals and Systems*, Lecture 16, Sampling, MIT OpenCourseWare, pages 16-1 and 16-2: https://ocw.mit.edu/courses/res-6-007-signals-and-systems-spring-2011/8708ec068ebdea2c4ee2f38fad39fb83_MITRES_6_007S11_lec16.pdf . Its sufficient condition uses a bandlimited continuous-time signal, equally spaced samples, a rate strictly above twice the highest frequency, and ideal low-pass reconstruction. It also explains the ambiguity between multiple sinusoids agreeing at every sample.

Claude E. Shannon, *Communication in the Presence of Noise*, Proceedings of the IRE 37(1), January 1949, section II, pages 11-12: https://fab.cba.mit.edu/classes/S62.12/docs/Shannon_noise.pdf . The original Fourier-based sampling and interpolation discussion gives historical context. Its compact endpoint formulation is not used to infer recoverability of arbitrary-phase pure tones exactly at the sampling boundary. The explicit elementary counterexample below determines that receiving control.

Both primary sources were retrieved on 2026-10-08. These are short paraphrases and references, not redistributed source PDFs or copied course text. All receiver identities, numerical examples and expected results below are independently derived.

## Sample identities to receive

Let a real sampled cosine be x[n] = A cos(2*pi*f*n/fs + phi), with positive sample rate fs and integer index n. Adding k*fs to f adds an integer multiple of 2*pi to the phase at every sample. Thus (f + k*fs, phi) and (f, phi) give the same entire discrete sequence. Reflection requires the correct phase: (fs - f, phi) agrees with (f, -phi) for a cosine. At nonzero phase it need not agree with (f, phi). This difference is consequential if the lab includes a phase control. If the lab intentionally fixes phase to zero, the receiver will preserve that stated specialization.

For fs=12 Hz, f=2 Hz, phi=pi/6 and A=1, the exact six-sample cosine period is:

[sqrt(3)/2, 0, -sqrt(3)/2, -sqrt(3)/2, 0, sqrt(3)/2].

Frequencies 14 and 26 Hz at the same phase have the identical period. A 10 Hz cosine at phi=pi/6 instead has the exact period:

[sqrt(3)/2, sqrt(3)/2, 0, -sqrt(3)/2, -sqrt(3)/2, 0].

This is the 2 Hz cosine with phase -pi/6. The sequences differ at index 1 by sqrt(3)/2, so a mistaken phase-preserving reflection cannot pass within a reasonable numerical tolerance. The zero-phase specialization at fs=12, f=2 has the period [1, 1/2, -1/2, -1, -1/2, 1/2]; 10, 14 and 26 Hz give those same samples.

The analogous signed-frequency sine identity is sin(-theta+phi) = sin(theta+pi-phi). The receiver will only use that case if the actual lab supports sine; it will not invent an unsupported waveform interface.

## Strict boundary and interpretation controls

At f=fs/2, x[n] = A*(-1)^n*cos(phi). The sample sequence loses the sine quadrature. A nonzero continuous-time cosine with phi=pi/2 gives all-zero samples, while phi=0 gives an alternating sequence. Different amplitude/phase pairs with equal A*cos(phi) also coincide. Therefore a general arbitrary-phase tone cannot be uniquely recovered at equality. The lab should retain an explicit boundary status or explanation instead of asserting unconditional recovery.

The rate fs is distinct from the Nyquist frequency fs/2 and the signal-dependent Nyquist rate 2*B. A sufficient low-pass-bandlimited reconstruction assumption is fs>2*B. It also presumes ideal uniform samples and an appropriate reconstruction operation. A displayed finite record, a line connecting samples, or one matching alias curve does not establish those assumptions or identify an unrestricted analog original. The receiver will inspect any status and course wording within the lab's actual single-tone scope.

Exactly representable boundary controls can use fs=12 and f=6-2^-20, 6, 6+2^-20. Their mathematical below/equal/above classifications are fixed independently; the implementation's documented display precision or explicit tolerance will be reported separately from the underlying numeric result.

At an integer multiple of fs, a zero-phase cosine gives the constant sequence 1 and has a zero-frequency alias. The alias interval for real cosine frequencies can include both 0 and fs/2. A zero-frequency case must remain representable if the supported interface admits it.

## Intended receiving surface

After the native contract is available, select a small subset of these fixed identities that spans the implemented controls. Use the real frozen module and existing course model to obtain output. Consume an actual emitted numeric table and CSV with an independent standard reader; compare every exported sample index, time and amplitude to the analytical sequence and the original parameters. Check row-count and endpoint rules against the declared interval contract, not an invented convention. Compare course worked answers to independent arithmetic and supported native examples; do not run the author's test selection or repeat its browser scenarios.

No native result, pass count or defect claim is made by this preparation document. Candidate/source identities, receiver freeze and actual process receipts will accompany subsequent execution.
