import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {spawn,spawnSync} from 'node:child_process';
const qa='/Users/me/recallweave-dc-learner-receiving-bd1abdb2f886-20261008';
const sha=b=>createHash('sha256').update(b).digest('hex');
const blob=b=>createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const expected=[
['source/demo.html','d0819e8630ff119be2c078408907ab53e3725999c8fdf71d35deb7f230d3bcd9','223ee1a4452e01c0fea2194c6921f82f4a062f6e'],
['source/courses/dc-circuits.json','cfe7a4586a4a97aa96356e9afe7fea5bc1e216a0aff70454476397c909058ccb','fb5a66a86c127cfe81f691ad4c3a81081ad5fe0c'],
['source/courses/dc-circuits.md','c3262be7f16448b8da30716169cee424efe3200290bee78a1ad2ca7acf83fa93','2f0f4b67cdd44858be7f8bbab0bde34dbe7ee4d6'],
['browser-helpers.mjs','03ceb9845d9ff65eb8f76609473831a506e5850634399d298ab8ae575fcce051',null],
['learner-consumer-contract.json','9bbd951d4e7e7a3ac1ddb2732ea8a9a68c3252daa27a8d5b3c881f6fc84cea30',null],
['original-thinkpad/receive_learner.mjs','77200679cad85dfd347030ca2943845e59f21df26a4a8eb3ca574ea2ec06a6af',null]
];
const rows=[];
for(const [path,expectedSha,expectedBlob]of expected){
 const bytes=await readFile(join(qa,path));
 assert.equal(sha(bytes),expectedSha,'Transferred SHA '+path);
 if(expectedBlob)assert.equal(blob(bytes),expectedBlob,'Transferred Git identity '+path);
 rows.push({path,bytes:bytes.length,sha256:sha(bytes),git_blob:blob(bytes)});
}
const adaptation=JSON.parse(await readFile(join(qa,'environment-adaptation.json')));
let original=await readFile(join(qa,'original-thinkpad/receive_learner.mjs'),'utf8');
for(const [before,after]of adaptation.replacements){
 assert.equal(original.split(before).length,2);
 original=original.replace(before,after);
}
const driver=join(qa,'receive_learner.mjs');
const driverBytes=await readFile(driver);
assert.equal(original,driverBytes.toString('utf8'),'Unexpected behavioral change during Mac adaptation');
const syntax=spawnSync(process.execPath,['--check',driver],{encoding:'utf8'});
const transfer={at:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,files:rows,driverSha256:sha(driverBytes),onlyRecordedEnvironmentChanges:true,syntaxExit:syntax.status,syntaxStdout:syntax.stdout,syntaxStderr:syntax.stderr};
await writeFile(join(qa,'transfer-receipt.json'),JSON.stringify(transfer,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(transfer));
if(syntax.status!==0)process.exit(syntax.status??1);
const started=new Date().toISOString(),start=performance.now();
const command=[process.execPath,driver],chunks=[];
const child=spawn(command[0],command.slice(1),{stdio:['ignore','pipe','pipe']});
for(const stream of [child.stdout,child.stderr])stream.on('data',bytes=>{chunks.push(bytes);process.stdout.write(bytes);});
const outcome=await new Promise((resolve,reject)=>{child.once('close',(exitCode,signal)=>resolve({exitCode,signal}));child.once('error',reject);});
const log=Buffer.concat(chunks);
await writeFile(join(qa,'first-process.log'),log,{flag:'wx'});
const receipt={command,started,finished:new Date().toISOString(),elapsedSeconds:(performance.now()-start)/1000,...outcome,logSha256:sha(log),driverSha256:sha(driverBytes)};
await writeFile(join(qa,'first-process.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
process.exitCode=outcome.exitCode??1;
