import fs from 'node:fs';import {spawn} from 'node:child_process';
const root='D:/Hamon/receiving/recall-genotype-counts-root-db371a37f4c8';const spec=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));const stem=root+'/'+spec.name;
const out=fs.openSync(stem+'.stdout','wx'),err=fs.openSync(stem+'.stderr','wx');
const child=spawn(spec.executable,spec.args,{cwd:spec.cwd,env:{...process.env,...spec.env},stdio:['ignore',out,err],windowsHide:false});
const launch={schema:'recall261-native-child-launch-v1',at:new Date().toISOString(),controller:process.pid,parent:process.ppid,child:child.pid,spec};fs.writeFileSync(stem+'-LAUNCH.json',JSON.stringify(launch,null,2)+'\n',{flag:'wx'});
let timeout=false;const timer=setTimeout(()=>{timeout=true;child.kill();},spec.timeoutMs);
child.on('error',e=>fs.writeFileSync(stem+'-SPAWN-ERROR.json',JSON.stringify({at:new Date().toISOString(),error:String(e)})));
child.on('close',(exitCode,signal)=>{clearTimeout(timer);fs.closeSync(out);fs.closeSync(err);const receipt={...launch,end:new Date().toISOString(),exitCode,signal,timeout};fs.writeFileSync(stem+'-EXIT.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));process.exitCode=exitCode===0&&!timeout?0:1;});
