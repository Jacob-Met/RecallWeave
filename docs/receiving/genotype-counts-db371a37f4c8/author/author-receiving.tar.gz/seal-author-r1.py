import ctypes,datetime,gzip,hashlib,io,json,os,pathlib,shutil,tarfile
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8');S=R/'seal-r1';S.mkdir(exist_ok=False)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin_bytes(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def pin(p):return pin_bytes(p.read_bytes())
def write(p,obj):p.write_bytes((json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
class MEM(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['totalPhys','availPhys','totalPage','availPage','totalVirtual','availVirtual','availExtended']]
m=MEM();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
capacity={'CFree':shutil.disk_usage('C:/').free,'DFree':shutil.disk_usage('D:/').free,'memoryAvailable':m.availPhys};assert capacity['CFree']>=1073741824 and capacity['DFree']>=1073741824 and m.availPhys>=2147483648
manifest=json.loads((R/'CANDIDATE-MANIFEST-r3.json').read_text(encoding='utf-8'))
for f in manifest:assert pin(R/'candidate-r3'/f['path'])=={k:f[k] for k in ['bytes','sha256','git']}
assert json.loads((R/'browser-controller-r1.json').read_text())['wrapperExit']==0
files=[]
for p in sorted(R.rglob('*')):
 rel=p.relative_to(R)
 if rel.parts[0] in ['seal-r1','publication']:continue
 assert not p.is_symlink(),str(p)
 if p.is_file():files.append({'path':rel.as_posix(),**pin(p)})
assert all('/tmp/' not in f['path'] for f in files)
doc={'format':'genotype-counts-author-archive/1','sealedAt':now(),'root':str(R),'capacity':capacity,'sourceCommit':'fee3679af46b15b158c2a00a99aad09935f7daec','sourceTree':'6ddd283615489dfb5aa715a313bef4401bbd5fe0','files':files,'count':len(files),'bytes':sum(f['bytes'] for f in files),'excluded':['seal-r1/**','publication/**'],'boundary':'All exact owned native source/evidence epochs; no peer namespace or donor payload copied. Donor manifests and before/after pins are retained.'}
write(S/'MANIFEST.json',doc);mbytes=(S/'MANIFEST.json').read_bytes()
archive=S/'author-receiving.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for entry in files+[{'path':'ARCHIVE-MANIFEST.json','bytes':len(mbytes)}]:
  body=mbytes if entry['path']=='ARCHIVE-MANIFEST.json' else (R/entry['path']).read_bytes()
  if entry['path']!='ARCHIVE-MANIFEST.json':assert pin_bytes(body)=={k:entry[k] for k in ['bytes','sha256','git']}
  info=tarfile.TarInfo(entry['path']);info.size=len(body);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)+1
 expected={f['path']:f for f in files}
 for member in members:
  assert member.isfile() and not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
  body=tar.extractfile(member).read()
  if member.name=='ARCHIVE-MANIFEST.json':assert body==mbytes
  else:assert pin_bytes(body)=={k:expected[member.name][k] for k in ['bytes','sha256','git']}
(S/'AUTHOR.md').write_bytes((R/'AUTHOR.md').read_bytes())
seal={'sealedAt':now(),'sourceCommit':doc['sourceCommit'],'archive':pin(archive),'manifest':pin(S/'MANIFEST.json'),'report':pin(S/'AUTHOR.md'),'payloadFiles':len(files),'tarMembers':len(members),'everyArchivedMemberExact':True,'allPriorAttemptsRetained':True};write(S/'SEAL.json',seal)
for entry in files:assert pin(R/entry['path'])=={k:entry[k] for k in ['bytes','sha256','git']}
audit={'at':now(),'status':'passed','archive':pin(archive),'manifest':pin(S/'MANIFEST.json'),'seal':pin(S/'SEAL.json'),'nativePayloadsUnchanged':len(files),'sourceFilesExact':len(manifest),'portableR2':pin(R/'portable-r2/genotype-counts-portable.zip'),'noProductRun':True,'rootIndependentPacket':'separate, not replaced by author evidence'};write(S/'FINAL-AUDIT.json',audit)
mapping={name:{'nativePath':str(S/name),**pin(S/name)} for name in ['author-receiving.tar.gz','AUTHOR.md','MANIFEST.json','SEAL.json','FINAL-AUDIT.json']}
write(S/'OBJECT-MAP.json',mapping);print(json.dumps({'status':'passed','wrapperPid':os.getpid(),'payloads':len(files),'members':len(members),'objects':mapping}))
