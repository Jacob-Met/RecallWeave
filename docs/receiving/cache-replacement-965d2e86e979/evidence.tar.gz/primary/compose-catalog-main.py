from pathlib import Path
import hashlib,json,subprocess,os,shutil
root=Path('/Users/me/hamon-recall-cache-965d2e86e979');src=root/'source';ev=root/'evidence'
git=lambda *a:subprocess.check_output(['git','-C',str(src),*a],text=True).strip()
assert git('rev-parse','HEAD')=='fab66b4b9e858be626e908577d90ac311f53fc96'
assert not git('status','--porcelain')
assert shutil.disk_usage(root).free>20*1024*1024
data=json.loads((ev/'catalog-main-composition-input.json').read_text())
helpers=(ev/'receive-baseline.py').read_text().split('def gh',1)[1].split('assert len(p["full_leaves"])',1)[0]
exec('def gh'+helpers)
leaves=[x for x in data['tree']['tree'] if x['type']=='blob']
assert th(leaves)==data['main']['commit']['tree']['sha']==data['tree']['sha']
old=json.loads((ev/'candidate-r1-freeze.json').read_text())
rows={x['path']:x for x in leaves}
for f in old['files']:
 if f['path']=='README.md':continue
 assert hashlib.sha256((src/f['path']).read_bytes()).hexdigest()==f['sha256']
 if f['path'] in rows:
  assert rows[f['path']]['sha']==f['gitBlob'] and rows[f['path']]['mode']==f['mode']
before={p:hashlib.sha256((src/p).read_bytes()).hexdigest() for p in git('ls-files').splitlines()}
readme=data['readme']['content']
assert gh('blob',readme.encode())==data['readme']['sha']==rows['README.md']['sha']
addition=json.loads((ev/'implementation-input.json').read_text())['readmeAddition']
(src/'README.md').write_text(readme+addition)
path=src/'courses/cache-replacement.md';guide=path.read_text()
needle='Each policy has an empty `initial` array, ordered `steps`, and `totals`.'
replacement=needle+' Its `order` field is exactly `oldest-inserted-first` for FIFO and `least-recently-used-first` for LRU; the arrays use that declared display order.'
assert guide.count(needle)==1
path.write_text(guide.replace(needle,replacement))
git('add','README.md','courses/cache-replacement.md')
git('commit','-qm','Preserve integrated catalog README and document trace ordering metadata')
record={'canonicalMain':data['main']['sha'],'canonicalTree':data['tree']['sha'],'canonicalLeaves':len(leaves),'previousCanonicalMain':data['oldMain'],'nativeHead':git('rev-parse','HEAD'),'nativeTree':git('rev-parse','HEAD^{tree}'),'priorNativeHead':'fab66b4b9e858be626e908577d90ac311f53fc96','changedNativePaths':['README.md','courses/cache-replacement.md'],'unchangedQualifiedSourceFiles':len(before)-2,'applicationUnchanged':all(hashlib.sha256((src/p).read_bytes()).hexdigest()==sha for p,sha in before.items() if p not in ('README.md','courses/cache-replacement.md')),'readmeExactCanonicalPrefix':(src/'README.md').read_text()==readme+addition,'currentCatalogManifestUntouched':True,'nativeRetest':'None: current dependency delta changes no accepted app/core/validator/UI bytes. Existing catalog build is manifest-driven and hosted checks remain a later gate.','metadataClarification':'Policy order was present in frozen R1 output. The guide now names its two exact constants; no runtime or frozen policy oracle changed.'}
(ev/'catalog-main-composition.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
