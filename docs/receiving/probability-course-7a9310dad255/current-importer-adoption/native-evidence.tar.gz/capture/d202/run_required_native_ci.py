import json,hashlib,os,subprocess,time,traceback
from pathlib import Path
root=Path("/tmp/hamon-7a9310dad255-recall19-integration")
candidate=root/"candidate"
run=root/"required-native-ci";run.mkdir()
tmp=run/"tmp";tmp.mkdir()
expected=json.loads((root/"pre-ci-source-manifest.json").read_text())
def pin(data):
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
def snapshot():
    rows=[]
    for p in sorted(candidate.rglob("*")):
        assert not p.is_symlink(),str(p)
        if p.is_file():rows.append({"path":str(p.relative_to(candidate)),"mode":"100755" if p.stat().st_mode&0o111 else "100644",**pin(p.read_bytes())})
    return rows
env={"PATH":"/usr/bin:/bin","LANG":"C.UTF-8","LC_ALL":"C.UTF-8","TMPDIR":str(tmp),"PYTHONDONTWRITEBYTECODE":"1"}
receipt={"repository":"Jacob-Met/RecallWeave","started_at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"source_tree":expected["source_tree"],"source_files":len(expected["files"]),"current_parent":expected["current_head"],"course_head":expected["course_head"],"workflow_blob":"a64c95e06e656a1875706bc013c13b82ccf8ca83","cwd":str(candidate),"source_manifest":pin((root/"pre-ci-source-manifest.json").read_bytes()),"workflow_node_major":20,"version_boundary":"Installed native Node 22.22.1 runs the unchanged required commands. Hosted Node 20 actual-head CI remains a separate gate.","commands":[],"completed":False}
start=time.monotonic()
def command(label,args,timeout=180):
    began=time.monotonic()
    with (run/(label+".stdout")).open("xb") as stdout,(run/(label+".stderr")).open("xb") as stderr:
        p=subprocess.run(args,cwd=candidate,env=env,stdout=stdout,stderr=stderr,timeout=timeout)
    out=(run/(label+".stdout")).read_bytes();err=(run/(label+".stderr")).read_bytes()
    item={"label":label,"argv":args,"exit":p.returncode,"seconds":time.monotonic()-began,"stdout":pin(out),"stderr":pin(err)}
    receipt["commands"].append(item)
    assert p.returncode==0,(label,p.returncode)
    return out.decode("utf-8")
try:
    assert snapshot()==expected["files"]
    receipt["node"]=command("node-version",["node","--version"]).strip()
    receipt["python"]=command("python-version",["python3","--version"]).strip()
    stdout=command("node-tests",["bash","--noprofile","--norc","-c","node --test tests/*.test.mjs"])
    receipt["test_summary"]="\n".join(stdout.splitlines()[-12:])
    demo_before=(candidate/"demo.html").read_bytes()
    (run/"demo-before.html").write_bytes(demo_before)
    command("make-demo",["python3","-B","tools/make_demo.py"])
    command("demo-parity",["cmp",str(run/"demo-before.html"),"demo.html"])
    assert (candidate/"demo.html").read_bytes()==demo_before
    after=snapshot()
    receipt["all_source_files_unchanged"]=after==expected["files"]
    assert receipt["all_source_files_unchanged"]
    receipt["demo"]=pin(demo_before)
    receipt["completed"]=True
except Exception as error:
    receipt["error"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
finally:
    receipt["finished_at_utc"]=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())
    receipt["seconds"]=time.monotonic()-start
    with (run/"receipt.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
    print(json.dumps(receipt,indent=2))
if not receipt["completed"]:raise SystemExit(1)
