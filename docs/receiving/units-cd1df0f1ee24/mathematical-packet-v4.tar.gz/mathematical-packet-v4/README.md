# Independent mathematical receiving: units and dimensions

The exact v4 converter passed **64 independent checks** in native Node 24.19.0: 48 numerical, refusal and display checks; four normalization probes; and twelve additional rounding probes. The same probes preserve the earlier v3 results, including three normalization failures.

## Exact source and provenance

The accepted module is Git blob **4c867b858a03f92c93a171ec0de6adcad1158229**, SHA256 **b98225814d7ccc4d93c224ddbbaf3343c0381c42e0fe1d313a14825f039d8613**, 11,668 bytes. Its frozen body is in [model-input-v4/unit-conversion.mjs](model-input-v4/unit-conversion.mjs).

The receiver froze the original 24 manually derived scale/result cases before inspecting the converter implementation or the authored course key. A Python Fraction check verifies the supplied factor tuples; it does not implement the production unit parser. Two mJ/MJ cases were added before the model's v3 table extension, prompted by the independently solved course. The mathematical oracle values are reduced rationals, separate from decimal display expectations.

Read the [original receiving contract](receiving-contract-v1/README.md), [frozen original oracles](receiving-contract-v1/units-oracles.json), [prefix addendum](model-receiver-v1/course-prefix-addendum.json), and [v4 command receipt](model-v4-receiving-command-receipt.json).

## Results

| Suite | v3 result | v4 result | Evidence |
| --- | --- | --- | --- |
| 26 exact conversions, eight incompatible pairs, nine invalid inputs, five display/case checks | 48 passed | 48 passed | [v3](model-results-v3/model-receiving.json), [v4](model-results-v4/model-receiving.json) |
| Reparse normalized grouped powers without changing dimensions or scale | 1 passed, 3 failed | 4 passed | [v3](normalization-result-v3.json), [v4](normalization-result-v4.json) |
| Independent 12-significant-digit boundary/carry/rounding cases | 12 passed | 12 passed | [v3](rounding-result-v3.json), [v4](rounding-result-v4.json) |

The v3 arithmetic for `(cm^2)^3`, `(m^2)^-1`, and `(cm^3)^0` was correct, but its normalized strings lost the grouping and could not be parsed again. The independent source review found this public representation defect. The repair preserves admitted grouping and length, canonicalizes only supported spelling conveniences, and expands superscripts inside parsing. The [exact v3-to-v4 diff](model-v3-v4.diff) leaves the rational arithmetic and decimal display algorithms unchanged. The original failed source and unmodified failed probe outputs remain included.

The additional rounding expectations were derived independently with Python Decimal at 150 digits and ROUND_HALF_UP to twelve significant digits. They distinguish the exact rational answer from a rounded display, including negative ties, carry boundaries, very small nonzero values and large exact integers.

## Interpretation and limits

These results qualify the bounded, explicitly listed unit grammar and exact scale arithmetic exercised here. Dimensional compatibility does not prove a physical law, establish a numerical coefficient, identify a physical quantity's meaning, estimate measurement uncertainty or validate learning effectiveness. No converter v2 receiving run is claimed by this receiver. The source author's earlier authored test failures and fixes belong to that author's separate receipt.

The [artifact manifest](artifact-manifest.json) pins every packet file except itself. All original stdout and stderr files are retained. These are independent receiver artifacts; they do not claim authorship of the converter.
