import pathlib,json,hashlib,datetime,os
R=pathlib.Path(__file__).resolve().parent;S=R/'candidate-r2'
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
rows=[dict(path=p.relative_to(S).as_posix(),**pin(p.read_bytes())) for p in sorted(S.rglob('*')) if p.is_file()]
runtime=[q for q in rows if not q['path'].startswith(('tests/','tools/check_','courses/dist/'))]
assert len(runtime)==30
for q in json.loads((R/'original-manifest.json').read_text()):
 assert next(x for x in rows if x['path']==q['path'])==q,q['path']
package=R/'portable-r1/sorting-networks-offline.zip'
offer=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository='Jacob-Met/RecallWeave',issue=253,original_commit='ec07bf3989132130759e5c00c6cb02eef19709d3',original_tree='a839b6877bf2824f134443829d1ce62e1bd79e50',source_root=str(S),runtime=runtime,source_manifest='candidate-source-final-r1.json',package=dict(path=str(package),**pin(package.read_bytes())),public_contract=str(R/'CONTRACT.md'),api_addendum=str(R/'PUBLIC-API-ADDENDUM.md'),presets=str(R/'PUBLIC-PRESETS.json'),preset_clarification=str(R/'PUBLIC-PRESET-CONTROL-CLARIFICATION.md'),blind_course=str(R/'COURSE-BLIND.json'),test_bodies_included=False)
(R/'candidate-source-final-r1.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode())
(R/'RUNTIME-ONLY-OFFER-r1.json').write_bytes((json.dumps(offer,indent=2)+'\n').encode())
print(json.dumps(dict(at=offer['at'],pid=os.getpid(),files=len(rows),runtime=len(runtime),offer=pin((R/'RUNTIME-ONLY-OFFER-r1.json').read_bytes()),package=offer['package'])))
