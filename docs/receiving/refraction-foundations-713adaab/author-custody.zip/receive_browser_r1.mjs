import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFile,writeFile,mkdir,mkdtemp,readdir,stat,statfs} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import os from 'node:os';

const root=resolve(process.argv[2] ?? '/home/jacob/chatgpt-recall-refraction-713adaab');
const source=join(root,'source'), output=join(root,'receiving','browser-r1');
const executable='/snap/chromium/3537/usr/lib/chromium-browser/chrome';
const hash=b=>createHash('sha256').update(b).digest('hex');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const free=async p=>{const s=await statfs(p);return s.bavail*s.bsize;};
async function sourceMap(){
 const m={};
 async function walk(dir,rel=''){
  for(const name of (await readdir(dir)).sort()){
   if(name==='.git')continue;
   const path=join(dir,name), key=rel?rel+'/'+name:name, s=await stat(path,{bigint:true});
   if(s.isDirectory())await walk(path,key);
   else if(s.isFile())m[key]={bytes:Number(s.size),sha256:hash(await readFile(path)),mtime_ns:String(s.mtimeNs)};
  }
 }
 await walk(source);return m;
}
const capacity={home_available:await free(root),tmp_available:await free('/tmp'),memory_available:os.freemem(),load:os.loadavg(),cpus:os.cpus().length};
await mkdir(output);
const report={schema:'recallweave.refraction-browser-receiving/1',started:new Date().toISOString(),source,executable,capacity,
 checks:[],pageRequests:[],pageErrors:[],downloads:[],status:'preflight',browser_started:false,
 limits:['Native direct-file learner only; not modular-server/browser-matrix coverage.','Page request events do not prove browser-wide zero network.','Screenshots show selected viewports, not full accessibility or print qualification.','Original learner estimates are model state, not efficacy evidence.']};
await writeFile(join(output,'intent.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
if(capacity.home_available<128*1024**2||capacity.tmp_available<128*1024**2||capacity.memory_available<1024**3||capacity.load[0]>Math.max(8,capacity.cpus*1.5)){
 report.status='held_before_browser_launch';report.reason='128MiB HOME/TMP,1GiB memory and bounded load admission not met';
 await writeFile(join(output,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.exitCode=2;
}else{
 const raw=await readFile(join(source,'courses/refraction-foundations.json'));
 const deck=JSON.parse(raw), byPrompt=new Map(deck.items.map(x=>[x.prompt,x]));
 const before=await sourceMap();report.before=before;
 const invalid=join(output,'invalid-deck.json');await writeFile(invalid,'{"format":',{flag:'wx'});
 const downloadPath=join(output,'downloads');await mkdir(downloadPath);
 const temp=await mkdtemp('/tmp/rf-'), profile=join(temp,'p');
 report.private_profile=profile;
 let browser,sessionId,sequence=0,buffer=Buffer.alloc(0),browserStderr='',deadline;
 const pending=new Map(),completed=new Map();
 const writeReport=()=>writeFile(join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
 function command(method,params={},scoped=true){
  const id=++sequence;
  return new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>{pending.delete(id);reject(new Error('CDP timeout: '+method));},10000);
   pending.set(id,{resolve,reject,timer});
   browser.stdio[3].write(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})})+'\0');
  });
 }
 function receive(chunk){
  buffer=Buffer.concat([buffer,chunk]);
  let end;
  while((end=buffer.indexOf(0))>=0){
   const body=buffer.subarray(0,end);buffer=buffer.subarray(end+1);if(!body.length)continue;
   const msg=JSON.parse(body.toString());
   if(msg.id&&pending.has(msg.id)){const p=pending.get(msg.id);pending.delete(msg.id);clearTimeout(p.timer);msg.error?p.reject(new Error(JSON.stringify(msg.error))):p.resolve(msg.result);}
   else if(msg.method==='Network.requestWillBeSent')report.pageRequests.push({url:msg.params.request.url,type:msg.params.type});
   else if(msg.method==='Runtime.exceptionThrown')report.pageErrors.push(msg.params.exceptionDetails.text);
   else if(msg.method==='Browser.downloadWillBegin')completed.set(msg.params.guid,{guid:msg.params.guid,name:msg.params.suggestedFilename});
   else if(msg.method==='Browser.downloadProgress'&&msg.params.state==='completed'){const d=completed.get(msg.params.guid);if(d)d.complete=true;}
  }
 }
 async function evaluate(expression){
  const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);
  return r.result.value;
 }
 async function wait(check,label){
  for(let i=0;i<100;i++){if(await check())return;await pause(100);}
  throw new Error('Timed out: '+label);
 }
 async function activate(selector){
  assert.ok(await evaluate('!!document.querySelector('+JSON.stringify(selector)+')'),selector);
  await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');
  await command('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,text:'\r'});
  await command('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});
 }
 async function chooseFile(path){
  const {root}=await command('DOM.getDocument');
  const {nodeId}=await command('DOM.querySelector',{nodeId:root.nodeId,selector:'#deck-file'});
  await command('DOM.setFileInputFiles',{nodeId,files:[path]});
 }
 const state=()=>evaluate(`({score:document.querySelector('#first-try-summary')?.textContent??null,review:[...document.querySelectorAll('.review-item')].map(x=>x.textContent),reflection:document.querySelector('#application-reflection')?.value??null,progress:document.querySelector('[role="progressbar"]')?.getAttribute('aria-valuenow')})`);
 async function screenshot(name,width,height){
  await command('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
  const {data}=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
  const bytes=Buffer.from(data,'base64');await writeFile(join(output,name),bytes,{flag:'wx'});
  report.checks.push({check:'viewport',name,width,height,sha256:hash(bytes),bytes:bytes.length,overflow:await evaluate('document.documentElement.scrollWidth>innerWidth')});
 }
 async function download(label){
  const existing=new Set(completed.keys());await activate('#save-notes-button');
  await wait(()=>Promise.resolve([...completed.values()].some(d=>!existing.has(d.guid)&&d.complete)),'actual notes download');
  const d=[...completed.values()].find(d=>!existing.has(d.guid)&&d.complete);
  const bytes=await readFile(join(downloadPath,d.guid));const text=bytes.toString('utf8');
  for(const item of deck.items)for(const field of [item.prompt,item.options[item.answer],item.explanation,item.transfer])assert.ok(text.includes(field),item.id);
  assert.ok(text.includes(deck.attribution));
  report.downloads.push({...d,label,bytes:bytes.length,sha256:hash(bytes)});
  return text;
 }
 try{
  const flags=['--headless','--disable-gpu','--remote-debugging-pipe','--user-data-dir='+profile,'--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--disable-default-apps','--disable-domain-reliability','--host-resolver-rules=MAP * ~NOTFOUND','--disable-dev-shm-usage','about:blank'];
  report.flags=flags;report.browser_started=true;report.status='running';
  browser=spawn(executable,flags,{stdio:['ignore','ignore','pipe','pipe','pipe'],detached:true,env:{...process.env,TMPDIR:temp}});
  report.browser_pid=browser.pid;browser.stdio[4].on('data',receive);browser.stderr.on('data',b=>{if(browserStderr.length<262144)browserStderr+=b.toString();});
  deadline=setTimeout(()=>{report.deadline_reached=true;try{process.kill(-browser.pid,'SIGTERM');}catch{}},120000);
  report.version=await command('Browser.getVersion',{},false);
  await command('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath,eventsEnabled:true},false);
  const {targetId}=await command('Target.createTarget',{url:'about:blank'},false);
  ({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));
  await command('Page.enable');await command('Runtime.enable');await command('Network.enable');
  await command('Network.setBlockedURLs',{urls:['http://*','https://*']});
  await command('Emulation.setDeviceMetricsOverride',{width:1200,height:900,deviceScaleFactor:1,mobile:false});
  await command('Page.navigate',{url:pathToFileURL(join(source,'demo.html')).href});
  await wait(()=>evaluate("!!document.querySelector('#start-button')"),'canonical learner ready');
  const initial=await state();
  await chooseFile(join(source,'courses/refraction-foundations.json'));
  await wait(()=>evaluate("!!document.querySelector('#start-deck')"),'preview');
  assert.equal(await evaluate("document.querySelector('#deck-preview-title').textContent"),deck.title);
  assert.equal(await evaluate("document.querySelectorAll('#deck-preview ol li').length"),16);
  assert.deepEqual(await state(),initial);
  await activate('#cancel-deck');assert.deepEqual(await state(),initial);
  report.checks.push({check:'valid preview and cancel preserve original session',passed:true});
  await chooseFile(join(source,'courses/refraction-foundations.json'));
  await wait(()=>evaluate("!!document.querySelector('#start-deck')"),'second preview');
  await activate('#start-deck');
  await wait(()=>evaluate("!!document.querySelector('.question-card h2')"),'explicit start');
  await screenshot('learner-desktop.png',1200,900);
  const seen=[];
  for(let i=0;i<16;i++){
   const prompt=await evaluate("document.querySelector('.question-card h2').textContent"),item=byPrompt.get(prompt);
   assert.ok(item&&!seen.includes(item.id));seen.push(item.id);
   const choice=item.id==='refract-critical-boundary'?1:item.answer;
   await activate('[data-choice="'+choice+'"]');
   assert.ok(await evaluate("document.querySelector('#feedback-slot').textContent").then(t=>t.includes(item.explanation)));
   await activate('#next-button');
  }
  await wait(()=>evaluate("!!document.querySelector('#first-try-summary')"),'completed learner');
  assert.match((await state()).score,/15 of 16/);
  await evaluate("document.querySelector('#application-reflection').value='Keep the medium order explicit; equality is the grazing limit.';document.querySelector('#application-reflection').dispatchEvent(new Event('input',{bubbles:true}))");
  const first=await download('first-session');
  assert.match(first,/15 of 16 connections correct on the first try/);assert.match(first,/Not started. 1 missed connection/);
  const preserved=await state();
  await chooseFile(invalid);await wait(()=>evaluate("document.querySelector('#deck-status').classList.contains('deck-error')"),'invalid-file refusal');
  assert.deepEqual(await state(),preserved);
  report.checks.push({check:'invalid actual file preserves completed session and reflection',passed:true});
  await activate('#practice-button');
  assert.equal(await evaluate("document.querySelector('.practice-card h2').textContent"),deck.items.find(x=>x.id==='refract-critical-boundary').prompt);
  await activate('[data-practice-choice="2"]');await activate('#practice-next');
  const final=await download('after-practice');
  assert.match(final,/15 of 16 connections correct on the first try/);assert.match(final,/1 of 1 practice answers recorded; 1 correct on retry/);
  assert.ok(final.includes('Keep the medium order explicit; equality is the grazing limit.'));
  assert.equal((await state()).review.length,16);
  await screenshot('learner-review-mobile.png',390,844);
  assert.equal(report.pageErrors.length,0);
  assert.equal(report.pageRequests.filter(x=>/^https?:/.test(x.url)).length,0);
  report.checks.push({check:'all16 actual questions, separate15/16 first pass,1/1 retry and two real note downloads',passed:true,seen});
  report.status='passed';
 }catch(error){report.status='failed';report.error=String(error.stack??error);process.exitCode=1;}
 finally{
  clearTimeout(deadline);
  if(browser){
   try{await command('Browser.close',{},false);}catch{}
   await pause(500);
   if(browser.exitCode===null){try{process.kill(-browser.pid,'SIGTERM');}catch{}await pause(500);}
   if(browser.exitCode===null){try{process.kill(-browser.pid,'SIGKILL');}catch{}}
   report.browser_exit_code=browser.exitCode;
  }
  report.after=await sourceMap();report.source_bytes_and_mtimes_unchanged=JSON.stringify(before)===JSON.stringify(report.after);
  if(!report.source_bytes_and_mtimes_unchanged){report.status='failed';process.exitCode=1;}
  report.finished=new Date().toISOString();
  await writeFile(join(output,'browser-stderr-private.txt'),browserStderr,{flag:'wx'});
  report.private_browser_stderr={bytes:Buffer.byteLength(browserStderr),sha256:hash(browserStderr),publish:false};
  await writeReport();
  console.log(JSON.stringify({status:report.status,report:join(output,'report.json'),sha256:hash(await readFile(join(output,'report.json'))),checks:report.checks.length,downloads:report.downloads.length,source_unchanged:report.source_bytes_and_mtimes_unchanged}));
 }
}
