import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {parseDeck} from './native-deck.mjs';

const [coursePath, blindPath] = process.argv.slice(2);
assert.ok(coursePath && blindPath, 'Pass exact candidate course and previously sealed blind solution paths');
const source = readFileSync(coursePath), blindBytes = readFileSync(blindPath);
const sha256 = b => createHash('sha256').update(b).digest('hex');
const blind = JSON.parse(blindBytes);
function checkAnswers(deck) {
  assert.equal(deck.items.length, 12);
  assert.deepEqual(deck.items.map(x => x.id), blind.items.map(x => x.id));
  for (let i = 0; i < 12; i++) {
    const actual = deck.items[i], expected = blind.items[i];
    for (const key of ['id', 'concept', 'prompt', 'options', 'answer'])
      assert.deepEqual(actual[key], expected[key], actual.id + '.' + key);
    assert.equal(actual.options.length, 4);
  }
}
try {
  const deck = parseDeck(source.toString('utf8'));
  checkAnswers(deck);
  assert.deepEqual(deck.concepts, [
    'Chromosome phase', 'Parental and recombinant gametes',
    'Weighted test crosses', 'Interpreting recombination evidence'
  ]);
  const prereqs = [
    [], ['Chromosome phase'],
    ['Chromosome phase', 'Parental and recombinant gametes'],
    ['Parental and recombinant gametes', 'Weighted test crosses']
  ];
  deck.items.forEach((x, i) => assert.deepEqual(x.prerequisites, prereqs[Math.floor(i / 3)]));
  const negatives = [];
  assert.equal(blind.negativeControlIds.length, 2);
  for (const id of blind.negativeControlIds) {
    const mutated = JSON.parse(JSON.stringify(deck));
    const item = mutated.items.find(x => x.id === id);
    assert.ok(item);
    item.answer = (item.answer + 1) % item.options.length;
    const admitted = parseDeck(JSON.stringify(mutated));
    assert.throws(() => checkAnswers(admitted));
    negatives.push({id, nativeSchemaAdmitted: true, independentAnswerCheckRejected: true});
  }
  assert.deepEqual(readFileSync(coursePath), source);
  assert.deepEqual(readFileSync(blindPath), blindBytes);
  console.log(JSON.stringify({schema: 'recallweave-linkage-independent-course-native/1',
    passed: true, node: process.version, sourceSha256: sha256(source),
    blindSolutionSha256: sha256(blindBytes), questions: 12, concepts: 4,
    blindAnswersMatch: true, exactPromptsOptionsMatch: true, negatives,
    sourceUnchanged: true,
    limit: 'Native schema/key equality does not replace manual scientific review of explanations, distractors and transfer wording.'
  }, null, 2));
} catch (error) {
  console.log(JSON.stringify({schema: 'recallweave-linkage-independent-course-native/1',
    passed: false, node: process.version, sourceSha256: sha256(source),
    blindSolutionSha256: sha256(blindBytes), failure: {name:error.name,message:error.message,stack:error.stack}
  }, null, 2));
  process.exitCode=1;
}
