import datetime,json,pathlib,subprocess,sys,os
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
path=R/'browser-controller-r1.json'
assert not path.exists()
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controllerPid':os.getpid(),'argv':[sys.executable,'-B','-u',str(R/'run-browser-r1.py')]}
path.write_text(json.dumps(record,indent=2),encoding='utf-8')
with (R/'browser-controller-r1.stdout.txt').open('wb') as out,(R/'browser-controller-r1.stderr.txt').open('wb') as err:
 child=subprocess.Popen(record['argv'],cwd=R,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
 record['wrapperPid']=child.pid;path.write_text(json.dumps(record,indent=2),encoding='utf-8')
 record['wrapperExit']=child.wait(timeout=240)
record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
path.write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record));sys.exit(record['wrapperExit'])
