const fs = require('node:fs/promises');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const {createHash} = require('node:crypto');
const {pathToFileURL} = require('node:url');
const {chromium} = require('playwright');
const root='/home/jacob/RecallWeave-receiving-4775-490fcd7c4056';
const out='/dev/shm/rw490f-legacy';
const hash=b=>createHash('sha256').update(b).digest('hex');
const report={status:'running',base:'4775af91ba6a5d4df787669f39b44364dd1e37ba',checks:[],downloads:[],pageErrors:[],externalRequests:[]};
(async()=>{
  const manifest=JSON.parse(await fs.readFile('/dev/shm/rw490f-current/source-manifest.json','utf8'));
  const verify=async()=>{for(const f of manifest.files)assert.equal(hash(await fs.readFile(path.join(root,f.path))),f.sha256,f.path);};
  await verify();
  report.manifestSha256=hash(await fs.readFile('/dev/shm/rw490f-current/source-manifest.json'));
  const legacy=await fs.readFile(path.join(out,'old-main-demo.html'));
  report.legacyDemo={bytes:legacy.length,sha256:hash(legacy),blob:createHash('sha1').update(Buffer.concat([Buffer.from('blob '+legacy.length+'\0'),legacy])).digest('hex')};
  assert.equal(report.legacyDemo.blob,'04ec6a5a58613880f7fd97c0eacd682bbc921a62');
  const deck=JSON.parse(await fs.readFile(path.join(root,'data/deck.json'),'utf8'));
  const server=http.createServer(async(req,res)=>{
    try{
      const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
      const file=path.resolve(root,'.'+(pathname==='/'?'/index.html':pathname));
      if(!file.startsWith(root+'/')){res.writeHead(403).end();return;}
      const b=await fs.readFile(file);
      const mime={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.json':'application/json'}[path.extname(file)]||'application/octet-stream';
      res.writeHead(200,{'Content-Type':mime+';charset=utf-8'}).end(b);
    }catch{res.writeHead(404).end();}
  });
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  const base='http://127.0.0.1:'+server.address().port;
  let browser;
  const pass=name=>{report.checks.push(name);console.log('PASS '+name);};
  const activate=async(page,selector)=>{await page.locator(selector).focus();await page.keyboard.press('Enter');};
  const openArchive=async page=>{if(!await page.locator('#trace-archive-panel').evaluate(e=>e.open))await page.locator('#trace-archive-panel > summary').click();};
  const save=async(page,selector,name)=>{
    const pending=page.waitForEvent('download');await activate(page,selector);const d=await pending;
    await d.saveAs(path.join(out,name));assert.equal(await d.failure(),null);
    const bytes=await fs.readFile(path.join(out,name));report.downloads.push({file:name,bytes:bytes.length,sha256:hash(bytes),suggestedFilename:d.suggestedFilename()});return bytes;
  };
  try{
    browser=await chromium.launch({executablePath:process.env.BROWSER_BIN,headless:true,args:['--no-sandbox','--disable-background-networking','--disable-dev-shm-usage']});
    report.browser=await browser.version();
    const context=await browser.newContext({viewport:{width:1280,height:1000},acceptDownloads:true});
    context.on('page',p=>p.on('pageerror',e=>report.pageErrors.push(e.message)));
    await context.route('**/*',route=>{
      const url=route.request().url();
      if(!url.startsWith(base)&&!url.startsWith('file:')&&!url.startsWith('blob:')&&!url.startsWith('data:')){report.externalRequests.push(url);return route.abort();}
      return route.continue();
    });
    const old=await context.newPage();await old.goto(pathToFileURL(path.join(out,'old-main-demo.html')).href);
    await activate(old,'#start-button');
    for(let i=0;i<deck.items.length;i++){
      const prompt=await old.locator('.question-card h2').textContent();
      const item=deck.items.find(x=>x.prompt===prompt);assert.ok(item);
      const choice=i%2===0?item.answer:(item.answer+1)%item.options.length;
      await activate(old,'[data-choice="'+choice+'"]');await activate(old,'#next-button');
    }
    await old.locator('.result-card').waitFor();
    await activate(old,'#practice-button');
    const practicePrompt=await old.locator('.practice-card h2').textContent();
    const retry=deck.items.find(x=>x.prompt===practicePrompt);assert.ok(retry);
    await activate(old,'[data-practice-choice="'+retry.answer+'"]');await activate(old,'#back-to-review');
    assert.match(await old.locator('#practice-status').textContent(),/Practice paused: 1 of 3/);
    await openArchive(old);
    const archived=JSON.parse(await save(old,'#save-trace-button','old-main-paused-trace.json'));
    assert.deepEqual(archived.deck,deck);assert.equal(Object.hasOwn(archived.deck,'format'),false);
    assert.equal(archived.practice.answers.length,1);
    assert.equal(archived.firstAnswers.length,6);
    pass('actual exact-main standalone download records raw bundled identity and paused practice');
    await old.close();
    for(const [name,url,width] of [['modular',base,1280],['standalone',pathToFileURL(path.join(root,'demo.html')).href,390]]){
      const page=await context.newPage();await page.setViewportSize({width,height:844});await page.goto(url);
      await openArchive(page);
      await page.locator('#trace-file').setInputFiles(path.join(out,'old-main-paused-trace.json'));
      await page.locator('#trace-preview').waitFor({state:'visible'});
      assert.match(await page.locator('#trace-preview-summary').textContent(),/Practice: 1 of 3 answers recorded/);
      await activate(page,'#restore-trace-confirm');
      assert.match(await page.locator('#trace-restore-status').textContent(),/Trace restored/);
      assert.match(await page.locator('#practice-status').textContent(),/Practice paused: 1 of 3/);
      const resaved=JSON.parse(await save(page,'#save-trace-button',name+'-legacy-restored.json'));
      for(const f of ['deck','model','firstAnswers','mastery','practice'])assert.deepEqual(resaved[f],archived[f],name+' '+f);
      const notes=(await save(page,'#save-notes-button',name+'-legacy-notes.txt')).toString('utf8');
      assert.ok(notes.includes(deck.title));
      for(const answer of archived.firstAnswers){const q=deck.items.find(x=>x.id===answer.item);assert.ok(notes.includes(q.options[answer.choice]));}
      await page.locator('#trace-archive-panel').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,name+'-legacy-restored.png')});
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
      pass(name+' restores the actual old-main file, resaves identical canonical state and downloads matching notes');
      await page.close();
    }
    assert.deepEqual(report.pageErrors,[]);assert.deepEqual(report.externalRequests,[]);
    await verify();report.sourceUnchanged=true;report.status='passed';
  }catch(error){report.status='failed';report.error=error.stack;process.exitCode=1;console.error(error.stack);}
  finally{
    await browser?.close();await new Promise(r=>server.close(r));
    report.node=process.version;await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(report,null,2)+'\n');
    console.log(JSON.stringify({status:report.status,checks:report.checks.length,downloads:report.downloads.length,sourceUnchanged:report.sourceUnchanged}));
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
