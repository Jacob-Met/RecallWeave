// Independent course oracle: complete path enumeration, no product imports.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const specification = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));

function pathReference(fixture) {
  const { jobs, durations, edges } = fixture;
  const n = jobs.length;
  const index = new Map(jobs.map((job, i) => [job, i]));
  const links = edges.map(([a, b]) => [index.get(a), index.get(b)]);
  const successors = jobs.map((_, i) => links.filter(([a]) => a === i).map(([, b]) => b).sort((a, b) => a - b));
  const incoming = jobs.map((_, i) => links.filter(([, b]) => b === i).length);
  const reachable = jobs.map(() => jobs.map(() => false));
  for (const [a, b] of links) reachable[a][b] = true;
  for (let via = 0; via < n; via++) {
    for (let a = 0; a < n; a++) {
      for (let b = 0; b < n; b++) reachable[a][b] ||= reachable[a][via] && reachable[via][b];
    }
  }
  const members = jobs.map((_, i) => i).filter(i => reachable[i][i]);
  if (members.length) {
    const seen = new Set();
    const components = [];
    for (const i of members) {
      if (seen.has(i)) continue;
      const component = members.filter(j => reachable[i][j] && reachable[j][i]);
      component.forEach(j => seen.add(j));
      components.push(component.map(j => jobs[j]));
    }
    return {
      timing: null,
      cycleComponents: components,
      cycleMembers: members.map(i => jobs[i]),
      blockedByCycle: jobs.filter((_, i) => !members.includes(i) && members.some(j => reachable[j][i])),
      ready: jobs.filter((_, i) => incoming[i] === 0),
    };
  }
  const paths = [];
  function walk(i, prefix) {
    const path = [...prefix, i];
    if (!successors[i].length) paths.push(path);
    else for (const next of successors[i]) walk(next, path);
  }
  jobs.forEach((_, i) => { if (incoming[i] === 0) walk(i, []); });
  const weights = paths.map(path => path.reduce((sum, i) => sum + durations[i], 0));
  const finish = Math.max(...weights);
  const earliest = jobs.map(() => 0);
  const suffix = jobs.map(() => 0);
  for (let p = 0; p < paths.length; p++) {
    let prefix = 0;
    for (const i of paths[p]) {
      earliest[i] = Math.max(earliest[i], prefix);
      suffix[i] = Math.max(suffix[i], weights[p] - prefix);
      prefix += durations[i];
    }
  }
  const criticalPaths = paths.filter((_, i) => weights[i] === finish);
  const criticalNodeSet = new Set(criticalPaths.flat());
  const edgeKeys = new Set();
  for (const path of criticalPaths) {
    for (let i = 1; i < path.length; i++) edgeKeys.add(path[i - 1] + ':' + path[i]);
  }
  return {
    duration: finish,
    rows: jobs.map((_, i) => [earliest[i], earliest[i] + durations[i], finish - suffix[i], finish - suffix[i] + durations[i], finish - suffix[i] - earliest[i]]),
    criticalJobs: jobs.filter((_, i) => criticalNodeSet.has(i)),
    criticalEdges: links.filter(([a, b]) => edgeKeys.has(a + ':' + b)).sort((a, b) => a[0] - b[0] || a[1] - b[1]).map(([a, b]) => [jobs[a], jobs[b]]),
    paths: paths.map((path, i) => ({ jobs: path.map(j => jobs[j]), duration: weights[i] })),
  };
}
function containsExpected(actual, expected) {
  for (const [key, value] of Object.entries(expected)) assert.deepEqual(actual[key], value, key);
}
const results = specification.fixtures.map(fixture => {
  const actual = pathReference(fixture);
  containsExpected(actual, fixture.expected);
  return { id: fixture.id, actual };
});
const wrongFinish = structuredClone(specification.fixtures.find(x => x.id === 'A-unequal').expected);
wrongFinish.duration = 6;
assert.throws(() => containsExpected(results.find(x => x.id === 'A-unequal').actual, wrongFinish), assert.AssertionError);
const wrongEdge = structuredClone(specification.fixtures.find(x => x.id === 'C-milestone-shortcut').expected);
wrongEdge.criticalEdges.push(['Start', 'Done']);
assert.throws(() => containsExpected(results.find(x => x.id === 'C-milestone-shortcut').actual, wrongEdge), assert.AssertionError);
function waitTimeline(beforeFirst, afterFirst) {
  const first = [beforeFirst, beforeFirst + 1];
  const second = [first[1] + afterFirst, first[1] + afterFirst + 1];
  const joinStart = Math.max(5, second[1]);
  return { first, second, long: [0, 5], join: [joinStart, joinStart + 1], finish: joinStart + 1 };
}
const waitCases = [
  { actual: waitTimeline(3, 0), expected: specification.explicitWaitTransfer.firstWaitOnly },
  { actual: waitTimeline(3, 3), expected: specification.explicitWaitTransfer.separateAdditionalWait },
];
for (const item of waitCases) {
  for (const key of ['first', 'second', 'long', 'join', 'finish']) assert.deepEqual(item.actual[key], item.expected[key], key);
}
process.stdout.write(JSON.stringify({
  schema: 'independent-critical-path-course-oracle-calibration/1',
  candidateCourseRead: false, productModulesImported: false,
  fixturesPassed: results.length, changedMathExpectationsRejected: 2, explicitWaitCasesPassed: 2,
  scope: 'Independent mathematical calibration only; not course answer-key or native product execution.',
  results, waitTimelines: waitCases.map(x => x.actual),
}, null, 2) + '\n');
