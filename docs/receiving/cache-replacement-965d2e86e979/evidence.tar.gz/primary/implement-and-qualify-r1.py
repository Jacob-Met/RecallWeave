import hashlib,json,os,pathlib,shutil,subprocess,time
root=pathlib.Path('/Users/me/hamon-recall-cache-965d2e86e979')
src=root/'source'
ev=root/'evidence'
raw=(ev/'implementation-input.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='0971bd47ddd4ea72b636973f797f4f1c754a3015f6010168e9a4a34b321b1a40'
data=json.loads(raw)
git=lambda *args:subprocess.check_output(['git','-C',str(src),*args],text=True).strip()
assert git('rev-parse','HEAD')==data['expectedHead']
assert not git('status','--porcelain')
assert shutil.disk_usage(root).free>20*1024*1024
paths=git('ls-files').splitlines()
before={p:hashlib.sha256((src/p).read_bytes()).hexdigest() for p in paths}
assert len(paths)==37
assert (src/'README.md').read_text()==data['readmeBefore']
for p in data['files']:
 assert p.startswith(('courses/cache-replacement','tools/build-cache-replacement','tests/cache-replacement'))
 assert not (src/p).exists(),p
changes=dict(data['files'])
changes['README.md']=data['readmeBefore']+data['readmeAddition']
for p,content in changes.items():
 target=src/p
 target.parent.mkdir(parents=True,exist_ok=True)
 temporary=target.with_name(target.name+'.production-write')
 temporary.write_text(content,encoding='utf-8')
 os.replace(temporary,target)
assert all(hashlib.sha256((src/p).read_bytes()).hexdigest()==sha for p,sha in before.items() if p!='README.md')
commands=[['/opt/homebrew/bin/node','tools/build-cache-replacement.mjs'],['/opt/homebrew/bin/node','--test','tests/cache-replacement.test.mjs'],['/opt/homebrew/bin/node','tools/build-cache-replacement.mjs','--check']]
results=[]
for index,command in enumerate(commands):
 started=time.time()
 run=subprocess.run(command,cwd=src,capture_output=True)
 out=ev/('candidate-r1-command-%d.stdout.log'%index);err=ev/('candidate-r1-command-%d.stderr.log'%index)
 out.write_bytes(run.stdout);err.write_bytes(run.stderr)
 result={'command':command,'exitCode':run.returncode,'seconds':round(time.time()-started,3),'stdout':out.name,'stdoutSha256':hashlib.sha256(run.stdout).hexdigest(),'stderr':err.name,'stderrSha256':hashlib.sha256(run.stderr).hexdigest(),'stderrBytes':len(run.stderr)}
 results.append(result)
 if run.returncode:break
receipt={'inputSha256':hashlib.sha256(raw).hexdigest(),'base':data['expectedHead'],'canonicalBase':data['canonicalBase'],'canonicalTree':data['canonicalTree'],'existingInputs':before,'unownedInputsPreserved':all(hashlib.sha256((src/p).read_bytes()).hexdigest()==sha for p,sha in before.items() if p!='README.md'),'commands':results,'changedFiles':{p:hashlib.sha256((src/p).read_bytes()).hexdigest() for p in changes},'generatedSha256':hashlib.sha256((src/'courses/cache-replacement.html').read_bytes()).hexdigest() if (src/'courses/cache-replacement.html').exists() else None}
(ev/'candidate-r1-native.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'commands':results,'preserved36':receipt['unownedInputsPreserved'],'free':shutil.disk_usage(root).free}))
