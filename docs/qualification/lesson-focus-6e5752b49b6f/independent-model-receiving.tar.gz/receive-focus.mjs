import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { closureOracle, makeFixtures, nonemptySelections } from './oracle-fixtures.mjs';

const root = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
const corePath = resolve(root, 'src/course-focus.mjs');
const deckPath = resolve(root, 'src/deck.mjs');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const before = await Promise.all([corePath, deckPath].map(path => readFile(path)));
const { planCourseFocus, createFocusedLesson } = await import(pathToFileURL(corePath));
const { validateDeck, parseDeck, MAX_DECK_BYTES } = await import(pathToFileURL(deckPath));
const report = {
  receiving: 'Independent source, closure and serialized-file qualification',
  source: { core: hash(before[0]), validator: hash(before[1]) },
  runtime: { node: process.version, platform: process.platform, arch: process.arch },
  cases: [], failures: []
};
let assertions = 0;
const same = (actual, expected, message) => { ++assertions; assert.deepEqual(actual, expected, message); };
const check = (condition, message) => { ++assertions; assert.ok(condition, message); };

async function group(name, fn) {
  const started = performance.now();
  try {
    const details = await fn();
    report.cases.push({ name, passed: true, elapsed_ms: performance.now() - started, ...details });
  } catch (error) {
    report.cases.push({ name, passed: false, elapsed_ms: performance.now() - started });
    report.failures.push({ group: name, name: error.name, message: error.message, stack: error.stack });
  }
}

function expectedInclusions(deck, oracle) {
  const retained = new Set(oracle.concepts);
  const requested = new Set(oracle.selected);
  return oracle.concepts.map(concept => ({
    concept,
    requested: requested.has(concept),
    questionCount: deck.items.filter(item => item.concept === concept).length,
    requiredBy: deck.concepts.filter(other => retained.has(other) &&
      deck.items.some(item => item.concept === other && item.prerequisites.includes(concept)))
  }));
}

function receiveResult(result, source, selected, title) {
  const expected = closureOracle(source, selected);
  same(result.requested, expected.selected, 'requested concepts must remain in source order');
  same(result.required, expected.required, 'required concepts must be the complete prerequisite closure');
  same(result.concepts, expected.concepts, 'concept order and membership must remain exact');
  same(result.items, expected.items, 'all retained questions and every approved field must remain exact');
  same(result.inclusions, expectedInclusions(source, expected), 'inclusion reasons/counts must match actual retained edges');
  if (title !== undefined) {
    same(result.deck, {
      format: 'recallweave-deck/1', title,
      attribution: source.attribution, license: source.license,
      concepts: expected.concepts, items: expected.items
    }, 'focused deck must preserve exact content/attribution with the requested title');
    same(parseDeck(result.json), result.deck, 'actual downloadable bytes must pass unchanged learner validator');
    same(result.bytes, Buffer.byteLength(result.json, 'utf8'), 'reported byte count must use UTF-8');
    check(result.bytes <= MAX_DECK_BYTES, 'output must fit actual file limit');
  }
}

await group('Hand-derived oracle controls', () => {
  const fixtures = makeFixtures();
  const diamond = fixtures.find(fixture => fixture.name === 'diamond').deck;
  same(new Set(closureOracle(diamond, ['Join']).concepts),
    new Set(['Start', 'Left, branch', 'Right → branch', 'Join']));
  same(closureOracle(diamond, ['__proto__']).concepts, ['__proto__']);
  const split = fixtures.find(fixture => fixture.name === 'split_questions').deck;
  same(new Set(closureOracle(split, ['Final']).concepts),
    new Set(['Start', 'Left, branch', 'Right → branch', 'Join', 'Middle', 'Final']));
  for (const { deck } of fixtures) validateDeck(deck);
  return { validated_fixture_decks: fixtures.length, hand_derived_controls: 3 };
});

await group('Every nonempty choice across varied prerequisite graphs', () => {
  let selections = 0;
  for (const fixture of makeFixtures()) {
    const source = fixture.deck;
    const original = JSON.stringify(source);
    for (const selected of nonemptySelections(source.concepts)) {
      const title = `Focused ${fixture.name} ${++selections}`;
      receiveResult(planCourseFocus(source, selected), source, selected);
      receiveResult(createFocusedLesson(source, selected, title), source, selected, title);
      same(JSON.stringify(source), original, 'planning and export must not mutate input');
    }
  }
  return { graph_fixtures: 7, distinct_selections: selections, questions_per_source: 16 };
});

await group('Malformed selection/title/source refusal and empty preview', () => {
  const source = makeFixtures()[3].deck;
  const empty = planCourseFocus(source, []);
  same(empty, { requested: [], required: [], concepts: [], items: [], inclusions: [] });
  const invalidChoices = [null, undefined, '', 'Start', {}, ['unknown'], ['Start', 'Start'], ['Start', null]];
  for (const selection of invalidChoices) {
    assert.throws(() => planCourseFocus(source, selection));
    assert.throws(() => createFocusedLesson(source, selection, 'A lesson'));
  }
  for (const title of [null, undefined, '', '   ', 12, 'x'.repeat(161)]) {
    assert.throws(() => createFocusedLesson(source, ['Start'], title));
  }
  assert.throws(() => createFocusedLesson(source, [], 'A lesson'));
  const cycle = structuredClone(source);
  cycle.items.find(item => item.concept === 'Start').prerequisites = ['Final'];
  assert.throws(() => createFocusedLesson(cycle, ['Start'], 'Cycle refused'));
  const uncovered = structuredClone(source);
  uncovered.items = uncovered.items.filter(item => item.concept !== 'Start');
  assert.throws(() => planCourseFocus(uncovered, ['Final']));
  return { malformed_selection_variants: invalidChoices.length, invalid_titles: 6,
    invalid_graphs: 2, explicit_empty_plan: true };
});

await group('Detached immutable outputs and literal metadata', () => {
  const source = makeFixtures()[3].deck;
  source.attribution = '  Exact <attribution> & "quotation"\n第二行🧭  ';
  source.license = '  Literal license\nNo added permissions.  ';
  source.items[0].id = '__proto__';
  source.items[1].id = 'constructor';
  const selected = ['Final', '<b>Literal optional concept</b>'];
  const title = '  Focused lesson — 漢字🧭  ';
  const result = createFocusedLesson(source, selected, title);
  receiveResult(result, source, selected, title);
  const frozenBytes = JSON.stringify(result);
  const walk = object => {
    if (!object || typeof object !== 'object') return;
    check(Object.isFrozen(object), 'every returned nested object/array must be frozen');
    Object.values(object).forEach(walk);
  };
  walk(result);
  source.attribution = 'Replaced source attribution';
  source.items.forEach(item => { item.options[0] = 'Changed source answer option'; });
  source.concepts.reverse(); selected.splice(0);
  same(JSON.stringify(result), frozenBytes, 'later source/input mutation must not alter preview or saved bytes');
  assert.throws(() => { result.deck.items[0].options[0] = 'Tampered result'; });
  return { nested_freezing: true, detached_source_and_selection: true, exact_literal_fields: true };
});

function limitDeck(unicode) {
  const source = {
    format: 'recallweave-deck/1', title: 'T', attribution: 'Fixture author', license: 'CC0-1.0',
    concepts: ['Only'],
    items: Array.from({ length: 100 }, (_, i) => ({
      id: `limit-${i}`, concept: 'Only', prerequisites: [],
      prompt: `Question ${i}${unicode ? ' 漢字🧭' : ''}`, options: ['Yes', 'No'], answer: i % 2,
      explanation: 'E', transfer: 'Transfer'
    }))
  };
  let remaining = MAX_DECK_BYTES - Buffer.byteLength(JSON.stringify(source), 'utf8');
  for (const item of source.items) {
    const count = Math.min(3999, remaining);
    item.explanation += 'x'.repeat(count); remaining -= count;
  }
  assert.equal(remaining, 0, 'fixture must have enough independently calculated text capacity');
  assert.equal(Buffer.byteLength(JSON.stringify(source), 'utf8'), MAX_DECK_BYTES);
  return source;
}

await group('Exact ASCII and multibyte file boundaries', () => {
  const boundaries = [];
  for (const unicode of [false, true]) {
    const source = limitDeck(unicode);
    const compact = JSON.stringify(source);
    same(parseDeck(compact), source, 'exact-limit source must be independently admitted');
    const result = createFocusedLesson(source, ['Only'], 'T');
    receiveResult(result, source, ['Only'], 'T');
    same(result.bytes, MAX_DECK_BYTES, 'equal-size output must not be rejected by pretty-print expansion');
    same(result.json, compact, 'compact fallback must preserve every exact content byte');
    assert.throws(() => createFocusedLesson(source, ['Only'], 'TT'));
    boundaries.push({ unicode, source_bytes: Buffer.byteLength(compact),
      output_bytes: result.bytes, source_sha256: hash(compact), output_sha256: hash(result.json),
      one_byte_larger_title_refused: true });
  }
  return { boundaries };
});

await group('Receiving oracle rejects consequential corrupted outputs', () => {
  const source = makeFixtures()[3].deck;
  const selected = ['Final'];
  const original = createFocusedLesson(source, selected, 'Receiver negative control');
  const corruptions = [
    value => { value.items.pop(); },
    value => { value.concepts.reverse(); },
    value => { value.items.reverse(); },
    value => { value.items[0].answer = (value.items[0].answer + 1) % 3; },
    value => { value.items[0].options.reverse(); },
    value => { value.deck.license = 'Changed permission'; },
    value => { value.required = []; },
    value => { value.inclusions[0].questionCount += 1; }
  ];
  for (const corrupt of corruptions) {
    const changed = structuredClone(original); corrupt(changed);
    assert.throws(() => receiveResult(changed, source, selected, 'Receiver negative control'));
  }
  return { deliberately_corrupted_controls_rejected: corruptions.length };
});

const after = await Promise.all([corePath, deckPath].map(path => readFile(path)));
report.inputs_unchanged = before.every((bytes, i) => bytes.equals(after[i]));
report.assertions = assertions;
report.passed = report.failures.length === 0 && report.inputs_unchanged;
await writeFile(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
process.exitCode = report.passed ? 0 : 1;
