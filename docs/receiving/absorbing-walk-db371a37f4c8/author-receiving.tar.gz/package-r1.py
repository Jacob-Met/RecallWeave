import pathlib,json,hashlib,zipfile,datetime,shutil
root=pathlib.Path('/run/user/1000/snap.chromium/hamon-absorbing-walk-author-db371a37f4c8')
assert shutil.disk_usage(root).free>=268435456
dest=root/'portable-r1';dest.mkdir(exist_ok=False)
files={}
for name in ['demo.html','courses/absorbing-walk-lab.html','courses/absorbing-walk.json','courses/absorbing-walk.md']:
 files[name]=(root/'source'/name).read_bytes()
files['PLAY.md']=(root/'PLAY-package.md').read_bytes()
manifest={'format':'recallweave-absorbing-walk-package/1','originalCommit':'698902f9c9c1d5c5023092b85b3632a7cb7a01ed','issue':206,'files':[{'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in sorted(files.items())]}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=dest/'absorbing-walk-portable.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  i=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,data)
with zipfile.ZipFile(archive) as z:
 assert sorted(z.namelist())==sorted(files)
 for name,data in files.items():assert z.read(name)==data
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'payloadBytes':sum(map(len,files.values())),'manifest':manifest,'verified':True}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
