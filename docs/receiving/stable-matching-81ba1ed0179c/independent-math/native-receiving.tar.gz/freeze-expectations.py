"""Independent mathematical oracle, frozen before candidate source access.
Enumerates complete permutations and checks the strict blocking-pair definition.
It does not implement or call deferred acceptance. Small proposal traces are
hand-authored separately and checked against state consistency only.
"""
from itertools import permutations
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib
root=Path(__file__).resolve().parent
def inspect(left,right,matching):
    n=len(left); inverse=[matching.index(j) for j in range(n)]
    lr=[left[i].index(matching[i])+1 for i in range(n)]
    rr=[right[j].index(inverse[j])+1 for j in range(n)]
    blocks=[]
    for i in range(n):
        for j in range(n):
            if matching[i]!=j and left[i].index(j)<left[i].index(matching[i]) and right[j].index(i)<right[j].index(inverse[j]):
                blocks.append({"left":i,"right":j,"leftCurrent":matching[i],"rightCurrent":inverse[j],
                  "leftCandidateRank":left[i].index(j)+1,"leftCurrentRank":lr[i],
                  "rightCandidateRank":right[j].index(i)+1,"rightCurrentRank":rr[j]})
    return {"leftMatching":list(matching),"rightMatching":inverse,"leftRanks":lr,"rightRanks":rr,"blockingPairs":blocks,"stable":not blocks}
profiles=[
 {"id":"one","leftPreferences":[[0]],"rightPreferences":[[0]]},
 {"id":"two-stable-role-reversal","leftPreferences":[[0,1],[1,0]],"rightPreferences":[[1,0],[0,1]]},
 {"id":"replacement-and-rejection","leftPreferences":[[0,1,2],[0,1,2],[1,0,2]],"rightPreferences":[[1,0,2],[0,2,1],[0,1,2]]},
 {"id":"common-strict-order","leftPreferences":[[0,1,2]]*3,"rightPreferences":[[0,1,2]]*3},
 {"id":"four-asymmetric","leftPreferences":[[0,2,1,3],[1,0,3,2],[2,3,0,1],[0,1,2,3]],"rightPreferences":[[2,1,0,3],[3,0,2,1],[0,2,1,3],[1,3,2,0]]},
]
for p in profiles:
    left,right=p["leftPreferences"],p["rightPreferences"];n=len(left)
    all_rows=[inspect(left,right,m) for m in permutations(range(n))]
    stable=[x for x in all_rows if x["stable"]]
    best_left=[min(x["leftRanks"][i] for x in stable) for i in range(n)]
    best_right=[min(x["rightRanks"][j] for x in stable) for j in range(n)]
    left_opt=[x for x in stable if x["leftRanks"]==best_left]
    right_opt=[x for x in stable if x["rightRanks"]==best_right]
    assert len(left_opt)==len(right_opt)==1
    p["completeMatchings"]=all_rows;p["stableLeftMatchings"]=[x["leftMatching"] for x in stable]
    p["leftProposingFinal"]=left_opt[0]["leftMatching"];p["rightProposingFinal"]=right_opt[0]["leftMatching"]
    p["bestLeftRanks"]=best_left;p["bestRightRanks"]=best_right
# Each row: proposer index, receiver index, decision, displaced proposer or None,
# then the complete left->right partial matching AFTER that one decision.
hand=[
 {"profile":"one","side":"left","steps":[[0,0,"hold",None,[0]]]},
 {"profile":"one","side":"right","steps":[[0,0,"hold",None,[0]]]},
 {"profile":"two-stable-role-reversal","side":"left","steps":[[0,0,"hold",None,[0,None]],[1,1,"hold",None,[0,1]]]},
 {"profile":"two-stable-role-reversal","side":"right","steps":[[0,1,"hold",None,[None,0]],[1,0,"hold",None,[1,0]]]},
 {"profile":"replacement-and-rejection","side":"left","steps":[[0,0,"hold",None,[0,None,None]],[1,0,"replace",0,[None,0,None]],[0,1,"hold",None,[1,0,None]],[2,1,"reject",None,[1,0,None]],[2,0,"reject",None,[1,0,None]],[2,2,"hold",None,[1,0,2]]]},
 {"profile":"replacement-and-rejection","side":"right","steps":[[0,1,"hold",None,[None,0,None]],[1,0,"hold",None,[1,0,None]],[2,0,"reject",None,[1,0,None]],[2,1,"reject",None,[1,0,None]],[2,2,"hold",None,[1,0,2]]]},
 {"profile":"common-strict-order","side":"left","steps":[[0,0,"hold",None,[0,None,None]],[1,0,"reject",None,[0,None,None]],[1,1,"hold",None,[0,1,None]],[2,0,"reject",None,[0,1,None]],[2,1,"reject",None,[0,1,None]],[2,2,"hold",None,[0,1,2]]]},
]
# Validate only mathematical consistency of the manually chosen trace states.
for h in hand:
    p=next(p for p in profiles if p["id"]==h["profile"]);n=len(p["leftPreferences"])
    assert h["steps"][-1][4]==p[h["side"]+"ProposingFinal"]
    seen=set();cursors=[0]*n;previous=[None]*n
    for proposer,receiver,action,displaced,matching in h["steps"]:
        assert (proposer,receiver) not in seen;seen.add((proposer,receiver));cursors[proposer]+=1
        assert len([x for x in matching if x is not None])==len(set(x for x in matching if x is not None))
        inverse=[matching.index(j) if j in matching else None for j in range(n)]
        # Attach canonical partial state and consumed-choice cursors without
        # deriving the proposal, decision or tie policy from a second algorithm.
        if h["side"]=="left":free=[i for i,x in enumerate(matching) if x is None]
        else:free=[j for j,x in enumerate(inverse) if x is None]
        previous=matching
    h["proposalCount"]=len(h["steps"])
invalid=[
 "null profile","array instead of profile","missing leftPreferences","missing rightPreferences",
 "zero participants","five participants","unequal side lengths","missing row","sparse row",
 "duplicate receiver in a row","missing receiver in a row","extra receiver in a row",
 "negative index","out-of-range index","fractional index","string index","boolean index",
 "NaN index","Infinity index","missing proposingSide","proposingSide='LEFT'","proposingSide='other'",
 "complete matching null","complete matching duplicate","complete matching wrong length",
 "complete matching sparse","complete matching negative","complete matching out of range","complete matching string index"
]
contract=(root/"contract.json").read_bytes()
out={"schema":"hamon.independent_stable_matching_expectations.v1","frozen_at":datetime.now(timezone.utc).isoformat(),
 "candidate_access_before_freeze":False,"contract_sha256":hashlib.sha256(contract).hexdigest(),
 "method":"Exact exhaustive complete permutations and strict two-sided blocking-pair definition, plus explicitly hand-authored small proposal sequences. No candidate code or candidate oracle accessed.",
 "sources":["https://www.rand.org/content/dam/rand/pubs/papers/2012/P2240.pdf"],
 "profiles":profiles,"handTraces":hand,"invalidAdmissionControls":invalid,
 "later_adapter_contract":"Bind these frozen mathematical expectations to the producer's public field names; retain frozen originals. Separately check detached/frozen arrays and proposal uniqueness, receiver-best-so-far and bound n^2 without modifying expected outcomes."}
target=root/"expectations-frozen.json";target.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"sha256":hashlib.sha256(target.read_bytes()).hexdigest(),"bytes":target.stat().st_size,"profiles":len(profiles),"complete_matchings":sum(len(p["completeMatchings"]) for p in profiles),"hand_traces":len(hand),"invalid_controls":len(invalid),"outcomes":[{"id":p["id"],"stable":p["stableLeftMatchings"],"left":p["leftProposingFinal"],"right":p["rightProposingFinal"]} for p in profiles]}))
