import pathlib,json,hashlib,zipfile,shutil,os,subprocess,stat,datetime
R=pathlib.Path('/run/user/1000/snap.chromium/hamon-recall-absorbing-receiving-db371a37f4c8');A=pathlib.Path('/run/user/1000/snap.chromium/hamon-absorbing-walk-author-db371a37f4c8')
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((R/'candidate-runtime-manifest-r1.json').read_text())['files']
receipt={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'platformAmendment':'Root-approved separate existing same-uid /run tmpfs placement, Chromium153 consumer; retain MSI C: guard refusal, no floor reduction or system changes.','files':[]}
assert shutil.disk_usage(R).free>=268435456
assert int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>=2147483648
for e in m:
 p=A/'source'/e['path'];b=p.read_bytes();assert p.is_file() and not p.is_symlink() and len(b)==e['bytes'] and sha(b)==e['sha256']
 t=R/'source'/e['path'];t.parent.mkdir(parents=True,exist_ok=True);assert not t.exists();t.write_bytes(b);assert sha(t.read_bytes())==e['sha256'] and sha(p.read_bytes())==e['sha256'];receipt['files'].append(e)
z=A/'portable-r1/absorbing-walk-portable.zip';b=z.read_bytes();assert len(b)==49847 and sha(b)=='a928a859470c668f8e313d839f11d0f31e781aaa4367a03441d6bcb70eb70426'
(R/'absorbing-walk-portable.zip').write_bytes(b);P=R/'portable';P.mkdir()
allowed={'demo.html','courses/absorbing-walk-lab.html','courses/absorbing-walk.json','courses/absorbing-walk.md','PLAY.md','MANIFEST.json'};receipt['package']={'bytes':len(b),'sha256':sha(b),'members':[]}
with zipfile.ZipFile(R/'absorbing-walk-portable.zip') as f:
 assert len(f.infolist())==6 and set(f.namelist())==allowed
 for i in f.infolist():
  assert not i.is_dir() and not pathlib.PurePosixPath(i.filename).is_absolute() and '..' not in pathlib.PurePosixPath(i.filename).parts
  mode=i.external_attr>>16;assert not stat.S_ISLNK(mode);assert i.file_size<200000
  v=f.read(i);t=P/i.filename;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(v);receipt['package']['members'].append({'path':i.filename,'bytes':len(v),'sha256':sha(v)})
for e in m:
 t=P/e['path']
 if t.exists(): assert sha(t.read_bytes())==e['sha256']
alone=R/'copied-alone';alone.mkdir();shutil.copyfile(P/'courses/absorbing-walk-lab.html',alone/'walk.html')
receipt['node']=subprocess.check_output(['/usr/bin/node','--version'],text=True).strip()
receipt['chromium']=subprocess.check_output(['/snap/bin/chromium','--version'],text=True).strip()
play=pathlib.Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8/source/node_modules/playwright/index.mjs')
receipt['playwrightEntry']={'path':str(play),'sha256':sha(play.read_bytes())}
receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['pass']=True
(R/'package-admission-r1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'pass':True,'runtimeFiles':len(m),'package':receipt['package'],'node':receipt['node'],'chromium':receipt['chromium']}))
