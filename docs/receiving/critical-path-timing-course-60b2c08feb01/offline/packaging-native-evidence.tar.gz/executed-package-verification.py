from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import posixpath, stat
class DeliveryLinks(HTMLParser):
    def __init__(self): super().__init__(); self.links=[]; self.ids=set()
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if a.get('id'): self.ids.add(a['id'])
        for key in ('href','src'):
            if key in a: self.links.append((tag,key,a[key]))
    handle_startendtag=handle_starttag
extracted=recall_pack_root/'extracted native package'
extracted.mkdir()
with zipfile.ZipFile(recall_zip) as archive:
    infos=archive.infolist()
    assert len(infos)==11 and len({i.filename for i in infos})==11
    assert archive.testzip() is None
    for info in infos:
        assert info.filename.startswith('RecallWeave/') and '..' not in Path(info.filename).parts
        assert stat.S_ISREG(info.external_attr>>16)
        assert stat.S_IMODE(info.external_attr>>16)==0o644
    archive.extractall(extracted)
delivery=extracted/'RecallWeave'
actual_files=sorted(p.relative_to(delivery).as_posix() for p in delivery.rglob('*') if p.is_file())
assert actual_files==sorted(m['path'] for m in recall_build_result['members'])
for member in recall_build_result['members']:
    raw=(delivery/member['path']).read_bytes()
    assert len(raw)==member['bytes'] and hashlib.sha256(raw).hexdigest()==member['sha256']
    assert hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()==member['git']
manifest=json.loads((delivery/'SHA256SUMS.json').read_text())
assert {x['path'] for x in manifest['files']}==set(actual_files)-{'SHA256SUMS.json'}
for entry in manifest['files']:
    raw=(delivery/entry['path']).read_bytes()
    assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
parsers={}
for relative in actual_files:
    if relative.endswith('.html'):
        parser=DeliveryLinks(); parser.feed((delivery/relative).read_text()); parser.close(); parsers[relative]=parser
local_links=[]; external_links=[]; ignored_data=[]
for relative in actual_files:
    raw=(delivery/relative).read_text(encoding='utf-8')
    if relative.endswith('.html'): links=[url for _,_,url in parsers[relative].links]
    elif relative.endswith('.md'): links=__import__('re').findall(r'\[[^\]]*\]\(([^)]+)\)',raw)
    else: continue
    for url in links:
        parsed=urlsplit(url)
        if parsed.scheme=='data': ignored_data.append({'from':relative,'url':url}); continue
        if parsed.scheme or parsed.netloc: external_links.append({'from':relative,'url':url}); continue
        target=posixpath.normpath(posixpath.join(posixpath.dirname(relative),unquote(parsed.path))) if parsed.path else relative
        assert not target.startswith('../') and target in actual_files,(relative,url,target)
        if parsed.fragment and target in parsers: assert unquote(parsed.fragment) in parsers[target].ids,(relative,url)
        local_links.append({'from':relative,'url':url,'target':target})
for relative,pin in recall_expected_pins.items():
    raw=(recall_source/relative).read_bytes()
    assert (delivery/relative).read_bytes()==raw
    assert hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()==pin['git']
deck=json.loads((delivery/'courses/critical-path-timing.json').read_text())
assert len(deck['items'])==16 and len(deck['concepts'])==4
recall_verification={
 'schema':'recallweave-critical-path-timing-offline-receiving/1',
 'source_commit':'be8e9fd6a279a72fc3843da44c52ac109dcd8cd2',
 'source_tree':'1328c908fbefd52b62ea05ae3c1bcb7e80e9c7b2',
 'package':recall_build_result,
 'build':{'command':recall_build_run['command'],'exit_code':recall_build_run['exit_code'],'python':recall_build_run['python']},
 'checks':{'zip_crc':True,'unique_safe_regular_members':11,'all_file_modes':'0644','extracted_member_hashes_equal':11,'manifest_covers_every_other_member':10,'exact_unchanged_product_assets':7,'all_local_links_resolve':True,'html_fragment_targets_resolve':True},
 'opening':{'entry':'RecallWeave/START-HERE.html','learner':'RecallWeave/demo.html','course':'RecallWeave/courses/critical-path-timing.json','preview_title':deck['title'],'questions':len(deck['items']),'concepts':len(deck['concepts']),'explicit_action':'Start this deck','companion':'RecallWeave/courses/dependency-timing.html','guide':'RecallWeave/courses/critical-path-timing.md'},
 'local_links':local_links,'optional_external_links':external_links,'data_links':ignored_data,
 'general_pack_negative':{'git':general_receipt['zip_git'],'bytes':general_receipt['zip_bytes'],'sha256':general_receipt['zip_sha256'],'member_count':len(general_members),'timing_course_present':False,'timing_companion_present':False,'receipt':'existing-general-pack-receipt.json'},
 'independent_source_review':{'reviewer':'estate-60b2c08feb01/estate_records','scope':'Direct canonical guide/companion/graph-link read and proposed opening instructions only. Final ZIP/START-HERE physical bytes not inspected by this reviewer.','outcome':'PASS stated instructions and seven-file local closure','execution':False},
 'limits':['Packaging and static-link/hash receiving only; no course, model or browser qualification replay.','No Windows learner execution or installed adoption.','Optional external references are not packaged.','No catalog, registry, native builder or accepted product source modification.','No GitHub write or Actions invocation during construction.'],
 'orchestration_negatives':[{'boundary':'Private controller preparation','observed':'NameError: Path is not defined before reading ZIP bytes','correction':'Explicit pathlib.Path import; no product call or native learner run occurred.'},{'boundary':'Connector retrieval','observed':'One companion file read returned RemoteProtocolError; one generic binary blob read did not provide UTF-8 content.','correction':'Exact companion fetch_blob and documented fetch_file encoding=base64 succeeded. Returned bytes verified by Git identity.'}]
}
(recall_pack_root/'packaging-receiving.json').write_text(json.dumps(recall_verification,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'verification':index_identity((recall_pack_root/'packaging-receiving.json').read_text()),'checks':recall_verification['checks'],'local_link_count':len(local_links),'external_link_count':len(external_links),'opening':recall_verification['opening'],'extracted':str(delivery)}))