from pathlib import Path
import datetime, hashlib, json, os, subprocess, time
root = Path(__file__).resolve().parent
def h(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}
freeze = {"frozen_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_manifest": h(root/"source-manifest.json"),
    "control": h(root/"receive_probability_current.mjs"), "contract": h(root/"control-contract.md"),
    "prior_trace": h(root/"inputs/probability-prior-paused-trace.json")}
with (root/"control-freeze.json").open("x") as file: json.dump(freeze,file,indent=2); file.write("\n")
command = ["/usr/bin/node", str(root/"receive_probability_current.mjs"), str(root)]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.perf_counter()
try:
    result = subprocess.run(command, cwd=root, capture_output=True, timeout=20)
    stdout,stderr,code = result.stdout,result.stderr,result.returncode
    timeout = False
except subprocess.TimeoutExpired as error:
    stdout,stderr,code = error.stdout or b"", error.stderr or b"",None
    timeout = True
elapsed = time.perf_counter() - clock
(root/"control.stdout").write_bytes(stdout)
(root/"control.stderr").write_bytes(stderr)
receipt = {"command": command,"cwd":str(root),"started_at_utc":started,
    "finished_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsed_seconds":elapsed,
    "exit_code":code,"timeout":timeout,"timeout_seconds":20,"source_freeze":h(root/"control-freeze.json"),
    "stdout":h(root/"control.stdout"),"stderr":h(root/"control.stderr"),"producer_freeze":freeze}
with (root/"control-execution.json").open("x") as file: json.dump(receipt,file,indent=2); file.write("\n")
print(json.dumps(receipt,indent=2))
if stdout: print(stdout.decode("utf-8","replace"),end="")
if stderr: print(stderr.decode("utf-8","replace"),end="")
raise SystemExit(0 if code==0 and not timeout else 1)
