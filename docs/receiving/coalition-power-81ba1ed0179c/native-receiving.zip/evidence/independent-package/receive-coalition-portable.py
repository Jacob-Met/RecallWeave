import pathlib,zipfile,hashlib,json,re,posixpath,subprocess,datetime,os
from html.parser import HTMLParser
root=pathlib.Path('/tmp/recall-coalition-power-81ba1ed0179c')
delivery=root/'delivery';arc=delivery/'coalition-power-offline.zip';raw=arc.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(raw)==49655 and sha(raw)=='44b5d5afd013bc6cbdf5fd13e7fec46fcf9ef122a6cce028b1302ab59a0f2c39'
mb=(delivery/'portable-manifest.json').read_bytes();manifest=json.loads(mb)
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.resources=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if t=='a' and 'href'in d:self.links.append(d['href'])
  if t in ['script','link','img','iframe','source'] and ('src'in d or 'href'in d):self.resources.append({'tag':t,**d})
members=[];routes=[];embedded=[];source=[]
with zipfile.ZipFile(arc) as z:
 assert len(z.namelist())==6
 for item in manifest['entries']:
  rel=item['path'];b=z.read('coalition-power-offline/'+rel)
  assert sha(b)==item['sha256'] and len(b)==item['bytes']
  assert b==(delivery/'fresh-extraction/coalition-power-offline'/rel).read_bytes()
  members.append({'path':rel,'bytes':len(b),'sha256':sha(b),'manifest_and_fresh_extraction_exact':True})
  if rel.endswith('.html'):
   p=Links();p.feed(b.decode())
   relative=[x for x in p.links if not re.match(r'^(?:[a-z]+:|#)',x)]
   for x in relative:assert 'coalition-power-offline/'+posixpath.normpath(posixpath.join(posixpath.dirname(rel),x.split('#')[0])) in z.namelist()
   assert not p.resources
   routes.append({'from':rel,'relative_links':relative,'all_relative_targets_present':True,'external_resource_elements':p.resources,'external_reference_links':[x for x in p.links if re.match(r'^https?://',x)]})
  if rel in ['courses/coalition-power-explorer.html','courses/coalition-power.json','courses/coalition-power.md','demo.html']:
   c=subprocess.run(['git','-C',str(root/'source'),'show',manifest['source']+':'+rel],capture_output=True,check=True)
   assert c.stdout==b==(root/'source'/rel).read_bytes()
   source.append({'path':rel,'manifest_commit':manifest['source'],'commit_object_and_worktree_exact':True})
 explorer=z.read('coalition-power-offline/courses/coalition-power-explorer.html').decode()
 for key,rel in [('COURSE_TEXT','courses/coalition-power.json'),('GUIDE_TEXT','courses/coalition-power.md')]:
  m=re.search(r'^const '+key+r' = (.*);$',explorer,re.M);assert m
  b=json.loads(m.group(1)).encode();assert b==z.read('coalition-power-offline/'+rel)
  embedded.append({'constant':key,'path':rel,'bytes':len(b),'sha256':sha(b),'embedded_literal_bytes_exact':True})
 demo=z.read('coalition-power-offline/demo.html')
 blob=hashlib.sha1(b'blob '+str(len(demo)).encode()+b'\0'+demo).hexdigest()
 assert blob=='ef7bc3e27e7f161d917ced6a457fad8822802f3f'
report={'schema':'recall-coalition-power.independent-portable-route-review/1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'estate-81ba1ed0179c/integration','status':'pass','scope':'Bounded package wording, static relative paths, exact archive/extraction/source identity. No browser, mathematical oracle, author tests or learner-suite execution; no product edits.','archive':{'path':str(arc),'bytes':len(raw),'sha256':sha(raw)},'manifest_sha256':sha(mb),'members':members,'routes':routes,'embedded':embedded,'source_identity':source,'canonical_learner':{'commit':'698902f9c9c1d5c5023092b85b3632a7cb7a01ed','path':'demo.html','git_blob_sha1':blob,'primary_fetch_file_metadata_sha_equal':True,'boundary':'Fresh GitHub fetch_file returned UTF-8 body and this object SHA. The byte-level native comparison is to the manifest source object and ZIP; no separately transferred canonical HTTP-body byte comparison is claimed.'},'wording_review':{'quickstart':'README and START-HERE both explain extract/open, explorer course download or included exact course, learner initially showing its bundled lesson, local chooser, Preview then explicit Start this deck.','formats':'Course JSON and Save observation are explicitly distinct; observation is applied game/current view and is not a learner course or answer archive.','persistence':'README, START-HERE and explorer explicitly say no automatic saving and require keeping explicit downloads. This is a wording/static source review, not a runtime storage observation.','routes':'All relative anchors resolve within the six-file extracted folder; explorer ../demo.html is correct. No external script/style/image resource elements. Explicit scholarly reference anchors are labeled as leaving the offline page.','provenance':'Original wording/example attribution and AI assistance/license are visible. Native partial-history source and canonical unchanged learner are distinguished; no hosted or main-integration claim.'},'requested_changes':[],'preserved_negative_boundary':'An initial broad read output was truncated; acceptance uses subsequent bounded identity/link/embedded-literal reads, not an assertion that truncated output was fully reviewed.'}
out=pathlib.Path('/run/user/1000/scpf81/coalition-portable-review.json')
b=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode()
with out.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
assert out.read_bytes()==b
print(json.dumps({'path':str(out),'bytes':len(b),'sha256':sha(b),'status':'pass','members':len(members),'requested_changes':[]}))
