#!/usr/bin/env node
/** Build the dependency-free, directly opened edit-distance explorer. */
import {readFile, writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {parseDeck, serializeDeck} from '../src/deck.mjs';

const args = process.argv.slice(2);
if (args.some(arg => arg !== '--check') || args.length > 1) {
  throw new Error('Usage: node tools/build_edit_distance_explorer.mjs [--check]');
}
const root = new URL('../', import.meta.url);
const paths = ['courses/edit-distance-explorer.template.html', 'courses/edit-distance-core.mjs', 'courses/edit-distance-ui.mjs', 'courses/edit-distance.json'];
const [template, core, ui, course] = await Promise.all(paths.map(path => readFile(new URL(path, root), 'utf8')));
const canonical = serializeDeck(parseDeck(course));
if (canonical !== course) throw new Error('The original course must use canonical deck serialization.');
const line = "import {POLICY, EXAMPLES, analyzeEditDistance} from './edit-distance-core.mjs';\n";
if (!ui.startsWith(line) || ui.split(line).length !== 2) throw new Error('The explorer import contract changed; review the standalone composition.');
const script = core + '\n' + ui.slice(line.length);
if (/<\/script/i.test(script)) throw new Error('Executable source contains a closing script token.');
const replacements = [
  ['<!-- EDIT_DISTANCE_DECK -->', '<script id="course-data" type="application/json">' + canonical.replaceAll('<', '\\u003c') + '</script>'],
  ['<!-- EDIT_DISTANCE_SCRIPT -->', '<script type="module">\n' + script + '</script>']
];
let html = template;
for (const [marker, value] of replacements) {
  if (html.split(marker).length !== 2) throw new Error('Expected one template marker: ' + marker);
  html = html.replace(marker, value);
}
const output = new URL('courses/edit-distance-explorer.html', root);
if (args.includes('--check')) {
  if (await readFile(output, 'utf8') !== html) throw new Error('Generated explorer differs. Run the builder and review the change.');
  console.log('PASS: explorer matches its exact template, model, UI and canonical course.');
} else {
  await writeFile(output, html);
  console.log('Built ' + fileURLToPath(output) + ' (' + Buffer.byteLength(html, 'utf8') + ' bytes)');
}
