import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const modelPath=process.argv[2]||path.join(root,'candidate-core/src/stoichiometry.mjs');
const model=await import(pathToFileURL(modelPath));
const oracle=JSON.parse(readFileSync(path.join(root,'oracle_cases.json'),'utf8'));
const contract=JSON.parse(readFileSync(path.join(root,'receiver_contract.json'),'utf8'));
const independent=JSON.parse(readFileSync(path.join(root,'independent-course-answers.json'),'utf8'));
const course=JSON.parse(readFileSync(path.join(root,'candidate-core/courses/stoichiometry-foundations.json'),'utf8'));
const checks=[];
function check(name,fn){
  try{fn();checks.push({name,passed:true});}
  catch(error){checks.push({name,passed:false,error:String(error),stack:error.stack});}
}
const value=f=>Number(f.numerator)/Number(f.denominator);
const tolerance=n=>16*Number.EPSILON*Math.max(1,Math.abs(n));
function near(actual,expected,label){
  assert.equal(typeof actual,'number',label+' must be a number');
  assert.ok(Number.isFinite(actual),label+' must be finite');
  assert.ok(Math.abs(actual-expected)<=tolerance(expected),
    label+': actual '+actual+', exact expectation '+expected);
}
function amount(actual,fraction,label){
  const n=value(fraction);
  near(actual,n,label);
  assert.ok(actual>=0,label+' must be nonnegative');
  const shown=model.formatMoles(actual);
  assert.equal(typeof shown,'string');
  assert.ok(shown.length>0&&Number.isFinite(Number(shown)),label+' has invalid displayed amount');
  const step=n===0?0:10**(Math.floor(Math.log10(Math.abs(n)))-7);
  assert.ok(Math.abs(Number(shown)-n)<=0.5000001*step+tolerance(n),
    label+' exceeds eight-significant-digit rounding: '+shown+' vs '+n);
  if(n===0)assert.equal(shown,'0',label+' should display zero');
}
const ascii=formula=>formula.replace(/[₀-₉]/g,c=>String(c.charCodeAt(0)-0x2080));
check('fixed reaction catalogue',()=>{
  assert.deepEqual(model.REACTIONS.map(r=>r.id),['water','ammonia','magnesium']);
});
for(const reaction of model.REACTIONS){
  check('chemical metadata and balance/'+reaction.id,()=>{
    const expected=contract.reaction_specs[reaction.id];
    for(const side of ['reactants','products']){
      assert.deepEqual(reaction[side].map(s=>({
        formula:ascii(s.formula),coefficient:s.coefficient,atoms:s.atoms
      })),expected[side]);
    }
    const atoms=new Set(reaction.reactants.concat(reaction.products).flatMap(s=>Object.keys(s.atoms)));
    for(const element of atoms){
      const reactantAtoms=reaction.reactants.reduce((n,s)=>n+s.coefficient*(s.atoms[element]||0),0);
      const productAtoms=reaction.products.reduce((n,s)=>n+s.coefficient*(s.atoms[element]||0),0);
      assert.equal(reactantAtoms,productAtoms,reaction.id+' must conserve '+element);
    }
  });
}
for(const c of oracle.cases){
  check('exact reaction/'+c.id,()=>{
    const actual=model.solveReaction(c.reaction,c.inputs);
    assert.equal(actual.reaction.id,c.reaction);
    assert.equal(actual.classification,c.classification,c.id+' limiting/matched/zero outcome');
    assert.equal(actual.reactants.length,2);
    assert.equal(actual.products.length,c.formed.length);
    amount(actual.extent,c.extent,c.id+'/extent');
    for(let i=0;i<2;i++){
      for(const [field,expectedField] of [['initial','initial'],['capacity','capacity'],['consumed','consumed'],['remaining','remaining']]){
        amount(actual.reactants[i][field],c[expectedField][i],c.id+'/'+i+'/'+field);
      }
      assert.ok(actual.reactants[i].consumed<=actual.reactants[i].initial+tolerance(actual.reactants[i].initial),c.id+' overconsumption');
      near(actual.reactants[i].consumed/actual.reactants[i].coefficient,value(c.extent),c.id+' coefficient ratio');
    }
    actual.products.forEach((p,i)=>amount(p.formed,c.formed[i],c.id+'/product/'+i));
    for(const element of Object.keys(c.atom_amounts_before)){
      const before=actual.reactants.reduce((n,s)=>n+s.initial*(s.atoms[element]||0),0);
      const after=actual.reactants.reduce((n,s)=>n+s.remaining*(s.atoms[element]||0),0)
        +actual.products.reduce((n,s)=>n+s.formed*(s.atoms[element]||0),0);
      near(before,value(c.atom_amounts_before[element]),c.id+' initial '+element+' inventory');
      near(after,value(c.atom_amounts_after[element]),c.id+' final '+element+' inventory');
      near(after,before,c.id+' conservation of '+element);
    }
    if(c.classification==='no-product'){
      assert.equal(actual.extent,0);
      assert.ok(actual.reactants.every(r=>r.consumed===0));
      assert.ok(actual.products.every(p=>p.formed===0));
    }else if(c.classification==='matched'){
      assert.ok(actual.reactants.every(r=>r.remaining===0));
    }else{
      const exhausted=c.classification==='first'?0:1;
      assert.equal(actual.reactants[exhausted].remaining,0);
      assert.ok(actual.reactants[1-exhausted].remaining>0);
    }
  });
}
for(const c of oracle.valid_parse_cases)check('admitted decimal/'+JSON.stringify(c.text),()=>assert.equal(model.parseMoles(c.text),c.expected_millimoles));
for(const text of oracle.invalid_parse_cases)check('refused decimal/'+JSON.stringify(text),()=>assert.throws(()=>model.parseMoles(text)));
for(const input of oracle.nontext_rejections)check('refused nontext/'+JSON.stringify(input),()=>assert.throws(()=>model.parseMoles(input)));
check('fixed reaction and two-amount input boundary',()=>{
  assert.throws(()=>model.solveReaction('unlisted',['1','1']));
  for(const input of [null,[],['1'],['1','1','1']])assert.throws(()=>model.solveReaction('water',input));
});
check('clear theoretical model scope',()=>{
  assert.match(model.MODEL_NOTE,/ideal/i);
  assert.match(model.MODEL_NOTE,/no side reactions/i);
  assert.match(model.MODEL_NOTE,/theoretical/i);
  for(const word of ['yield','rate','equilibrium'])assert.ok(model.MODEL_NOTE.includes(word));
});
check('human-readable worked record retains scope',()=>{
  const record=model.workedRecord(model.solveReaction('ammonia',['1','1']),'second');
  assert.ok(record.split('\n').length>=12);
  assert.ok(!record.includes('\\n'),'record contains escaped line breaks instead of lines');
  assert.ok(record.includes(model.MODEL_NOTE));
  assert.ok(record.includes('NH₃'));
  assert.throws(()=>model.workedRecord(model.solveReaction('water',['2','1']),'unlisted-prediction'));
});
check('course structure and prerequisite concepts',()=>{
  assert.equal(course.format,'recallweave-deck/1');
  assert.equal(course.items.length,12);
  assert.equal(new Set(course.items.map(q=>q.id)).size,12);
  assert.equal(course.concepts.length,4);
  assert.equal(new Set(course.concepts).size,4);
  for(const q of course.items){
    assert.ok(course.concepts.includes(q.concept));
    assert.ok(q.prerequisites.every(p=>course.concepts.includes(p)&&p!==q.concept));
    assert.equal(q.options.length,4);
    assert.ok(Number.isInteger(q.answer)&&q.answer>=0&&q.answer<q.options.length);
  }
});
for(const expected of independent.answers){
  check('independently derived course answer/'+expected.id,()=>{
    const actual=course.items.find(q=>q.id===expected.id);
    assert.ok(actual);
    assert.equal(actual.answer,expected.answer_index_zero_based,expected.rationale);
  });
}
const hash=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
const report={
  schema:'independent-stoichiometry-receiving/v1',
  timestamp_utc:new Date().toISOString(),
  node:process.version,
  producer_core_commit:contract.producer_core_commit,
  model_path:modelPath,
  model_sha256:hash(modelPath),
  course_sha256:hash(path.join(root,'candidate-core/courses/stoichiometry-foundations.json')),
  control_commit:'e78bdde722b905e36076fb189e4593f197c3229e',
  independent_answer_commit:'674729bb4b77713686948ab539f3be6a7508abd9',
  oracle_sha256:hash(path.join(root,'oracle_cases.json')),
  exact_numerical_cases:oracle.cases.length,
  independent_lesson_answers:independent.answers.length,
  producer_tests_read:false,
  passed:checks.filter(c=>c.passed).length,
  failed:checks.filter(c=>!c.passed).length,
  checks
};
writeFileSync(path.join(root,'numerical-content-receiving.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({report:path.join(root,'numerical-content-receiving.json'),...Object.fromEntries(Object.entries(report).filter(([key])=>key!=='checks')),failures:checks.filter(c=>!c.passed)}));
if(report.failed)process.exitCode=1;
