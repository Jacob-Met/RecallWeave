import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';

export const ASSUMPTIONS = [
  "Hypothetical diploid plants; two autosomal loci A/a and B/b.",
  "One double-heterozygous AaBb parent is crossed with an aabb tester that contributes ab.",
  "Alleles segregate equally; the two parental gamete classes share probability equally, as do the two recombinant classes.",
  "The entered recombination percentage is a stipulated recombinant-gamete fraction, not a count of crossover events.",
  "No mutation, segregation distortion, differential gamete or offspring survival, or nonrandom fertilization is modeled.",
  "Probabilities describe possible offspring; they are not quotas for a finite sample and do not locate genes on a physical chromosome map."
];
export const GAMETES = ['AB','Ab','aB','ab'];
export const FIXED_TIME = '2026-10-09T02:00:00.000Z';
export function sha256(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
export function gitBlob(bytes) { return createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex'); }
export function pinFile(path) { const b=readFileSync(path); return {path,bytes:b.length,git:gitBlob(b),sha256:sha256(b)}; }
export function fraction(n,d) { let a=n,b=d; while(b) [a,b]=[b,a%b]; return {numerator:n/a,denominator:d/a}; }
export const fracText = f => f.numerator+'/'+f.denominator;
export function expectedAnalysis(phase,r) {
  assert(['coupling','repulsion'].includes(phase)); assert(Number.isInteger(r)&&r>=0&&r<=50);
  const homologs=phase==='coupling'?['AB','ab']:['Ab','aB'];
  const offspring=['AaBb','Aabb','aaBb','aabb'];
  const rows=GAMETES.map((gamete,i)=>({gamete,kind:homologs.includes(gamete)?'parental':'recombinant',probability:fraction(homologs.includes(gamete)?100-r:r,200),offspringGenotype:offspring[i]}));
  return {format:'recallweave-genetic-linkage/1',input:{phase,recombinationPercent:r},assumptions:[...ASSUMPTIONS],parent:{genotype:'AaBb',homologs},tester:{genotype:'aabb',gamete:'ab'},rows,totals:{parental:fraction(100-r,100),recombinant:fraction(r,100),all:{numerator:1,denominator:1}},marginals:{A:{numerator:1,denominator:2},a:{numerator:1,denominator:2},B:{numerator:1,denominator:2},b:{numerator:1,denominator:2}},independentComparison:{probability:{numerator:1,denominator:4},matches:r===50}};
}
export function expectedObservation(phase,raw) {
 return JSON.stringify({format:'recallweave-genetic-linkage-observation/1',entered:{phase,recombinationPercent:raw},analysis:expectedAnalysis(phase,Number(raw.trim()))},null,2)+'\n';
}
export async function assertCross(page,phase,r) {
 const expected=expectedAnalysis(phase,r);
 assert.equal(await page.locator('#linkage-result').isVisible(),true);
 assert.deepEqual((await page.locator('#linkage-homologs [data-homolog]').allTextContents()).map(x=>x.trim()),expected.parent.homologs);
 const seen=await page.locator('#linkage-rows tr[data-gamete]').evaluateAll(rows=>rows.map(row=>({gamete:row.dataset.gamete,fields:Object.fromEntries(['kind','probability','offspring','independent'].map(key=>[key,row.querySelector('td[data-field="'+key+'"]')?.textContent.trim()]))})));
 assert.deepEqual(seen,expected.rows.map(row=>({gamete:row.gamete,fields:{kind:row.kind==='parental'?'Parental':'Recombinant',probability:row.probability.numerator+'/'+row.probability.denominator,offspring:row.offspringGenotype,independent:'1/4'}})));
 for(const [name,key] of [['parental','parental'],['recombinant','recombinant'],['all','all']]) assert.equal((await page.locator('#linkage-'+name+'-total').textContent()).trim(),fracText(expected.totals[key]));
 for(const allele of ['A','a','B','b']) assert.equal((await page.locator('#linkage-marginals [data-allele="'+allele+'"]').textContent()).trim(),'1/2');
 assert.equal((await page.locator('#linkage-independent-match').textContent()).trim(),r===50?'Matches independent assortment':'Differs from independent assortment');
 return expected;
}
export async function storageSnapshot(page,label) {
 return page.evaluate(async label=>{
  const take=name=>{try{const s=window[name];return Object.fromEntries(Array.from({length:s.length},(_,i)=>s.key(i)).map(k=>[k,s.getItem(k)]));}catch(e){return {unavailable:e.name};}};
  const result={label,url:location.href,events:[...window.__linkageAudit.storage],local:take('localStorage'),session:take('sessionStorage'),cookie:document.cookie};
  try{result.databases=await indexedDB.databases();}catch(e){result.databasesUnavailable=e.name;}
  try{result.caches=await caches.keys();}catch(e){result.cachesUnavailable=e.name;}
  result.urls=window.__linkageAudit.urls;return result;
 },label);
}
export function assertNoStorage(snapshot) {
 assert.deepEqual(snapshot.events,[]);
 for(const key of ['local','session']) if(!snapshot[key]?.unavailable) assert.deepEqual(snapshot[key],{});
 assert.equal(snapshot.cookie,'');if(snapshot.databases)assert.deepEqual(snapshot.databases,[]);if(snapshot.caches)assert.deepEqual(snapshot.caches,[]);
}
