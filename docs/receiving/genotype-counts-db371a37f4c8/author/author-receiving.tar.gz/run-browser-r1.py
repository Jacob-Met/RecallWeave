import ctypes,datetime,hashlib,json,os,pathlib,platform,re,shutil,subprocess,sys,time,traceback
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8');E=R/'browser-r1';E.mkdir(exist_ok=False)
DONOR=pathlib.Path(r'D:/Hamon/receiving/pneumatic-goals-root-db371a37f4c8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(): (E/'receipt.json').write_bytes((json.dumps(rec,indent=2)+'\n').encode('utf-8'))
def ps(command):
 p=subprocess.run(['powershell','-NoProfile','-Command',command],stdin=subprocess.DEVNULL,capture_output=True,timeout=20)
 assert p.returncode==0,p.stderr.decode('utf-8','replace')
 text=p.stdout.decode('utf-8-sig').strip();return json.loads(text) if text else []
class MEM(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['totalPhys','availPhys','totalPage','availPage','totalVirtual','availVirtual','availExtended']]
rec={'started':now(),'wrapperPid':os.getpid(),'parentPid':os.getppid(),'status':'started','children':[]};save()
try:
 m=MEM();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
 u=ctypes.create_unicode_buffer(256);n=ctypes.c_ulong(256);assert ctypes.windll.advapi32.GetUserNameW(u,ctypes.byref(n))
 rec['identity']={'machine':platform.node(),'user':u.value};assert platform.node().upper()=='MSI' and u.value=='Veria'
 rec['capacity']={'CFree':shutil.disk_usage('C:/').free,'DFree':shutil.disk_usage('D:/').free,'memoryAvailable':m.availPhys};rec['guard']={'C':1073741824,'D':1073741824,'memory':2147483648}
 assert rec['capacity']['CFree']>=1073741824 and rec['capacity']['DFree']>=1073741824 and m.availPhys>=2147483648
 manifest=json.loads((R/'CANDIDATE-MANIFEST-r2.json').read_text(encoding='utf-8'));rec['sourceBefore']=[]
 for entry in manifest:
  p=pin(R/'candidate-r2'/entry['path']);assert p=={k:entry[k] for k in ['bytes','sha256','git']};rec['sourceBefore'].append({'path':entry['path'],**p})
 package=json.loads((R/'portable-r1/receipt.json').read_text(encoding='utf-8'));rec['portableBefore']=package['members']
 for rel,expected in package['members'].items():assert pin(R/'portable-r1/unpacked'/rel)==expected
 rec['package']=pin(R/'portable-r1/genotype-counts-portable.zip');assert rec['package']['sha256']=='7ac3e0ca10978b67eb8f9570eb7e84abda0217b609aaa2a12e373f5ab70446e7'
 dm=json.loads((DONOR/'LINUX-DONOR-MANIFEST.json').read_text(encoding='utf-8'));assert len(dm)==173
 rec['donorManifest']={'path':str(DONOR/'LINUX-DONOR-MANIFEST.json'),**pin(DONOR/'LINUX-DONOR-MANIFEST.json')};rec['donorBefore']=[]
 for rel,expected in dm.items():
  p=pin(DONOR/'dependencies/node_modules'/rel);assert p['bytes']==expected['bytes'] and p['sha256']==expected['sha256'];rec['donorBefore'].append({'path':rel,**p})
 node=pathlib.Path(r'C:/Program Files/nodejs/node.exe');edge=pathlib.Path(r'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe')
 rec['node']={'path':str(node),**pin(node)};rec['edge']={'path':str(edge),**pin(edge)}
 assert rec['node']['sha256']=='3602f2bb1a10f2cbab4c36886218a33c1ab3db87290e73b033c46c77147d0237'
 rec['edgeVersion']=ps("(Get-Item 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe').VersionInfo.ProductVersion | ConvertTo-Json");assert rec['edgeVersion']=='154.0.4258.53'
 rec['driver']=pin(R/'receive-browser-r1.mjs')
 tmp=E/'tmp';tmp.mkdir();env=os.environ.copy();env.update({'TEMP':str(tmp),'TMP':str(tmp),'DEBUG':'pw:browser','PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD':'1','PYTHONDONTWRITEBYTECODE':'1'});env.pop('PLAYWRIGHT_LEGACY_SCREENSHOT',None)
 argv=[str(node),str(R/'receive-browser-r1.mjs'),str(R),str(E)]
 with (E/'stdout.txt').open('wb') as out,(E/'stderr.txt').open('wb') as err:
  child=subprocess.Popen(argv,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
  rec['children'].append({'pid':child.pid,'argv':argv,'cwd':str(R),'envDelta':{'TEMP':str(tmp),'TMP':str(tmp),'DEBUG':'pw:browser','PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD':'1','PLAYWRIGHT_LEGACY_SCREENSHOT':'absent'}});save()
  try:code=child.wait(timeout=180)
  except subprocess.TimeoutExpired:
   rec['timeout']=True
   kill=subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True);rec['ownedTimeoutCleanup']={'exitCode':kill.returncode,'stdout':kill.stdout.decode('utf-8','replace'),'stderr':kill.stderr.decode('utf-8','replace')};code=child.wait(timeout=15)
 rec['children'][-1]['exitCode']=code;rec['stdout']=pin(E/'stdout.txt');rec['stderr']=pin(E/'stderr.txt')
 log=(E/'stderr.txt').read_text(encoding='utf-8',errors='replace');rec['browserLogPids']=sorted(set(map(int,re.findall(r'pid=(\d+)',log))));rec['browserExitLines']=[l for l in log.splitlines() if 'process did exit' in l]
 if (E/'driver-receipt.json').exists():rec['driverReceipt']=pin(E/'driver-receipt.json')
 time.sleep(2)
 command="$exclude=@("+str(os.getpid())+","+str(os.getppid())+"); @(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*recall-genotype-counts-db371a37f4c8*' -and $_.ProcessId -notin $exclude -and $_.Name -ne 'powershell.exe' } | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine) | ConvertTo-Json -Depth 4 -Compress"
 rec['namespaceAfter']=ps(command);assert not rec['namespaceAfter'],'Owned namespace remains live'
 shutil.rmtree(tmp);rec['profileTempRemoved']=not tmp.exists()
 rec['sourceAfter']=[{'path':e['path'],**pin(R/'candidate-r2'/e['path'])} for e in manifest];assert rec['sourceBefore']==rec['sourceAfter']
 rec['portableAfter']={rel:pin(R/'portable-r1/unpacked'/rel) for rel in package['members']};assert rec['portableBefore']==rec['portableAfter']
 rec['donorAfter']=[{'path':rel,**pin(DONOR/'dependencies/node_modules'/rel)} for rel in dm];assert rec['donorBefore']==rec['donorAfter']
 rec['status']='passed' if code==0 else 'failed';rec['finished']=now();save()
 print(json.dumps({'status':rec['status'],'wrapperPid':os.getpid(),'nodePid':child.pid,'nodeExit':code,'browserPids':rec['browserLogPids'],'browserExitLines':rec['browserExitLines'],'profileTempRemoved':rec['profileTempRemoved'],'receipt':pin(E/'receipt.json')}));sys.exit(code)
except BaseException as e:
 if not isinstance(e,SystemExit):rec.update({'status':'failed','finished':now(),'error':str(e),'traceback':traceback.format_exc()});save()
 raise
