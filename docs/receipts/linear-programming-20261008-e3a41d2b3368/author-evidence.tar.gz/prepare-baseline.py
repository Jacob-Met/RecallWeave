import pathlib,json,hashlib,subprocess,shutil,time
r=pathlib.Path('/home/jacob/hamon-universal-e3a41d2b3368-recall-linear-programming')
p=json.loads((r/'BASELINE-INPUT.json').read_text())
assert shutil.disk_usage(r).free>64*1024*1024
source=r/'baseline'; source.mkdir()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
pins=[]
for x in p['files']:
 b=x['content'].encode(); assert blob(b)==x['gitBlob'],x['path']
 dest=source/x['path']; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b)
 pins.append({'path':x['path'],'git_blob':x['gitBlob'],'sha256':hashlib.sha256(b).hexdigest()})
for x in p['coordination']['sourceAbsence']: assert x['absent']
driver=r/'baseline-native.mjs'
driver.write_text('''import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { parseDeck } from './baseline/src/deck.mjs';
const raw = await readFile(new URL('./baseline/courses/network-flow.json', import.meta.url), 'utf8');
const deck = parseDeck(raw);
assert.equal(deck.format, 'recallweave-deck/1');
assert.equal(deck.items.length, 14);
assert.ok(Object.isFrozen(deck));
assert.ok(Object.isFrozen(deck.items));
console.log(JSON.stringify({status: 'passed', items: deck.items.length, concepts: deck.concepts.length, originalDeckAdmitted: true, runtime: process.version}));
''')
v=subprocess.run(['/usr/bin/node','--version'],capture_output=True,text=True); assert v.returncode==0
out=subprocess.run(['/usr/bin/node',str(driver)],cwd=r,capture_output=True)
(r/'baseline-native.stdout').write_bytes(out.stdout); (r/'baseline-native.stderr').write_bytes(out.stderr)
for x in pins: assert hashlib.sha256((source/x['path']).read_bytes()).hexdigest()==x['sha256']
receipt={'schema':'recallweave.linear-programming.before/1','time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'baseline_commit':p['commit'],'baseline_tree':p['tree'],'partial_compiler_closure':True,'source_files':pins,'upstream_leaf_count':p['upstreamBlobLeaves'],'exact_absence':p['coordination']['sourceAbsence'],'command':['/usr/bin/node',str(driver)],'cwd':str(r),'exit':out.returncode,'node_version':v.stdout.strip(),'stdout_sha256':hashlib.sha256(out.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(out.stderr).hexdigest(),'source_unchanged':True,'interpretation':'Native original-deck admission control plus complete canonical path absence. New course/lab capability; no regression failure or existing solver defect alleged.'}
(r/'BEFORE-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2)); print(out.stdout.decode()); print(out.stderr.decode())
assert out.returncode==0
