import pathlib,json,hashlib,shutil,subprocess,datetime,os
R=pathlib.Path(__file__).resolve().parent
P=json.loads((R/'browser-driver-successor-r2.json').read_text(encoding='utf-8'))
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
original=(R/'candidate-r1/tools/check_sorting_networks_browser.mjs').read_bytes()
assert original==P['old'].encode('utf-8')
assert P['fixed']==P['old'].replace('await learner.locator("#start-deck").click();await learner.locator("#start-button").click();','await learner.locator("#start-deck").click();')
S=R/'candidate-r2';shutil.copytree(R/'candidate-r1',S)
(S/'tools/check_sorting_networks_browser.mjs').write_bytes(P['fixed'].encode())
(R/'check-learner-remaining-r2.mjs').write_bytes(P['continuation'].encode())
node='C:/Program Files/nodejs/node.exe'
cp=subprocess.run([node,'--check',str(R/'check-learner-remaining-r2.mjs')],capture_output=True,timeout=20)
(R/'r2-syntax.stdout').write_bytes(cp.stdout);(R/'r2-syntax.stderr').write_bytes(cp.stderr)
manifest=[dict(path=p.relative_to(S).as_posix(),**pin(p.read_bytes())) for p in sorted(S.rglob('*')) if p.is_file()]
for path in ('candidate-manifest-r2.json','runtime-manifest-r2.json'):
 rows=manifest if path.startswith('candidate') else [q for q in manifest if not q['path'].startswith(('tests/','tools/check_'))]
 (R/path).write_bytes((json.dumps(rows,indent=2)+'\n').encode())
receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),syntax_exit=cp.returncode,old=pin(original),fixed=pin(P['fixed'].encode()),focused=pin(P['continuation'].encode()),changed=['tools/check_sorting_networks_browser.mjs'],runtime_change=False,reason=P['reason'])
(R/'R2-OBSERVER-CORRECTION.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
raise SystemExit(cp.returncode)
