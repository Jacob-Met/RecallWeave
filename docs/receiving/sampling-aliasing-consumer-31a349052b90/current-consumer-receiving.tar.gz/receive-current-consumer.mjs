#!/usr/bin/env node
// Current reflection-composition receiving. Transport and shared assertions derive
// from frozen receive-sampling-v3.mjs; this runs only two changed-source surfaces.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, mkdtemp, rm, copyFile, stat } from 'node:fs/promises';
import { extname, join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const option = (name, fallback) => {
  const i = process.argv.indexOf(name);
  return i < 0 ? fallback : process.argv[i + 1];
};
const project = resolve(option('--root', './source'));
const output = resolve(option('--output', './run-v1'));
const executable = option('--browser', 'chromium');
const manifestPath = resolve(option('--manifest', './source-manifest.json'));
const suppliedCourse = resolve(option('--course-input', './inputs/sampling-aliasing.json'));
const pausedTracePath = resolve(option('--paused-trace', './inputs/modular-paused-trace.json'));
await mkdir(output, {recursive:true});
const downloadPath = join(output, 'downloads');
await mkdir(downloadPath, {recursive:true});
const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const pin = bytes => ({
  bytes:bytes.length, sha256:hash(bytes),
  git_blob:createHash('sha1').update(Buffer.concat([Buffer.from('blob ' + bytes.length + '\0'),bytes])).digest('hex')
});
const report = {
  status:'running', source:{repo:manifest.repo,commit:manifest.commit,tree:manifest.tree},
  runtime:{node:process.version,platform:process.platform,arch:process.arch,executable},
  sourceFiles:manifest.source_files, checks:[], downloads:[], screenshots:[], sessions:[],
  requests:[], served:[], blockedRequests:[], pageErrors:[], transport:[], stages:[], startedAt:new Date().toISOString()
};
const verifySource = async () => {
  for (const expected of manifest.source_files) {
    assert.deepEqual(pin(await readFile(join(project,expected.path))),
      {bytes:expected.bytes,sha256:expected.sha256,git_blob:expected.git_blob},expected.path);
  }
};
await verifySource();
const rawCourse = await readFile(join(project,'courses/sampling-aliasing.json'));
const {parseDeck} = await import(pathToFileURL(join(project,'src/deck.mjs')));
const course = parseDeck(rawCourse.toString('utf8'));
const allowedFiles = new Map(manifest.source_files.map(x=>[x.path,x]));
const server = createServer(async (request,response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url,'http://localhost').pathname);
    const relative = pathname === '/' ? 'index.html' : pathname.slice(1);
    if (!allowedFiles.has(relative) || request.method !== 'GET') { response.writeHead(404).end(); return; }
    const bytes = await readFile(join(project,relative));
    const expected = allowedFiles.get(relative);
    assert.equal(hash(bytes),expected.sha256);
    report.served.push({path:relative,...pin(bytes)});
    const mime={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.json':'application/json'}[extname(relative)];
    response.writeHead(200,{'Content-Type':(mime || 'application/octet-stream')+'; charset=utf-8','Cache-Control':'no-store'});
    response.end(bytes);
  } catch(error) { report.pageErrors.push('owned server: '+error.message); response.writeHead(500).end(); }
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base='http://127.0.0.1:'+server.address().port;
const profile=await mkdtemp(join(output,'profile-'));
let browser,socket,sessionId,targetId,sequence=0,browserLog='';
const pending=new Map(),downloads=new Map();
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function waitFor(check,label) {
  let last;
  const deadline=Date.now()+20000;
  while(Date.now()<deadline) {
    try { if(await check()) return; } catch(e) { last=e; }
    if(browser?.exitCode!==null && browser?.exitCode!==undefined) throw Error('Browser exited '+browser.exitCode+': '+browserLog);
    await sleep(100);
  }
  throw Error('Timed out: '+label+(last?' ('+last.message+')':''));
}
function command(method,params={},scoped=true) {
  const id=++sequence;
  if (/Input\.|Page.navigate|DOM.setFile/.test(method)) report.transport.push({id,method,params,at:new Date().toISOString()});
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method));},12000);
    pending.set(id,{resolve,reject,timer});
    socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));
  });
}
async function evaluate(expression) {
  const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails) throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);
  return r.result.value;
}
async function key(name) {
  const code=name==='Tab'?9:13;
  for(const type of ['keyDown','keyUp'])
    await command('Input.dispatchKeyEvent',{type,key:name,code:name,windowsVirtualKeyCode:code,nativeVirtualKeyCode:code,
      ...(name==='Enter'&&type==='keyDown'?{text:'\r',unmodifiedText:'\r'}:{})});
}
async function activate(selector) {
  report.stages.push({action:'activate',selector,at:new Date().toISOString()});
  await writeFile(join(output,'checkpoint.json'),JSON.stringify(report,null,2)+'\n');
  assert.equal(await evaluate('!!document.querySelector('+JSON.stringify(selector)+')'),true,'control '+selector);
  await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');
  await key('Enter');
}
const exists=selector=>evaluate('!!document.querySelector('+JSON.stringify(selector)+')');
const text=selector=>evaluate('document.querySelector('+JSON.stringify(selector)+')?.textContent');
async function visible(selector) {
  return evaluate('(()=>{const x=document.querySelector('+JSON.stringify(selector)+');return !!x&&!x.hidden&&x.getClientRects().length>0})()');
}
async function newPage(url,width=1280,height=900) {
  report.stages.push({action:'navigate',url,width,at:new Date().toISOString()});
  await writeFile(join(output,'checkpoint.json'),JSON.stringify(report,null,2)+'\n');
  const old=targetId;
  ({targetId}=await command('Target.createTarget',{url:'about:blank'},false));
  ({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));
  if(old) await command('Target.closeTarget',{targetId:old},false);
  await command('Page.enable');
  await command('Runtime.enable');
  await command('Network.enable');
  await command('Fetch.enable',{patterns:[{urlPattern:'http://*'},{urlPattern:'https://*'}]});
  await command('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
  await command('Page.navigate',{url});
  await waitFor(()=>evaluate('document.URL==='+JSON.stringify(url)+'&&document.readyState==="complete"'),'document '+url);
}
async function chooseFile(selector,path) {
  report.stages.push({action:'file-input',selector,path,at:new Date().toISOString()});
  await writeFile(join(output,'checkpoint.json'),JSON.stringify(report,null,2)+'\n');
  const {root}=await command('DOM.getDocument');
  const {nodeId}=await command('DOM.querySelector',{nodeId:root.nodeId,selector});
  assert.ok(nodeId,'file input '+selector);
  await command('DOM.setFileInputFiles',{nodeId,files:[path]});
}
async function saveDownload(selector,name) {
  const before=new Set(downloads.keys());
  await activate(selector);
  let item;
  await waitFor(()=>{
    item=[...downloads.values()].find(x=>!before.has(x.guid)&&x.state==='completed');
    return !!item;
  },'completed download '+name);
  const source=join(downloadPath,item.guid);
  const bytes=await readFile(source);
  const path=join(downloadPath,name);
  await copyFile(source,path);
  await rm(source);
  const result={name,suggestedFilename:item.suggestedFilename,...pin(bytes)};
  report.downloads.push(result);
  return {path,bytes,entry:result};
}
async function openTrace() {
  if(!await evaluate('document.querySelector("#trace-archive-panel").open'))
    await activate('#trace-archive-panel > summary');
}
async function snapshot() {
  return evaluate('({html:document.querySelector("#session-content").innerHTML,progress:document.querySelector("[role=progressbar]").getAttribute("aria-valuenow"),title:document.title,subject:document.querySelector("#lesson-description").textContent})');
}
async function screen(name,selector) {
  await evaluate('document.querySelector('+JSON.stringify(selector)+').scrollIntoView({block:"start"})');
  const {data}=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
  const bytes=Buffer.from(data,'base64');
  await writeFile(join(output,name),bytes);
  report.screenshots.push({name,...pin(bytes)});
}
function passed(name,details) {
  report.checks.push({name,passed:true,...(details?{details}:{})});
  console.log('PASS '+name);
}
async function previewCourse(file) {
  await chooseFile('#deck-file',file);
  await waitFor(()=>visible('#deck-preview'),'course preview');
  assert.equal(await text('#deck-preview-title'),course.title);
  assert.match(await text('.deck-preview-count'),/12 questions · 4 concepts/);
  assert.equal(await text('.deck-preview-attribution'),'Attribution supplied in the deck: '+course.attribution);
  assert.equal(await text('.deck-preview-license'),'License supplied in the deck: '+course.license);
  const prompts=await evaluate('[...document.querySelectorAll(".deck-questions li")].map(x=>({prompt:x.querySelector("strong").textContent,concept:x.querySelector("p").textContent}))');
  assert.deepEqual(prompts,course.items.map(x=>({
    prompt:x.prompt,concept:x.concept+' · '+(x.prerequisites.length?'Prerequisites: '+x.prerequisites.join(', '):'No prerequisites')
  })));
}
async function startCourse(file) {
  await previewCourse(file);
  await activate('#start-deck');
  await waitFor(()=>exists('.question-card h2'),'imported question');
  assert.equal(await text('#lesson-description'),course.title);
  assert.equal(await text('#step-count'),'0 / 12');
  assert.deepEqual(await evaluate('[...document.querySelectorAll("#lesson-map .deck-concept")].map(x=>x.textContent)'),course.concepts);
}
async function verifyReview(state,practice) {
  const rows=await evaluate('[...document.querySelectorAll(".review-item")].map(x=>({prompt:x.querySelector(".review-prompt").textContent,status:x.querySelector(".review-status").textContent,choices:[...x.querySelectorAll(".review-answers dd")].map(y=>y.textContent),explanation:x.querySelector(".review-body > p").textContent,transfer:x.querySelector(".review-transfer").textContent,practice:x.querySelector(".review-practice-answer")?.textContent||null}))');
  assert.equal(rows.length,12);
  for(const [i,entry] of state.first.entries()) {
    const item=course.items.find(x=>x.id===entry.item);
    assert.equal(rows[i].prompt,item.prompt);
    assert.equal(rows[i].status,(entry.correct?'Correct':'Needs review')+' · first try');
    assert.deepEqual(rows[i].choices,[item.options[entry.choice],item.options[item.answer]]);
    assert.equal(rows[i].explanation,item.explanation);
    assert.equal(rows[i].transfer,'Apply the idea: '+item.transfer);
    const retry=practice.find(x=>x.item===entry.item);
    if(retry) assert.ok(rows[i].practice?.includes(item.options[retry.choice]));
    else assert.equal(rows[i].practice,null);
  }
  assert.deepEqual(await evaluate('[...document.querySelectorAll(".mastery-box output")].map(x=>x.textContent)'),
    course.concepts.map(c=>Math.round(state.mastery[c]*100)+'%'));
  assert.match(await text('#first-try-summary'),/10 of 12/);
  return rows;
}
function verifyTrace(bytes,state,retries=null) {
  const trace=JSON.parse(bytes.toString('utf8'));
  assert.equal(trace.format,'recallweave.learning-trace');
  assert.equal(trace.version,1);
  assert.equal(new Date(trace.savedAt).toISOString(),trace.savedAt);
  assert.deepEqual(trace.deck,course);
  assert.deepEqual(trace.firstAnswers,state.first.map(({item,choice})=>({item,choice})));
  assert.deepEqual(trace.mastery,state.mastery);
  assert.deepEqual(trace.practice,retries===null?null:{answers:retries});
  return trace;
}
function verifyNotes(bytes,state,retries=null) {
  const notes=bytes.toString('utf8');
  assert.ok(notes.startsWith('RecallWeave — study notes\n'+course.title+'\nSaved: '));
  assert.ok(notes.includes('10 of 12 connections correct on the first try.'));
  assert.ok(notes.includes('Practice does not change the first-session estimates.'));
  assert.ok(notes.includes(course.attribution)); assert.ok(notes.includes(course.license));
  for(const entry of state.first) {
    const item=course.items.find(x=>x.id===entry.item);
    const section='Your first answer: '+item.options[entry.choice]+'\nFirst try: '+(entry.correct?'correct':'needs review')+'\nCorrect answer: '+item.options[item.answer]+'\nExplanation: '+item.explanation+'\nApply the idea: '+item.transfer;
    assert.ok(notes.includes(section),'complete notes for '+entry.item);
  }
  for(const c of course.concepts) assert.ok(notes.includes(c+': '+Math.round(state.mastery[c]*100)+'%'));
  if(retries===null) assert.ok(notes.includes('Not started. 2 missed connections are available for practice.'));
  else assert.ok(notes.includes((retries.length===2?'Complete':'Paused')+': '+retries.length+' of 2 practice answers recorded; '+retries.length+' correct on retry.'));
}
async function retry(itemId) {
  const item=course.items.find(x=>x.id===itemId);
  assert.equal(await text('.practice-card h2'),item.prompt);
  const options=await evaluate('[...document.querySelectorAll("[data-practice-choice]")].map(x=>({choice:Number(x.dataset.practiceChoice),text:x.textContent.slice(1)}))');
  assert.deepEqual(options,options.map(x=>({choice:x.choice,text:item.options[x.choice]})));
  await activate('[data-practice-choice="'+item.answer+'"]');
  assert.ok((await text('#practice-feedback')).includes(item.explanation));
  assert.ok((await text('#practice-feedback')).includes(item.transfer));
  return {item:item.id,choice:item.answer};
}

try {
  browser=spawn(executable,[
    '--headless=new','--no-sandbox','--disable-gpu','--disable-background-networking',
    '--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check',
    '--disk-cache-size=1','--media-cache-size=1',
    '--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'
  ],{stdio:['ignore','ignore','pipe']});
  report.runtime.pid=browser.pid;
  browser.stderr.on('data',bytes=>{browserLog+=bytes.toString();});
  let launchError;
  browser.on('error',e=>{launchError=e;});
  let port,endpoint;
  await waitFor(async()=>{
    if(launchError) throw launchError;
    [port,endpoint]=(await readFile(join(profile,'DevToolsActivePort'),'utf8')).trim().split('\n');
    return !!port&&!!endpoint;
  },'native browser startup');
  socket=new WebSocket('ws://127.0.0.1:'+port+endpoint);
  socket.addEventListener('message',async event=>{
    const message=JSON.parse(event.data);
    if(message.id) {
      const p=pending.get(message.id);if(!p)return;
      pending.delete(message.id);clearTimeout(p.timer);
      message.error?p.reject(Error(message.error.message)):p.resolve(message.result);
    } else if(message.method==='Runtime.exceptionThrown') {
      report.pageErrors.push(message.params.exceptionDetails.exception?.description||message.params.exceptionDetails.text);
    } else if(message.method==='Network.requestWillBeSent') {
      report.requests.push({sessionId:message.sessionId,url:message.params.request.url,type:message.params.type});
    } else if(message.method==='Browser.downloadWillBegin'||message.method==='Browser.downloadProgress') {
      const value=message.params;downloads.set(value.guid,{...downloads.get(value.guid),...value});
    } else if(message.method==='Fetch.requestPaused') {
      const {requestId,request}=message.params;
      const external=new URL(request.url).origin!==base;
      if(external)report.blockedRequests.push(request.url);
      try {await command(external?'Fetch.failRequest':'Fetch.continueRequest',
        external?{requestId,errorReason:'BlockedByClient'}:{requestId});}
      catch(e){report.pageErrors.push('request policy: '+e.message);}
    }
  });
  await new Promise((resolve,reject)=>{
    socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});
  });
  report.runtime.browser=await command('Browser.getVersion',{},false);
  await command('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath,eventsEnabled:true},false);

  const physicalCourse = await readFile(suppliedCourse);
  assert.deepEqual(physicalCourse,rawCourse);
  const pausedBytes = await readFile(pausedTracePath);
  assert.equal(hash(pausedBytes),'ded4188a36a1197f0dbd9128daaf7582b78978339dbef589cb8a7939ca9be7bf');
  const historical=JSON.parse(pausedBytes.toString('utf8'));
  assert.deepEqual(historical.deck,course);
  const state={
    first:historical.firstAnswers.map(x=>({...x,correct:x.choice===course.items.find(i=>i.id===x.item).answer})),
    mastery:historical.mastery
  };
  state.missed=state.first.filter(x=>!x.correct).map(x=>x.item);
  assert.equal(state.first.length,12);assert.equal(state.missed.length,2);
  assert.deepEqual(new Set(state.missed),new Set(['sampling-assumption-boundary','sampling-acquisition-filter']));
  assert.equal(historical.practice.answers.length,1);
  const firstRetry=historical.practice.answers[0];
  verifyTrace(pausedBytes,state,[firstRetry]);
  report.receivedInputs=[
    {name:'sampling-aliasing.json',path:suppliedCourse,...pin(physicalCourse),qualification:'physical original lab download; reused without another lab execution'},
    {name:'modular-paused-trace.json',path:pausedTracePath,...pin(pausedBytes),qualification:'physical 8b82 v4 paused trace; first twelve answers are not replayed'}
  ];
  const prompt='Choose one connection from this deck and explain how it relates to another idea in your own words.';
  const noteId='sampling-assumption-boundary';
  const note='Sampling notebook receipt 31a349052b90\nText kept in study notes only.';
  const application='Application receipt 31a349052b90: literal <samples> & unchanged first answers.';
  const noteIndex=state.first.findIndex(x=>x.item===noteId);
  async function verifyNotebook(written) {
    const fields=await evaluate('[...document.querySelectorAll("[data-reflection-item]")].map(x=>({item:x.dataset.reflectionItem,text:x.value}))');
    assert.deepEqual(fields,state.first.map(x=>({item:x.item,text:written&&x.item===noteId?note:''})));
    assert.equal(await text('#application-prompt'),prompt);
    assert.equal(await evaluate('document.querySelector("#application-reflection").value'),written?application:'');
    assert.equal(await evaluate('document.documentElement.scrollWidth>innerWidth'),false);
    return fields;
  }
  async function typeText(selector,value) {
    await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');
    await command('Input.insertText',{text:value});
    assert.equal(await evaluate('document.querySelector('+JSON.stringify(selector)+').value'),value);
  }
  async function restore(file,retries) {
    await openTrace();await chooseFile('#trace-file',file);
    await waitFor(()=>visible('#trace-preview'),'physical trace preview');
    assert.match(await text('#trace-preview-summary'),/First try: 10 of 12/);
    assert.ok((await text('#trace-preview-summary')).includes('Practice: '+retries.length+' of 2'));
    await activate('#restore-trace-confirm');
    await waitFor(()=>exists('.result-card'),'restored review');
    await verifyReview(state,retries);
  }
  function currentNotes(bytes,retries,written) {
    verifyNotes(bytes,state,retries);
    const notes=bytes.toString('utf8');
    assert.equal(notes.split('Your explanation — reflection, not scored:').length-1,12);
    assert.equal((notes.match(/^  Not written\.$/gm)||[]).length,written?11:12);
    assert.ok(notes.includes('YOUR APPLICATION REFLECTION — NOT SCORED\nPrompt: '+prompt+'\n'+
      (written?'  > '+application:'Not written.')));
    assert.equal(notes.includes('Trace energy from sunlight'),false);
    assert.equal(notes.includes('  > '+note.replaceAll('\n','\n  > ')),written);
    assert.equal(notes.includes(application),written);
    return notes;
  }
  await newPage(base+'/index.html');
  await waitFor(()=>exists('#trace-archive-panel'),'current modular initialization');
  await startCourse(suppliedCourse);
  await restore(pausedTracePath,[firstRetry]);
  await verifyNotebook(false);
  await activate('.review-item:nth-of-type('+(noteIndex+1)+') > summary');
  await typeText('[data-reflection-item="'+noteId+'"]',note);
  await typeText('#application-reflection',application);
  await verifyNotebook(true);
  await activate('#practice-button');await waitFor(()=>exists('.practice-card'),'only remaining practice item');
  const secondRetry=await retry(state.missed.find(x=>x!==firstRetry.item));
  await activate('#practice-next');await waitFor(()=>exists('.result-card'),'completed current practice');
  const retries=[firstRetry,secondRetry];
  await verifyReview(state,retries);await verifyNotebook(true);
  const modularNotes=await saveDownload('#save-notes-button','current-modular-written-notes.txt');
  currentNotes(modularNotes.bytes,retries,true);
  await openTrace();
  const currentTrace=await saveDownload('#save-trace-button','current-modular-complete-trace.json');
  const completed=verifyTrace(currentTrace.bytes,state,retries);
  const expected=structuredClone(historical);expected.practice={answers:retries};expected.savedAt=completed.savedAt;
  assert.deepEqual(completed,expected,'the actual current trace adds no notebook or changed original state');
  assert.equal(currentTrace.bytes.toString('utf8').includes('31a349052b90'),false);
  await activate('.review-item:nth-of-type('+(noteIndex+1)+') > summary');
  await screen('current-modular-reflection.png','.review-item:nth-of-type('+(noteIndex+1)+')');
  report.sessions.push({surface:'current-modular-restored',width:1280,first:state.first,mastery:state.mastery,practice:retries,notebook:await verifyNotebook(true)});
  passed('current modular sampling restoration binds twelve notebook identities, keeps written reflections through the remaining retry and saves actual notes plus an answer-only trace');

  await newPage(pathToFileURL(join(project,'demo.html')).href,390,844);
  await waitFor(()=>exists('#trace-archive-panel'),'current standalone initialization');
  await startCourse(suppliedCourse);
  await restore(currentTrace.path,retries);
  await verifyNotebook(false);
  const freshNotes=await saveDownload('#save-notes-button','current-standalone-restored-notes.txt');
  currentNotes(freshNotes.bytes,retries,false);
  await activate('.review-item:nth-of-type('+(noteIndex+1)+') > summary');
  await screen('current-standalone-reflection-390.png','.review-item:nth-of-type('+(noteIndex+1)+')');
  report.sessions.push({surface:'current-standalone-restored',width:390,first:state.first,mastery:state.mastery,practice:retries,notebook:await verifyNotebook(false)});
  passed('fresh current 390px standalone restores every original answer and both retries from that physical trace, starts a blank notebook and saves current notes');

  assert.equal(report.downloads.length,3);
  assert.deepEqual(report.pageErrors,[]);assert.deepEqual(report.blockedRequests,[]);
  assert.ok(report.served.some(x=>x.path==='src/reflections.mjs'));
  assert.ok(report.requests.some(x=>x.url===pathToFileURL(join(project,'demo.html')).href));
  await verifySource();report.sourceUnchanged=true;
  report.boundary='Two changed-source surfaces, one remaining practice answer, three new physical artifacts; no lab, CSV, course mathematics or original first-answer replay.';
  report.status='passed';
} catch(error) {
  report.status='failed';report.error={name:error.name,message:error.message,stack:error.stack};
  try {report.lastPage=await evaluate('({url:document.URL,title:document.title,text:document.body.innerText.slice(0,18000)})');}catch{}
  console.error(error.stack);
  process.exitCode=1;
} finally {
  if(socket?.readyState===1) {
    try{await command('Browser.close',{},false);}catch{}
    socket.close();
  }
  if(browser && browser.exitCode===null)browser.kill('SIGTERM');
  await new Promise(resolve=>server.close(resolve));
  for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('receiver closed'));}
  pending.clear();
  await sleep(250);
  await rm(profile,{recursive:true,force:true});
  report.profileRemoved=true;
  report.endedAt=new Date().toISOString();
  await writeFile(join(output,'browser.log'),browserLog);
  await writeFile(join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({status:report.status,checks:report.checks.length,downloads:report.downloads.length,output}));
}
