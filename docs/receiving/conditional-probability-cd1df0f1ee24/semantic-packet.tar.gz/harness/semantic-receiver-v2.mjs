import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve, relative, isAbsolute } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const receiverRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const EXPECTED_FIXTURES = [
  ['recovered-original/semantic-oracles-v1.json', '609b81dae69d40281aa6e325ce6b877b49a0203c2cec2908eec5759736b4a359'],
  ['recovered-admission/high-count-oracles-v1.json', '6bf4d3d873d76f174a802c9c724222fbb402b3b998c69042be005d054300fac8'],
  ['recovered-admission/admission-cases-v1.json', '489ec5200e4f7d15c4cdf4ae43f0d34906238ca15e5acaf46db18d5e76939448'],
];
const CELL_KEYS = ['ab', 'aNotB', 'notAB', 'neither'];
const PUBLIC_IDS = [
  'joint_ab', 'joint_a_not_b', 'joint_not_a_b', 'joint_neither',
  'marginal_a', 'marginal_not_a', 'marginal_b', 'marginal_not_b',
  'a_given_b', 'not_a_given_b', 'a_given_not_b', 'not_a_given_not_b',
  'b_given_a', 'not_b_given_a', 'b_given_not_a', 'not_b_given_not_a',
];
const FORMAT = 'recallweave-conditional-table/1';
const DEFAULT_CELLS = { ab: '9', aNotB: '1', notAB: '99', neither: '891' };
const DEFAULT_LABELS = { a: 'defective file', b: 'flagged' };
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const gitBlob = bytes => createHash('sha1')
  .update('blob ' + bytes.length + '\0').update(bytes).digest('hex');
const describeError = error => ({
  name: error?.name ?? typeof error,
  message: error?.message ?? String(error),
  stack: error?.stack ?? null,
});
function argsOf(args) {
  const result = {};
  for (let i = 0; i < args.length; i += 2) {
    const key = args[i];
    if (!['--module', '--sha256', '--out'].includes(key) || !args[i + 1] || key in result) {
      throw new Error('Usage: node semantic-receiver-v1.mjs --module ABSOLUTE_PATH --sha256 EXACT_SHA256 --out NEW_OWN_RUN_DIRECTORY');
    }
    result[key] = args[i + 1];
  }
  for (const key of ['--module', '--sha256', '--out']) assert.ok(result[key], key + ' is required');
  assert.match(result['--sha256'], /^[0-9a-f]{64}$/);
  assert.ok(isAbsolute(result['--module']) && isAbsolute(result['--out']), 'Paths must be absolute');
  const rel = relative(receiverRoot, result['--out']);
  assert.ok(rel && !rel.startsWith('..') && !isAbsolute(rel), 'Output must remain in this receiver namespace');
  return result;
}
function cellSet(values) {
  assert.ok(Array.isArray(values), 'Cell membership must be an array');
  assert.equal(new Set(values).size, values.length, 'Duplicate cell membership');
  for (const value of values) assert.ok(CELL_KEYS.includes(value), 'Unknown cell membership: ' + value);
  return [...values].sort((a, b) => CELL_KEYS.indexOf(a) - CELL_KEYS.indexOf(b));
}
function sumCells(counts, indices) {
  return indices.reduce((sum, i) => sum + BigInt(counts[i]), 0n).toString();
}
function observeAdmission(fn, raw) {
  // Catch only the product call. Adapter/representation failures remain failures.
  let value;
  try { value = fn(raw); }
  catch (error) { return { accepted: false, error: describeError(error), nativeError: error }; }
  return { accepted: true, value };
}
function checkAdmission(observation, fixture, outputKind) {
  assert.equal(observation.accepted, fixture.expected.accepted, 'Admission decision');
  if (!fixture.expected.accepted) {
    const expectedClass = typeof fixture.input === 'string' ? RangeError : TypeError;
    assert.ok(observation.nativeError instanceof expectedClass,
      'Expected ' + expectedClass.name + ', got ' + observation.error?.name);
    return;
  }
  assert.equal(typeof observation.value, outputKind, 'Admitted result type');
  const literal = outputKind === 'bigint' ? observation.value.toString() : observation.value;
  assert.equal(literal, fixture.expected.value, 'Admitted literal or exact count');
}
function serialAdmission(observation) {
  if (!observation.accepted) return { accepted: false, error: observation.error };
  return {
    accepted: true,
    type: typeof observation.value,
    value: typeof observation.value === 'bigint' ? observation.value.toString() : observation.value,
  };
}
function verifyTable(result, fixture, queries, definitions) {
  assert.deepEqual(JSON.parse(JSON.stringify(result)), result, 'Table result must be JSON-safe');
  assert.equal(result.format, FORMAT);
  assert.deepEqual(result.labels, DEFAULT_LABELS);
  assert.deepEqual(result.cells, Object.fromEntries(CELL_KEYS.map((key, i) => [key, fixture.counts[i]])));
  assert.equal(result.total, fixture.total);
  assert.ok(Array.isArray(result.probabilities));
  assert.equal(result.probabilities.length, 16);
  for (let i = 0; i < 16; i++) {
    const actual = result.probabilities[i];
    const query = queries[i];
    const expectedNumerator = sumCells(fixture.counts, query.numerator_cells);
    const expectedDenominator = sumCells(fixture.counts, query.denominator_cells);
    assert.equal(actual.id, PUBLIC_IDS[i], 'Probability identity and ordering');
    assert.equal(actual.kind, i < 4 ? 'joint' : i < 8 ? 'marginal' : 'conditional');
    assert.equal(actual.symbol, definitions[i].symbol, 'Public definition symbol');
    assert.deepEqual(cellSet(actual.numeratorCells), cellSet(query.numerator_cells.map(j => CELL_KEYS[j])));
    assert.deepEqual(cellSet(actual.denominatorCells), cellSet(query.denominator_cells.map(j => CELL_KEYS[j])));
    assert.equal(actual.numerator, expectedNumerator, 'Exact numerator count');
    assert.equal(actual.denominator, expectedDenominator, 'Exact denominator count');
    if (fixture.probabilities[i] === null) {
      assert.equal(actual.defined, false);
      assert.equal(actual.reducedNumerator, null);
      assert.equal(actual.reducedDenominator, null);
    } else {
      const [numerator, denominator] = fixture.probabilities[i].split('/');
      assert.equal(actual.defined, true);
      assert.equal(actual.reducedNumerator, numerator, 'Frozen exact reduced numerator');
      assert.equal(actual.reducedDenominator, denominator, 'Frozen exact reduced denominator');
    }
  }
  assert.equal(result.independence.defined, fixture.independent !== null);
  assert.equal(result.independence.independent, fixture.independent);
  assert.equal(result.independence.left, fixture.identity_left ?? '0');
  assert.equal(result.independence.right, fixture.identity_right ?? '0');
}
function evidenceStringify(value) {
  // Only encode evidence: comparison paths above still use the untouched result.
  const ancestors = [];
  return JSON.stringify(value, function (key, item) {
    if (typeof item === 'bigint') return { $receiverType: 'bigint', decimal: item.toString() };
    if (typeof item === 'number' && !Number.isFinite(item)) return { $receiverType: 'number', literal: String(item) };
    if (typeof item === 'undefined') return { $receiverType: 'undefined' };
    if (typeof item === 'symbol') return { $receiverType: 'symbol', literal: String(item) };
    if (typeof item === 'function') return { $receiverType: 'function', name: item.name };
    if (item !== null && typeof item === 'object') {
      while (ancestors.length && ancestors.at(-1) !== this) ancestors.pop();
      if (ancestors.includes(item)) return { $receiverType: 'circular-reference' };
      ancestors.push(item);
    }
    return item;
  }, 2) + '\n';
}
async function main() {
  let options;
  try { options = argsOf(process.argv.slice(2)); }
  catch (error) { process.stderr.write(error.message + '\n'); process.exitCode = 2; return; }
  const sourcePath = resolve(options['--module']);
  const output = resolve(options['--out']);
  await mkdir(output, { recursive: false });
  const receipt = {
    kind: 'Independent conditional-probability semantic receiving',
    started_at: new Date().toISOString(),
    node: process.version,
    expectedCoverage: { tableFixtures: 30, exactRatios: 480, independenceStates: 30, admissionFixtures: 135 },
    productSource: null,
    fixturePins: [],
    receiver: null,
    fixturesPassed: 0,
    fixturesFailed: 0,
    observations: [],
    fatal: null,
  };
  let sourceBefore;
  try {
    const fixtures = [];
    for (const [path, expected] of EXPECTED_FIXTURES) {
      const bytes = await readFile(resolve(receiverRoot, path));
      assert.equal(sha(bytes), expected, 'Frozen fixture hash: ' + path);
      receipt.fixturePins.push({ path, bytes: bytes.length, sha256: sha(bytes) });
      fixtures.push(JSON.parse(bytes.toString('utf8')));
    }
    const [ordinary, large, admissions] = fixtures;
    assert.deepEqual(large.queries, ordinary.queries);
    assert.equal(ordinary.tables.length + large.tables.length, 30);
    assert.equal(admissions.count_cases.length + admissions.label_cases.length, 135);
    const receiverBytes = await readFile(fileURLToPath(import.meta.url));
    receipt.receiver = { bytes: receiverBytes.length, sha256: sha(receiverBytes) };
    sourceBefore = await readFile(sourcePath);
    assert.equal(sha(sourceBefore), options['--sha256'], 'Exact candidate source gate');
    receipt.productSource = { path: sourcePath, bytes: sourceBefore.length, sha256: sha(sourceBefore), gitBlob: gitBlob(sourceBefore) };
    const model = await import(pathToFileURL(sourcePath).href);
    for (const name of ['parseCount', 'parseEventLabel', 'analyzeTable']) {
      assert.equal(typeof model[name], 'function', 'Missing declared export: ' + name);
    }
    assert.deepEqual(model.CELL_KEYS, CELL_KEYS);
    assert.ok(Array.isArray(model.PROBABILITIES));
    assert.equal(model.PROBABILITIES.length, 16);
    for (let i = 0; i < 16; i++) {
      const definition = model.PROBABILITIES[i];
      const query = ordinary.queries[i];
      assert.equal(definition.id, PUBLIC_IDS[i]);
      assert.equal(definition.kind, i < 4 ? 'joint' : i < 8 ? 'marginal' : 'conditional');
      assert.equal(typeof definition.symbol, 'string');
      assert.ok(definition.symbol.trim());
      assert.deepEqual(cellSet(definition.numeratorCells), cellSet(query.numerator_cells.map(j => CELL_KEYS[j])));
      assert.deepEqual(cellSet(definition.denominatorCells), cellSet(query.denominator_cells.map(j => CELL_KEYS[j])));
    }
    async function run(group, id, action) {
      const observation = { group, id, passed: false };
      try { await action(observation); observation.passed = true; receipt.fixturesPassed++; }
      catch (error) { observation.error = describeError(error); receipt.fixturesFailed++; }
      receipt.observations.push(observation);
    }
    for (const fixture of [...ordinary.tables, ...large.tables]) {
      await run('table', fixture.id, observation => {
        const input = { cells: Object.fromEntries(CELL_KEYS.map((key, i) => [key, fixture.counts[i]])), labels: { ...DEFAULT_LABELS } };
        const before = JSON.stringify(input);
        const actual = model.analyzeTable(input);
        observation.actual = actual;
        assert.equal(JSON.stringify(input), before, 'Pure model must preserve input');
        verifyTable(actual, fixture, ordinary.queries, model.PROBABILITIES);
        assert.deepEqual(model.analyzeTable(input), actual, 'Same input must have deterministic output');
      });
    }
    for (const fixture of admissions.count_cases) {
      await run('count-admission', fixture.id, observation => {
        const parsed = observeAdmission(model.parseCount, fixture.input);
        observation.parser = serialAdmission(parsed);
        checkAdmission(parsed, fixture, 'bigint');
        observation.tableEntries = [];
        for (const key of CELL_KEYS) {
          const input = { cells: { ...DEFAULT_CELLS, [key]: fixture.input }, labels: { ...DEFAULT_LABELS } };
          const before = JSON.stringify(input);
          const full = observeAdmission(model.analyzeTable, input);
          observation.tableEntries.push({ field: key, ...serialAdmission(full) });
          assert.equal(JSON.stringify(input), before, 'Rejected or accepted input remains unchanged');
          if (!fixture.expected.accepted) checkAdmission(full, fixture, 'object');
          else {
            assert.equal(full.accepted, true, 'Table must admit the same count');
            assert.deepEqual(JSON.parse(JSON.stringify(full.value)), full.value);
            assert.equal(full.value.cells[key], fixture.expected.value);
          }
        }
      });
    }
    for (const fixture of admissions.label_cases) {
      await run('label-admission', fixture.id, observation => {
        const parsed = observeAdmission(model.parseEventLabel, fixture.input);
        observation.parser = serialAdmission(parsed);
        checkAdmission(parsed, fixture, 'string');
        observation.tableEntries = [];
        for (const key of ['a', 'b']) {
          const input = { cells: { ...DEFAULT_CELLS }, labels: { ...DEFAULT_LABELS, [key]: fixture.input } };
          const before = JSON.stringify(input);
          const full = observeAdmission(model.analyzeTable, input);
          observation.tableEntries.push({ field: key, ...serialAdmission(full) });
          assert.equal(JSON.stringify(input), before, 'Rejected or accepted input remains unchanged');
          if (!fixture.expected.accepted) checkAdmission(full, fixture, 'object');
          else {
            assert.equal(full.accepted, true, 'Table must admit the same literal label');
            assert.deepEqual(JSON.parse(JSON.stringify(full.value)), full.value);
            assert.equal(full.value.labels[key], fixture.expected.value);
          }
        }
      });
    }
    assert.equal(receipt.fixturesPassed + receipt.fixturesFailed, 165);
    const sourceAfter = await readFile(sourcePath);
    assert.deepEqual(sourceAfter, sourceBefore, 'Source bytes preserved after execution');
    receipt.sourcePreserved = true;
    for (const pin of receipt.fixturePins) {
      assert.equal(sha(await readFile(resolve(receiverRoot, pin.path))), pin.sha256, 'Fixture bytes preserved');
    }
  } catch (error) {
    receipt.fatal = describeError(error);
    receipt.sourcePreserved = sourceBefore ? sha(await readFile(sourcePath)) === sha(sourceBefore) : null;
  }
  receipt.finished_at = new Date().toISOString();
  receipt.passed = !receipt.fatal && receipt.fixturesFailed === 0 && receipt.fixturesPassed === 165;
  await writeFile(resolve(output, 'receipt.json'), evidenceStringify(receipt), { flag: 'wx' });
  process.stdout.write(JSON.stringify({
    passed: receipt.passed, fixturesPassed: receipt.fixturesPassed, fixturesFailed: receipt.fixturesFailed,
    fatal: receipt.fatal, output, source: receipt.productSource, expectedCoverage: receipt.expectedCoverage,
  }) + '\n');
  process.exitCode = receipt.passed ? 0 : 1;
}
await main();
