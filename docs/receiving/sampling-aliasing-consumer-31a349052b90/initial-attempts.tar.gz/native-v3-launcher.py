from pathlib import Path
import subprocess,hashlib,os,json,datetime,time,signal
r=Path('/dev/shm/hamon-31a349052b90-recall-sampling-consumer'); out=r/'run-v3'; out.mkdir(exist_ok=False)
for n in ['tmp','cache','config']: (out/n).mkdir()
exe=Path('/snap/chromium/current/usr/lib/chromium-browser/chrome').resolve(strict=True)
with exe.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
runtime={'executable':str(exe),'bytes':exe.stat().st_size,'sha256':digest,'node':subprocess.check_output(['/usr/bin/node','--version'],text=True).strip(),'browser_version':subprocess.check_output([str(exe),'--version'],text=True).strip(),'host':os.uname().nodename}
(out/'runtime.json').write_text(json.dumps(runtime,indent=2)+'\n')
args=['/usr/bin/node',str(r/'receive-sampling-v3.mjs'),'--root',str(r/'source'),'--manifest',str(r/'source-manifest.json'),'--course-input',str(r/'run-v1/downloads/sampling-aliasing.json'),'--output',str(out),'--browser',str(exe)]
env=os.environ.copy();env.update({'TMPDIR':str(out/'tmp'),'XDG_CACHE_HOME':str(out/'cache'),'XDG_CONFIG_HOME':str(out/'config')})
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); began=time.monotonic(); timed_out=False
with (out/'stdout.txt').open('w') as stdout,(out/'stderr.txt').open('w') as stderr:
 p=subprocess.Popen(args,cwd=r,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try: rc=p.wait(timeout=150)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
receipt={'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-began,'argv':args,'pid':p.pid,'exit_code':rc,'timed_out':timed_out,'runtime':runtime,'runner_sha256':hashlib.sha256((r/'receive-sampling-v3.mjs').read_bytes()).hexdigest()}
(out/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));print((out/'stdout.txt').read_text());print((out/'stderr.txt').read_text()[-8000:])
