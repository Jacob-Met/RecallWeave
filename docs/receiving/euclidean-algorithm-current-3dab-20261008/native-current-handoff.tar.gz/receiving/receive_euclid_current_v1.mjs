#!/usr/bin/env node
// Focused current-learner Euclid receiver. CDP lifecycle follows the previously received
// Euclid/SQL/counting private-profile route; this file runs only published Euclid
// actual-file learner handoff through corrected division-3, with no HTTP server.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import {readFile,writeFile,mkdir,mkdtemp,rm,rename,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
const carrier='/home/jacob/snap/chromium/common/optimizer-euclid-current-handoff-3dab-20261008';
const root=join(carrier,'source'),output=join(carrier,'receiving/browser-v1');
const executable='/snap/bin/chromium';
const sha=b=>createHash('sha256').update(b).digest('hex');
const git=b=>createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const manifestBytes=await readFile(join(carrier,'receiving/source-pins.json'));
assert.equal(sha(manifestBytes),'7ce2bcfcecff22ef8d5493d815e1675ac887c8d3ad860a8c04d88a804d7a519f');
const manifest=JSON.parse(manifestBytes);
await mkdir(output);
const downloadPath=join(output,'downloads');await mkdir(downloadPath);
const profile=await mkdtemp(join(output,'profile-'));
const report={started:new Date().toISOString(),status:'running',node:process.version,platform:process.platform,root,output,executable,manifest:sha(manifestBytes),checks:[],pages:[],screenshots:[],downloads:[],pageErrors:[],requests:[],blocked:[]};
async function guards(){
 const result={};
 for(const [name,pin]of Object.entries(manifest.files)){
  const b=await readFile(join(root,name)),actual={bytes:b.length,sha256:sha(b),git_blob:git(b)};
  assert.deepEqual(actual,pin,name);result[name]=actual;
 }
 async function walk(dir,prefix=''){const paths=[];for(const e of await readdir(dir,{withFileTypes:true})){const n=prefix+e.name;if(e.isDirectory())paths.push(...await walk(join(dir,e.name),n+'/'));else{assert.ok(e.isFile());paths.push(n);}}return paths;}
 assert.deepEqual((await walk(root)).sort(),Object.keys(result).sort());return result;
}
report.before=await guards();
const courseBytes=await readFile(join(root,'courses/euclidean-algorithm.json')),course=JSON.parse(courseBytes);
const pending=new Map(),downloads=new Map();let browser,socket,sessionId,sequence=0,stderr='';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitFor(fn,label){let last;for(let i=0;i<160;i++){try{if(await fn())return;}catch(e){last=e;}await sleep(75);}throw Error('Timed out '+label+(last?': '+last.message:''));}
function cmd(method,params={},scoped=true){const id=++sequence;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));});}
async function evaluate(expression){const r=await cmd('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value;}
async function key(name){const codes={Enter:13,Tab:9,Backspace:8,Space:32,Escape:27};for(const type of ['keyDown','keyUp'])await cmd('Input.dispatchKeyEvent',{type,key:name==='Space'?' ':name,code:name,windowsVirtualKeyCode:codes[name],nativeVirtualKeyCode:codes[name],...(name==='Enter'&&type==='keyDown'?{text:'\r',unmodifiedText:'\r'}:{})});}
async function focus(selector){assert.ok(await evaluate('!!document.querySelector('+JSON.stringify(selector)+')'),'Missing '+selector);await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');assert.ok(await evaluate('document.activeElement.matches('+JSON.stringify(selector)+')'));}
async function activate(selector){await focus(selector);await key('Enter');}
async function fill(selector,text){await evaluate('(()=>{const e=document.querySelector('+JSON.stringify(selector)+');e.focus();e.select();})()');await key('Backspace');if(text)await cmd('Input.insertText',{text});assert.equal(await evaluate('document.querySelector('+JSON.stringify(selector)+').value'),text);}
async function radio(name,value){const selector='input[name='+name+'][value='+value+']';if(!await evaluate('document.querySelector('+JSON.stringify(selector)+').checked')){await focus(selector);await key('Space');}assert.equal(await evaluate('document.querySelector('+JSON.stringify(selector)+').checked'),true);}
async function navigate(file,width=1280,height=1000,ready='#count-form'){const url=pathToFileURL(join(root,file)).href;await cmd('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});await cmd('Page.navigate',{url});await waitFor(()=>evaluate('document.URL === '+JSON.stringify(url)+' && document.readyState==="complete" && !!document.querySelector('+JSON.stringify(ready)+')'),'navigate '+file);}
async function screenshot(name,selector){if(selector)await evaluate('document.querySelector('+JSON.stringify(selector)+').scrollIntoView({block:"start"})');const {data}=await cmd('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const b=Buffer.from(data,'base64');await writeFile(join(output,name),b);report.screenshots.push({name,bytes:b.length,sha256:sha(b)});}
async function download(selector,name){const old=new Set(downloads.keys());await activate(selector);let d;await waitFor(()=>{d=[...downloads.values()].find(x=>!old.has(x.guid)&&x.state==='completed');return !!d;},'download '+name);const from=join(downloadPath,d.guid),to=join(downloadPath,name),bytes=await readFile(from);await rename(from,to);report.downloads.push({name,suggestedFilename:d.suggestedFilename,bytes:bytes.length,sha256:sha(bytes),guid:d.guid});return {path:to,bytes,suggestedFilename:d.suggestedFilename};}
function passed(label){report.checks.push(label);console.log('PASS '+label);}
function exited(ms){if(!browser||browser.exitCode!==null||browser.signalCode!==null)return Promise.resolve(true);return new Promise(resolve=>{const done=()=>{clearTimeout(timer);browser.off('exit',done);resolve(true);};const timer=setTimeout(()=>{browser.off('exit',done);resolve(false);},ms);browser.once('exit',done);});}
try{
 browser=spawn(executable,['--headless=new','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--password-store=basic','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1, EXCLUDE localhost','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
 browser.stderr.on('data',b=>{stderr+=b.toString();});
 const endpoint=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Browser startup timeout')),45000);browser.once('error',e=>{clearTimeout(timer);reject(e);});browser.once('exit',c=>{clearTimeout(timer);reject(Error('Browser exited '+c));});browser.stderr.on('data',()=>{const m=stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});});
 socket=new WebSocket(endpoint);socket.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}else if(m.method.startsWith('Browser.download')){const d=m.params;downloads.set(d.guid,{...downloads.get(d.guid),...d});}else if(m.method==='Runtime.exceptionThrown')report.pageErrors.push(m.params);else if(m.method==='Network.requestWillBeSent')report.requests.push(m.params.request.url);else if(m.method==='Fetch.requestPaused'){report.blocked.push(m.params.request.url);cmd('Fetch.failRequest',{requestId:m.params.requestId,errorReason:'BlockedByClient'}).catch(e=>report.pageErrors.push(e.message));}});
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 report.browser=await cmd('Browser.getVersion',{},false);await cmd('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath,eventsEnabled:true},false);
 const {targetId}=await cmd('Target.createTarget',{url:'about:blank'},false);({sessionId}=await cmd('Target.attachToTarget',{targetId,flatten:true},false));
 for(const method of ['Page.enable','Runtime.enable','Network.enable','DOM.enable'])await cmd(method);
 await cmd('Network.setCacheDisabled',{cacheDisabled:true});await cmd('Network.setBypassServiceWorker',{bypass:true});await cmd('Fetch.enable',{patterns:[{urlPattern:'http://*'},{urlPattern:'https://*'}]});
 await navigate('courses/euclidean-algorithm-explorer.html',1280,1000,'#euclid-form');
 const courseDownload=await download('#download-course','downloaded-euclidean-algorithm.json');
 assert.deepEqual(courseDownload.bytes,courseBytes);assert.equal(courseDownload.suggestedFilename,'euclidean-algorithm.json');
 passed('published explorer physically downloads the exact V2 course bytes');
 await navigate('demo.html',390,844,'#deck-file');
 const before=await evaluate("({progress:document.querySelector('#step-count').textContent,size:document.querySelector('#lesson-size').textContent,html:document.querySelector('#session-content').innerHTML})");assert.equal(before.progress,'0 / 6');
 const {root:doc}=await cmd('DOM.getDocument');const {nodeId}=await cmd('DOM.querySelector',{nodeId:doc.nodeId,selector:'#deck-file'});
 await cmd('DOM.setFileInputFiles',{nodeId,files:[courseDownload.path]});
 await waitFor(()=>evaluate("!document.querySelector('#deck-preview').hidden && !!document.querySelector('#start-deck')"),'downloaded Euclid course preview');
 report.learnerPreview=await evaluate("({title:document.querySelector('#deck-preview-title').textContent,count:document.querySelector('.deck-preview-count').textContent,prompts:[...document.querySelectorAll('.deck-questions li strong')].map(x=>x.textContent),progress:document.querySelector('#step-count').textContent,size:document.querySelector('#lesson-size').textContent,html:document.querySelector('#session-content').innerHTML})");
 assert.equal(report.learnerPreview.title,course.title);assert.deepEqual(report.learnerPreview.prompts,course.items.map(x=>x.prompt));assert.match(report.learnerPreview.count,/12 questions · 4 concepts/);
 assert.equal(report.learnerPreview.progress,before.progress);assert.equal(report.learnerPreview.size,before.size);assert.equal(report.learnerPreview.html,before.html);
 passed('actual downloaded-file preview contains all twelve canonical prompts and preserves the default session before Start');
 await activate('#start-deck');await waitFor(()=>evaluate("!!document.querySelector('.question-card h2')"),'explicit Euclid start');
 assert.equal(await evaluate("document.querySelector('#lesson-size').textContent"),'12 challenges');
 const seen=new Set();report.lesson=[];let reached=false;
 for(let i=0;i<12;i++){
  const prompt=await evaluate("document.querySelector('.question-card h2').textContent"),item=course.items.find(x=>x.prompt===prompt);
  assert.ok(item,'Question belongs to exact downloaded Euclid deck');assert.ok(!seen.has(item.id),'No duplicate advancement');seen.add(item.id);
  await activate('.choice[data-choice="'+item.answer+'"]');await waitFor(()=>evaluate("!!document.querySelector('#feedback-slot .feedback')"),'canonical feedback '+item.id);
  const feedback=await evaluate("document.querySelector('#feedback-slot .feedback').textContent");
  assert.ok(feedback.includes(item.explanation));assert.equal(await evaluate("document.querySelector('.choice[data-choice=\""+item.answer+"\"]').disabled"),true);
  report.lesson.push({item:item.id,prompt,answer:item.answer,feedback});
  if(item.id==='euclid-division-3'){
   assert.equal(prompt,'When a nonnegative integer a is divided by a positive integer b, which condition gives the full allowed range of the Euclidean remainder r?');
   await screenshot('euclid-division-3-phone.png','.question-card');reached=true;break;
  }
  await activate('#next-button');await waitFor(()=>evaluate("document.querySelector('.question-card h2')?.textContent !== "+JSON.stringify(prompt)),'ordinary next after '+item.id);
 }
 assert.ok(reached,'Ordinary selector must reach the corrected division-3 question');
 report.geometry=await evaluate("({width:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth})");
 assert.ok(report.geometry.document<=report.geometry.width+1,'390px learner horizontal bounds');
 passed('explicit Start and ordinary canonical answer/Next events reach corrected division-3 feedback at 390px');
 assert.deepEqual(report.pageErrors,[]);assert.deepEqual(report.blocked,[]);assert.ok(report.requests.every(x=>x.startsWith('file:')||x.startsWith('blob:')));
 report.after=await guards();assert.deepEqual(report.after,report.before);passed('all three published input files remain exact and observed page requests remain offline without JavaScript exceptions');report.status='passed';
}catch(error){report.status='failed';report.error=error.stack??String(error);process.exitCode=1;console.error(report.error);if(sessionId)try{report.lastPage=await evaluate("({url:location.href,text:document.body.innerText.slice(0,15000),focus:document.activeElement.outerHTML})");await screenshot('failed-state.png');}catch{}}
finally{
 try{report.after=await guards();assert.deepEqual(report.after,report.before);}catch(e){report.guardError=e.stack;report.status='failed';process.exitCode=1;}
 if(socket?.readyState===WebSocket.OPEN)try{await cmd('Browser.close',{},false);}catch{}socket?.close();for(const p of pending.values())clearTimeout(p.timer);
 if(!await exited(5000)){browser.kill('SIGTERM');if(!await exited(5000)){browser.kill('SIGKILL');await exited(5000);}}
 try{assert.ok(!browser||browser.exitCode!==null||browser.signalCode!==null,'Owned browser exit not observed');await rm(profile,{recursive:true,force:true,maxRetries:5,retryDelay:150});report.cleanup={profile,pid:browser?.pid,exitCode:browser?.exitCode,signal:browser?.signalCode,removed:true};}catch(e){report.cleanup={profile,error:e.stack};report.status='failed';process.exitCode=1;}
 report.finished=new Date().toISOString();await writeFile(join(output,'browser-stderr.txt'),stderr);await writeFile(join(output,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
 console.log('EUCLID_HANDOFF_'+(report.status==='passed'?'OK':'FAILED')+' checks='+report.checks.length+' failures='+(report.status==='passed'?0:1));
}
