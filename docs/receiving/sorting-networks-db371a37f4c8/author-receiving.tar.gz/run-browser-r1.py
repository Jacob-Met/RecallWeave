import pathlib,json,hashlib,subprocess,datetime,os,sys,time,shutil,re
R=pathlib.Path(__file__).resolve().parent
S=R/'candidate-r1'
NODE=pathlib.Path('C:/Program Files/nodejs/node.exe')
EDGE=pathlib.Path('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe')
DONOR=pathlib.Path('D:/Hamon/receiving/pneumatic-goals-root-db371a37f4c8')
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 b=v if isinstance(v,bytes) else (json.dumps(v,indent=2)+'\n').encode()
 with p.open('xb') as h:h.write(b)
guard=json.loads(subprocess.check_output(['powershell','-NoProfile','-Command',"[pscustomobject]@{c=(Get-PSDrive C).Free;d=(Get-PSDrive D).Free;memory=[int64](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1024;edge=(Get-Item 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe').VersionInfo.ProductVersion}|ConvertTo-Json -Compress"],text=True,encoding='utf-8'))
assert guard['c']>=2**30 and guard['d']>=2**30 and guard['memory']>=2**31,guard
RUN=R/'browser-r1';RUN.mkdir(exist_ok=False)
receipt=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),guard=guard,commands=[],error=None)
source=lambda:[dict(path=p.relative_to(S).as_posix(),**pin(p.read_bytes())) for p in sorted(S.rglob('*')) if p.is_file()]
before=source();save(RUN/'source-before.json',before)
donor=json.loads((DONOR/'LINUX-DONOR-MANIFEST.json').read_text(encoding='utf-8'))
def check_donor():
 for p,q in donor.items():
  b=(DONOR/'dependencies/node_modules'/p).read_bytes()
  assert len(b)==q['bytes'] and hashlib.sha256(b).hexdigest()==q['sha256'],p
try:
 check_donor()
 receipt['donor_manifest']=pin((DONOR/'LINUX-DONOR-MANIFEST.json').read_bytes())
 receipt['donor_admission']=pin((DONOR/'WINDOWS-ADMISSION-r1.json').read_bytes())
 receipt['donor_files']=len(donor)
 receipt['node']=pin(NODE.read_bytes());receipt['edge']=pin(EDGE.read_bytes())
 code=subprocess.run([str(NODE),'--check',str(S/'tools/check_sorting_networks_browser.mjs')],capture_output=True,timeout=20)
 save(RUN/'syntax.stdout',code.stdout);save(RUN/'syntax.stderr',code.stderr)
 assert code.returncode==0,'driver syntax'
 tmp=RUN/'tmp';tmp.mkdir()
 env=os.environ.copy();env.update(TEMP=str(tmp),TMP=str(tmp),DEBUG='pw:browser')
 env.pop('PLAYWRIGHT_LEGACY_SCREENSHOT',None)
 args=[str(NODE),str(S/'tools/check_sorting_networks_browser.mjs'),'--root',str(S),'--browser',str(EDGE),'--playwright',str(DONOR/'dependencies/node_modules/playwright/index.mjs'),'--output',str(RUN/'artifacts')]
 with (RUN/'driver.stdout').open('xb') as out,(RUN/'driver.stderr').open('xb') as err:
  t=time.monotonic();p=subprocess.Popen(args,cwd=RUN,env=env,stdout=out,stderr=err)
  receipt['child_pid']=p.pid;save(RUN/'started.json',dict(pid=os.getpid(),child=p.pid,args=args,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  try:rc=p.wait(timeout=180)
  except subprocess.TimeoutExpired:
   receipt['timeout']=True
   result=subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,timeout=20)
   save(RUN/'timeout-taskkill.stdout',result.stdout);save(RUN/'timeout-taskkill.stderr',result.stderr)
   p.wait(timeout=10);raise
 receipt['commands'].append(dict(argv=args,pid=p.pid,exit=rc,seconds=time.monotonic()-t))
 receipt['child_exit']=rc
 receipt['source_exact']=source()==before;assert receipt['source_exact']
 check_donor();receipt['donor_exact']=True
 receipt['remaining_tmp_entries']=[q.relative_to(tmp).as_posix() for q in tmp.rglob('*')]
 receipt['browser_pids']=[int(x) for x in re.findall(r'<launched> pid=(\d+)',(RUN/'driver.stderr').read_text(encoding='utf-8',errors='replace'))]
 if rc!=0:raise RuntimeError('browser driver exit '+str(rc))
except BaseException as e:receipt['error']=repr(e)
finally:
 receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 save(RUN/'wrapper-receipt.json',receipt)
 print(json.dumps(receipt))
sys.exit(1 if receipt['error'] else 0)
