# Independent source review — edit distance candidate v1

## Decision and attribution

**Accepted for the bounded source review described here. No blocking source defect was found.** This is a continuation by `/root/levenshtein_receiving` after the session/agent-store reset. The original independent contract, independently reasoned answers, oracle generation and native receiving belong to **estate-68094585a1c2 / scope_receiving**. They have been recovered and preserved verbatim.

This continuation began with native custody recovery at 2026-10-08T20:33:09.899478+00:00. It read the admitted candidate and the existing frozen answers. It did not create a new blind contract, solve the fourteen questions again, import or execute the candidate, rerun the four receiving groups, read the author's focused tests/browser receiver, or repeat the upstream 39-test suite.

The source decision applies to candidate manifest SHA-256 `5ffc0ffb89d06c7c3728da8b37b4663bcbf97213e8a19c0d5e6c5ec3918fe8b3`. The eight candidate files in `candidate-admission.json` remain byte-identical to the author's current admitted packet, as read back on the native device at 2026-10-08T20:41:04.747968+00:00.

## Original evidence carried forward

The public contract was frozen before author implementation acceptance. The original independent receiver froze its own contract at **2026-10-08T20:04:45.722Z**, with access limited to the public contract, question-only course and additive representation clarification. It admitted the candidate only at **2026-10-08T20:11:47.087454+00:00**.

The original receiving ran on hamon-thinkpad, device `d55b2499-5e82-4805-819a-d0d7ddea1efe`, Node **v22.22.1**, from **2026-10-08T20:13:43.746Z to 20:13:44.202Z**. Its four accepted groups are:

| Original receiving group | Preserved result |
|---|---|
| Frozen complete model records | 15 exact records; 1,184 prefix cells; 3,149 candidate moves |
| Input refusal | 36 vectors across both input positions threw |
| Fixed course through the exact original parser | All 14 answers matched the independently frozen key; original question fields were unchanged |
| Native source/input custody | 18 protected files unchanged before and after receiving |

The full record comparison included matrix costs, decimal path counts, complete per-cell candidates, policy, literal code points, indexed gaps and canonical forward alignment. Twelve small independent cases used unpruned path enumeration; three maximum-length cases used binomial closed forms. The maximum supplementary cases recorded **2,704,156** paths. This is an exact decimal-count check, not evidence that any demonstrated count exceeds Number.MAX_SAFE_INTEGER.

The original refusal receiver asserted that each refused call threw; it recorded the observed error class and message. It did **not** compare every message against a frozen expected message. This source review separately confirms the explicit TypeError/RangeError guard paths in the admitted model.

Original receipt: `native-receiving.json`, SHA-256 `65fde907f3c91e4fc5a542eb894380a862e029fcceb5890be5fc5441f9df5ea6`.
Raw actual model records: `actual-model-records.json`, SHA-256 `8b1097e8d295bcaa45e374706944b59a7031ac5c61d1981b220cad7bf7e0a6e7`.

## Course explanations and transfer prompts

All fourteen explanations and the guide's fourteen-answer table were read alongside the **existing** `expected-course-answers.json`. Each correct option is supported by the already frozen reason. The table below records the review focus; it is not a replacement answer key.

| Course item | Review of explanation and transfer |
|---|---|
| one-substitution | Gives a feasible one-edit construction and the nonidentity lower bound; transfer preserves both proof obligations. |
| suffix-shift | Uses the length-change lower bound and explains why aligned source/target indices can differ; the gap transfer addresses positional-mismatch confusion. |
| empty-source | Requires one insertion per target code point and treats empty input as valid; transfer separates zero edits from one empty path. |
| not-transposition | States the allowed operations and rules out every one-edit possibility; transfer asks learners to compare operation models before comparing values. |
| prefix-meaning | Defines indices as consumed prefix lengths; neither suffixes nor edit budgets are substituted for that meaning. |
| boundary-row | Connects increasing boundary values to mandatory insertions/deletions and explains why zero boundaries corrupt interior cells. |
| cell-cost | Adds the last operation cost to each predecessor before minimizing; transfer explicitly calls for recomputation when the input changes. |
| why-recurrence | Exhausts possible final alignment columns and supplies the optimal-prefix replacement argument. |
| repeat-tie | Applies diagonal preference while moving backward, then reverses the choices for the forward display; the insertion transfer uses the same direction convention. |
| path-count | Distinguishes indexed monotone alignment paths from target strings and arbitrary orders of mutable-string commands. |
| count-parents | Uses a unique last move to justify disjoint addition and excludes a more expensive incoming edge. |
| normalization | Preserves the literal code-point model and the frozen two-edit reasoning; preprocessing is presented as an explicit alternative input model. |
| emoji-units | Uses the declared three-code-point sequence and the length lower bound; it does not equate a displayed symbol with a single code point. |
| input-bound | Separates code-point count, UTF-16 length and edit distance; transfer explains that a display bound is not an inherent limit of the algorithm. |

The four concepts progress from allowed edits through prefix subproblems and ties to representation. Prerequisite labels match the course's concept vocabulary. Questions state the assumptions needed to stand alone under adaptive selection; explanations do not depend on the immediately preceding question. Transfers require reasoning or a related construction, rather than changing the fixed answer key.

## Guide, model and primary references

The guide's operation table, boundary formulas, complete ABC → AC table and AB → BA tie table agree with the original frozen course conclusions and admitted model policy. Its proof distinguishes an attainable cost from proof of optimality, and the alignment examples distinguish a local prefix solution from the complete selected path.

The model uses row-major prefix construction, diagonal/deletion/insertion candidate order, equality cost zero, unit nonmatch costs, one empty path at the origin and addition only along optimal edges. Canonical reconstruction chooses the first optimal predecessor while moving backward and reverses the resulting columns. The returned policy and its nested costs/tie-order arrays are copied; source and target literals are retained. Source code inspection found no trimming, normalization, case folding, or silent truncation.

**Primary-reference review, accessed 2026-10-08:**

- [Wagner and Fischer, The String-to-String Correction Problem (original paper)](https://computingbiology.github.io/docs/wagner1974.pdf), sections 2–4, Theorems 2–4 and Algorithms X/Y, supports the edit operations, prefix recurrence, boundaries and reconstruction argument. The [ACM publication record](https://dl.acm.org/doi/10.1145/321796.321811) confirms the 1974 bibliographic citation. The paper's printed reconstruction order differs from this lab's preference; the guide correctly identifies the lab's tie policy as its own declared choice. The exact count augmentation is justified by the guide's unique-last-edge argument, without attributing that extension to the paper.
- [Unicode UAX #29, revision 49](https://www.unicode.org/reports/tr29/tr29-49.html), introduction and grapheme-cluster discussion, supports distinguishing code points from user-perceived character boundaries. The opened version identifies revision 49, dated 2026-09-01. The lab explicitly performs code-point comparison and makes no grapheme-segmentation conformance claim.
- [Levenshtein's translated historical paper](https://nymity.ch/sybilhunting/pdf/Levenshtein1966a.pdf) was retrievable as a four-page PDF, but the web extraction supplied zero text lines. Its screenshot response exposed only a text placeholder to this continuation. A targeted metadata search returned no results. Accordingly, full historical-paper content verification is **not claimed** here; the guide's algorithm justification rests on the Wagner–Fischer primary paper above.

The guide retains the distinction between minimum edit cost and semantic similarity, and between the exact educational count and constant-time arithmetic. Its complexity discussion states the matrix cell count and the additional cost of retaining candidates and BigInt counts. No unlimited-input or universal constant-time claim was found.

## Interface source review

| Area | Source finding |
|---|---|
| Draft versus applied comparison | The model is called only on explicit comparison/example load. A successful result is assigned only after validation; failed admission retains the prior result and complete drafts. Draft changes visibly mark the retained table and disable comparison download. Restoring exact drafts restores eligibility. |
| Error feedback | Invalid input receives aria-invalid, a role=alert message and programmatic focus. Normal input edits clear the corresponding marker; comparison clears and re-evaluates both. |
| Matrix meaning | The caption and scoped headers define source rows and target columns. Each cell reports cost, path count and exact prefixes. All incoming candidates show predecessor cost, step cost, total, optimal status and predecessor path contribution. |
| Selection and keyboard | Buttons have descriptive labels, aria-pressed selection, one roving tab stop and bounded arrow-key movement. Focus/scroll targets are derived from admitted numeric indices. Source inspection supports these behaviors; it is not a screen-reader or browser execution receipt. |
| Canonical alignment | Revealed forward columns carry source/target indices, literal code-point values, explicit gaps, operation and running cost. Consumed-prefix text and matrix path highlighting share the same record. Empty/empty has a separate zero-column explanation. |
| Representation | Literal content is assigned through textContent. Control/bidi formatting code points are exposed by names or U+ labels in tokens; every nongap alignment token carries its code-point label. Gaps use null and explicit absence labels, not a learner-entered hyphen. |
| Export consistency | The comparison JSON is serialized from the applied complete record before view controls are used. Previous/Next/Show all affect revelation only. The download handler rechecks draft equality. The fixed embedded course is serialized independently once. |
| Offline behavior | The UI builds local Blob downloads and contains no request, storage or comparison-import path. External references are ordinary links. No actual browser offline/download success is inferred from this source inspection. |
| Standalone composition | The builder validates canonical course serialization through the original parser, requires one known import line, rejects executable closing-script tokens and escapes less-than signs in embedded JSON. The generated HTML was already admitted as an exact source-pinned file; this continuation did not rebuild it. |
| Layout | CSS uses bounded grid tracks, min-width:0 cards, internal matrix/alignment overflow, a single-column narrow breakpoint and visible focus styles. Rendered viewport behavior remains the author's separate browser receiving responsibility. |
| Learner handoff | The page, guide and README describe the fixed course download and the unchanged learner preview/Start this deck path. No explorer state rewrites the course. Only the original parser execution is claimed by this independent packet; full learner/browser flow belongs to separate author evidence. |

## Failure preservation and limits

The original first remote write failed with **“Error: __ERROR__: Path validation operation timed out after 10 seconds”**. The predecessor's subsequent owned-directory custody check found zero files, and no freeze or receiving script ran on that failed attempt. `initial-freeze-write-failure.json` is preserved verbatim.

This continuation has made no product edit. It preserves every one of the 27 recovered original files and separately records their hashes in `continuation-custody.json`. The source review uses the already admitted candidate; its independence comes from the original preserved contract-before-candidate evidence, not from a renewed claim of blindness.

Actual browser interaction, physical downloads, rendered responsive behavior, accessibility with assistive technology, and the author's unchanged-learner flow are not independently certified by this packet. Author browser failures and later browser observations must be carried in the author's own evidence with their original provenance. A product change after these candidate pins requires a targeted validity assessment before reusing this acceptance.

### Continuation sealing failure retained

The first documentation write in the original /tmp namespace failed with native OSError [Errno 28] No space left on device. Process 1431707 completed with exit code 1 after 7.39 seconds. Readback at 2026-10-08T20:45:22.484330+00:00 found only a zero-byte source-review.md; README.md, source-review.json and continuation-custody.json had not been created. The 18 original native protected inputs were unchanged. The failed empty file remains in the original namespace, and an exact copy plus the raw error are retained under continuation-failures/. The completed packet is a verified copy under /home/jacob/hamon-levenshtein-independent-68094585a1c2-packet. No source file was removed or replaced.
