## Select a shorter worksheet from an existing checked lesson

Owner: `estate-6e5752b49b6f/production_slice`, coordinated by root under the standing execution mandate. A teacher preparing a short activity currently has to print every question or edit a separate course. Extend the existing handout page with explicit question selection, preserving its questions-only worksheet and separate answer key.

Actual baseline: main `698902f9c9c1d5c5023092b85b3632a7cb7a01ed`, tree `d6d3707b691850af7928299242631534cff89aa8`, 2,915 leaves. `src/course-handout.mjs` blob `1da93ffca03186aca71189541bb85c4b5b972b92` always projects every item; UI blob `7462b6713a1ff7ab8a2462d979719e52005fbdc5` has no selection control.

## Frozen behavior before implementation

- Opening and explicitly using a checked deck initially selects every question. Native labeled checkboxes let the teacher keep any nonempty subset; **Select all** and **Clear selection** support quick preparation.
- Preserve original course question numbering, source question order, all selected prompts/options/transfer wording, and exact attribution/license. Selection order never reorders the source. Show only concepts belonging to included questions, in original concept order.
- Worksheet projection and its complete downloaded HTML omit answer indices, explanations and unselected question content. The separately labeled key includes only the same selected questions and their canonical answers/explanations. This creates a paper activity, not a new validated deck or prerequisite-complete lesson.
- The model gains an optional third `selectedQuestionIds` argument to `createHandout` and `createHandoutDocument`. Omitted selection keeps the complete legacy result/document exactly. An explicit selection is a nonempty dense array of unique existing exact string question IDs. Sparse arrays, duplicate/unknown IDs and wrong types refuse without mutating the deck or caller array. Exact IDs are not trimmed or coerced.
- Empty UI selection is editable but cannot print or save a previous worksheet/key. Both copies and their preview always refer to the current selection. All-selection output remains identical to the old default.
- Successful **Use this deck** resets selection to all of that new deck. Cancellation, unreadable/invalid files and rejected previews preserve the current deck and chosen questions. Editing selection retires any pending read/preview so a late file result cannot replace ongoing preparation.
- Explicit print/save actions retain the existing offline behavior. No upload, automatic storage, question editing, model state, learner session or new assessment claim.

## Bounded fence and ownership

Only `src/course-handout.mjs`, `src/course-handout-ui.mjs`, `handout/index.html`, `handout/handout.css`, regenerated `handout.html`, a narrow README addition, new dedicated selection tests/browser receiver, and unique qualification evidence. The existing builder may be invoked unchanged. Existing deck validator, learner/studio/focus/catalog, courses, builder, original receiving runner and all workflows remain untouched.

Original handout #35/#38 is explicitly source/print-complete in comment6062932246, with later publication closure6063409623. This is a coordinated follow-on, not an assumption that an unfinished owner has abandoned a claim. Fresh full current tree, all169 issue/PR records, complete handout-owner comments and exact handout/worksheet searches found no selection claimant. Of440 native advisory JSON records,21 were unreadable; those scopes remain unknown and were not bypassed or treated as abandoned. No matching claim was found in readable evidence. Existing prerequisite-complete focus #44/#164 remains distinct.

## Native qualification and Actions hold

Preserve the exact all-question baseline before editing; challenge selected-only output/private-data exclusion, original ID/number/order, strict admission, all-selection byte parity, retained file selection and stale reads, actual downloads reopened offline, keyboard/narrow display and real print rendering. Reuse ordinary UID1000 Node22 and an already installed browser only after current admission; no dependencies or browser install.

All five current workflow definitions were read in full. Events are main-push, pull_request and their path filters; none handles issues/comments or non-main branch pushes. The user Actions hold remains in force. Only inert source/evidence custody after current event review is allowed; no PR, merge, dispatch, rerun or workflow edit. Native and unrun hosted gates remain separate.