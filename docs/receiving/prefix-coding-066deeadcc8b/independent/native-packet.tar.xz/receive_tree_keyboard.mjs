#!/usr/bin/env node
// Post-inspection bounded receiving of the explicitly scrollable SVG surface.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const [htmlPath,fixturesPath,out,playwrightPath]=process.argv.slice(2);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const bytes=await fs.readFile(htmlPath),raw=await fs.readFile(fixturesPath),fixture=JSON.parse(raw);
await fs.mkdir(out,{recursive:false});
const report={schema:'recall-prefix-independent-tree-keyboard-v1',argv:process.argv,node:process.version,htmlSha256:sha(bytes),fixtureSha256:sha(raw),cases:[],checks:[],errors:[],requests:[]};
const check=(name,f)=>{try{f();report.checks.push({name,ok:true});}catch(e){report.checks.push({name,ok:false,error:e.stack});}};
const {chromium}=await import(pathToFileURL(playwrightPath));
let browser;
try{
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--no-first-run','--disable-background-networking','--disable-component-update','--disable-sync']});
 report.browser=await browser.version();
 for(const name of ['eight-equal','skew-seven']){
  const item=fixture.cases.find(c=>c.name===name),dir=path.join(out,name);await fs.mkdir(dir);
  const html=path.join(dir,'explorer.html');await fs.writeFile(html,bytes);
  const context=await browser.newContext({viewport:{width:375,height:900}});
  const page=await context.newPage();page.on('pageerror',e=>report.errors.push(e.message));page.on('request',r=>report.requests.push({case:name,url:r.url(),method:r.method()}));
  await context.route('**/*',r=>/^https?:/.test(r.request().url())?r.abort():r.continue());
  const c={name,states:[],keys:[]};report.cases.push(c);
  try{
   await page.goto(pathToFileURL(html).href);
   let count=await page.locator('.symbol-row').count();
   while(count<item.expected.symbols.length){await page.locator('#add-symbol').click();count++;}
   for(let i=0;i<count;i++){await page.locator('#symbol-'+i).fill(item.expected.symbols[i].symbol);await page.locator('#count-'+i).fill(String(item.expected.symbols[i].count));}
   await page.locator('#step-all').click();
   const surface=page.locator('#tree-scroll');await surface.scrollIntoViewIfNeeded();await surface.focus();
   const read=()=>surface.evaluate(e=>({left:e.scrollLeft,top:e.scrollTop,width:e.clientWidth,height:e.clientHeight,scrollWidth:e.scrollWidth,scrollHeight:e.scrollHeight,focused:document.activeElement===e,tabindex:e.tabIndex,aria:e.getAttribute('aria-label'),documentWidth:document.documentElement.scrollWidth,viewport:innerWidth,svg:e.querySelector('svg').outerHTML}));
   let s=await read();c.states.push({phase:'left',...s});
   check(name+':keyboard-surface',()=>{assert(s.focused);assert.equal(s.tabindex,0);assert(/scroll horizontally/i.test(s.aria));assert(s.scrollWidth>s.width);assert(s.documentWidth<=s.viewport+1);});
   await surface.screenshot({path:path.join(dir,'left.png')});
   for(let i=0;i<40&&s.left+s.width<s.scrollWidth-1;i++){
    const before=s.left;await page.keyboard.press('ArrowRight');c.keys.push('ArrowRight');
    await page.waitForFunction(before=>{const e=document.querySelector('#tree-scroll');return e.scrollLeft>before||e.scrollLeft+e.clientWidth>=e.scrollWidth-1;},before,{timeout:1500});
    s=await read();
   }
   c.states.push({phase:'right',...s});
   check(name+':all-horizontal-branches-reachable',()=>{assert(s.left>0);assert(s.left+s.width>=s.scrollWidth-1);assert(s.focused);assert(s.documentWidth<=s.viewport+1);});
   if(s.scrollHeight>s.height){
    const before=s.top;await page.keyboard.press('ArrowDown');c.keys.push('ArrowDown');
    await page.waitForFunction(before=>document.querySelector('#tree-scroll').scrollTop>before,before,{timeout:1500});
    s=await read();c.states.push({phase:'down',...s});check(name+':deepest-tree-scrolls-vertically',()=>assert(s.top>before));
   }
   await surface.screenshot({path:path.join(dir,'right.png')});
   await fs.writeFile(path.join(dir,'saved-dom.html'),await page.content());
   check(name+':delivered-bytes-stable',()=>assert.equal(sha(bytes),report.htmlSha256));
  }catch(e){c.error=e.stack;check(name+':complete',()=>{throw e;});}finally{await context.close();}
 }
 check('no-application-errors',()=>assert.deepEqual(report.errors,[]));
 check('only-two-detached-document-requests',()=>{assert.equal(report.requests.length,2);assert(report.requests.every(r=>r.method==='GET'&&r.url.startsWith('file:')));});
}finally{
 if(browser)await browser.close();
 report.sourceAfterSha256=sha(await fs.readFile(htmlPath));check('original-source-unchanged',()=>assert.equal(report.sourceAfterSha256,report.htmlSha256));
 report.passed=report.checks.filter(x=>x.ok).length;report.failed=report.checks.filter(x=>!x.ok).length;
 await fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({cases:report.cases.length,passed:report.passed,failed:report.failed}));
 process.exitCode=report.failed?1:0;
}
