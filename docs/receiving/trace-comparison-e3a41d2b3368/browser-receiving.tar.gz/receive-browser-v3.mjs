import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import puppeteer from '/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';

const root = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(root, 'receiving-v3');
const fixtures = path.join(out, 'fixtures');
const downloadDir = path.join(out, 'downloads');
for (const p of [out, fixtures, downloadDir]) fs.mkdirSync(p, {recursive:true});
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const pin = p => ({path:p, bytes:fs.statSync(p).size, sha256:sha(fs.readFileSync(p))});
const initialSource = JSON.parse(fs.readFileSync(path.join(root, 'source-manifest.json'), 'utf8'));
const currentSource = JSON.parse(fs.readFileSync(path.join(root, 'current-source-manifest.json'), 'utf8'));
const source = {repository:initialSource.repository, parent:currentSource.parent, tree:currentSource.tree, comparison_intake_parent:initialSource.parent, files:[...initialSource.files,...currentSource.files], qualified_dependencies:currentSource.qualified_dependencies};
for (const f of source.files) assert.equal(pin(path.join(root, f.path)).sha256, f.sha256, f.path);
const deck = JSON.parse(fs.readFileSync(path.join(root, 'baseline/data/deck.json'), 'utf8'));
const groups = [], checks = [], requests = [], pageErrors = [], downloadReceipts = [];
let browser, page, learner, browserClosed = false;
const result = {started_at:new Date().toISOString(), node:process.version, platform:process.platform, arch:process.arch, source, harness:pin(fileURLToPath(import.meta.url)), groups, checks, requests, pageErrors, downloadReceipts};
function ok(condition, label) { checks.push(label); assert.ok(condition, label); }
function eq(actual, expected, label) { checks.push(label); assert.deepEqual(actual, expected, label); }
async function group(name, fn) { const before=checks.length; try { await fn(); groups.push({name,status:'passed',checks:checks.length-before}); } catch(e) { groups.push({name,status:'failed',checks:checks.length-before,error:e.stack}); throw e; } }
function observe(p, label) { p.on('pageerror', e=>pageErrors.push({page:label,error:String(e)}));p.on('request', r=>requests.push({page:label,url:r.url()})); }
const waitPair = () => page.waitForFunction(() => !document.getElementById('trace-comparison').hidden);
const upload = async (side, filename) => { const input=await page.$('#trace-'+side+'-file'); await input.uploadFile(filename); };
const pair = async (left,right) => { await upload('left',left); await upload('right',right); await waitPair(); };
const shownIds = () => page.$$eval('#trace-question-list .question-card', cards=>cards.filter(x=>!x.hidden).map(x=>x.dataset.itemId));
const status = side => page.$eval('#trace-'+side+'-status', n=>n.textContent);
let A, B, aPath, bPath, cdp;
const fixturesPins = new Map();
function fixture(name, text) { const p=path.join(fixtures,name);fs.writeFileSync(p,text);fixturesPins.set(p,pin(p));return p; }
function practiceFor(document,item) {
  const first=document.firstAnswers.find(x=>x.item===item.id);
  if(first.choice===item.answer) return {state:'not-needed',choice:null};
  if(document.practice===null) return {state:'unstarted',choice:null};
  const retry=document.practice.answers.find(x=>x.item===item.id);
  return retry ? {state:'answered',choice:retry.choice} : {state:'pending',choice:null};
}
function oracle(left,right) { return deck.items.map(item=>{
  const l=left.firstAnswers.find(x=>x.item===item.id), r=right.firstAnswers.find(x=>x.item===item.id);
  const lp=practiceFor(left,item),rp=practiceFor(right,item);
  return {id:item.id,item,left:l,right:r,leftPractice:lp,rightPractice:rp,firstChanged:l.choice!==r.choice,practiceChanged:lp.state!==rp.state||lp.choice!==rp.choice};
}); }
async function getRows() { return page.$$eval('#trace-question-list .question-card', cards=>cards.map(card=>({
  id:card.dataset.itemId,prompt:card.querySelector('h3').textContent,
  sides:[...card.querySelectorAll('.answer-side')].map(side=>({heading:side.querySelector('h4').textContent,outcome:side.querySelector('.answer-outcome').textContent,terms:[...side.querySelectorAll('dt')].map(n=>n.textContent),definitions:[...side.querySelectorAll('dd')].map(n=>n.textContent)}))
}))); }
async function realDownload(label) {
  await learner.$eval('#trace-archive-panel', n=>{if(!n.open)n.querySelector('summary').click();});
  const done = new Promise((resolve,reject)=>{
    let started;
    const timer=setTimeout(()=>{cleanup();reject(Error('Native download timed out'));},15000);
    const begin=e=>{started=e;};
    const progress=e=>{if(started&&e.guid===started.guid&&e.state==='completed'){cleanup();resolve({...started,...e});}};
    function cleanup(){clearTimeout(timer);cdp.off('Browser.downloadWillBegin',begin);cdp.off('Browser.downloadProgress',progress);}
    cdp.on('Browser.downloadWillBegin',begin);cdp.on('Browser.downloadProgress',progress);
  });
  await learner.click('#save-trace-button');
  const event=await done;
  const downloaded=path.join(downloadDir,event.guid);
  const bytes=fs.readFileSync(downloaded);
  const file=fixture(label+'.json',bytes);
  const document=JSON.parse(bytes);
  downloadReceipts.push({label,guid:event.guid,suggestedFilename:event.suggestedFilename,totalBytes:event.totalBytes,receivedBytes:event.receivedBytes,download:pin(downloaded),copy:pin(file)});
  return {file,document};
}
async function session(choiceIndices, practiceMode) {
  await learner.click('#start-button');
  for(let n=0;n<deck.items.length;n++){
    await learner.waitForSelector('#session-content [data-choice]');
    const prompt=await learner.$eval('#session-content h2', n=>n.textContent);
    const index=deck.items.findIndex(item=>item.prompt===prompt);
    assert.notEqual(index,-1,'native learner prompt exists in pinned deck');
    await learner.click('#session-content [data-choice="'+choiceIndices[index]+'"]');
    await learner.click('#next-button');
  }
  await learner.waitForSelector('#reset-button');
  if(practiceMode){
    await learner.click('#practice-button');
    const count=practiceMode==='partial'?1:choiceIndices.filter((choice,i)=>choice!==deck.items[i].answer).length;
    for(let n=0;n<count;n++){
      const prompt=await learner.$eval('#session-content h2', n=>n.textContent);
      const item=deck.items.find(item=>item.prompt===prompt);
      await learner.click('[data-practice-choice="'+(practiceMode==='partial'?(item.answer+2)%item.options.length:item.answer)+'"]');
      if(practiceMode==='partial') await learner.click('#back-to-review');
      else await learner.click('#practice-next');
    }
    await learner.waitForSelector('#reset-button');
  }
}
try {
  browser=await puppeteer.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,userDataDir:path.join(out,'chrome-profile')});
  result.browser=await browser.version();result.user_agent=await browser.userAgent();result.browser_pid=browser.process()?.pid;
  cdp=await browser.target().createCDPSession();
  await cdp.send('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath:downloadDir,eventsEnabled:true});
  learner=await browser.newPage();observe(learner,'unchanged learner');await learner.setViewport({width:1280,height:900,deviceScaleFactor:1});
  await learner.goto(pathToFileURL(path.join(root,'current-main/demo.html')).href,{waitUntil:'load'});
  await group('current e49aee89 learner saves two completed traces with separate practice',async()=>{
    ok(await learner.$('#trace-file'),'existing single-trace restore control exists');
    eq(await learner.$('#trace-left-file'),null,'baseline has no two-file comparison control');
    const indicesA=[0,1,1,0,1,1].map((n,i)=>(deck.items[i].answer+n)%deck.items[i].options.length);
    const indicesB=[0,0,2,1,1,0].map((n,i)=>(deck.items[i].answer+n)%deck.items[i].options.length);
    await session(indicesA,'partial');({file:aPath,document:A}=await realDownload('trace-a'));
    await learner.click('#reset-button');
    await session(indicesB,'complete');({file:bPath,document:B}=await realDownload('trace-b'));
    eq(A.firstAnswers.length,deck.items.length,'Trace A complete');
    eq(B.firstAnswers.length,deck.items.length,'Trace B complete');
    eq(A.firstAnswers.map(x=>[x.item,x.choice]).sort(),deck.items.map((item,i)=>[item.id,indicesA[i]]).sort(),'Trace A canonical choices saved by native learner');
    eq(B.firstAnswers.map(x=>[x.item,x.choice]).sort(),deck.items.map((item,i)=>[item.id,indicesB[i]]).sort(),'Trace B canonical choices saved by native learner');
    eq(A.practice.answers.length,1,'Trace A one actual retry');
    eq(B.practice.answers.length,3,'Trace B completed three actual retries');
    eq(A.deck,JSON.parse(fs.readFileSync(path.join(root,'baseline/data/deck.json'),'utf8')),'legacy raw course identity preserved in actual download');
    eq(A.deck,B.deck,'two learner downloads retain identical raw course');
  });
  page=await browser.newPage();observe(page,'comparison');await page.setViewport({width:1280,height:900,deviceScaleFactor:1});
  await page.goto(pathToFileURL(path.join(root,'candidate/compare-traces.html')).href,{waitUntil:'load'});
  const expected=oracle(A,B);
  await group('current and previously saved traces retain answer identity',async()=>{
    await pair(aPath,bPath);
    const rows=await getRows();
    eq(rows.map(row=>row.id),deck.items.map(item=>item.id),'current consumer comparison has canonical question order');
    for(const [i,row] of rows.entries())for(const [j,doc] of [A,B].entries()){
      const item=deck.items[i],answer=doc.firstAnswers.find(a=>a.item===item.id);
      eq(row.sides[j].definitions[0],item.options[answer.choice],item.id+' current side '+j+' exact first answer');
    }
    eq(await page.$eval('#trace-change-count',n=>n.textContent),'4 of 6 first answers differ. 5 practice records differ.','current learner archive pair retains separate difference counts');
    const priorPath=path.join(root,'receiving-v1/browser-result.json');
    const prior=JSON.parse(fs.readFileSync(priorPath,'utf8'));result.prior_browser_receipt=pin(priorPath);
    for(const f of prior.selected_files)eq(pin(f.path).sha256,f.sha256,'original browser fixture unchanged '+path.basename(f.path));
    for(const f of prior.downloadReceipts)eq(pin(f.download.path).sha256,f.download.sha256,'original downloaded trace unchanged '+f.label);
    const oldA=path.join(root,'receiving-v1/fixtures/trace-a.json');
    await pair(oldA,bPath);
    eq(await page.$eval('#trace-change-count',n=>n.textContent),'4 of 6 first answers differ. 5 practice records differ.','previous c00bd1 learner archive compares with current e49aee89 learner archive');
    await upload('left',aPath);await waitPair();
    await learner.type('#application-reflection','Current learner note <literal> stays here.');
    ok(await learner.$('#lesson-archive'),'current learner retains unfinished-lesson controls');
    await page.bringToFront();
  });
  await group('narrow viewport and keyboard controls preserve readable comparison',async()=>{
    await page.setViewport({width:390,height:844,deviceScaleFactor:1});
    await page.evaluate(()=>window.scrollTo(0,0));
    eq(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1),true,'390px page has no horizontal overflow');
    eq(await page.$eval('.files',n=>getComputedStyle(n).gridTemplateColumns.split(' ').length),1,'file cards stack on narrow viewport');
    eq(await page.$eval('.answer-grid',n=>getComputedStyle(n).gridTemplateColumns.split(' ').length),1,'answers stack on narrow viewport');
    await page.screenshot({path:path.join(out,'mobile-top.png'),fullPage:false});
    await page.$eval('#trace-comparison',n=>n.scrollIntoView());
    await page.screenshot({path:path.join(out,'mobile-comparison.png'),fullPage:false});
    await page.focus('#trace-difference-filter');await page.keyboard.press('d');
    eq(await page.$eval('#trace-difference-filter',n=>n.value),'first','keyboard changes difference selection');
    eq(await shownIds(),expected.filter(x=>x.firstChanged).map(x=>x.id),'keyboard selection applies filter');
    const visibleSummary='#trace-question-list .question-card:not([hidden]) .answer-detail summary';
    await page.focus(visibleSummary);await page.keyboard.press('Enter');
    ok(await page.$eval(visibleSummary,n=>n.parentElement.open),'explanation opens with keyboard');
    await page.focus('#trace-reset-filters');await page.keyboard.press('Enter');
    eq(await shownIds(),deck.items.map(x=>x.id),'keyboard reset works at narrow viewport');
  });
  await group('print view retains filenames, selected questions and filter context',async()=>{
    await page.setViewport({width:1280,height:900,deviceScaleFactor:1});
    const chosen=deck.concepts[0];await page.select('#trace-concept-filter',chosen);
    await page.evaluate(()=>{window.__prints=0;window.print=()=>{window.__prints++;};});
    await page.click('#trace-print');eq(await page.evaluate(()=>window.__prints),1,'print button reaches browser print boundary once');
    await page.emulateMediaType('print');
    eq(await page.$eval('#trace-left-file',n=>getComputedStyle(n).display),'none','print hides file picker');
    eq(await page.$eval('.filters',n=>getComputedStyle(n).display),'none','print hides interactive filters');
    ok(await page.$eval('#trace-left-name',n=>n.getBoundingClientRect().height>0&&n.textContent==='trace-a.json'),'print retains Trace A filename');
    ok(await page.$eval('#trace-right-name',n=>n.getBoundingClientRect().height>0&&n.textContent==='trace-b.json'),'print retains Trace B filename');
    eq(await shownIds(),expected.filter(x=>x.item.concept===chosen).map(x=>x.id),'print retains selected question subset');
    ok((await page.$eval('#trace-visible-count',n=>n.textContent)).includes('concept: '+chosen),'print explains active concept filter');
    ok(await page.$eval('#trace-course-attribution',n=>n.getBoundingClientRect().height>0),'print retains supplied source attribution');
    await page.evaluate(()=>window.scrollTo(0,0));
    await page.screenshot({path:path.join(out,'print-view.png'),fullPage:true});
    await page.pdf({path:path.join(out,'filtered-comparison.pdf'),format:'A4',printBackground:true});
    await page.emulateMediaType('screen');
  });
  await group('comparison leaves source files and original learner session unchanged',async()=>{
    eq(await learner.$eval('#first-try-summary',n=>n.textContent).then(text=>text.match(/You made (\d+) of (\d+)/)?.slice(1)),['3','6'],'original learner Trace B first-answer summary unchanged by comparison');
    eq(await learner.$eval('#practice-status',n=>n.textContent),'You answered 3 of 3 correctly on retry.','original learner practice unchanged by comparison');
    eq(await learner.$eval('#application-reflection',n=>n.value),'Current learner note <literal> stays here.','current learner reflection unchanged by comparison');
    for(const f of source.files)eq(pin(path.join(root,f.path)).sha256,f.sha256,'source unchanged '+f.path);
    for(const [p,original] of fixturesPins)eq(pin(p).sha256,original.sha256,'selected fixture unchanged '+path.basename(p));
    for(const receipt of downloadReceipts)eq(pin(receipt.download.path).sha256,receipt.download.sha256,'actual downloaded original unchanged '+receipt.label);
    eq(pageErrors,[],'no application page errors');
    eq(requests.filter(x=>!x.url.startsWith('file:')&&!x.url.startsWith('blob:')),[],'observed application requests are local files or local download blobs');
  });
  result.status='passed';
}catch(e){result.status='failed';result.error=e.stack;try{if(page&&!page.isClosed())await page.screenshot({path:path.join(out,'failure.png'),fullPage:false});}catch{}process.exitCode=1;}
finally{
  if(browser){try{await browser.close();browserClosed=true;}catch(e){result.browser_close_error=String(e);process.exitCode=1;}}
  result.browser_closed=browserClosed;result.finished_at=new Date().toISOString();result.total_checks=checks.length;result.passed_groups=groups.filter(x=>x.status==='passed').length;
  result.selected_files=[...fixturesPins.values()];
  result.source_unchanged=source.files.every(f=>pin(path.join(root,f.path)).sha256===f.sha256);
  fs.writeFileSync(path.join(out,'browser-result.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({status:result.status,groups:groups.map(x=>({name:x.name,status:x.status,checks:x.checks})),total_checks:result.total_checks,browser_closed:browserClosed,source_unchanged:result.source_unchanged,error:result.error,receipt:path.join(out,'browser-result.json')}));
}
