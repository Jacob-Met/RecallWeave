#!/usr/bin/env python3
"""Recompute the completed model/course receiving foundation from preserved bytes."""
from pathlib import Path, PurePosixPath
import json, hashlib, tarfile, io, gzip, types, sys

ROOT_PIN='6f920f177ae90a09958146d41612a0e83f52702f'
TREE_PIN='c2be5240d1ffa17c7e66b3fb8fe74aa334ec10b2'
NATIVE_ROOT='/Users/me/recall-prefix-review-066deeadcc8b/'
def need(ok,message):
    if not ok:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def git_blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def regular_tar(data):
    files={}
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:*') as archive:
        for member in archive.getmembers():
            p=PurePosixPath(member.name)
            need(member.isfile() and not p.is_absolute() and '..' not in p.parts,'archive member type/path')
            need(member.name not in files,'duplicate archive path')
            b=archive.extractfile(member).read()
            need(len(b)==member.size,'archive member size')
            files[member.name]=b
    return files
class MemoryPath:
    def __init__(self,files,name=''):self.files=files;self.name=PurePosixPath(name)
    def __truediv__(self,name):return MemoryPath(self.files,self.name/name)
    @property
    def parent(self):return MemoryPath(self.files,self.name.parent)
    def read_bytes(self):return self.files[str(self.name)]
    def read_text(self):return self.read_bytes().decode()
    def __str__(self):return str(self.name)
def module(files,name):
    scope={'__name__':'independent_'+name.replace('.','_'),'__file__':name}
    exec(compile(files[name],name,'exec'),scope)
    return scope
def logical_files(root):
    files={p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()}
    packet=files['model-component-packet.tar.xz']
    need(len(packet)==326776 and sha(packet)=='b59f7e3ac3377e7962575c29d77a9f8d999385532f24fe10cce9acf0c8f75aa2','component checkpoint identity')
    nested=regular_tar(packet);manifest=json.loads(nested['component-manifest.json'])
    need(len(nested)==36 and len(manifest['files'])==35,'component checkpoint counts')
    for row in manifest['files']:
        b=nested[row['path']]
        need(len(b)==row['bytes'] and sha(b)==row['sha256'],'component checkpoint artifact')
    for name,data in nested.items():
        if name=='component-manifest.json':continue
        need(name not in files or files[name]==data,'changed component checkpoint duplicate')
        files[name]=data
    return files
def verify(files):
    data=lambda name:files[name]
    doc=lambda name:json.loads(data(name))
    commit=doc('evidence/canonical-commit.json');tree=doc('evidence/canonical-tree.json')
    need(commit['sha']==ROOT_PIN and commit['tree']['sha']==TREE_PIN and tree['sha']==TREE_PIN,'canonical parent identity')
    leaves={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    need(len(leaves)==1179 and not tree.get('truncated'),'complete parent tree')
    need(not any(PurePosixPath(p).name=='AGENTS.md' for p in leaves),'unexpected source instructions')
    baseline=doc('evidence/baseline-source-manifest.json')
    need(len(baseline['files'])==16,'baseline closure size')
    for row in baseline['files']:
        b=data('baseline/'+row['path']);leaf=leaves[row['path']]
        need(len(b)==row['bytes']==leaf['size'] and sha(b)==row['sha256'] and git_blob(b)==row['git_blob']==leaf['sha'],'canonical baseline source')
        need(row['mode']==leaf['mode']=='100644','baseline mode')
    for missing in ['src/prefix-coding.mjs','courses/prefix-coding.json','courses/prefix-coding.md','courses/prefix-coding-explorer.html']:
        need(missing not in leaves,'baseline already has new capability')
    demo=data('canonical-demo.html');builder=data('delivery-source/tools/make_demo.py')
    need(git_blob(demo)==leaves['demo.html']['sha'] and git_blob(builder)==leaves['tools/make_demo.py']['sha'],'direct canonical demo/build source')
    need(data('delivery-source/demo.html')==demo,'original builder exact demo output')
    need(doc('evidence/delivery-reconstruction.json')['exact_canonical_reconstruction'] is True,'rebuild receipt')
    fixture_raw=gzip.decompress(data('oracle-fixtures.json.gz'))
    need(sha(fixture_raw)=='c8b7e50a7c90e0bada790b349862042405e513dc21e09aaadf2a080a777ee913','oracle fixture identity')
    need(sha(data('oracle.py'))=='01b04c69436f9e6d18c7e408faeaf47a98b4d413f8ac5b80857ad4280c86ec5f','oracle program identity')
    oracle=module(files,'oracle.py')
    regenerated=(json.dumps(oracle['make_fixture'](),ensure_ascii=True,separators=(',',':'))+'\n').encode()
    need(regenerated==fixture_raw,'full exhaustive fixture regeneration')
    fixture=json.loads(fixture_raw);model_verifier=module(files,'verify_model_evidence.py')
    model_outcomes=[]
    pins={'v1':'d6973ac2985b6a093d805477172ada5ba9877e80248712bca5f07294bceda9b5','v2':'b47ae48d03d38e8e2996d7a4228c225ece3938d62b29d9438c6866ed10034b80'}
    for version,pin in pins.items():
        report=doc('model-'+version+'-results/report.json')
        need(sha(data('model-'+version+'/prefix-coding.mjs'))==pin==report['sourceBeforeSha256']==report['sourceAfterSha256'],'model bytes/request binding')
        need(report['fixtureSha256']==sha(fixture_raw),'actual model fixture binding')
        model_outcomes.append({'version':version,'source_sha256':pin,**model_verifier['verify_model_record'](report,fixture)})
    first=doc('model-v1-results/report.json');second=doc('model-v2-results/report.json')
    for key in ['cases','invalidModels','protocolCases','negativeControls','checks']:
        need(first[key]==second[key],'dense source successor changed results')
    old=data('model-v1/prefix-coding.mjs').decode();new=data('model-v2/prefix-coding.mjs').decode()
    guards=["  for (let i = 0; i < rows.length; i++) {\n    if (!Object.prototype.hasOwnProperty.call(rows, i)) fail('Every symbol row must be present.');\n  }\n",
            "  for (let i = 0; i < symbols.length; i++) {\n    if (!Object.prototype.hasOwnProperty.call(symbols, i)) fail('Every message symbol must be present.');\n  }\n"]
    for guard in guards:
        need(new.count(guard)==1,'exact dense guard')
        new=new.replace(guard,'',1)
    need(new==old,'two guards reconstruct v1 source')
    sparse1=doc('model-v1-sparse.json');sparse2=doc('model-v2-sparse.json')
    names=['sparse-model-rows','one-hole-message','known-hole-known-message']
    for record,version,wanted in [(sparse1,'v1',False),(sparse2,'v2',True)]:
        need(record['sha256']==pins[version] and [x['name'] for x in record['cases']]==names,'sparse source/cohort identity')
        need(all(x['refused'] is wanted for x in record['cases']),'sparse result')
    need(sparse1['cases'][1]['returned']=={'bits':'','symbols':[None],'segments':[None]},'original silent omission preserved')
    need(sparse1['cases'][2]['returned']['bits']=='01' and sparse1['cases'][2]['returned']['symbols']==['A',None,'B'],'original partial omission preserved')
    learned=module(files,'verify_learner_evidence.py');mem=MemoryPath(files)
    learner_outcomes=[]
    for label,report,course,base in [
      ('baseline','baseline-learner/report.json','baseline/courses/binary-search.json',True),
      ('new-course','course-v1-learner/report.json','course-v1/courses/prefix-coding.json',False)]:
        learner_outcomes.append({'cohort':label,**learned['verify'](mem,mem/report,mem/course,base)})
    course_pins={'courses/prefix-coding.json':'611e3eac54d2ecc05d4ee3ef5123a3c7d71934c61612a155b6306a5cba249e53','courses/prefix-coding.md':'afcf472d9d3658c5425f0248c8f1d5e26d1613848106336b20d4ac84df052452','tests/prefix-coding-course.test.mjs':'a79053ccf4f885d3872d069f1a5c116471c5a3f695fffddbd635941ccf60a6c2'}
    for name,pin in course_pins.items():need(sha(data('course-v1/'+name))==pin,'accepted course source')
    answers=doc('course-independent-answers.json');course=doc('course-v1/courses/prefix-coding.json')
    need(answers['answers_and_explanations_inspected'] is False and len(answers['answers'])==12,'independent masked-answer record')
    by_id={x['id']:x for x in course['items']}
    for answer in answers['answers']:
        item=by_id[answer['id']]
        need(answer['selected_index']==item['answer'] and answer['selected_text']==item['options'][item['answer']] and bool(answer['reason']),'independent answer comparison')
    process_expected=[
      ('baseline-model',1,'receive_model.mjs'),('baseline-learner',0,'receive_learner.mjs'),
      ('model-v1',0,'receive_model.mjs'),('model-v1-sparse',1,'receive_sparse.mjs'),
      ('model-v2',0,'receive_model.mjs'),('model-v2-sparse',0,'receive_sparse.mjs'),
      ('course-v1-learner',0,'receive_learner.mjs')]
    for name,code,driver in process_expected:
        record=doc('evidence/'+name+'-process.json')
        need(record['returncode']==code and record['argv'][0]=='/opt/homebrew/Cellar/node/26.3.0/bin/node','actual receiver process outcome')
        need(record['argv'][1]==NATIVE_ROOT+driver and record['elapsed_s']>=0,'actual receiver command')
        for kind in ['stdout','stderr']:
            out=record[kind];need(out['path'].startswith(NATIVE_ROOT),'actual output path')
            b=data(out['path'][len(NATIVE_ROOT):])
            need(len(b)==out['bytes'] and sha(b)==out['sha256'],'actual process captured output')
    absent=doc('baseline-model/report.json')
    need(not absent['cases'] and absent['failedChecks']==1 and 'ENOENT' in absent['harnessError'],'actual absent model negative')
    need(sha(data('receive_model.mjs'))=='5e3cdb00325e3a72e27526e626e5d2a73a18aab775416533e03f758c57746ac1','frozen model driver')
    need(sha(data('receive_learner.mjs'))=='7dc1db53236684778b828be01ec065004998ecfcd8a66b1e531897b60eb5abcd','frozen learner driver')
    need(sha(data('receive_sparse.mjs'))=='0102eb4e794943e6c10e44eb6b9540969c6c73061697c7a3b0b1193427985e2a','sparse replay driver')
    return {'schema':'recall-prefix-independent-foundation-verification-v1','baseline_commit':ROOT_PIN,'baseline_tree':TREE_PIN,
      'canonical_leaves':1179,'canonical_learner_files':16,'canonical_demo_reconstruction':True,
      'model_runs':model_outcomes,'sparse_v1_refusals':0,'sparse_v2_refusals':3,'source_successor_only_two_guards':True,
      'learner_runs':learner_outcomes,'independently_solved_course_answers':12,'actual_receiver_process_records':7,
      'application_execution_during_verification':False,'complete_explorer_acceptance':False}
def main():
    root=Path(sys.argv[1]);result=verify(logical_files(root));b=(json.dumps(result,indent=2)+'\n').encode()
    Path(sys.argv[2]).write_bytes(b);print(b.decode())
if __name__=='__main__':main()
