import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const sha=x=>createHash('sha256').update(x).digest('hex');
const raw=readFileSync(new URL('./rounding-oracles.json',import.meta.url));
const expected=JSON.parse(raw);
const source=process.env.UNITS_MODEL_PATH;
assert.equal(sha(readFileSync(source)),process.env.UNITS_MODEL_SHA256);
const {convertUnits}=await import(pathToFileURL(source).href);
const cases=expected.cases.map(c=>{
 try{
  const actual=convertUnits(c.value,c.from,c.to);
  for(const field of ['factor','result']){
   assert.equal(actual[field].numerator,c[field].numerator);
   assert.equal(actual[field].denominator,c[field].denominator);
  }
  assert.equal(Number(actual.display.text),Number(c.displayNumericalValue));
  assert.equal(actual.display.rounded,c.rounded);
  assert.equal(actual.display.significant_digits,12);
  return {id:c.id,pass:true,expected:c,actual:actual.display};
 }catch(error){return {id:c.id,pass:false,expected:c,error:{name:error.name,message:error.message}};}
});
const receipt={sourceSHA256:sha(readFileSync(source)),oracleSHA256:sha(raw),runnerSHA256:sha(readFileSync(fileURLToPath(import.meta.url))),node:process.version,cases};
writeFileSync(process.env.UNITS_PROBE_OUTPUT,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({passed:cases.filter(c=>c.pass).length,failed:cases.filter(c=>!c.pass).length}));
process.exitCode=cases.every(c=>c.pass)?0:1;
