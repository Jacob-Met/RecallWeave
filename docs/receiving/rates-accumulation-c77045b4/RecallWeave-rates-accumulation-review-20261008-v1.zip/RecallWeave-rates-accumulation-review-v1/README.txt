RecallWeave · Rates and accumulation
Offline review v1 · 8 October 2026

OPEN THE EXPERIENCE

1. Extract this entire ZIP to a folder. Open the extracted files, not the
   archive preview.
2. Open courses/rates-accumulation-explorer.html in your browser.
3. Try “Out and back”: inspect 4 seconds and then 8 seconds. Compare signed
   displacement with total distance. You can edit the points and apply a new
   curve, or choose one of the other worked examples.
4. For the twelve-question lesson, use the explorer's link to RecallWeave.
   In the learner, choose courses/rates-accumulation.json under “Bring your
   own lesson”, inspect its preview, then select “Start this deck”.
   You can also download the same lesson file from the explorer first.
5. Keep a calculation or study notes through the explicit download buttons.
   courses/rates-accumulation.md contains the worked guide and source credit.

No installation, server, internet connection or account is required.
Keep demo.html beside the courses folder so the explorer's learner link works.
The learner initially shows its bundled cellular-energy lesson until you
explicitly select and start the rates course. Work stays in the current tab;
download anything you want to keep before closing or refreshing it.

WHAT THIS MODEL COVERS

These are authored mathematical velocity curves, not measurements. The model
connects 2–8 points with straight lines, with whole-second point times through
120 seconds and velocities from -50 to 50 m/s at one-decimal precision.
Inspection uses tenths of a second. Calculation records retain exact fractions;
the accumulation graph samples at 0.1-second spacing. A corner can have unequal
one-sided acceleration, and average velocity is undefined at zero duration.
The exercise and its implementation checks do not establish learning efficacy.

SOURCE SNAPSHOT

Version: recallweave-rates-accumulation-review/1
Content source: 9207da3fe40a5376886c656d68b073815a563f8c
https://github.com/Jacob-Met/RecallWeave/tree/9207da3fe40a5376886c656d68b073815a563f8c
Review and receiving: https://github.com/Jacob-Met/RecallWeave/pull/92

The four product files are exact copies from that source. This review bundle
adds only these opening instructions. Original attribution and permission
statements remain in the course, guide and learner.
