import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath,pathToFileURL} from 'node:url';import puppeteer from '/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
const root=path.dirname(fileURLToPath(import.meta.url));const out=path.join(root,'keyboard-diagnostic');fs.mkdirSync(out,{recursive:true});
let browser;const result={started_at:new Date().toISOString(),sequences:[]};
try{
browser=await puppeteer.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,userDataDir:path.join(out,'chrome-profile')});result.browser=await browser.version();
const page=await browser.newPage();await page.goto(pathToFileURL(path.join(root,'candidate/compare-traces.html')).href);
for(const [side,name] of [['left','trace-a.json'],['right','trace-b.json']])await (await page.$('#trace-'+side+'-file')).uploadFile(path.join(root,'receiving-v1/fixtures',name));
await page.waitForFunction(()=>!document.getElementById('trace-comparison').hidden);await page.bringToFront();
await page.evaluate(()=>{const native=document.getElementById('trace-difference-filter').cloneNode(true);native.id='receiver-native-control';document.body.prepend(native);window.__keyEvents=[];for(const id of ['trace-difference-filter','receiver-native-control']){for(const type of ['keydown','keyup','change','input'])document.getElementById(id).addEventListener(type,e=>window.__keyEvents.push({id,type,key:e.key,value:e.target.value,trusted:e.isTrusted}));}});
const sequences=[
{name:'arrowdown-enter-delayed',keys:['ArrowDown','Enter']},
{name:'arrowdown-arrowdown-enter-delayed',keys:['ArrowDown','ArrowDown','Enter']},
{name:'space-arrowdown-enter-delayed',keys:['Space','ArrowDown','Enter']},
{name:'typeahead-d',keys:['d']},
{name:'typeahead-full',text:'Different first answers'}
];
for(const sequence of sequences){for(const id of ['receiver-native-control','trace-difference-filter']){
await page.keyboard.press('Escape');await page.select('#'+id,'all');await page.focus('#'+id);
await page.evaluate(()=>{window.__keyEvents=[];});
if(sequence.text)await page.keyboard.type(sequence.text,{delay:80});
else for(const key of sequence.keys){await page.keyboard.press(key,{delay:150});await new Promise(resolve=>setTimeout(resolve,150));}
const state=await page.evaluate(id=>({value:document.getElementById(id).value,active:document.activeElement.id,hasFocus:document.hasFocus(),visibility:document.visibilityState,events:window.__keyEvents}),id);
result.sequences.push({sequence:sequence.name,id,...state});
}}
result.status='completed';
}catch(e){result.status='failed';result.error=e.stack;process.exitCode=1;}finally{if(browser)await browser.close();result.browser_closed=true;result.finished_at=new Date().toISOString();result.harness_sha256=crypto.createHash('sha256').update(fs.readFileSync(fileURLToPath(import.meta.url))).digest('hex');fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));}
