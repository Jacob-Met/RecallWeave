## Learner outcome and ownership

Owner: **chatgpt-astra-bd1abdb2f886-20261008 / estate_source**, under Jacob's continuing autonomous estate mandate. Root retains independent physics/content review; native browser receiving will use a separate authored contract.

Add an original introductory **Spring energy: motion, force and conservation** lesson and an offline phase explorer. A learner can predict a turning point or equilibrium crossing, then inspect the signed position, velocity, acceleration and restoring force beside the kinetic, spring-potential and total energies. Changing mass, stiffness or amplitude makes the different period/energy dependencies visible.

Current inspected source is `04470d482c7c743b8bce913055e33640a9b53681`, tree `b1f8b2de4c764d01bb1f51b1b915858b69670d16`. The complete tree has 1,976 leaves and no AGENTS.md, CODEX_HANDOFF.md or HALT.json. Current project issues/PRs, supplied-course paths and scoped spring/oscillator searches, including the HAMON coordination issue search, reveal no overlapping owner.

## Exact additive fence

Only new `spring-energy` source paths: course JSON and worked guide, standalone lab HTML, model/UI ES modules, HTML template, bounded standalone builder, focused model/course/build tests, and this contribution's unique receiving evidence. An additive README course link may be composed after the final shared-file recheck. Existing learner, deck codec, selector, review/practice, notes, archives, catalog, other courses, their builders/tests and active content owners stay exact.

Use the project's existing Node ES modules, built-in test runner and self-contained offline HTML pattern. The native worktree will be isolated at `/home/jacob/recallweave-spring-energy-bd1abdb2f886-20261008`; the actual ThinkPad preflight has Node 22.22.1, Git 2.53.0 and available storage. No shared runtime, installed learner or another owner's worktree is changed.

## Model and interaction contract

The model is one ideal horizontal Hooke-law spring with a positive point mass, a massless spring, no friction, no drive and a fixed equilibrium. The block starts at positive maximum displacement and is released from rest. The phase control traverses one cycle; it is an analytical phase inspection, not a measured recording or a numerical time integrator.

Bounded finite inputs will be explicit: mass 0.1–10 kg, stiffness 1–200 N/m, amplitude 0–0.5 m, and phase 0–360 degrees. Zero amplitude is a valid resting system with zero energies; the model's natural period remains defined. Strict numeric admission refuses empty, malformed and nonfinite text before replacing an accepted view. Inputs apply together, and failed edits retain a clearly identified prior accepted experiment.

Display the phase/time relation, physical units, force direction and energy exchange without relying on color alone. Provide canonical phase shortcuts, a real keyboard-operable phase slider, a responsive spring diagram, readable numerical values and a complete-cycle table. Export the applied experiment and exact checked lesson bytes through explicit downloads. The course enters the existing preview → explicit Start → learning/review → separate practice → study-notes flow.

Physics references checked before drafting: [MIT 8.01SC, Chapter 23, sections 23.2–23.3](https://ocw.mit.edu/courses/8-01sc-classical-mechanics-fall-2016/mit8_01scs22_chapter23.pdf). All question wording, distractors, transfer exercises, worked values and lab presentation will be original.

## Receiving before integration

Freeze the interaction and independent analytical controls before candidate execution. Blind-answer review precedes disclosure of the authored key. Qualify force and acceleration signs, quadrant/turning/equilibrium states, mass/stiffness/amplitude scaling, energy conservation, the zero-amplitude case, refused inputs and exact export provenance. Run the maintained native suite and builder parity; receive the actual standalone lab at desktop and phone widths with native pointer/keyboard actions, actual downloaded files and the real current learner importer. Retain first failures and any receiver corrections separately.

Independent review, exact-head hosted gates and complete parent/payload readback precede source integration. This is an educational source contribution; it makes no claim about a real apparatus, learning efficacy or installed deployment.

Publication state: create_issue was rejected by GitHub's secondary content limit at 2026-10-08 16:56:27 UTC. This is an isolated source draft only; no public issue or native-global lease is asserted.
