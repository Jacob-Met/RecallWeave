import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)),parse=n=>JSON.parse(fs.readFileSync(path.join(root,n),'utf8').replace(/^\uFEFF/,''));
function pin(p){const b=fs.readFileSync(p),s=fs.statSync(p,{bigint:true});return {bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),git:crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex'),mtime_ns:s.mtimeNs.toString()};}
function exact(p,s){const x=pin(p);for(const k of ['bytes','sha256','git','mtime_ns'])if(s[k]!==undefined)assert.equal(x[k],s[k],p+' '+k);return x;}
const started=new Date().toISOString(),input=parse('ADMISSION-INPUT.json'),literals=parse('LITERAL-GOLD.json'),received=[];
assert.equal(input.canonicalSourceApiBound,true);assert.equal(input.originalManifest.length,26);
exact(input.node.path,input.node);exact(input.edge.path,input.edge);for(const d of input.donor.files)exact(path.join(input.donor.root,d.path),d);
exact(input.offer.contract.path,input.offer.contract);exact(input.offer.manifest.path,input.offer.manifest);
fs.mkdirSync(path.join(root,'original'),{recursive:false});
for(const f of input.originalManifest){
 const source=path.join(input.offer.originalRoot,f.path),before=exact(source,f),destination=path.join(root,'original',f.path);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.copyFileSync(source,destination,fs.constants.COPYFILE_EXCL);
 const receiver=exact(destination,f);assert.deepEqual(pin(source),before);received.push({path:f.path,mode:input.sourceModes.find(x=>x.path===f.path).mode,source:before,receiver});
}
fs.mkdirSync(path.join(root,'reused-original'),{recursive:false});const reused=[];
for(const f of input.reuse){const src=path.join(input.reuseRoot,f.name);exact(src,f);const destination=path.join(root,'reused-original',f.name);fs.copyFileSync(src,destination,fs.constants.COPYFILE_EXCL);reused.push({name:f.name,original:f,receiver:pin(destination)});}
const prior=JSON.parse(fs.readFileSync(path.join(root,'reused-original/ORIGINAL-FREEZE.json'),'utf8'));
assert.equal(prior.status,'passed');assert.equal(prior.candidateSourceRead,false);
for(const p of prior.source){const current=received.find(x=>x.path===p.path);assert.ok(current);assert.equal(current.receiver.sha256,p.receiver.sha256);assert.equal(current.receiver.git,p.receiver.git);}
const b=JSON.parse(fs.readFileSync(path.join(root,'reused-original/ORIGINAL-BROWSER-r1.json'),'utf8'));
const bx=JSON.parse(fs.readFileSync(path.join(root,'reused-original/ORIGINAL-BROWSER-r1-EXIT.json'),'utf8'));
const correction=JSON.parse(fs.readFileSync(path.join(root,'reused-original/ORIGINAL-OBSERVATION-CORRECTION.json'),'utf8'));
assert.equal(b.status,'passed');assert.equal(bx.exitCode,0);assert.equal(b.browserClosed,true);assert.equal(correction.DOMComparisonIsVacuous,true);assert.ok(correction.checks.every(x=>x.postPracticeDownloadExact));
const parser=await import(pathToFileURL(path.join(root,'original/src/deck.mjs')).href),raw=fs.readFileSync(path.join(root,'original/courses/mendelian-inheritance.json'),'utf8'),obj=JSON.parse(raw),deck=parser.parseDeck(raw);
assert.equal(deck.items.length,12);assert.deepEqual(deck,obj);assert.deepEqual(parser.parseDeck(parser.serializeDeck(deck)),obj);
function frozen(x){if(x&&typeof x==='object'){assert.equal(Object.isFrozen(x),true);Object.values(x).forEach(frozen);}}frozen(deck);
const caller=structuredClone(obj),copied=parser.validateDeck(caller);caller.items[0].options[0]='changed outside accepted snapshot';caller.concepts[0]='changed outside accepted snapshot';assert.deepEqual(copied,obj);
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b),rat=(a,b=1n)=>{a=BigInt(a);b=BigInt(b);assert.ok(b!==0n);if(b<0n){a=-a;b=-b;}const g=gcd(a,b);return [a/g,b/g];},mul=(a,b)=>rat(a[0]*b[0],a[1]*b[1]),add=(a,b)=>rat(a[0]*b[1]+b[0]*a[1],a[1]*b[1]),fmt=a=>a[1]===1n?String(a[0]):String(a[0])+'/'+String(a[1]);
function observed(counts){
 const [aa,het,bb]=counts.map(BigInt),N=aa+het+bb,A=2n*aa+het,B=2n*bb+het,base={counts,N:Number(N),copies:[Number(A),Number(B)],totalCopies:Number(2n*N)};
 if(N===0n)return {...base,allele:null,observed:null,probabilities:null,expectedCounts:null,expectedCopies:null};
 const p=rat(A,2n*N),q=rat(B,2n*N),prob=[mul(p,p),mul(rat(2n),mul(p,q)),mul(q,q)],expect=prob.map(x=>mul(rat(N),x)),copies=[add(mul(rat(2n),expect[0]),expect[1]),add(expect[1],mul(rat(2n),expect[2]))];
 assert.equal(fmt(add(p,q)),'1');assert.equal(fmt(prob.reduce(add,rat(0n))),'1');assert.equal(fmt(expect.reduce(add,rat(0n))),String(N));assert.equal(fmt(copies[0]),String(A));assert.equal(fmt(copies[1]),String(B));
 return {...base,allele:[fmt(p),fmt(q)],observed:[aa,het,bb].map(x=>fmt(rat(x,N))),probabilities:prob.map(fmt),expectedCounts:expect.map(fmt),expectedCopies:copies.map(fmt)};
}
const observations=[];
for(const gold of literals){const actual={id:gold.id,...observed(gold.counts)};assert.deepEqual(actual,gold,gold.id+' independently frozen complete fraction table');observations.push(actual);}
assert.deepEqual(observations[2].allele,observations[3].allele);assert.notDeepEqual(observations[2].observed,observations[3].observed);
const scaled=observed([21,18,9]);assert.equal(scaled.N,48);assert.deepEqual(scaled.copies,[60,36]);assert.deepEqual(scaled.allele,['5/8','3/8']);assert.deepEqual(scaled.expectedCounts,['75/4','45/2','27/4']);
for(const f of received)exact(path.join(input.offer.originalRoot,f.path),f.source);
const result={schema:'recall261-independent-original-admission-v1',started,finished:new Date().toISOString(),pid:process.pid,parent:process.ppid,status:'passed',sourceCommit:input.offer.canonical.commit,sourceTree:input.offer.canonical.tree,source:received,bytes:received.reduce((s,x)=>s+x.source.bytes,0),node:input.node,edge:input.edge,donor:input.donor,reuse:{same23CanonicalConsumerFilesExact:true,priorOriginalBrowser:b.groups.map(g=>({name:g.name,status:g.status})),priorOriginalBrowserExit:0,closed:true,correctionRetained:correction,records:reused,noNewBrowserReplay:true},originalParser:{actualMendelianItems:12,allFieldsExact:true,roundtrip:true,deeplyFrozen:true,callerCopySeparated:true},math:{literals:observations,scaled,modelCandidateRead:false},plan:pin(path.join(root,'RECEIVING-PLAN.md')),literalFreeze:pin(path.join(root,'LITERAL-GOLD.json')),candidateContentRead:false,candidateAnswerKeysRead:false,authoredTestsOrResultsRead:false};
fs.writeFileSync(path.join(root,'ORIGINAL-ADMISSION.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:'passed',at:result.finished,pid:process.pid,sourceFiles:received.length,originalCourseItems:12,mathGroups:observations.length,scaled:true,originalBrowserReusedWithoutReplay:true}));
