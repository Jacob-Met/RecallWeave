import json,hashlib,urllib.request,tarfile,io,os,shutil,subprocess,time
from pathlib import Path
root=Path("/tmp/hamon-7a9310dad255-recall19-integration")
expected=json.loads((root/"expected-public-inputs.json").read_text())
def git_tree(rows):
    tree={}
    for row in rows:
        node=tree;parts=row["path"].split("/")
        for part in parts[:-1]:node=node.setdefault(part,{})
        assert parts[-1] not in node
        node[parts[-1]]=(row["mode"],row["sha"])
    def emit(node):
        raw=b""
        for name,item in sorted(node.items(),key=lambda x:(x[0]+("/" if isinstance(x[1],dict) else "")).encode()):
            mode,sha=("40000",emit(item)) if isinstance(item,dict) else item
            raw+=mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(sha)
        return hashlib.sha1(b"tree "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
    return emit(tree)

def pin(data):
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
receipt={"started":time.time(),"repository":expected["repository"],"current_head":expected["current_head"],"current_tree":expected["current_tree"],"course_head":expected["course_head"],"setup_note":"An initial expected-input write returned ENOENT before this isolated directory was created; no source was written. The directory was then explicitly created.","downloads":[],"commands":[]}
def download(label,head):
    url="https://codeload.github.com/Jacob-Met/RecallWeave/tar.gz/"+head
    path=root/(label+".tar.gz");started=time.monotonic()
    with urllib.request.urlopen(url,timeout=45) as response:
        assert response.status==200
        data=response.read(64*1024*1024+1)
    assert len(data)<=64*1024*1024
    with path.open("xb") as f:f.write(data)
    receipt["downloads"].append({"label":label,"url":url,"path":str(path),**pin(data),"seconds":time.monotonic()-started})
    return path
def capture(archive,dest,rows):
    wanted={x["path"]:x for x in rows};written=[]
    dest.mkdir()
    with tarfile.open(archive,"r:gz") as tar:
        for item in tar:
            if not item.isfile():continue
            parts=item.name.split("/",1)
            assert len(parts)==2
            path=parts[1]
            if path not in wanted:continue
            assert not Path(path).is_absolute() and ".." not in Path(path).parts
            data=tar.extractfile(item).read()
            assert len(data)==wanted[path]["size"] and pin(data)["git_blob"]==wanted[path]["sha"],path
            out=dest/path;out.parent.mkdir(parents=True,exist_ok=True)
            with out.open("xb") as f:f.write(data)
            mode=wanted[path]["mode"];assert mode in ["100644","100755"],(path,mode)
            out.chmod(0o755 if mode=="100755" else 0o644);written.append(path)
    assert len(written)==len(wanted) and set(written)==set(wanted)
    return written
def snapshot(where):
    rows=[]
    for p in sorted(where.rglob("*")):
        if p.is_file():
            b=p.read_bytes();rows.append({"path":str(p.relative_to(where)),"mode":"100755" if p.stat().st_mode&0o111 else "100644",**pin(b)})
    return rows
try:
    current_tar=download("current-d202",expected["current_head"])
    course_tar=download("course-226",expected["course_head"])
    baseline=root/"baseline";overlay=root/"course-overlay";candidate=root/"candidate"
    capture(current_tar,baseline,expected["current_entries"])
    capture(course_tar,overlay,expected["course_entries"])
    base=snapshot(baseline)
    tree=git_tree([{"path":x["path"],"mode":x["mode"],"sha":x["git_blob"]} for x in base])
    assert tree==expected["current_tree"] and len(base)==444
    assert all(not(baseline/x["path"]).exists() for x in expected["course_entries"])
    shutil.copytree(baseline,candidate)
    patch=root/"original-course-28.patch"
    env=dict(os.environ,GIT_OPTIONAL_LOCKS="0")
    with patch.open("xb") as out:
        for x in expected["course_entries"]:
            cmd=["git","--no-replace-objects","--no-pager","-c","core.autocrlf=false","diff","--no-ext-diff","--no-textconv","--binary","--full-index","--no-index","--","/dev/null",x["path"]]
            p=subprocess.run(cmd,cwd=overlay,env=env,capture_output=True)
            assert p.returncode==1 and not p.stderr,(x["path"],p.returncode,p.stderr.decode())
            out.write(p.stdout)
    for command in [["git","apply","--check",str(patch)],["git","apply",str(patch)]]:
        p=subprocess.run(command,cwd=candidate,env=env,capture_output=True)
        receipt["commands"].append({"command":command,"cwd":str(candidate),"exit":p.returncode,"stdout":p.stdout.decode(),"stderr":p.stderr.decode()})
        assert p.returncode==0
    final=snapshot(candidate);fm={x["path"]:x for x in final};bm={x["path"]:x for x in base}
    assert len(final)==472
    assert all(fm[p]["git_blob"]==x["git_blob"] and fm[p]["mode"]==x["mode"] for p,x in bm.items())
    assert all(fm[x["path"]]["git_blob"]==x["sha"] and fm[x["path"]]["mode"]==x["mode"] for x in expected["course_entries"])
    ctree=git_tree([{"path":x["path"],"mode":x["mode"],"sha":x["git_blob"]} for x in final])
    receipt.update({"completed":True,"baseline_files":444,"candidate_files":472,"baseline_tree":tree,"course_composed_tree":ctree,"all_current_leaves_preserved":True,"all_original_28_course_blobs_preserved":True,"patch":pin(patch.read_bytes()),"finished":time.time(),"source_freeze":"Course-only composition before additive current-adoption documentation."})
    with (root/"course-composed-source-manifest.json").open("x") as f:json.dump({"current_head":expected["current_head"],"current_tree":tree,"course_head":expected["course_head"],"source_tree":ctree,"files":final},f,indent=2);f.write("\n")
    with (root/"capture-composition-receipt.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
    print(json.dumps(receipt,indent=2))
except Exception as error:
    receipt.update({"completed":False,"error":type(error).__name__,"message":str(error),"finished":time.time()})
    with (root/"capture-composition-failure.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
    print(json.dumps(receipt,indent=2))
    raise
