from pathlib import Path
import copy, datetime, hashlib, json, re, subprocess, sys, traceback
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SOURCE=ROOT/'subject-v2/source'
ORACLE=ROOT/'oracles-v1/blind-oracles.json'
BRIDGE=HERE/'invoke_candidate.mjs'
OWNER=Path('/Users/me/recallweave-euclid-3dab-20261008/source')
NODE='/opt/homebrew/bin/node'
def facts(b):
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def require(ok, why):
    if not ok: raise ValueError(why)
def read_pinned(path,sha):
    b=path.read_bytes();require(hashlib.sha256(b).hexdigest()==sha,'pin changed: '+str(path));return b
def guard():
    pins=json.loads(read_pinned(ROOT/'subject-v2/author-product-v2-pins.json',
       '8fb9998c83129ad02b18f64f05596be374563a6f05b2dd4d0f5a87602372ecb8'))
    observed={}
    for rel,want in pins.items():
        for label,base in [('review',SOURCE),('owner',OWNER)]:
            got=facts((base/rel).read_bytes());require(got==want,'changed '+label+'/'+rel)
            observed[label+'/'+rel]=got
    doc='courses/euclidean-algorithm.md'
    b=read_pinned(SOURCE/doc,'a06b3005c916d5274b6d85357c7f698238df57ef53662e85c1d6a242efe32a8d')
    observed['review/'+doc]=facts(b)
    for p in [Path(__file__),BRIDGE]:
        observed['receiver/'+p.name]=facts(p.read_bytes())
    read_pinned(ORACLE,'7d2c6566151dc6ecd654073254c3d707ade4d6649abce2a98cd4b4559f269252')
    read_pinned(ROOT/'questions-v1/blind-answers.json','bec9e73659ae9eca94a4e19912e3d5f2b7bd9bcc8963f11cc17b0cf785dcaf13')
    read_pinned(ROOT/'questions-v1/questions-only.json','414fe1e27a6047ad420028b367fcd41d8d319ea18a4ffb9c15386c6235e47d73')
    return observed
def integer_text(value, signed=False):
    pattern=r'(?:0|-?[1-9][0-9]*)' if signed else r'(?:0|[1-9][0-9]*)'
    require(type(value) is str and re.fullmatch(pattern,value) is not None,'noncanonical integer text')
    return int(value)
def pair(value):
    require(type(value) is dict and set(value)=={'x','y'},'coefficient pair shape')
    return integer_text(value['x'],True),integer_text(value['y'],True)
def receive(trace,expected):
    require(type(trace) is dict,'trace shape')
    require(trace['format']=='recallweave-euclid-trace/1','trace format')
    require(trace['convention']=='gcd(0, 0) = 0','zero convention')
    require(trace['inputs']=={'a':expected['a'],'b':expected['b']},'original ordered inputs')
    a,b=integer_text(trace['inputs']['a']),integer_text(trace['inputs']['b'])
    d=integer_text(trace['gcd'])
    require(str(d)==expected['gcd'],'gcd differs from blind oracle')
    require(type(trace['steps']) is list and len(trace['steps'])==expected['division_count'],'complete division count')
    previous=None
    for i,(actual,want) in enumerate(zip(trace['steps'],expected['steps']),1):
        require(type(actual['index']) is int and actual['index']==i,'step index')
        values={k:integer_text(actual[k]) for k in ['dividend','divisor','quotient','remainder']}
        require(all(actual[k]==want[k] for k in values),'division differs from blind oracle')
        dividend,divisor,q,r=(values[k] for k in ['dividend','divisor','quotient','remainder'])
        require(divisor>0 and dividend==q*divisor+r and 0<=r<divisor,'Euclidean equation or range')
        dc,bc,rc=(pair(actual[k]) for k in ['dividendCoefficients','divisorCoefficients','remainderCoefficients'])
        for value,(x,y) in [(dividend,dc),(divisor,bc),(r,rc)]:
            require(a*x+b*y==value,'coefficient reconstruction')
        require(rc==(dc[0]-q*bc[0],dc[1]-q*bc[1]),'displayed coefficient subtraction')
        if previous is not None:
            require((dividend,divisor)==previous[:2],'division chain')
            require((dc,bc)==previous[2:],'coefficient chain')
        previous=(divisor,r,bc,rc)
    if trace['steps']:
        require(previous[:2]==(d,0),'terminal pair')
    else:
        require(b==0 and d==a,'zero initial divisor')
    x,y=pair(trace['coefficients'])
    require(a*x+b*y==d,'final Bezout identity')
    require((d==0 and a==b==0) or (d>0 and a%d==0 and b%d==0),'common-divisor boundary')
    return {'inputs':trace['inputs'],'gcd':trace['gcd'],'divisions':len(trace['steps']),
            'final_coefficients':trace['coefficients'],'all_exact_reconstructions':True}
def dump(name,obj):
    (HERE/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def main():
    before=guard()
    oracle=json.loads(ORACLE.read_text())
    command=[NODE,str(BRIDGE),str(SOURCE/'src/euclidean-algorithm.mjs'),str(ORACLE)]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result=subprocess.run(command,cwd=SOURCE,capture_output=True,timeout=20)
    (HERE/'candidate-stdout.json').write_bytes(result.stdout)
    (HERE/'candidate-stderr.txt').write_bytes(result.stderr)
    require(result.returncode==0 and not result.stderr,'native candidate process failed')
    actual=json.loads(result.stdout)
    require(actual['maximum']=='999999','declared domain maximum')
    require(len(actual['records'])==len(oracle['vectors'])==29,'exact frozen vector count')
    accepted=[receive(t,e) for t,e in zip(actual['records'],oracle['vectors'])]
    # These controls mutate received JSON in memory, never candidate source.
    target=next(i for i,e in enumerate(oracle['vectors']) if (e['a'],e['b'])==('48','18'))
    good=actual['records'][target]; expected=oracle['vectors'][target]
    corruptions=[]
    bad=copy.deepcopy(good);bad['steps'][1]['quotient']=str(int(bad['steps'][1]['quotient'])+1)
    corruptions.append(('wrong_middle_quotient_with_right_gcd',bad))
    bad=copy.deepcopy(good);bad['steps'].pop()
    corruptions.append(('omitted_terminal_zero_row',bad))
    bad=copy.deepcopy(good);bad['coefficients']['x']=str(int(bad['coefficients']['x'])+1)
    corruptions.append(('wrong_final_coefficient_with_right_gcd',bad))
    bad=copy.deepcopy(good);bad['steps'][1]['dividendCoefficients']['x']=str(int(bad['steps'][1]['dividendCoefficients']['x'])+1)
    corruptions.append(('wrong_intermediate_reconstruction',bad))
    bad=copy.deepcopy(good);bad['gcd']=int(bad['gcd'])
    corruptions.append(('numeric_instead_of_exact_text',bad))
    rejected=[]
    for name,bad in corruptions:
        try:receive(bad,expected)
        except ValueError as failure:rejected.append({'name':name,'refusal':str(failure)})
        else:raise ValueError('receiver accepted '+name)
    alternate=copy.deepcopy(good)
    d=int(good['gcd']);a=int(expected['a']);b=int(expected['b'])
    alternate['coefficients']={'x':str(int(good['coefficients']['x'])+b//d),
                                'y':str(int(good['coefficients']['y'])-a//d)}
    receive(alternate,expected)
    original=json.loads((ROOT/'questions-v1/questions-only.json').read_text())['questions']
    blind=json.loads((ROOT/'questions-v1/blind-answers.json').read_text())
    course=json.loads((SOURCE/'courses/euclidean-algorithm.json').read_text())
    require(len(course['items'])==len(original)==12,'course question count')
    require([q['answer'] for q in course['items']]==blind['intended_indices_zero_based'],'blind answer mismatch')
    changes=[]
    for old,new in zip(original,course['items']):
        for key in old:
            if old[key]!=new[key]:changes.append({'id':old['id'],'field':key,'before':old[key],'after':new[key]})
    required_prompt='When a nonnegative integer a is divided by a positive integer b, which condition gives the full allowed range of the Euclidean remainder r?'
    require(len(changes)==1 and changes[0]['id']=='euclid-division-3' and changes[0]['field']=='prompt' and changes[0]['after']==required_prompt,'unexpected question-only delta')
    html=(SOURCE/'courses/euclidean-algorithm-explorer.html').read_text()
    match=re.search(r'<script type="application/json" id="euclid-course-json">(.*?)</script>',html,re.S)
    require(match is not None,'embedded exact course missing')
    require(json.loads(match.group(1))==(SOURCE/'courses/euclidean-algorithm.json').read_text(),'bundled course differs')
    after=guard();require(after==before,'before/after guards differ')
    receipt={'status':'passed','started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'command':command,'cwd':str(SOURCE),'exit_code':result.returncode,'stderr_empty':not result.stderr,
      'native_runtime':actual['runtime'],'receiver_python':sys.version,'accepted_vectors':accepted,
      'total_division_rows':sum(x['divisions'] for x in accepted),'negative_observation_controls':rejected,
      'alternative_valid_final_coefficients_accepted':alternate['coefficients'],'blind_answer_indices':blind['intended_indices_zero_based'],
      'question_only_delta':changes,'bundled_course_exact':True,'source_guards_before':before,'source_guards_after':after,
      'scope':'Independent frozen mathematics/content receiving; no authored-suite, browser, learner or source mutation.',
      'candidate_stdout':facts(result.stdout),'candidate_stderr':facts(result.stderr)}
    dump('receiving-receipt.json',receipt)
    print('EUCLID_MATH_REVIEW_OK vectors=29 negative_controls=5 alternate_pair=1 answers=12')
    print(json.dumps({'divisions':receipt['total_division_rows'],'runtime':actual['runtime'],'receipt_sha256':facts((HERE/'receiving-receipt.json').read_bytes())['sha256']}))
if __name__=='__main__':
    try:main()
    except BaseException as failure:
        dump('failure.json',{'type':type(failure).__name__,'message':str(failure),'traceback':traceback.format_exc()})
        raise
