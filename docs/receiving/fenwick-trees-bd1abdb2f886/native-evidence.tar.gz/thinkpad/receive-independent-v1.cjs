const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),cp=require("node:child_process");
const root="/home/jacob/recallweave-fenwick-bd1abdb2f886-20261008",source=path.join(root,"candidate-v2"),qa=path.join(root,"candidate-v2-qa");
const hash=(b)=>crypto.createHash("sha256").update(b).digest("hex");
const git=(b)=>crypto.createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
const pin=(p)=>{const b=fs.readFileSync(p);return{bytes:b.length,sha256:hash(b),git_blob:git(b),mode:(fs.statSync(p).mode&511).toString(8)};};
const initial=JSON.parse(fs.readFileSync(path.join(qa,"execution.json")));
const paths=Object.keys(initial.source_after).concat("courses/fenwick-trees-explorer.html");
const sourcePins=()=>Object.fromEntries(paths.map(name=>[name,pin(path.join(source,name))]));
const reportPath=path.join(qa,"independent-report.json"),receiptPath=path.join(qa,"independent-execution.json");
if(fs.existsSync(reportPath)||fs.existsSync(receiptPath))throw Error("Existing receiving must be read, not replayed");
const before=sourcePins(),receiverBefore=pin(path.join(root,"independent-receiver-v1.mjs"));
if(receiverBefore.git_blob!=="a440bca8e644efd620b3daa07713c07883b18a36")throw Error("Independent receiver identity mismatch");
const args=[path.join(root,"independent-receiver-v1.mjs"),path.join(source,"src/fenwick-trees.mjs"),reportPath];
const start=Date.now(),run=cp.spawnSync(process.execPath,args,{cwd:root,encoding:"utf8",timeout:30000,maxBuffer:2*1024*1024});
const result={schema:"recallweave-fenwick-independent-execution/v1",at:new Date().toISOString(),argv:[process.execPath,...args],exit:run.status,signal:run.signal,error:run.error?String(run.error):null,milliseconds:Date.now()-start,source_before:before,receiver_before:receiverBefore,controller:pin(__filename)};
for(const stream of["stdout","stderr"]){const p=path.join(qa,"independent."+stream+".txt");fs.writeFileSync(p,run[stream]||"",{flag:"wx"});result[stream]=pin(p);}
result.source_after=sourcePins();result.receiver_after=pin(path.join(root,"independent-receiver-v1.mjs"));
if(fs.existsSync(reportPath)){result.report=pin(reportPath);result.summary=JSON.parse(fs.readFileSync(reportPath)).summary;}
result.pass=run.status===0&&!run.error&&JSON.stringify(before)===JSON.stringify(result.source_after)&&JSON.stringify(receiverBefore)===JSON.stringify(result.receiver_after);
fs.writeFileSync(receiptPath,JSON.stringify(result,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify({pass:result.pass,exit:run.status,summary:result.summary,report:result.report,receipt:pin(receiptPath)}));process.exitCode=result.pass?0:1;
