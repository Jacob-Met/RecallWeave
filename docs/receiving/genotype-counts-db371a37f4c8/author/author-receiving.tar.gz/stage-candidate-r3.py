import ctypes, datetime, hashlib, json, os, pathlib, platform, shutil, subprocess, sys, traceback
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
E=R/'author-native-r3'
E.mkdir(exist_ok=False)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):
 b=p.read_bytes()
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(name,obj): (E/name).write_bytes((json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
class MEM(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['totalPhys','availPhys','totalPage','availPage','totalVirtual','availVirtual','availExtended']]
m=MEM();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
u=ctypes.create_unicode_buffer(256);n=ctypes.c_ulong(256);assert ctypes.windll.advapi32.GetUserNameW(u,ctypes.byref(n))
rec={'started':now(),'wrapperPid':os.getpid(),'status':'started','identity':{'machine':platform.node(),'user':u.value},'python':{'path':sys.executable,**pin(pathlib.Path(sys.executable))},'capacity':{'CFree':shutil.disk_usage('C:/').free,'DFree':shutil.disk_usage('D:/').free,'memoryAvailable':m.availPhys},'guard':{'C':1073741824,'D':1073741824,'memory':2147483648},'children':[]}
save('receipt.json',rec)
try:
 assert platform.node().upper()=='MSI' and u.value=='Veria'
 assert rec['python']['sha256']=='5f7b89a612c9b8af1d6456cdfcd1dbe5ca630849e79aebced9bee9a6694952ec'
 assert rec['capacity']['CFree']>=1073741824 and rec['capacity']['DFree']>=1073741824 and m.availPhys>=2147483648
 manifest=json.loads((R/'ORIGINAL-MANIFEST.json').read_text(encoding='utf-8'))
 packet=json.loads((R/'CANDIDATE-STAGING-r2.json').read_text(encoding='utf-8'))
 correction=json.loads((R/'TEST-CORRECTION-DIAGNOSIS.json').read_text(encoding='utf-8'))
 for item in packet['files']:
  if item['path']=='tests/genotype-counts-course.test.mjs':item['content']=correction['file']
 rec['testCorrection']=correction['reason'];rec['priorDiagnostic']=correction['priorDiagnostic']
 candidate=R/'candidate-r3';candidate.mkdir(exist_ok=False)
 for item in manifest:
  src=R/'original'/item['path'];p=pin(src);assert all(p[k]==item[k] for k in ['bytes','sha256','git'])
  dst=candidate/item['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
 for f in packet['files']:
  dst=candidate/f['path'];assert not dst.exists();dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(f['content'].encode('utf-8'))
 before=[{'path':str(p.relative_to(candidate)).replace('\\','/'),**pin(p)} for p in sorted(candidate.rglob('*')) if p.is_file()]
 assert len(before)==30
 rec['sourceBefore']=before;rec['originalManifest']=pin(R/'ORIGINAL-MANIFEST.json');rec['packet']=pin(R/'CANDIDATE-STAGING-r2.json');rec['projection']=pin(R/'PROMPTS-ONLY-r1.json')
 node=pathlib.Path(r'C:/Program Files/nodejs/node.exe');rec['node']={'path':str(node),**pin(node)};assert rec['node']['sha256']=='3602f2bb1a10f2cbab4c36886218a33c1ab3db87290e73b033c46c77147d0237'
 tmp=E/'tmp';tmp.mkdir();env=os.environ.copy();env.update({'TEMP':str(tmp),'TMP':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'})
 argv=[str(node),'--test','--test-name-pattern=worksheet keeps','tests/genotype-counts-course.test.mjs']
 with (E/'stdout.txt').open('wb') as out,(E/'stderr.txt').open('wb') as err:
  child=subprocess.Popen(argv,cwd=candidate,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
  rec['children'].append({'pid':child.pid,'argv':argv,'cwd':str(candidate),'envDelta':{'TEMP':str(tmp),'TMP':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'}});save('receipt.json',rec)
  try: code=child.wait(timeout=30)
  except subprocess.TimeoutExpired: child.kill();code=child.wait();rec['timeout']=True
 rec['children'][-1]['exitCode']=code
 rec['stdout']=pin(E/'stdout.txt');rec['stderr']=pin(E/'stderr.txt')
 after=[{'path':str(p.relative_to(candidate)).replace('\\','/'),**pin(p)} for p in sorted(candidate.rglob('*')) if p.is_file()]
 assert before==after;rec['sourceAfter']=after
 for item in manifest:
  assert all(pin(R/'original'/item['path'])[k]==item[k] for k in ['bytes','sha256','git'])
 shutil.rmtree(tmp);rec['tempRemoved']=True
 rec['finished']=now();rec['status']='passed' if code==0 else 'failed';save('receipt.json',rec)
 (R/'CANDIDATE-MANIFEST-r3.json').write_bytes((json.dumps(before,indent=2)+'\n').encode('utf-8'))
 print(json.dumps({'status':rec['status'],'wrapperPid':os.getpid(),'childPid':child.pid,'childExit':code,'receipt':pin(E/'receipt.json'),'projection':rec['projection'],'sourceFiles':len(before)}))
 sys.exit(code)
except BaseException as e:
 if not isinstance(e,SystemExit):
  rec.update({'status':'failed','finished':now(),'error':str(e),'traceback':traceback.format_exc()});save('receipt.json',rec)
 raise
