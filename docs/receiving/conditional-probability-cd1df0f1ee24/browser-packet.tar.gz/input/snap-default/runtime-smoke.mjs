import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const root='/home/jacob/hamon-probability-cd1df0f1ee24/receiving-browser/snap-default';
const require=createRequire(import.meta.url);
const entry=require.resolve('/home/jacob/.local/lib/node_modules/@wonderwhy-er/desktop-commander/node_modules/puppeteer-core');
const imported=await import(pathToFileURL(entry).href);
const puppeteer=imported.default;
const executablePath='/snap/bin/chromium';
const userDataDir=path.join(root,'smoke-profile');
const receipt={scope:'Blank-page native-runtime smoke only; no product source or learner execution',started:new Date().toISOString(),node:process.version,puppeteerEntry:entry,executablePath,userDataDir,requests:[],pageErrors:[],checks:[]};
const check=(name,value,detail)=>{receipt.checks.push({name,pass:!!value,detail});if(!value)throw Error(name)};
let browser;
try{
 browser=await puppeteer.launch({executablePath,userDataDir,headless:true,timeout:20000,args:['--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync']});
 receipt.browserVersion=await browser.version();
 const page=await browser.newPage();
 await page.setViewport({width:1024,height:640,deviceScaleFactor:1});
 await page.setRequestInterception(true);
 page.on('request',r=>{receipt.requests.push({url:r.url(),method:r.method()});if(/^https?:/.test(r.url()))r.abort();else r.continue();});
 page.on('pageerror',e=>receipt.pageErrors.push(String(e)));
 await page.goto('about:blank');
 await page.setContent('<!doctype html><html lang="en"><meta charset="utf-8"><title>Probability receiving — runtime smoke</title><style>body{font:20px system-ui;background:#f4f7f4;color:#193628;margin:0;padding:64px}main{max-width:720px;background:white;padding:32px;border:2px solid #647f70}button{font:inherit;padding:12px 20px;border:2px solid #355942;background:white}button:focus{outline:3px solid #1b65b9;outline-offset:4px}output{font-weight:bold}</style><main><h1>Native browser runtime</h1><p>This isolated blank page checks DOM, pointer input and screenshot capture.</p><button id="increment">Increment smoke counter</button><p>Counter: <output id="value">0</output></p></main><script>document.querySelector("#increment").addEventListener("click",()=>{document.querySelector("#value").textContent="1";});</script></html>');
 check('literal DOM available',await page.$eval('h1',e=>e.textContent)==='Native browser runtime');
 await page.click('#increment');
 check('native browser pointer click updates DOM',await page.$eval('#value',e=>e.textContent)==='1');
 check('button has focus',await page.$eval('#increment',e=>e===document.activeElement));
 const png=path.join(root,'smoke-page.png');await page.screenshot({path:png,fullPage:true});
 const bytes=await fs.readFile(png);receipt.screenshot={path:png,bytes:bytes.length,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),width:1024,height:640,visuallyInspected:false};
 check('PNG signature and nonempty capture',bytes.subarray(0,8).toString('hex')==='89504e470d0a1a0a'&&bytes.length>1000);
 check('no page errors',receipt.pageErrors.length===0,receipt.pageErrors);
 check('no attempted HTTP(S) page requests',receipt.requests.every(r=>!/^https?:/.test(r.url())),receipt.requests);
 receipt.pass=true;
}catch(error){receipt.pass=false;receipt.error=String(error);process.exitCode=1;}
finally{if(browser){await browser.close();receipt.closed=true;}receipt.ended=new Date().toISOString();await fs.writeFile(path.join(root,'smoke-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));}
