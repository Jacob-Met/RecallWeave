'use strict';
// Receive the exact published probability course through the current importer and trace UI.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {createHash}=require('node:crypto'),{pathToFileURL}=require('node:url');
const {chromium}=require('/home/jacob/.cache/returnby-backup-8b336fefde84/node_modules/playwright');
const root=__dirname,source=path.join(root,'source'),out=path.join(root,'evidence');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'source-manifest.json')));
const published=JSON.parse(fs.readFileSync(path.join(root,'published-source-manifest.json')));
const oracle=JSON.parse(fs.readFileSync(path.join(root,'published/docs/receiving/probability-course-7a9310dad255/browser/course-oracle.json')));
const coursePath=path.join(source,'courses/probability-foundations.json'),course=JSON.parse(fs.readFileSync(coursePath));
const sha=b=>createHash('sha256').update(b).digest('hex'),digest=p=>sha(fs.readFileSync(p));
const sourceNames=new Set(manifest.files.map(f=>f.path));
const changed=structuredClone(course);changed.items[0].explanation+=' [Independent receiving version marker.]';
const changedPath=path.join(root,'fixtures','changed-probability-foundations.json');
fs.writeFileSync(changedPath,JSON.stringify(changed,null,2)+'\n');
const receipt={started:new Date().toISOString(),coursePR:19,courseHead:manifest.course_head,receivingBase:manifest.receiving_base,
 receiverManifestSha256:manifest.receiver_manifest_sha256,compositionManifestSha256:digest(path.join(root,'source-manifest.json')),
 courseSha256:digest(coursePath),oracleSha256:digest(path.join(root,'published/docs/receiving/probability-course-7a9310dad255/browser/course-oracle.json')),
 changedCourse:{path:path.relative(root,changedPath),sha256:digest(changedPath),change:'Append one test-only marker to the first explanation; all title, question IDs, options, answer keys, and other fields stay equal.'},
 groups:[],surfaces:[],servedResources:{},jsErrors:[],externalRequests:[]};
const persist=()=>fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
function verify(stage){
 for(const f of manifest.files){
  const b=fs.readFileSync(path.join(source,f.path));assert.equal(sha(b),f.sha256,f.path);assert.equal(createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex'),f.blob,f.path);
 }
 for(const f of published.files){const b=fs.readFileSync(path.join(root,'published',f.path));assert.equal(sha(b),f.sha256,f.path);}
 assert.equal(fs.statSync(coursePath).size,13164);assert.equal(digest(coursePath),'17a35b359ab5c1f097931bba29dcf7deddc75c98accbf1cced8ae5eca9e9ad01');
 receipt[stage]={sourceFiles:manifest.files.length,receiverFiles:manifest.files.length-2,publishedInputFiles:published.files.length};
}
for(const item of course.items){
 const prior=oracle.items.find(x=>x.id===item.id);assert(prior);
 for(const field of ['concept','prerequisites','prompt','options','explanation','transfer'])assert.deepEqual(item[field],prior[field]);
 assert.equal(item.options[item.answer],prior.expected_correct_text);
}
assert.equal(course.items.length,12);assert.equal(course.concepts.length,4);
assert.deepEqual(oracle.items.filter(x=>!x.expected_first_correct).map(x=>x.id),['pf-c1','pf-i2']);
const mime={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.json':'application/json'};
const server=http.createServer((req,res)=>{
 try{
  const n=decodeURIComponent(new URL(req.url,'http://localhost').pathname).replace(/^\//,'')||'index.html';
  if(!sourceNames.has(n)){res.writeHead(404);res.end();return;}
  const b=fs.readFileSync(path.join(source,n));receipt.servedResources[n]={bytes:b.length,sha256:sha(b)};
  res.writeHead(200,{'Content-Type':mime[path.extname(n)]||'application/octet-stream'});res.end(b);
 }catch{res.writeHead(404);res.end();}
});
let browser,origin;
async function activate(page,selector){const n=page.locator(selector);await n.focus();assert.equal(await n.evaluate(x=>x===document.activeElement),true);await page.keyboard.press('Enter');}
async function open(surface,entropy){
 const context=await browser.newContext({viewport:surface==='modular'?{width:1280,height:960}:{width:390,height:900},acceptDownloads:true});
 await context.addInitScript(value=>{Math.random=()=>value;},entropy);
 const file=pathToFileURL(path.join(source,'demo.html')).href;
 await context.route('**/*',route=>{
  const u=route.request().url();if(u.startsWith(origin+'/')||u===file||u.startsWith('blob:')||u.startsWith('data:'))return route.continue();
  receipt.externalRequests.push({surface,url:u});return route.abort();
 });
 const page=await context.newPage();page.setDefaultTimeout(7000);page.on('pageerror',e=>receipt.jsErrors.push({surface,error:e.message}));
 await page.goto(surface==='modular'?origin+'/index.html':file);await page.locator('#start-button').waitFor();
 return {page,context};
}
async function importCourse(page,variant=false){
 const before=await page.locator('#session-content').innerHTML();
 if(variant)await page.locator('#deck-file').setInputFiles({name:'probability-foundations.json',mimeType:'application/json',buffer:fs.readFileSync(changedPath)});
 else await page.locator('#deck-file').setInputFiles(coursePath);
 await page.locator('#start-deck').waitFor({state:'visible'});
 assert.equal(await page.locator('#deck-preview-title').textContent(),course.title);
 assert.match(await page.locator('.deck-preview-count').textContent(),/12 questions · 4 concepts/);
 assert.equal(await page.locator('#session-content').innerHTML(),before);
 await activate(page,'#start-deck');await page.locator('[data-choice]').first().waitFor({state:'visible'});
 assert.equal(await page.locator('#lesson-description').textContent(),course.title);assert.equal(await page.locator('#step-count').textContent(),'0 / 12');
}
async function chooseText(page,item,text,practice=false){
 const selector=practice?'[data-practice-choice]':'[data-choice]',nodes=page.locator(selector);
 const options=await nodes.evaluateAll(ns=>ns.map(n=>({canonical:Number(n.dataset.practiceChoice??n.dataset.choice),label:n.querySelector('.choice-key').textContent,text:[...n.childNodes].filter(x=>x.nodeType===Node.TEXT_NODE).map(x=>x.textContent).join('')})));
 assert.equal(options.length,item.options.length);
 for(const option of options)assert.equal(option.text,item.options[option.canonical]);
 const position=options.findIndex(o=>o.text===text);assert(position>=0&&options.filter(o=>o.text===text).length===1);
 assert.equal(options[position].canonical,item.options.indexOf(text));
 await nodes.first().focus();for(let i=0;i<position;i++)await page.keyboard.press('Tab');
 assert.equal(await nodes.nth(position).evaluate(n=>n===document.activeElement),true);await page.keyboard.press('Enter');
 return {id:item.id,displayed:options,selected:{position,...options[position]}};
}
async function ensurePanel(page){if(await page.locator('#trace-archive-panel').getAttribute('open')===null)await activate(page,'#trace-archive-panel > summary');}
async function download(page,observed,label,kind){
 if(kind==='trace')await ensurePanel(page);
 const pending=page.waitForEvent('download');await activate(page,kind==='trace'?'#save-trace-button':'#save-notes-button');
 const result=await pending;assert.equal(await result.failure(),null);
 const suffix=kind==='trace'?'.json':'.txt',name=result.suggestedFilename();
 assert.match(name,kind==='trace'?/^recallweave-learning-trace-\d{4}-\d{2}-\d{2}\.json$/:/^recallweave-study-notes-\d{4}-\d{2}-\d{2}\.txt$/);
 const file=path.join(observed.directory,label+suffix);await result.saveAs(file);
 const b=fs.readFileSync(file),entry={kind,label,path:path.relative(root,file),suggestedFilename:name,bytes:b.length,sha256:sha(b)};
 observed.downloads.push(entry);
 return {...entry,file,text:b.toString('utf8'),document:kind==='trace'?JSON.parse(b):null};
}
function assertTrace(document,order){
 assert.equal(document.format,'recallweave.learning-trace');assert.deepEqual(document.deck,course);
 assert.deepEqual(document.firstAnswers.map(x=>x.item),order);
 for(const answer of document.firstAnswers){const item=course.items.find(x=>x.id===answer.item),prior=oracle.items.find(x=>x.id===answer.item);assert.equal(item.options[answer.choice],prior.selected_first_text);}
 assert.deepEqual(Object.keys(document.mastery).sort(),[...course.concepts].sort());
}
function assertNotes(text,trace,order){
 assert(text.includes(course.title));assert(text.includes(course.attribution));assert(text.includes(course.license));
 assert(text.includes('10 of 12 connections correct on the first try.'));
 const practice=trace.practice?.answers??[];
 if(trace.practice===null)assert(text.includes('Not started. 2 missed connections are available for practice.'));
 else assert(text.includes((practice.length===2?'Complete':'Paused')+': '+practice.length+' of 2 practice answers recorded; '+practice.length+' correct on retry.'));
 for(const concept of course.concepts)assert(text.includes(concept+': '+Math.round(trace.mastery[concept]*100)+'%'));
 for(let i=0;i<order.length;i++){
  const item=course.items.find(x=>x.id===order[i]),prior=oracle.items.find(x=>x.id===item.id);
  const next=order[i+1],start=text.indexOf((i+1)+'. '+item.prompt),end=next?text.indexOf((i+2)+'. '+course.items.find(x=>x.id===next).prompt):text.indexOf('\nDECK ATTRIBUTION');
  assert(start>=0&&end>start);const block=text.slice(start,end);
  assert(block.includes('Your first answer: '+prior.selected_first_text));
  assert(block.includes('Correct answer: '+prior.expected_correct_text));
  assert(block.includes('Explanation: '+prior.explanation));assert(block.includes('Apply the idea: '+prior.transfer));
  const retry=practice.find(x=>x.item===item.id);if(retry)assert(block.includes('Practice answer: '+item.options[retry.choice]));
 }
}
function normalizedNotes(text){return text.replace(/^Saved: .+$/m,'Saved: <timestamp>');}
function sameTrace(a,b){const {savedAt:aa,...left}=a,{savedAt:bb,...right}=b;assert.deepEqual(left,right);}
async function loadTrace(page,file,refuse=false){
 await ensurePanel(page);await page.locator('#trace-file').setInputFiles(file);
 if(refuse){await page.waitForFunction(()=>/different course or course version/.test(document.getElementById('trace-restore-status').textContent));return;}
 await page.locator('#trace-preview').waitFor({state:'visible'});assert.match(await page.locator('#trace-preview-summary').textContent(),/First try: 10 of 12/);
}
async function group(name,run){
 const began=Date.now();try{const evidence=await run();receipt.groups.push({name,passed:true,milliseconds:Date.now()-began,evidence});console.log('PASS '+name);}
 catch(e){receipt.groups.push({name,passed:false,milliseconds:Date.now()-began,error:e.stack});throw e;}finally{persist();}
}
async function runSurface(surface){
 const observed={surface,directory:path.join(out,surface),downloads:[],questionObservations:[],practiceObservations:[],freshContexts:0};
 fs.mkdirSync(observed.directory,{recursive:true});receipt.surfaces.push(observed);
 let {page,context}=await open(surface,0);observed.freshContexts++;
 let firstTrace,pausedTrace,pausedNotes,completeTrace;const order=[];
 try{
  await group(surface+': exact published course completes a canonical twelve-question lesson and produces matching notes and saved trace',async()=>{
   await importCourse(page);
   for(let i=0;i<12;i++){
    const prompt=await page.locator('.question-card h2').textContent(),item=course.items.find(x=>x.prompt===prompt);assert(item);assert(!order.includes(item.id));order.push(item.id);
    const prior=oracle.items.find(x=>x.id===item.id),choice=await chooseText(page,item,prior.selected_first_text);
    observed.questionObservations.push(choice);
    const correct=await page.locator('.choice.correct').evaluate(n=>[...n.childNodes].filter(x=>x.nodeType===Node.TEXT_NODE).map(x=>x.textContent).join(''));
    assert.equal(correct,prior.expected_correct_text);
    assert.equal(choice.selected.canonical===item.answer,prior.expected_first_correct);
    await activate(page,'#next-button');
   }
   assert.equal(new Set(order).size,12);assert.match(await page.locator('#first-try-summary').textContent(),/10 of 12/);
   firstTrace=await download(page,observed,'first-session-trace','trace');assertTrace(firstTrace.document,order);assert.equal(firstTrace.document.practice,null);
   const notes=await download(page,observed,'first-session-notes','notes');assertNotes(notes.text,firstTrace.document,order);
   return {uniqueQuestions:order.length,order,correct:10,missed:['pf-c1','pf-i2'],trace:firstTrace.sha256,notes:notes.sha256};
  });
  await group(surface+': a real paused trace restores in a fresh same-course import with different display order, then resumes only its remaining retry',async()=>{
   await activate(page,'#practice-button');
   const prompt=await page.locator('.practice-card h2').textContent(),first=course.items.find(x=>x.prompt===prompt);assert(['pf-c1','pf-i2'].includes(first.id));
   observed.practiceObservations.push({phase:'before-save',...(await chooseText(page,first,oracle.items.find(x=>x.id===first.id).expected_correct_text,true))});
   await activate(page,'#back-to-review');
   pausedTrace=await download(page,observed,'paused-trace','trace');pausedNotes=await download(page,observed,'paused-notes','notes');
   assertTrace(pausedTrace.document,order);assert.equal(pausedTrace.document.practice.answers.length,1);assertNotes(pausedNotes.text,pausedTrace.document,order);
   assert.deepEqual(pausedTrace.document.firstAnswers,firstTrace.document.firstAnswers);assert.deepEqual(pausedTrace.document.mastery,firstTrace.document.mastery);
   await context.close();({page,context}=await open(surface,0.999999));observed.freshContexts++;
   assert.equal(await page.locator('#lesson-description').textContent()===course.title,false,'A fresh context has no imported course state');
   await importCourse(page);
   const unchanged=await page.locator('#session-content').innerHTML();await loadTrace(page,pausedTrace.file);
   assert.equal(await page.locator('#session-content').innerHTML(),unchanged);assert.match(await page.locator('#trace-preview-summary').textContent(),/Practice: 1 of 2/);
   await activate(page,'#restore-trace-confirm');assert.match(await page.locator('#practice-status').textContent(),/Practice paused: 1 of 2/);
   const restored=await download(page,observed,'restored-paused-trace','trace'),restoredNotes=await download(page,observed,'restored-paused-notes','notes');
   sameTrace(restored.document,pausedTrace.document);assertNotes(restoredNotes.text,restored.document,order);
   assert.equal(normalizedNotes(restoredNotes.text),normalizedNotes(pausedNotes.text));
   await activate(page,'#practice-button');
   const currentPrompt=await page.locator('.practice-card h2').textContent(),remaining=course.items.find(x=>x.prompt===currentPrompt);assert(remaining&&remaining.id!==first.id);assert(['pf-c1','pf-i2'].includes(remaining.id));
   const choice=await chooseText(page,remaining,oracle.items.find(x=>x.id===remaining.id).expected_correct_text,true);
   observed.practiceObservations.push({phase:'fresh-restored',...choice});
   assert.notDeepEqual(choice.displayed.map(x=>x.canonical),observed.questionObservations.find(x=>x.id===remaining.id).displayed.map(x=>x.canonical),'Fresh display order changed while canonical choice stayed correct');
   await activate(page,'#practice-next');assert.match(await page.locator('#practice-status').textContent(),/2 of 2 correctly on retry/);
   completeTrace=await download(page,observed,'completed-restored-trace','trace');const completeNotes=await download(page,observed,'completed-restored-notes','notes');
   assertTrace(completeTrace.document,order);assertNotes(completeNotes.text,completeTrace.document,order);
   assert.deepEqual(completeTrace.document.firstAnswers,firstTrace.document.firstAnswers);assert.deepEqual(completeTrace.document.mastery,firstTrace.document.mastery);
   assert.deepEqual(completeTrace.document.practice.answers.slice(0,1),pausedTrace.document.practice.answers);
   assert.deepEqual(new Set(completeTrace.document.practice.answers.map(x=>x.item)),new Set(['pf-c1','pf-i2']));
   for(const answer of completeTrace.document.practice.answers)assert.equal(answer.choice,course.items.find(x=>x.id===answer.item).answer);
   return {freshContext:true,firstRetry:first.id,resumedRetry:remaining.id,pausedTrace:pausedTrace.sha256,restoredTrace:restored.sha256,completeTrace:completeTrace.sha256,notes:completeNotes.sha256,fullStateAndNotesPreservedExceptTimestamps:true};
  });
  await group(surface+': same-name course-content change refuses the saved trace; the exact published course accepts that same completed file',async()=>{
   await importCourse(page,true);const unchanged=await page.locator('#session-content').innerHTML();
   await loadTrace(page,completeTrace.file,true);
   assert.equal(await page.locator('#trace-preview').isHidden(),true);assert.equal(await page.locator('#session-content').innerHTML(),unchanged);
   assert.equal(await page.locator('#step-count').textContent(),'0 / 12');assert.equal(await page.locator('#save-trace-button').isDisabled(),true);
   const refusal=await page.locator('#trace-restore-status').textContent();
   await importCourse(page);await loadTrace(page,completeTrace.file);await activate(page,'#restore-trace-confirm');
   assert.match(await page.locator('#practice-status').textContent(),/2 of 2 correctly on retry/);assert.equal(await page.locator('#practice-button').count(),0);
   const accepted=await download(page,observed,'unchanged-course-completed-round-trip','trace');sameTrace(accepted.document,completeTrace.document);
   return {changedCourseSha256:receipt.changedCourse.sha256,refusal,exactCourseAccepted:true,completedRoundTrip:accepted.sha256};
  });
 }finally{await context.close();}
}
(async()=>{
 try{
  verify('sourceBefore');await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;
  browser=await chromium.launch({headless:true,executablePath:'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome',args:['--no-sandbox','--disable-dev-shm-usage'],env:{...process.env,TMPDIR:'/dev/shm/rw490f-probtmp'}});
  receipt.browser=browser.version();receipt.node=process.version;receipt.harnessSha256=digest(__filename);
  for(const surface of ['modular','standalone'])await runSurface(surface);
  assert.equal(receipt.jsErrors.length,0);assert.equal(receipt.externalRequests.length,0);receipt.passed=true;
 }catch(e){receipt.passed=false;receipt.error=e.stack;console.error(e.stack);process.exitCode=1;}
 finally{
  if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));
  try{verify('sourceAfter');}catch(e){receipt.passed=false;receipt.sourceError=e.stack;process.exitCode=1;}
  receipt.finished=new Date().toISOString();persist();
  console.log(JSON.stringify({passed:receipt.passed,groups:receipt.groups.map(x=>({name:x.name,passed:x.passed})),downloads:receipt.surfaces.reduce((n,s)=>n+s.downloads.length,0),jsErrors:receipt.jsErrors,externalRequests:receipt.externalRequests}));
 }
})();
