import pathlib,hashlib,json,subprocess,datetime,sys
root=pathlib.Path('/home/jacob/snap/chromium/common/optimizer-counting-principles-3dab-20261008')
script=root/'receiving/receive_counting_learner_v2.mjs'
out=root/'receiving/command-learner-v2';out.mkdir()
b=script.read_bytes();assert hashlib.sha256(b).hexdigest()=='9fdf8d1af2d2c49039c7cce3838df733aabbe6cf504636cbd57c5bba28f7ce3f'
r={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receiver_sha256':hashlib.sha256(b).hexdigest(),'argv':['/usr/bin/node',str(script)],'source_manifest':'259201272faad03d8ad316848ad7c95cb092f5963b3263f6f40d994c08474a15','stages':[]}
for label,argv in [('syntax',['/usr/bin/node','--check',str(script)]),('browser',r['argv'])]:
 p=subprocess.run(argv,capture_output=True,timeout=240)
 (out/(label+'-stdout.txt')).write_bytes(p.stdout);(out/(label+'-stderr.txt')).write_bytes(p.stderr)
 stage={'label':label,'argv':argv,'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 r['stages'].append(stage)
 print(label,p.returncode,p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'),flush=True)
 if p.returncode:break
r['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
r['receiver_unchanged']=script.read_bytes()==b
r['accepted']=len(r['stages'])==2 and all(x['exit_code']==0 for x in r['stages']) and r['receiver_unchanged'] and p.stdout.decode().splitlines().count('COUNTING_BROWSER_OK checks=2 failures=0')==1
if (root/'receiving/browser-learner-v2/browser-report.json').exists():
 report=(root/'receiving/browser-learner-v2/browser-report.json').read_bytes();r['report_sha256']=hashlib.sha256(report).hexdigest();r['report_status']=json.loads(report)['status'];r['accepted']=r['accepted'] and r['report_status']=='passed'
(out/'controller.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print('COUNTING_CONTROLLER_'+('OK' if r['accepted'] else 'FAILED'),flush=True)
sys.exit(0 if r['accepted'] else 1)
