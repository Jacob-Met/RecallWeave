"""Resolve this isolated receiving snapshot, without changing its source owner."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
CONFLICT = re.compile(r"^<<<<<<< current-main-a64369f\n(.*?)^\|\|\|\|\|\|\| declared-base-262bf32\n(.*?)^=======\n(.*?)^>>>>>>> importer-snapshot\n", re.M | re.S)
resolutions = []

def resolve_app(match):
    current, base, importer = match.groups()
    number = len([r for r in resolutions if r['path'] == 'src/app.mjs']) + 1
    if number == 1:
        assert 'createStudyNotes' in current and 'mountDeckPicker' in importer
        result = current + importer
        purpose = 'Keep current study-note and option-order modules together with importer validation and picker modules.'
    elif number == 2:
        assert 'const optionOrders = new Map' in current and 'let concepts = deck.concepts;' in importer
        order_line = next(line for line in current.splitlines() if line.startswith('const optionOrders = '))
        result = importer.replace('let concepts = deck.concepts;\n', 'let concepts = deck.concepts;\n' + order_line.replace('const optionOrders', 'let optionOrders', 1) + '\n')
        purpose = 'Keep validated mutable deck state and initialize canonical option-index permutations for the active session.'
    elif number == 3:
        assert 'optionOrders.get(item.id)' in current and '${escapeHtml(item.prompt)}' in importer
        result = current.replace('${conceptLabel(item.concept).toUpperCase()}', '${escapeHtml(conceptLabel(item.concept).toUpperCase())}').replace('${item.prompt}', '${escapeHtml(item.prompt)}').replace('${item.options[choice]}', '${escapeHtml(item.options[choice])}')
        purpose = 'Keep shuffled canonical indices while retaining importer escaping for concept, prompt, and option text.'
    elif number == 4:
        assert 'const reflection = deck === bundledDeck' in importer and "const resetButton = root.querySelector('#reset-button');" in current
        notes_controls = current[current.index("  const resetButton = root.querySelector('#reset-button');"):]
        notes_controls = notes_controls.replace('() => location.reload()', '() => resetSession()')
        reset_line = "  root.querySelector('#reset-button').addEventListener('click', () => resetSession());\n"
        assert importer.count(reset_line) == 1
        result = importer.replace(reset_line, notes_controls)
        purpose = 'Keep deck-specific reflection and supplied attribution/license, append existing study-note controls, and reset the active imported deck locally.'
    else:
        raise AssertionError(f'Unexpected app conflict {number}')
    resolutions.append({'path':'src/app.mjs', 'conflict':number, 'resolution':purpose})
    return result

raw_app = (ROOT / 'merge-results/src__app.mjs.txt').read_text()
app, app_count = CONFLICT.subn(resolve_app, raw_app)
assert app_count == 4
reset_prefix = 'function resetSession(nextDeck = deck) {\n  deck = nextDeck;\n  concepts = deck.concepts;\n'
assert app.count(reset_prefix) == 1
app = app.replace(reset_prefix, reset_prefix + '  optionOrders = new Map(deck.items.map(item => [item.id, orderOptions(item.options.length)]));\n')
resolutions.append({'path':'src/app.mjs', 'outside_textual_conflicts':True, 'resolution':'Regenerate the session option map on resetSession, including imported/bundled deck changes. Practice and review do not reset it.'})

def resolve_builder(match):
    current, base, importer = match.groups()
    number = len([r for r in resolutions if r['path'] == 'tools/make_demo.py']) + 1
    if number == 1:
        assert 'session_export =' in current and 'deck_model =' in importer
        result = current + importer
        purpose = 'Load all current-main and importer modules into the dependency-free demo builder.'
    elif number == 2:
        lines = current.splitlines(keepends=True)
        assert lines[0].startswith('session_export = re.sub(') and lines[1].startswith('answer_order = re.sub(')
        assert '{core}\\n{review}\\n{deck_model}\\n{deck_picker}\\n{app}' in importer
        result = ''.join(lines[:2]) + importer.replace('{core}\\n{review}\\n{deck_model}\\n{deck_picker}\\n{app}', '{core}\\n{review}\\n{session_export}\\n{answer_order}\\n{deck_model}\\n{deck_picker}\\n{app}')
        purpose = 'Retain the importer loader count guard, import stripping, and less-than escaping; emit existing note/export and option-order modules in the bundle.'
    else:
        raise AssertionError(f'Unexpected builder conflict {number}')
    resolutions.append({'path':'tools/make_demo.py', 'conflict':number, 'resolution':purpose})
    return result

raw_builder = (ROOT / 'merge-results/tools__make_demo.py.txt').read_text()
builder, builder_count = CONFLICT.subn(resolve_builder, raw_builder)
assert builder_count == 2
for path, content in [('src/app.mjs', app), ('tools/make_demo.py', builder)]:
    assert not re.search(r'^(<<<<<<<|=======|>>>>>>>|\|\|\|\|\|\|\|)', content, re.M)
    (ROOT / 'composed' / path).write_text(content)

record = {
    'kind':'isolated-receiving-only-source-composition',
    'current_main':'a64369f84fae4cfd0b81aa3878cc11e2fa8d298c',
    'importer_declared_base':'262bf32aa09bcc62fb5a29c3b97d26bcdc31b27d',
    'importer_snapshot_manifest_sha256':'37eac06e7ffdbeb96e3448e6b9198ecb87aaaede680580ac26108dbaef13a955',
    'scope':'Only our receiving copy. No importer owner source, Git branch, or app-main mutation.',
    'unverified':'The importer checkout had no readable Git head. Its base is an issue declaration, not independently proven ancestry.',
    'conflicts':{'src/app.mjs':app_count,'tools/make_demo.py':builder_count},
    'resolutions':resolutions,
    'setup_failures':[
        {'failure':'Argument list too long (OS error 7) while submitting a 133 KB shell command','effect':'Execution did not start; no source mutation from the failed call. Replaced with bounded apply_patch writes and verified fetched Git blobs.'},
        {'failure':'git merge-file rejected the unsupported --label option','effect':'No resolved output accepted; reran with documented -L labels. Nonzero 4/2 statuses then denoted preserved app/builder conflict counts.'},
        {'failure':'The first local builder conflict callback omitted its replacement return, removing both conflict sections from the generated builder.','effect':'Caught immediately by generated size and builder readback before receiving/publication; exact failed builder/demo and diagnosis retained in failed-builder-return/. Corrected the callback, rebuilt and checked embedded script syntax.'}
    ],
    'resolved_files':[{'path':path, 'sha256':hashlib.sha256((ROOT/'composed'/path).read_bytes()).hexdigest()} for path in ['src/app.mjs','tools/make_demo.py']]
}
(ROOT / 'manual-resolutions.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
