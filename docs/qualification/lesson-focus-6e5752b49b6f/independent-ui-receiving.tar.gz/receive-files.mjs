import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const [original, current, evidence, output] = process.argv.slice(2);
assert.ok(original && current && evidence && output);
const sha = b => createHash('sha256').update(b).digest('hex');
const read = (root,p) => readFile(resolve(root,p));
const git = (root,...args) => execFileSync('git',['-C',root,...args], {maxBuffer:4*1024*1024});
const originalPin='3904c2f384d7f8fd4225d6ffbc2f4c89e6eae0ed';
const currentPin='ff99f4085b25d82227d33eb76d9f707e158a90e8';
const tree = (root,pin) => new Map(git(root,'ls-tree','-rz',pin).toString().split('\0').filter(Boolean).map(line => {
  const [meta,path]=line.split('\t'); const [mode,type,oid]=meta.split(' '); return [path,{mode,type,sha:oid}];
}));
const report={original:originalPin,current:currentPin,groups:[],limitations:[
 'The nine broad browser groups and learner operations were executed by github_integration on original 3904 source, not rerun by this receiver.',
 'This receiver independently reads the actual downloaded files, source hashes, source trees, and their learner notes.',
 'The peer actual browser separately challenges concept action identity on the exact original and corrected standalone bytes.'
]};
const receiptBytes=await read(evidence,'browser-r1/receiving.json');
const receipt=JSON.parse(receiptBytes);
assert.equal(receipt.source_commit,originalPin);assert.equal(receipt.passed,true);
assert.equal(sha(await read(evidence,'receive-focus-browser.mjs')),receipt.receiver_sha256);
for (const [path,want] of Object.entries(receipt.source_sha256)) {
 const bytes=await read(original,path);
 assert.equal(sha(bytes),want,path);
 assert.deepEqual(bytes,git(original,'show',originalPin+':'+path),path+' executed source pin');
}
report.groups.push({name:'author browser evidence and 17 executed source hashes admitted',passed:true,source_files:Object.keys(receipt.source_sha256).length,receiver_sha256:receipt.receiver_sha256,receipt_sha256:sha(receiptBytes)});
const validator=await import(pathToFileURL(resolve(original,'src/deck.mjs')).href);
const options=['First “choice”','Second <choice>','Third / choice','Fourth & choice','Fifth choice','Sixth choice'];
const make=(id,concept,prerequisites,answer)=>({id,concept,prerequisites,prompt:id+': literal <em data-focus-injection="yes">café</em>\nChoose a connection.',options:[...options],answer,explanation:id+': original explanation with "quotes"\nand a second line.',transfer:id+': explain the connection in your own words.'});
const expected={format:'recallweave-deck/1',title:'Focused café “connections”',attribution:'Original fixture author\nSource <em data-focus-injection="yes">text</em>',license:'Fixture only — permission text unchanged',concepts:['Application','Foundations','Comparison','Measurement'],items:[
 make('apply-a','Application',['Comparison'],2),
 make('measure','Measurement',['Foundations'],1),
 make('apply-b','Application',['Measurement'],0),
 make('foundation','Foundations',[],3),
 make('compare','Comparison',['Foundations'],4)
]};
const downloads=[];
for(const record of receipt.downloads) {
 const bytes=await read(evidence,'browser-r1/'+record.filename);
 assert.equal(bytes.length,record.bytes,record.filename);
 assert.equal(sha(bytes),record.sha256,record.filename);
 downloads.push({path:record.filename,bytes:bytes.length,sha256:sha(bytes)});
 if(record.filename.endsWith('.focus.json') && record.filename!=='exact-boundary.focus.json') {
   assert.deepEqual(JSON.parse(bytes),expected,record.filename+' literal independent expected data');
   assert.deepEqual(validator.parseDeck(bytes.toString()),expected,record.filename+' current checked admission');
 }
}
report.groups.push({name:'all eight actual download hashes and five full focused-deck snapshots match',passed:true,downloads,expected_item_order:expected.items.map(i=>i.id),concept_order:expected.concepts});
const boundary=await read(evidence,'browser-r1/exact-boundary.focus.json');
assert.equal(boundary.length,262144);
const boundaryDeck=validator.parseDeck(boundary.toString());
assert.equal(boundaryDeck.title,'T');assert.equal(boundaryDeck.items.length,30);
report.groups.push({name:'the actual 262144-byte download remains checked and matches its author-reported input bytes',passed:true,bytes:boundary.length,questions:boundaryDeck.items.length,sha256:sha(boundary)});
const notesA=(await read(evidence,'browser-r1/modular-study-notes.txt')).toString();
const notesB=(await read(evidence,'browser-r1/standalone-study-notes.txt')).toString();
const withoutSaved=s=>s.replace(/^Saved: .+$/m,'Saved: [timestamp]');
assert.equal(withoutSaved(notesA),withoutSaved(notesB));
assert.ok(notesA.startsWith('RecallWeave — study notes\n'+expected.title+'\nSaved: '));
assert.ok(notesA.includes('3 of 5 connections correct on the first try.'));
assert.ok(notesA.includes('Complete: 2 of 2 practice answers recorded; 2 correct on retry.'));
assert.ok(notesA.includes('DECK ATTRIBUTION\n'+expected.attribution+'\n'+expected.license+'\n'));
const learned=[['foundation',3],['compare',5],['measure',1],['apply-a',3],['apply-b',0]];
const blocks=notesA.split('REVIEW THE CONNECTIONS\n\n')[1].split('\n\nDECK ATTRIBUTION')[0].trim().split('\n\n');
assert.equal(blocks.length,5);
for(let n=0;n<learned.length;n++){
 const [id,choice]=learned[n],item=expected.items.find(i=>i.id===id),correct=choice===item.answer;
 let want=(n+1)+'. '+item.prompt+'\nConcept: '+item.concept+'\nYour first answer: '+options[choice]+'\nFirst try: '+(correct?'correct':'needs review')+'\nCorrect answer: '+options[item.answer]+'\nExplanation: '+item.explanation+'\nApply the idea: '+item.transfer;
 if(!correct)want+='\nPractice answer: '+options[item.answer]+'\nPractice result: correct on retry';
 assert.equal(blocks[n],want,id+' actual notes and canonical choice identity');
}
assert.ok(!notesA.includes('unrelated: literal')&&!notesA.includes('extension: literal'));
report.groups.push({name:'both actual learner notes preserve canonical answer/content identity and attributed provenance',passed:true,review_order:learned.map(x=>x[0]),first_correct:3,total:5,retries:2,identical_except_saved_timestamp:true});
const main=JSON.parse(gunzipSync(await readFile(new URL('./current-main-tree.json.gz',import.meta.url))));
assert.equal(main.sha,'c00bd1f31c353698957d2ebad311334536cdef98');assert.equal(main.truncated,false);
const leaves=main.tree.filter(e=>e.type!=='tree');
const candidate=tree(current,currentPin);
for(const leaf of leaves){
 if(leaf.path==='README.md')continue;
 assert.deepEqual(candidate.get(leaf.path),{mode:leaf.mode,type:leaf.type,sha:leaf.sha},'current main preservation: '+leaf.path);
}
const additions=[...candidate.keys()].filter(p=>!leaves.some(x=>x.path===p)).sort();
assert.deepEqual(additions,['focus.html','focus/focus.css','focus/index.html','src/course-focus-ui.mjs','src/course-focus.mjs','tests/course-focus-bundle.test.mjs','tests/course-focus.test.mjs','tools/make_focus.py'].sort());
const delta=git(current,'diff','--name-only','55fda259c0627e7f8d977a43b34e9eaf830f85ac',currentPin).toString().trim().split('\n').sort();
assert.deepEqual(delta,['focus.html','src/course-focus-ui.mjs']);
const qualifiedOriginal=tree(original,originalPin);
const inheritedConsumers=Object.keys(receipt.source_sha256).filter(p=>!p.startsWith('focus')&&!p.startsWith('src/course-focus')&&!p.startsWith('tools/make_focus'));
for(const p of inheritedConsumers)assert.deepEqual(candidate.get(p),qualifiedOriginal.get(p),p+' unchanged executed consumer');
const focusPaths=['README.md',...additions];
const sourceHashes={};
for(const p of focusPaths){
 const bytes=await read(current,p);
 assert.deepEqual(bytes,git(current,'show',currentPin+':'+p),p+' current on-disk pin');
 sourceHashes[p]=sha(bytes);
 if(!delta.includes(p))assert.deepEqual(bytes,git(original,'show',originalPin+':'+p),p+' unchanged original focus source');
}
assert.equal(sourceHashes['src/course-focus-ui.mjs'],'feacd13485dc4b40ef46f799a515f6f3e80a840068f87add919f3eee234d6394');
assert.equal(sourceHashes['focus.html'],'525a89161daa4cd0b40f7e291e801ec33d8afdc0f46bfb5e2adcc920e7e67c59');
report.groups.push({name:'all current-main non-README leaves and original browser consumers preserved; only numbered-reference UI and bundle differ',passed:true,base:main.sha,parent_leaves:leaves.length,preserved_parent_leaves:leaves.length-1,candidate_leaves:candidate.size,added:additions,existing_delta:['README.md'],r2_delta:delta,unchanged_browser_consumers:inheritedConsumers.length,current_source_sha256:sourceHashes});
const parity=execFileSync('python3',[resolve(current,'tools/make_focus.py'),'--check'],{encoding:'utf8'});
assert.ok(parity.includes('matches its modular sources'));
report.groups.push({name:'corrected standalone matches exact modular sources',passed:true,output:parity.trim()});
report.accepted=true;
report.receiver_sha256=sha(await readFile(new URL(import.meta.url)));
await writeFile(output,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({accepted:true,groups:report.groups.length,current:currentPin,downloads:downloads.length,main_leaves:leaves.length,preserved:leaves.length-1,consumers:inheritedConsumers.length,receipt_sha256:sha(await readFile(output))}));

