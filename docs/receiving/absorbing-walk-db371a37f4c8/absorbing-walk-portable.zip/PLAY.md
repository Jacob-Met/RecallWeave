# RecallWeave absorbing-walk portable lesson

Open courses/absorbing-walk-lab.html in an installed modern browser. No server, package manager, installation or network is required.

Choose the five inputs and Apply. Use the step controls to inspect exact first-arrival, cumulative absorption, survival and stopping-time results. Download experiment saves the complete applied analysis and selected step. Editing a model input retires the old result until a valid Apply.

For the learning workflow, use Download course in the lab. Open demo.html, choose that actual downloaded JSON file, read the preview and select Start this deck. Complete the lesson, review missed questions, practice them and download study notes. The learner is the unchanged RecallWeave original at commit698902f9c9c1d5c5023092b85b3632a7cb7a01ed, demo blobef7bc3e27e7f161d917ced6a457fad8822802f3f.

The lab also works when copied alone. Its companion-learner link needs this package layout. The course and guide are fixed original content; experiment controls do not alter them.

Qualification at packaging: exact arithmetic/course native checks have passed on Windows Node24.19 and transferred runtime/original inputs were re-admitted on Linux Node22.22.1. Independent mathematical/course receiving and actual browser consumption are in progress. An additive final qualification record will report their real outcomes without rewriting this historical package label.

Hypothetical finite independent-step probability model, not a real-world forecast or strategy. No browser storage or automatic save. Original lesson text: CC BY4.0. The guide cites the standard mathematical derivation.

Source ownership and public contract: https://github.com/Jacob-Met/RecallWeave/issues/206
