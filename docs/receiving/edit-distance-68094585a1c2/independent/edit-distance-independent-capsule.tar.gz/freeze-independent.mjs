import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const root='/tmp/hamon-levenshtein-independent-68094585a1c2', author='/tmp/hamon-levenshtein-68094585a1c2';
const hash=raw=>createHash('sha256').update(raw).digest('hex');
const pin=name=>{const raw=fs.readFileSync(path.join(root,name));return{path:name,bytes:raw.length,sha256:hash(raw)};};
const put=(name,value)=>fs.writeFileSync(path.join(root,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const inputs=['public-contract.json','course-questions-only.json'].map(name=>{const raw=fs.readFileSync(path.join(author,name));fs.writeFileSync(path.join(root,'original-'+name),raw,{flag:'wx'});return{path:path.join(author,name),bytes:raw.length,sha256:hash(raw)};});
assert.equal(inputs[0].sha256,'63bee3e8e1c988737aeda2b688e171bfe2859c7e965b7fae842b2ed29b371cbc');
const questions=JSON.parse(fs.readFileSync(path.join(root,'original-course-questions-only.json')));
const answers=[{"id":"edit-distance-one-substitution","expectedOptionIndex":2,"optionLabel":"C","reason":"Only the middle code point differs. A substitution attains cost 1; zero cost would require equal strings."},{"id":"edit-distance-suffix-shift","expectedOptionIndex":0,"optionLabel":"A","reason":"Deleting the first A leaves B exactly. The length difference forces at least one edit."},{"id":"edit-distance-empty-source","expectedOptionIndex":3,"optionLabel":"D","reason":"An empty source supplies no code points to match or substitute. DOG requires three separate insertions."},{"id":"edit-distance-not-transposition","expectedOptionIndex":1,"optionLabel":"B","reason":"A single substitution cannot fix both wrong positions; one insertion or deletion would change the length. Two substitutions attain cost 2, as do the two delete/match/insert alternatives."},{"id":"edit-distance-prefix-meaning","expectedOptionIndex":1,"optionLabel":"B","reason":"The first two source code points are AB and the first target code point is A. The cell describes those prefixes, not suffixes or a cost allowance."},{"id":"edit-distance-boundary-row","expectedOptionIndex":3,"optionLabel":"D","reason":"The empty-source row requires one insertion per target code point. The empty-target column requires one deletion per source code point."},{"id":"edit-distance-cell-cost","expectedOptionIndex":0,"optionLabel":"A","reason":"The unequal final pair gives diagonal cost 0+1=1. Above and left each give 1+1=2. Choose the least candidate, 1."},{"id":"edit-distance-why-recurrence","expectedOptionIndex":2,"optionLabel":"C","reason":"The last alignment column consumes both code points, only the source, or only the target. Those exhaust allowed moves. A cheaper preceding prefix would improve the complete alignment."},{"id":"edit-distance-repeat-tie","expectedOptionIndex":0,"optionLabel":"A","reason":"At final cell (2,1), diagonal matches source index 1 to target index 0 and is preferred. The remaining boundary move deletes source index 0. Reverse the trace: delete the first A, then match the second A."},{"id":"edit-distance-path-count","expectedOptionIndex":2,"optionLabel":"C","reason":"The three cost-2 paths are two substitutions; delete/match/insert; and insert/match/delete. Deleting and reinserting both strings costs 4. Position and gap choices distinguish the three paths."},{"id":"edit-distance-count-parents","expectedOptionIndex":3,"optionLabel":"D","reason":"Paths ending in distinct incoming edges are disjoint. Sum the two optimal predecessor counts, 2+3=5, and exclude the more expensive edge."},{"id":"edit-distance-normalization","expectedOptionIndex":2,"optionLabel":"C","reason":"One substitution would leave only one target code point; one insertion would retain U+00E9. An insertion and substitution produce the two unequal target code points at cost 2."},{"id":"edit-distance-emoji-units","expectedOptionIndex":1,"optionLabel":"B","reason":"The woman code point matches for zero. The joiner and microscope require two deletions; the code-point length difference proves the same lower bound."},{"id":"edit-distance-input-bound","expectedOptionIndex":0,"optionLabel":"A","reason":"Twenty-four valid supplementary emoji have 24 code points although 48 UTF-16 units. Twenty-five ASCII letters have 25 code points and exceed the bound."}];
assert.equal(questions.items.length,14);answers.forEach((a,i)=>assert.equal(a.id,questions.items[i].id));
put('expected-course-answers.json',{schema:'hamon.recallweave-edit-distance.independent-course-key/1',indexing:'Zero-based option indices; A-D labels supplemental.',answers,inputs});
const policy={maxCodePoints:24,unit:'Unicode code point',normalization:'none',trim:false,caseFolding:false,costs:{match:0,insert:1,delete:1,substitute:1},tieOrder:['diagonal','delete','insert'],countMeaning:'optimal monotone alignment paths'};
put('public-schema-clarification.json',{origin:'Author supplied additive public representation clarification by coordination before candidate access.',cells:'Two-dimensional row-major cells[i][j], same dimensions as matrix.',gaps:'null for the gap side source/target and sourceIndex/targetIndex.',policy,operations:['match','substitute','delete','insert'],sourcePoints:'Ordered Unicode code points from the literal source string; targetPoints analogously.',format:'recallweave-edit-distance/1'});
const rank=op=>op==='delete'?1:op==='insert'?2:0;
const better=(a,b)=>{if(b===null)return true;for(let i=a.length-1,j=b.length-1;i>=0&&j>=0;i--,j--){const d=rank(a[i].operation)-rank(b[j].operation);if(d)return d<0;}return a.length<b.length;};
const makeStep=(S,T,i,j,op)=>({operation:op,sourceIndex:op==='insert'?null:i,targetIndex:op==='delete'?null:j,source:op==='insert'?null:S[i],target:op==='delete'?null:T[j],cost:op==='match'?0:1,from:[i,j],to:[i+(op==='insert'?0:1),j+(op==='delete'?0:1)]});
function record(source,target,matrix,counts,selected){
 const S=Array.from(source),T=Array.from(target),m=S.length,n=T.length;
 const cells=matrix.map((row,i)=>row.map((cost,j)=>{
  const candidates=[];
  if(i&&j){const stepCost=S[i-1]===T[j-1]?0:1,totalCost=matrix[i-1][j-1]+stepCost;candidates.push({operation:stepCost?'substitute':'match',from:[i-1,j-1],stepCost,totalCost,optimal:totalCost===cost});}
  if(i){const totalCost=matrix[i-1][j]+1;candidates.push({operation:'delete',from:[i-1,j],stepCost:1,totalCost,optimal:totalCost===cost});}
  if(j){const totalCost=matrix[i][j-1]+1;candidates.push({operation:'insert',from:[i,j-1],stepCost:1,totalCost,optimal:totalCost===cost});}
  if(i||j)assert.equal(candidates.filter(c=>c.optimal).reduce((a,c)=>a+BigInt(counts[c.from[0]][c.from[1]]),0n).toString(),counts[i][j]);
  return{i,j,cost,optimalPathCount:counts[i][j],candidates};
 }));
 return{format:'recallweave-edit-distance/1',policy:structuredClone(policy),source,target,sourcePoints:S,targetPoints:T,distance:matrix[m][n],optimalPathCount:counts[m][n],matrix,cells,alignment:selected.map((s,i)=>({step:i+1,...s}))};
}
function exhaustive(source,target){
 const S=Array.from(source),T=Array.from(target),m=S.length,n=T.length;
 const matrix=Array.from({length:m+1},()=>Array(n+1).fill(Infinity)),counts=Array.from({length:m+1},()=>Array(n+1).fill(0n)),paths=Array.from({length:m+1},()=>Array(n+1).fill(null));
 let visitedPrefixPaths=0;const selected=[];
 function visit(i,j,cost){
  visitedPrefixPaths++;
  if(cost<matrix[i][j]){matrix[i][j]=cost;counts[i][j]=1n;paths[i][j]=selected.slice();}
  else if(cost===matrix[i][j]){counts[i][j]++;if(better(selected,paths[i][j]))paths[i][j]=selected.slice();}
  const moves=[];if(i<m&&j<n)moves.push(S[i]===T[j]?'match':'substitute');if(i<m)moves.push('delete');if(j<n)moves.push('insert');
  for(const op of moves){const s=makeStep(S,T,i,j,op);selected.push(s);visit(s.to[0],s.to[1],cost+s.cost);selected.pop();}
 }
 visit(0,0,0);
 return{record:record(source,target,matrix,counts.map(r=>r.map(String)),paths[m][n]),oracle:{kind:'Unpruned enumeration of all monotone prefix paths; minimum counts accumulated directly, canonical path chosen by reverse operation-rank lexicographic order.',visitedPrefixPaths}};
}
function choose(n,k){k=Math.min(k,n-k);let r=1n;for(let i=1;i<=k;i++)r=r*BigInt(n-k+i)/BigInt(i);return r;}
function closed(source,target,matching){
 const S=Array.from(source),T=Array.from(target),m=S.length,n=T.length;
 if(matching)assert(S.concat(T).every(c=>c===S[0]));else assert(!S.some(c=>T.includes(c)));
 const matrix=Array.from({length:m+1},(_,i)=>Array.from({length:n+1},(_,j)=>matching?Math.abs(i-j):Math.max(i,j))),counts=matrix.map((row,i)=>row.map((_,j)=>choose(Math.max(i,j),Math.min(i,j)).toString()));
 const moves=[...Array(Math.max(m-n,0)).fill('delete'),...Array(Math.max(n-m,0)).fill('insert'),...Array(Math.min(m,n)).fill(matching?'match':'substitute')];
 let i=0,j=0;const selected=moves.map(op=>{const s=makeStep(S,T,i,j,op);[i,j]=s.to;return s;});
 return{record:record(source,target,matrix,counts,selected),oracle:{kind:'Closed form for every prefix: '+(matching?'equal repeated code points, cost abs(i-j)':'disjoint alphabets, cost max(i,j)')+'; optimal count C(max(i,j),min(i,j)), choosing shorter-side positions on the longer side. Backward diagonal priority puts all required gaps first in forward order.'}};
}
const seeds=[{"id":"rotated-long-word","source":"BANANA","target":"ANANAS","distance":2,"count":"1","ops":["delete","match","match","match","match","match","insert"]},{"id":"unequal-prefix-parent-counts","source":"aba","target":"baa","distance":2,"count":"4","ops":["substitute","substitute","match"]},{"id":"deletion-before-insertion-backtrace","source":"aba","target":"bab","distance":2,"count":"2","ops":["insert","match","match","delete"]},{"id":"three-repeated-source-positions","source":"xxx","target":"xx","distance":1,"count":"3","ops":["delete","match","match"]},{"id":"supplementary-gap-indices","source":"😀x😀","target":"😀😀","distance":1,"count":"1","ops":["match","delete","match"]},{"id":"supplementary-substitution-tie","source":"😀x","target":"y😀","distance":2,"count":"2","ops":["substitute","substitute"]},{"id":"decomposed-to-precomposed","source":"á","target":"á","distance":2,"count":"2","ops":["delete","substitute"]},{"id":"nul-whitespace-literal","source":"\u0000 A\n","target":"\u0000A \n","distance":2,"count":"3","ops":["match","substitute","substitute","match"]},{"id":"literal-markup-identical","source":"<&>","target":"<&>","distance":0,"count":"1","ops":["match","match","match"]},{"id":"case-folding-is-absent","source":"MiXeD","target":"mixed","distance":3,"count":"1","ops":["substitute","match","substitute","match","substitute"]},{"id":"empty-with-supplementary-and-LF","source":"","target":"🧭\n","distance":2,"count":"1","ops":["insert","insert"]},{"id":"supplementary-same-high-surrogate","source":"𐐀a","target":"𐐁a","distance":1,"count":"1","ops":["substitute","match"]}];
const cases=seeds.map(c=>{const e=exhaustive(c.source,c.target);assert.equal(e.record.distance,c.distance,c.id);assert.equal(e.record.optimalPathCount,c.count,c.id);assert.deepEqual(e.record.alignment.map(x=>x.operation),c.ops,c.id);return{id:c.id,manual:{distance:c.distance,optimalPathCount:c.count,operations:c.ops},...e};});
for(const[id,source,target,matching]of[['maximum-supplementary-repeat-deletion','😀'.repeat(24),'😀'.repeat(12),true],['maximum-supplementary-repeat-insertion','😀'.repeat(12),'😀'.repeat(24),true],['maximum-decomposed-disjoint-alphabets','a\u0301'.repeat(12),'á'.repeat(12),false]]){
 const e=closed(source,target,matching);assert.equal(e.record.optimalPathCount,'2704156');assert.equal(e.record.distance,matching?12:24);cases.push({id,...e});
}
put('expected-model-records.json',{schema:'hamon.recallweave-edit-distance.independent-model-oracle/1',caseCount:cases.length,cases});
const refusals=[],both=(id,value)=>{refusals.push({id:id+'-source',source:value,target:{kind:'string',value:'x'}});refusals.push({id:id+'-target',source:{kind:'string',value:'x'},target:value});};
for(const kind of['undefined','null','number','boolean','array','object','boxed-string','symbol','bigint'])both('nonstring-'+kind,{kind});
for(const[id,units]of[['lone-high',[0xd800]],['lone-low',[0xdc00]],['high-before-ASCII',[0xd800,0x61]],['low-after-ASCII',[0x61,0xdc00]],['high-before-valid-pair',[0xd800,0xd800,0xdc00]],['low-after-valid-pair',[0xd83d,0xde00,0xdfff]]])both('malformed-UTF16-'+id,{kind:'code-units',units});
for(const[id,value]of[['ASCII25','Z'.repeat(25)],['supplementary25','😀'.repeat(25)],['space-after-supplementary24','😀'.repeat(24)+' ']])both('over-bound-'+id,{kind:'string',value});
assert.equal(refusals.length,36);
put('expected-refusals.json',{schema:'hamon.recallweave-edit-distance.independent-refusals/1',expectation:'Every case throws before producing a result; message/class are not prescribed. Both input roles are separate. Malformed UTF-16 is constructed natively from numeric code units, not passed through tool JSON.',cases:refusals});
const files=['original-public-contract.json','original-course-questions-only.json','expected-course-answers.json','public-schema-clarification.json','expected-model-records.json','expected-refusals.json'].map(pin);
const receipt={schema:'hamon.recallweave-edit-distance.independent-contract-before-candidate/1',identity:'estate-68094585a1c2 / scope_receiving',issue:'https://github.com/Jacob-Met/RecallWeave/issues/141',frozenAt:new Date().toISOString(),node:process.version,
 accessBoundary:'Only public contract (including public manual examples), question-only file and additive public representation clarification accessed. No candidate implementation, answer key, explanations, guide, authored tests or browser receiver accessed.',
 basis:'Independently solved questions and fifteen distinct full model records. Twelve small cases use unpruned path enumeration; three maximum-length cases use binomial closed forms. No candidate import or execution while freezing.',
 semanticChecks:['Exact public record fields and policy','Every prefix cost/count and candidate move/cost/optimal flag in fixed order','Canonical forward alignment, exact code-point/gap indices and literal values','Position/gap path counting excludes nonoptimal predecessor edges','Maximum supplementary boundaries; no normalization/trim/case folding','Thirty-six strict refusals across both input positions'],
 questionCount:answers.length,questionChoices:answers.map(a=>a.expectedOptionIndex),modelCases:cases.length,refusalCases:refusals.length,inputs,files,freezeScript:pin('freeze-independent.mjs'),
 priorTransportFailure:'First remote write_file failed in path validation after 10 seconds; read-only own-namespace custody showed zero files. No freeze script or receiving process ran then. Raw failure is retained separately.',
 limitations:'Independent native acceptance is separate from actual browser and unchanged-learner receiving. No upstream 39-test suite repeated. Decimal counts are checked exactly; no demonstrated count is claimed to exceed Number.MAX_SAFE_INTEGER.'};
put('contract-before-candidate.json',receipt);
const summary={contract:pin('contract-before-candidate.json'),files,questionCount:answers.length,choices:receipt.questionChoices,cases:cases.map(c=>({id:c.id,distance:c.record.distance,count:c.record.optimalPathCount,operations:c.record.alignment.map(s=>s.operation)})),refusals:refusals.length};
put('freeze-summary.json',summary);
console.log(JSON.stringify(summary,null,2));
