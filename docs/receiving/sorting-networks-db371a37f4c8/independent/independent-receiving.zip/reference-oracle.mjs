import assert from 'node:assert/strict';
export function trace(configuration, source=configuration.values) {
  const current=source.map(value=>Object.is(value,-0)?0:value),input=[...current],steps=[];
  for(let k=0;k<configuration.comparators.length;k++){
    const pair=[...configuration.comparators[k]],a=pair[0]-1,b=pair[1]-1,before=[...current];
    const swapped=current[a]>current[b];
    if(swapped){const temporary=current[a];current[a]=current[b];current[b]=temporary;}
    steps.push({index:k+1,pair,before,after:[...current],swapped});
  }
  let firstInversion=null;
  for(let i=1;i<current.length;i++)if(current[i-1]>current[i]){firstInversion=[i,i+1];break;}
  return {input,steps,output:[...current],sorted:firstInversion===null,firstInversion};
}
export function analyze(c){
  const configuration={wires:c.wires,values:c.values.map(v=>Object.is(v,-0)?0:v),comparators:c.comparators.map(p=>[...p])};
  const cases=[];
  for(let ordinal=0;ordinal<2**c.wires;ordinal++){
    const values=Array.from({length:c.wires},(_,i)=>Math.floor(ordinal/(2**(c.wires-i-1)))%2);
    cases.push({ordinal,...trace(configuration,values)});
  }
  const failingOrdinals=cases.filter(row=>!row.sorted).map(row=>row.ordinal),total=cases.length,failed=failingOrdinals.length;
  return {format:"recallweave-sorting-network-observation/1",configuration,authored:trace(configuration),binary:{total,passed:total-failed,failed,sortsAll:failed===0,failingOrdinals,cases}};
}
export function insertionConfiguration(n){
  const comparators=[];for(let right=2;right<=n;right++)for(let wire=right;wire>=2;wire--)comparators.push([wire-1,wire]);
  return {wires:n,values:Array.from({length:n},(_,i)=>n-i),comparators};
}
export function* permutations(values){
  if(values.length===0){yield [];return;}
  for(let i=0;i<values.length;i++)for(const tail of permutations(values.filter((_,j)=>j!==i)))yield [values[i],...tail];
}
export function selfCheck(literals) {
  const observations=[];
  for(const test of literals){
    const observed=analyze(test.configuration);
    assert.deepEqual([observed.authored.input,...observed.authored.steps.map(s=>s.after)],test.vectors,test.name+' full literal states');
    assert.deepEqual(observed.authored.steps.map(s=>s.swapped),test.swapped,test.name+' literal swap flags');
    if(test.binary)for(const [field,value] of Object.entries(test.binary)){
      if(field==='failingInputs')assert.deepEqual(observed.binary.cases.filter(r=>!r.sorted).map(r=>r.input),value);
      else if(field==='failingOutputs')assert.deepEqual(observed.binary.cases.filter(r=>!r.sorted).map(r=>r.output),value);
      else assert.deepEqual(observed.binary[field],value,test.name+' '+field);
    }
    observations.push({name:test.name,observation:observed});
  }
  const permutationGroups=[];
  for(let n=2;n<=6;n++){
    const c=insertionConfiguration(n);let count=0;
    for(const vector of permutations(Array.from({length:n},(_,i)=>i*3-7))){
      assert.deepEqual(trace(c,vector).output,[...vector].sort((a,b)=>a-b));count++;
    }
    assert.equal(analyze(c).binary.failed,0);permutationGroups.push({wires:n,comparators:c.comparators.length,permutations:count});
  }
  return {observations,permutationGroups};
}
