import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {reference, assertResult, assertFrozen, descriptorSnapshot} from './rational-oracle.mjs';

const target = process.argv[2];
assert.ok(target, 'Pass the separately frozen candidate module path');
const before = readFileSync(target);
const sha256 = b => createHash('sha256').update(b).digest('hex');
const mod = await import(pathToFileURL(target).href);
const groups = [];
function group(name, f) { const detail = f(); groups.push({name, passed: true, detail}); }
try {
  assert.equal(typeof mod.analyzeLinkage, 'function');
  group('all102 exact phase/percent results and immutable input custody', () => {
    let count = 0;
    for (const phase of ['coupling', 'repulsion']) for (let p = 0; p <= 50; p++) {
      const input = Object.freeze({phase, recombinationPercent: p});
      const snapshot = descriptorSnapshot(input);
      const out = mod.analyzeLinkage(input);
      assertResult(out, phase, p);
      assertFrozen(out);
      assert.notEqual(out.input, input);
      assert.deepEqual(descriptorSnapshot(input), snapshot);
      assert.deepEqual(out.assumptions, mod.LINKAGE_ASSUMPTIONS);
      count++;
    }
    assertFrozen(mod.LINKAGE_ASSUMPTIONS);
    return {cases: count};
  });
  group('hand fixtures, phase reversal, allele marginals and endpoints', () => {
    const examples = [
      ['coupling', 0, [[1,2],[0,1],[0,1],[1,2]]],
      ['repulsion', 0, [[0,1],[1,2],[1,2],[0,1]]],
      ['coupling', 20, [[2,5],[1,10],[1,10],[2,5]]],
      ['repulsion', 14, [[7,100],[43,100],[43,100],[7,100]]],
      ['coupling', 37, [[63,200],[37,200],[37,200],[63,200]]],
      ['repulsion', 49, [[49,200],[51,200],[51,200],[49,200]]],
      ['coupling', 50, [[1,4],[1,4],[1,4],[1,4]]],
      ['repulsion', 50, [[1,4],[1,4],[1,4],[1,4]]],
    ];
    for (const [phase,p,expected] of examples) {
      const out=mod.analyzeLinkage({phase,recombinationPercent:p});
      assert.deepEqual(out.rows.map(r=>[r.probability.numerator,r.probability.denominator]),expected);
      assert.deepEqual(Object.values(out.marginals),Array.from({length:4},()=>({numerator:1,denominator:2})));
    }
    for (const p of [0,1,17,37,49,50]) {
      const c=mod.analyzeLinkage({phase:'coupling',recombinationPercent:p});
      const r=mod.analyzeLinkage({phase:'repulsion',recombinationPercent:p});
      assert.deepEqual(c.rows.map(x=>x.probability), [r.rows[1],r.rows[0],r.rows[3],r.rows[2]].map(x=>x.probability));
      assert.deepEqual(c.totals,r.totals);
      assert.ok(c.rows.every((x,i)=>x.kind!==r.rows[i].kind));
    }
    return {handCases: examples.length, metamorphicCases: 6};
  });
  group('null prototype, nonenumerable own data, negative zero and detached result', () => {
    const input=Object.create(null);
    Object.defineProperties(input,{phase:{value:'repulsion',enumerable:false,writable:true,configurable:true},
      recombinationPercent:{value:-0,enumerable:false,writable:true,configurable:true}});
    const snapshot=descriptorSnapshot(input);
    const out=mod.analyzeLinkage(input);
    assertResult(out,'repulsion',0); assertFrozen(out);
    assert.equal(Object.is(out.input.recombinationPercent,-0),false);
    assert.deepEqual(descriptorSnapshot(input),snapshot);
    input.phase='coupling';input.recombinationPercent=50;
    assertResult(out,'repulsion',0);
    assert.throws(()=>{out.rows[0].probability.numerator=100;},TypeError);
    assert.throws(()=>{out.parent.homologs.push('xx');},TypeError);
    return {cases: 1};
  });
  group('malformed strict record and value refusals without coercion', () => {
    const invalid=[undefined,null,false,0,'coupling',[],()=>{},new Date(),
      {},{phase:'coupling'},{recombinationPercent:20},
      Object.create({phase:'coupling',recombinationPercent:20}),
      Object.assign(Object.create({unrelated:true}),{phase:'coupling',recombinationPercent:20}),
      {phase:'coupling',recombinationPercent:20,extra:0}];
    for(const phase of ['Coupling','repulsion ','AB/ab','',null,1,{},new String('coupling')])
      invalid.push({phase,recombinationPercent:20});
    for(const p of [-1,51,0.5,49.5,NaN,Infinity,-Infinity,'20',null,undefined,true,20n,new Number(20)])
      invalid.push({phase:'coupling',recombinationPercent:p});
    const extra= {phase:'coupling',recombinationPercent:20};
    Object.defineProperty(extra,'hidden',{value:1});invalid.push(extra);
    const sym={phase:'coupling',recombinationPercent:20,[Symbol('extra')]:1};invalid.push(sym);
    let coercions=0;
    invalid.push({phase:'coupling',recombinationPercent:{valueOf(){coercions++;return 20;}}});
    for(const input of invalid) {
      const snapshot=input && (typeof input==='object'||typeof input==='function') ? descriptorSnapshot(input):null;
      assert.throws(()=>mod.analyzeLinkage(input));
      if(snapshot) assert.deepEqual(descriptorSnapshot(input),snapshot);
    }
    assert.equal(coercions,0);
    return {cases:invalid.length};
  });
  group('accessor fields refuse without evaluating their getter', () => {
    let reads=0;let cases=0;
    for(const key of ['phase','recombinationPercent']) {
      const input={phase:'coupling',recombinationPercent:20};
      Object.defineProperty(input,key,{get(){reads++;throw new Error('getter must not run');},enumerable:true});
      const snapshot=descriptorSnapshot(input);
      assert.throws(()=>mod.analyzeLinkage(input));
      assert.equal(reads,0);assert.deepEqual(descriptorSnapshot(input),snapshot);cases++;
    }
    return {cases, getterReads:reads};
  });
  const after=readFileSync(target);assert.deepEqual(after,before);
  console.log(JSON.stringify({schema:'recallweave-linkage-independent-model-receiving/1',passed:true,
    node:process.version,target,sourceSha256:sha256(before),sourceUnchanged:true,groups},null,2));
} catch(error) {
  console.log(JSON.stringify({schema:'recallweave-linkage-independent-model-receiving/1',passed:false,
    node:process.version,target,sourceSha256:sha256(before),groups,
    failure:{name:error.name,message:error.message,stack:error.stack}},null,2));
  process.exitCode=1;
}
