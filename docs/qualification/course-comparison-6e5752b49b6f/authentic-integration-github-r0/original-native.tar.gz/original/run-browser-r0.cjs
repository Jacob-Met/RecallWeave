const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),c=require('node:crypto'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
const root=__dirname,sha=b=>c.createHash('sha256').update(b).digest('hex'),git=b=>c.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex');
const pin=p=>{const b=fs.readFileSync(p),s=fs.statSync(p);return{path:p,bytes:b.length,sha256:sha(b),gitBlob:git(b),mtimeMs:s.mtimeMs};};
const report={format:'recall180-browser-controller/1',at:new Date().toISOString(),pid:process.pid,accepted:false};
try{
 assert.equal(process.version,'v24.14.0');assert.equal(os.userInfo().username,'jacob');
 const manifestPath=path.join(root,'browser-manifest-r0.json'),m=JSON.parse(fs.readFileSync(manifestPath));assert.equal(pin(manifestPath).sha256,'b3d72b0b38823752fa25a9e68a1deeab84a03f88ecb5e8b3c25c89c4031d44e2');
 const receiver=path.join(root,'receive-browser-r0.mjs');assert.equal(pin(receiver).sha256,'3e49b09afa1b774ae30a2c35a27a0c1eda75250a8ac4e679fe8068c670f92c28');
 assert.equal(pin(path.join(root,'owned-chrome-observer.mjs')).sha256,'42ee5938f9eaea96b8f494e71c21f624a936b315580a15b33d14bfe19c1bdb8e');
 assert.equal(pin(process.execPath).sha256,'63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088');
 const output=path.join(root,'browser-r0');assert.ok(!fs.existsSync(output));const st=fs.statfsSync(root);report.resources={freeMemory:os.freemem(),freeDisk:Number(st.bavail)*Number(st.bsize)};assert.ok(report.resources.freeMemory>=2*1024**3);assert.ok(report.resources.freeDisk>=1024**3);
 const paths=[__filename,manifestPath,receiver,path.join(root,'owned-chrome-observer.mjs'),path.join(root,'browser-protocol-r0.json'),...Object.keys(m.sources).map(x=>path.join(root,'source-r0',x))];report.before=paths.map(pin);
 const args=['--max-old-space-size=256',receiver,'--root',path.join(root,'source-r0'),'--browser',m.runtime.chrome.path,'--output',output,'--manifest',manifestPath,'--manifest-sha256','b3d72b0b38823752fa25a9e68a1deeab84a03f88ecb5e8b3c25c89c4031d44e2','--owner-git-blob','680e96107af0264c4b65a3ae26d84f803af0a27a','--receiver-sha256','3e49b09afa1b774ae30a2c35a27a0c1eda75250a8ac4e679fe8068c670f92c28'];report.argv=[process.execPath,...args];
 const t=Date.now(),r=spawnSync(process.execPath,args,{encoding:'utf8',windowsHide:true,timeout:150000,maxBuffer:2*1024**2});report.process={pid:r.pid,status:r.status,signal:r.signal,error:r.error?String(r.error):null,elapsedMs:Date.now()-t};
 fs.writeFileSync(path.join(root,'browser-r0.stdout'),r.stdout??'',{flag:'wx'});fs.writeFileSync(path.join(root,'browser-r0.stderr'),r.stderr??'',{flag:'wx'});report.stdout=pin(path.join(root,'browser-r0.stdout'));report.stderr=pin(path.join(root,'browser-r0.stderr'));
 report.after=paths.map(pin);assert.deepEqual(report.after,report.before);report.inputsUnchanged=true;
 if(fs.existsSync(path.join(output,'receiving.json'))){report.receipt=pin(path.join(output,'receiving.json'));const inner=JSON.parse(fs.readFileSync(path.join(output,'receiving.json'),'utf8'));report.inner={status:inner.status,checks:inner.checks.length,artifacts:inner.artifacts.length,browserPid:inner.browserPid,profileRemoved:inner.profileRemoved,closure:inner.browserClosure};}
 assert.equal(r.status,0);assert.equal(r.signal,null);assert.equal(report.inner?.status,'passed');report.accepted=true;
}catch(e){report.error=e.stack??String(e);process.exitCode=1;}
fs.writeFileSync(path.join(root,'browser-execution-r0.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({accepted:report.accepted,process:report.process,inner:report.inner,receipt:report.receipt,error:report.error}));
