import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {computeTrace,absorbingStates,observationJSON} from './original/courses/markov-chains-core.mjs';
import {parseDeck,serializeDeck} from './original/src/deck.mjs';
const R=path.dirname(fileURLToPath(import.meta.url));
const manifest=JSON.parse(fs.readFileSync(path.join(R,'original-admission-input.json'),'utf8'));
const oracleBytes=fs.readFileSync(path.join(R,'finite-walk-oracle-r1.json'));
const sha=b=>createHash('sha256').update(b).digest('hex');
assert.equal(sha(oracleBytes),'a931f2fad9a349ce18a8a1a7d5278588442569768095bc47c649b3a72380aef3');
const fixtures=JSON.parse(oracleBytes).fixtures;
const before=manifest.files.map(e=>({path:e.path,sha256:sha(fs.readFileSync(path.join(R,'original',e.path)))}));
for(const e of before)assert.equal(e.sha256,manifest.files.find(x=>x.path===e.path).sha256);
const checks=[];
for(const [name,percent] of [['original-percent-bridge',75],['original-fair-bridge',50]]){
 const input={matrix:[[100,0,0],[100-percent,0,percent],[0,0,100]],initial:[0,100,0]};
 const expected=fixtures.find(f=>f.name===name).analysis;
 const actual=computeTrace(input,5);
 for(let t=0;t<=5;t++){
  const exp=expected.frames[t];
  assert.deepEqual(actual.trace[t].probabilities,exp.distribution.map(f=>Number(f.numerator)/Number(f.denominator)));
  if(t)for(let i=0;i<3;i++)for(let j=0;j<3;j++){
   const e=exp.contributions.find(e=>e.from===i&&e.to===j);
   assert.equal(actual.trace[t].contributions[i][j],e?Number(e.mass.numerator)/Number(e.mass.denominator):0);
  }
 }
 assert.deepEqual(absorbingStates(input),['A','C']);
 const text=observationJSON(actual,5);assert.ok(text.endsWith('\n'));const exported=JSON.parse(text);
 assert.deepEqual(exported.transitionPercent,input.matrix);assert.equal(exported.selectedStep,5);assert.equal(exported.trace.length,6);
 checks.push({name,frames:6,allDistributionsAndContributionsExact:true,originalExportRecomputesAppliedInput:true});
}
assert.throws(()=>computeTrace({matrix:[[100,0,0],[25,0,74],[0,0,100]],initial:[0,100,0]},5));
checks.push({name:'original invalid row is refused, never normalized',pass:true});
const courseBytes=fs.readFileSync(path.join(R,'original/courses/markov-chains.json'));
const deck=parseDeck(courseBytes.toString('utf8'));assert.equal(deck.items.length,14);assert.equal(deck.concepts.length,5);
assert.deepEqual(parseDeck(serializeDeck(deck)),deck);
checks.push({name:'original course admitted by unchanged parser and serialization',questions:14,concepts:5,sha256:sha(courseBytes)});
for(const e of before)assert.equal(sha(fs.readFileSync(path.join(R,'original',e.path))),e.sha256);
const receipt={at:new Date().toISOString(),checks,all23OriginalExact:true,oracleSha256:sha(oracleBytes),contractSha256:sha(fs.readFileSync(path.join(R,'CONTRACT.md'))),node:process.version,candidateRead:false,browserClaim:false};
const target=path.join(R,'original-native-receipt.json');assert.equal(fs.existsSync(target),false);fs.writeFileSync(target,JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
