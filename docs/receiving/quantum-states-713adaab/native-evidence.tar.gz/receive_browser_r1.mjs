import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFile,writeFile,mkdir,mkdtemp,readdir,lstat,statfs} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import os from 'node:os';

const root=resolve('/Users/me/Developer/recallweave-quantum-states-20261009-713adaab');
const source=join(root,'candidate'), output=join(root,'receiving','browser-r1');
const executable='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const hash=b=>createHash('sha256').update(b).digest('hex');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const free=async p=>{const s=await statfs(p);return s.bavail*s.bsize;};
async function sourceMap(){
 const map={};
 async function walk(dir,rel=''){
  for(const name of (await readdir(dir)).sort()){
   const path=join(dir,name),key=rel?rel+'/'+name:name,s=await lstat(path,{bigint:true});
   assert.ok(!s.isSymbolicLink(),'No source link: '+key);
   if(s.isDirectory())await walk(path,key);
   else if(s.isFile())map[key]={bytes:Number(s.size),sha256:hash(await readFile(path)),mtime_ns:String(s.mtimeNs)};
  }
 }
 await walk(source);return map;
}
const capacity={home_available:await free(root),tmp_available:await free('/tmp'),memory_available:os.freemem(),load:os.loadavg(),cpus:os.cpus().length};
await mkdir(output);
const report={schema:'recallweave.quantum-browser-receiving/1',started:new Date().toISOString(),source,executable,capacity,
 checks:[],pageRequests:[],pageErrors:[],downloads:[],status:'preflight',browser_started:false,
 limits:['Native direct-file Chromium receiving, not a browser matrix or full accessibility/print qualification.','Keyboard Enter activates action buttons; select changes use actual DOM change handlers, not a native select-popup inspection.','Page-local request events do not prove browser-wide zero networking. Browser startup netlog and stderr remain private.','Screenshots show selected viewports; DOM width checks cover the target document.','Actual learner estimates and study notes are model behavior, not learning efficacy.']};
await writeFile(join(output,'intent.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
if(capacity.home_available<128*1024**2||capacity.tmp_available<128*1024**2||capacity.memory_available<1024**3||capacity.load[0]>Math.max(8,capacity.cpus*1.5)){
 report.status='held_before_browser_launch';report.reason='128MiB HOME/TMP,1GiB memory and bounded load admission not met';
 await writeFile(join(output,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({status:report.status,capacity,report:join(output,'report.json'),sha256:hash(await readFile(join(output,'report.json')))}));process.exitCode=2;
}else{
 const before=await sourceMap();report.before=before;
 const frozen=JSON.parse(await readFile(join(root,'candidate-source-r1.json'),'utf8'));
 for(const f of frozen.files)assert.equal(before[f.path]?.sha256,f.sha256,'exact frozen source '+f.path);
 assert.equal(Object.keys(before).length,frozen.files.length);
 const raw=await readFile(join(source,'courses/quantum-states.json')),guide=await readFile(join(source,'courses/quantum-states.md'));
 const deck=JSON.parse(raw),byPrompt=new Map(deck.items.map(x=>[x.prompt,x]));
 const downloadPath=join(output,'downloads');await mkdir(downloadPath);
 const temp=await mkdtemp('/tmp/qs-'),profile=join(temp,'p'),netlog=join(temp,'netlog.private.json');
 report.private_temporary={path:temp,uid:(await lstat(temp)).uid,mode:(await lstat(temp)).mode&0o777};
 let browser,sessionId,sequence=0,buffer=Buffer.alloc(0),browserStderr='',deadline;
 const pending=new Map(),completed=new Map();
 function command(method,params={},scoped=true){
  const id=++sequence;
  return new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>{pending.delete(id);reject(new Error('CDP timeout: '+method));},10000);
   pending.set(id,{resolve,reject,timer});
   browser.stdio[3].write(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})})+'\0');
  });
 }
 function receive(chunk){
  buffer=Buffer.concat([buffer,chunk]);
  let end;
  while((end=buffer.indexOf(0))>=0){
   const body=buffer.subarray(0,end);buffer=buffer.subarray(end+1);if(!body.length)continue;
   const msg=JSON.parse(body.toString());
   if(msg.id&&pending.has(msg.id)){const p=pending.get(msg.id);pending.delete(msg.id);clearTimeout(p.timer);msg.error?p.reject(new Error(JSON.stringify(msg.error))):p.resolve(msg.result);}
   else if(msg.method==='Network.requestWillBeSent')report.pageRequests.push({url:msg.params.request.url,type:msg.params.type});
   else if(msg.method==='Runtime.exceptionThrown')report.pageErrors.push(msg.params.exceptionDetails.exception?.description??msg.params.exceptionDetails.text);
   else if(msg.method==='Browser.downloadWillBegin')completed.set(msg.params.guid,{guid:msg.params.guid,name:msg.params.suggestedFilename});
   else if(msg.method==='Browser.downloadProgress'&&msg.params.state==='completed'){const d=completed.get(msg.params.guid);if(d)d.complete=true;}
  }
 }
 async function evaluate(expression){
  const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);
  return r.result.value;
 }
 async function wait(check,label){
  for(let i=0;i<100;i++){if(await check())return;await pause(100);}
  throw new Error('Timed out: '+label);
 }
 async function activate(selector){
  assert.ok(await evaluate('!!document.querySelector('+JSON.stringify(selector)+')'),selector);
  await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');
  await command('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,text:'\r'});
  await command('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});
 }
 async function select(selector,value){
  await evaluate('(()=>{const e=document.querySelector('+JSON.stringify(selector)+');e.value='+JSON.stringify(value)+';e.dispatchEvent(new Event("change",{bubbles:true}));})()');
 }
 async function chooseFile(path){
  const {root}=await command('DOM.getDocument');
  const {nodeId}=await command('DOM.querySelector',{nodeId:root.nodeId,selector:'#deck-file'});
  await command('DOM.setFileInputFiles',{nodeId,files:[path]});
 }
 async function screenshot(name,width,height,selector){
  await command('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
  if(selector)await evaluate('document.querySelector('+JSON.stringify(selector)+').scrollIntoView({block:"start"})');
  const {data}=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
  const bytes=Buffer.from(data,'base64');await writeFile(join(output,name),bytes,{flag:'wx'});
  const overflow=await evaluate('document.documentElement.scrollWidth>innerWidth');
  report.checks.push({check:'viewport',name,width,height,sha256:hash(bytes),bytes:bytes.length,overflow});
  assert.equal(overflow,false,name+' document width');
 }
 async function download(selector,label,expected){
  const existing=new Set(completed.keys());await activate(selector);
  await wait(()=>Promise.resolve([...completed.values()].some(d=>!existing.has(d.guid)&&d.complete)),label+' actual download');
  const d=[...completed.values()].find(d=>!existing.has(d.guid)&&d.complete);
  const bytes=await readFile(join(downloadPath,d.guid));
  if(expected)assert.deepEqual(bytes,expected,label+' exact original bytes');
  const named=join(downloadPath,label+'-'+d.name);await writeFile(named,bytes,{flag:'wx'});
  report.downloads.push({...d,label,bytes:bytes.length,sha256:hash(bytes),actual_browser_path:join(downloadPath,d.guid),exact_named_copy:named});
  return {bytes,path:named};
 }
 const learnerState=()=>evaluate('({score:document.querySelector("#first-try-summary")?.textContent??null,review:[...document.querySelectorAll(".review-item")].map(x=>x.textContent),reflection:document.querySelector("#application-reflection")?.value??null,progress:document.querySelector("[role=progressbar]")?.getAttribute("aria-valuenow")})');
 try{
  const flags=['--headless','--disable-gpu','--remote-debugging-pipe','--user-data-dir='+profile,'--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--disable-default-apps','--disable-domain-reliability','--host-resolver-rules=MAP * ~NOTFOUND','--disable-dev-shm-usage','--log-net-log='+netlog,'about:blank'];
  report.flags=flags;report.browser_started=true;report.status='running';
  browser=spawn(executable,flags,{stdio:['ignore','ignore','pipe','pipe','pipe'],detached:true,env:{...process.env,TMPDIR:temp}});
  report.browser_pid=browser.pid;browser.stdio[4].on('data',receive);browser.stderr.on('data',b=>{if(browserStderr.length<262144)browserStderr+=b.toString();});
  deadline=setTimeout(()=>{report.deadline_reached=true;try{process.kill(-browser.pid,'SIGTERM');}catch{}},120000);
  report.version=await command('Browser.getVersion',{},false);
  await command('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath,eventsEnabled:true},false);
  const {targetId}=await command('Target.createTarget',{url:'about:blank'},false);
  ({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));
  await command('Page.enable');await command('Runtime.enable');await command('Network.enable');
  await command('Network.setBlockedURLs',{urls:['http://*','https://*']});
  await command('Emulation.setDeviceMetricsOverride',{width:1200,height:1000,deviceScaleFactor:1,mobile:false});
  await command('Page.navigate',{url:pathToFileURL(join(source,'courses/quantum-states-lab.html')).href});
  await wait(()=>evaluate('document.documentElement.dataset.labReady==="true"'),'lab ready');
  const initial=await evaluate('({comparison:document.querySelector("#comparison-result").textContent,A:document.querySelector("#circuit-A .amplitudes").textContent,B:document.querySelector("#circuit-B .amplitudes").textContent,rows:[...document.querySelectorAll(".trace-body")].map(x=>x.rows.length)})');
  assert.match(initial.comparison,/marginals agree; the joint probabilities differ/);assert.deepEqual(initial.rows,[3,3]);
  report.checks.push({check:'actual initial Bell/product tables and retained traces',passed:true,observed:initial});
  await screenshot('lab-desktop.png',1200,1000,'header');
  await screenshot('lab-circuits.png',1200,1000,'#circuits');
  const courseDownload=await download('#download-course','course',raw);
  await download('#download-guide','guide',guide);
  const observation=JSON.parse((await download('#download-observation','initial-observation')).bytes);
  assert.equal(observation.schema,'recallweave.quantum-observation/1');assert.deepEqual(observation.selected_steps,{A:2,B:2});
  assert.deepEqual(observation.basis_order,['00','01','10','11']);
  assert.equal(observation.circuits.A.steps.length,3);
  assert.ok(Math.abs(observation.circuits.A.steps[2].probabilities[0]-0.5)<1e-12);
  assert.ok(Math.abs(observation.circuits.B.steps[2].probabilities[0]-0.25)<1e-12);
  await activate('[data-preset="phase"]');
  assert.match(await evaluate('document.querySelector("#comparison-result").textContent'),/joint probabilities differ/);
  await select('#A-step','1');await select('#B-step','2');
  assert.match(await evaluate('document.querySelector("#comparison-result").textContent'),/joint probabilities agree/);
  await activate('[data-preset="global"]');
  assert.match(await evaluate('document.querySelector("#circuit-B .amplitudes").textContent'),/-1.000000/);
  assert.match(await evaluate('document.querySelector("#comparison-result").textContent'),/joint probabilities agree/);
  await activate('[data-preset="complex"]');
  assert.match(await evaluate('document.querySelector("#circuit-B .amplitudes").textContent'),/0.500000 \+ 0.500000i/);
  report.checks.push({check:'keyboard presets, selected-step phase distinction, global sign and complex interference',passed:true});
  await select('#A-basis','01');await activate('#circuit-A .clear-gates');
  await select('#A-gate','CNOT');await select('#A-target','0');await select('#A-control','0');
  const prior=await evaluate('document.querySelector("#circuit-A .trace-body").textContent');
  await activate('#circuit-A .add-gate');
  assert.match(await evaluate('document.querySelector("#circuit-A .editor-status").textContent'),/control and target must differ/);
  assert.equal(await evaluate('document.querySelector("#circuit-A .trace-body").textContent'),prior);
  await select('#A-control','1');await activate('#circuit-A .add-gate');
  let custom=JSON.parse((await download('#download-observation','edited-observation')).bytes);
  assert.equal(custom.circuits.A.initial,'01');assert.equal(custom.circuits.A.steps[1].probabilities[3],1);
  await activate('#circuit-A .undo-gate');
  assert.equal(await evaluate('document.querySelector("#circuit-A .trace-body").rows.length'),1);
  report.checks.push({check:'changed initial basis, same-bit refusal preserves trace, reversed CNOT and undo',passed:true});
  await activate('[data-preset="correlations"]');
  await screenshot('lab-mobile.png',390,844,'#circuit-A');
  await evaluate('document.querySelector("#circuit-A details").open=true');
  assert.equal(await evaluate('document.documentElement.scrollWidth>innerWidth'),false);
  const trace=await evaluate('({rows:document.querySelector("#circuit-A .trace-body").rows.length,scrollable:document.querySelector("#circuit-A .trace-scroll").scrollWidth>document.querySelector("#circuit-A .trace-scroll").clientWidth})');
  assert.equal(trace.rows,3);assert.equal(trace.scrollable,true);
  report.checks.push({check:'narrow full-trace horizontal container without page clipping',passed:true,observed:trace});
  await activate('a[href="../demo.html"]');await wait(()=>evaluate('!!document.querySelector("#start-button")'),'unchanged learner link');
  const originalSession=await learnerState();
  await chooseFile(courseDownload.path);await wait(()=>evaluate('!!document.querySelector("#start-deck")'),'downloaded course preview');
  assert.equal(await evaluate('document.querySelector("#deck-preview-title").textContent'),deck.title);
  assert.equal(await evaluate('document.querySelectorAll("#deck-preview ol li").length'),12);
  assert.deepEqual(await learnerState(),originalSession);
  await activate('#cancel-deck');assert.deepEqual(await learnerState(),originalSession);
  await chooseFile(courseDownload.path);await wait(()=>evaluate('!!document.querySelector("#start-deck")'),'second preview');
  await activate('#start-deck');await wait(()=>evaluate('!!document.querySelector(".question-card h2")'),'explicit start');
  const seen=[];
  for(let i=0;i<12;i++){
   const prompt=await evaluate('document.querySelector(".question-card h2").textContent'),item=byPrompt.get(prompt);
   assert.ok(item&&!seen.includes(item.id));seen.push(item.id);
   const choice=item.id==='qs-10'?(item.answer+1)%item.options.length:item.answer;
   await activate('[data-choice="'+choice+'"]');
   assert.ok((await evaluate('document.querySelector("#feedback-slot").textContent')).includes(item.explanation));
   await activate('#next-button');
  }
  await wait(()=>evaluate('!!document.querySelector("#first-try-summary")'),'completed learner');
  assert.match((await learnerState()).score,/11 of 12/);
  await evaluate('document.querySelector("#application-reflection").value="Equal marginals do not determine joint outcomes; q0 is leftmost here.";document.querySelector("#application-reflection").dispatchEvent(new Event("input",{bubbles:true}))');
  const firstNotes=(await download('#save-notes-button','first-study-notes')).bytes.toString('utf8');
  for(const item of deck.items)for(const field of [item.prompt,item.options[item.answer],item.explanation,item.transfer])assert.ok(firstNotes.includes(field),item.id);
  assert.ok(firstNotes.includes(deck.attribution));assert.match(firstNotes,/11 of 12 connections correct on the first try/);
  await activate('#practice-button');
  assert.equal(await evaluate('document.querySelector(".practice-card h2").textContent'),deck.items.find(x=>x.id==='qs-10').prompt);
  await activate('[data-practice-choice="1"]');await activate('#practice-next');
  const finalNotes=(await download('#save-notes-button','final-study-notes')).bytes.toString('utf8');
  assert.match(finalNotes,/11 of 12 connections correct on the first try/);assert.match(finalNotes,/1 of 1 practice answers recorded; 1 correct on retry/);
  assert.ok(finalNotes.includes('Equal marginals do not determine joint outcomes; q0 is leftmost here.'));
  assert.equal((await learnerState()).review.length,12);
  await screenshot('learner-review-mobile.png',390,844,'#session-content');
  report.checks.push({check:'actual downloaded course, unchanged preview/cancel,12 questions,11/12 first pass,1/1 retry and physical notes downloads',passed:true,seen});
  assert.equal(report.pageErrors.length,0);assert.equal(report.pageRequests.filter(x=>/^https?:/.test(x.url)).length,0);
  report.status='passed';
 }catch(error){report.status='failed';report.error=String(error.stack??error);process.exitCode=1;}
 finally{
  clearTimeout(deadline);
  if(browser){
   try{await command('Browser.close',{},false);}catch{}
   await pause(500);
   if(browser.exitCode===null){try{process.kill(-browser.pid,'SIGTERM');}catch{}await pause(500);}
   if(browser.exitCode===null){try{process.kill(-browser.pid,'SIGKILL');}catch{}}
   report.browser_exit_code=browser.exitCode;
  }
  report.after=await sourceMap();report.source_bytes_and_mtimes_unchanged=JSON.stringify(before)===JSON.stringify(report.after);
  if(!report.source_bytes_and_mtimes_unchanged){report.status='failed';process.exitCode=1;}
  report.finished=new Date().toISOString();
  await writeFile(join(output,'browser-stderr-private.txt'),browserStderr,{flag:'wx'});
  report.private_browser_stderr={bytes:Buffer.byteLength(browserStderr),sha256:hash(browserStderr),publish:false};
  try{
   const rawNet=await readFile(netlog);report.private_netlog={path:netlog,bytes:rawNet.length,sha256:hash(rawNet),publish:false};
   if(rawNet.length<=8*1024**2){
    const log=JSON.parse(rawNet),types=Object.fromEntries(Object.entries(log.constants.logEventTypes).map(([k,v])=>[v,k]));
    const jobs=new Map();let sent=0,received=0;
    for(const e of log.events){
     const type=types[e.type],p=e.params??{};
     if(type==='URL_REQUEST_START_JOB'&&/^https?:/.test(p.url??'')){
      const u=new URL(p.url);jobs.set(e.source.id,{origin:u.origin,path:u.pathname,query_present:!!u.search,terminal_errors:[]});
     }
     if(jobs.has(e.source.id)&&p.net_error!==undefined)jobs.get(e.source.id).terminal_errors.push(p.net_error);
     if(type==='SOCKET_BYTES_SENT')sent+=p.byte_count??0;
     if(type==='SOCKET_BYTES_RECEIVED')received+=p.byte_count??0;
    }
    report.browser_wide_diagnostics={remote_url_jobs:[...jobs.values()],socket_bytes_sent:sent,socket_bytes_received:received,interpretation:'Whole isolated-browser netlog counters, not target attribution; attempted URL jobs are reported even when name resolution fails.'};
   }else report.netlog_parse_limit='Retained raw netlog exceeds8MiB; no whole-browser network conclusion.';
  }catch(error){report.netlog_read_error=String(error);}
  await writeFile(join(output,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({status:report.status,report:join(output,'report.json'),sha256:hash(await readFile(join(output,'report.json'))),checks:report.checks.length,downloads:report.downloads.length,source_unchanged:report.source_bytes_and_mtimes_unchanged,error:report.error}));
 }
}
