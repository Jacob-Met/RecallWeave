# Independent course receiving: units and dimensions

All twelve authored questions and all twelve worked transfer tasks agree with the receiver's solutions frozen before answer-key access. The existing RecallWeave deck parser accepts the exact final 13,008-byte JSON, and its canonical roundtrip preserves the recognized course content.

## Blind review and final source

The [questions-only packet](blind-review-v1/questions-only-v1.json) contains prompts, options and open transfer tasks without answers or explanations. Its SHA256 is **41f62611cd7a8318b4868d177c41c14ceb89c6bf4640ead5c965b7f20ba4df24**. The receiver's [solutions before key access](blind-review-v1/solutions-before-key-v1.json), SHA256 **210838180265e481c8a34cfaa581aaabfc1bfaa8d83b683dcd34705ee72ed490**, select the zero-based positions:

`[1, 3, 0, 2, 0, 3, 1, 2, 0, 3, 2, 1]`

Each solution includes reasoning and an independent transfer result. The [blind packet manifest](blind-review-v1/artifact-manifest.json) and its write-attempt provenance retain the exact sequence of evidence.

The accepted course JSON is [course-input-v2/courses/units-and-dimensions.json](course-input-v2/courses/units-and-dimensions.json), Git blob **378eebc2aad75b6d433f1df3c13a7e5be6c9cced**, SHA256 **df0c8c8ba1f0061bbc73bcad0e9a62b257341b4bd5d6a7adbd6824820a02128e**. Four concepts each have three original four-option questions. All answer positions occur three times. The [key comparison](course-input-v2/source-key-comparison.json), [content acceptance](course-input-v2/independent-content-acceptance.json), and actual parser stdout/stderr are retained.

## Two disclosed refinements

After the blind solution was frozen, the author clarified the power-dimensions prompt to state a constant-mass object and a constant net force. A mechanical comparison found this single prompt change; the options, key, derivation and transfer task did not change. The receiver accepted the stronger physical assumptions without repeating or replacing the blind solution.

The original fully reviewed worked guide remains in the v2 content packet. The final [guide v3](guide-v3/units-and-dimensions.md), SHA256 **46918e49fd0b61475f0f7cbb3690eff971f4534303b98c4dc56aef943abe3398**, adds only one section linking the supplied explorer and explaining its input notation. The [exact delta](guide-v2-v3.diff) distinguishes written mathematical shorthand from explicit `*`, `/`, integer `^` powers and denominator parentheses. The link targets the actually supplied `unit-conversion-explorer.html`. The course JSON, answer key and worked transfer calculations remain unchanged.

## Scope of acceptance

The content checks cover unit-factor cancellation, case-sensitive decimal prefixes, squared and cubed scale factors, litre and time relations, compound rates and density, derived dimensions and the limits of dimensional consistency. Definitions were checked against the [BIPM SI Brochure](https://www.bipm.org/en/publications/si-brochure), [NIST SI prefixes](https://www.nist.gov/pml/owm/metric-si-prefixes), and [NIST SP 330 section 4](https://www.nist.gov/pml/special-publication-330/sp-330-section-4). The BIPM English edition retrieved during review was V4.01, June 2026.

This is independent content and format receiving, not an empirical learning assessment. The authored course and worked guide belong to the course author in issue #50; this receiver did not author or change those production files. Actual native browser import/practice/download evidence is sealed in the separate native receiving packet.

The [artifact manifest](artifact-manifest.json) pins every file except itself. Original errors attributable to local evidence writing are preserved as evidence-writing provenance and are not relabeled as product failures.
