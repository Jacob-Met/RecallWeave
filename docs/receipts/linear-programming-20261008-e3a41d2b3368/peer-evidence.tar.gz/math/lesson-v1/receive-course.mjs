import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const root = '/home/jacob/hamon-universal-e3a41d2b3368-recall-lp-review';
const sha = b => createHash('sha256').update(b).digest('hex');
const validator = readFileSync(root+'/original-deck.mjs');
assert.equal(sha(validator), '621438c166ec4bfafd9d87c698a1d46cb1722f4fb92dcbb8d9f52fce682c338b');
const course = readFileSync(root+'/lesson-v1/course-frozen.json');
assert.equal(sha(course), 'd251a3bc174d109d185d600871f8890d81722aed5c190f759b604d162685c5c5');
const authored = readFileSync('/home/jacob/hamon-universal-e3a41d2b3368-recall-linear-programming/candidate/courses/linear-programming.json');
assert.deepEqual(authored, course);
const {parseDeck} = await import(pathToFileURL(root+'/original-deck.mjs'));
const deck = parseDeck(course.toString('utf8'));
assert.equal(deck.items.length,16);
assert.equal(deck.concepts.length,5);
const independent = JSON.parse(readFileSync(root+'/lesson-v1/INDEPENDENT-ANSWERS.json','utf8'));
assert.deepEqual(deck.items.map(i=>({id:i.id,answer:i.answer})),independent.answers.map(({id,answer})=>({id,answer})));
assert(Object.isFrozen(deck));
assert(Object.isFrozen(deck.items));
assert(Object.isFrozen(deck.concepts));
assert(deck.items.every(i=>Object.isFrozen(i)&&Object.isFrozen(i.options)&&Object.isFrozen(i.prerequisites)));
console.log(JSON.stringify({
 schema:'e3.recall-lp.lesson-native-validation/1',
 node:process.version,status:'pass',items:deck.items.length,concepts:deck.concepts.length,
 course_sha256:sha(course),validator_sha256:sha(validator),
 all_independent_choices_match:true,native_deck_immutable:true,author_course_unchanged:true,
 scope:'Exact frozen new lesson admitted by unchanged original native parseDeck; no candidate model, UI, browser, or author tests executed.'
},null,2));
