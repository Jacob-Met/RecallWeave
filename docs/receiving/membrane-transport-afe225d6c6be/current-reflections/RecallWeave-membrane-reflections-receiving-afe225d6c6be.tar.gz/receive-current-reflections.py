from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,os,hashlib,socket,time
root=Path('/dev/recall-root-afe225d6c6be');repo=root/'reference';out=root/'receiving-reflections'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,stderr=subprocess.PIPE)
head=git('rev-parse','HEAD').decode().strip();tree=git('write-tree').decode().strip();assert head=='97b40c2c91f4ac2bbdcaafea680120935c1b4f2c';assert tree=='c7d00099eda946922dce64f7807ecbd1292da31e';assert not git('status','--porcelain').strip()
original=Path('/dev/shm/hamon-afe225d6c6be-coordination-membrane-final/review_membrane_current.mjs').read_bytes();assert hashlib.sha256(original).hexdigest()=='eda268ed060361b81afcf93bbfae0833fd4bfba22071a11db27b731c32acf2af'
(out/'historical-driver-r3.mjs').write_bytes(original)
text=original.decode()
text=text.replace("import crypto from 'node:crypto';","import crypto from 'node:crypto';\nimport { execFileSync } from 'node:child_process';")
text=text.replace("const receipt = {","const observedSource = {commit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: sourceRoot, encoding: 'utf-8'}).trim(), tree: execFileSync('git', ['rev-parse', 'HEAD^{tree}'], {cwd: sourceRoot, encoding: 'utf-8'}).trim()};\nassert.equal(execFileSync('git', ['status', '--porcelain'], {cwd: sourceRoot, encoding: 'utf-8'}).trim(), '');\nconst receipt = {",1)
text=text.replace("source_commit: 'd8a9ff81e8e5290e8daad5b4af957d4eddc0ee74',","source_commit: observedSource.commit,").replace("source_tree: '2d6b3849fe9efe0d38f8c3cd62588fb9477d328d',","source_tree: observedSource.tree,")
text=text.replace("executablePath: '/workspace/scratch/3e50c5ad22c5/production/browser/chromium',","executablePath: '/tmp/hamon-project-browser-ce7eb129730f/portable-153/chromium',")
driver=out/'receive-current-reflections-r1.mjs';driver.write_text(text)
assert text.count("source_commit: observedSource.commit")==1
change={'kind':'Historical course receiver adapted only for observed source identity and existing root Chromium path','historical_sha256':hashlib.sha256(original).hexdigest(),'current_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'source_head':head,'source_tree':tree,'assertion_contract_changed':False}
(out/'driver-provenance-r1.json').write_text(json.dumps(change,indent=2)+'\n')
def freeze():
 rows=[]
 for name in git('ls-files','-z').decode().split(chr(0)):
  if not name:continue
  b=(repo/name).read_bytes();rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+bytes([0])+b).hexdigest()})
 return rows
before=freeze();assert len(before)==931
(out/'source-readback-before.json').write_text(json.dumps(before,indent=2)+'\n')
checks=[]
env=os.environ.copy();env['TMPDIR']=str(root/'tmp');Path(env['TMPDIR']).mkdir()
for name,cmd in [('demo-check',['python3','tools/make_demo.py','--check']),('node-tests',['bash','-c','node --test tests/*.test.mjs']),('driver-syntax',['node','--check',str(driver)])]:
 p=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,text=True);b=(p.stdout+p.stderr).encode();(out/(name+'.log')).write_bytes(b);checks.append({'name':name,'exit_code':p.returncode,'log_sha256':hashlib.sha256(b).hexdigest(),'tail':p.stdout.splitlines()[-9:]});print(json.dumps({'check':checks[-1]}),flush=True)
 assert p.returncode==0,checks[-1]
assert not git('status','--porcelain').strip()
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
serverlog=(out/'http-server.log').open('wb')
server=subprocess.Popen(['python3','-m','http.server',str(port),'--bind','127.0.0.1','--directory',str(repo)],env=env,stdout=serverlog,stderr=subprocess.STDOUT)
try:
 for _ in range(100):
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=0.1):break
  except OSError:
   assert server.poll() is None
   time.sleep(0.05)
 else:raise RuntimeError('Owned HTTP server did not become ready')
 browserdir=out/'browser-r1';runroot=root/'browser-runtime-r1';runroot.mkdir()
 cmd=['node',str(driver),str(repo),str(repo/'courses/membrane-transport.json'),str(browserdir),'http://127.0.0.1:'+str(port),str(runroot)]
 print(json.dumps({'browserStarted':True,'source':head,'tree':tree,'port':port}),flush=True)
 p=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,text=True)
 (out/'browser-r1.log').write_text(p.stdout+p.stderr)
finally:
 server.terminate();server.wait(timeout=10);serverlog.close()
after=freeze();(out/'source-readback-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after and not git('status','--porcelain').strip()
result=json.loads((browserdir/'browser-receipt.json').read_bytes())
record={'kind':'Actual membrane course receiving after merged reflections','recorded_at':datetime.now(timezone.utc).isoformat(),'native_head':head,'native_tree':tree,'base':'3cdebd86e69506709bcaeaeff4026deb3d1fc208','checks':checks,'browser_exit_code':p.returncode,'browser_passed':result.get('passed'),'browser_receipt_sha256':hashlib.sha256((browserdir/'browser-receipt.json').read_bytes()).hexdigest(),'source_files_verified_before_and_after':len(before),'source_unchanged':True,'groups':[{'id':g['id'],'passed':g['passed'],'first_answers':len(g['first_order']),'practice_retries':len(g['practice_order']),'downloads':g['downloads'],'page_errors':g['page_errors'],'width_checks':g['width_checks']} for g in result['groups']],'driver':change,'qualification_boundary':'Exact course import, first answers, practice and notes under current reflections consumer. No empirical learning claim or separate new reflection feature acceptance is inferred.'}
(out/'receiving-summary.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
assert p.returncode==0 and result.get('passed'),result.get('error')
