import pathlib,json,hashlib,os,datetime,subprocess
R=pathlib.Path(__file__).resolve().parent
P=json.loads((R/'original-packet.json').read_text(encoding='utf-8'))
def pin(b): return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
S=R/'original'
S.mkdir(exist_ok=False)
rows=[]
for q in P['files']:
 b=q['content'].encode('utf-8');v=pin(b)
 assert (v['bytes'],v['git'])==(q['bytes'],q['git']),(q['path'],v,q)
 put(S/q['path'],b);rows.append(dict(path=q['path'],**v))
put(R/'CONTRACT.md',P['contract'].encode('utf-8')+b'\n')
preset=json.dumps(P['presets'],ensure_ascii=False,indent=2).encode('utf-8')+b'\n'
put(R/'PUBLIC-PRESETS.json',preset)
put(R/'original-manifest.json',(json.dumps(rows,indent=2)+'\n').encode())
node=pathlib.Path('C:/Program Files/nodejs/node.exe')
run=R/'original-native-r1';run.mkdir(exist_ok=False)
code="""import assert from 'node:assert/strict';
import fs from 'node:fs';
import {parseDeck,serializeDeck,validateDeck} from '../original/src/deck.mjs';
const text=fs.readFileSync(new URL('../original/data/deck.json',import.meta.url),'utf8');
const deck=parseDeck(text); assert.equal(deck.items.length,6);
assert.deepEqual(parseDeck(serializeDeck(deck)),deck);
assert.ok(Object.isFrozen(deck)&&deck.items.every(Object.isFrozen));
assert.throws(()=>parseDeck('{"format":"other"}'));
assert.throws(()=>validateDeck({...deck,items:[{...deck.items[0],answer:99}]}));
const html=fs.readFileSync(new URL('../original/demo.html',import.meta.url),'utf8');
assert.ok(html.includes('Start this deck')&&html.includes('Download'));
console.log(JSON.stringify({groups:['canonical-six-question-parse','roundtrip','immutable-model','unsupported-version-refusal','answer-refusal','actual-standalone-consumer-present'],title:deck.title,items:deck.items.map(x=>({id:x.id,concept:x.concept})),format:deck.format}));"""
put(run/'baseline.mjs',code.encode())
cp=subprocess.run([str(node),str(run/'baseline.mjs')],cwd=run,capture_output=True,timeout=30)
put(run/'stdout.bin',cp.stdout);put(run/'stderr.bin',cp.stderr)
post=[dict(path=q['path'],**pin((S/q['path']).read_bytes())) for q in rows]
assert post==rows
receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),exit=cp.returncode,argv=[str(node),str(run/'baseline.mjs')],source=rows,node=pin(node.read_bytes()),stdout=pin(cp.stdout),stderr=pin(cp.stderr),source_unchanged=True)
put(run/'receipt.json',(json.dumps(receipt,indent=2)+'\n').encode())
offer=dict(repository=P['repository'],commit=P['commit'],tree=P['tree'],issue='https://github.com/Jacob-Met/RecallWeave/issues/253',original_root=str(S),source_manifest=str(R/'original-manifest.json'),contract=str(R/'CONTRACT.md'),presets=str(R/'PUBLIC-PRESETS.json'),original_receipt=str(run/'receipt.json'),runtime=str(node),files=rows,candidate_exposure=False,qualification='Original parser/serializer native baseline only; actual original browser pending independent receiving.')
put(R/'ORIGINAL-ONLY-OFFER.json',(json.dumps(offer,indent=2)+'\n').encode())
print(json.dumps(dict(exit=cp.returncode,source_files=len(rows),bytes=sum(q['bytes'] for q in rows),contract=pin((R/'CONTRACT.md').read_bytes()),offer=pin((R/'ORIGINAL-ONLY-OFFER.json').read_bytes()),stdout=cp.stdout.decode('utf-8'),stderr=cp.stderr.decode('utf-8'))))
raise SystemExit(cp.returncode)
