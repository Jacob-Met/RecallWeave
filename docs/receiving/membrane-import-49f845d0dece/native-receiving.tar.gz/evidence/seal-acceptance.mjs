import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import assert from 'node:assert/strict';
const root='/tmp/rw49-membrane-49f845d0dece',evidence=join(root,'evidence'),run=join(evidence,'run-01');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const read=async path=>JSON.parse(await readFile(path,'utf8'));
const report=await read(join(run,'browser-report.json'));
assert.equal(report.status,'passed');assert.equal(report.checks.length,13);
const source=await read(join(evidence,'source-manifest.json')),correspondence=await read(join(evidence,'post-run-runtime-correspondence.json'));
const course=await read(join(root,'inputs/membrane-transport.json'));
const proof={schema:'recallweave.independent.membrane-importer-adoption.v1',owner:'estate-49f845d0dece/recall_import_receiving',outcome:'accepted for bounded current-importer adoption',sealedAt:new Date().toISOString(),nativeStartedAt:report.startedAt,nativeFinishedAt:report.finishedAt,course:{head:source.courseSourceRef,path:source.coursePath,bytes:source.courseBytes,sha256:source.courseSha256,gitBlob:source.courseGitBlob,sourceOwner:'afe225d6c6be',pr:26,sourceAndPublicationRemainWithOwner:true},runtime:{observedBefore:'9b69c9c1dcc578d45e58d9b7f78eecb0613d76f3',observedAfter:correspondence.currentMain,observedAfterTree:correspondence.currentTree,acceptedImporterHead:correspondence.sourceHead,acceptedImporterMerge:correspondence.acceptedImporterMerge,allFourteenBlobsAndModesIdentical:true,sourceUnchangedDuringReceiving:true},browser:report.browser,node:report.node,platform:report.platform,checksPassed:report.checks.length,downloadCount:report.downloads.length,screenshotCount:report.screenshots.length,pageExceptions:report.pageErrors,externalAppRequests:report.externalRequests,pins:{},entries:[],limits:['Course scientific/content correctness and prior blind answers remain the course owner independent evidence; this receiving verifies current importer adoption only.','The operating-system file chooser window itself was not automated; real HTML file-input files were assigned through native Chrome CDP. Empty input selection is the chooser-cancellation witness.','No reflection or incomplete-session behavior is qualified.','No course/importer source edits, source branch changes, PR readiness changes, merges, account use or deployments.'],receiverLineage:'Adapted from final authored-file PR33 receiving receiver 90de9283e7ace12ddbc562b01761c261702e918cf8e9d5d6bc2c15320df44ab6; exact membrane bytes/count, mixed 4/12 answers, real review disclosure visits, and all eight correct retries are the bounded changes.'};
for(const [label,path] of [['receiver','receive-membrane-import-trace.mjs'],['browserReport','evidence/run-01/browser-report.json'],['sourceManifest','evidence/source-manifest.json'],['initialRuntimeCorrespondence','evidence/runtime-correspondence.json'],['postRunRuntimeCorrespondence','evidence/post-run-runtime-correspondence.json'],['nativeProcessReceipt','evidence/native-process-receipt.json']]){
 const bytes=await readFile(join(root,path));proof.pins[label]={path,bytes:bytes.length,sha256:hash(bytes)};
}
for(const entry of report.entries){
 const traces={};for(const stage of ['first','paused','restored','continued'])traces[stage]=await read(join(run,entry.name+'-'+stage+'-trace.json'));
 for(const stage of ['paused','restored','continued'])for(const field of ['deck','model','firstAnswers','mastery'])assert.deepEqual(traces[stage][field],traces.first[field]);
 assert.deepEqual(traces.restored.practice,traces.paused.practice);
 assert.equal(traces.first.practice,null);assert.equal(traces.paused.practice.answers.length,1);assert.equal(traces.continued.practice.answers.length,8);
 assert.equal(entry.firstAnswers.filter(x=>x.correct).length,4);
 assert.equal(entry.reviewedQuestions.length,12);
 assert.ok(entry.correctedPracticeAnswers.every(x=>x.correct));
 const row={name:entry.name,url:entry.url,width:entry.width,firstAnswerCount:12,firstCorrect:4,firstMissed:8,reviewDisclosuresOpened:12,practicePausedAfter:1,finalPracticeCorrect:8,finalPracticeTotal:8,firstAnswersAndFullPrecisionMasteryExactAcrossSaveRestorePractice:true,actualTraceRedownloadStateEqual:true,changedOptionOrdersAfterFreshDocument:true,mastery:traces.first.mastery,adaptiveQuestionOrder:entry.firstAnswers.map(x=>x.item),answers:course.items.map(item=>{const first=entry.firstAnswers.find(x=>x.item===item.id),retry=entry.correctedPracticeAnswers.find(x=>x.item===item.id);return {id:item.id,canonicalAnswer:item.answer,firstCanonicalChoice:first.choice,firstCorrect:first.correct,retryCanonicalChoice:retry?.choice??null,retryCorrect:retry?.correct??null};})};
 proof.entries.push(row);
}
for(const file of [...report.downloads,...report.screenshots])assert.equal(hash(await readFile(join(run,file.name))),file.sha256,file.name);
proof.downloads=report.downloads;proof.screenshots=report.screenshots;
await writeFile(join(evidence,'acceptance.json'),JSON.stringify(proof,null,2)+'\n');
console.log(JSON.stringify(proof,null,2));
