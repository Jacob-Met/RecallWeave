import assert from "node:assert/strict";
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, rmSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
const root = dirname(fileURLToPath(import.meta.url));
const candidate = resolve(root, "candidate");
const chrome = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const out = resolve(root, "browser-v1");
mkdirSync(out, { recursive: false });
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, label, ms = 15000) {
  const end = Date.now() + ms;
  while (Date.now() < end) { const value = await fn(); if (value) return value; await sleep(80); }
  throw Error("Timed out: " + label);
}
const manifest = JSON.parse(readFileSync(resolve(root, "SOURCE-RECEIPT.json")));
function sourcePins() {
  return manifest.files.map(file => {
    const bytes = readFileSync(resolve(candidate, file.path));
    assert.equal(bytes.length, file.bytes, file.path);
    assert.equal(sha(bytes), file.sha256, file.path);
    return { path: file.path, sha256: file.sha256 };
  });
}
const before = sourcePins();
const admission = JSON.parse(readFileSync(resolve(root, "RUN-ADMISSION.json")));
assert(admission.freeDisk >= 268435456 && admission.freeMemory >= 536870912);
assert.equal(admission.chromeProcessCount, 0);
const receipt = { schema: "recallweave.lp-la7-browser/1", started: new Date().toISOString(), node: process.version,
 executable: process.execPath, platform: process.platform, before, admission, groups: [], checks: 0, errors: [],
 sourceUnchanged: false, status: "running", cleanup: {} };
const check = (condition, message) => { receipt.checks++; assert.ok(condition, message); };
const eq = (actual, expected, message) => { receipt.checks++; assert.deepEqual(actual, expected, message); };
const group = async (name, action) => { await action(); receipt.groups.push(name); console.log("PASS " + name); };
class CDP {
  constructor(ws) {
    this.ws = ws; this.next = 1; this.pending = new Map(); this.events = [];
    ws.addEventListener("message", event => {
      const message = JSON.parse(event.data);
      if (message.id) {
        const pending = this.pending.get(message.id);
        if (pending) {
          clearTimeout(pending.timer); this.pending.delete(message.id);
          message.error ? pending.reject(Error(JSON.stringify(message.error))) : pending.resolve(message.result);
        }
      } else this.events.push(message);
    });
  }
  static async open(url) {
    const ws = new WebSocket(url);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(Error("CDP open timeout")), 10000);
      ws.addEventListener("open", () => { clearTimeout(timer); resolve(); }, { once: true });
      ws.addEventListener("error", () => { clearTimeout(timer); reject(Error("CDP socket error")); }, { once: true });
    });
    return new CDP(ws);
  }
  send(method, params = {}, sessionId) {
    const id = this.next++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(Error("CDP timeout " + method)); }, 15000);
      this.pending.set(id, { resolve, reject, timer });
      this.ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    });
  }
  close() { this.ws.close(); }
}
const profile = resolve(out, "profile"), downloads = resolve(out, "downloads");
mkdirSync(downloads); assert(!existsSync(profile));
const args = ["--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
 "--disable-background-networking", "--disable-component-update", "--disable-default-apps", "--disable-sync",
 "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0", "--user-data-dir=" + profile,
 "--window-size=1280,960", "about:blank"];
receipt.browserCommand = { executable: chrome, args, sandboxDisablingFlags: false };
let proc, cdp, exited = false, exitInfo, log = "", main;
async function page() {
  const { targetId } = await cdp.send("Target.createTarget", { url: "about:blank" });
  const { sessionId } = await cdp.send("Target.attachToTarget", { targetId, flatten: true });
  const send = (method, params = {}) => cdp.send(method, params, sessionId);
  const evaluate = async expression => {
    const result = await send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
    if (result.exceptionDetails) throw Error("Page exception " + JSON.stringify(result.exceptionDetails));
    return result.result.value;
  };
  const value = selector => evaluate("document.querySelector(" + JSON.stringify(selector) + ")?.value");
  const text = selector => evaluate("document.querySelector(" + JSON.stringify(selector) + ")?.innerText");
  const count = selector => evaluate("document.querySelectorAll(" + JSON.stringify(selector) + ").length");
  const visible = selector => evaluate("(()=>{const e=document.querySelector(" + JSON.stringify(selector) + ");return !!e&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';})()");
  async function click(selector) {
    const point = await evaluate("(()=>{const e=document.querySelector(" + JSON.stringify(selector) + ");if(!e)throw Error('Missing selector');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();if(!r.width||!r.height)throw Error('Invisible target');return {x:r.x+r.width/2,y:r.y+r.height/2};})()");
    await send("Input.dispatchMouseEvent", { type: "mousePressed", button: "left", clickCount: 1, ...point });
    await send("Input.dispatchMouseEvent", { type: "mouseReleased", button: "left", clickCount: 1, ...point });
  }
  async function key(key, code, keyCode, modifiers = 0) {
    await send("Input.dispatchKeyEvent", { type: "rawKeyDown", key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode, modifiers });
    await send("Input.dispatchKeyEvent", { type: "keyUp", key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode, modifiers });
  }
  async function fill(selector, content) {
    await click(selector); await key("a", "KeyA", 65, 2);
    if (content === "") await key("Backspace", "Backspace", 8);
    else await send("Input.insertText", { text: content });
  }
  async function select(selector, targetValue) {
    const index = await evaluate("Array.from(document.querySelector(" + JSON.stringify(selector) + ").options).findIndex(o=>o.value===" + JSON.stringify(targetValue) + ")");
    assert(index >= 0);
    // Native select receives trusted keyboard events; no value assignment or synthetic change.
    await evaluate("document.querySelector(" + JSON.stringify(selector) + ").focus()");
    await key("Home", "Home", 36);
    for (let i = 0; i < index; i++) await key("ArrowDown", "ArrowDown", 40);
    await key("Enter", "Enter", 13);
    await until(async () => await value(selector) === targetValue, "native select " + targetValue);
  }
  async function screenshot(name) {
    const metrics = await send("Page.getLayoutMetrics");
    const size = metrics.cssContentSize;
    assert(size.width <= 1600 && size.height <= 16000);
    const shot = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: true,
      clip: { x: 0, y: 0, width: Math.ceil(size.width), height: Math.ceil(size.height), scale: 1 } });
    const bytes = Buffer.from(shot.data, "base64"); writeFileSync(resolve(out, name + ".png"), bytes);
    return { bytes: bytes.length, sha256: sha(bytes) };
  }
  async function navigate(path) {
    await send("Page.navigate", { url: pathToFileURL(path).href });
    await until(() => evaluate("document.readyState==='complete'"), "page complete");
  }
  await send("Page.enable"); await send("Runtime.enable"); await send("Network.enable"); await send("Log.enable");
  await send("Emulation.setDeviceMetricsOverride", { width: 1280, height: 960, deviceScaleFactor: 1, mobile: false });
  return { targetId, sessionId, send, evaluate, value, text, count, visible, click, key, fill, select, screenshot, navigate };
}
async function download(selector, filename) {
  const start = cdp.events.length;
  await main.click(selector);
  const begun = await until(() => cdp.events.slice(start).find(e => e.method === "Browser.downloadWillBegin"), "download event");
  eq(begun.params.suggestedFilename, filename, "actual suggested filename");
  const complete = await until(() => cdp.events.slice(start).find(e => e.method === "Browser.downloadProgress" && e.params.guid === begun.params.guid && e.params.state !== "inProgress"), "download completion");
  eq(complete.params.state, "completed", "actual download completed");
  const path = resolve(downloads, filename);
  await until(() => existsSync(path), "download bytes");
  return readFileSync(path);
}
try {
  proc = spawn(chrome, args, { stdio: ["ignore", "pipe", "pipe"], windowsHide: true });
  receipt.pid = proc.pid;
  proc.stdout.on("data", bytes => { if (log.length < 65536) log += bytes; });
  proc.stderr.on("data", bytes => { if (log.length < 65536) log += bytes; });
  proc.once("exit", (code, signal) => { exited = true; exitInfo = { code, signal }; });
  proc.once("error", error => receipt.errors.push("spawn: " + error.message));
  const active = await until(() => {
    const path = resolve(profile, "DevToolsActivePort");
    if (existsSync(path)) return readFileSync(path, "utf8").trim().split(/\r?\n/);
    if (exited) throw Error("Chrome exited before debugging");
    return null;
  }, "owned Chrome debugging file", 20000);
  cdp = await CDP.open("ws://127.0.0.1:" + active[0] + active[1]);
  receipt.browser = await cdp.send("Browser.getVersion");
  await cdp.send("Browser.setDownloadBehavior", { behavior: "allow", downloadPath: downloads, eventsEnabled: true });
  main = await page();
  await main.navigate(resolve(candidate, "courses/linear-programming-explorer.html"));
  await until(() => main.visible("#result"), "initial applied result");
  const preset = async id => { await main.select("#preset", id); await main.click("#load-preset"); };
  await group("initial unique optimum and all boundary pairs", async () => {
    check((await main.text("#optimum-summary")).includes("Maximum 9 at V3 (1, 3)"), "unique optimum");
    eq(await main.count("#vertices-table tbody tr"), 4, "four exact vertices");
    eq(await main.count("#pairs-table tbody tr"), 15, "all pairs");
    check((await main.text("#status")).includes("exact arithmetic"), "applied status");
  });
  await group("fractional optimum and actual exact observation download", async () => {
    await preset("fractional");
    check((await main.text("#optimum-summary")).includes("Maximum 10/3"), "fractional value");
    check((await main.text("#vertices-table")).includes("5/3"), "fractional coordinates");
    await main.select("#vertex-select", "V3");
    const bytes = await download("#download-observation", "linear-programming-observation.json");
    const observation = JSON.parse(bytes);
    eq(observation.optimum.value, "10/3", "download value");
    eq(observation.inspection.selectedVertex, "V3", "download inspection");
    eq(observation.pairs.length, 15, "download complete pair records");
    eq(observation.vertices.find(v => v.id === "V3").x, "5/3", "download exact x");
    eq(observation.vertices.find(v => v.id === "V3").slacks.length, 6, "download all slacks");
    receipt.desktop = await main.screenshot("desktop-fractional");
  });
  await group("complete optimal dimensions and infeasibility", async () => {
    for (const [id, summary, coverage] of [["edge","entire segment","remaining feasible"],["constant","entire feasible region","Every feasible"],["line","Minimum 6","Every feasible"],["point","(2, 1)","Every feasible"],["empty","Infeasible","no attained optimum"]]) {
      await preset(id);
      check((await main.text("#optimum-summary")).includes(summary), id + " exact summary");
      check((await main.text("#coverage")).includes(coverage), id + " complete set");
    }
    eq(await main.evaluate("document.querySelector('#vertex-select').disabled"), true, "empty inspection disabled");
    eq(await main.count("#vertices-table tbody tr"), 0, "no stale vertices");
    eq(await main.count("#slacks-table tbody tr"), 0, "no stale slacks");
  });
  await group("draft retirement invalid recovery and bound changes", async () => {
    await preset("fractional"); await main.fill("#xmax", "1");
    eq(await main.visible("#result"), false, "draft retires result");
    eq(await main.evaluate("document.querySelector('#download-observation').disabled"), true, "draft retires observation");
    await main.click("#apply");
    check((await main.text("#optimum-summary")).includes("Maximum 3"), "new bound changes optimum");
    await main.fill("#constraints", '<img src=x onerror="window.bad=1">'); await main.click("#apply");
    eq(await main.visible("#error"), true, "invalid draft alert");
    eq(await main.visible("#result"), false, "invalid draft has no stale result");
    eq(await main.count("img"), 0, "input is not markup");
    eq(await main.evaluate("typeof window.bad"), "undefined", "no injected effect");
    await main.fill("#constraints", "2, 1, 5\n1, 2, 5"); await main.click("#apply");
    eq(await main.visible("#error"), false, "valid recovery clears error");
    check((await main.text("#optimum-summary")).includes("Maximum 3"), "recovered problem");
  });
  await group("zero-normal contradiction and singleton bounds", async () => {
    await preset("unique"); await main.fill("#constraints", "0, 0, -1"); await main.click("#apply");
    check((await main.text("#optimum-summary")).startsWith("Infeasible"), "zero-normal contradiction");
    // innerText in a closed details can omit descendants; read literal table text without opening state simulation.
    check((await main.evaluate("document.querySelector('#pairs-table').textContent")).includes("zero-normal"), "zero-normal pair retained");
    for (const [id, value] of [["xmin","2"],["xmax","2"],["ymin","1"],["ymax","1"],["p","0"],["q","0"],["constraints",""]]) await main.fill("#" + id, value);
    await main.click("#apply");
    check((await main.text("#optimum-summary")).includes("(2, 1)"), "singleton coordinate");
    check((await main.text("#coverage")).includes("Every feasible"), "whole singleton optimal");
    check(await main.count("#plot circle") > 0, "singleton drawn");
  });
  let courseBytes;
  await group("actual course and guide downloads preserve bytes", async () => {
    courseBytes = await download("#download-course", "linear-programming.json");
    eq(courseBytes, readFileSync(resolve(candidate, "courses/linear-programming.json")), "course byte parity");
    const guideBytes = await download("#download-guide", "linear-programming.md");
    eq(guideBytes, readFileSync(resolve(candidate, "courses/linear-programming.md")), "guide byte parity");
  });
  await group("trusted keyboard application and vertex selection", async () => {
    await preset("unique"); await main.fill("#p", "1"); await main.key("Enter", "Enter", 13);
    check((await main.text("#result-title")).includes("1x + 2y"), "keyboard applies draft");
    await main.evaluate("document.querySelector('#vertex-select').focus()");
    await main.key("End", "End", 35); await main.key("Enter", "Enter", 13);
    eq(await main.value("#vertex-select"), "V4", "native End selects last vertex");
    check((await main.text("#vertex-detail")).startsWith("V4"), "inspection follows trusted keyboard");
    eq(await main.count("#slacks-table tbody tr"), 6, "all inspected row slacks");
  });
  await group("mobile layout complete pair table and print rendering", async () => {
    await main.send("Emulation.setDeviceMetricsOverride", { width: 390, height: 844, deviceScaleFactor: 1, mobile: false });
    eq(await main.evaluate("document.documentElement.scrollWidth<=innerWidth"), true, "mobile no horizontal overflow");
    await main.click("#pair-details summary");
    eq(await main.evaluate("document.querySelector('#pair-details').open"), true, "native details control opens");
    eq(await main.evaluate("document.documentElement.scrollWidth<=innerWidth"), true, "wide table contained");
    receipt.mobile = await main.screenshot("mobile-pairs");
    await main.send("Emulation.setEmulatedMedia", { media: "print" });
    receipt.print = await main.screenshot("print");
    await main.send("Emulation.setEmulatedMedia", { media: "screen" });
  });
  await group("downloaded course enters unchanged learner preview start and feedback", async () => {
    const learner = await page();
    receipt.learnerSession = learner.sessionId;
    await learner.navigate(resolve(candidate, "learner/demo.html"));
    const { root: document } = await learner.send("DOM.getDocument");
    const { nodeId } = await learner.send("DOM.querySelector", { nodeId: document.nodeId, selector: "#deck-file" });
    await learner.send("DOM.setFileInputFiles", { nodeId, files: [resolve(downloads, "linear-programming.json")] });
    await until(() => learner.visible("#start-deck"), "native imported deck preview");
    check((await learner.text("#deck-preview-title")).includes("Linear programming"), "native preview title");
    check((await learner.text(".deck-preview-count")).includes("16"), "native preview count");
    await learner.click("#start-deck");
    await until(() => learner.visible(".question-card h2"), "native lesson started");
    const prompt = await learner.text(".question-card h2");
    const question = JSON.parse(courseBytes).items.find(item => item.prompt === prompt);
    check(Boolean(question), "native learner uses downloaded lesson");
    await learner.click('.choice[data-choice="' + question.answer + '"]');
    await until(() => learner.visible("#feedback-slot .feedback"), "native answer feedback");
    check((await learner.text("#feedback-slot")).includes(question.explanation), "native matching explanation");
    eq(await learner.count(".choice.correct"), 1, "native learner marks correct");
    receipt.learner = await learner.screenshot("learner-feedback");
    await cdp.send("Target.closeTarget", { targetId: learner.targetId });
    check((await main.text("#vertex-detail")).startsWith("V4"), "learner tab preserves lab inspection");
  });
  await group("no external page requests errors or automatic storage", async () => {
    const sessions = new Set([main.sessionId, receipt.learnerSession]);
    receipt.pageRequests = cdp.events.filter(e => sessions.has(e.sessionId) && e.method === "Network.requestWillBeSent").map(e => e.params.request.url);
    check(receipt.pageRequests.every(url => /^(file:|data:|blob:)/.test(url)), "all page requests local");
    const errors = cdp.events.filter(e => sessions.has(e.sessionId) && (e.method === "Runtime.exceptionThrown" || (e.method === "Log.entryAdded" && e.params.entry.level === "error") || (e.method === "Runtime.consoleAPICalled" && e.params.type === "error")));
    eq(errors, [], "no actual page errors");
    eq(await main.evaluate("({local:localStorage.length,session:sessionStorage.length})"), { local: 0, session: 0 }, "no automatic storage");
  });
  receipt.status = "passed";
} catch (error) {
  receipt.status = "failed"; receipt.errors.push(error.stack || String(error));
  if (main) { try { receipt.failureScreenshot = await main.screenshot("failure"); } catch (e) { receipt.errors.push("Failure screenshot: " + e.message); } }
} finally {
  receipt.actualDownloadEvents = cdp?.events.filter(e => e.method?.startsWith("Browser.download")) ?? [];
  if (cdp) { try { await cdp.send("Browser.close"); } catch (error) { receipt.cleanup.closeDiagnostic = error.message; } cdp.close(); }
  if (proc && !exited) {
    try { await until(() => exited, "owned Chrome exit", 10000); }
    catch { receipt.cleanup.termination = "Owned child handle only"; proc.kill(); try { await until(() => exited, "owned child termination", 5000); } catch (error) { receipt.cleanup.exitWaitError = error.message; } }
  }
  receipt.cleanup.browserExited = exited; receipt.cleanup.exit = exitInfo ?? null;
  if (exited && existsSync(profile)) {
    try { rmSync(profile, { recursive: true, force: false, maxRetries: 3, retryDelay: 250 }); receipt.cleanup.profileRemoved = !existsSync(profile); }
    catch (error) { receipt.cleanup.profileError = error.message; }
  }
  receipt.after = sourcePins(); receipt.sourceUnchanged = JSON.stringify(before) === JSON.stringify(receipt.after);
  if (!receipt.sourceUnchanged || !exited || !receipt.cleanup.profileRemoved) receipt.status = "failed";
  receipt.finished = new Date().toISOString();
  writeFileSync(resolve(out, "browser.log"), log);
  writeFileSync(resolve(out, "RECEIPT.json"), JSON.stringify(receipt, null, 2) + "\n");
  console.log(JSON.stringify({ status: receipt.status, groups: receipt.groups.length, checks: receipt.checks, errors: receipt.errors, cleanup: receipt.cleanup, sourceUnchanged: receipt.sourceUnchanged }, null, 2));
  process.exitCode = receipt.status === "passed" ? 0 : 1;
}
