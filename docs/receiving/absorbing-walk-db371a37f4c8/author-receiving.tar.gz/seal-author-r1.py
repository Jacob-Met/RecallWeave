import pathlib,json,hashlib,tarfile,zipfile,datetime,shutil,base64,os
root=pathlib.Path('/run/user/1000/snap.chromium/hamon-absorbing-walk-author-db371a37f4c8')
assert shutil.disk_usage(root).free>=268435456
dest=root/'publication-author-r1';dest.mkdir(exist_ok=False)
b=base64.b64decode((root/'windows-author.tar.gz.b64').read_text(),validate=True)
assert hashlib.sha256(b).hexdigest()=='dcdbdb94da20a08d20147ee4b71737628a585bb6548d279b32e604a7bbaa150e'
(root/'windows-author.tar.gz').write_bytes(b)
proof=json.loads((root/'source-fulltree-proof.json').read_text())
source=[]
for row in proof['delta']:
 p=root/'source'/row['path'];b=p.read_bytes();git=hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest();assert git==row['sha'],row['path']
 source.append({'path':row['path'],'bytes':len(b),'git':git,'sha256':hashlib.sha256(b).hexdigest()})
runtime=json.loads((root/'runtime-manifest-r1.json').read_text())
assert all(hashlib.sha256((root/'source'/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in runtime)
packet=json.loads((root/'source-packet.json').read_text())
assert all(hashlib.sha1(('blob '+str(len((root/'original'/x['path']).read_bytes()))+'\0').encode()+(root/'original'/x['path']).read_bytes()).hexdigest()==x['git'] for x in packet['original']['files'])
original_readme=(root/'original/README.md').read_bytes();assert (root/'source/README.md').read_bytes().startswith(original_readme)
package=root/'portable-r1/absorbing-walk-portable.zip'
assert hashlib.sha256(package.read_bytes()).hexdigest()=='a928a859470c668f8e313d839f11d0f31e781aaa4367a03441d6bcb70eb70426'
with zipfile.ZipFile(package) as z:
 assert len(z.namelist())==6
 m=json.loads(z.read('MANIFEST.json'))
 for x in m['files']:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
owned=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name) in [os.getpid(),os.getppid()]:continue
 try:
  cmd=p.joinpath('cmdline').read_bytes()
  if b'hamon-absorbing-walk-author-db371a37f4c8' in cmd:owned.append({'pid':p.name,'cmd':cmd.decode(errors='replace')})
 except (FileNotFoundError,PermissionError):pass
assert not owned,owned
audit={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'runtimeFilesExact':len(runtime),'originalFilesExact':len(packet['original']['files']),'readmeAppendOnly':True,'packageExact':True,'ownedProcesses':owned,'rootReviewSha256':hashlib.sha256((root/'root-review-r1/ROOT-REVIEW.json').read_bytes()).hexdigest()}
(root/'FINAL-AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
rows=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or dest in p.parents:continue
 rel=p.relative_to(root).as_posix()
 if p.suffix=='.b64' or any(part in ['tmp','cache','profile'] for part in p.relative_to(root).parts):continue
 assert not p.is_symlink()
 b=p.read_bytes();rows.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':proof['sourceCommit'],'files':rows}
(dest/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=dest/'author-receiving.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for row in rows:t.add(root/row['path'],arcname=row['path'],recursive=False)
 t.add(dest/'MANIFEST.json',arcname='MANIFEST.json',recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(rows)+1
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
seal={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payloadFiles':len(rows),'archiveMembers':len(rows)+1,'files':[]}
for name,path in [('author-receiving.tar.gz',archive),('AUTHOR.md',root/'AUTHOR.md'),('author-manifest.json',dest/'MANIFEST.json'),('author-final-audit.json',root/'FINAL-AUDIT.json'),('ROOT-REVIEW.json',root/'root-review-r1/ROOT-REVIEW.json'),('absorbing-walk-portable.zip',package)]:
 b=path.read_bytes();seal['files'].append({'name':name,'native':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()})
 (dest/(name+'.b64')).write_text(base64.b64encode(b).decode())
(dest/'SEAL.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps(seal))
