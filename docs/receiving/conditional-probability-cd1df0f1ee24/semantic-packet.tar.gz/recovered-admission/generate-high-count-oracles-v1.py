import json
from fractions import Fraction
v=json.loads("{\"queries\":[{\"id\":\"joint_A_B\",\"numerator_cells\":[0],\"denominator_cells\":[0,1,2,3]},{\"id\":\"joint_A_notB\",\"numerator_cells\":[1],\"denominator_cells\":[0,1,2,3]},{\"id\":\"joint_notA_B\",\"numerator_cells\":[2],\"denominator_cells\":[0,1,2,3]},{\"id\":\"joint_neither\",\"numerator_cells\":[3],\"denominator_cells\":[0,1,2,3]},{\"id\":\"marginal_A\",\"numerator_cells\":[0,1],\"denominator_cells\":[0,1,2,3]},{\"id\":\"marginal_notA\",\"numerator_cells\":[2,3],\"denominator_cells\":[0,1,2,3]},{\"id\":\"marginal_B\",\"numerator_cells\":[0,2],\"denominator_cells\":[0,1,2,3]},{\"id\":\"marginal_notB\",\"numerator_cells\":[1,3],\"denominator_cells\":[0,1,2,3]},{\"id\":\"A_given_B\",\"numerator_cells\":[0],\"denominator_cells\":[0,2]},{\"id\":\"notA_given_B\",\"numerator_cells\":[2],\"denominator_cells\":[0,2]},{\"id\":\"A_given_notB\",\"numerator_cells\":[1],\"denominator_cells\":[1,3]},{\"id\":\"notA_given_notB\",\"numerator_cells\":[3],\"denominator_cells\":[1,3]},{\"id\":\"B_given_A\",\"numerator_cells\":[0],\"denominator_cells\":[0,1]},{\"id\":\"notB_given_A\",\"numerator_cells\":[1],\"denominator_cells\":[0,1]},{\"id\":\"B_given_notA\",\"numerator_cells\":[2],\"denominator_cells\":[2,3]},{\"id\":\"notB_given_notA\",\"numerator_cells\":[3],\"denominator_cells\":[2,3]}],\"tables\":[[\"all_max_independent\",[\"999999999999999999\",\"999999999999999999\",\"999999999999999999\",\"999999999999999999\"]],[\"max_only_neither\",[\"0\",\"0\",\"0\",\"999999999999999999\"]],[\"max_perfect_association\",[\"999999999999999999\",\"0\",\"0\",\"999999999999999999\"]],[\"max_near_independent_exactly_false\",[\"999999999999999997\",\"999999999999999998\",\"999999999999999998\",\"999999999999999999\"]],[\"above_binary64_integer_precision\",[\"9007199254740993\",\"9007199254740992\",\"0\",\"1\"]],[\"large_nonuniform_independent\",[\"99999999999999999\",\"199999999999999998\",\"299999999999999997\",\"599999999999999994\"]],[\"rare_joint_large_denominator\",[\"1\",\"999999999999999999\",\"999999999999999999\",\"0\"]],[\"large_asymmetric_exact_half_marginal\",[\"999999999999999999\",\"999999999999999997\",\"1\",\"3\"]]]}")
out={"receiver_schema":"semantic-table-admission-boundaries-v1","cell_order":["A∩B","A∩notB","notA∩B","neither"],"queries":v["queries"],"tables":[]}
for label,counts in v["tables"]:
 c=list(map(int,counts));x,y,z,w=c;n=sum(c)
 assert all(0<=a<=999999999999999999 for a in c)
 probabilities=[]
 for q in v["queries"]:
  a=sum(c[i] for i in q["numerator_cells"]);b=sum(c[i] for i in q["denominator_cells"])
  if b:
   f=Fraction(a,b);p=str(f.numerator)+"/"+str(f.denominator)
  else:p=None
  probabilities.append(p)
 independent=None if not n else Fraction(x,n)==Fraction(x+y,n)*Fraction(x+z,n)
 assert not n or independent==(x*w==y*z)
 out["tables"].append({"id":label,"counts":counts,"total":str(n),"probabilities":probabilities,"independent":independent,"identity_left":None if not n else str(x*n),"identity_right":None if not n else str((x+y)*(x+z)),"determinant":None if not n else str(x*w-y*z)})
assert out["tables"][3]["determinant"]=="-1"
assert out["tables"][4]["probabilities"][0]=="1/2"
assert out["tables"][5]["independent"] is True
assert out["tables"][7]["probabilities"][6]=="1/2"
print(json.dumps(out,ensure_ascii=False,separators=(",",":")))

