# Independent RecallWeave LP receiving

Status: **PASS, no blocking mathematical or lesson finding** for the exact model and course identified below. This is a model and native course-format review; it does not qualify the new UI, browser behavior, or repository integration.

The model is `src/linear-programming.mjs`, SHA-256 `63e3a3661c0c3e1ab7da3eedd2aa3ed72c2de479ee7e29973d75de9dfdc1e18d`. The course is `courses/linear-programming.json`, 13,211 bytes, SHA-256 `d251a3bc174d109d185d600871f8890d81722aed5c190f759b604d162685c5c5`. Both author files were read back unchanged when this packet was frozen.

## Model receiving

The hand-derived geometry and scope expectations were committed before reading the implementation at `c882a1231082e06e82d2b18ac17d73c1a66e4d9c`; the separate Python Fraction oracle was committed at `f3d60ec0cf0143e66399a200963ec8e41f6c4594`. The completed model gate is committed at `a2ed6a48779d87e5bd36ea67c8508864c46192f5`.

All 18 independent native Node 22.22.1 groups passed: 14 exact geometry cases plus row transformations, API admission, text grammar/boundaries, and preset validity. The geometry receiver checked every one of 254 boundary-pair records, exact vertex sets, objective values, slacks, active row identities, originating pairs, optimal sets and hull orientation. It includes fractional extrema, minimization, a tied edge, a zero-objective polygon, nonzero objective constant on a feasible line, a singleton, degenerate boxes, infeasibility, zero-normal rows, redundant/coincident/parallel inequalities, and maximum admitted input ranges.

One oracle terminology clarification is preserved additively: `optimum.kind` describes the geometry of the optimal set; `wholeRegion` independently records whether that set covers the feasible region. The original complete optimal point sets and values did not change. The full feasible line therefore has kind `segment` and `wholeRegion: true`. No runtime change was requested.

See `MODEL-ACCEPTANCE.json`, `MODEL-RECEIVING.md`, `model-v1/RESULTS.json` and `API-LABEL-CLARIFICATION.json`.

## Blinded lesson receiving

Only each question's ID, prompt and options were exposed first. Independent zero-based answers and explicit calculations for all 16 questions were committed at `538e2fe494873850dd1c62b3b69fd168e7916ef4`, before revealing any authored answer, explanation or transfer prompt. The candidate model was not used as an answer oracle.

All **16 of 16** independent answers match the authored keys. After the key reveal, every explanation and transfer prompt was reviewed. The exact arithmetic is consistent; the lesson distinguishes feasible candidates from accepted intersections, full optimal segments/regions from their endpoint or vertex representation, empty feasibility from unbounded objective behavior, and real variables from integer input data. The box is correctly treated as an actual constraint. No correction is requested.

The exact course was also admitted by the unchanged original `src/deck.mjs` copied from base `698902f9c9c1d5c5023092b85b3632a7cb7a01ed`, SHA-256 `621438c166ec4bfafd9d87c698a1d46cb1722f4fb92dcbb8d9f52fce682c338b`. The actual Node 22.22.1 receiver exited 0 with empty stderr, received **16 items and 5 concepts**, matched all independent choices, and verified the native immutable deck shape. The receiving code and all stdout, stderr and execution metadata are under `lesson-v1/`.

The mathematical background reference is [MIT 6.854, Linear Programming](https://courses.csail.mit.edu/6.854/21/Notes/n11-lp.html). This review uses the standard convex halfspace and bounded-polytope vertex facts; the review cases and lesson solutions were independently derived.

## Limits and preservation

No author tests were read. No candidate source was edited. No GitHub writes, Actions runs, large installs, browser launches, native service operations or live index operations were performed. The accepted scope is explicitly bounded, continuous, two-variable linear programming with exact rational results; no unbounded, integer, physical or generalized solver capability is claimed.

The original hand oracle, clarification, model results, blinded questions, pre-reveal solutions, revealed-key comparison, original validator and native execution logs are preserved. `LP-ACCEPTANCE.json` and `LP-MEMBER-INDEX.json` bind this packet's exact evidence bytes.
