const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');
const { pathToFileURL } = require('node:url');
const crypto = require('node:crypto');

const root = path.resolve(__dirname, '..');
const candidate = path.join(root, 'candidate');
const run = path.join(__dirname, process.argv[2]);
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const sourcePaths = [
  'courses/sampling-aliasing.json', 'courses/sampling-aliasing.md', 'courses/sampling-aliasing-lab.html',
  'src/sampling-aliasing.mjs', 'src/sampling-aliasing-ui.mjs',
  'templates/sampling-aliasing-lab.html', 'tools/build-sampling-aliasing.mjs',
  'tests/sampling-aliasing.test.mjs', 'tests/sampling-aliasing-course.test.mjs',
  'src/deck.mjs', 'src/knowledge.mjs', 'src/review.mjs', 'src/session-export.mjs', 'data/deck.json',
];

async function pinSources() {
  return Promise.all(sourcePaths.map(async name => {
    const bytes = await fs.readFile(path.join(candidate, name));
    return { path: name, bytes: bytes.length, sha256: sha(bytes) };
  }));
async function main() {
  await fs.mkdir(run);
  await fs.mkdir(path.join(run, 'tmp'));
  await fs.mkdir(path.join(run, 'downloads'));
  process.env.TMPDIR = path.join(run, 'tmp');
  const { chromium } = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'playwright'));
  const before = await pinSources();
  await fs.writeFile(path.join(run, 'source-before.json'), JSON.stringify(before, null, 2) + '\n');
  const report = { startedAt: new Date().toISOString(), scenarios: [], requests: [], pageErrors: [], consoleErrors: [], downloads: [] };
  let browser;
  try {
    browser = await chromium.launch({
      executablePath: '/workspace/scratch/0c6c4d37eb0f/native-product-worker/browser-runtime/chromium',
      headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'],
      downloadsPath: path.join(run, 'downloads'),
    });
    report.browserVersion = browser.version();
    const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, acceptDownloads: true });
    const page = await context.newPage();
    page.on('request', request => report.requests.push(request.url()));
    page.on('pageerror', error => report.pageErrors.push(String(error)));
    page.on('console', message => { if (message.type() === 'error') report.consoleErrors.push(message.text()); });

    async function observed(label) {
      const state = await page.evaluate(() => ({
        frequency: document.getElementById('sa-frequency').value,
        rate: document.getElementById('sa-rate').value,
        hidden: document.getElementById('sa-result').hidden,
        error: document.getElementById('sa-error').hidden ? null : document.getElementById('sa-error').textContent,
        disabled: document.getElementById('sa-download-csv').disabled,
        readouts: ['sa-reference-value', 'sa-comparison-value', 'sa-alias-value', 'sa-half-rate'].map(id => document.getElementById(id).textContent),
        rows: [...document.querySelectorAll('#sa-sample-rows tr')].map(row => [...row.cells].map(cell => cell.textContent)),
        sampleMarkers: document.querySelectorAll('#sa-plot circle').length,
        relation: document.getElementById('sa-relation').textContent,
        overflow: document.documentElement.scrollWidth > window.innerWidth,
      }));
      report.scenarios.push({ label, state });
      return state;
    }
    async function download(selector, name) {
      const waiting = page.waitForEvent('download');
      await page.locator(selector).click();
      const item = await waiting;
      const destination = path.join(run, name);
      await item.saveAs(destination);
      const bytes = await fs.readFile(destination);
      report.downloads.push({ name, suggestedFilename: item.suggestedFilename(), bytes: bytes.length, sha256: sha(bytes) });
      return bytes;
    }
    async function forbidForcedDownload() {
      const event = page.waitForEvent('download', { timeout: 400 }).then(() => true, error => {
        if (error.name !== 'TimeoutError') throw error;
        return false;
      });
      await page.locator('#sa-download-csv').evaluate(element => element.dispatchEvent(new MouseEvent('click', { bubbles: true })));
      assert.equal(await event, false, 'invalid state must not create a download');
    }

    await page.goto(pathToFileURL(path.join(candidate, 'courses/sampling-aliasing-lab.html')).href);
    await page.locator('#sa-result').waitFor({ state: 'visible' });
    await page.locator('#sa-table-detail summary').click();
    const initial = await observed('default 9 Hz at 8 samples/sec');
    assert.deepEqual(initial.readouts, ['9 Hz', '1 Hz', '1 Hz', '4 Hz']);
    assert.equal(initial.rows.length, 9);
    assert.equal(initial.sampleMarkers, 9);
    assert.equal(initial.overflow, false);
    const defaultCsv = await download('#sa-download-csv', 'default-9-at-8.csv');
    const parsed = defaultCsv.toString().trim().split('\n').slice(1).map(line => line.split(',').map(Number));
    for (let i = 0; i < parsed.length; i++) {
      assert.deepEqual(parsed[i].slice(0, 6), [i, i / 8, 9, 8, 1, 1]);
      initial.rows[i].forEach((value, column) => assert.ok(Math.abs(Number(value) - parsed[i][[0, 1, 6, 7][column]]) < 0.00000051));
    }
    await page.locator('#sa-table-detail summary').click();
    await page.screenshot({ path: path.join(run, 'desktop.png'), fullPage: true });

    await page.locator('[data-sa-frequency="5"]').click();
    const below = await observed('below-half-rate preset still shows a different higher alias');
    assert.deepEqual(below.readouts, ['5 Hz', '17 Hz', '5 Hz', '6 Hz']);
    assert.equal(below.rows.length, 13);
    assert.match(below.relation, /higher matching alternative/);
    await page.locator('#sa-frequency').focus();
    await page.keyboard.press('ArrowUp');
    const keyboard = await observed('keyboard ArrowUp edits the frequency by one half-Hz step');
    assert.equal(keyboard.frequency, '5.5');
    assert.deepEqual(keyboard.readouts.slice(0, 3), ['5.5 Hz', '17.5 Hz', '5.5 Hz']);
    assert.equal(await page.locator('#sa-frequency').evaluate(element => element === document.activeElement), true);

    await page.locator('[data-sa-frequency="4"]').click();
    const boundary = await observed('boundary cosine is correctly labeled');
    assert.match(boundary.relation, /exactly at the half-rate/);
    boundary.rows.forEach((row, index) => assert.equal(Number(row[2]), (-1) ** index));
    await page.locator('[data-sa-frequency="8"]').click();
    const dc = await observed('constant-looking samples retain the 8 Hz reference');
    assert.deepEqual(dc.readouts.slice(0, 3), ['8 Hz', '0 Hz', '0 Hz']);
    dc.rows.forEach(row => assert.equal(Number(row[2]), 1));

    await page.locator('#sa-rate').fill('');
    const empty = await observed('empty rate retires observations and downloads');
    assert.equal(empty.hidden, true);
    assert.equal(empty.disabled, true);
    assert.equal(empty.rows.length, 0);
    assert.equal(empty.sampleMarkers, 0);
    await forbidForcedDownload();
    await page.locator('#sa-rate').fill('8.5');
    assert.equal((await observed('noninteger rate remains invalid')).hidden, true);
    await forbidForcedDownload();
    await page.locator('#sa-rate').fill('8');
    await page.locator('#sa-frequency').fill('3.25');
    assert.equal((await observed('off-step frequency remains invalid')).hidden, true);
    await forbidForcedDownload();
    await page.locator('[data-sa-frequency="9"]').click();
    await page.locator('#sa-frequency').evaluate(element => { element.value = '100'; });
    await forbidForcedDownload();
    const stale = await observed('forced click rechecks an input changed without an input event');
    assert.equal(stale.hidden, true);
    assert.equal(stale.disabled, true);
    assert.equal(await page.locator('#sa-frequency').getAttribute('aria-invalid'), 'true');

    await page.locator('#sa-frequency').fill('9');
    await page.locator('#sa-rate').fill('24');
    const changed = await observed('a changed acquisition exports the same new state');
    assert.deepEqual(changed.readouts, ['9 Hz', '33 Hz', '9 Hz', '12 Hz']);
    const changedCsv = (await download('#sa-download-csv', 'new-9-at-24.csv')).toString().trim().split('\n').slice(1).map(line => line.split(',').map(Number));
    assert.equal(changedCsv.length, 25);
    changedCsv.forEach((row, i) => assert.deepEqual(row.slice(0, 6), [i, i / 24, 9, 24, 33, 9]));

    await page.locator('#sa-frequency').fill('40');
    await page.locator('#sa-rate').fill('32');
    const maximum = await observed('supported maximum values');
    assert.equal(maximum.rows.length, 33);
    assert.deepEqual(maximum.readouts.slice(0, 3), ['40 Hz', '8 Hz', '8 Hz']);
    await download('#sa-download-csv', 'maximum-40-at-32.csv');
    const courseBytes = await download('#sa-download-course', 'downloaded-sampling-course.json');
    assert.deepEqual(courseBytes, await fs.readFile(path.join(candidate, 'courses/sampling-aliasing.json')));

    await page.setViewportSize({ width: 390, height: 844 });
    await page.locator('[data-sa-frequency="9"]').click();
    await page.locator('#sa-table-detail summary').click();
    const mobile = await observed('390 pixel direct-file layout and numerical alternative');
    assert.equal(mobile.overflow, false);
    assert.equal(mobile.rows.length, 9);
    await page.screenshot({ path: path.join(run, 'mobile.png'), fullPage: true });

    // Use the actually downloaded file as input to untouched published Deck studio.
    await page.setViewportSize({ width: 1280, height: 960 });
    await page.goto(pathToFileURL(path.join(__dirname, 'native-author/author.html')).href);
    await page.locator('#open-deck').setInputFiles(path.join(run, 'downloaded-sampling-course.json'));
    await page.locator('#open-preview').waitFor({ state: 'visible' });
    assert.equal(await page.locator('#deck-title').inputValue(), '');
    const preview = await page.locator('#open-preview-summary').textContent();
    await page.locator('#replace-draft').click();
    const originalCourse = JSON.parse(courseBytes.toString());
    assert.equal(await page.locator('#deck-title').inputValue(), originalCourse.title);
    assert.equal(await page.locator('#question-picker option').count(), 12);
    await page.locator('#check-draft').click();
    await page.locator('#author-preview').waitFor({ state: 'visible' });
    const answerKey = await page.locator('#preview-content').textContent();
    for (const item of originalCourse.items) {
      assert.ok(answerKey.includes(item.prompt), `native preview retains ${item.id}`);
      assert.ok(answerKey.includes(item.options[item.answer]), `native key retains ${item.id}`);
    }
    const studioBytes = await download('#download-deck', 'native-studio-export.json');
    const { parseDeck, serializeDeck } = await import(pathToFileURL(path.join(candidate, 'src/deck.mjs')).href);
    assert.deepEqual(parseDeck(studioBytes.toString()), parseDeck(courseBytes.toString()));
    assert.equal(studioBytes.toString(), serializeDeck(originalCourse));
    report.scenarios.push({ label: 'actual downloaded course through existing Deck studio preview, explicit replace, check and export', state: { preview, items: 12, semanticCoursePreserved: true, nativeSerializationExact: true } });
    await page.screenshot({ path: path.join(run, 'native-studio.png'), fullPage: true });

    assert.deepEqual(report.pageErrors, []);
    assert.deepEqual(report.consoleErrors, []);
    assert.deepEqual(report.requests.filter(url => !url.startsWith('file:') && !url.startsWith('blob:')), []);
    report.success = true;
    await context.close();
  } catch (error) {
    report.success = false;
    report.failure = { name: error.name, message: error.message, stack: error.stack };
    process.exitCode = 1;
  } finally {
    if (browser) await browser.close();
    const after = await pinSources();
    report.sourceUnchanged = JSON.stringify(before) === JSON.stringify(after);
    if (!report.sourceUnchanged) process.exitCode = 1;
    report.completedAt = new Date().toISOString();
    await fs.writeFile(path.join(run, 'source-after.json'), JSON.stringify(after, null, 2) + '\n');
    await fs.writeFile(path.join(run, 'receipt.json'), JSON.stringify(report, null, 2) + '\n');
    process.stdout.write(JSON.stringify({ success: report.success, scenarios: report.scenarios.length, downloads: report.downloads.length, browser: report.browserVersion, sourceUnchanged: report.sourceUnchanged, failure: report.failure, receipt: path.join(run, 'receipt.json') }) + '\n');
  }
}
main().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
