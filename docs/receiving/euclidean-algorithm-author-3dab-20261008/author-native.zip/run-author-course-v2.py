from pathlib import Path
import hashlib, json, platform, subprocess, sys, time
root = Path("/Users/me/recallweave-euclid-3dab-20261008")
source = root / "source"
out = root / "receiving" / "author-course-v2"
out.mkdir(exist_ok=False)
node = "/opt/homebrew/Cellar/node/26.3.0/bin/node"
def pins():
    result = {}
    for path in sorted(source.rglob("*")):
        if not path.is_file(): continue
        data = path.read_bytes()
        result[str(path.relative_to(source))] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}
    return result
before = pins()
(out / "source-before.json").write_text(json.dumps(before, indent=2) + "\n")
command = [node, "--test", "--test-reporter=tap", "tests/euclidean-algorithm-course.test.mjs"]
started = time.time()
run = subprocess.run(command, cwd=source, capture_output=True, timeout=90)
(out / "stdout.txt").write_bytes(run.stdout)
(out / "stderr.txt").write_bytes(run.stderr)
after = pins()
(out / "source-after.json").write_text(json.dumps(after, indent=2) + "\n")
report = {"subject": "RecallWeave Euclidean corrected course V2, unchanged learner APIs and exact standalone parity",
"base_commit": "169b618ce71d2d4702a0d2ef740821df53581ad2",
"base_tree": "96471ac3db79b3c5329a27837d92d81f34b1f318",
"command": command, "cwd": str(source),
"runtime": {"node": subprocess.check_output([node, "--version"], text=True).strip(), "python": sys.version, "platform": platform.platform()},
"exit_code": run.returncode, "elapsed_seconds": round(time.time()-started, 3), "guarded_source_count": len(before), "all_source_unchanged": before == after,
"stdout_bytes": len(run.stdout), "stderr_bytes": len(run.stderr), "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(run.stderr).hexdigest()}
(out / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
print(run.stdout.decode())
if run.stderr: print(run.stderr.decode(), file=sys.stderr)
sys.exit(0 if run.returncode == 0 and before == after else 1)
