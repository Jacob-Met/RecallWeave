
import {fileURLToPath} from 'node:url';
async function receiveFocus(){
 const [rootArg,portableArg,outputArg,executable]=process.argv.slice(2);
 if(!rootArg||!portableArg||!outputArg||!executable)throw new Error('Need source, fresh extraction, output, Chrome.');
 const source=resolve(rootArg),portable=resolve(portableArg),output=resolve(outputArg);
 await mkdir(output);
 const receipt={at:new Date().toISOString(),groups:[],downloads:[],screenshots:[],source:{},cleanup:null};
 const runtimePaths=['courses/coalition-power-core.mjs','courses/coalition-power.json','courses/coalition-power.md','courses/coalition-power-explorer-ui.mjs','courses/coalition-power-explorer.template.html','courses/coalition-power-explorer.html'];
 for(const path of runtimePaths)receipt.source[path]=sha256(await readFile(join(source,path)));
 assert.equal(receipt.source['courses/coalition-power-explorer.html'],'d72b621c56b76947c11a4cbfc6123749832cd011e70907543145503932874dd6');
 const core=await import(pathToFileURL(join(source,'courses/coalition-power-core.mjs')));
 const course=await readFile(join(source,'courses/coalition-power.json'));
 let b;
 const group=async(name,fn)=>{await fn();receipt.groups.push({name,passed:true});console.log('PASS '+name);};
 const download=async(selector)=>{const d=await b.download(selector);receipt.downloads.push({name:d.suggestedFilename,path:d.path,bytes:d.bytes.length,sha256:d.sha256,completed:d.completed.state});return d;};
 try{
  b=await openBrowser(output,executable);receipt.browser=b.version;receipt.pid=b.childPid;receipt.profile=b.profile;
  await b.navigate(join(source,'courses/coalition-power-explorer.html'),1280,1000);
  await until(()=>b.evaluate('(()=>{const e=document.querySelector("#result");return e&&!e.hidden;})()'),'corrected explorer');
  await group('Only actual keyboard-focused control receives the visible focus outline',async()=>{
   const initial=await b.evaluate('[...document.querySelectorAll("button")].map(e=>({id:e.id,style:getComputedStyle(e).outlineStyle,width:getComputedStyle(e).outlineWidth}))');
   assert.ok(initial.every(x=>x.style==='none'||x.width==='0px'));receipt.initialStyles=initial;
   await b.key('Tab');
   assert.equal(await b.evaluate('document.activeElement.id'),'course-save');
   const focused=await b.evaluate('(()=>{const e=document.activeElement,s=getComputedStyle(e);return {visible:e.matches(":focus-visible"),style:s.outlineStyle,width:s.outlineWidth};})()');
   assert.deepEqual(focused,{visible:true,style:'solid',width:'3px'});receipt.focusedStyle=focused;
   assert.equal(await b.evaluate('[...document.querySelectorAll("button")].filter(e=>getComputedStyle(e).outlineStyle!=="none"&&getComputedStyle(e).outlineWidth!=="0px").length'),1);
   receipt.screenshots.push(await b.screenshot('desktop-final.png'));
   await b.viewport(390,844);assert.ok(await b.evaluate('document.documentElement.scrollWidth<=innerWidth'));
   receipt.screenshots.push(await b.screenshot('phone-final.png'));
  });
  await group('Refreshed exact package retains relative entry/learner routes and actual course/observation bytes',async()=>{
   await b.navigate(join(portable,'START-HERE.html'),1280,1000);
   await b.activate('a[href="courses/coalition-power-explorer.html"]');
   await until(()=>b.evaluate('(()=>{const e=document.querySelector("#result");return location.href.endsWith("/courses/coalition-power-explorer.html")&&e&&!e.hidden;})()'),'new package explorer');
   assert.equal(await b.evaluate('document.querySelectorAll("#coalitions tr").length'),8);
   const c=await download('#course-save');assert.deepEqual(c.bytes,course);
   const o=await download('#observation-save');
   assert.equal(o.bytes.toString(),JSON.stringify({format:'recallweave-coalition-power-observation/1',analysis:core.analyzeGame([6,4,2],7),view:{player_index:1,critical_only:false}},null,2)+'\n');
   await b.activate('#learner-link');
   await until(()=>b.evaluate('location.href.endsWith("/demo.html")&&!!document.querySelector("#deck-file")'),'new package relative learner');
   assert.equal(await b.evaluate('location.href'),pathToFileURL(join(portable,'demo.html')).href);
   assert.equal(sha256(await readFile(join(portable,'demo.html'))),'fe7d44d125f9797c867251c05f02868a7cacf91c7d5129f46bbca3c69dc7ae1d');
   assert.equal(b.errors.length,0);assert.ok(b.requests.every(x=>x.startsWith('file:')));
   receipt.requests=[...b.requests];receipt.errors=[...b.errors];
  });
  receipt.accepted=true;
 }catch(error){receipt.accepted=false;receipt.error=String(error.stack??error);throw error;}
 finally{if(b){await b.close();receipt.cleanup={closed:true,profileRemoved:true};}await writeFile(join(output,'focused-receiving.json'),JSON.stringify(receipt,null,2)+'\n');}
}
receiveFocus().catch(error=>{console.error(error);process.exitCode=1;});
