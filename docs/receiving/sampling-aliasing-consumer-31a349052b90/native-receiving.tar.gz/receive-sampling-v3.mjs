#!/usr/bin/env node
// Course-specific independent receiving. CDP transport follows the repository's
// optional native runners; assertions and scenarios are authored for this course.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, mkdtemp, rm, copyFile, stat } from 'node:fs/promises';
import { extname, join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const option = (name, fallback) => {
  const i = process.argv.indexOf(name);
  return i < 0 ? fallback : process.argv[i + 1];
};
const project = resolve(option('--root', './source'));
const output = resolve(option('--output', './run-v1'));
const executable = option('--browser', 'chromium');
const manifestPath = resolve(option('--manifest', './source-manifest.json'));
const suppliedCourse = option('--course-input', null);
await mkdir(output, {recursive:true});
const downloadPath = join(output, 'downloads');
await mkdir(downloadPath, {recursive:true});
const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const pin = bytes => ({
  bytes:bytes.length, sha256:hash(bytes),
  git_blob:createHash('sha1').update(Buffer.concat([Buffer.from('blob ' + bytes.length + '\0'),bytes])).digest('hex')
});
const report = {
  status:'running', source:{repo:manifest.repo,commit:manifest.commit,tree:manifest.tree},
  runtime:{node:process.version,platform:process.platform,arch:process.arch,executable},
  sourceFiles:manifest.source_files, checks:[], downloads:[], screenshots:[], sessions:[],
  requests:[], served:[], blockedRequests:[], pageErrors:[], transport:[], stages:[], startedAt:new Date().toISOString()
};
const verifySource = async () => {
  for (const expected of manifest.source_files) {
    assert.deepEqual(pin(await readFile(join(project,expected.path))),
      {bytes:expected.bytes,sha256:expected.sha256,git_blob:expected.git_blob},expected.path);
  }
};
await verifySource();
const rawCourse = await readFile(join(project,'courses/sampling-aliasing.json'));
const {parseDeck} = await import(pathToFileURL(join(project,'src/deck.mjs')));
const {initialMastery, updateMastery, selectNextItem} = await import(pathToFileURL(join(project,'src/knowledge.mjs')));
const course = parseDeck(rawCourse.toString('utf8'));
const misses = new Set(['sampling-assumption-boundary','sampling-acquisition-filter']);
const allowedFiles = new Map(manifest.source_files.map(x=>[x.path,x]));
const server = createServer(async (request,response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url,'http://localhost').pathname);
    const relative = pathname === '/' ? 'index.html' : pathname.slice(1);
    if (!allowedFiles.has(relative) || request.method !== 'GET') { response.writeHead(404).end(); return; }
    const bytes = await readFile(join(project,relative));
    const expected = allowedFiles.get(relative);
    assert.equal(hash(bytes),expected.sha256);
    report.served.push({path:relative,...pin(bytes)});
    const mime={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.json':'application/json'}[extname(relative)];
    response.writeHead(200,{'Content-Type':(mime || 'application/octet-stream')+'; charset=utf-8','Cache-Control':'no-store'});
    response.end(bytes);
  } catch(error) { report.pageErrors.push('owned server: '+error.message); response.writeHead(500).end(); }
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base='http://127.0.0.1:'+server.address().port;
const profile=await mkdtemp(join(output,'profile-'));
let browser,socket,sessionId,targetId,sequence=0,browserLog='';
const pending=new Map(),downloads=new Map();
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function waitFor(check,label) {
  let last;
  const deadline=Date.now()+20000;
  while(Date.now()<deadline) {
    try { if(await check()) return; } catch(e) { last=e; }
    if(browser?.exitCode!==null && browser?.exitCode!==undefined) throw Error('Browser exited '+browser.exitCode+': '+browserLog);
    await sleep(100);
  }
  throw Error('Timed out: '+label+(last?' ('+last.message+')':''));
}
function command(method,params={},scoped=true) {
  const id=++sequence;
  if (/Input\.|Page.navigate|DOM.setFile/.test(method)) report.transport.push({id,method,params,at:new Date().toISOString()});
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method));},12000);
    pending.set(id,{resolve,reject,timer});
    socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));
  });
}
async function evaluate(expression) {
  const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails) throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);
  return r.result.value;
}
async function key(name) {
  const code=name==='Tab'?9:13;
  for(const type of ['keyDown','keyUp'])
    await command('Input.dispatchKeyEvent',{type,key:name,code:name,windowsVirtualKeyCode:code,nativeVirtualKeyCode:code,
      ...(name==='Enter'&&type==='keyDown'?{text:'\r',unmodifiedText:'\r'}:{})});
}
async function activate(selector) {
  report.stages.push({action:'activate',selector,at:new Date().toISOString()});
  await writeFile(join(output,'checkpoint.json'),JSON.stringify(report,null,2)+'\n');
  assert.equal(await evaluate('!!document.querySelector('+JSON.stringify(selector)+')'),true,'control '+selector);
  await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');
  await key('Enter');
}
const exists=selector=>evaluate('!!document.querySelector('+JSON.stringify(selector)+')');
const text=selector=>evaluate('document.querySelector('+JSON.stringify(selector)+')?.textContent');
async function visible(selector) {
  return evaluate('(()=>{const x=document.querySelector('+JSON.stringify(selector)+');return !!x&&!x.hidden&&x.getClientRects().length>0})()');
}
async function newPage(url,width=1280,height=900) {
  report.stages.push({action:'navigate',url,width,at:new Date().toISOString()});
  await writeFile(join(output,'checkpoint.json'),JSON.stringify(report,null,2)+'\n');
  const old=targetId;
  ({targetId}=await command('Target.createTarget',{url:'about:blank'},false));
  ({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));
  if(old) await command('Target.closeTarget',{targetId:old},false);
  await command('Page.enable');
  await command('Runtime.enable');
  await command('Network.enable');
  await command('Fetch.enable',{patterns:[{urlPattern:'http://*'},{urlPattern:'https://*'}]});
  await command('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
  await command('Page.navigate',{url});
  await waitFor(()=>evaluate('document.URL==='+JSON.stringify(url)+'&&document.readyState==="complete"'),'document '+url);
}
async function chooseFile(selector,path) {
  report.stages.push({action:'file-input',selector,path,at:new Date().toISOString()});
  await writeFile(join(output,'checkpoint.json'),JSON.stringify(report,null,2)+'\n');
  const {root}=await command('DOM.getDocument');
  const {nodeId}=await command('DOM.querySelector',{nodeId:root.nodeId,selector});
  assert.ok(nodeId,'file input '+selector);
  await command('DOM.setFileInputFiles',{nodeId,files:[path]});
}
async function saveDownload(selector,name) {
  const before=new Set(downloads.keys());
  await activate(selector);
  let item;
  await waitFor(()=>{
    item=[...downloads.values()].find(x=>!before.has(x.guid)&&x.state==='completed');
    return !!item;
  },'completed download '+name);
  const source=join(downloadPath,item.guid);
  const bytes=await readFile(source);
  const path=join(downloadPath,name);
  await copyFile(source,path);
  await rm(source);
  const result={name,suggestedFilename:item.suggestedFilename,...pin(bytes)};
  report.downloads.push(result);
  return {path,bytes,entry:result};
}
async function openTrace() {
  if(!await evaluate('document.querySelector("#trace-archive-panel").open'))
    await activate('#trace-archive-panel > summary');
}
async function snapshot() {
  return evaluate('({html:document.querySelector("#session-content").innerHTML,progress:document.querySelector("[role=progressbar]").getAttribute("aria-valuenow"),title:document.title,subject:document.querySelector("#lesson-description").textContent})');
}
async function screen(name,selector) {
  await evaluate('document.querySelector('+JSON.stringify(selector)+').scrollIntoView({block:"start"})');
  const {data}=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
  const bytes=Buffer.from(data,'base64');
  await writeFile(join(output,name),bytes);
  report.screenshots.push({name,...pin(bytes)});
}
function passed(name,details) {
  report.checks.push({name,passed:true,...(details?{details}:{})});
  console.log('PASS '+name);
}
async function previewCourse(file) {
  await chooseFile('#deck-file',file);
  await waitFor(()=>visible('#deck-preview'),'course preview');
  assert.equal(await text('#deck-preview-title'),course.title);
  assert.match(await text('.deck-preview-count'),/12 questions · 4 concepts/);
  assert.equal(await text('.deck-preview-attribution'),'Attribution supplied in the deck: '+course.attribution);
  assert.equal(await text('.deck-preview-license'),'License supplied in the deck: '+course.license);
  const prompts=await evaluate('[...document.querySelectorAll(".deck-questions li")].map(x=>({prompt:x.querySelector("strong").textContent,concept:x.querySelector("p").textContent}))');
  assert.deepEqual(prompts,course.items.map(x=>({
    prompt:x.prompt,concept:x.concept+' · '+(x.prerequisites.length?'Prerequisites: '+x.prerequisites.join(', '):'No prerequisites')
  })));
}
async function startCourse(file) {
  await previewCourse(file);
  await activate('#start-deck');
  await waitFor(()=>exists('.question-card h2'),'imported question');
  assert.equal(await text('#lesson-description'),course.title);
  assert.equal(await text('#step-count'),'0 / 12');
  assert.deepEqual(await evaluate('[...document.querySelectorAll("#lesson-map .deck-concept")].map(x=>x.textContent)'),course.concepts);
}
async function answerCourse() {
  const asked=new Set(),first=[],mastery=initialMastery(course.concepts);
  for(let n=0;n<course.items.length;n++) {
    const expected=selectNextItem(course.items,asked,mastery);
    const prompt=await text('.question-card h2');
    assert.equal(prompt,expected.prompt,'native selector receiving at '+n);
    assert.ok(!asked.has(expected.id)); asked.add(expected.id);
    const options=await evaluate('[...document.querySelectorAll("[data-choice]")].map(x=>({choice:Number(x.dataset.choice),key:x.querySelector(".choice-key").textContent,text:x.textContent.slice(x.querySelector(".choice-key").textContent.length)}))');
    assert.deepEqual(options.map(x=>x.choice).sort((a,b)=>a-b),[0,1,2,3]);
    assert.deepEqual(options,options.map((x,i)=>({choice:x.choice,key:String.fromCharCode(65+i),text:expected.options[x.choice]})));
    const choice=misses.has(expected.id)?(expected.answer+1)%4:expected.answer;
    const correct=choice===expected.answer;
    await activate('[data-choice="'+choice+'"]');
    const feedback=await text('#feedback-slot .feedback');
    assert.ok(feedback.includes(expected.explanation));
    assert.ok(feedback.includes(expected.transfer));
    assert.equal(await evaluate('document.activeElement.id'),'next-button');
    mastery[expected.concept]=updateMastery(mastery[expected.concept],correct);
    first.push({item:expected.id,choice,correct,displayOrder:options.map(x=>x.choice)});
    await key('Enter');
    await waitFor(()=>n===course.items.length-1?exists('.result-card'):exists('.question-card h2'),'next question/result');
  }
  assert.equal(await text('#step-count'),'12 / 12');
  assert.match(await text('#first-try-summary'),/10 of 12/);
  const state={first,mastery,missed:first.filter(x=>!x.correct).map(x=>x.item)};
  await verifyReview(state,[]);
  return state;
}
async function verifyReview(state,practice) {
  const rows=await evaluate('[...document.querySelectorAll(".review-item")].map(x=>({prompt:x.querySelector(".review-prompt").textContent,status:x.querySelector(".review-status").textContent,choices:[...x.querySelectorAll(".review-answers dd")].map(y=>y.textContent),explanation:x.querySelector(".review-body > p").textContent,transfer:x.querySelector(".review-transfer").textContent,practice:x.querySelector(".review-practice-answer")?.textContent||null}))');
  assert.equal(rows.length,12);
  for(const [i,entry] of state.first.entries()) {
    const item=course.items.find(x=>x.id===entry.item);
    assert.equal(rows[i].prompt,item.prompt);
    assert.equal(rows[i].status,(entry.correct?'Correct':'Needs review')+' · first try');
    assert.deepEqual(rows[i].choices,[item.options[entry.choice],item.options[item.answer]]);
    assert.equal(rows[i].explanation,item.explanation);
    assert.equal(rows[i].transfer,'Apply the idea: '+item.transfer);
    const retry=practice.find(x=>x.item===entry.item);
    if(retry) assert.ok(rows[i].practice?.includes(item.options[retry.choice]));
    else assert.equal(rows[i].practice,null);
  }
  assert.deepEqual(await evaluate('[...document.querySelectorAll(".mastery-box output")].map(x=>x.textContent)'),
    course.concepts.map(c=>Math.round(state.mastery[c]*100)+'%'));
  assert.match(await text('#first-try-summary'),/10 of 12/);
  return rows;
}
function verifyTrace(bytes,state,retries=null) {
  const trace=JSON.parse(bytes.toString('utf8'));
  assert.equal(trace.format,'recallweave.learning-trace');
  assert.equal(trace.version,1);
  assert.equal(new Date(trace.savedAt).toISOString(),trace.savedAt);
  assert.deepEqual(trace.deck,course);
  assert.deepEqual(trace.firstAnswers,state.first.map(({item,choice})=>({item,choice})));
  assert.deepEqual(trace.mastery,state.mastery);
  assert.deepEqual(trace.practice,retries===null?null:{answers:retries});
  return trace;
}
function verifyNotes(bytes,state,retries=null) {
  const notes=bytes.toString('utf8');
  assert.ok(notes.startsWith('RecallWeave — study notes\n'+course.title+'\nSaved: '));
  assert.ok(notes.includes('10 of 12 connections correct on the first try.'));
  assert.ok(notes.includes('Practice does not change the first-session estimates.'));
  assert.ok(notes.includes(course.attribution)); assert.ok(notes.includes(course.license));
  for(const entry of state.first) {
    const item=course.items.find(x=>x.id===entry.item);
    const section='Your first answer: '+item.options[entry.choice]+'\nFirst try: '+(entry.correct?'correct':'needs review')+'\nCorrect answer: '+item.options[item.answer]+'\nExplanation: '+item.explanation+'\nApply the idea: '+item.transfer;
    assert.ok(notes.includes(section),'complete notes for '+entry.item);
  }
  for(const c of course.concepts) assert.ok(notes.includes(c+': '+Math.round(state.mastery[c]*100)+'%'));
  if(retries===null) assert.ok(notes.includes('Not started. 2 missed connections are available for practice.'));
  else assert.ok(notes.includes((retries.length===2?'Complete':'Paused')+': '+retries.length+' of 2 practice answers recorded; '+retries.length+' correct on retry.'));
}
async function retry(itemId) {
  const item=course.items.find(x=>x.id===itemId);
  assert.equal(await text('.practice-card h2'),item.prompt);
  const options=await evaluate('[...document.querySelectorAll("[data-practice-choice]")].map(x=>({choice:Number(x.dataset.practiceChoice),text:x.textContent.slice(1)}))');
  assert.deepEqual(options,options.map(x=>({choice:x.choice,text:item.options[x.choice]})));
  await activate('[data-practice-choice="'+item.answer+'"]');
  assert.ok((await text('#practice-feedback')).includes(item.explanation));
  assert.ok((await text('#practice-feedback')).includes(item.transfer));
  return {item:item.id,choice:item.answer};
}

try {
  browser=spawn(executable,[
    '--headless=new','--no-sandbox','--disable-gpu','--disable-background-networking',
    '--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check',
    '--disk-cache-size=1','--media-cache-size=1',
    '--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'
  ],{stdio:['ignore','ignore','pipe']});
  report.runtime.pid=browser.pid;
  browser.stderr.on('data',bytes=>{browserLog+=bytes.toString();});
  let launchError;
  browser.on('error',e=>{launchError=e;});
  let port,endpoint;
  await waitFor(async()=>{
    if(launchError) throw launchError;
    [port,endpoint]=(await readFile(join(profile,'DevToolsActivePort'),'utf8')).trim().split('\n');
    return !!port&&!!endpoint;
  },'native browser startup');
  socket=new WebSocket('ws://127.0.0.1:'+port+endpoint);
  socket.addEventListener('message',async event=>{
    const message=JSON.parse(event.data);
    if(message.id) {
      const p=pending.get(message.id);if(!p)return;
      pending.delete(message.id);clearTimeout(p.timer);
      message.error?p.reject(Error(message.error.message)):p.resolve(message.result);
    } else if(message.method==='Runtime.exceptionThrown') {
      report.pageErrors.push(message.params.exceptionDetails.exception?.description||message.params.exceptionDetails.text);
    } else if(message.method==='Network.requestWillBeSent') {
      report.requests.push({sessionId:message.sessionId,url:message.params.request.url,type:message.params.type});
    } else if(message.method==='Browser.downloadWillBegin'||message.method==='Browser.downloadProgress') {
      const value=message.params;downloads.set(value.guid,{...downloads.get(value.guid),...value});
    } else if(message.method==='Fetch.requestPaused') {
      const {requestId,request}=message.params;
      const external=new URL(request.url).origin!==base;
      if(external)report.blockedRequests.push(request.url);
      try {await command(external?'Fetch.failRequest':'Fetch.continueRequest',
        external?{requestId,errorReason:'BlockedByClient'}:{requestId});}
      catch(e){report.pageErrors.push('request policy: '+e.message);}
    }
  });
  await new Promise((resolve,reject)=>{
    socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});
  });
  report.runtime.browser=await command('Browser.getVersion',{},false);
  await command('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath,eventsEnabled:true},false);
  let actualCourse;
  if(suppliedCourse) {
    const bytes=await readFile(resolve(suppliedCourse));
    assert.deepEqual(bytes,rawCourse);
    actualCourse={path:resolve(suppliedCourse),bytes,entry:{name:'sampling-aliasing.json',...pin(bytes)}};
    report.receivedDownload={...actualCourse.entry,path:actualCourse.path,qualification:'Physical lab download from preserved local run-v1, transferred and verified byte-exact; not produced again by this run'};
  } else {
    await newPage(pathToFileURL(join(project,'courses/sampling-aliasing-lab.html')).href);
    await waitFor(()=>visible('#sa-result'),'actual lab computation ready');
    actualCourse=await saveDownload('#sa-download-course','sampling-aliasing.json');
    assert.deepEqual(actualCourse.bytes,rawCourse);
    assert.equal(actualCourse.entry.suggestedFilename,'sampling-aliasing.json');
    passed('actual offline lab download is the exact published 11,663-byte course',actualCourse.entry);
  }

  await newPage(base+'/index.html');
  await waitFor(()=>exists('#trace-archive-panel'),'modular app initialization and archive controls');
  await activate('#start-button');
  await waitFor(()=>exists('[data-choice]'),'bundled question');
  await activate('[data-choice="0"]');
  const prior=await snapshot();
  await previewCourse(actualCourse.path);
  assert.deepEqual(await snapshot(),prior);
  await activate('#cancel-deck');
  assert.deepEqual(await snapshot(),prior);
  passed('complete course preview and cancel preserve a real unfinished bundled answer');

  await startCourse(actualCourse.path);
  const state=await answerCourse();
  report.sessions.push({surface:'modular',width:1280,...state});
  await activate('.review-item > summary');
  assert.equal(await evaluate('document.querySelector(".review-item").open'),true);
  assert.equal(await evaluate('document.documentElement.scrollWidth>innerWidth'),false);
  await screen('modular-review.png','.review-list');
  passed('all twelve canonical questions, adaptive order, original text and 10/12 review reach the current modular learner');
  const firstNotes=await saveDownload('#save-notes-button','modular-first-notes.txt');
  await openTrace();
  const firstTrace=await saveDownload('#save-trace-button','modular-first-trace.json');
  verifyNotes(firstNotes.bytes,state);verifyTrace(firstTrace.bytes,state);
  passed('physical first-session notes and trace preserve complete course evidence and exact native estimates');

  await activate('#practice-button');
  await waitFor(()=>exists('.practice-card'),'first practice');
  const firstRetry=await retry(state.missed[0]);
  await activate('#back-to-review');
  await waitFor(()=>exists('.result-card'),'paused practice review');
  await verifyReview(state,[firstRetry]);
  const pausedNotes=await saveDownload('#save-notes-button','modular-paused-notes.txt');
  await openTrace();
  const pausedTrace=await saveDownload('#save-trace-button','modular-paused-trace.json');
  verifyNotes(pausedNotes.bytes,state,[firstRetry]);verifyTrace(pausedTrace.bytes,state,[firstRetry]);
  passed('one correct practice retry stays separate from first answers and survives actual paused downloads');

  await newPage(pathToFileURL(join(project,'demo.html')).href,390,844);
  await waitFor(()=>exists('#trace-archive-panel'),'standalone app initialization and archive controls');
  const fresh=await snapshot();
  await openTrace();
  await chooseFile('#trace-file',pausedTrace.path);
  await waitFor(async()=> (await text('#trace-restore-status')).includes('different course'),'wrong course refusal');
  assert.equal(await visible('#trace-preview'),false);
  assert.deepEqual(await snapshot(),fresh);
  await startCourse(actualCourse.path);
  const unanswered=await snapshot();
  await openTrace();
  await chooseFile('#trace-file',pausedTrace.path);
  await waitFor(()=>visible('#trace-preview'),'saved sampling trace preview');
  assert.match(await text('#trace-preview-summary'),/First try: 10 of 12/);
  assert.match(await text('#trace-preview-summary'),/Practice: 1 of 2/);
  assert.deepEqual(await snapshot(),unanswered);
  await activate('#restore-trace-cancel');
  assert.deepEqual(await snapshot(),unanswered);
  await chooseFile('#trace-file',pausedTrace.path);
  await waitFor(()=>visible('#trace-preview'),'second trace preview');
  await activate('#restore-trace-confirm');
  await waitFor(()=>exists('.result-card'),'explicit restored result');
  await verifyReview(state,[firstRetry]);
  passed('fresh 390px direct-file learner refuses wrong course and preserves preview/cancel before exact restoration');

  await activate('#practice-button');
  await waitFor(()=>exists('.practice-card'),'resume second practice');
  const secondRetry=await retry(state.missed[1]);
  await activate('#practice-next');
  await waitFor(()=>exists('.result-card'),'completed practice');
  const retries=[firstRetry,secondRetry];
  await verifyReview(state,retries);
  assert.equal(await evaluate('document.documentElement.scrollWidth>innerWidth'),false);
  const finalNotes=await saveDownload('#save-notes-button','standalone-complete-notes.txt');
  await openTrace();
  const finalTrace=await saveDownload('#save-trace-button','standalone-complete-trace.json');
  verifyNotes(finalNotes.bytes,state,retries);verifyTrace(finalTrace.bytes,state,retries);
  await activate('.review-item > summary');
  await screen('standalone-review-390.png','.review-list');
  report.sessions.push({surface:'standalone-restored',width:390,...state,practice:retries});
  passed('fresh-document practice resumes only the remaining question and physical final exports retain first-session identity');

  assert.equal(report.downloads.length+(suppliedCourse?1:0),7);
  assert.deepEqual(report.pageErrors,[]);
  assert.deepEqual(report.blockedRequests,[]);
  assert.ok(report.served.some(x=>x.path==='src/deck-picker.mjs'));
  assert.ok(report.requests.some(x=>x.url===pathToFileURL(join(project,'demo.html')).href));
  await verifySource();
  report.sourceUnchanged=true;
  passed('all nineteen source inputs remain exact; six new physical artifacts plus received course and zero external page requests/errors');
  report.status='passed';
} catch(error) {
  report.status='failed';report.error={name:error.name,message:error.message,stack:error.stack};
  try {report.lastPage=await evaluate('({url:document.URL,title:document.title,text:document.body.innerText.slice(0,18000)})');}catch{}
  console.error(error.stack);
  process.exitCode=1;
} finally {
  if(socket?.readyState===1) {
    try{await command('Browser.close',{},false);}catch{}
    socket.close();
  }
  if(browser && browser.exitCode===null)browser.kill('SIGTERM');
  await new Promise(resolve=>server.close(resolve));
  for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('receiver closed'));}
  pending.clear();
  await sleep(250);
  await rm(profile,{recursive:true,force:true});
  report.profileRemoved=true;
  report.endedAt=new Date().toISOString();
  await writeFile(join(output,'browser.log'),browserLog);
  await writeFile(join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({status:report.status,checks:report.checks.length,downloads:report.downloads.length,output}));
}
