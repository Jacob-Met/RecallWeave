import pathlib,json,hashlib,zipfile,datetime,os
R=pathlib.Path(__file__).resolve().parent
S=R/'candidate-r2'
OUT=R/'portable-r1';OUT.mkdir(exist_ok=False)
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
r1=json.loads((R/'browser-r1/artifacts/receipt.json').read_text(encoding='utf-8'))
r2=json.loads((R/'browser-r2/artifacts/receipt.json').read_text(encoding='utf-8'))
assert [g['name'].split('-')[0] for g in r1['groups']]==['B1','B2','B3','B4']
assert [g['name'].split('-')[0] for g in r2['groups']]==['B5','B6'] and r2['error'] is None
source=json.loads((R/'candidate-manifest-r2.json').read_text())
for row in source:
 assert pin((S/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256','git')}
play="""# Open the sorting-network lab

Extract this archive to a new folder, keeping the courses subfolder.
Open courses/sorting-networks-explorer.html in your browser.
Choose an example, choose Use example as draft, then Run network.
Follow each comparator and select any binary case to inspect a witness.
Editing the wire/value/pair draft retires the prior result until another Run.

Use the three download buttons to keep the accepted configuration, complete
observation and fixed lesson. Open demo.html, choose the downloaded lesson,
review its preview and explicitly Start this deck. The learner is the exact
unchanged canonical RecallWeave standalone consumer.

No server, installation, account or network connection is required for the lab
or learner. The reference hyperlink is optional and external. Nothing is saved
automatically. Configuration JSON is an inspection/reuse artifact; this page
does not import it. The guide describes the exact bounds and model.

Original source: Jacob-Met/RecallWeave
ec07bf3989132130759e5c00c6cb02eef19709d3
tree a839b6877bf2824f134443829d1ce62e1bd79e50
Source scope: issue253, all new sorting-network paths; shared learner unchanged.

Author native and consumer checks are complete. Independent receiving and
root acceptance remain pending at this package creation. That dated status
will be supplemented by final qualification rather than silently rewritten.
Keep this original ZIP and source manifest for recovery.
"""
members={p:(S/p).read_bytes() for p in ['courses/sorting-networks-explorer.html','courses/sorting-networks.json','courses/sorting-networks.md','demo.html']}
members['PLAY.md']=play.encode()
manifest=dict(format='recallweave-sorting-networks-portable/1',created=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_commit='ec07bf3989132130759e5c00c6cb02eef19709d3',original_tree='a839b6877bf2824f134443829d1ce62e1bd79e50',members=[dict(path=p,**pin(b)) for p,b in members.items()],source=source,qualification='Author checks complete; independent/root receiving pending.')
members['SOURCE-MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=OUT/'sorting-networks-offline.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p,b in members.items():
  info=zipfile.ZipInfo(p,date_time=(2026,1,1,0,0,0));info.create_system=3;info.external_attr=(0o100644<<16);info.compress_type=zipfile.ZIP_DEFLATED
  archive.writestr(info,b)
with zipfile.ZipFile(target) as archive:
 assert archive.namelist()==list(members)
 for p,b in members.items():assert archive.read(p)==b
assert len(members)==6
dest=S/'courses/dist/sorting-networks-offline.zip';dest.parent.mkdir(parents=True,exist_ok=True)
with dest.open('xb') as f:f.write(target.read_bytes())
receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),archive=pin(target.read_bytes()),members=[dict(path=p,**pin(b)) for p,b in members.items()],exact_roundtrip=True)
(OUT/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
