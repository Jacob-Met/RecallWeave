import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
source = root / 'source'
original = Path('/dev/shm/estate-60b2c08feb01-recall-graph/source')
admission = json.loads((root / 'input-manifest.json').read_text())
commit = admission['canonicalCommit']
entries = admission['entries']
frozen = json.loads((original.parent / 'source-freeze.json').read_text())

def git(args, data=None, where=source):
    return subprocess.check_output(['git', *args], cwd=where, input=data)

def command(args, data=None, where=source):
    return git(args, data, where).decode().strip()

def leaves(ref):
    result = {}
    for row in git(['ls-tree', '-rz', ref]).split(b'\0'):
        if row:
            meta, name = row.split(b'\t', 1)
            mode, kind, sha = meta.decode().split()
            result[name.decode()] = {'mode': mode, 'type': kind, 'sha': sha}
    return result

assert command(['rev-parse', 'HEAD'], where=original) == frozen['head'] == admission['originalSourceHead']
assert command(['status', '--porcelain'], where=original) == ''
assert not any(item['path'].endswith('AGENTS.md') for item in entries)
expected = {item['path']: item for item in entries}
by_parent = {}
for item in entries:
    parent = item['path'].rsplit('/', 1)[0] if '/' in item['path'] else ''
    by_parent.setdefault(parent, []).append(item)
tree_checks = 0
for directory in sorted(by_parent, key=lambda p: (p.count('/') + bool(p), p), reverse=True):
    raw = b''.join(f"{item['mode']} {item['type']} {item['sha']}\t{item['path'].split('/')[-1]}\0".encode() for item in by_parent[directory])
    sha = command(['mktree', '--missing', '-z'], raw)
    want = expected[directory]['sha'] if directory else commit['tree']['sha']
    assert sha == want, (directory, sha, want)
    tree_checks += 1

verification = commit['verification']
payload = verification['payload']
signature = verification['signature']
assert verification['verified'] and payload and signature
split = payload.index('\n\n')
raw_commit = (payload[:split] + '\ngpgsig ' + signature.replace('\n', '\n ') + payload[split:]).encode()
assert command(['hash-object', '-w', '-t', 'commit', '--stdin'], raw_commit) == commit['sha']
assert command(['rev-parse', commit['sha'] + '^{tree}']) == commit['tree']['sha']

base_leaves = leaves(commit['sha'])
assert len(base_leaves) == 871
guide = frozen['guideOnlyExistingChange']
assert base_leaves[guide]['sha'] == '690cd7d64e5fd6492e40ac905e5d51d7984660e3'
for path in frozen['exactNewProductPaths']:
    assert path not in base_leaves, path
feature = frozen['sourcePins']
for path, pin in feature.items():
    assert command(['rev-parse', frozen['head'] + ':' + path]) == pin['sha']
    data = git(['cat-file', 'blob', pin['sha']])
    assert hashlib.sha256(data).hexdigest() == pin['sha256']

command(['read-tree', commit['sha']])
index_lines = ''.join(f"{pin['mode']} {pin['sha']}\t{path}\n" for path, pin in feature.items()).encode()
command(['update-index', '--index-info'], index_lines)
tree = command(['write-tree', '--missing-ok'])
composed = leaves(tree)
expected_leaves = dict(base_leaves)
expected_leaves.update({path: {key: pin[key] for key in ('mode', 'type', 'sha')} for path, pin in feature.items()})
assert composed == expected_leaves
assert len(composed) == 877
unrelated = [path for path in base_leaves if path not in feature]
assert len(unrelated) == 870
assert all(composed[path] == base_leaves[path] for path in unrelated)
message = ('Compose dependency explorer with current RecallWeave learner\n\n'
           'Preserve current 3cdebd86 source, including learner reflections and all unrelated courses.\n'
           'Apply only the seven qualified dependency-plan paths from b48f33b5.\n'
           'Original author source and qualification remain unchanged; current-base gates are separate.\n')
head = command(['commit-tree', tree, '-p', commit['sha'], '-p', frozen['head']], message.encode())
command(['update-ref', 'refs/heads/estate/60b2c08feb01-dependency-plan-current', head, '0' * 40])
command(['read-tree', head])
command(['update-index', '--skip-worktree', '-z', '--stdin'], b'\0'.join(path.encode() for path in composed) + b'\0')

materialize = sorted(set(feature) | {
    'courses/dependency-graphs.json', 'src/deck.mjs', 'src/deck-picker.mjs',
    'demo.html', 'src/app.mjs', 'src/reflections.mjs', 'src/session-export.mjs',
    'styles.css', 'tools/make_demo.py', 'README.md', '.github/workflows/test.yml'
})
materialized = {}
for path in materialize:
    if path not in composed:
        continue
    pin = composed[path]
    data = git(['cat-file', 'blob', pin['sha']])
    destination = source / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    destination.chmod(0o755 if pin['mode'] == '100755' else 0o644)
    command(['update-index', '--no-skip-worktree', '--', path])
    materialized[path] = {**pin, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

assert command(['status', '--porcelain']) == ''
assert command(['rev-parse', 'HEAD'], where=original) == frozen['head']
assert command(['status', '--porcelain'], where=original) == ''
source_receipt = {
    'head': head, 'tree': tree, 'parents': [commit['sha'], frozen['head']],
    'base': commit['sha'], 'baseTree': commit['tree']['sha'],
    'originalSourceHead': frozen['head'], 'originalSourceTree': frozen['tree'],
    'canonicalTreesReconstructed': tree_checks, 'canonicalSignedCommitExact': True,
    'currentBaseLeaves': len(base_leaves), 'composedLeaves': len(composed),
    'allUnrelatedCurrentLeavesPreserved': len(unrelated), 'exactSevenQualifiedPaths': feature,
    'materializedSource': materialized, 'originalSourceUnchanged': True, 'clean': True,
    'excludedEvidencePreservedByGitIDs': True,
    'currentNativeGate': 'pending separate frozen invocation',
    'currentLearnerBoundary': 'independent receiver owns actual current demo import; old author browser remains historical',
    'claim': frozen['claim'],
}
(root / 'source-composition.json').write_text(json.dumps(source_receipt, indent=2) + '\n')
print(json.dumps({key: source_receipt[key] for key in ('head', 'tree', 'parents', 'canonicalTreesReconstructed', 'currentBaseLeaves', 'composedLeaves', 'allUnrelatedCurrentLeavesPreserved', 'clean')}))
