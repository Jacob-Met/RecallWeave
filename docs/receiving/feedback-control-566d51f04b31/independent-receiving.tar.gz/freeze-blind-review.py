from pathlib import Path
from fractions import Fraction as F
import json,hashlib,datetime,shutil
root=Path('/home/jacob/hamon-research-build/recall-feedback-control-review-566d51f04b31-coordination')
front=Path('/tmp/recall-feedback-control-566d51f04b31/evidence/blind-question-fronts.json')
raw=front.read_bytes();assert len(raw)==8365 and hashlib.sha256(raw).hexdigest()=='315dea636585e11077a04b9db77654d9029f1eac1608d05e9b486b589a16e862'
v=json.loads(raw)
rows=json.loads("[[\"fc-read-order\",2,\"Read the current state, calculate its correction, then calculate the next state. The equations define an explicit update, not an implicit simultaneous solve.\"],[\"fc-read-number\",1,\"u[0]=0.5*(1-0.5)=0.25 and a*x[0]=0.375, so x[1]=0.625.\"],[\"fc-read-sign\",3,\"With k positive and x[n]>r, r-x[n]<0, so the correction is negative. The sign of the total state change still depends on the full update.\"],[\"fc-loop-coefficient\",0,\"Expanding k(r-x[n]) gives (a-k)*x[n]+k*r+d. Thus q=a-k and c=k*r+d.\"],[\"fc-loop-two-starts\",2,\"Subtract the two recurrences. The common c cancels, leaving Delta[n+1]=q*Delta[n].\"],[\"fc-loop-three-steps\",1,\"Delta[3]=(-0.5)^3*1=-0.125.\"],[\"fc-fixed-point\",3,\"At a fixed point, (1-q)*x*=c. The given q!=1 allows x*=c/(1-q).\"],[\"fc-fixed-reference\",0,\"x*=0.5/(1-0.25)=2/3, so r-x*=1/3. Attraction follows from |q|=0.25<1.\"],[\"fc-fixed-exception\",2,\"A fixed point would require x=x+0.25, impossible over the reals. The exact state rises by 0.25 each update.\"],[\"fc-stability-alternation\",1,\"Only q=-0.5 has negative sign and magnitude strictly below one, so each nonzero deviation changes sign and shrinks.\"],[\"fc-stability-gain\",3,\"-1<0.75-k<1 implies -0.25<k<1.75. Intersecting with k>=0 gives 0<=k<1.75; the endpoint is neutral, not decaying.\"],[\"fc-stability-boundary\",0,\"z[n]=(-1)^n*0.25 is a two-cycle of constant nonzero magnitude and cannot converge to zero.\"],[\"fc-stability-flat\",2,\"Zero is a fixed point, but a nonzero perturbation has magnitude 1.25^n times its initial magnitude. The zero trajectory alone does not establish attraction.\"],[\"fc-disturbance-offset\",1,\"q=a-k stays 0.25. c decreases from 0.5 to 0.25, so x* moves from 2/3 to 1/3, with unchanged decay multiplier.\"],[\"fc-reference-vs-rate\",0,\"q=a-k is independent of r. When q!=1, x*=(k*r+d)/(1-q); a reference change can move it when k is nonzero. If k=0 there is no reference effect, and q=1 needs separate treatment.\"],[\"fc-limit-time\",3,\"The given index counts discrete updates. No sampling interval or mapping to a physical device has been supplied, so elapsed physical time is not inferred.\"],[\"fc-limit-horizon\",2,\"The exact deviation law z[n]=q^n*z[0] gives decay for every initial deviation precisely when |q|<1. A finite plot or special initial point is not that proof.\"],[\"fc-limit-transfer\",1,\"The result establishes decay of initial-state perturbations for this stated ideal recurrence. Unmodeled physical effects and practical tuning competence do not follow.\"]]")
assert [x['id'] for x in v['items']]==[x[0] for x in rows] and len(rows)==18
answers={'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Blind answers frozen before authored-answer or model source read','source_fronts_sha256':hashlib.sha256(raw).hexdigest(),'actor':'chatgpt-566d51f04b31-coordination','answers':[{'id':id,'zero_based_option':n,'selected_text':next(x for x in v['items'] if x['id']==id)['options'][n],'independent_reason':why} for id,n,why in rows],'front_review':{'unambiguous_best_options':18,'front_blockers':[],'qualification':[{'id':'fc-reference-vs-rate','severity':'wording precision for review','note':'The unchanged q is unconditional. Fixed-point movement requires existence and a nonzero gain; the modal can avoids claiming all references change the equilibrium, but the explanation should preserve those qualifications.'}]}}
cases=[
('course-first-update','3/4','1/2','1','0','1/2'),
('course-negative-disturbance','3/4','1/2','1','-1/4','1/2'),
('two-starts-A','3/4','5/4','1','0','0'),
('two-starts-B','3/4','5/4','1','0','1'),
('neutral-minus-one','3/4','7/4','0','0','1/4'),
('growing-nonzero','3/4','2','0','0','1/4'),
('growing-flat-fixed','3/4','2','0','0','0'),
('unit-q-drift','1','0','1','1/4','0'),
('unit-q-all-fixed','1','0','1','0','1/2'),
('one-update-fixed','3/4','3/4','1','0','0'),
('reference-shift','3/4','1/2','2','0','1/2'),
('just-inside-plus-one','1','1/1099511627776','1','0','0'),
('just-inside-minus-one','1','2199023255551/1099511627776','0','0','1/4'),
('just-outside-minus-one','1','2199023255553/1099511627776','0','0','1/4')]
expect=[]
for name,aa,kk,rr,dd,xx in cases:
 a,k,r,d,x0=map(F,(aa,kk,rr,dd,xx));q=a-k;c=k*r+d;x=x0;trace=[]
 for n in range(7):
  u=k*(r-x)
  trace.append({'n':n,'x_exact':str(x),'x':float(x),'u_exact':str(u),'u':float(u),'reference_error_exact':str(r-x),'reference_error':float(r-x)})
  x=q*x+c
 fixed=None if q==1 else c/(1-q)
 expect.append({'name':name,'inputs':{'a':float(a),'k':float(k),'r':float(r),'d':float(d),'x0':float(x0),'steps':6},'exact_inputs':dict(zip(('a','k','r','d','x0'),(aa,kk,rr,dd,xx))),'q':float(q),'q_exact':str(q),'c':float(c),'fixed_point':None if fixed is None else float(fixed),'fixed_exact':None if fixed is None else str(fixed),'decays_for_all_initial_states':abs(q)<1,'q_one_kind':('all fixed' if c==0 else 'no fixed point') if q==1 else None,'trace':trace})
oracle={'frozen_at':answers['frozen_at'],'status':'Independent rational numeric expectations frozen before implementation read','basis':'Exact rational affine solution and recurrence, computed independently with Python fractions; no source equations or constants copied from implementation. Inputs may be subject to the actual documented admission domain; any rejected case is reported without altering its expected mathematics.','fronts_sha256':hashlib.sha256(raw).hexdigest(),'trace_boundary':'Seven states n=0..6; u[n] is computed from the current x[n]. Direct implementation binding will use the admitted step argument and report interface-only adaptations.','cases':expect,'cross_case_expectation':{'two_starts_delta_after_three':-0.125,'two_starts_delta_law':'xB[n]-xA[n]=(-0.5)^n','constant_q_between_reference_cases':0.25,'original_fixed':2/3,'shifted_reference_fixed':4/3},'numeric_limits_review_plan':'Check exact stability boundaries separately from finite-display traces; inspect nonfinite input handling and explicit horizon/state limits after freeze. No inference of physical sampling rate.'}
for name,value in [('blind-solved-answers.json',answers),('blind-course-numeric-oracles.json',oracle)]:
 p=root/name;assert not p.exists();p.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'file':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
dest=root/'blind-question-fronts.json';assert not dest.exists();dest.write_bytes(raw)
