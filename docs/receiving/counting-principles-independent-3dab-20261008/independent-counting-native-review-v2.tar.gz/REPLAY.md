# Reproduce only when the subject changes or a concrete question requires it

Keep the original packet and native-v2 receipts unchanged. To run in a fresh owned directory, copy the receiver, controller, SOURCE_CUSTODY.json, PAGE-FIELD-CLARIFICATION.json and source/ files there. Place the exact separate blind-counting-oracle-v1.tar.gz beside them and extract its flat members into blind-oracle-v1/.

Use the existing Node and Python runtimes:

    python3 -I -B run-native-v2.py

The controller refuses to overwrite an existing native-v2/ directory, freezes inputs before execution, and writes stdout/stderr directly to files. The receiver checks exact core/oracle pins before importing the source. A replay receives its own timestamp and runtime identity; it must not be relabeled as the recorded 18:57 UTC Node22 run.

The Python blind oracle need not be regenerated. Its exact original source, contract, observations and controller are retained in its separate archive. The one-based returned page display mapping is explicit in REVIEW.md and PAGE-FIELD-CLARIFICATION.json.
