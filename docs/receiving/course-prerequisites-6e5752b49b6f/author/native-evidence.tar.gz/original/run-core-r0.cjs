const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const root = __dirname;
const source = path.join(root, 'source-r1');
const out = path.join(root, 'core-native-r0');
const hash = b => ({ bytes: b.length, sha256: crypto.createHash('sha256').update(b).digest('hex'), git: crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob ' + b.length + '\0'), b])).digest('hex') });
const nodePin = hash(fs.readFileSync(process.execPath));
const preflight = { user: os.userInfo().username, node: process.execPath, version: process.version, nodePin, freeMemory: os.freemem(), time: new Date().toISOString() };
if (preflight.user !== 'jacob' || process.version !== 'v24.14.0' || nodePin.sha256 !== '63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088' || preflight.freeMemory < 536870912) throw Error('Runtime/resource admission refused');
if (fs.existsSync(source) || fs.existsSync(out)) throw Error('Exclusive source/output path already exists');
const files = JSON.parse(fs.readFileSync(path.join(root, 'core-payload-r0.json'), 'utf8'));
if (hash(Buffer.from(files['src/deck.mjs'])).git !== 'f0f8a4b234489c2388f427633f548d56c6ed4c03' ||
    hash(Buffer.from(files['src/course-focus.mjs'])).git !== '337b90d667170f19e5c75f5aaf4898e3410630b9') throw Error('Baseline source mismatch');
fs.mkdirSync(source); fs.mkdirSync(out);
const before = {};
for (const [name, text] of Object.entries(files)) {
  const target = path.join(source, name);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, text, { flag: 'wx' });
  before[name] = hash(fs.readFileSync(target));
}
const start = Date.now();
const child = spawnSync(process.execPath, ['--max-old-space-size=128', '--test', 'tests/course-prerequisites.test.mjs'], { cwd: source, timeout: 30000, windowsHide: true, encoding: 'utf8', maxBuffer: 1024 * 1024 });
const after = Object.fromEntries(Object.keys(files).map(name => [name, hash(fs.readFileSync(path.join(source, name)))]));
fs.writeFileSync(path.join(out, 'stdout.txt'), child.stdout || '', { flag: 'wx' });
fs.writeFileSync(path.join(out, 'stderr.txt'), child.stderr || '', { flag: 'wx' });
const unchanged = JSON.stringify(before) === JSON.stringify(after);
const report = { format: 'recallweave-prerequisites-core-native/1', preflight, argv: ['--max-old-space-size=128', '--test', 'tests/course-prerequisites.test.mjs'], source, exit: child.status, signal: child.signal, error: child.error ? String(child.error) : null, elapsedMs: Date.now() - start, before, after, unchanged, runtimeAfter: hash(fs.readFileSync(process.execPath)), stdout: hash(Buffer.from(child.stdout || '')), stderr: hash(Buffer.from(child.stderr || '')), accepted: child.status === 0 && !child.signal && !child.error && unchanged };
fs.writeFileSync(path.join(out, 'receiving.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(report));
process.exit(report.accepted ? 0 : 1);
