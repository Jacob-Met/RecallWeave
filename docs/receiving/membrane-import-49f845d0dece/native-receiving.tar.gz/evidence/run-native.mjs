import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,openSync,closeSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
const root='/tmp/rw49-membrane-49f845d0dece',evidence=join(root,'evidence');
for(const [src,dest] of [['/tmp/rw49-stage-membrane-49f845d0dece.mjs','stage-source.mjs'],['/tmp/rw49-membrane-stage-49f845d0dece.stdout.log','stage.stdout.log'],['/tmp/rw49-membrane-stage-49f845d0dece.stderr.log','stage.stderr.log']])copyFileSync(src,join(evidence,dest));
const receipt={owner:'estate-49f845d0dece/recall_import_receiving',startedAt:new Date().toISOString(),cwd:root,steps:[]};
const save=()=>writeFileSync(join(evidence,'native-process-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
for(const [name,executable,args,cwd] of [
 ['receiver-syntax','/usr/bin/node',['--check',join(root,'receive-membrane-import-trace.mjs')],root],
 ['standalone-parity','python3',[join(root,'source/tools/make_demo.py'),'--check'],join(root,'source')],
 ['browser','/usr/bin/node',[join(root,'receive-membrane-import-trace.mjs'),'--root',join(root,'source'),'--input',join(root,'inputs/membrane-transport.json'),'--output',join(evidence,'run-01'),'--browser','/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome'],root]
]){
 const stdoutPath=join(evidence,name+'.stdout.log'),stderrPath=join(evidence,name+'.stderr.log');
 const out=openSync(stdoutPath,'w'),err=openSync(stderrPath,'w');
 const step={name,executable,args,cwd,startedAt:new Date().toISOString(),stdoutPath,stderrPath};
 receipt.steps.push(step);save();
 const r=spawnSync(executable,args,{cwd,stdio:['ignore',out,err]});
 closeSync(out);closeSync(err);
 Object.assign(step,{finishedAt:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?.message??null});
 save();console.log(name+': '+r.status);
 if(r.status!==0){receipt.status='failed';save();process.exit(r.status||1);}
}
receipt.status='passed';receipt.finishedAt=new Date().toISOString();save();
console.log('Native membrane receiving completed');
