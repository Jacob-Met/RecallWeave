import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,readdir,copyFile} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {withBrowser,until,sha,delay} from './browser-helpers-startup60.mjs';

const root='/home/jacob/recallweave-spring-energy-bd1abdb2f886-20261008';
const sourceRoot=join(root,'source'),output=join(root,'qa/learner-browser-v1');
const coursePath=join(root,'qa/lab-browser-v1/course/spring-energy.json');
if(existsSync(join(output,'browser-report.json')))throw Error('Refusing to overwrite a prior learner receipt.');
const courseBytes=await readFile(coursePath),course=JSON.parse(courseBytes);
assert.equal(sha(courseBytes),'84c87182731e35e036d5c2b2729cee94ae65091336272547e3a791a5cab068cc');
const composition=JSON.parse(await readFile(join(root,'qa/current-main-composition.json'),'utf8'));
const inherited=new Map(composition.inherited.map(row=>[row.path,row]));
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:sourceRoot,encoding:'utf8'}).trim();
assert.equal(head,composition.head);
const paths=['demo.html','src/app.mjs','src/deck.mjs','src/deck-picker.mjs','src/knowledge.mjs','src/review.mjs','src/session-export.mjs','src/reflections.mjs','src/answer-order.mjs','src/lesson-archive.mjs','src/lesson-archive-ui.mjs','src/trace-archive.mjs','src/trace-archive-ui.mjs','styles.css'];
const before={};
for(const path of paths){
 const bytes=await readFile(join(sourceRoot,path));const expected=inherited.get(path);
 assert.ok(expected,path);assert.equal(sha(bytes),expected.sha256,path);
 before[path]={bytes:bytes.length,sha256:sha(bytes),gitBlob:expected.sha};
}
await mkdir(output,{recursive:true});
await copyFile(join(sourceRoot,'demo.html'),join(output,'actual-current-demo.html'));
await copyFile(coursePath,join(output,'actual-explorer-course.json'));
await writeFile(join(output,'source-before.json'),JSON.stringify({head,tree:composition.tree,node:process.version,executable:process.execPath,course:{path:coursePath,bytes:courseBytes.length,sha256:sha(courseBytes)},files:before},null,2)+'\n');
const report=await withBrowser({output,profileParent:join(root,'qa')},async b=>{
 const{command,evaluate,click,key,type,viewport,navigate,screenshot,check}=b;
 const captures=[],trace=[];
 const text=selector=>evaluate('document.querySelector('+JSON.stringify(selector)+').textContent');
 const chooseCourse=async()=>{
  const document=await command('DOM.getDocument',{depth:1});
  const {nodeId}=await command('DOM.querySelector',{nodeId:document.root.nodeId,selector:'#deck-file'});
  await command('DOM.setFileInputFiles',{nodeId,files:[coursePath]});
  await until(()=>evaluate('!document.querySelector("#deck-preview").hidden'),'actual file preview');
 };
 await viewport(1240,950);
 await navigate(pathToFileURL(join(sourceRoot,'demo.html')).href);
 await until(()=>evaluate('!!document.querySelector("#start-button")'),'current standalone welcome');
 let existing;
 await check('create a real existing learner answer before staging the spring deck',async()=>{
  await click('#start-button');await click('[data-choice="0"]');
  existing=await evaluate('({html:document.querySelector("#session-content").innerHTML,count:document.querySelector("#step-count").textContent,progress:document.querySelector("[role=progressbar]").getAttribute("aria-valuenow"),title:document.title})');
  assert.equal(existing.progress,'1');
  assert.ok(existing.html.includes('next-button'));
 });
 await check('actual downloaded deck previews all12 prompts and cancellation preserves the existing session',async()=>{
  await chooseCourse();
  assert.equal(await text('#deck-preview-title'),course.title);
  assert.match(await text('.deck-preview-count'),/12 questions · 4 concepts/);
  const prompts=await evaluate('[...document.querySelectorAll("#deck-preview li strong")].map(n=>n.textContent)');
  assert.deepEqual(prompts,course.items.map(item=>item.prompt));
  const staged=await evaluate('({html:document.querySelector("#session-content").innerHTML,count:document.querySelector("#step-count").textContent,progress:document.querySelector("[role=progressbar]").getAttribute("aria-valuenow"),title:document.title})');
  assert.deepEqual(staged,existing);
  captures.push(await screenshot('01-spring-preview.png'));
  await click('#cancel-deck');
  assert.equal(await evaluate('document.querySelector("#deck-preview").hidden'),true);
  const cancelled=await evaluate('({html:document.querySelector("#session-content").innerHTML,count:document.querySelector("#step-count").textContent,progress:document.querySelector("[role=progressbar]").getAttribute("aria-valuenow"),title:document.title})');
  assert.deepEqual(cancelled,existing);
 });
 await check('explicit Start begins the selected course and all12 canonical answers are received through visible choices',async()=>{
  await chooseCourse();await click('#start-deck');
  assert.match(await text('#deck-status'),/Started/);
  assert.equal(await text('#lesson-description'),course.title);
  assert.equal(await text('#step-count'),'0 / 12');
  const seen=new Set();
  for(let index=0;index<12;index++){
   const prompt=await text('#session-content h2');
   const item=course.items.find(row=>row.prompt===prompt);assert.ok(item,prompt);assert.equal(seen.has(item.id),false);seen.add(item.id);
   const choice=item.id==='spring-phase-2'?(item.answer+1)%item.options.length:item.answer;
   assert.ok((await text('[data-choice="'+choice+'"]')).includes(item.options[choice]));
   await click('[data-choice="'+choice+'"]');
   const feedback=await text('#feedback-slot');
   assert.ok(feedback.includes(item.explanation),item.id);assert.ok(feedback.includes(item.transfer),item.id);
   assert.equal(await evaluate('[...document.querySelectorAll("[data-choice]")].every(n=>n.disabled)'),true);
   trace.push({id:item.id,choice,expected:item.answer,correct:choice===item.answer,prompt,selected:item.options[choice]});
   await click('#next-button');
  }
  assert.equal(seen.size,12);assert.equal(trace.filter(row=>row.correct).length,11);
  assert.match(await text('#first-try-summary'),/11 of 12/);
  assert.equal(await evaluate('document.querySelectorAll(".review-item").length'),12);
  await writeFile(join(output,'actual-first-answers.json'),JSON.stringify(trace,null,2)+'\n');
  captures.push(await screenshot('02-complete-first-trace.png'));
 });
 let firstAnswers,mastery;
 await check('one correct retry is separate from unchanged canonical first answers and mastery',async()=>{
  firstAnswers=await evaluate('[...document.querySelectorAll(".review-item")].map(n=>({prompt:n.querySelector(".review-prompt").textContent,answers:[...n.querySelectorAll(".review-answers dd")].map(v=>v.textContent),status:n.querySelector(".review-status").textContent}))');
  mastery=await evaluate('[...document.querySelectorAll(".mastery-box output")].map(n=>({text:n.textContent,label:n.getAttribute("aria-label")}))');
  await click('#practice-button');
  const missed=course.items.find(item=>item.id==='spring-phase-2');
  assert.equal(await text('#session-content h2'),missed.prompt);
  await click('[data-practice-choice="'+missed.answer+'"]');await click('#practice-next');
  assert.match(await text('#practice-status'),/1 of 1 correctly on retry/);
  assert.match(await text('#first-try-summary'),/11 of 12/);
  const after=await evaluate('[...document.querySelectorAll(".review-item")].map(n=>({prompt:n.querySelector(".review-prompt").textContent,answers:[...n.querySelectorAll(".review-answers dd")].map(v=>v.textContent),status:n.querySelector(".review-status").textContent}))');
  assert.deepEqual(after,firstAnswers);
  assert.deepEqual(await evaluate('[...document.querySelectorAll(".mastery-box output")].map(n=>({text:n.textContent,label:n.getAttribute("aria-label")}))'),mastery);
  assert.equal(await evaluate('document.querySelectorAll(".review-practice-answer").length'),1);
 });
 await check('actual study-notes download retains the full original course and distinct retry',async()=>{
  await type('#application-reflection','At the same position the spring force agrees, but the velocity can point either way.');
  const downloadPath=join(output,'notes');await mkdir(downloadPath,{recursive:true});
  await command('Browser.setDownloadBehavior',{behavior:'allow',downloadPath,eventsEnabled:true},false);
  await click('#save-notes-button');
  const files=await until(async()=>{const names=await readdir(downloadPath);return names.length===1&&names[0].endsWith('.txt')?names:null;},'actual study notes file');
  const path=join(downloadPath,files[0]),bytes=await readFile(path),notes=bytes.toString('utf8');
  assert.ok(notes.includes(course.title));assert.match(notes,/11 of 12 connections correct on the first try/);
  assert.match(notes,/1 of 1 practice answers recorded; 1 correct on retry/);
  assert.ok(notes.includes('At the same position the spring force agrees, but the velocity can point either way.'));
  for(const item of course.items)for(const value of [item.prompt,item.explanation,item.transfer])assert.ok(notes.includes(value),item.id);
  const missed=course.items.find(item=>item.id==='spring-phase-2');
  assert.ok(notes.includes(missed.options[(missed.answer+1)%missed.options.length]));
  b.report.notes={path,bytes:bytes.length,sha256:sha(bytes)};
 });
 await check('completed course remains readable at390px and the standalone makes no network request',async()=>{
  await viewport(390,844);await click('#first-try-summary');
  assert.equal(await evaluate('document.documentElement.scrollWidth<=innerWidth'),true);
  captures.push(await screenshot('03-phone-first-trace.png'));
  assert.equal(b.report.pageErrors.length,0);
  assert.deepEqual(b.report.requests.filter(r=>/^https?:/.test(r.url)),[]);
 });
 b.report.captures=captures;b.report.trace=trace;
});
const after={};for(const path of paths){const bytes=await readFile(join(sourceRoot,path));after[path]={bytes:bytes.length,sha256:sha(bytes),gitBlob:inherited.get(path).sha};}
const unchanged=JSON.stringify(before)===JSON.stringify(after)&&sha(await readFile(coursePath))===sha(courseBytes);
await writeFile(join(output,'source-after.json'),JSON.stringify({files:after,unchanged},null,2)+'\n');
console.log(JSON.stringify({status:report.status,checks:report.checks,sourceUnchanged:unchanged,notes:report.notes,cleanup:report.cleanup}));
process.exitCode=report.status==='passed'&&unchanged?0:1;
