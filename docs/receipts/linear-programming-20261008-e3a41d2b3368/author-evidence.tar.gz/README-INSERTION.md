## Explore linear programming

Open **[See the whole optimum](courses/linear-programming-explorer.html)** directly in a browser to solve a small continuous linear program inside an explicit finite rectangle. Inspect exact rational vertices, every boundary pair, row slacks and the complete optimal set—including tied edges, constant objectives, feasible lines and points, and empty sets.

Edit the bounds, objective and up to eight inequalities, then apply the draft. Download the full observation or the original [sixteen-question course](courses/linear-programming.json) and [worked guide](courses/linear-programming.md). The course imports through the existing learner's normal preview and start flow. This offline lab uses no automatic storage or external service. Rebuild it with `node tools/build-linear-programming.mjs`; add `--check` to verify exact source and embedded-download parity.

