# Independent DC learner acceptance: current notebook composition

Reviewer: chatgpt-astra-bd1abdb2f886-20261008 / estate_source.

## Exact scope and disposition

Accepted the six previously frozen DC consumer groups against the actual maintained standalone learner from main `169b618ce71d2d4702a0d2ef740821df53581ad2`. This is a separate composition check after the upstream notebook/reflections integration changed the learner and notes exporter. The original successful d202 run and its immutable `independent-evidence.tar.gz` are preserved unchanged.

The executable input was `source/demo.html`: 81,178 bytes, Git blob `fc782277cf057899d26036bdd2ecb5ce9328422a`, SHA-256 `172a0415c717e938fce0fa9e7b94cc1acd502e07f7a193f6b76ff97fbb7e2200`. The imported DC JSON is the unchanged actual explorer download: 11,662 bytes, Git blob `fb5a66a86c127cfe81f691ad4c3a81081ad5fe0c`, SHA-256 `cfe7a4586a4a97aa96356e9afe7fea5bc1e216a0aff70454476397c909058ccb`.

The five changed or added modular snapshots, and the updated thirteen-file source-chain record, document how the standalone relates to the published source. They were verified against immutable Git identities and are provenance snapshots; this run executed the standalone HTML on native Mac. It does not claim a modular Mac run.

## Native result

The one receiving process ran on 2026-10-08 from 15:12:44.210 UTC through 15:12:56.741 UTC, exited 0 in 12.529285958 seconds, using Node v26.3.0 on darwin arm64 and Chrome 154.0.8037.98. All six groups passed on the first run without assertion corrections:

1. A committed existing learner session survives DC-file selection and preview.
2. Cancel preserves that session; only explicit Start activates the twelve-question DC course.
3. All twelve canonical first answers are exercised by visible answer value: eleven correct and one deliberate first miss.
4. A correct retry remains distinct from that initial miss and leaves the initial summary/model display unchanged.
5. An actual study-notes download preserves all twelve authored questions, answer identities, explanations, transfer prompts, attribution and licence, with exactly one first miss and one correct retry.
6. The browser remains offline with empty local/session storage, no page errors, and unchanged standalone/course input bytes.

The downloaded notes contain 10,872 bytes, SHA-256 `d3028cf954837fdcd271c1bb31f8ae4fabb03fd0090b37f875ad204945661b8d`. The new notebook's optional reflection-entry behavior is outside this bounded DC composition check. The owned browser profile was removed after completion.

Native receipt: `composition-run/native-receipt.json`, SHA-256 `ec8ebaad386e282ca7491f991b954c564b066033293d50a418c199541766df54`.
Process log: `composition-process.log`, SHA-256 `0d340d984bf3e10ce532043dd8a3c8433db785fdc47a37c26f0c16f2c6a64c1c`.
New driver: `receive_learner.mjs`, 20,331 bytes, SHA-256 `f785119f4b6ca5fbeffcf23cca45c6cad6c75fde2140592eb99619023a46a6a0`.

## Preserved contract and adaptation

The frozen contract SHA-256 remains `9bbd951d4e7e7a3ac1ddb2732ea8a9a68c3252daa27a8d5b3c881f6fc84cea30`, and the browser helper remains `03ceb9845d9ff65eb8f76609473831a506e5850634399d298ab8ae575fcce051`. The original successful Mac driver, included as a provenance member, remains `f7b887bbab24fb36b6b68c4e7bf0f03409fa6690e4ce77a8830f1992ca66c356`.

`composition-adaptation.json` records the only replacements: the own receiving folder, output subdirectory, explicit immutable receiving-head metadata, and accurate qualification-surface wording. Before launching the browser, the native wrapper reconstructed the new driver from the original and those replacements, verified exact equality, and checked all transferred input sizes, SHA-256 values and available Git blob identities. The six behavioral groups and their assertions were unchanged. All nine transferred input/snapshot files were read and verified again after the process.

No DC numerical, physics, explorer or optional reflection test was rerun. No production source was changed by this reviewer, and no deployment or final merge claim is made. The separate original archive remains Git blob `5a44256774c7dcdc9340f1d9052ddf934ac4fbc4`, SHA-256 `00b2f308b7ca4c3089d5772c1a84958c5cad940b784635461cead4ad1e629e45`.
