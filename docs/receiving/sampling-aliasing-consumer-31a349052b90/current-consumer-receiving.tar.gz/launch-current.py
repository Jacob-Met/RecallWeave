from pathlib import Path
import subprocess,hashlib,os,json,datetime,time,signal,tempfile,shutil
r=Path('/dev/shm/hamon-31a349052b90-recall-sampling-consumer/current-main');out=r/'run-v1';out.mkdir(exist_ok=False)
for n in ['cache','config']:(out/n).mkdir()
exe=Path('/snap/chromium/3537/usr/lib/chromium-browser/chrome')
with exe.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
assert digest=='5d4f4ce28120d4f6ab7566306c26b9a766227ca76da70f44ed322e4ee04b5bbb'
runner=r/'receive-current-consumer.mjs'
assert hashlib.sha256(runner.read_bytes()).hexdigest()=='01ab95b13fd29b4beacb02e8dfe5f333c6dfd17478ef27f2864d2e0f35f3baf5'
runtime={'executable':str(exe),'bytes':exe.stat().st_size,'sha256':digest,'node':subprocess.check_output(['/usr/bin/node','--version'],text=True).strip(),'browser_version':subprocess.check_output([str(exe),'--version'],text=True).strip(),'host':os.uname().nodename}
(out/'runtime.json').write_text(json.dumps(runtime,indent=2)+'\n')
args=['/usr/bin/node',str(runner),'--root',str(r/'source'),'--manifest',str(r/'source-manifest.json'),'--course-input',str(r/'inputs/sampling-aliasing.json'),'--paused-trace',str(r/'inputs/modular-paused-trace.json'),'--output',str(out),'--browser',str(exe)]
shorttmp=Path(tempfile.mkdtemp(prefix='rwc31-',dir='/dev/shm'))
env=os.environ.copy();env.update({'TMPDIR':str(shorttmp),'XDG_CACHE_HOME':str(out/'cache'),'XDG_CONFIG_HOME':str(out/'config')})
start=datetime.datetime.now(datetime.timezone.utc).isoformat();began=time.monotonic();timed_out=False
with (out/'stdout.txt').open('w') as stdout,(out/'stderr.txt').open('w') as stderr:
 p=subprocess.Popen(args,cwd=r,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:rc=p.wait(timeout=90)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
receipt={'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-began,'argv':args,'pid':p.pid,'exit_code':rc,'timed_out':timed_out,'runtime':runtime,'runner_sha256':hashlib.sha256(runner.read_bytes()).hexdigest(),'private_tmpdir':str(shorttmp),'source_commit':'3cdebd86e69506709bcaeaeff4026deb3d1fc208','scope':'Two changed-source surfaces and three physical downloads; original first-answer/lab work not repeated'}
shutil.rmtree(shorttmp);receipt['private_tmpdir_removed']=not shorttmp.exists()
(out/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));print((out/'stdout.txt').read_text());print((out/'stderr.txt').read_text()[-8000:])
