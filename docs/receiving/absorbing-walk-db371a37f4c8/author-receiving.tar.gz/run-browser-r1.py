import pathlib,subprocess,json,datetime,hashlib,os,shutil,signal,traceback
root=pathlib.Path('/run/user/1000/snap.chromium/hamon-absorbing-walk-author-db371a37f4c8')
run=root/'browser-wrapper-r1';run.mkdir(exist_ok=False)
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid()}
child=None
try:
 report['filesystemFree']=shutil.disk_usage(root).free
 report['memory']=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 assert report['filesystemFree']>=268435456 and report['memory']>=2147483648
 driver=root/'source/tools/check-absorbing-walk-browser.mjs'
 report['driverSha256']=hashlib.sha256(driver.read_bytes()).hexdigest()
 c=subprocess.run(['/usr/bin/node','--check',str(driver)],capture_output=True,timeout=15)
 report['syntaxExit']=c.returncode;(run/'syntax.stdout').write_bytes(c.stdout);(run/'syntax.stderr').write_bytes(c.stderr);assert c.returncode==0
 tmp=run/'tmp';tmp.mkdir();env=dict(os.environ,TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),XDG_CACHE_HOME=str(run/'cache'))
 argv=['/usr/bin/node',str(driver),'--root',str(root/'source'),'--browser','/snap/bin/chromium','--output',str(root/'browser-r1')]
 report['argv']=argv
 with (run/'stdout.txt').open('wb') as out,(run/'stderr.txt').open('wb') as err:
  child=subprocess.Popen(argv,cwd=root/'source',env=env,stdout=out,stderr=err,start_new_session=True)
  report['child']=child.pid
  (run/'started.json').write_text(json.dumps(report,indent=2)+'\n')
  try:report['exit']=child.wait(timeout=120)
  except subprocess.TimeoutExpired:
   report['timeout']=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=10);raise
 rows=json.loads((root/'runtime-manifest-r1.json').read_text())
 report['runtimeExact']=all(hashlib.sha256((root/'source'/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in rows)
 assert report['exit']==0 and report['runtimeExact'];report['status']='passed'
except Exception:report['status']='failed';report['error']=traceback.format_exc()
finally:
 report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (run/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
