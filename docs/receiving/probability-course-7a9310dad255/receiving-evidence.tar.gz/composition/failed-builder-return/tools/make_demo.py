#!/usr/bin/env python3
"""Build a double-clickable, dependency-free single-file RecallWeave demo."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "index.html").read_text()
css = (ROOT / "styles.css").read_text()
core = (ROOT / "src/knowledge.mjs").read_text()
review = (ROOT / "src/review.mjs").read_text()
app = (ROOT / "src/app.mjs").read_text()
deck = (ROOT / "data/deck.json").read_text()

html = html.replace('  <link rel="stylesheet" href="./styles.css">\n', "")
html = html.replace('  <script type="module" src="./src/app.mjs"></script>\n', "")
html = html.replace("</head>", f"<style>\n{css}\n</style>\n</head>")
core = re.sub(r"^export (const|function) ", r"\1 ", core, flags=re.M)
review = re.sub(r"^export (const|function) ", r"\1 ", review, flags=re.M)
(ROOT / "demo.html").write_text(html)
print(f"Built {ROOT / 'demo.html'} ({len(html)} bytes)")
