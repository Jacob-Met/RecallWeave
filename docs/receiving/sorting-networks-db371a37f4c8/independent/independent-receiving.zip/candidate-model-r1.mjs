import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import crypto from 'node:crypto';import {pathToFileURL} from 'node:url';
import {analyze,trace,insertionConfiguration,permutations} from './reference-oracle.mjs';
const root=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const parse=name=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8').replace(/^\uFEFF/,''));
const digest=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const freeze=parse('ORIGINAL-FREEZE.json');
for(const name of ['reference-oracle.mjs','LITERAL-GOLD.json','candidate-model-r1.mjs'])assert.equal(digest(path.join(root,name)),freeze.artifacts.find(f=>f.path===name).sha256);
const candidatePath=process.argv[2];assert.ok(candidatePath,'Explicit admitted candidate core path required');
const model=await import(pathToFileURL(candidatePath).href),literals=parse('LITERAL-GOLD.json'),record={schema:'recall253-independent-model-v1',started:new Date().toISOString(),pid:process.pid,parent:process.ppid,corePath:candidatePath,coreSHA256:digest(candidatePath),groups:[],status:'running'};
function group(name,fn){const g={name,start:new Date().toISOString()};record.groups.push(g);try{g.result=fn();g.status='passed';}catch(e){g.status='failed';g.error=String(e.stack||e);}g.end=new Date().toISOString();}
group('full literal and exhaustive binary observations',()=>{
  const observed=[];
  assert.equal(model.MAX_WIRES,6);assert.equal(model.MAX_COMPARATORS,30);
  for(const test of literals){const expected=analyze(test.configuration),actual=model.analyzeNetwork(test.configuration);assert.deepEqual(actual,expected,test.name);assert.deepEqual(model.traceInput(test.configuration,test.configuration.values),expected.authored,test.name+' traceInput');observed.push({name:test.name,observation:actual});}
  return {families:observed.length,observations:observed};
});
group('2 through 6 wire insertion schedules and all distinct-value permutations',()=>{
  const results=[];
  for(let n=2;n<=6;n++){
    const c=insertionConfiguration(n),observed=model.analyzeNetwork(c);assert.deepEqual(observed,analyze(c));
    let count=0;const hashes=crypto.createHash('sha256');
    for(const values of permutations(Array.from({length:n},(_,i)=>i*3-7))){
      const actual=model.traceInput(c,values),expected=trace(c,values);assert.deepEqual(actual,expected);assert.deepEqual(actual.output,[...values].sort((a,b)=>a-b));hashes.update(JSON.stringify({values,actual})+'\n');count++;
    }
    results.push({wires:n,comparators:c.comparators.length,binary:observed.binary,permutations:count,allPermutationTracesSHA256:hashes.digest('hex')});
  }
  return {permutations:results.reduce((s,r)=>s+r.permutations,0),results};
});
group('exact configuration copy, immutable nested snapshots and JSON serialization',()=>{
  const seed={wires:3,values:[-0,999,-999],comparators:[[1,2],[2,3],[1,2]]},initial=structuredClone(seed),accepted=model.validateConfiguration(seed);
  assert.deepEqual(accepted,{wires:3,values:[0,999,-999],comparators:[[1,2],[2,3],[1,2]]});assert.equal(Object.is(accepted.values[0],-0),false);
  assert.ok(Object.isFrozen(accepted)&&Object.isFrozen(accepted.values)&&Object.isFrozen(accepted.comparators)&&accepted.comparators.every(Object.isFrozen));
  seed.values[1]=5;seed.comparators[0][0]=2;seed.comparators.push([1,3]);assert.deepEqual(accepted,{wires:3,values:[0,999,-999],comparators:[[1,2],[2,3],[1,2]]});
  const downloads=[];
  for(const t of literals){
    const cfg=model.configurationJSON(t.configuration),obs=model.observationJSON(t.configuration);
    assert.equal(cfg,JSON.stringify(JSON.parse(cfg),null,2)+'\n');assert.equal(obs,JSON.stringify(JSON.parse(obs),null,2)+'\n');
    assert.deepEqual(JSON.parse(cfg),analyze(t.configuration).configuration);assert.deepEqual(JSON.parse(obs),analyze(t.configuration));
    downloads.push({name:t.name,configurationSHA256:crypto.createHash('sha256').update(cfg).digest('hex'),observationSHA256:crypto.createHash('sha256').update(obs).digest('hex'),observationBytes:Buffer.byteLength(obs)});
  }
  return {negativeZeroNormalized:true,copyAndFreeze:true,originalSeed:initial,serialization:downloads};
});
group('programmatic malformed inputs refused without coercion',()=>{
  const base=()=>({wires:3,values:[3,1,2],comparators:[[1,2],[2,3],[1,2]]});
  const cases=[['null',null],['array',[]],['boolean',true],['string','{}']];
  for(const key of ['wires','values','comparators']){const c=base();delete c[key];cases.push(['missing '+key,c]);}
  {const c=base();c.extra=1;cases.push(['unsupported field',c]);}
  for(const [name,v] of [['low',1],['high',7],['zero',0],['negative',-3],['fraction',3.5],['boolean',true],['string','3'],['NaN',NaN],['Infinity',Infinity]]){const c=base();c.wires=v;cases.push(['wires '+name,c]);}
  for(const [name,v]of [['null',null],['string','3 1 2'],['short',[1,2]],['long',[1,2,3,4]],['sparse',[3,,2]],['boolean',[true,1,2]],['string value',['3',1,2]],['fraction',[0.5,1,2]],['NaN',[NaN,1,2]],['Infinity',[Infinity,1,2]],['negative Infinity',[-Infinity,1,2]],['over max',[1000,1,2]],['under min',[-1000,1,2]]]){const c=base();c.values=v;cases.push(['values '+name,c]);}
  for(const [name,v]of [['null',null],['string','1 2'],['flat',[1,2]],['nonarray pair',[{a:1,b:2}]],['one value',[[1]]],['three values',[[1,2,3]]],['same wire',[[1,1]]],['reversed',[[2,1]]],['zero',[[0,2]]],['out of range',[[1,4]]],['fraction',[[1,2.5]]],['string number',[[1,'2']]],['boolean',[[true,2]]],['NaN',[[1,NaN]]],['Infinity',[[1,Infinity]]],['31 comparators',Array.from({length:31},()=>[1,2])]]){const c=base();c.comparators=v;cases.push(['comparators '+name,c]);}
  const refusals=[];
  for(const [name,input]of cases){let message;try{model.validateConfiguration(input);}catch(e){message=String(e.message||e);}assert.ok(message,name+' was accepted');refusals.push({name,message});}
  const traceRefusals=[];
  for(const values of [[],[1,2],[1,2,3,4],[true,0,1],[0.25,0,1],[NaN,0,1],[Infinity,0,1],[1000,0,1]]){let message;try{model.traceInput(base(),values);}catch(e){message=String(e.message||e);}assert.ok(message,'invalid trace input accepted');traceRefusals.push(message);}
  return {configurationRefusals:refusals.length,refusals,traceRefusals};
});
group('public decimal editor grammar and raw length boundaries',()=>{
  const positives=[
    {name:'ordinary',args:['3','3 1 2','1 2\n2 3\n1 2'],expected:literals[0].configuration},
    {name:'signed leading zeros and surrounding whitespace',args:[' +03 ',' +003\t-01 -000 ','\n 1 2 \r\n 2 3 \n 1 2 \n'],expected:{wires:3,values:[3,-1,0],comparators:[[1,2],[2,3],[1,2]]}},
    {name:'empty comparators',args:['2','1 0',' \n\t '],expected:{wires:2,values:[1,0],comparators:[]}},
    {name:'wire20',args:['0'.repeat(19)+'2','1 0','1 2'],expected:{wires:2,values:[1,0],comparators:[[1,2]]}},
    {name:'values200',args:['2','1 0'+' '.repeat(197),'1 2'],expected:{wires:2,values:[1,0],comparators:[[1,2]]}},
    {name:'comparators2000',args:['2','1 0','1 2'+' '.repeat(1997)],expected:{wires:2,values:[1,0],comparators:[[1,2]]}},
    {name:'inclusive endpoints',args:['2','-999 +999','1 2'],expected:{wires:2,values:[-999,999],comparators:[[1,2]]}}
  ];
  for(const t of positives)assert.deepEqual(model.parseDraft(...t.args),t.expected,t.name);
  const negatives=[
    ['wire decimal','3.0','3 1 2','1 2'],['wire exponent','3e0','3 1 2','1 2'],['wire hex','0x3','3 1 2','1 2'],['wire unicode','٣','3 1 2','1 2'],['wire missing','','3 1 2','1 2'],
    ['values comma','3','3,1,2','1 2'],['values decimal','3','3 1.0 2','1 2'],['values exponent','3','3 1e0 2','1 2'],['values hex','3','3 0x1 2','1 2'],['values missing','3',' \t ','1 2'],['values extra','3','1 2 3 4','1 2'],['values short','3','1 2','1 2'],['values high','3','1000 1 2','1 2'],['values low','3','-1000 1 2','1 2'],
    ['pair comma','3','3 1 2','1,2'],['interior blank','3','3 1 2','1 2\n\n2 3'],['pair short','3','3 1 2','1'],['pair long','3','3 1 2','1 2 3'],['pair reversed','3','3 1 2','2 1'],['pair same','3','3 1 2','1 1'],['pair too high','3','3 1 2','1 4'],
    ['wire21','0'.repeat(20)+'2','1 0','1 2'],['values201','2','1 0'+' '.repeat(198),'1 2'],['comparators2001','2','1 0','1 2'+' '.repeat(1998)],['31 pairs','2','1 0',Array(31).fill('1 2').join('\n')],['nonstring wire',3,'3 1 2','1 2']
  ];
  const refusals=[];for(const [name,...args] of negatives){let message;try{model.parseDraft(...args);}catch(e){message=String(e.message||e);}assert.ok(message,name+' was accepted');refusals.push({name,message});}
  return {positiveCases:positives.map(t=>({name:t.name,expected:t.expected})),refusals};
});
record.status=record.groups.every(g=>g.status==='passed')?'passed':'failed';record.finished=new Date().toISOString();
fs.writeFileSync(path.join(root,'CANDIDATE-MODEL-r1.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:record.status,pid:process.pid,groups:record.groups.map(g=>({name:g.name,status:g.status,error:g.error}))}));if(record.status!=='passed')process.exitCode=1;
