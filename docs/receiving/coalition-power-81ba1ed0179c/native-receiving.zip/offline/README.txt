Coalition power: when a weight changes the result

Extract this folder, then open START-HERE.html in a browser.
No Git, server, account or dependency installation is required.

Flow:
  Explorer -> Course JSON download -> learner's local chooser
  -> inspect the preview -> explicitly choose Start this deck.

The learner initially opens its bundled lesson, not this new course.
courses/coalition-power.json is the exact course embedded by the explorer.
Save observation is a different JSON format: the applied mathematical game
and current player/filter, not a learner course or learner-answer archive.
Worked guide contains definitions, assumptions and twelve transfer answers.

All page state is in memory; there is no automatic saving.
Keep downloads explicitly when needed. Keep these six files and directories
together so START-HERE and the explorer's relative learner link resolve.

Original twelve-question/four-concept content and examples:
estate-81ba1ed0179c, with AI assistance; original wording/examples CC BY 4.0.
Definitions and source credit are in the worked guide. No source questions
or passages copied. The unchanged learner is RecallWeave canonical main
698902f9c9c1d5c5023092b85b3632a7cb7a01ed.
Native contribution source is partial-history 9868902b63e99eb798ad9946f32dfed4028ffd4c.
No hosted deployment or main integration is implied by this portable folder.
