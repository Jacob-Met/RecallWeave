# Edit distance: prefixes, choices, and alignments

[Open the offline explorer](edit-distance-explorer.html) · [Download the 14-question course](edit-distance.json) · [Open RecallWeave](../demo.html)

The explorer finds the least total cost of transforming one short sequence of Unicode code points into another. Its complete prefix matrix exposes the alternatives behind that answer. A deterministic alignment shows one optimum; an exact count retains other optimal monotone paths.

This original course extends the learner's string-sequence dynamic-programming path. Source and target may have different lengths, and pairing equal-index positions can be a poor choice. The course uses the existing adaptive learner, importer, review, practice and study-note exporter.

## Fix the model before calculating

| Operation | Consumes source | Consumes target | Cost |
|---|---:|---:|---:|
| Match equal code points | 1 | 1 | 0 |
| Substitute different code points | 1 | 1 | 1 |
| Delete a source code point | 1 | 0 | 1 |
| Insert a target code point | 0 | 1 | 1 |

Each input contains **0–24 Unicode code points**. Empty input is meaningful. Spaces, case and code-point representation are preserved; there is no trimming, case folding or normalization. Nonstring model inputs and lone UTF-16 surrogates are refused. Browser text areas use their ordinary line-ending representation; this is not a byte-preserving file importer.

Swapping adjacent code points is not a single allowed edit. **AB → BA** costs 2: substitute both positions. A single insertion or deletion would change the length, and one substitution would leave one wrong position. A model that allows an adjacent transposition at cost 1 can give a different answer.

Minimum edit cost does not establish similarity of meaning, identify someone's intended correction or measure a person's ability.

## Why prefixes solve the whole problem

Let \(D[i][j]\) be the minimum cost from the first \(i\) source code points to the first \(j\) target code points. Rows consume source positions; columns consume target positions. A zero prefix length means an empty sequence.

\[
D[0][j]=j,\qquad D[i][0]=i.
\]

Starting empty requires one insertion per target point. Ending empty requires one deletion per source point. The shared origin costs zero.

For an interior cell, remove the final alignment column. That column consumes a source point, a target point, or both. These cases give:

\[
D[i][j]=\min\left(
D[i-1][j-1]+[s_{i-1}\ne t_{j-1}],
D[i-1][j]+1,
D[i][j-1]+1
\right).
\]

The bracket is 0 for equal code points and 1 otherwise. The candidates mean match/substitution, deletion and insertion.

An optimal preceding prefix must supply each candidate. If that prefix could be cheaper, replacing it would improve the whole alignment. Conversely, appending the last operation to an optimal preceding prefix constructs an alignment with exactly the candidate's cost. Exhausting the possible final columns proves the recurrence. The original Wagner–Fischer paper supplies the recurrence and boundary/reconstruction arguments [1]; the lab's tie preference and examples are its own declared choices.

### A complete table: ABC → AC

| Source prefix ↓ / target prefix → | empty | A | AC |
|---|---:|---:|---:|
| empty | 0 | 1 | 2 |
| A | 1 | 0 | 1 |
| AB | 2 | 1 | 1 |
| ABC | 3 | 2 | **1** |

At **AB → AC**, the diagonal candidate costs \(0+1=1\), substituting B with C after matching A. Deletion and insertion each cost \(1+1=2\).

The **whole** problem chooses match A, delete B, match C, for cost 1. Its path need not pass through every smaller cell that a learner inspected. Each cell answers its own pair of prefixes.

| Alignment column | 1 | 2 | 3 |
|---|---|---|---|
| Source | A | B | C |
| Target | A | gap | C |
| Operation | match | delete | match |
| Cost | 0 | 1 | 0 |

A gap is the absence of a code point. A literal hyphen entered by the learner remains an ordinary code point.

## Ties and exact path counts

For **AB → BA**:

| Source prefix ↓ / target prefix → | empty | B | BA |
|---|---:|---:|---:|
| empty | 0 | 1 | 2 |
| A | 1 | 1 | 1 |
| AB | 2 | 1 | **2** |

All three incoming candidates at the final cell cost 2. The optimal monotone paths are:

| Path | Forward operations | Cost |
|---|---|---:|
| Two substitutions | A → B; B → A | 2 |
| Keep B | delete A; match B; insert A | 2 |
| Keep A | insert B; match A; delete B | 2 |

The origin has **one empty path**. At each later cell, add the counts of precisely the predecessors whose candidate cost equals the minimum. Every path has a unique last move, so these sets are disjoint. Two minimum-cost predecessors with 2 and 3 paths contribute \(2+3=5\), while a more expensive move contributes none.

Counts use BigInt internally and decimal strings in JSON. They count **monotone alignment paths through indexed positions**, not different target texts or all possible orders of commands applied to a mutable string.

### Reconstruct one representative

1. Start at the final cell.
2. Prefer an optimal **diagonal** move, then **deletion**, then **insertion**.
3. Continue to the origin.
4. Reverse the backward choices for the forward display.

For **AA → A**, a diagonal move at the final cell matches the second source A. The preceding boundary step deletes the first A. Displayed forward, the result is **delete the first A, then match the second**. Matching the first A and deleting the second is equally cheap.

For **A → AA**, the same rule matches the source A with the second target A during backtrace. The forward display inserts the first target A, then matches. Distance, path count and the selected representative are separate facts.

## Representation changes the problem

| Source | Target | Distance | Optimal paths |
|---|---|---:|---:|
| empty | empty | 0 | 1 |
| empty | ABC | 3 | 1 |
| ABC | empty | 3 | 1 |
| ABC | AC | 1 | 1 |
| AA | A | 1 | 2 |
| A | AA | 1 | 2 |
| AB | BA | 2 | 3 |
| cat | Cat | 1 | 1 |
| U+00E9 | U+0065 U+0301 | 2 | 2 |
| U+1F469 U+200D U+1F52C | U+1F469 | 2 | 1 |

For **KITTEN → SITTING**, substitute K → S; match I, T and T; substitute E → I; match N; insert G. That construction costs 3. The complete table establishes the optimum, rather than relying only on a plausible edit sequence.

Unicode distinguishes code points from grapheme clusters, which approximate user-perceived characters [3]. This lab exposes code-point sequences and does not implement grapheme segmentation.

The accented **é** may be U+00E9 or U+0065 followed by U+0301. Those representations can look alike. Here, transforming the former into the latter costs 2. One insertion would leave U+00E9 present; one substitution could not create two target code points. One substitution and one insertion suffice.

The declared tie rule chooses **insert U+0065, then substitute U+00E9 with U+0301**. Another optimum substitutes U+00E9 with U+0065, then inserts U+0301. The code-point labels make that distinction visible.

**👩‍🔬** contains woman, zero width joiner and microscope: three code points. **👩** contains one. Matching woman and deleting the other two costs 2, even though each side can appear as one symbol. An application requiring normalized or grapheme-aware comparison needs a different explicit input model.

JavaScript's ordinary string length counts UTF-16 code units. This model iterates code points: 24 copies of 😀 are admitted even though their string length is 48; 25 ASCII letters are refused. Drafts are never silently truncated.

## Explore, export and learn

**Compare strings** admits both complete drafts and replaces the table only when valid. **Load example** explicitly compares the labeled pair. Draft edits mark the retained table as the previous comparison and disable its download until drafts and applied result match again. Validation keeps the draft visible and focuses its error.

Select a matrix cell to see its exact source/target prefixes, complete candidate costs, optimal choices, predecessor counts and local canonical choice. Arrow keys move between cells. A long matrix scrolls within its own region on a small screen.

**Previous**, **Next** and **Show all** reveal forward alignment columns with source/target indices, explicit gaps, code-point labels, operation cost and running cost. Their consumed-prefix explanation connects the alignment to the matrix. These controls change the view, not the complete calculation saved by the download.

**Download this comparison JSON** saves the exact applied record:

- Explicit format and policy: costs, units, input bound, tie order and count meaning.
- Literal source/target and code-point arrays.
- Complete matrix and all per-cell candidates.
- Exact decimal path counts and full canonical alignment.

The record is an inspection export. This lab does not import or execute records or automatically save comparisons across reloads.

**Download the course JSON** always saves the same original 14-question lesson. In RecallWeave, choose **Bring your own lesson**, select the file, inspect the preview and choose **Start this deck**. Finish the session, review explanations, practice missed questions and download study notes through the unchanged learner controls. Explorer edits never rewrite the course.

## All fourteen answer derivations

The learner may shuffle display positions of options. These answer texts and reasons stay stable.

| Question | Correct conclusion | Reason |
|---|---|---|
| CAT → CUT | Cost 1: substitute U for A | The strings differ, so zero is impossible; one substitution suffices. |
| AB → B | Cost 1: delete the first A | One deletion gives the right length and exact target. |
| empty → DOG | Cost 3 | Three unit length increases are necessary and sufficient. |
| AB → BA | Cost 2 | Two substitutions work; no single allowed edit can produce the target. |
| D[2][1] in ABC → AC | AB → A | Indices count prefixes, not suffixes or edit budgets. |
| Boundary row/column | D[0][j] = j; D[i][0] = i | Every nonempty-side point must be inserted or deleted. |
| D[2][2] for AB → AC | min(0 + 1, 1 + 1, 1 + 1) = 1 | Add each last-operation cost before minimizing. |
| Why three candidates suffice | Exhaustive final columns plus optimal preceding prefixes | A cheaper prefix would improve the whole path. |
| Canonical AA → A | Delete first A, match second A | Apply diagonal preference backward, then reverse for display. |
| Optimal AB → BA paths | 3 | Two substitutions, keep B with gaps, or keep A with gaps. |
| Predecessor counts 2 and 3 | 5 | Unique last moves partition paths, so add their counts. |
| U+00E9 → U+0065 U+0301 | Cost 2 | One edit cannot remove U+00E9 while making both target points. |
| Woman–joiner–microscope → woman | Cost 2 | Two deletions work; the length difference supplies a lower bound. |
| 24 emoji versus 25 ASCII letters | Admit 24 code points; refuse 25 | Code-point count, UTF-16 length and edit distance are different quantities. |

Each question supplies its operation or representation assumptions and a transfer prompt. Prerequisite concepts guide selection; explanations do not depend on the immediately preceding question.

## Source and native verification

The model is maintained in edit-distance-core.mjs, the browser behavior in edit-distance-ui.mjs, and the page shell in edit-distance-explorer.template.html. The generated HTML embeds them and the validated course, opening directly without an external dependency.

    node tools/build_edit_distance_explorer.mjs
    node tools/build_edit_distance_explorer.mjs --check
    node --test tests/edit-distance.test.mjs
    node tools/check_edit_distance_browser.mjs --root . --browser /path/to/chromium --output /new/empty/receipt-directory

The focused tests include manually frozen examples, exhaustive path enumeration for all 961 pairs of binary strings up to length four, every prefix cost/count, canonical alignment replay, literal/invalid input, exact generated content and unchanged native learner/review/notes consumers.

The optional browser receiver requires Node 22+ and an already installed Chromium-family browser. It records actual direct-file interaction and physical downloads in a new private output directory and installs nothing.

For source lengths \(m,n\), the distance matrix has \((m+1)(n+1)\) cells, with three candidates per interior cell. This lab additionally retains candidates and exact path counts. BigInt counting has an integer-addition cost; it does not imply unlimited constant-time counting. The explicit 24-code-point limit keeps the complete teaching result bounded.

## Primary references and attribution

1. Robert A. Wagner and Michael J. Fischer, **The String-to-String Correction Problem**, *Journal of the ACM* 21(1), 168–173 (1974). [DOI](https://doi.org/10.1145/321796.321811), [original paper](https://computingbiology.github.io/docs/wagner1974.pdf), [MIT CSAIL bibliography](https://projects.csail.mit.edu/jacm/References/wagnerf1974:168.html). Prefix recurrence, boundary and reconstruction arguments.
2. V. I. Levenshtein, **Binary Codes Capable of Correcting Deletions, Insertions, and Reversals**, *Soviet Physics Doklady* 10(8) (1966 translation of the 1965 paper). [Original translated paper](https://nymity.ch/sybilhunting/pdf/Levenshtein1966a.pdf). Historical attribution; the lab's operations are explicitly fixed above.
3. The Unicode Consortium, **UAX #29: Unicode Text Segmentation**, revision 49. [Grapheme cluster boundaries](https://www.unicode.org/reports/tr29/tr29-49.html#Grapheme_Cluster_Boundaries). This lab explains the distinction and operates on code points.

Original questions, explanations, transfer prompts, worked examples and guide: HAMON / RecallWeave, estate-68094585a1c2. [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/). Referenced papers and Unicode documentation retain their own terms.
