import pathlib,json,hashlib,tarfile,gzip,io,sys,datetime
root=pathlib.Path('/home/jacob/snap/chromium/common/optimizer-counting-principles-3dab-20261008')
out=root/'packet-browser-v1';out.mkdir()
pin=lambda b:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
original=json.loads((root/'receiving/author-source-v1-pins.json').read_text())
assert pin((root/'receiving/author-source-v1-pins.json').read_bytes())['sha256']=='048dcb539fe12fcf808b5a9333f5cdbb85bc1a4b492145d5b014b9a260f55fb4'
subject=json.loads((root/'receiving/browser-source-v1-pins.json').read_text())
for name,row in subject['files'].items():assert pin((root/'source-v1'/name).read_bytes())==row,name
before=json.loads((root/'receiving/browser-v1/browser-report.json').read_text());after=json.loads((root/'receiving/browser-learner-v2/browser-report.json').read_text())
assert before['status']=='failed' and len(before['checks'])==7 and after['status']=='passed' and len(after['checks'])==2
for r in [before,after]:
 assert r['before']==r['after']==subject['files']
 assert not r['pageErrors'] and not r['blocked'] and r['cleanup']['removed'] and r['cleanup']['exitCode']==0
paths=['source-v1/'+name for name in subject['files']]
paths+=['receiving/'+name for name in ['author-source-v1-pins.json','browser-source-v1-pins.json','setup-v1.json','source-assembly-v1.json','receive_counting_browser_v1.mjs','run_counting_browser_v1.py','receive_counting_learner_v2.mjs','run_counting_learner_v2.py','learner-v2-assembly-failure.json','seal_browser_packet_v1.py']]
for folder in ['browser-v1','command-v1','browser-learner-v2','command-learner-v2']:
 paths+= [str(p.relative_to(root)) for p in (root/'receiving'/folder).rglob('*') if p.is_file()]
assert len(paths)==len(set(paths))
members={}
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0,filename='') as gz:
 with tarfile.open(fileobj=gz,mode='w') as tar:
  for name in sorted(paths):
   b=(root/name).read_bytes();members[name]=pin(b)
   info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0
   tar.addfile(info,io.BytesIO(b))
archive=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 assert tar.getnames()==sorted(paths)
 for name in paths:assert tar.extractfile(name).read()==(root/name).read_bytes()
(out/'native-browser-receiving.tar.gz').write_bytes(archive)
(out/'NATIVE_MEMBERS.json').write_text(json.dumps({'files':members},indent=2,sort_keys=True)+'\n')
(out/'README.md').write_text(sys.argv[1])
for name,src in [('SOURCE_PINS.json','author-source-v1-pins.json'),('BROWSER_SOURCE_PINS.json','browser-source-v1-pins.json')]:
 (out/name).write_bytes((root/'receiving'/src).read_bytes())
review=pathlib.Path('/home/jacob/snap/chromium/common/root-counting-content-review-3dab-20261008')
(out/'review').mkdir()
reviews={'REVIEW-v2.md':'fee4f5fd15f286b921139ce0bdae12f699e5406c08d998624fb08508a2c92c63','SOURCE_PINS.json':'ba646d1cb604c775982dad80e41eea00abc77a54fc80bb2c342e50e3b751a7bc','BROWSER_REVIEW.md':'0411f4c448baecf1430000c556dd321656edbd50ada8fb4ce1f235425f54468d','blind-oracle-verification.json':'696d5d01acba8b1142eaa74992de38fdb472d8e7e7aa993c437f13ee0d613991'}
for name,expected in reviews.items():
 b=(review/name).read_bytes();assert pin(b)['sha256']==expected,name;(out/'review'/name).write_bytes(b)
receipt={'sealed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_manifest':pin((out/'SOURCE_PINS.json').read_bytes()),'browser_source_manifest':pin((out/'BROWSER_SOURCE_PINS.json').read_bytes()),'original_report':pin((root/'receiving/browser-v1/browser-report.json').read_bytes()),'original_command':pin((root/'receiving/command-v1/controller.json').read_bytes()),'continuation_report':pin((root/'receiving/browser-learner-v2/browser-report.json').read_bytes()),'continuation_command':pin((root/'receiving/command-learner-v2/controller.json').read_bytes()),'archive':pin(archive),'members':len(members),'all_archived_bytes_readback_exact':True,'source_files_unchanged':10,'result':'seven original completed stages plus two passing continuation stages; original V1 remains FAILED'}
(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
payload={str(p.relative_to(out)):pin(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps({'files':payload},indent=2,sort_keys=True)+'\n')
print(json.dumps({'packet':str(out),'manifest':pin((out/'MANIFEST.json').read_bytes()),'payloads':len(payload),'archive':pin(archive),'members':len(members)},sort_keys=True))
