import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const R=path.dirname(fileURLToPath(import.meta.url)),output=path.join(R,'candidate-native-r1');
assert.equal(fs.existsSync(output),false);fs.mkdirSync(output);
const sha=b=>createHash('sha256').update(b).digest('hex');
const oracleBytes=fs.readFileSync(path.join(R,'finite-walk-oracle-r1.json'));
assert.equal(sha(oracleBytes),'a931f2fad9a349ce18a8a1a7d5278588442569768095bc47c649b3a72380aef3');
const fixtures=JSON.parse(oracleBytes).fixtures,negatives=JSON.parse(fs.readFileSync(path.join(R,'invalid-inputs-r1.json'),'utf8')).cases;
const sourceRoot=path.resolve(process.argv[2]);
const manifest=JSON.parse(fs.readFileSync(path.join(R,'candidate-runtime-manifest-r1.json'),'utf8'));
const checks=[];const receipt={started:new Date().toISOString(),node:process.version,sourceRoot,oracleSha256:sha(oracleBytes),checks};
function checkSources(){return manifest.files.filter(e=>sha(fs.readFileSync(path.join(sourceRoot,e.path)))!==e.sha256).map(e=>e.path);}
assert.deepEqual(checkSources(),[]);
const gcd=(a,b)=>{a=a<0n?-a:a;b=b<0n?-b:b;while(b){[a,b]=[b,a%b];}return a;};
class F{
 constructor(n=0n,d=1n){n=BigInt(n);d=BigInt(d);assert.notEqual(d,0n);if(d<0n){n=-n;d=-d;}const g=gcd(n,d);this.n=n/g;this.d=d/g;}
 add(x){return new F(this.n*x.d+x.n*this.d,this.d*x.d);}
 sub(x){return new F(this.n*x.d-x.n*this.d,this.d*x.d);}
 mul(x){return new F(this.n*x.n,this.d*x.d);}
 div(x){return new F(this.n*x.d,this.d*x.n);}
 toJSON(){return {numerator:String(this.n),denominator:String(this.d)};}
 toString(){return this.n+'/'+this.d;}
}
const zero=()=>new F(),one=()=>new F(1);

function fraction(v){
 assert.deepEqual(Object.keys(v).sort(),['denominator','numerator']);
 assert.match(v.numerator,/^-?(0|[1-9][0-9]*)$/);assert.notEqual(v.numerator,'-0');
 assert.match(v.denominator,/^[1-9][0-9]*$/);
 const f=new F(v.numerator,v.denominator);assert.equal(String(f.n),v.numerator);assert.equal(String(f.d),v.denominator);return f;
}
function equal(v,f){assert.deepEqual(v,f.toJSON());}
function invariantLong(actual,input){
 assert.deepEqual(actual.input,input);assert.equal(actual.frames.length,input.horizon+1);
 const p=new F(input.rightNumerator,input.rightDenominator),q=one().sub(p),N=input.upper;
 const es=[];for(let from=0;from<=N;from++){if(from===0||from===N)es.push({from,to:from,p:one()});else es.push({from,to:from-1,p:q},{from,to:from+1,p});}
 equal(actual.probabilities.right,p);equal(actual.probabilities.left,q);
 let accumulatedTime=zero(),firstLeft=zero(),firstRight=zero();
 const expectation=fraction(actual.eventual[input.start].expectedSteps);
 for(let step=0;step<=input.horizon;step++){
  const frame=actual.frames[step];assert.equal(frame.step,step);assert.equal(frame.distribution.length,N+1);
  const d=frame.distribution.map(fraction);d.forEach(f=>assert.ok(f.n>=0n));assert.equal(d.reduce((s,f)=>s.add(f),zero()).toString(),'1/1');
  const fl=fraction(frame.firstArrival.left),fr=fraction(frame.firstArrival.right);firstLeft=firstLeft.add(fl);firstRight=firstRight.add(fr);
  equal(frame.absorbed.left,firstLeft);equal(frame.absorbed.right,firstRight);equal(frame.absorbed.left,d[0]);equal(frame.absorbed.right,d[N]);
  equal(frame.survival,d.slice(1,N).reduce((s,f)=>s.add(f),zero()));equal(frame.truncatedExpectedSteps,accumulatedTime);equal(frame.expectedExcessSteps,expectation.sub(accumulatedTime));
  if(step===0){
   d.forEach((f,i)=>assert.equal(f.toString(),i===input.start?'1/1':'0/1'));assert.deepEqual(frame.contributions,[]);
   equal(frame.firstArrival.left,input.start===0?one():zero());equal(frame.firstArrival.right,input.start===N?one():zero());
  }else{
   const previous=actual.frames[step-1].distribution.map(fraction),dest=Array.from({length:N+1},zero);
   assert.equal(frame.contributions.length,es.length);
   frame.contributions.forEach((e,k)=>{assert.equal(e.from,es[k].from);assert.equal(e.to,es[k].to);equal(e.probability,es[k].p);equal(e.mass,previous[e.from].mul(es[k].p));dest[e.to]=dest[e.to].add(fraction(e.mass));});
   d.forEach((f,i)=>assert.equal(f.toString(),dest[i].toString()));
   equal(frame.firstArrival.left,previous[1].mul(q));equal(frame.firstArrival.right,previous[N-1].mul(p));
  }
  accumulatedTime=accumulatedTime.add(fraction(frame.survival));
 }
}
try{
 const {analyzeWalk}=await import(pathToFileURL(path.join(sourceRoot,'src/absorbing-walk.mjs')));
 assert.equal(typeof analyzeWalk,'function');
 for(const fixture of fixtures){
  const input=structuredClone(fixture.analysis.input),before=structuredClone(input);const actual=analyzeWalk(input);
  assert.deepEqual(input,before);assert.deepEqual(actual,fixture.analysis);
  checks.push({name:fixture.name,exactWholeAnalysis:true,frames:actual.frames.length});
 }
 const values={string:'2',boolean:true,fractional:1.5,NaN:NaN,Infinity:Infinity,negativeInfinity:-Infinity,undefined:undefined};
 for(const item of negatives){
  const input=Object.hasOwn(item,'value')?structuredClone(item.value):{...item.base,[item.field]:values[item.kind]};
  assert.throws(()=>analyzeWalk(input),undefined,item.label);
 }
 checks.push({name:'strict malformed/bounded inputs',refusals:negatives.length});
 const input={upper:8,start:4,rightNumerator:5,rightDenominator:12,horizon:30},actual=analyzeWalk(input);
 const eventual=fixtures.find(f=>f.name==='wide-denominator').analysis.eventual;
 assert.deepEqual(actual.eventual,eventual);invariantLong(actual,input);
 checks.push({name:'biased denominator12 horizon30 exact induction and independent eventual boundary oracle',frames:31,edgeRecords:actual.frames[1].contributions.length});
 receipt.pass=true;
}catch(e){receipt.pass=false;receipt.error=String(e.stack||e);process.exitCode=1;}
finally{
 receipt.finished=new Date().toISOString();receipt.sourceMismatches=checkSources();
 if(receipt.sourceMismatches.length){receipt.pass=false;process.exitCode=1;}
 fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
}
