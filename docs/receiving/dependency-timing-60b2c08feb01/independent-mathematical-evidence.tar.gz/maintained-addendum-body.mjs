
// Dated receiving addendum (2026-10-08). The original independently frozen
// mathematical tests above remain byte-exact; ordinary descriptor admission
// was explicitly clarified by the model author after that initial freeze.
test('duration admission refuses accessors without executing getters or coercion', () => {
  const result = checkOrdinaryDurationRecords(analyzeTiming);
  assert.equal(result.refusal_cases, 26);
  assert.equal(result.accepted_controls, 6);
});

test('the checked-in timing page exactly matches the native builder output', async () => {
  const {buildDependencyTiming, dependencyTimingPath} =
    await import('../tools/build-dependency-timing.mjs');
  const {readFileSync} = await import('node:fs');
  assert.equal(buildDependencyTiming(), readFileSync(dependencyTimingPath, 'utf8'));
});
