import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
const root='/home/jacob/recall-stable-matching-81ba1ed0179c';
const own='/home/jacob/stable-matching-independent-integration-81ba1ed0179c';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const original=JSON.parse(await fs.readFile(root+'/evidence/source-v1-part1.json','utf8')).files['src/stable-matching.mjs'];
assert.equal(typeof original,'string');
const oldPath=own+'/core-before-signed-zero.mjs';
await fs.writeFile(oldPath,original,{flag:'wx'});
const currentPath=root+'/source/src/stable-matching.mjs';
const current=await fs.readFile(currentPath,'utf8');
assert.equal(hash(original),'53e80279fcca73a348714bf974548bb81e76b888e3a0945099fcccb9107bd5ee');
assert.equal(hash(current),'551a9b9532c5cf47a8b996d54ab70361bb1f8a2a90b00ec3f399598aa6d96517');
const delta=' || Object.is(index, -0)';
assert.equal(current.split(delta).length,2);
assert.equal(current.replace(delta,''),original);
const before=await import(pathToFileURL(oldPath));
const after=await import(pathToFileURL(currentPath));
const records=[];
for(const side of ['left','right']){
 const ordinary={leftPreferences:[[0]],rightPreferences:[[0]],proposingSide:side};
 assert.deepEqual(after.traceStableMatching(ordinary),before.traceStableMatching(ordinary));
 assert.deepEqual(after.listCompleteMatchings(ordinary),before.listCompleteMatchings(ordinary));
 assert.deepEqual(after.inspectMatching(ordinary,[0]),before.inspectMatching(ordinary,[0]));
 assert.deepEqual(after.traceStableMatching(ordinary),JSON.parse(JSON.stringify(after.traceStableMatching(ordinary))));
 records.push('Ordinary zero singleton trace/list/inspection and JSON equality, '+side+' proposes');
 for(const key of ['leftPreferences','rightPreferences']){
  const signed={...ordinary,[key]:[[-0]]};
  assert.ok(Object.is(before.traceStableMatching(signed).profile[key][0][0],-0));
  assert.throws(()=>after.traceStableMatching(signed));
  assert.throws(()=>after.listCompleteMatchings(signed));
  assert.throws(()=>after.inspectMatching(signed,[0]));
  records.push('Signed zero in '+key+' refused at trace/list/inspection admission, '+side+' proposes');
 }
 assert.ok(Object.is(before.inspectMatching(ordinary,[-0]).leftMatching[0],-0));
 assert.throws(()=>after.inspectMatching(ordinary,[-0]));
 records.push('Signed zero complete matching refused, '+side+' proposes');
}
assert.equal(hash(await fs.readFile(currentPath)),hash(current));
const receipt={schema:'hamon.independent_source_addendum.v1',at:new Date().toISOString(),reviewer:'estate-81ba1ed0179c/integration',success:true,original_sha256:hash(original),current_sha256:hash(current),delta,checks:records,scope:'One canonical-index guard plus bounded ordinary/signed-zero controls. Original 12 independent math groups retained separately and not rerun.',source_unchanged:true};
const target=own+'/signed-zero-addendum.json';
await fs.writeFile(target,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
const b=await fs.readFile(target);console.log(JSON.stringify({path:target,bytes:b.length,sha256:hash(b),checks:records.length}));
