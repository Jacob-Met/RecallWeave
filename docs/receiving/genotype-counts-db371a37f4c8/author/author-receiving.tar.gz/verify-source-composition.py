import datetime,hashlib,json,pathlib
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
P=R/'SOURCE-COMPOSITION-INPUT.json';packet=json.loads(P.read_text(encoding='utf-8'))
def object_hash(kind,body):return hashlib.sha1(kind.encode()+b' '+str(len(body)).encode()+b'\0'+body).hexdigest()
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':object_hash('blob',b)}
def verify(tree):
 assert not tree['truncated'];entries=tree['tree'];mapping={e['path']:e for e in entries};assert len(entries)==len(mapping)
 children={}
 for e in entries:
  path=pathlib.PurePosixPath(e['path']);assert not path.is_absolute() and '..' not in path.parts
  parent=str(path.parent);parent='' if parent=='.' else parent;children.setdefault(parent,[]).append(e)
 computed={}
 for directory in sorted(children,key=lambda p:(-p.count('/'),-len(p))):
  body=b''
  for e in sorted(children[directory],key=lambda e:(pathlib.PurePosixPath(e['path']).name+('/' if e['type']=='tree' else '')).encode()):
   name=pathlib.PurePosixPath(e['path']).name;sha=computed[e['path']] if e['type']=='tree' else e['sha'];assert sha==e['sha']
   mode='40000' if e['type']=='tree' else e['mode']
   body+=mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(sha)
  computed[directory]=object_hash('tree',body)
  assert computed[directory]==(tree['sha'] if directory=='' else mapping[directory]['sha']),directory
 assert computed['']==tree['sha']
 return {'tree':computed[''],'directoriesVerified':len(computed),'leaves':{e['path']:e for e in entries if e['type']!='tree'}}
a=verify(packet['original']);b=verify(packet['final'])
for path,e in a['leaves'].items():
 q=b['leaves'][path];assert all(e[k]==q[k] for k in ['sha','mode','type']),path
additions={p:e for p,e in b['leaves'].items() if p not in a['leaves']}
assert set(additions)=={e['path'] for e in packet['newFiles']}
bound=[]
for f in packet['newFiles']:
 p=pathlib.Path(packet['nativeSourceRoot'])/f['path'];v=pin(p);assert v['git']==f['sha']==additions[f['path']]['sha'];bound.append({'path':f['path'],**v})
c=packet['commit'];assert c['tree']['sha']==b['tree'] and len(c['parents'])==1 and c['parents'][0]['sha']==packet['canonicalCommit']=='ec07bf3989132130759e5c00c6cb02eef19709d3'
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':c['sha'],'parent':packet['canonicalCommit'],'originalTree':a['tree'],'finalTree':b['tree'],'originalLeavesPreserved':len(a['leaves']),'finalLeaves':len(b['leaves']),'originalDirectoriesVerified':a['directoriesVerified'],'finalDirectoriesVerified':b['directoriesVerified'],'additions':bound,'input':pin(P),'noRefsOrActions':True,'claimBoundary':'Full API tree reconstruction and native four-file byte binding, not a claim that all repository blobs were locally copied or executed.'}
out=R/'SOURCE-COMPOSITION-PROOF.json';out.write_bytes((json.dumps(proof,indent=2)+'\n').encode());print(json.dumps({'proof':proof,'proofPin':pin(out)}))
v=R/'AUTHOR-VISUAL-REVIEW.json';original=v.read_bytes();(R/'AUTHOR-VISUAL-REVIEW-first-write.json').write_bytes(original)
record=json.loads(original);record.pop('at',None);record['recordedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['reviewInterval']='After the11:54:50 browser closure and before the11:57:07 source freeze; the first draft used an approximate minute timestamp, retained separately.'
v.write_bytes((json.dumps(record,indent=2)+'\n').encode())
