import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

const args = process.argv.slice(2);
assert.equal(args.length % 2, 0);
const options = Object.fromEntries(args.reduce((all, value, index) => index % 2 ? all : [...all, [value.replace(/^--/, ''), args[index + 1]]], []));
const root = resolve(options.root), output = resolve(options.output);
await mkdir(output, { recursive: true });
const temporary = resolve(output, 'owned-browser-temporary');
await mkdir(temporary, { recursive: true });
process.env.TMPDIR = temporary;
const { chromium } = createRequire(import.meta.url)(options.playwright);
const source = JSON.parse(await readFile(options.manifest, 'utf8'));
assert.deepEqual(source.missing, []);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
for (const row of source.files) assert.equal(hash(await readFile(resolve(root, row.path))), row.sha256, row.path);
const bytes = await readFile(options.input);
assert.equal(bytes.length, 3285);
assert.equal(hash(bytes), '544dced1fc8c909dd2a8353fe28bb7235effb5e871a38eebcdf377b3cd505475');
const deck = JSON.parse(bytes.toString('utf8'));
assert.deepEqual(deck.items.map(item => item.id), ['apply-a', 'measure', 'apply-b', 'foundation', 'compare']);
const report = { source_commit: source.commit, source_tree: source.tree, source_files: source.files,
  input: { path: resolve(options.input), bytes: bytes.length, sha256: hash(bytes) },
  receiver_sha256: hash(await readFile(new URL(import.meta.url))), node: process.version,
  cases: [], downloads: [], screenshots: [], page_errors: [], external_requests: [] };
const genericPrompt = 'Choose one connection from this deck and explain how it relates to another idea in your own words.';
const noteFor = id => `My ${id} connection: <literal> café "evidence"\nSecond line for ${id}.`;
const application = 'My imported-course application: <em>literal</em>\nConnect the retained ideas in my own words.';
const file = { name: 'actual-focused-lesson.json', mimeType: 'application/json', buffer: bytes };
const server = createServer(async (request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
  if (pathname === '/favicon.ico') { response.writeHead(204); response.end(); return; }
  const path = resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
  if (!path.startsWith(root + sep)) { response.writeHead(403); response.end(); return; }
  try {
    const data = await readFile(path);
    response.writeHead(200, { 'Content-Type': (({ '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json' })[extname(path)] || 'application/octet-stream') + '; charset=utf-8' });
    response.end(data);
  } catch { response.writeHead(404); response.end(); }
});
await new Promise(done => server.listen(0, '127.0.0.1', done));
const origin = 'http://127.0.0.1:' + server.address().port;
let browser;
async function button(page, selector) { const control = page.locator(selector); await control.focus(); await control.press('Enter'); }
async function preview(page) {
  await page.locator('#deck-file').setInputFiles(file);
  await page.locator('#start-deck').waitFor({ state: 'visible' });
  assert.equal(await page.locator('#deck-preview-title').textContent(), deck.title);
}
async function finish(page, mixed) {
  const answers = [];
  for (let index = 0; index < deck.items.length; index++) {
    const prompt = await page.locator('.question-card h2').textContent();
    const item = deck.items.find(item => item.prompt === prompt);
    assert.ok(item && !answers.some(answer => answer.id === item.id));
    const choice = mixed && index % 2 ? (item.answer + 1) % item.options.length : item.answer;
    await button(page, `[data-choice="${choice}"]`);
    assert.ok((await page.locator('#feedback-slot').textContent()).includes(item.explanation));
    answers.push({ id: item.id, choice, correct: choice === item.answer });
    await button(page, '#next-button');
  }
  assert.equal(await page.locator('[data-reflection-item]').count(), 5);
  assert.equal(await page.locator('#application-prompt').textContent(), genericPrompt);
  return answers;
}
async function currentWriting(page) {
  return page.evaluate(() => ({
    notes: [...document.querySelectorAll('[data-reflection-item]')].map(field => [field.dataset.reflectionItem, field.value]),
    application: document.querySelector('#application-reflection').value,
    first_summary: document.querySelector('#first-try-summary').textContent,
    mastery: document.querySelector('.mastery-box').textContent
  }));
}
async function downloadNotes(page, filename) {
  const event = page.waitForEvent('download');
  await button(page, '#save-notes-button');
  const download = await event;
  assert.equal(await download.failure(), null);
  const chunks = [];
  for await (const chunk of await download.createReadStream()) chunks.push(chunk);
  const data = Buffer.concat(chunks);
  await writeFile(resolve(output, filename), data);
  const record = { filename, bytes: data.length, sha256: hash(data), suggested_filename: download.suggestedFilename() };
  report.downloads.push(record);
  return { text: data.toString('utf8'), record };
}
try {
  browser = await chromium.launch({ executablePath: options.browser, headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-background-networking'] });
  report.browser_version = browser.version();
  for (const standalone of [false, true]) {
    const mode = standalone ? 'standalone-phone' : 'modular';
    const context = await browser.newContext({ acceptDownloads: true, viewport: { width: standalone ? 390 : 1280, height: standalone ? 844 : 960 } });
    await context.route('**/*', route => {
      const url = route.request().url();
      if (url.startsWith(origin + '/') || url.startsWith(pathToFileURL(root + '/').href) || url.startsWith('blob:') || url.startsWith('data:')) return route.continue();
      report.external_requests.push(url); return route.abort();
    });
    if (standalone) await context.setOffline(true);
    const page = await context.newPage();
    page.on('pageerror', error => report.page_errors.push(String(error)));
    try {
      await page.goto(standalone ? pathToFileURL(resolve(root, 'demo.html')).href : origin + '/index.html');
      await button(page, '#start-button');
      await button(page, '[data-choice="0"]');
      const original = await page.locator('#session-content').innerHTML();
      await preview(page);
      assert.equal(await page.locator('#session-content').innerHTML(), original);
      await button(page, '#cancel-deck');
      assert.equal(await page.locator('#session-content').innerHTML(), original);
      await preview(page);
      await button(page, '#start-deck');
      const firstAnswers = await finish(page, true);
      assert.equal(firstAnswers.filter(answer => answer.correct).length, 3);
      assert.deepEqual((await currentWriting(page)).notes.map(([, value]) => value), ['', '', '', '', '']);
      for (const answer of firstAnswers) {
        const field = page.locator(`[data-reflection-item="${answer.id}"]`);
        const details = field.locator('xpath=ancestor::details[1]');
        await details.locator('summary').click();
        const item = deck.items.find(item => item.id === answer.id);
        assert.deepEqual(await details.locator('dd').allTextContents(), [item.options[answer.choice], item.options[item.answer]]);
        await field.fill(noteFor(answer.id));
      }
      await page.locator('#application-reflection').fill(application);
      const written = await currentWriting(page);
      assert.match(written.first_summary, /3 of 5/);
      for (const [id, value] of written.notes) assert.equal(value, noteFor(id));
      await preview(page);
      assert.deepEqual(await currentWriting(page), written);
      await button(page, '#cancel-deck');
      assert.deepEqual(await currentWriting(page), written);
      await button(page, '#practice-button');
      const missed = firstAnswers.filter(answer => !answer.correct);
      for (const answer of missed) {
        const item = deck.items.find(item => item.id === answer.id);
        assert.equal(await page.locator('.practice-card h2').textContent(), item.prompt);
        await button(page, `[data-practice-choice="${item.answer}"]`);
        await button(page, '#practice-feedback button');
      }
      assert.deepEqual(await currentWriting(page), written);
      const notes = await downloadNotes(page, mode + '-reflections.txt');
      assert.ok(notes.text.includes(deck.attribution)); assert.ok(notes.text.includes(deck.license));
      assert.ok(notes.text.includes('3 of 5 connections correct on the first try.'));
      assert.ok(notes.text.includes('Complete: 2 of 2 practice answers recorded; 2 correct on retry.'));
      for (let index = 0; index < firstAnswers.length; index++) {
        const answer = firstAnswers[index], item = deck.items.find(item => item.id === answer.id);
        const marker = `\n${index + 1}. ${item.prompt}\n`;
        const start = notes.text.indexOf(marker); assert.ok(start >= 0, item.id);
        const next = index + 1 < firstAnswers.length ? `\n${index + 2}. ${deck.items.find(item => item.id === firstAnswers[index + 1].id).prompt}\n` : '\nYOUR APPLICATION REFLECTION';
        const end = notes.text.indexOf(next, start + marker.length); assert.ok(end > start);
        const block = notes.text.slice(start, end);
        for (const expected of [`Your first answer: ${item.options[answer.choice]}`, `Correct answer: ${item.options[item.answer]}`, item.explanation, item.transfer,
          ...noteFor(item.id).split('\n').map(line => `  > ${line}`)]) assert.ok(block.includes(expected), item.id + ': ' + expected);
        for (const other of deck.items.filter(other => other.id !== item.id)) assert.ok(!block.includes(noteFor(other.id).split('\n')[0]));
        if (!answer.correct) assert.ok(block.includes(`Practice answer: ${item.options[item.answer]}`));
      }
      assert.ok(notes.text.includes('Prompt: ' + genericPrompt));
      for (const line of application.split('\n')) assert.ok(notes.text.includes('  > ' + line));
      assert.equal(await page.locator('textarea em, textarea literal').count(), 0);
      const dimensions = await page.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }));
      assert.ok(dimensions.scroll <= dimensions.width, JSON.stringify(dimensions));
      if (standalone) {
        await page.locator('#application-reflection').scrollIntoViewIfNeeded();
        const filename = 'phone-current-reflections.png';
        await page.screenshot({ path: resolve(output, filename) });
        report.screenshots.push(filename);
      }
      await preview(page);
      assert.deepEqual(await currentWriting(page), written);
      await button(page, '#start-deck');
      const freshAnswers = await finish(page, false);
      assert.ok(freshAnswers.every(answer => answer.correct));
      const cleared = await currentWriting(page);
      assert.deepEqual(cleared.notes.map(([, value]) => value), ['', '', '', '', '']);
      assert.equal(cleared.application, '');
      assert.match(cleared.first_summary, /5 of 5/);
      const fresh = await downloadNotes(page, mode + '-fresh-session.txt');
      for (const item of deck.items) assert.ok(!fresh.text.includes(noteFor(item.id).split('\n')[0]));
      assert.ok(!fresh.text.includes(application.split('\n')[0]));
      assert.ok(fresh.text.includes('No missed connections in the first session.'));
      report.cases.push({ name: mode + ': actual focused-file import, reflection identity, cancel/practice retention and explicit fresh-session clearing', passed: true,
        firstAnswers, retries: missed.map(answer => answer.id), first_summary: written.first_summary, mastery: written.mastery,
        reflections: written.notes, application: written.application, dimensions, notes: notes.record, fresh_notes: fresh.record, fresh_summary: cleared.first_summary });
      console.log('PASS ' + mode);
    } catch (error) { report.cases.push({ name: mode, passed: false, error: error.stack }); throw error; }
    finally { await context.close(); }
  }
  assert.deepEqual(report.page_errors, []);
  assert.deepEqual(report.external_requests, []);
  for (const row of source.files) assert.equal(hash(await readFile(resolve(root, row.path))), row.sha256, row.path + ' unchanged');
  assert.equal(hash(await readFile(options.input)), report.input.sha256);
  report.passed = true;
} catch (error) { report.passed = false; report.error = error.stack; process.exitCode = 1; }
finally {
  await browser?.close();
  await new Promise(done => server.close(done));
  await rm(temporary, { recursive: true, force: true });
  await writeFile(resolve(output, 'receiving.json'), JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ passed: report.passed, cases: report.cases.length, downloads: report.downloads.length, output }));
