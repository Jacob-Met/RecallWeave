const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto");
const {pathToFileURL}=require("node:url");
const root="/home/jacob/recallweave-fenwick-bd1abdb2f886-20261008";
const hash=(b)=>crypto.createHash("sha256").update(b).digest("hex");
const git=(b)=>crypto.createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
const pin=(p)=>{const b=fs.readFileSync(p);return{bytes:b.length,sha256:hash(b),git_blob:git(b),mode:(fs.statSync(p).mode&511).toString(8)};};
(async()=>{
 const space=fs.statfsSync(root);if(space.bavail*space.bsize<134217728)throw Error("128MiB capacity reserve");
 const inputBytes=fs.readFileSync(path.join(root,"native-input.json"));const input=JSON.parse(inputBytes);
 const source=path.join(root,"original");const qa=path.join(root,"baseline-qa");
 if(fs.existsSync(source)||fs.existsSync(qa))throw Error("Fresh original/QA paths required; inspect prior result");
 fs.mkdirSync(source);fs.mkdirSync(qa);
 const before={};
 for(const file of input.files){
  if(!/^(src\/deck\.mjs|courses\/euclidean-algorithm\.json)$/.test(file.path))throw Error("Unexpected source path");
  const bytes=Buffer.from(file.content,"utf8");if(git(bytes)!==file.git_blob)throw Error("Git source mismatch");
  const dst=path.join(source,file.path);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,bytes,{flag:"wx",mode:420});before[file.path]=pin(dst);
 }
 const {parseDeck}=await import(pathToFileURL(path.join(source,"src/deck.mjs")));
 const parsed=parseDeck(fs.readFileSync(path.join(source,"courses/euclidean-algorithm.json"),"utf8"));
 const after=Object.fromEntries(input.files.map(file=>[file.path,pin(path.join(source,file.path))]));
 if(JSON.stringify(before)!==JSON.stringify(after))throw Error("Original source changed");
 const absent=input.complete_leaf_inventory.filter(x=>/fenwick|binary.indexed|prefix.sum/i.test(x.path));
 if(absent.length)throw Error("Unexpected existing feature source");
 const result={schema:"recallweave-fenwick-native-baseline/v1",at:new Date().toISOString(),pass:true,
  scope:input.scope,canonical:{commit:input.commit,tree:input.tree,inventory_leaves:input.complete_leaf_inventory.length},
  runtime:{execPath:process.execPath,version:process.version,platform:process.platform,arch:process.arch},
  capacity_before:space.bavail*space.bsize,baseline_input:pin(path.join(root,"native-input.json")),
  contract_blob:input.contract_blob,unchanged_validator_receiving:{course_title:parsed.title,items:parsed.items.length,concepts:parsed.concepts.length},
  feature_absence:{path_matches:absent,interpretation:"Source absence, not an invented runtime failure."},
  source_before:before,source_after:after,controller:pin(__filename)};
 fs.writeFileSync(path.join(qa,"baseline.json"),JSON.stringify(result,null,2)+"\n",{flag:"wx"});
 console.log(JSON.stringify({pass:true,items:parsed.items.length,source_unchanged:true,receipt:pin(path.join(qa,"baseline.json"))}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
