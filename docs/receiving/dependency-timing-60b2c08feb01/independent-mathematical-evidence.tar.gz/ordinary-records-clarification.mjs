// Receiving addendum, 2026-10-08: root explicitly clarified ordinary own
// data descriptors after the original independent mathematical oracle freeze.
// This file adds admission checks only; the frozen path oracle is unchanged.
import assert from 'node:assert/strict';

export function checkOrdinaryDurationRecords(analyzeTiming) {
  const cases = [];
  const job = 'constructor', end = '工程🔧';
  const hooks = {get: 0, set: 0, primitive: 0};
  const zeroHooks = () => assert.deepEqual(hooks, {get: 0, set: 0, primitive: 0},
    'Admission must not invoke record accessors or value coercion hooks');
  const valueFor = field => field === 'job' ? job : 0;
  const toxicValue = kind => {
    const value = kind === 'boxed-number' ? new Number(0) :
      kind === 'boxed-string' ? new String(job) : {};
    Object.defineProperties(value, {
      [Symbol.toPrimitive]: {value() { hooks.primitive++; throw new Error('coercion ran'); }},
      valueOf: {value() { hooks.primitive++; throw new Error('valueOf ran'); }},
      toString: {value() { hooks.primitive++; throw new Error('toString ran'); }}
    });
    return value;
  };
  const unchanged = (record, descriptors, frozen) => {
    assert.deepEqual(Reflect.ownKeys(record), Reflect.ownKeys(descriptors));
    const after = Object.getOwnPropertyDescriptors(record);
    for (const key of Reflect.ownKeys(descriptors)) {
      assert.deepEqual(Reflect.ownKeys(after[key]), Reflect.ownKeys(descriptors[key]));
      for (const attr of Reflect.ownKeys(descriptors[key]))
        assert.equal(after[key][attr], descriptors[key][attr], 'Input descriptor changed');
    }
    assert.equal(Object.isFrozen(record), frozen, 'Caller record freezing changed');
  };
  const run = (name, make, accept) => {
    for (const cyclic of [false, true]) {
      const graph = {jobs: [job, end], edges: cyclic ? [[job, job]] : [[job, end]]};
      const beforeGraph = JSON.stringify(graph);
      const record = make(), second = {job: end, duration: 2};
      const entries = [record, second], descriptors = Object.getOwnPropertyDescriptors(record);
      const frozen = Object.isFrozen(record);
      if (accept) {
        const result = analyzeTiming(graph, entries);
        assert.deepEqual(result.durations, [{job, duration: 0}, {job: end, duration: 2}]);
        assert.equal(Object.is(result.durations[0].duration, -0), false);
        assert.notEqual(result.durations[0], record);
        assert(Object.isFrozen(result) && Object.isFrozen(result.durations) &&
          Object.isFrozen(result.durations[0]));
        if (cyclic) {
          assert.equal(result.timing, null);
          assert.deepEqual(result.graphAnalysis.cycleMembers, [job]);
          assert.deepEqual(result.graphAnalysis.blockedByCycle, []);
        } else {
          assert.equal(result.timing.projectDuration, 2);
          assert.deepEqual(result.timing.criticalEdges, [[job, end]]);
        }
      } else assert.throws(() => analyzeTiming(graph, entries));
      zeroHooks();
      unchanged(record, descriptors, frozen);
      assert.equal(JSON.stringify(graph), beforeGraph);
      assert.equal(entries.length, 2);
      assert.equal(entries[0], record); assert.equal(entries[1], second);
      assert.deepEqual(second, {job: end, duration: 2});
      assert.equal(Object.isFrozen(entries), false);
      cases.push({name, graph: cyclic ? 'cyclic' : 'acyclic', accepted: accept,
        input_preserved: true, accessor_and_coercion_calls: 0});
    }
  };
  for (const field of ['job', 'duration']) for (const kind of
    ['getter', 'throwing-getter', 'setter-only', 'getter-and-setter']) {
    run(field + '/' + kind, () => {
      const record = {job, duration: 0};
      const descriptor = {enumerable: true, configurable: true};
      if (kind !== 'setter-only') descriptor.get = () => {
        hooks.get++; if (kind === 'throwing-getter') throw new Error('getter ran');
        return valueFor(field);
      };
      if (kind === 'setter-only' || kind === 'getter-and-setter')
        descriptor.set = () => { hooks.set++; };
      Object.defineProperty(record, field, descriptor);
      return record;
    }, false);
  }
  run('both-fields/getters', () => Object.defineProperties({}, {
    job: {get() { hooks.get++; return job; }},
    duration: {get() { hooks.get++; return 0; }}
  }), false);
  for (const [field, kind] of [
    ['job', 'object'], ['duration', 'object'],
    ['duration', 'boxed-number'], ['job', 'boxed-string']
  ]) run(field + '/' + kind + '-without-coercion', () =>
    ({job, duration: 0, [field]: toxicValue(kind)}), false);
  run('null-prototype/ordinary-negative-zero', () =>
    Object.assign(Object.create(null), {job, duration: -0}), true);
  run('nonenumerable/ordinary-negative-zero', () => Object.defineProperties({}, {
    job: {value: job}, duration: {value: -0}
  }), true);
  run('ordinary-own-data-shadows-inherited-accessors', () => {
    const inherited = Object.defineProperties({}, {
      job: {get() { hooks.get++; throw new Error('inherited getter ran'); }},
      duration: {get() { hooks.get++; throw new Error('inherited getter ran'); }}
    });
    return Object.defineProperties(Object.create(inherited), {
      job: {value: job, enumerable: true}, duration: {value: -0, enumerable: true}
    });
  }, true);
  assert.equal(cases.filter(row => !row.accepted).length, 26);
  assert.equal(cases.filter(row => row.accepted).length, 6);
  return {cases, hooks, refusal_cases: 26, accepted_controls: 6};
}
