import {withBrowser} from './browser-helpers.mjs';
import {join} from 'node:path';
import {writeFile,copyFile} from 'node:fs/promises';
const root='/home/jacob/recallweave-spring-energy-bd1abdb2f886-20261008';
const output=join(root,'qa/phone-before-correction');
const r=await withBrowser({output,profileParent:join(root,'qa')},async b=>{
 await b.viewport(390,844);await b.navigate('file://'+root+'/source/courses/spring-energy-lab.html');
 await b.click('[data-phase="270"]');
 const geometry=await b.evaluate('({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,overflow:[...document.querySelectorAll("body *")].filter(n=>!n.closest(".table-region")&&!n.closest("svg")).map(n=>{const r=n.getBoundingClientRect();return{tag:n.tagName,id:n.id,class:n.className,left:r.left,right:r.right,width:r.width,text:n.textContent.slice(0,70)}}).filter(r=>r.width>0&&(r.right>innerWidth+.1||r.left<-.1))})');
 b.report.observations.push(geometry);
 await writeFile(join(output,'geometry.json'),JSON.stringify(geometry,null,2)+'\n');
 await b.click('#motion-title');b.report.observations.push(await b.screenshot('phone-motion-before.png'));
 await b.check('original390px page overflow reproduced before any source correction',async()=>{if(!(geometry.scrollWidth>390))throw Error('No original overflow');});
});
await copyFile(join(root,'source/templates/spring-energy-lab.html'),join(output,'spring-energy-lab.template.html'));
await copyFile(join(root,'source/courses/spring-energy-lab.html'),join(output,'spring-energy-lab.html'));
console.log(JSON.stringify({status:r.status,observations:r.observations,cleanup:r.cleanup}));
process.exitCode=r.status==='passed'?0:1;
