const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const root = __dirname, source = path.join(root, 'source-r1'), out = path.join(root, 'ui-native-r0');
const hash = b => ({bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),git:crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex')});
const baseline = JSON.parse(fs.readFileSync(path.join(root,'core-native-r0','receiving.json'),'utf8')).after;
const original = Object.fromEntries(Object.keys(baseline).map(p=>[p,hash(fs.readFileSync(path.join(source,p)))]));
if(JSON.stringify(original)!==JSON.stringify(baseline)) throw Error('Original core inputs changed');
const runtime=hash(fs.readFileSync(process.execPath)), capacity={user:os.userInfo().username,node:process.version,freeMemory:os.freemem(),freeDisk:Number(fs.statfsSync(root).bavail)*Number(fs.statfsSync(root).bsize),time:new Date().toISOString()};
if(capacity.user!=='jacob'||capacity.node!=='v24.14.0'||runtime.sha256!=='63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088'||capacity.freeMemory<536870912||capacity.freeDisk<67108864) throw Error('Admission refused');
if(fs.existsSync(out)||fs.existsSync(path.join(source,'prerequisites.html'))) throw Error('Output already exists');
const files=JSON.parse(fs.readFileSync(path.join(root,'ui-payload-r0.json'),'utf8'));
for(const [p,text] of Object.entries(files)){const target=path.join(source,p);if(fs.existsSync(target))throw Error('New source path exists '+p);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,text,{flag:'wx'});}
fs.mkdirSync(out);
const before=Object.fromEntries([...Object.keys(baseline),...Object.keys(files)].map(p=>[p,hash(fs.readFileSync(path.join(source,p)))]));
const commands=[['tools/build-course-prerequisites.mjs'],['--check','src/course-prerequisites-ui.mjs'],['--test','tests/course-prerequisites-bundle.test.mjs'],['tools/build-course-prerequisites.mjs','--check']];
const results=[];
for(let i=0;i<commands.length;i++){const start=Date.now();const argv=['--max-old-space-size=128',...commands[i]];const child=spawnSync(process.execPath,argv,{cwd:source,encoding:'utf8',timeout:30000,maxBuffer:1048576,windowsHide:true});fs.writeFileSync(path.join(out,i+'.stdout.txt'),child.stdout||'',{flag:'wx'});fs.writeFileSync(path.join(out,i+'.stderr.txt'),child.stderr||'',{flag:'wx'});results.push({argv,exit:child.status,signal:child.signal,error:child.error?String(child.error):null,elapsedMs:Date.now()-start,stdout:hash(Buffer.from(child.stdout||'')),stderr:hash(Buffer.from(child.stderr||''))});if(child.status!==0||child.signal||child.error)break;}
const after=Object.fromEntries(Object.keys(before).map(p=>[p,hash(fs.readFileSync(path.join(source,p)))]));
const generated=fs.existsSync(path.join(source,'prerequisites.html'))?hash(fs.readFileSync(path.join(source,'prerequisites.html'))):null;
const report={format:'recallweave-prerequisite-ui-native/1',capacity,runtime,before,after,unchanged:JSON.stringify(before)===JSON.stringify(after),generated,results,runtimeAfter:hash(fs.readFileSync(process.execPath))};
report.accepted=results.length===4&&results.every(r=>r.exit===0&&!r.signal&&!r.error)&&report.unchanged&&JSON.stringify(runtime)===JSON.stringify(report.runtimeAfter);
fs.writeFileSync(path.join(out,'receiving.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));process.exit(report.accepted?0:1);
