# Independent receiving contract — RecallWeave absorbing walk

Frozen 2026-10-09 before any new absorbing-walk source or author tests are read.
Receiver estate-db371a37f4c8 / longwater_receiving_recovery.
Canonical repository Jacob-Met/RecallWeave main698902f9c9c1d5c5023092b85b3632a7cb7a01ed, actual complete tree d6d3707b691850af7928299242631534cff89aa8 (2915 leaves).
Public pre-code contract is issue206, created2026-10-09T03:50:33Z; exact body copied separately.
Existing finite rank-selection stopping issue191 retains its distinct nine paths. New author fence is the eleven paths plus unique evidence stated in issue206; original Markov, deck/parser/learner/catalog and workflows are exact inputs.

## Independence and original boundary
I directly read original Markov core Git9731705b87a6b01a334bd8e21b930ae07191d205, UI061ccbd808f3ec8d112ff3c9e8331dac151a7e98, guide1b51800344f96785d229fc4ccf8795c58089e3b1 and deck parser f0f8a4b234489c2388f427633f548d56c6ed4c03. No new candidate or author test has been received.
Original computeTrace uses three states and integer percentages, with row-current/column-next contributions. Use exact N2 bridges p3/4 and p1/2, not a rounded2/3 unsupported by that API. Original preset and no-normalization semantics are not changed. Original native deck parsing and existing learner chooser/preview/explicit Start provide the consumer boundary; any inability to launch original browser is retained as a runtime admission failure, not invented product proof.

## Mathematical oracle
New analyzeWalk inputs are exactly upper,start,rightNumerator,rightDenominator,horizon; finite integers, N2..8,i0..N,b1..12,a0..b,H0..30. Preserve entered a,b; fractions normalize separately. Refuse coercion, missing/unknown fields, array/nonobject, nonfinite/fractional/out-of-range values.
The independent reference uses weighted enumeration of every finite direction word for chosen H<=8, retaining the full path and first endpoint hitting time. It computes marginal state masses, first-hit/cumulative/survival and E[min(T,H)] by summing exact integer word weights, not candidate recurrence code. Eventual probabilities and means are solved independently as rational linear boundary equations, not copied from the author's closed-form implementation.
For the long-tail case N3,start1,p1/2,H30, derive survival2^-t, internal position1 at even t/2 at odd t, first-left2^-t only at odd positive t and first-right2^-t only at even positive t. E[min(T,t)]=2*(1-2^-t), excess2^(1-t). Boundary start T0 is handled separately.
All expected fractions are reduced signed numerator/positive denominator decimal strings, zero0/1. All probabilities nonnegative; expected values nonnegative; no binary64 decision/tolerance or sampled outcomes serve as exact expected data.

## Hand-fixed examples
- N2,start1,p2/3,H3: step0[0,1,0]; step1 and all later[1/3,0,2/3]. First-hit masses step1 left1/3,right2/3; all later zero. Survival1 at0, then0. E[T]=1; truncated0 then1; excess1 then0.
- N3,start1,p1/2,H4: distributions [0,1,0,0], [1/2,0,1/2,0], [1/2,1/4,0,1/4], [5/8,0,1/8,1/4], [5/8,1/16,0,5/16]. First-left1/2 at1 and1/8 at3; first-right1/4 at2 and1/16 at4. Survival1,1/2,1/4,1/8,1/16. Truncated0,1,3/2,7/4,15/8; eventual mean2; excess2,1,1/2,1/4,1/8.
- N4,start2,p2/3,H4: eventual upper4/5,lower1/5,mean18/5. Eventual upper by starting state[0,8/15,4/5,14/15,1]; means[0,17/5,18/5,11/5,0]. At2 distribution[1/9,0,4/9,0,4/9], first-hit1/9 and4/9. At4 distribution[13/81,0,16/81,0,52/81], first-hit4/81 and16/81. Truncated at4 is26/9, excess32/45. Reverse bias p1/3 swaps boundaries, retaining mean at center.
- Entered4/6 yields the same probabilities as2/3 while retaining4 and6 in input.
- N5,start2,p1: deterministic positions2,3,4,5 then5; T3. p0 reaches0 at2. Endpoint starts always T0, including the endpoint opposite deterministic motion.
- N8,start0,p7/12: first-left1 exactly at0, then no first hits; all mass remains0 and all time expectations0.
- H0 retains one complete initial frame and all eventual results. N8,start3,p3/4 exercises rational equations with no finite transitions.
- N3 fair H30 retains a strictly positive survival1/1073741824 and excess1/536870912; never call this already fully absorbed.

## Complete output predicates
For frames0..H, distributions have N+1 states summing exactly1. End masses equal cumulative corresponding first hits. Survival equals interior mass and1 minus cumulative total. Truncated expectation sums prior survival; eventual mean minus truncated is the reported unconditional expected excess, not a conditional residual time.
Step0 has no contributions. Every later frame has exactly2+2*(N-1) edges: self0, each interior left then right, selfN in ascending source order. Include zero contributions. Edge probabilities are1 at boundaries and q/p inside. Mass equals previous state mass times edge probability, and destination sums reconstruct next distribution.
All eventual rows satisfy both endpoint conditions and interior probability/time recurrences. Fair and deterministic cases are included explicitly. Fractions must be reduced with positive denominators, never '-0', leading sign-plus, scientific notation or NaN.

## Native consumer predicates
Use actual Apply, preset and step controls against exact mathematical fixtures. Editing retires both result and experiment export immediately; invalid Apply cannot export stale output. Valid Apply/preset selects0. First/Previous/Next/Last and selected step preserve applied inputs and expose all frames. Exact displayed fractions and text table must agree with saved analysis; no horizontal page overflow at390px.
Real experiment download is strict JSON with final LF, complete exact analysis and selectedStep. Dirty/invalid controls cannot leak an old result into that download. Course and guide downloads retain exact fixed source bytes before/after experimental edits.
Open a copied-alone offline lab with network requests blocked; retain actual downloads. Import the downloaded course bytes into original learner using real chooser → preview → explicit Start, then ordinary learner/review/practice and a real study-notes download. No substituted deck, mocked DOM, author test expected answer, automatic storage, external provider or generated screenshot stands in for the consumer.
Before reading each new course answer/explanation, independently solve its visible prompt/options from the frozen mathematical model; record semantic correctness and transfer/explanation review separately from schema validation. Candidate API key/selector binding may be adapted after admission without changing mathematical/UI predicates.

## Native custody
Own namespace D:/Hamon/receiving/recall-absorbing-walk-db371a37f4c8 on MSI route9ea77fe9-bb87-46e0-a5a8-8b3e25f6ff7e, observed MSI\\Veria. Existing Node/Edge only, no install. Fresh admission03:52:46 saw C:1122807808B,D:400062308352B,available memory5688733696B. Before browser launches keep1GiB C:,256MiB D:,2GiB memory floors; own D: profile/TEMP/output. Coordinate one native UI/browser window, preserve failed attempts, exact original/candidate before/after hashes, and observed process/profile closure. No ref/PR/Actions/merge mutation.
