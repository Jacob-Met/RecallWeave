import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
source = root / 'source'
expected = {item['path']: item for item in json.loads((root / 'input-manifest.json').read_text())['entries']}
records = json.loads(sys.argv[1])
pins = []
for item in records:
    want = expected[item['path']]
    data = item['content'].encode('utf-8')
    sha = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert sha == item['sha'] == want['sha'], item['path']
    assert len(data) == want['size'], item['path']
    written = subprocess.check_output(['git', 'hash-object', '-w', '--stdin'], cwd=source, input=data).decode().strip()
    assert written == sha
    pin = {'path': item['path'], 'gitBlob': sha, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    pins.append(pin)
    with (root / 'imported-native-blobs.jsonl').open('a') as stream:
        stream.write(json.dumps(pin, sort_keys=True) + '\n')
print(json.dumps({'imported': pins}))
