import json
from fractions import Fraction
names=["A∩B","A∩notB","notA∩B","neither"]
qs=[
("joint_A_B",[0],[0,1,2,3]),("joint_A_notB",[1],[0,1,2,3]),
("joint_notA_B",[2],[0,1,2,3]),("joint_neither",[3],[0,1,2,3]),
("marginal_A",[0,1],[0,1,2,3]),("marginal_notA",[2,3],[0,1,2,3]),
("marginal_B",[0,2],[0,1,2,3]),("marginal_notB",[1,3],[0,1,2,3]),
("A_given_B",[0],[0,2]),("notA_given_B",[2],[0,2]),
("A_given_notB",[1],[1,3]),("notA_given_notB",[3],[1,3]),
("B_given_A",[0],[0,1]),("notB_given_A",[1],[0,1]),
("B_given_notA",[2],[2,3]),("notB_given_notA",[3],[2,3])]
tables=[
("fictional_default",[9,1,99,891]),
("uniform_independent",[1,1,1,1]),
("nonuniform_independent",[2,3,4,6]),
("mutually_exclusive_positive",[0,1,1,0]),
("perfect_association",[1,0,0,1]),
("empty_table",[0,0,0,0]),
("A_empty",[0,0,2,3]),("B_empty",[0,2,0,3]),
("A_certain",[2,3,0,0]),("B_certain",[2,0,3,0]),
("only_neither",[0,0,0,7]),("only_both",[7,0,0,0]),
("only_A_notB",[0,7,0,0]),("only_notA_B",[0,0,7,0]),
("one_zero_cell",[3,0,2,5]),
("prime_total",[1,2,3,5]),
("near_independent_exactly_false",[889,890,890,891]),
("default_transpose",[9,99,1,891]),
("default_complement_A",[99,891,9,1]),
("default_complement_B",[1,9,891,99]),
("independent_scaled_by_7",[14,21,28,42]),
("dependent_scaled_by_7",[7,14,21,35])]
def exact(n,d):
 if not d:return None
 f=Fraction(n,d);return str(f.numerator)+"/"+str(f.denominator)
out={"receiver_schema":"semantic-table-oracles-v1","purpose":"Independent mathematical fixture schema; no product API is assumed.","cell_order":names,"queries":[{"id":q,"numerator_cells":a,"denominator_cells":b} for q,a,b in qs],"tables":[]}
for label,c in tables:
 x,y,z,w=c;n=sum(c)
 probabilities=[exact(sum(c[i] for i in a),sum(c[i] for i in b)) for _,a,b in qs]
 independent=None if not n else Fraction(x,n)==Fraction(x+y,n)*Fraction(x+z,n)
 determinant=x*w-y*z
 if n:assert independent==(determinant==0)
 out["tables"].append({"id":label,"counts":list(map(str,c)),"total":str(n),"probabilities":probabilities,"independent":independent,"identity_left":None if not n else str(x*n),"identity_right":None if not n else str((x+y)*(x+z)),"determinant":None if not n else str(determinant)})
assert out["tables"][0]["probabilities"]==["9/1000","1/1000","99/1000","891/1000","1/100","99/100","27/250","223/250","1/12","11/12","1/892","891/892","9/10","1/10","1/10","9/10"]
assert out["tables"][5]["probabilities"]==[None]*16
assert out["tables"][6]["independent"] is True and out["tables"][6]["probabilities"][12] is None
assert out["tables"][16]["independent"] is False and out["tables"][16]["determinant"]=="-1"
print(json.dumps(out,ensure_ascii=False,separators=(",",":")))
