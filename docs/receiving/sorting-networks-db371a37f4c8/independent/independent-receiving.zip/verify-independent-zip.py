import sys,json,zipfile,hashlib,pathlib,os
root=pathlib.Path(sys.argv[1])
manifest=json.loads((root/"independent-sealed"/"SEALED-MANIFEST.json").read_text(encoding="utf-8"))
archive=root/"independent-sealed"/"independent-receiving.zip"
with zipfile.ZipFile(archive) as z:
    infos=z.infolist()
    expected={row["path"]:row for row in manifest["files"]}
    assert len(infos)==len(expected)+1
    assert len(set(i.filename.casefold() for i in infos))==len(infos)
    assert set(i.filename for i in infos)==set(expected)|{"SEALED-MANIFEST.json"}
    assert z.testzip() is None
    total=0
    for item in infos:
        data=z.read(item)
        assert not item.is_dir() and item.compress_type==zipfile.ZIP_DEFLATED
        assert data==(root/"independent-sealed"/"SEALED-MANIFEST.json").read_bytes() if item.filename=="SEALED-MANIFEST.json" else data==(root/item.filename).read_bytes()
        if item.filename in expected:
            row=expected[item.filename]
            assert len(data)==row["bytes"] and hashlib.sha256(data).hexdigest()==row["sha256"]
            assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==row["git"]
            total+=len(data)
print(json.dumps({"status":"passed","pid":os.getpid(),"python":sys.version,"members":len(infos),"payloadFiles":len(expected),"payloadBytes":total,"crcAllPassed":True,"wholeMemberBytesExact":True}))
