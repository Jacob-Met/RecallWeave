import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

/** New-course receiving over the unchanged native learner and its real downloaded files. */
export async function receiveLearner(api, courseFile, urls) {
  const { root, report, evaluate, activate, key, waitFor, chooseFile, download, capture, passed, navigate, fill } = api;
  const { parseDeck } = await import(pathToFileURL(join(root, 'src/deck.mjs')));
  const { initialMastery, updateMastery } = await import(pathToFileURL(join(root, 'src/knowledge.mjs')));
  const { readTraceArchive } = await import(pathToFileURL(join(root, 'src/trace-archive.mjs')));
  const courseBytes = await readFile(courseFile);
  const deck = parseDeck(courseBytes.toString('utf8'));
  assert.equal(deck.items.length, 12);
  assert.equal(deck.concepts.length, 4);
  const firstRuns = [];
  const noteText = 'The remainder preserves a common divisor.\nI can check the integer combination: 252 × 4 − 198 × 5 = 18. < & >';
  const applicationText = 'A smaller divisor connects each division to termination.\nMy explanation is a reflection, not another scored answer.';

  async function firstState() {
    return evaluate("({summary:document.querySelector('#first-try-summary')?.textContent??null,"
      + "estimates:[...document.querySelectorAll('.mastery-box output')].map(e=>e.textContent),"
      + "rows:[...document.querySelectorAll('.review-item')].map(e=>({prompt:e.querySelector('.review-prompt').textContent,"
      + "first:e.querySelectorAll('.review-answers dd')[0].textContent,correct:e.querySelectorAll('.review-answers dd')[1].textContent,"
      + "explanation:e.querySelector('.review-body > p').textContent,transfer:e.querySelector('.review-transfer').textContent})),"
      + "progress:document.querySelector('[role=progressbar]').getAttribute('aria-valuenow')})");
  }
  async function openArchive() {
    if (!await evaluate("document.querySelector('#trace-archive-panel').open")) await activate('#trace-archive-panel > summary');
  }
  async function loadCourse(label) {
    const original = await evaluate("({progress:document.querySelector('#step-count').textContent,session:document.querySelector('#session-content').innerHTML,title:document.title})");
    await chooseFile('#deck-file', courseFile);
    await waitFor(() => evaluate("!document.querySelector('#deck-preview').hidden"), 'course preview');
    const preview = await evaluate("({title:document.querySelector('#deck-preview-title').textContent,count:document.querySelector('.deck-preview-count').textContent,"
      + "attribution:document.querySelector('.deck-preview-attribution').textContent,license:document.querySelector('.deck-preview-license').textContent,"
      + "prompts:[...document.querySelectorAll('.deck-questions strong')].map(e=>e.textContent),focus:document.activeElement.id})");
    assert.equal(preview.title, deck.title);
    assert.ok(preview.count.includes('12 questions · 4 concepts'));
    assert.ok(preview.attribution.endsWith(deck.attribution));
    assert.ok(preview.license.endsWith(deck.license));
    assert.deepEqual(preview.prompts, deck.items.map(x=>x.prompt));
    assert.equal(preview.focus, 'deck-preview-title');
    assert.deepEqual(await evaluate("({progress:document.querySelector('#step-count').textContent,session:document.querySelector('#session-content').innerHTML,title:document.title})"), original);
    await api.tabTo('#start-deck');
    await key('Enter');
    await waitFor(() => evaluate("!!document.querySelector('.question-card h2')"), 'explicit imported course start');
    assert.equal(await evaluate("document.querySelector('#step-count').textContent"), '0 / 12');
    assert.equal(await evaluate("document.title"), deck.title + ' — RecallWeave');
    assert.deepEqual(await evaluate("[...document.querySelectorAll('#lesson-map .deck-concept')].map(e=>e.textContent)"), deck.concepts);
    report.learnerPreviews.push({label, preview, original});
  }
  async function saveArchive(label, expectedAnswers, expectedMastery) {
    await openArchive();
    const before = await firstState();
    const file = await download('#save-trace-button', label + '.json');
    assert.match(file.suggestedFilename, /^recallweave-learning-trace-\d{4}-\d{2}-\d{2}\.json$/);
    const document = JSON.parse(file.bytes.toString('utf8'));
    const restored = readTraceArchive(file.bytes.toString('utf8'), deck);
    assert.deepEqual(document.deck, deck);
    assert.deepEqual(document.firstAnswers, expectedAnswers);
    assert.deepEqual(document.mastery, expectedMastery);
    assert.equal(restored.summary.correctFirst, 10);
    assert.deepEqual(await firstState(), before);
    return {...file, document, restored};
  }
  async function receiveNotes(label, state, firstAnswers, completed) {
    const file = await download('#save-notes-button', label + '.txt');
    assert.match(file.suggestedFilename, /^recallweave-study-notes-\d{4}-\d{2}-\d{2}\.txt$/);
    const text = new TextDecoder('utf-8', {fatal:true}).decode(file.bytes);
    assert.ok(text.includes(deck.title));
    assert.ok(text.includes('10 of 12 connections correct on the first try.'));
    assert.ok(text.includes('ESTIMATED MASTERY — MODEL STATE, NOT A GRADE'));
    assert.ok(text.includes(completed ? 'Complete: 2 of 2 practice answers recorded; 2 correct on retry.' : 'Paused: 1 of 2 practice answers recorded; 1 correct on retry.'));
    assert.ok(text.includes(deck.attribution));
    assert.ok(text.includes(deck.license));
    for (const answer of firstAnswers) {
      const item = deck.items.find(x=>x.id===answer.item);
      assert.ok(text.includes(item.prompt));
      assert.ok(text.includes('Your first answer: ' + item.options[answer.choice]));
      assert.ok(text.includes('Correct answer: ' + item.options[item.answer]));
      assert.ok(text.includes('Explanation: ' + item.explanation));
      assert.ok(text.includes('Apply the idea: ' + item.transfer));
    }
    for (const line of noteText.split('\n')) assert.ok(text.includes('  > ' + line));
    for (const line of applicationText.split('\n')) assert.ok(text.includes('  > ' + line));
    assert.deepEqual(await firstState(), state);
    return file;
  }

  report.learnerPreviews = [];
  report.learnerRuns = [];
  for (const {label, url, width, height} of urls) {
    await navigate(url, width, height, '#start-button');
    await waitFor(() => evaluate("!!document.querySelector('#trace-archive-panel')"), 'native learner initialization');
    await loadCourse(label);
    passed(label + ': actual downloaded course previews all 12 prompts and 4 concepts, then starts only explicitly');
    const answers = [];
    const expectedMastery = initialMastery(deck.concepts);
    const optionOrders = new Map();
    const seen = new Set();
    for (let index=0; index<12; index++) {
      const visible = await evaluate("({prompt:document.querySelector('.question-card h2').textContent,choices:[...document.querySelectorAll('[data-choice]')].map(e=>({canonical:Number(e.dataset.choice),text:e.textContent.slice(1)}))})");
      const item = deck.items.find(x=>x.prompt===visible.prompt);
      assert.ok(item, 'Visible question must be from exact downloaded course');
      assert.ok(!seen.has(item.id), 'Each first-session question appears once');
      seen.add(item.id);
      assert.deepEqual([...visible.choices.map(x=>x.canonical)].sort((a,b)=>a-b), item.options.map((_,i)=>i));
      for (const choice of visible.choices) assert.equal(choice.text, item.options[choice.canonical]);
      optionOrders.set(item.id, visible.choices.map(x=>x.canonical));
      const correct = index!==1 && index!==7;
      const choice = correct ? item.answer : (item.answer+1)%item.options.length;
      await activate('[data-choice="' + choice + '"]');
      assert.equal(await evaluate('document.activeElement.id'), 'next-button');
      const feedback = await evaluate("document.querySelector('#feedback-slot').textContent");
      assert.ok(feedback.includes(item.explanation));
      assert.ok(feedback.includes(item.transfer));
      answers.push({item:item.id, choice});
      expectedMastery[item.concept] = updateMastery(expectedMastery[item.concept], correct);
      if (index===0) {
        assert.equal(await evaluate('document.documentElement.scrollWidth > innerWidth'), false);
        await capture(label + '-first-question.png', '.question-card');
      }
      await key('Enter');
    }
    const initialState = await firstState();
    assert.ok(initialState.summary.includes('10 of 12'));
    assert.equal(initialState.progress, '12');
    assert.deepEqual(initialState.estimates, deck.concepts.map(c=>Math.round(expectedMastery[c]*100)+'%'));
    assert.equal(initialState.rows.length, 12);
    for (let index=0; index<12; index++) {
      const answer=answers[index], item=deck.items.find(x=>x.id===answer.item);
      assert.deepEqual(initialState.rows[index], {prompt:item.prompt,first:item.options[answer.choice],correct:item.options[item.answer],explanation:item.explanation,transfer:'Apply the idea: '+item.transfer});
    }
    const initial = await saveArchive(label + '-first-trace', answers, expectedMastery);
    assert.equal(initial.document.practice, null);
    const missed=initial.restored.review.filter(x=>!x.correct);
    assert.equal(missed.length,2);
    passed(label + ': 12 canonical first answers, two deliberate misses, exact explanations and full precision native model archive');

    await activate('.review-item > summary');
    await fill('#reflection-0', noteText);
    await fill('#application-reflection', applicationText);
    assert.deepEqual(await firstState(), initialState);
    await activate('#practice-button');
    assert.equal(await evaluate("document.querySelector('.question-card h2').textContent"), missed[0].prompt);
    assert.deepEqual(await evaluate("[...document.querySelectorAll('[data-practice-choice]')].map(e=>Number(e.dataset.practiceChoice))"), optionOrders.get(missed[0].id));
    await activate('[data-practice-choice="'+missed[0].answer+'"]');
    await activate('#back-to-review');
    assert.deepEqual(await firstState(), initialState);
    assert.ok((await evaluate("document.querySelector('#practice-status').textContent")).includes('1 of 2'));
    const paused = await saveArchive(label + '-paused-trace', answers, expectedMastery);
    assert.deepEqual(paused.document.practice.answers,[{item:missed[0].id,choice:missed[0].answer}]);
    await receiveNotes(label + '-paused-notes', initialState, answers, false);
    passed(label + ': one practice answer pauses separately; actual notes retain all original answers, attribution and multiline writing');

    await activate('#practice-button');
    assert.equal(await evaluate("document.querySelector('.question-card h2').textContent"), missed[1].prompt);
    assert.deepEqual(await evaluate("[...document.querySelectorAll('[data-practice-choice]')].map(e=>Number(e.dataset.practiceChoice))"), optionOrders.get(missed[1].id));
    await activate('[data-practice-choice="'+missed[1].answer+'"]');
    await activate('#practice-next');
    assert.deepEqual(await firstState(), initialState);
    const complete=await saveArchive(label+'-complete-trace',answers,expectedMastery);
    assert.deepEqual(complete.document.practice.answers,missed.map(x=>({item:x.id,choice:x.answer})));
    assert.deepEqual(complete.document.firstAnswers,initial.document.firstAnswers);
    assert.deepEqual(complete.document.mastery,initial.document.mastery);
    await receiveNotes(label+'-complete-notes',initialState,answers,true);
    assert.equal(await evaluate("document.documentElement.scrollWidth > innerWidth"),false);
    await capture(label+'-completed-trace.png','.result-card');
    passed(label + ': resume answers only the remaining miss; completed practice preserves exact first trace and estimates');
    report.learnerRuns.push({label,url,width,height,firstAnswers:answers,mastery:expectedMastery,initialState,initialArchive:initial.name,pausedArchive:paused.name,completeArchive:complete.name,optionOrders:Object.fromEntries(optionOrders)});
    firstRuns.push({label,firstAnswers:answers,mastery:expectedMastery,complete});
  }
  if(firstRuns.length===2){
    assert.deepEqual(firstRuns[1].firstAnswers, firstRuns[0].firstAnswers);
    assert.deepEqual(firstRuns[1].mastery, firstRuns[0].mastery);
    passed('modular and direct-file learners preserve the same canonical answer trace and full precision estimates despite independently shuffled options');
  }else if(api.priorStandalone){
    const prior=api.priorStandalone.learnerRuns[0];
    assert.deepEqual(firstRuns[0].firstAnswers,prior.firstAnswers);
    assert.deepEqual(firstRuns[0].mastery,prior.mastery);
    report.crossSurfaceComparison={priorLabel:prior.label,canonicalFirstAnswersEqual:true,fullPrecisionMasteryEqual:true};
    passed('actual modular first answers and full precision estimates equal the preserved completed direct-file journey');
  }else{
    report.crossSurfaceComparison='Pending native HTTP browser transport; this execution receives the direct-file learner only.';
  }
  const target=api.restoreTarget??urls.at(-1);
  await navigate(target.url,390,844,'#start-button');
  await waitFor(()=>evaluate("!!document.querySelector('#trace-archive-panel')"),'fresh direct-file trace controls');
  await loadCourse('fresh-direct-file-restore');
  await openArchive();
  const questionBefore=await evaluate("({prompt:document.querySelector('.question-card h2').textContent,progress:document.querySelector('#step-count').textContent})");
  await chooseFile('#trace-file',firstRuns[0].complete.path);
  await waitFor(()=>evaluate("!document.querySelector('#trace-preview').hidden"),'cross-surface trace preview');
  assert.ok((await evaluate("document.querySelector('#trace-preview-summary').textContent")).includes('10 of 12'));
  assert.deepEqual(await evaluate("({prompt:document.querySelector('.question-card h2').textContent,progress:document.querySelector('#step-count').textContent})"),questionBefore);
  await activate('#restore-trace-cancel');
  assert.deepEqual(await evaluate("({prompt:document.querySelector('.question-card h2').textContent,progress:document.querySelector('#step-count').textContent})"),questionBefore);
  await chooseFile('#trace-file',firstRuns[0].complete.path);
  await waitFor(()=>evaluate("!document.querySelector('#trace-preview').hidden"),'renewed trace preview');
  await activate('#restore-trace-confirm');
  assert.equal(await evaluate("document.querySelectorAll('.review-item').length"),12);
  const restored=await saveArchive('fresh-direct-file-restored-trace',firstRuns[0].firstAnswers,firstRuns[0].mastery);
  assert.deepEqual(restored.document.practice,firstRuns[0].complete.document.practice);
  assert.equal(await evaluate("document.querySelector('#reflection-0').value"),'');
  assert.equal(await evaluate("document.querySelector('#application-reflection').value"),'');
  report.restored={firstAnswers:restored.document.firstAnswers,mastery:restored.document.mastery,practice:restored.document.practice};
  passed('real completed archive reopens in a fresh direct-file course only after preview/confirmation; cancel preserves the unanswered lesson and reflections remain outside the archive');
  return {courseFile, firstRuns:firstRuns.map(({label,firstAnswers,mastery})=>({label,firstAnswers,mastery}))};
}
