# Independent damped-motion receiving expectations

This packet was authored before receiving the implementation or its authored tests. It is a mathematical fixture oracle, not product execution. All parameters are within the supplied educational domain.

Let omega=sqrt(k/m), alpha=b/m=2*zeta*omega, and beta=k/m. With y=(x,v), the equation is y'=A y where A=[[0,1],[-beta,-alpha]]. Thus y(t)=sum(n>=0) t^n A^n y(0)/n!. The generator accumulates this series directly with Decimal arithmetic at both 100 and 150 digits. It contains no under/critical/over branch and no product imports. Successive terms are obtained by matrix multiplication; reference values agree at the declared precision and selected cases also agree with elementary exponential formulas.

For zeta<1, set wd=omega*sqrt(1-zeta^2). Then x=e^(-zeta*omega*t)[x0*cos(wd*t)+(v0+zeta*omega*x0)*sin(wd*t)/wd]. At zeta=1, x=e^(-omega*t)[x0+(v0+omega*x0)t]. For zeta>1, the two real roots are -zeta*omega +/- omega*sqrt(zeta^2-1), with coefficients determined by x0 and v0. These formulas establish the regimes, but the independent numerical values use the branch-free series. Near-critical continuity follows from sin(wd*t)/wd tending to t and from the corresponding real-root limit; the entered regime must still be labelled by exact comparison with 1.

For m=k=1 and zeta=1, x0=1,v0=-2 gives x=(1-t)e^-t: a genuine crossing at t=1. For zeta=1.25, x0=.5,v0=-2 gives x=-(2/3)e^(-t/2)+(7/6)e^(-2t), crossing at (2/3)ln(7/4). The latter is positive at .25 and negative at .5. Therefore arbitrary critical/overdamped initial conditions cannot be taught as never crossing zero.

E=(m*v^2+k*x^2)/2. Differentiating and substituting the equation gives E'=v*(m*x''+k*x)=-b*v^2. Energy is nonnegative, nonincreasing with nonnegative damping, and constant at zero damping. It need not decrease strictly at every instant: v=0 makes the instantaneous derivative zero. The rest solution x0=v0=0 is exactly invariant.

Scaling m and k by the same factor scales b by that factor and leaves alpha,beta unchanged, so the trajectory is unchanged. Energy and dissipation power scale with the factor.

The JSON freezes thirteen parameter cases in ten conceptual groups: undamped/under/critical/over trajectories, two adverse-velocity crossings, the three near-critical labels and values, a bounded fast-decay case, exact rest, and a matched parameter-scaling pair. It retains high-precision reference strings and explicit binary64 fixture tolerances. This tolerance is intended for these fixtures, not a proven global error bound or an apparatus/clinical claim.
