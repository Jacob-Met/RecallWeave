import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
const R=process.argv[2],E=process.argv[3],P=path.join(R,'portable-r2','unpacked');
const {chromium}=await import('file:///D:/Hamon/receiving/pneumatic-goals-root-db371a37f4c8/dependencies/node_modules/playwright/index.mjs');
const course=JSON.parse(fs.readFileSync(path.join(P,'courses/genotype-counts.json'),'utf8'));
const receipt={started:new Date().toISOString(),node:process.version,pid:process.pid,groups:[],errors:[],remoteRequests:[],checks:0};
function save(){fs.writeFileSync(path.join(E,'driver-receipt.json'),JSON.stringify(receipt,null,2)+'\n');}
function check(value,label){assert.ok(value,label);receipt.checks++;}
function pin(p){const b=fs.readFileSync(p);return {bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')};}
async function group(name,run){receipt.active=name;save();await run();receipt.groups.push(name);delete receipt.active;save();}
let browser;
try{
 browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true,chromiumSandbox:true,timeout:45000});
 const cdp=await browser.newBrowserCDPSession();receipt.browserVersion=await cdp.send('Browser.getVersion');
 receipt.initialProcesses=await cdp.send('SystemInfo.getProcessInfo');save();
 const context=await browser.newContext({viewport:{width:1280,height:960},acceptDownloads:true});
 context.on('page',p=>{p.on('pageerror',e=>receipt.errors.push(String(e)));p.on('request',r=>{if(/^https?:/.test(r.url()))receipt.remoteRequests.push(r.url());});});
 const learner=await context.newPage();
 learner.setDefaultTimeout(10000);
 await group('actual portable course preview and explicit start',async()=>{
  await learner.goto(pathToFileURL(path.join(P,'demo.html')).href);
  const ready=await learner.locator('#session-content').innerText();
  check(ready.includes('What do you already know?'),'original welcome');
  await learner.locator('#deck-file').setInputFiles(path.join(P,'courses/genotype-counts.json'));
  await learner.getByRole('button',{name:'Start this deck',exact:true}).waitFor();
  check((await learner.locator('#deck-preview').innerText()).includes(course.title),'actual preview title');
  check(await learner.locator('#session-content').innerText()===ready,'preview does not start/change session');
  await learner.getByRole('button',{name:'Start this deck',exact:true}).click();
  await learner.locator('.question-card h2').waitFor();
 });
 const visited=[],answers=[];
 await group('fourteen actual choices and complete exact feedback',async()=>{
  for(let i=0;i<14;i++){
   const prompt=await learner.locator('.question-card h2').innerText();
   const item=course.items.find(q=>q.prompt===prompt);check(!!item,'prompt identifies exact authored item');check(!visited.includes(item.id),'one first answer per item');
   visited.push(item.id);
   const choice=item.id==='gc-compare-3'?0:item.answer;
   check((await learner.locator('[data-choice="'+choice+'"]').innerText()).endsWith(item.options[choice]),'actual selected option text');
   await learner.locator('[data-choice="'+choice+'"]').click();
   const feedback=await learner.locator('#feedback-slot').innerText();
   check(feedback.includes(item.explanation)&&feedback.includes(item.transfer),'full explanation and transfer visible');
   check(feedback.includes(item.options[item.answer]),'correct answer text visible');
   answers.push({id:item.id,choice,correct:choice===item.answer});
   await learner.locator('#next-button').click();
  }
  check(new Set(visited).size===14,'all fourteen unique');
  check((await learner.locator('#first-try-summary').innerText()).includes('13 of 14'),'first try13/14');
  check(await learner.locator('.review-item').count()===14,'review has fourteen items');
  receipt.answers=answers;
 });
 await group('separate missed-item practice and actual study-notes file',async()=>{
  await learner.locator('#practice-button').click();
  const missed=course.items.find(x=>x.id==='gc-compare-3');
  check(await learner.locator('.practice-card h2').innerText()===missed.prompt,'only deliberately missed item');
  await learner.locator('[data-practice-choice="'+missed.answer+'"]').click();
  check((await learner.locator('#practice-feedback').innerText()).includes(missed.explanation),'complete retry explanation');
  await learner.locator('#practice-next').click();
  check((await learner.locator('#practice-status').innerText()).includes('1 of 1 correctly'),'practice1/1');
  check((await learner.locator('#first-try-summary').innerText()).includes('13 of 14'),'first attempt preserved after practice');
  const downloadPromise=learner.waitForEvent('download');
  await learner.locator('#save-notes-button').click();
  const download=await downloadPromise;
  const target=path.join(E,'actual-study-notes.txt');await download.saveAs(target);check(await download.failure()===null,'physical notes download');
  const notes=fs.readFileSync(target,'utf8');
  for(const item of course.items){check(notes.includes(item.prompt)&&notes.includes(item.explanation)&&notes.includes(item.transfer),'notes complete '+item.id);}
  check(notes.includes(missed.options[0])&&notes.includes(missed.options[missed.answer]),'notes retain original wrong and correct answer');
  receipt.notes={suggestedFilename:download.suggestedFilename(),path:target,...pin(target)};
 });
 const worksheet=await context.newPage();
 await group('actual static worksheet ordinary width and browser print',async()=>{
  await worksheet.goto(pathToFileURL(path.join(P,'courses/genotype-counts-worksheet.html')).href);
  check(await worksheet.locator('.case').count()===6,'six original tables');
  check(await worksheet.locator('script,input,textarea,form').count()===0,'unanswered static page');
  check(await worksheet.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'ordinary page no horizontal overflow');
  receipt.ordinaryGeometry=await worksheet.locator('.case').evaluateAll(es=>es.map(e=>({id:e.id,x:e.getBoundingClientRect().x,width:e.getBoundingClientRect().width})));
  const pdf=path.join(E,'worksheet-A4.pdf');
  await worksheet.pdf({path:pdf,preferCSSPageSize:true,printBackground:true});
  check(fs.readFileSync(pdf).subarray(0,5).toString()==='%PDF-','actual browser PDF');
  receipt.print={path:pdf,...pin(pdf)};
 });
 const phone=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,isMobile:true,hasTouch:true});
 phone.on('page',p=>{p.on('pageerror',e=>receipt.errors.push(String(e)));p.on('request',r=>{if(/^https?:/.test(r.url()))receipt.remoteRequests.push(r.url());});});
 const phonePage=await phone.newPage();
 await group('phone worksheet complete table and companion links',async()=>{
  await phonePage.goto(pathToFileURL(path.join(P,'courses/genotype-counts-worksheet.html')).href);
  check(await phonePage.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'phone no horizontal overflow');
  for(const id of ['g1','g2','g3','g4','g5','g6']){
   const card=phonePage.locator('#'+id);await card.scrollIntoViewIfNeeded();
   const g=await card.boundingBox();check(g.x>=0&&g.x+g.width<=391,'phone card fits '+id);
   check(await card.locator('tbody tr').count()===6,'six writing rows '+id);
  }
  for(const href of ['genotype-counts.json','genotype-counts.md','../demo.html']){
   check(await phonePage.locator('a[href="'+href+'"]').count()===1,'companion link '+href);
  }
  receipt.phoneGeometry=await phonePage.locator('.case').evaluateAll(es=>es.map(e=>({id:e.id,x:e.getBoundingClientRect().x,width:e.getBoundingClientRect().width})));
 });
 check(receipt.errors.length===0,'no page exception');check(receipt.remoteRequests.length===0,'no remote request');
 receipt.behaviorCompleteAt=new Date().toISOString();save();
 await group('photography after all behavior assertions',async()=>{
  await learner.locator('#first-try-summary').scrollIntoViewIfNeeded();await learner.screenshot({path:path.join(E,'learner-review.png')});
  await worksheet.evaluate(()=>scrollTo(0,0));await worksheet.screenshot({path:path.join(E,'worksheet-desktop.png')});
  await phonePage.locator('#g2').scrollIntoViewIfNeeded();await phonePage.screenshot({path:path.join(E,'worksheet-phone.png')});
  receipt.images=['learner-review.png','worksheet-desktop.png','worksheet-phone.png'].map(name=>({name,...pin(path.join(E,name))}));
 });
 await phone.close();await context.close();
 receipt.status='passed';
}catch(e){receipt.status='failed';receipt.error=String(e);receipt.stack=e.stack;process.exitCode=1;}
finally{
 if(browser){try{await Promise.race([browser.close(),new Promise((_,reject)=>setTimeout(()=>reject(new Error('browser close exceeded15s')),15000))]);receipt.browserClosed=true;}catch(e){receipt.closeError=String(e);process.exitCode=1;}}
 receipt.finished=new Date().toISOString();save();console.log(JSON.stringify({status:receipt.status,groups:receipt.groups,checks:receipt.checks,pid:process.pid,browserClosed:receipt.browserClosed,error:receipt.error}));
}
