"""Distinct semantic controls for the SQL course's exact authored fixture.

These inspect intermediate NULL/aggregate/join facts instead of replaying the
course generator's twelve answer-equality checks. Only an in-memory database
is created; all SQL is retained in the resulting receipt.
"""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys


def main():
    source_path, receipt_path = map(Path, sys.argv[1:])
    source_bytes = source_path.read_bytes()
    source = json.loads(source_bytes)
    connection = sqlite3.connect(":memory:")
    connection.executescript(source["setup_sql"])
    cases = [
        (
            "null_truth_values_do_not_alias_zero",
            "SELECT id, value = NULL AS eq_null, value IS NULL AS is_null, "
            "value = 0 AS eq_zero FROM readings ORDER BY id;",
            [[1, None, 0, 0], [2, None, 1, None], [3, None, 0, 0],
             [4, None, 0, 0], [5, None, 0, 1], [6, None, 0, 0]],
        ),
        (
            "all_null_input_still_has_one_counted_row",
            "SELECT COUNT(*), COUNT(value), SUM(value), AVG(value) "
            "FROM readings WHERE value IS NULL;",
            [[1, 0, None, None]],
        ),
        (
            "empty_aggregate_input_has_no_counted_rows",
            "SELECT COUNT(*), COUNT(value), SUM(value), AVG(value) "
            "FROM readings WHERE id < 0;",
            [[0, 0, None, None]],
        ),
        (
            "joined_rows_readings_and_measurements_differ",
            "SELECT s.id, s.name, COUNT(*), COUNT(r.id), COUNT(r.value), "
            "SUM(r.value), AVG(r.value) FROM stations AS s "
            "LEFT JOIN readings AS r ON r.station_id = s.id "
            "GROUP BY s.id, s.name ORDER BY s.id;",
            [[1, "North", 2, 2, 1, 10, 10],
             [2, "South", 3, 3, 3, 40, 40 / 3],
             [3, "East", 1, 0, 0, None, None],
             [4, "West", 1, 0, 0, None, None]],
        ),
        (
            "on_high_threshold_preserves_all_left_rows",
            "SELECT s.name, r.id, r.value FROM stations AS s "
            "LEFT JOIN readings AS r ON r.station_id = s.id AND r.value >= 30 "
            "ORDER BY s.id, r.id;",
            [["North", None, None], ["South", None, None],
             ["East", None, None], ["West", None, None]],
        ),
        (
            "where_high_threshold_does_not_rescue_unmatched_reading",
            "SELECT s.name, r.id, r.value FROM stations AS s "
            "LEFT JOIN readings AS r ON r.station_id = s.id "
            "WHERE r.value >= 30 ORDER BY s.id, r.id;",
            [],
        ),
    ]
    observations = []
    for name, sql, expected in cases:
        cursor = connection.execute(sql)
        actual = [list(row) for row in cursor.fetchall()]
        observations.append({"name": name, "sql": sql,
            "columns": [c[0] for c in cursor.description],
            "expected": expected, "actual": actual, "passed": actual == expected})
    connection.close()
    receipt = {
        "source_sha256": hashlib.sha256(source_bytes).hexdigest(),
        "setup_sql_sha256": hashlib.sha256(source["setup_sql"].encode()).hexdigest(),
        "probe_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python": sys.version, "sqlite_version": sqlite3.sqlite_version,
        "database": ":memory:", "observations": observations,
        "passes": sum(o["passed"] for o in observations),
        "failures": sum(not o["passed"] for o in observations),
    }
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: v for k, v in receipt.items() if k != "observations"}, indent=2))
    return 0 if receipt["failures"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
