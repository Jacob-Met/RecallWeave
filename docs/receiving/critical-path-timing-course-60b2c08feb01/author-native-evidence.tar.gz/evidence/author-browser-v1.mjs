import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {validateDeck} from '../src/deck.mjs';
import {createReview,beginPractice,answerPractice} from '../src/review.mjs';
import {initialMastery,updateMastery} from '../src/knowledge.mjs';
import {createReflections,updateReflection,updateApplicationReflection} from '../src/reflections.mjs';
import {createStudyNotes} from '../src/session-export.mjs';
import {analyzeTiming} from '../src/dependency-timing.mjs';

const root=process.cwd(), out=resolve(root,'evidence/browser-first');
await mkdir(out,{recursive:true});
const expectedPins=JSON.parse(await readFile(resolve(root,'evidence/browser-source-pins.json'),'utf8'));
const digest=b=>({bytes:b.length,sha256:createHash('sha256').update(b).digest('hex'),gitBlob:createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex')});
async function sourcePins(){return Object.fromEntries(await Promise.all(Object.keys(expectedPins).map(async p=>[p,digest(await readFile(resolve(root,p)))])));}
const receipt={schema:'critical-path-course-author-browser/1',startedAt:new Date().toISOString(),command:'node evidence/author-browser-v1.mjs',node:process.version,coursePin:expectedPins['courses/critical-path-timing.json'],groups:[],requests:[],served:[],downloads:[],pageErrors:[],consoleErrors:[],storage:[],answers:[],practiceAnswers:[],timingCases:[],boundaries:['Actual unchanged self-contained file learner, course-specific journey only.','Native notes reference consumes observed first/practice answers; numerical course key also has separate blind receiving.','No hosted Actions, efficacy experiment, catalog modification or persistence/restore claim.']};
const deck=validateDeck(JSON.parse(await readFile(resolve(root,'courses/critical-path-timing.json'),'utf8')));
const misses=new Set(['ct-early-2','ct-slack-2','ct-critical-2','ct-change-2']);
let browser,context,page,companion;
let mastery=initialMastery(deck.concepts), reflections=createReflections(deck.items),practice=null;
const auditPending=[];
function observe(p){
 p.on('pageerror',e=>receipt.pageErrors.push({url:p.url(),message:e.message}));
 p.on('console',m=>{if(m.type()==='error')receipt.consoleErrors.push({url:p.url(),text:m.text()});});
 p.on('response',r=>{if(r.request().isNavigationRequest()) auditPending.push((async()=>receipt.served.push({url:r.url(),status:r.status(),...digest(await r.body())}))());});
}
async function persist(){receipt.endedAt=new Date().toISOString();await writeFile(join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');}
async function exactText(locator,expected){assert.equal(await locator.textContent(),expected);}
async function pressEnter(locator){await locator.focus();assert.equal(await locator.evaluate(el=>document.activeElement===el),true);await locator.press('Enter');}
async function downloadNotes(label){
 const [d]=await Promise.all([page.waitForEvent('download'),page.locator('#save-notes-button').click()]);
 const file=join(out,label+'.txt'); await d.saveAs(file);const b=await readFile(file),text=b.toString('utf8');
 const stamp=/^Saved: (.+)$/m.exec(text)?.[1];assert.ok(stamp,'Actual native Saved timestamp');
 const expected=createStudyNotes({deck,review:createReview(deck.items,receipt.answers),mastery,practice,reflections,exportedAt:new Date(stamp),conceptLabel:id=>id,applicationPrompt:'Choose one connection from this deck and explain how it relates to another idea in your own words.'});
 assert.equal(d.suggestedFilename(),expected.filename); assert.deepEqual(b,Buffer.from(expected.text));
 receipt.downloads.push({kind:label,filename:d.suggestedFilename(),savedTimestamp:stamp,exactNativeBytes:true,...digest(b)});
 return text;
}
async function cardIdentity(selector='[data-choice]'){
 const prompt=await page.locator('.question-card h2').textContent(),item=deck.items.find(x=>x.prompt===prompt);
 assert.ok(item,'Rendered prompt identifies exactly one admitted course item');
 assert.equal(deck.items.filter(x=>x.prompt===prompt).length,1);
 const choices=await page.locator(selector).evaluateAll(es=>es.map(el=>{const c=el.cloneNode(true);c.querySelector('.choice-key')?.remove();return {index:Number(el.getAttribute(el.hasAttribute('data-choice')?'data-choice':'data-practice-choice')),text:c.textContent.trim()};}));
 assert.equal(choices.length,4);assert.deepEqual(choices.map(x=>x.index).sort(),[0,1,2,3]);
 for(const choice of choices)assert.equal(choice.text,item.options[choice.index]);
 return item;
}
async function assertFeedback(slot,item){
 const text=await page.locator(slot).textContent();assert.ok(text.includes(item.explanation));assert.ok(text.includes(item.transfer));assert.ok(text.includes(item.options[item.answer]));
}
try{
 receipt.before=await sourcePins();for(const[p,v]of Object.entries(receipt.before))assert.equal(v.gitBlob,expectedPins[p],p);
 browser=await chromium.launch({executablePath:'/workspace/scratch/3e50c5ad22c5/production/browser/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 receipt.browser=browser.version();context=await browser.newContext({viewport:{width:1280,height:900},acceptDownloads:true});
 context.on('request',r=>receipt.requests.push({url:r.url(),method:r.method(),type:r.resourceType()}));
 await context.route(/^https?:/,route=>route.abort('blockedbyclient'));
 await context.addInitScript(()=>{
  globalThis.__courseStorageWrites=[];
  const original=Storage.prototype.setItem;
  Storage.prototype.setItem=function(...args){globalThis.__courseStorageWrites.push({kind:'storage-set',key:String(args[0])});return original.apply(this,args);};
  const db=IDBFactory.prototype.open;
  IDBFactory.prototype.open=function(...args){globalThis.__courseStorageWrites.push({kind:'indexeddb-open',name:String(args[0])});return db.apply(this,args);};
 });
 page=await context.newPage();observe(page);
 await page.goto(pathToFileURL(resolve(root,'demo.html')).href);
 assert.equal(await page.locator('.question-card').count(),0);
 await page.locator('#deck-file').setInputFiles(resolve(root,'courses/critical-path-timing.json'));
 await page.locator('#start-deck').waitFor({state:'visible'});
 await exactText(page.locator('#deck-preview-title'),deck.title);
 assert.match(await page.locator('.deck-preview-count').textContent(),/16 questions · 4 concepts/);
 const prompts=await page.locator('.deck-questions li').allTextContents();assert.deepEqual(prompts,deck.items.map(x=>x.prompt));
 assert.equal(await page.locator('.question-card').count(),0,'Preview must not start lesson');
 await pressEnter(page.locator('#start-deck'));
 assert.equal(await page.title(),deck.title+' — RecallWeave');
 receipt.groups.push({name:'Explicit file import, complete prompt preview, keyboard start',status:'pass'});
 for(let i=0;i<16;i++){
  const item=await cardIdentity();assert.ok(!receipt.answers.some(x=>x.item===item.id));
  const choice=misses.has(item.id)?(item.answer+1)%4:item.answer;
  if(i===4){await page.setViewportSize({width:375,height:812});await pressEnter(page.locator('[data-choice="'+choice+'"]'));}
  else await page.locator('[data-choice="'+choice+'"]').click();
  await page.locator('#next-button').waitFor({state:'visible'});await assertFeedback('#feedback-slot',item);
  const correct=choice===item.answer;receipt.answers.push({item:item.id,concept:item.concept,choice,correct});
  mastery[item.concept]=updateMastery(mastery[item.concept],correct);
  assert.equal(await page.locator('[data-choice]:enabled').count(),0);
  if(i===4){
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,'375px document must not overflow horizontally');
   await page.screenshot({path:join(out,'learner-375.png'),fullPage:true});
   await pressEnter(page.locator('#next-button'));await page.setViewportSize({width:1280,height:900});
  }else await page.locator('#next-button').click();
 }
 assert.equal(receipt.answers.length,16);assert.equal(receipt.answers.filter(x=>x.correct).length,12);
 assert.match(await page.locator('#first-try-summary').textContent(),/12 of 16/);
 const review=createReview(deck.items,receipt.answers);
 assert.deepEqual(await page.locator('.review-prompt').allTextContents(),review.map(x=>x.prompt));
 const actualReview=await page.locator('.review-item').evaluateAll(es=>es.map(el=>({prompt:el.querySelector('.review-prompt').textContent,answers:[...el.querySelectorAll('.review-answers dd')].map(x=>x.textContent)})));
 assert.deepEqual(actualReview,review.map(x=>({prompt:x.prompt,answers:[x.options[x.choice],x.options[x.answer]]})));
 receipt.groups.push({name:'All sixteen actual questions, four designated misses and unchanged first-answer review',status:'pass',correct:12,total:16,narrowKeyboard:true});
 const reflection='A margin is shared along the branch.\nFirst 3–4 then Second 7–8 spends two separate waits.';
 const field=page.locator('[data-reflection-item="ct-slack-4"]');
 await field.locator('xpath=ancestor::details').evaluate(el=>el.open=true);
 await field.fill(reflection);reflections=updateReflection(reflections,'ct-slack-4',reflection);
 const application='Compare both branches before shortening a job; these times do not allocate real people or calendars.';
 await page.locator('#application-reflection').fill(application);reflections=updateApplicationReflection(reflections,application);
 const beforeNotes=await downloadNotes('first-session-notes');
 assert.ok(beforeNotes.includes('Not started. 4 missed connections are available for practice.'));
 receipt.groups.push({name:'Native study-notes bytes preserve actual first answers and authored reflections',status:'pass'});
 await page.locator('#practice-button').click();practice=beginPractice(review);
 for(let i=0;i<4;i++){
  const item=await cardIdentity('[data-practice-choice]');assert.equal(item.id,practice.items[i].id);assert.ok(misses.has(item.id));
  await page.locator('[data-practice-choice="'+item.answer+'"]').click();await assertFeedback('#practice-feedback',item);
  practice=answerPractice(practice,item.id,item.answer);receipt.practiceAnswers.push({...practice.answers.at(-1)});
  await page.locator('#practice-next').click();
 }
 assert.match(await page.locator('#practice-status').textContent(),/4 of 4 correctly on retry/);
 assert.match(await page.locator('#first-try-summary').textContent(),/12 of 16/);
 assert.equal(await page.locator('#practice-button').count(),0);
 const afterNotes=await downloadNotes('completed-practice-notes');
 assert.ok(afterNotes.includes('Complete: 4 of 4 practice answers recorded; 4 correct on retry.'));
 for(const a of receipt.answers){const item=deck.items.find(x=>x.id===a.item);assert.ok(afterNotes.includes('Your first answer: '+item.options[a.choice]));}
 assert.equal(await field.inputValue(),reflection);assert.equal(await page.locator('#application-reflection').inputValue(),application);
 receipt.groups.push({name:'Only the four missed items retried once; complete native notes keep first answers/model/reflections separate',status:'pass'});
 companion=await context.newPage();observe(companion);
 await companion.goto(pathToFileURL(resolve(root,'courses/dependency-timing.html')).href);
 assert.equal(await companion.locator('#timing-results').isVisible(),false);
 await companion.locator('#jobs-input').fill('Prep\nDraft\nReview\nPack');
 await companion.locator('#edges-input').fill('Prep -> Draft\nPrep -> Review\nDraft -> Pack\nReview -> Pack');
 for(const[job,d]of Object.entries({Prep:2,Draft:3,Review:4,Pack:1}))await companion.locator('input[data-job="'+job+'"]').fill(String(d));
 const graph={jobs:['Prep','Draft','Review','Pack'],edges:[['Prep','Draft'],['Prep','Review'],['Draft','Pack'],['Review','Pack']]};
 for(const duration of [3,4,5]){
  if(duration!==3){
   await companion.locator('input[data-job="Draft"]').fill(String(duration));
   assert.equal(await companion.locator('#timing-results').isVisible(),false);
   assert.equal(await companion.locator('#download-trace').isEnabled(),false);
  }
  await companion.locator('#calculate-timing').click();
  const durations=graph.jobs.map(job=>({job,duration:job==='Draft'?duration:({Prep:2,Review:4,Pack:1})[job]}));
  const native=analyzeTiming(graph,durations);
  assert.equal(Number(await companion.locator('#project-duration').textContent()),duration===5?8:7);
  const rows=await companion.locator('#timing-rows tr[data-job]').evaluateAll(es=>es.map(el=>Object.fromEntries([['job',el.dataset.job],...['duration','earliestStart','earliestFinish','latestStart','latestFinish','totalSlack'].map(k=>[k,Number(el.querySelector('[data-field="'+k+'"]').textContent)]),['critical',el.dataset.critical==='true']])));
  assert.deepEqual(rows,native.timing.rows);
  assert.deepEqual(await companion.locator('#critical-jobs li').evaluateAll(es=>es.map(el=>el.dataset.job)),native.timing.criticalJobs);
  receipt.timingCases.push({draftDuration:duration,timing:native.timing,explicitRecalculation:true});
 }
 const [traceDownload]=await Promise.all([companion.waitForEvent('download'),companion.locator('#download-trace').click()]);
 const tracePath=join(out,'draft-five-timing.json');await traceDownload.saveAs(tracePath);const traceBytes=await readFile(tracePath),trace=JSON.parse(traceBytes);
 assert.equal(traceDownload.suggestedFilename(),'recallweave-dependency-timing.json');
 assert.equal(trace.schema,'recallweave-dependency-timing/1');assert.deepEqual(trace.input.graph,graph);
 assert.deepEqual(trace.input.durations,graph.jobs.map(job=>({job,duration:({Prep:2,Draft:5,Review:4,Pack:1})[job]})));
 assert.deepEqual(trace.result.timing,receipt.timingCases.at(-1).timing);
 assert.equal(traceBytes.toString('utf8'),JSON.stringify(trace,null,2)+'\n');
 receipt.downloads.push({kind:'native-timing-trace',filename:traceDownload.suggestedFilename(),...digest(traceBytes)});
 receipt.groups.push({name:'Existing timing companion A, Draft4 tie and Draft5 critical-branch change with edit invalidation and actual trace',status:'pass'});
 receipt.storage=[...await page.evaluate(()=>globalThis.__courseStorageWrites),...await companion.evaluate(()=>globalThis.__courseStorageWrites)];
 assert.deepEqual(receipt.storage,[]);assert.deepEqual(receipt.pageErrors,[]);assert.deepEqual(receipt.consoleErrors,[]);
 assert.equal(receipt.requests.filter(x=>/^https?:/.test(x.url)).length,0);
 await Promise.all(auditPending);
 assert.equal(receipt.served.length,2);
 for(const served of receipt.served){
  const p=served.url.endsWith('/demo.html')?'demo.html':'courses/dependency-timing.html';assert.equal(served.gitBlob,expectedPins[p]);
 }
 receipt.after=await sourcePins();assert.deepEqual(receipt.after,receipt.before);
 receipt.groups.push({name:'Exact unchanged consumer/source bytes, no off-origin attempts, storage writes or browser errors',status:'pass'});
 receipt.status='pass';
}catch(error){receipt.status='fail';receipt.failure={name:error.name,message:error.message,stack:error.stack};process.exitCode=1;}
finally{
 await Promise.allSettled(auditPending);
 if(context){receipt.lastUrls=context.pages().map(p=>p.url());await context.close();}
 if(browser)await browser.close();
 await persist();
}
console.log(JSON.stringify({status:receipt.status,groups:receipt.groups.length,requests:receipt.requests.length,downloads:receipt.downloads.length,failure:receipt.failure??null,receipt:join(out,'receipt.json')}));
