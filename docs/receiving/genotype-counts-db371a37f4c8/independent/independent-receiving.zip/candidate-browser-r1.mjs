import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {fileURLToPath,pathToFileURL} from 'node:url';
import {chromium} from 'file:///D:/Hamon/receiving/pneumatic-goals-root-db371a37f4c8/dependencies/node_modules/playwright/index.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),read=p=>fs.readFileSync(p),parse=p=>JSON.parse(read(p).toString('utf8').replace(/^\uFEFF/,''));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),pin=p=>{const b=read(p),s=fs.statSync(p,{bigint:true});return {bytes:b.length,sha256:hash(b),git:crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex'),mtime_ns:s.mtimeNs.toString()};};
const admission=parse(path.join(root,'CANDIDATE-ADMISSION-r2.json')),previous=parse(path.join(root,'CANDIDATE-ADMISSION.json')),freeze=parse(path.join(root,'ORIGINAL-FREEZE.json')),inputs=parse(path.join(root,'CANDIDATE-ADMISSION-r2-INPUT.json'));
const literals=parse(path.join(root,'LITERAL-GOLD.json')),answers=parse(path.join(root,'COURSE-ANSWERS.json')),portable=admission.package.portableRoot;
const expectPin=(p,s)=>assert.deepEqual(pin(p),{bytes:s.bytes,sha256:s.sha256,git:s.git,mtime_ns:s.mtime_ns},p);
function provenance(){
 for(const [a,offer] of [[admission,inputs.offer],[previous,inputs.previousOffer]]){for(const s of a.files){expectPin(path.join(a.candidateRoot,s.path),s.receiver);expectPin(path.join(offer.sourceRoot,s.path),s.source);}for(const s of a.package.members)expectPin(path.join(a.package.portableRoot,s.path),s);expectPin(a.package.path,a.package.received);expectPin(offer.portablePackage.path,a.package.source);}
 for(const s of freeze.original){expectPin(path.join(root,'original',s.path),s.receiver);expectPin(path.join(inputs.originalOffer.originalRoot,s.path),s.source);}
 for(const s of freeze.artifacts)expectPin(path.join(root,s.path),s);
 for(const s of freeze.donor.files)expectPin(path.join(freeze.donor.root,s.path),s);
 expectPin(freeze.node.path,freeze.node);expectPin(freeze.edge.path,freeze.edge);expectPin(path.join(root,'ORIGINAL-FREEZE.json'),inputs.originalFreeze);expectPin(path.join(root,'BLIND-ANSWER-FREEZE.json'),inputs.blindFreeze);const b=parse(path.join(root,'BLIND-ANSWER-FREEZE.json'));expectPin(path.join(root,'COURSE-BLIND.json'),b.projectionCopy);expectPin(path.join(root,'COURSE-ANSWERS.json'),b.answers);
 return {currentCandidateFiles:admission.files.length,previousCandidateFiles:previous.files.length,originalFiles:freeze.original.length,currentAndPriorPortableFiles:12,preCandidateArtifacts:freeze.artifacts.length,donorFiles:freeze.donor.files.length,node:true,edge:true,originalAndBlindFreezes:true,sourceCopiesAndZips:true};
}
const receipt={schema:'recall261-root-candidate-browser-v1',started:new Date().toISOString(),pid:process.pid,parent:process.ppid,canonical:admission.canonical,package:admission.package.received,status:'running',groups:[],requests:[],internalEdgeRequests:[],unexpectedRequests:[],pageErrors:[],consoleErrors:[],storageCalls:[],downloadEvents:[],downloads:[],browserProcesses:[],captures:[],authoredTestsOrResultsRead:false};
let browser,context,page,downloadedLesson;
function checkpoint(){fs.writeFileSync(path.join(root,'CANDIDATE-BROWSER-r1-PROGRESS.json'),JSON.stringify(receipt,null,2)+'\n');}
async function group(name,fn){const g={name,start:new Date().toISOString()};receipt.groups.push(g);try{g.result=await fn();g.status='passed';}catch(e){g.status='failed';g.error=String(e.stack||e);throw e;}finally{g.end=new Date().toISOString();checkpoint();}}
const text=id=>page.locator(id).textContent();
async function capture(name,details={}){const file=path.join(root,name);assert.equal(fs.existsSync(file),false);await page.screenshot({path:file});receipt.captures.push({path:name,...pin(file),...details});}
async function download(selector,name,expected){const pending=page.waitForEvent('download');await page.locator(selector).click();const d=await pending,destination=path.join(root,'downloads',name);assert.equal(fs.existsSync(destination),false);await d.saveAs(destination);assert.equal(await d.failure(),null);const b=read(destination);if(expected!==undefined)assert.deepEqual(b,Buffer.isBuffer(expected)?expected:Buffer.from(expected,'utf8'));const r={selector,suggestedFilename:d.suggestedFilename(),path:destination,...pin(destination)};receipt.downloads.push(r);return {...r,bytesContent:b};}
try{
 receipt.provenanceBefore=provenance();fs.mkdirSync(path.join(root,'browser-tmp-r1'),{recursive:false});fs.mkdirSync(path.join(root,'downloads'),{recursive:false});
 browser=await chromium.launch({executablePath:freeze.edge.path,headless:true,chromiumSandbox:true,timeout:45000});receipt.browserVersion=browser.version();
 context=await browser.newContext({viewport:{width:1360,height:900},acceptDownloads:true,serviceWorkers:'block'});await context.setOffline(true);
 await context.exposeBinding('__rootStorageObservation',(_,entry)=>receipt.storageCalls.push(entry));
 await context.addInitScript(()=>{for(const method of ['setItem','removeItem','clear']){const original=Storage.prototype[method];Storage.prototype[method]=function(...args){window.__rootStorageObservation({method,origin:location.href,args:args.map(String)});return original.apply(this,args);};}const originalOpen=IDBFactory.prototype.open;IDBFactory.prototype.open=function(...args){window.__rootStorageObservation({method:'indexedDB.open',origin:location.href,args:args.map(String)});return originalOpen.apply(this,args);};});
 context.on('request',r=>{const url=r.url();receipt.requests.push(url);if(/^edge:\/\/downloads-hub\//.test(url))receipt.internalEdgeRequests.push(url);else if(!/^(file|data|blob):/.test(url))receipt.unexpectedRequests.push(url);});
 context.on('page',p=>{p.on('pageerror',e=>receipt.pageErrors.push(String(e)));p.on('console',m=>{if(m.type()==='error')receipt.consoleErrors.push(m.text());});p.on('download',d=>receipt.downloadEvents.push({at:new Date().toISOString(),url:d.url(),filename:d.suggestedFilename()}));});
 page=await context.newPage();page.setDefaultTimeout(12000);const cdp=await browser.newBrowserCDPSession();receipt.browserProcesses=(await cdp.send('SystemInfo.getProcessInfo')).processInfo;await cdp.detach();
 await group('actual extracted worksheet six unchanged public tables, unanswered structure and desktop/phone layout',async()=>{
  await page.goto(pathToFileURL(path.join(portable,'courses/genotype-counts-worksheet.html')).href,{waitUntil:'load'});assert.equal(await text('h1'),'Genotype counts');
  assert.equal(await page.locator('script').count(),0);assert.equal(await page.locator('input,textarea,button').count(),0);assert.equal(await page.locator('section.page').count(),3);assert.equal(await page.locator('.work tbody tr').count(),36);assert.equal(await page.locator('.blank').count(),36);
  assert.deepEqual(await page.locator('.blank').allTextContents(),Array(36).fill('Space for your answer'));
  const labels=await page.locator('.counts').evaluateAll(es=>es.map(e=>e.getAttribute('aria-label')));assert.deepEqual(labels,literals.map(g=>g.id+': AA '+g.counts[0]+', Aa '+g.counts[1]+', aa '+g.counts[2]));
  const links=await page.locator('nav a').evaluateAll(es=>es.map(e=>({href:e.getAttribute('href'),text:e.textContent,download:e.hasAttribute('download')})));assert.deepEqual(links.map(x=>x.href),['genotype-counts.json','genotype-counts.md','../demo.html']);assert.equal(links[0].download,true);assert.ok(links[1].text.includes('contains answers'));
  const rule=await text('.rule');assert.ok(rule.includes('For N > 0, p = (2nAA + nAa)/(2N) is the A-copy fraction, and q = (2naa + nAa)/(2N) is the a-copy fraction.'));
  const layouts=[];
  for(const viewport of [{width:1360,height:900},{width:390,height:844}]){await page.setViewportSize(viewport);await page.evaluate(()=>scrollTo(0,0));const bounds=await page.evaluate(()=>({width:innerWidth,documentWidth:document.documentElement.scrollWidth,cases:[...document.querySelectorAll('.case')].map(e=>{const b=e.getBoundingClientRect();return {id:e.id,x:b.x,width:b.width,height:b.height};}),links:[...document.querySelectorAll('nav a')].map(e=>{const b=e.getBoundingClientRect();return {href:e.getAttribute('href'),x:b.x,width:b.width,height:b.height};})}));assert.ok(bounds.documentWidth<=viewport.width);for(const b of [...bounds.cases,...bounds.links])assert.ok(b.width>0&&b.height>0&&b.x>=-1&&b.x+b.width<=viewport.width+1,JSON.stringify(b));if(viewport.width===390)assert.equal(bounds.cases[0].x,bounds.cases[1].x);else assert.ok(bounds.cases[1].x>bounds.cases[0].x);await capture('candidate-worksheet-'+viewport.width+'x'+viewport.height+'.png',{viewport,bounds});layouts.push({viewport,bounds});}
  await page.setViewportSize({width:1360,height:900});return {labels,links,rule,blankAnswerCells:36,scripts:0,inputs:0,layouts};
 });
 await group('actual native Edge print of unanswered worksheet with CSS page size',async()=>{
  const pdfPath=path.join(root,'candidate-worksheet-print-r1.pdf');assert.equal(fs.existsSync(pdfPath),false);await page.pdf({path:pdfPath,preferCSSPageSize:true,printBackground:true,displayHeaderFooter:false});assert.equal(read(pdfPath).subarray(0,5).toString('ascii'),'%PDF-');receipt.print={path:pdfPath,...pin(pdfPath),options:{preferCSSPageSize:true,printBackground:true,displayHeaderFooter:false},pageAndPixelReviewPending:true};return receipt.print;
 });
 await group('actual worksheet course download is the exact packaged native deck',async()=>{const d=await download('a[download]','genotype-counts.json',read(path.join(portable,'courses/genotype-counts.json')));downloadedLesson=d.path;return {path:d.path,bytes:d.bytes,sha256:d.sha256,git:d.git};});
 let firstSummary,firstAnswers,firstMastery,answered,wrongId,reviewBefore;
 const note='Independent counting note: AA contributes two A copies and Aa one; a model expectation remains separate.',application='Equal allele fractions can conceal different genotype pairings; an empty group supplies no denominator.';
 function reviewSnapshot(){return page.locator('.review-item').evaluateAll(rows=>rows.map(e=>({prompt:e.querySelector('.review-prompt').textContent,status:e.querySelector('.review-status').textContent,answers:[...e.querySelectorAll('.review-answers dd')].map(x=>x.textContent),fullAnswerText:e.querySelector('.review-answers').textContent,explanation:e.querySelector('.review-body > p').textContent})));}
 await group('actual packaged learner link and fourteen-course first answers, review, reflection and retry',async()=>{
  await page.locator('a[href="../demo.html"]').click();await page.locator('#start-button').waitFor();assert.equal(page.url(),pathToFileURL(path.join(portable,'demo.html')).href);
  const course=parse(downloadedLesson);assert.equal(course.items.length,14);assert.deepEqual(course.items.map(x=>({id:x.id,answer:x.answer})),answers.map(x=>({id:x.id,answer:x.answer})));
  const before=await page.locator('#session-content').innerHTML();await page.locator('#deck-file').setInputFiles(downloadedLesson);await page.locator('#start-deck').waitFor();
  assert.equal(await text('#deck-preview-title'),course.title);assert.equal(await page.locator('#session-content').innerHTML(),before);
  await page.locator('#start-deck').click();assert.equal(await text('#step-count'),'0 / 14');assert.equal(await text('#lesson-description'),course.title);
  answered=[];
  for(let i=0;i<14;i++){
   const prompt=await text('#session-content h2'),item=course.items.find(x=>x.prompt===prompt);assert.ok(item);assert.equal(answered.some(x=>x.id===item.id),false);
   if(i===0){for(const viewport of [{width:1360,height:900},{width:390,height:844}]){await page.setViewportSize(viewport);await page.evaluate(()=>scrollTo(0,0));const bounds=await page.evaluate(()=>({width:innerWidth,documentWidth:document.documentElement.scrollWidth,choices:[...document.querySelectorAll('[data-choice]')].map(e=>{const b=e.getBoundingClientRect();return {choice:e.dataset.choice,x:b.x,width:b.width,height:b.height};})}));assert.ok(bounds.documentWidth<=viewport.width);for(const b of bounds.choices)assert.ok(b.width>0&&b.height>0&&b.x>=-1&&b.x+b.width<=viewport.width+1);await capture('candidate-learner-'+viewport.width+'x'+viewport.height+'.png',{viewport,bounds});}await page.setViewportSize({width:1360,height:900});}
   const frozen=answers.find(x=>x.id===item.id).answer,choice=i===0?(frozen+1)%item.options.length:frozen;if(i===0)wrongId=item.id;
   await page.locator('[data-choice="'+choice+'"]').click();await page.locator('#next-button').waitFor();const feedback=await text('#feedback-slot');
   for(const wanted of [item.options[choice],item.options[frozen],item.explanation,item.transfer])assert.ok(feedback.includes(wanted),item.id+' feedback '+wanted);
   answered.push({id:item.id,prompt,choice,correct:choice===frozen,correctIndex:frozen,feedback});await page.locator('#next-button').click();
  }
  await page.locator('#first-try-summary').waitFor();firstSummary=await text('#first-try-summary');assert.ok(firstSummary.includes('13 of 14'));
  reviewBefore=await reviewSnapshot();assert.equal(reviewBefore.length,14);
  for(let i=0;i<14;i++){const a=answered[i],item=course.items.find(x=>x.id===a.id),r=reviewBefore[i];assert.equal(r.prompt,item.prompt);assert.deepEqual(r.answers,[item.options[a.choice],item.options[a.correctIndex]]);assert.equal(r.status,(a.correct?'Correct':'Needs review')+' · first try');assert.equal(r.explanation,item.explanation);assert.ok(r.fullAnswerText.length>0);}
  firstAnswers=await page.locator('.review-answers').allTextContents();assert.ok(firstAnswers.every(x=>x.length>0));firstMastery=await page.locator('.mastery-box output').allInnerTexts();assert.ok(firstMastery.length>0&&firstMastery.every(x=>x.length>0));
  await page.locator('.review-item').first().locator('summary').click();await page.locator('[data-reflection-item]').first().fill(note);await page.locator('#application-reflection').fill(application);
  await page.locator('#practice-button').click();const missed=course.items.find(x=>x.id===wrongId);assert.equal(await text('#session-content h2'),missed.prompt);
  await page.locator('[data-practice-choice="'+answers.find(x=>x.id===wrongId).answer+'"]').click();await page.locator('#practice-next').click();await page.locator('#first-try-summary').waitFor();
  assert.equal(await text('#first-try-summary'),firstSummary);assert.deepEqual(await page.locator('.review-answers').allTextContents(),firstAnswers);assert.deepEqual(await reviewSnapshot(),reviewBefore);assert.deepEqual(await page.locator('.mastery-box output').allInnerTexts(),firstMastery);
  assert.equal(await page.locator('[data-reflection-item]').first().inputValue(),note);assert.equal(await page.locator('#application-reflection').inputValue(),application);assert.equal(await text('#practice-status'),'You answered 1 of 1 correctly on retry.');
  return {courseSHA:pin(downloadedLesson).sha256,previewPreservedSession:true,answered,firstSummary,reviewBefore,firstAnswers,firstMastery,wrongId,practiceCorrect:true,firstAnswersAndMasteryPreserved:true,reflectionsPreserved:true};
 });
 await group('actual complete lesson notes preserve choices and observations remain offline',async()=>{
  const d=await download('#save-notes-button','candidate-study-notes.txt'),notes=d.bytesContent.toString('utf8'),course=parse(downloadedLesson);
  for(const wanted of [course.title,'13 of 14 connections correct on the first try.','Complete: 1 of 1 practice answers recorded; 1 correct on retry.',note,application,course.attribution,course.license])assert.ok(notes.includes(wanted),wanted);
  const noteRows=[];
  for(let i=0;i<answered.length;i++){
   const a=answered[i],item=course.items.find(x=>x.id===a.id),start=notes.indexOf('\n'+(i+1)+'. '+item.prompt+'\n'),end=i+1<answered.length?notes.indexOf('\n'+(i+2)+'. '+answered[i+1].prompt+'\n'):notes.indexOf('\nYOUR APPLICATION REFLECTION');
   assert.ok(start>=0&&end>start);const segment=notes.slice(start,end);
   for(const wanted of ['Your first answer: '+item.options[a.choice],'First try: '+(a.correct?'correct':'needs review'),'Correct answer: '+item.options[a.correctIndex],'Explanation: '+item.explanation,'Apply the idea: '+item.transfer])assert.ok(segment.includes(wanted),item.id+' '+wanted);
   if(item.id===wrongId){assert.ok(segment.includes('Practice answer: '+item.options[a.correctIndex]));assert.ok(segment.includes('Practice result: correct on retry'));}
   noteRows.push({id:item.id,firstChoice:a.choice,firstCorrect:a.correct,practice:item.id===wrongId,segment});
  }
  for(const estimate of firstMastery)assert.ok(notes.includes(estimate),estimate);
  const storage=await page.evaluate(()=>({local:localStorage.length,session:sessionStorage.length}));assert.deepEqual(storage,{local:0,session:0});
  assert.deepEqual(receipt.storageCalls,[]);assert.deepEqual(receipt.unexpectedRequests,[]);assert.deepEqual(receipt.pageErrors,[]);assert.equal(receipt.downloadEvents.length,2);assert.equal(receipt.downloads.length,2);
  return {path:d.path,sha256:d.sha256,bytes:d.bytes,noteRows,notes,storage,storageCalls:[],unexpectedRequests:[],pageErrors:[],explicitDownloads:receipt.downloads.length};
 });

 const finalCdp=await browser.newBrowserCDPSession();receipt.browserProcessesFinal=(await finalCdp.send('SystemInfo.getProcessInfo')).processInfo;await finalCdp.detach();assert.deepEqual(receipt.consoleErrors,[]);receipt.status='passed';
}catch(e){receipt.status='failed';receipt.error=String(e.stack||e);process.exitCode=1;if(page)try{await capture('candidate-browser-r1-failure.png',{failure:true});}catch(captureError){receipt.failureCaptureError=String(captureError);}}
finally{
 if(browser)try{const c=await browser.newBrowserCDPSession();receipt.browserProcessesAtClose=(await c.send('SystemInfo.getProcessInfo')).processInfo;await c.detach();}catch(e){receipt.closeCensusError=String(e);}
 if(context)await context.close().catch(e=>{receipt.contextCloseError=String(e);receipt.status='failed';process.exitCode=1;});
 if(browser)await browser.close().then(()=>receipt.browserClosed=true).catch(e=>{receipt.browserCloseError=String(e);receipt.status='failed';process.exitCode=1;});
 try{receipt.provenanceAfter=provenance();receipt.sourceAndRuntimeUnchanged=true;}catch(e){receipt.provenanceError=String(e.stack||e);receipt.status='failed';process.exitCode=1;}
 receipt.finished=new Date().toISOString();fs.writeFileSync(path.join(root,'CANDIDATE-BROWSER-r1.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:receipt.status,pid:process.pid,groups:receipt.groups.map(g=>({name:g.name,status:g.status})),browserClosed:receipt.browserClosed,sourceAndRuntimeUnchanged:receipt.sourceAndRuntimeUnchanged,print:receipt.print,error:receipt.error}));
}
