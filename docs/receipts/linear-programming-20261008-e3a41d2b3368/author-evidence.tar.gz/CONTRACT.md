# Exact bounded linear-programming teaching contract

Repository: Jacob-Met/RecallWeave.
Base main: 698902f9c9c1d5c5023092b85b3632a7cb7a01ed.
Actual tree: d6d3707b691850af7928299242631534cff89aa8; 2,915 complete blob leaves.
This is a new course and exact offline mathematical consumer, not a regression repair.

Beneficiary: a learner who can solve linear equations but needs to distinguish
a boundary crossing, a feasible point, and a point or whole edge with the best
linear objective value. Existing native lesson import/review/practice remains
unchanged. All teaching questions, examples, diagrams and prose will be original.

Input and model:
- Two real variables x and y. Require an explicit closed rectangle with integer
  xmin, xmax, ymin, ymax in [-20,20], minima <= maxima. Degenerate rectangles
  remain valid mathematical inputs.
- Zero to eight authored constraints a*x + b*y <= c, with integer a,b,c in
  [-100,100]. A zero normal is retained as an explicit tautology or contradiction,
  not silently dropped. Duplicate/redundant rows retain authored identities.
- Explicit objective p*x + q*y, integer p,q in [-100,100], and min or max.
  This is continuous bounded linear optimization, not integer programming.
- Text admission uses a strict signed-integer grammar, at most 4,096 characters
  for constraint text, exactly three comma-separated fields per nonempty row,
  and the same numeric bounds as the API. No expressions, executable input,
  floating approximations, nonfinite values, or implicit rectangle.
- Enumerate all independent pairs from authored and four rectangle boundaries
  (at most 66 pairs). Compute determinant/intersection, feasibility, active
  constraints, slacks and objective with normalized BigInt rationals.
- Deduplicate coordinate identities without losing coincident source pairs.
  Produce all feasible extreme points, a deterministic convex boundary and
  explicit empty/point/segment/polygon region classification. Missing feasible
  vertices means infeasible within the required bounded rectangle.
- Select exact min/max objective over the full feasible vertex set. Retain every
  tied vertex and classify the optimal set as point, segment or whole region.
  A constant objective includes the entire nonempty feasible set; a singleton
  feasible set remains a point even for constant objective.
- Preserve the full admitted input, exact pair intersections and refused-pair
  reasons, all feasibility checks, all active/slack/objective values, region,
  optimum and applied inspection state in a bounded observation download.
  Rational strings are reduced with positive denominators; negative zero is
  numerical zero. No BigInt escapes through JSON and no binary float controls
  feasibility, equality, ordering, objective or optimum selection.
- The finite rectangle is part of the mathematical problem, not merely a plot
  viewport. No unboundedness, general simplex, sensitivity, dual certificate,
  integer optimum or practical resource-allocation advice is claimed.

Consumer and original course:
- New dependency-free module, UI module, standalone template/build artifact,
  strict builder, original 14–16 question native course and worked guide.
- Accessible SVG/table inspection of every feasible vertex, active constraints,
  exact objective and optimal segment/region. Rendering may convert bounded
  rational coordinates to Number; every displayed exact result and download
  comes from the rational model.
- Draft edits retire the current result/download until successful Apply.
  Invalid input keeps clear errors without presenting stale results as current.
  Explicit preset selection, real keyboard operation, narrow/mobile layout,
  and literal text handling are part of receiving.
- Course and guide downloads preserve authored bytes. Observation is a separate
  mathematical record, not a learner-answer archive. No automatic storage,
  network, account, external provider or existing learner-session mutation.
- Reuse unchanged src/deck.mjs validation for the course and builder. Receive
  actual downloaded course through the unchanged exact current standalone
  learner: preview, start, one answer/feedback, existing session preserved by
  merely opening/downloading the lab.

Source fence:
New src/linear-programming.mjs and src/linear-programming-ui.mjs;
courses/linear-programming.json, .md, -explorer.template.html and -explorer.html;
tools/build-linear-programming.mjs and tools/check-linear-programming-browser.mjs;
tests/linear-programming.test.mjs and tests/linear-programming-course.test.mjs;
one additive README discovery subsection; unique
docs/receiving/linear-programming-e3a41d2b3368/.
No shared learner, model, catalog, offline-pack, importer, builder, course,
workflow, dependency or runtime source is edited. #49 row operations, #163
convex hull, #167 knapsack, #39/#63 catalog, and all other owners stay separate.

Receiving plan:
Freeze an independent mathematical oracle before reading implementation tests.
Include unique fractional optimum, tied edge, constant objective, infeasible,
point/segment feasible sets, parallel/duplicate/zero constraints, active
degeneracy, min/max, row-order/scaling equivalence, invalid/limit inputs, complete
pair identity and immutable outputs. Validate original answer keys separately
from implementation output. Native Node and actual sandboxed browser receiving
use existing dependencies only, under measured capacity floors.
All Actions/source-ref/PR/merge triggers remain held. No required hosted gate
is waived; a safe issue claim may be posted only after complete current
workflow/ownership recheck and the parent's serialized slot.

Primary mathematical reference actually read:
https://courses.csail.mit.edu/6.854/21/Notes/n11-lp.html
Sections 1.3–1.5 support intersection geometry, independent active boundaries
and a vertex optimum for a nonempty bounded feasible set. This is background
verification; no reference exercise, question, diagram or passage is copied.
