import assert from 'node:assert/strict';import {readFile,writeFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
const root='/Users/me/hamon-native-406d0fb04c43/recallweave-weighted-intervals-independent',sha=b=>createHash('sha256').update(b).digest('hex');
const paths=['math-receipt.json','browser-baseline/receipt.json','browser-current-343d20/receipt.json','candidate-receiving.json','current-consumer-receiving.json','answer-review.json','oracle-freeze.json','browser-adapter-freeze.json','current-oracle-freeze.json','transport-control.json','transport-control-v2.json','preflight.json'];
const files=[];for(const path of paths){const b=await readFile(root+'/'+path);files.push({path,bytes:b.length,sha256:sha(b)});}
const before=JSON.parse(await readFile(root+'/browser-baseline/receipt.json')),after=JSON.parse(await readFile(root+'/browser-current-343d20/receipt.json'));
assert.equal(before.status,'accepted');assert.equal(after.status,'accepted');assert.deepEqual(before.learner,after.learner);
const originalTrace=JSON.parse(await readFile(root+'/browser-baseline/learner-trace.json')),currentTrace=JSON.parse(await readFile(root+'/browser-current-343d20/learner-trace.json'));
const {savedAt:oldSave,...oldContent}=originalTrace,{savedAt:newSave,...newContent}=currentTrace;assert.deepEqual(oldContent,newContent);
const stripTime=s=>s.replace(/^Saved:.*$/m,'Saved: <actual save time>');
assert.equal(stripTime(await readFile(root+'/browser-baseline/study-notes.txt','utf8')),stripTime(await readFile(root+'/browser-current-343d20/study-notes.txt','utf8')));
const parity={format:'recallweave-current-learner-artifact-parity/1',status:'accepted',baseline:'3cdebd86e69506709bcaeaeff4026deb3d1fc208',current:'343d20e38fb619c5eea2ec588b61c5f26fea714b',sameQuestionSequenceCanonicalAnswersMasteryAndRetry:true,learningTraceContentEqualExceptSavedAt:true,studyNotesEqualExceptSavedLine:true,originalSavedAt:oldSave,currentSavedAt:newSave,note:'Compares the already-produced artifacts; no new browser or solver run.'};
await writeFile(root+'/current-artifact-parity.json',JSON.stringify(parity,null,2)+'\n',{flag:'wx'});
const summary={files,baseline:{checks:before.checks,downloads:before.downloads,screenshots:before.screenshots,pageRequests:before.pageRequests,learner:before.learner,browser:before.browser},current:{checks:after.checks,downloads:after.downloads,screenshots:after.screenshots,pageRequests:after.pageRequests,consumerPin:after.consumerPin},parity};
await writeFile(root+'/evidence-summary.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(summary));
