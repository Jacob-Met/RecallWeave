#!/usr/bin/env node
/** Actual course receiving with the estate's already installed native browser stack. */
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, mkdtemp, rm } from 'node:fs/promises';
import { extname, join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const arg = (key, fallback) => process.argv.includes(key) ? process.argv[process.argv.indexOf(key) + 1] : fallback;
const project = resolve(arg('--root', '../source'));
const output = resolve(arg('--output', './author-browser'));
const playwright = arg('--playwright', '/Users/me/workspace/estate/production-evidence-49f845d0dece/browser-tools/node_modules/playwright/index.mjs');
const executable = arg('--browser', '/Users/me/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing');
const { chromium } = await import(pathToFileURL(playwright));
await mkdir(output, { recursive: true });
const temporary = await mkdtemp(join(output, 'temporary-'));
const coursePath = join(project, 'courses/binary-search.json');
const courseRaw = await readFile(coursePath, 'utf8');
const { parseDeck, serializeDeck } = await import(pathToFileURL(join(project, 'src/deck.mjs')));
const course = parseDeck(courseRaw);
const report = { status: 'running', project, courseSha256: createHash('sha256').update(courseRaw).digest('hex'),
  node: process.version, playwright, executable, checks: [], downloads: [], captures: [], sourceSha256: {}, pageErrors: [], externalRequests: [] };
const sourcePaths = ['author.html', 'author/index.html', 'author/author.css', 'src/deck.mjs',
  'src/deck-author.mjs', 'src/deck-author-loader.mjs', 'src/deck-author-ui.mjs', 'tools/make_author.py'];
for (const name of sourcePaths) report.sourceSha256[name] = createHash('sha256').update(await readFile(join(project, name))).digest('hex');

const server = createServer(async (request, response) => {
  try {
    const name = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    const path = resolve(project, `.${name}`);
    if (!path.startsWith(project + '/')) { response.writeHead(403).end(); return; }
    const body = await readFile(path);
    const mime = { '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json' }[extname(path)] ?? 'application/octet-stream';
    response.writeHead(200, { 'Content-Type': mime + '; charset=utf-8' }).end(body);
  } catch { response.writeHead(404).end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const base = `http://127.0.0.1:${server.address().port}`;
let browser, context, page;
const evaluate = expression => page.evaluate(expression);
async function activate(selector) { await page.locator(selector).focus(); await page.keyboard.press('Enter'); }
async function documentAt(url, width) {
  await context?.close();
  context = await browser.newContext({ viewport: { width, height: width === 390 ? 844 : 1000 }, acceptDownloads: true });
  await context.route('**/*', route => {
    const url = route.request().url();
    const allowed = url.startsWith(base + '/') || url.startsWith(pathToFileURL(project + '/').href) || /^(data|blob):/.test(url);
    if (!allowed) { report.externalRequests.push(url); return route.abort(); }
    return route.continue();
  });
  page = await context.newPage();
  page.on('pageerror', error => report.pageErrors.push(error.message));
  await page.goto(url, { waitUntil: 'networkidle', timeout: 20000 });
  await page.locator('#open-deck').waitFor({ state: 'attached' });
}
async function choose(path) { await page.locator('#open-deck').setInputFiles(path); await page.locator('#open-preview').waitFor({ state: 'visible' }); }
const meta = () => evaluate("['title','attribution','license'].map(id=>document.querySelector('#deck-'+id).value)");
function passed(name) { report.checks.push({ name }); console.log('PASS ' + name); }
async function capture(name, selector) {
  await page.locator(selector).scrollIntoViewIfNeeded();
  const bytes = await page.screenshot({ path: join(output, name) });
  report.captures.push({ name, sha256: createHash('sha256').update(bytes).digest('hex') });
}

async function receive(label, url, width) {
  await documentAt(url, width);
  const before = await meta();
  await choose(coursePath);
  assert.equal(await evaluate("document.querySelector('#open-preview-title').textContent"), `Open “${course.title}”?`);
  assert.match(await evaluate("document.querySelector('#open-preview-summary').textContent"), /12 questions · 4 concepts/);
  assert.deepEqual(await meta(), before);
  await activate('#cancel-open');
  assert.deepEqual(await meta(), before);
  assert.equal(await evaluate("document.querySelector('#open-preview').hidden"), true);
  passed(label + ': actual course preview and cancellation preserve the editor');

  await choose(coursePath); await activate('#replace-draft');
  assert.deepEqual(await meta(), [course.title, course.attribution, course.license]);
  assert.equal(await evaluate("document.querySelector('#question-picker').options.length"), course.items.length);
  const observed = [];
  for (let index = 0; index < course.items.length; index++) {
    await page.locator('#question-picker').selectOption({ index });
    const value = await evaluate(`({prompt:document.querySelector('#question-prompt').value,
      options:[...document.querySelectorAll('#option-list textarea')].map(node=>node.value),
      answer:[...document.querySelectorAll('#option-list input[type=radio]')].findIndex(node=>node.checked),
      concept:document.querySelector('#question-concept').selectedOptions[0].textContent,
      prerequisites:[...document.querySelectorAll('#question-prerequisites-list label')].filter(node=>node.querySelector('input').checked).map(node=>node.querySelector('span').textContent),
      explanation:document.querySelector('#question-explanation').value,
      transfer:document.querySelector('#question-transfer').value})`);
    const expected = course.items[index];
    assert.deepEqual(value, { prompt: expected.prompt, options: expected.options, answer: expected.answer,
      concept: expected.concept, prerequisites: expected.prerequisites, explanation: expected.explanation, transfer: expected.transfer });
    observed.push({ id: expected.id, ...value });
  }
  await writeFile(join(output, label + '-editor-content.json'), JSON.stringify(observed, null, 2) + '\n');
  passed(label + ': all twelve editor questions retain exact text, choices, answer identity and links');

  await activate('#check-draft');
  assert.equal(await evaluate("document.querySelector('#author-error').hidden"), true);
  assert.equal(await evaluate("document.querySelector('#author-preview').hidden"), false);
  const preview = await evaluate(`([...document.querySelectorAll('#preview-content details')].map(node=>({
    prompt:node.querySelector('.preview-prompt').textContent,
    options:[...node.querySelectorAll('.preview-options li')].map(option=>option.firstChild.textContent),
    answer:[...node.querySelectorAll('.preview-options li')].findIndex(option=>option.classList.contains('correct')),
    detail:[...node.querySelectorAll('.preview-detail')].map(paragraph=>paragraph.lastChild.textContent)
  })))`);
  assert.deepEqual(preview, course.items.map(question => ({ prompt: question.prompt, options: question.options,
    answer: question.answer, detail: [question.explanation, question.transfer] })));
  assert.equal(await evaluate('document.documentElement.scrollWidth > innerWidth'), false);
  await capture(label + '-preview.png', '#author-preview');
  passed(label + ': accepted author preview displays the full course with no viewport overflow');

  const ready = page.waitForEvent('download'); await activate('#download-deck');
  const download = await ready;
  const name = label + '-authored-course.json';
  const path = join(output, name); await download.saveAs(path);
  const bytes = await readFile(path);
  const exported = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  assert.equal(exported, serializeDeck(course));
  assert.deepEqual(parseDeck(exported), course);
  report.downloads.push({ name, filename: download.suggestedFilename(), bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
  await documentAt(url, width); await choose(path); await activate('#replace-draft'); await activate('#check-draft');
  assert.equal(await evaluate("document.querySelector('#preview-content details:last-of-type .preview-prompt').textContent"), course.items.at(-1).prompt);
  assert.equal(await evaluate("document.querySelector('#question-picker').options.length"), 12);
  passed(label + ': actual checked download reopens and retains the canonical course');
}

try {
  const response = await fetch(base + '/author/index.html', { signal: AbortSignal.timeout(5000) });
  report.selfHttp = { status: response.status, bytes: (await response.arrayBuffer()).byteLength }; assert.equal(response.status, 200);
  browser = await chromium.launch({ executablePath: executable, headless: true, downloadsPath: temporary,
    env: { ...process.env, TMPDIR: temporary } });
  report.browser = browser.version();
  await receive('desktop-http', base + '/author/index.html', 1280);
  await receive('phone-file', pathToFileURL(join(project, 'author.html')).href, 390);
  assert.deepEqual(report.pageErrors, []); assert.deepEqual(report.externalRequests, []);
  for (const path of sourcePaths) assert.equal(createHash('sha256').update(await readFile(join(project, path))).digest('hex'), report.sourceSha256[path]);
  assert.equal(createHash('sha256').update(await readFile(coursePath)).digest('hex'), report.courseSha256);
  passed('accepted renderer sources and course bytes remain unchanged; no external page request or error');
  report.status = 'passed';
} catch (error) { report.status = 'failed'; report.error = error.stack; process.exitCode = 1; }
finally {
  await writeFile(join(output, 'receipt.json'), JSON.stringify(report, null, 2) + '\n');
  await context?.close(); await browser?.close();
  await new Promise(resolve => server.close(resolve));
  await rm(temporary, { recursive: true, force: true, maxRetries: 3 });
  console.log(JSON.stringify({ status: report.status, checks: report.checks.length, downloads: report.downloads.length, error: report.error, receipt: join(output, 'receipt.json') }));
}
