import pathlib,json,hashlib,tarfile,gzip,io,sys,datetime
root=pathlib.Path('/home/jacob/snap/chromium/common/optimizer-euclid-current-handoff-3dab-20261008')
out=root/'packet-current-handoff-v1';out.mkdir()
pin=lambda b:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
m=json.loads((root/'receiving/source-pins.json').read_text())
assert pin((root/'receiving/source-pins.json').read_bytes())['sha256']=='7ce2bcfcecff22ef8d5493d815e1675ac887c8d3ad860a8c04d88a804d7a519f'
for name,row in m['files'].items():assert pin((root/'source'/name).read_bytes())==row,name
rb=(root/'receiving/browser-v1/browser-report.json').read_bytes();r=json.loads(rb)
assert r['status']=='passed' and len(r['checks'])==4 and r['before']==r['after']==m['files']
assert not r['pageErrors'] and not r['blocked'] and r['cleanup']['exitCode']==0 and r['cleanup']['removed']
assert r['lesson'][-1]['item']=='euclid-division-3'
c=json.loads((root/'receiving/command-v1/controller.json').read_text());assert c['accepted']
paths=['source/'+name for name in m['files']]
paths+=['receiving/'+name for name in ['source-pins.json','receive_euclid_current_v1.mjs','run_euclid_current_v1.py','seal_current_handoff_v1.py']]
for folder in ['browser-v1','command-v1']:
 paths += [str(p.relative_to(root)) for p in (root/'receiving'/folder).rglob('*') if p.is_file()]
assert len(paths)==len(set(paths));members={};buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0,filename='') as gz:
 with tarfile.open(fileobj=gz,mode='w') as tar:
  for name in sorted(paths):
   b=(root/name).read_bytes();members[name]=pin(b);info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
archive=buf.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 assert tar.getnames()==sorted(paths)
 for name in paths:assert tar.extractfile(name).read()==(root/name).read_bytes()
(out/'native-current-handoff.tar.gz').write_bytes(archive)
(out/'NATIVE_MEMBERS.json').write_text(json.dumps({'files':members},indent=2,sort_keys=True)+'\n')
(out/'SOURCE_PINS.json').write_bytes((root/'receiving/source-pins.json').read_bytes())
(out/'README.md').write_text(sys.argv[1])
receipt={'sealed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'passed','groups':r['checks'],'visited_items':[x['item'] for x in r['lesson']],'report':pin(rb),'controller':pin((root/'receiving/command-v1/controller.json').read_bytes()),'receiver':pin((root/'receiving/receive_euclid_current_v1.mjs').read_bytes()),'archive':pin(archive),'members':len(members),'all_archive_members_readback_exact':True,'all_source_before_after_exact':True,'cleanup':r['cleanup'],'screenshots':r['screenshots'],'downloads':r['downloads']}
(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
files={str(p.relative_to(out)):pin(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps({'files':files},indent=2,sort_keys=True)+'\n')
print(json.dumps({'packet':str(out),'manifest':pin((out/'MANIFEST.json').read_bytes()),'payloads':len(files),'archive':pin(archive),'members':len(members),'report':pin(rb),'visited':receipt['visited_items']},sort_keys=True))
