RecallWeave — Sampling without replacement
========================================
Extract the complete ZIP and open START-HERE.html.

Contents
- courses/hypergeometric-explorer.html: self-contained exact sampling explorer.
- courses/hypergeometric.json: original 14-question course.
- courses/hypergeometric.md: worked guide, answers and mathematical sources.
- demo.html: unchanged RecallWeave learner from canonical 1c8ece2713554f95b0e507297a34909d50222736.
- START-HERE.html: local entry page.
- MANIFEST.json: exact payload hashes (the manifest does not hash itself).

The explorer downloads the course and guide. To study it, open demo.html, choose the lesson JSON under Bring your own lesson, preview and explicitly start it. Initial learner biology content is unchanged. Answers and notes stay in the tab; download notes to retain your writing.

The hypergeometric model assumes uniform subsets of a fixed size among distinct tokens, without replacement. N is bounded 1..200, K and n 0..N. Inclusive event bounds must satisfy 0<=lower<=upper<=n. Exact BigInt counts and rational strings are retained; decimal fields/bars are approximations. Illustrative token subsets are deterministic, not observed or random samples.

Qualification of these exact payloads
- Original 14-question key independently answered before exposure to key/source.
- Exact counts/events/moments checked against 818 exhaustive labelled-subset configurations through N=12 and independent addition-only Pascal coefficients up to N=200.
- 107 native tests across the new capability and unchanged selected learner/deck/author closure; this is not a claim that the full repository suite ran.
- Actual offline Chromium 153: 14 browser groups, 5 downloads, full course import/feedback/review, separate retry and notes reflection; desktop 1280 and phone 390 width received with no page overflow.
- Zero page exceptions, external requests, automatic storage writes or source changes in the browser receiving.
- An initial browser-driver Enter event lacked its character payload. That negative is retained; the corrected driver passed with no product change.

This is a native, locally qualified product packet. No remote source branch, PR, merge or hosted workflow was triggered for this contribution. Current estate no-GitHub-Actions direction holds triggering publication. Claim: https://github.com/Jacob-Met/RecallWeave/issues/166

Original course content is CC0-1.0. Mathematical sources remain separately copyrighted and are linked, not copied, in the guide. All examples are hypothetical teaching systems.
