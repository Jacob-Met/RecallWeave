import datetime as dt
import hashlib
import json
import pathlib
import platform
import subprocess
import sys
import time

root = pathlib.Path(__file__).resolve().parent
run = root / "native-v2"
run.mkdir(exist_ok=False)
def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()
def pin(path):
    b = path.read_bytes()
    return {"path": path.relative_to(root).as_posix(), "mode": "100644", "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest(), "gitBlob": hashlib.sha1(b"blob " + str(len(b)).encode() + b"\0" + b).hexdigest()}
def save(path, doc):
    with path.open("x", encoding="utf-8", newline="\n") as h:
        json.dump(doc, h, indent=2, sort_keys=True); h.write("\n")
paths = [root/"source/counting-principles.mjs", root/"source/browser-source-v1-pins.json", root/"receive_counting_native_v2.mjs", root/"run-native-v2.py", root/"PAGE-FIELD-CLARIFICATION.json", root/"SOURCE_CUSTODY.json", root/"blind-counting-oracle-v1.tar.gz"]
before = [pin(path) for path in paths]
save(run/"source-freeze.json", {"frozenUTC":stamp(),"inputs":before,"subject":"New actual native run; original raw Node24 receipt is not reconstructed.","blindOracleRegenerated":False})
command = ["node", str(root/"receive_counting_native_v2.mjs")]
started = stamp()
clock = time.monotonic()
with (run/"stdout.json").open("xb") as stdout, (run/"stderr.txt").open("xb") as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr, timeout=120)
after = [pin(path) for path in paths]
raw = (run/"stdout.json").read_bytes()
receipt = {
    "format":"independent-counting-native-controller-v2",
    "startedUTC":started,"finishedUTC":stamp(),"elapsedSeconds":time.monotonic()-clock,
    "command":command,"cwd":str(root),"exitCode":result.returncode,
    "controllerPython":sys.version,"platform":platform.platform(),
    "sourcePinsBefore":before,"sourcePinsAfter":after,"sourcePinsUnchanged":before==after,
    "stdout":pin(run/"stdout.json"),"stderr":pin(run/"stderr.txt"),
    "rawOutputsWrittenDirectlyToFiles":True,"blindOracleRegenerated":False,"originalRunReconstructed":False,
}
try:
    native = json.loads(raw)
    receipt["nativeStatus"] = native["status"]
    receipt["checks"] = native["checks"]; receipt["counters"] = native["counters"]; receipt["runtime"] = native["runtime"]
    receipt["status"] = "passed" if result.returncode == 0 and before == after and native["status"] == "passed" else "failed"
except Exception as error:
    receipt["status"] = "failed"; receipt["parseError"] = str(error)
save(run/"controller-receipt.json",receipt)
manifest = {"format":"native-counting-v2-execution-manifest","frozenUTC":stamp(),"status":receipt["status"],"files":[pin(path) for path in sorted(run.iterdir()) if path.is_file()]}
save(run/"MANIFEST.json",manifest)
print(json.dumps({"status":receipt["status"],"root":str(root),"run":str(run),"receipt":pin(run/"controller-receipt.json"),"stdout":receipt["stdout"],"stderr":receipt["stderr"],"manifest":pin(run/"MANIFEST.json"),"checks":receipt.get("checks"),"counters":receipt.get("counters"),"runtime":receipt.get("runtime")},sort_keys=True))
raise SystemExit(0 if receipt["status"] == "passed" else 1)
