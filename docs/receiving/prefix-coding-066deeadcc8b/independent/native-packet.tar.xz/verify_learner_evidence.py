#!/usr/bin/env python3
"""Verify retained actual learner exports against the exact supplied course."""
from pathlib import Path
import json, hashlib, copy, re, sys
def need(ok,message):
    if not ok: raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def verify(root, report_path, course_path, baseline=False, override=None):
    report=json.loads(report_path.read_bytes()); raw=course_path.read_bytes(); course=json.loads(raw)
    need(report.get('harnessError') is None and report['failedChecks']==0,'learner browser completion')
    need(report['passedChecks']==(133 if baseline else 129),'learner check count')
    need(all(x['ok'] is True for x in report['checks']),'learner recorded assertion')
    need(len({x['name'] for x in report['checks']})==len(report['checks']),'duplicate learner check')
    need(report['courseSha256']==report['courseAfterSha256']==sha(raw),'course identity')
    need(report['sourceBefore']==report['sourceAfter'],'learner source movement')
    canonical=json.loads((root/'evidence/baseline-source-manifest.json').read_bytes())
    expected={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']} for r in canonical['files']}
    need(report['sourceBefore']==expected,'canonical learner closure')
    for r in canonical['files']:
        b=(root/'baseline'/r['path']).read_bytes()
        need(len(b)==r['bytes'] and sha(b)==r['sha256'],'learner source bytes')
    for served in report['served']:
        need(served['method']=='GET','unexpected served method')
        if served['status']==200:
            need(served['path'] in expected,'unknown served source')
            need({k:served[k] for k in ('bytes','sha256')}==expected[served['path']],'served source identity')
        else: need(served['status']==404,'unexpected source response')
    need(not report['pageErrors'] and not report['blockedRequests'],'browser application/network error')
    for request in report['requests']:
        need(request['method']=='GET' and request['url'].startswith(report['origin']+'/'),'external browser request')
    observation=report['finalObservation']
    need(observation['viewport']==375 and observation['documentWidth']<=376,'narrow layout')
    need(not observation['localStorageKeys'] and not observation['sessionStorageKeys'],'unexpected persistence')
    answers=report['answers'];need(len(answers)==len(course['items'])==12,'question count')
    lookup={item['id']:item for item in course['items']};need(len(lookup)==12,'question IDs')
    need(set(a['id'] for a in answers)==set(lookup),'complete question identity')
    for i,a in enumerate(answers):
        item=lookup[a['id']]
        need(a['index']==i and a['prompt']==item['prompt'] and a['answer']==item['answer'],'question content identity')
        need(a['correct']==(i>=3) and (a['choice']==item['answer'])==(i>=3),'first answer attribution')
        need(item['explanation'] in a['feedback'] and item['transfer'] in a['feedback'],'actual feedback content')
    downloads=report['downloads'];need(len(downloads)==2,'actual notes downloads')
    contents=[]
    for index,row in enumerate(downloads):
        name='study-notes-'+('before' if index==0 else 'after')+'-practice'
        need(row['name']==name and row['suggestedFilename'].endswith('.txt'),'download identity')
        p=report_path.parent/(name+'.txt'); data=override[name] if override and name in override else p.read_bytes()
        if override is None:need(len(data)==row['bytes'] and sha(data)==row['sha256'],'download custody')
        text=data.decode();contents.append(text)
        need(course['title'] in text and course['attribution'] in text and course['license'] in text,'download metadata')
        need('9 of 12 connections correct on the first try.' in text,'download first result')
        parts=re.split(r'\n(?=\d+\. )',text)
        need(len(parts)==13,'twelve notes sections')
        for i,(a,section) in enumerate(zip(answers,parts[1:])):
            item=lookup[a['id']]
            need(section.startswith(str(i+1)+'. '+item['prompt']+'\n'),'download question order')
            for field,label in [('explanation','Explanation: '),('transfer','Apply the idea: ')]:
                need(label+item[field]+'\n' in section,'download '+field+' missing: '+item['id'])
            need('Your first answer: '+item['options'][a['choice']]+'\n' in section,'download first answer')
            need('Correct answer: '+item['options'][item['answer']]+'\n' in section,'download correct answer')
            need('First try: '+('needs review' if i<3 else 'correct')+'\n' in section,'download first correctness')
            if i<3:
                need('  > Receiver reflection '+str(i)+': <b id=prefix-note>literal</b> & Ω\n  > A separate explanation of a connection.\n' in section,'literal reflection export')
                if index==1:
                    need('Practice answer: '+item['options'][item['answer']]+'\nPractice result: correct on retry\n' in section,'separate practice identity')
        need('  > Receiver application: prefix-free payload accounting is separate from framing.\n  > Keep my literal <tag> & Ω note.\n' in text,'literal application reflection')
    before,after=contents
    need(before.count('Practice answer: not recorded.')==3 and before.count('Practice answer:')==3 and 'Not started. 3 missed connections are available for practice.' in before,'practice must be explicitly unrecorded before action')
    need(after.count('Practice answer:')==3 and 'Complete: 3 of 3 practice answers recorded; 3 correct on retry.' in after,'separate practice denominator')
    def mastery(text):return text.split('ESTIMATED MASTERY — MODEL STATE, NOT A GRADE\n',1)[1].split('\nPRACTICE\n',1)[0]
    need(mastery(before)==mastery(after),'practice changed first estimates')
    if baseline:
        controls=report['capabilityControls']
        need(len(controls)==4 and all(x['status']==404 and x['text']=='Not found' for x in controls),'missing prefix baseline controls')
    else:need(report['capabilityControls']==[],'candidate absence claim')
    return {'questions':12,'first_correct':9,'first_wrong':3,'separate_correct_practice':3,'actual_notes_downloads':2,'note_sections_recomputed':24,'browser_checks':report['passedChecks'],'course_sha256':sha(raw)}
def main():
    root=Path(sys.argv[1]);summary=[]
    for name,report,course,baseline in [
      ('baseline','baseline-learner/report.json','baseline/courses/binary-search.json',True),
      ('course','course-v1-learner/report.json','course-v1/courses/prefix-coding.json',False)]:
        summary.append({'cohort':name,**verify(root,root/report,root/course,baseline)})
    # Keep all saved success assertions and the original files unchanged; omit a
    # real explanation only in an in-memory download to challenge semantic checks.
    d=json.loads((root/'course-v1/courses/prefix-coding.json').read_bytes())
    report=json.loads((root/'course-v1-learner/report.json').read_bytes())
    first=next(x for x in d['items'] if x['id']==report['answers'][0]['id'])
    data=(root/'course-v1-learner/study-notes-after-practice.txt').read_bytes()
    altered=data.replace(('Explanation: '+first['explanation']+'\n').encode(),b'Explanation: removed in receiver negative.\n',1)
    need(altered!=data,'negative preparation')
    rejected=False
    try:verify(root,root/'course-v1-learner/report.json',root/'course-v1/courses/prefix-coding.json',False,{'study-notes-after-practice':altered})
    except ValueError as e:
        need('download explanation missing' in str(e),'negative failed at unrelated boundary')
        rejected=True
    need(rejected,'missing explanation was accepted')
    outcome={'schema':'recall-prefix-learner-raw-verification-v1','cohorts':summary,'omitted_download_explanation_rejected':True,'product_execution':False}
    out=Path(sys.argv[2]);out.write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
if __name__=='__main__':main()
