import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {parseDeck} from './native-deck.mjs';
const [originalPath, clarifiedPath, blindPath] = process.argv.slice(2);
assert.ok(originalPath && clarifiedPath && blindPath);
const bytes=[originalPath,clarifiedPath,blindPath].map(p=>readFileSync(p));
const sha=b=>createHash('sha256').update(b).digest('hex');
const original=JSON.parse(bytes[0]), clarified=JSON.parse(bytes[1]), blind=JSON.parse(bytes[2]);
const clauses=new Map([
 ['gl-recombination-3','The two parental gamete classes are equally likely.'],
 ['gl-testcross-2','The two parental gamete classes are equally likely.'],
 ['gl-testcross-3','The two recombinant gamete classes are equally likely.'],
]);
try {
 const normalized=JSON.parse(JSON.stringify(clarified)), changes=[];
 for(const [id,clause]of clauses){
  const old=original.items.find(x=>x.id===id), now=clarified.items.find(x=>x.id===id);
  assert.ok(old&&now);
  assert.equal(now.prompt,clause+' '+old.prompt,id+' exact prefix only');
  normalized.items.find(x=>x.id===id).prompt=old.prompt;
  changes.push({id,clause,answerUnchanged:now.answer===old.answer,reasoningUnchanged:true});
 }
 assert.deepEqual(normalized,original,'No other course field may change');
 const admitted=parseDeck(bytes[1].toString('utf8'));
 assert.equal(admitted.items.length,12);
 assert.deepEqual(admitted.items.map(x=>x.answer),blind.items.map(x=>x.answer));
 assert.deepEqual(admitted.items.map(x=>x.options),blind.items.map(x=>x.options));
 [originalPath,clarifiedPath,blindPath].forEach((p,i)=>assert.deepEqual(readFileSync(p),bytes[i]));
 console.log(JSON.stringify({schema:'recallweave-linkage-targeted-premise-clarification/1',
  passed:true,node:process.version,sourceSha256s:bytes.map(sha),changes,
  allOtherFieldsExact:true,nativeSchemaAdmitted:true,blindKeysAndOptionsPreserved:true,
  sourceUnchanged:true,originalWholeCourseReview:'c5fc07dad315d6b64006f25e0b22a7b5c053ed4d',
  scope:'Only three declared premise prefixes and native admission of this successor; original blind answers and first full-course result remain separate.'
 },null,2));
}catch(error){
 console.log(JSON.stringify({schema:'recallweave-linkage-targeted-premise-clarification/1',
 passed:false,node:process.version,sourceSha256s:bytes.map(sha),
 failure:{name:error.name,message:error.message,stack:error.stack}},null,2));process.exitCode=1;
}
