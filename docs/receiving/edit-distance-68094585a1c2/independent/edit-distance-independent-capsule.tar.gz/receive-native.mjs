import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const root='/tmp/hamon-levenshtein-independent-68094585a1c2';
const read=name=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'));
const hash=raw=>createHash('sha256').update(raw).digest('hex');
const pin=name=>{const raw=fs.readFileSync(path.join(root,name));return{path:name,bytes:raw.length,sha256:hash(raw)};};
const put=(name,value)=>fs.writeFileSync(path.join(root,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const frozen=read('contract-before-candidate.json'),admitted=read('candidate-admission.json');
assert.equal(pin('contract-before-candidate.json').sha256,'b20671afa677db319389fa5c79449a9db83d96cd80dc9d517015f588fa1ef523');
for(const item of frozen.files)assert.equal(pin(item.path).sha256,item.sha256,item.path);
const tracked=[...frozen.files.map(x=>x.path),'freeze-independent.mjs','contract-before-candidate.json','original-source/src/deck.mjs','candidate-v1/MANIFEST.json',...admitted.candidate.map(x=>'candidate-v1/'+x.path)];
const before=tracked.map(pin);
for(const x of admitted.candidate)assert.equal(pin('candidate-v1/'+x.path).sha256,x.sha256,x.path);
assert.equal(pin('original-source/src/deck.mjs').sha256,admitted.originalParser.sha256);
const receipt={schema:'hamon.recallweave-edit-distance.independent-native-receiving/1',startedAt:new Date().toISOString(),node:process.version,contractSHA256:pin('contract-before-candidate.json').sha256,candidateManifestSHA256:admitted.candidateManifest.sha256,sourceBefore:before,groups:[],errors:[],browserClaim:false,authorTestsAccessed:false,upstream39TestSuiteRepeated:false};
const checks=[],actualRecords=[];
function check(name,fn){
 try{const detail=fn();checks.push({name,pass:true,...detail});}
 catch(e){checks.push({name,pass:false,error:String(e.message),stack:String(e.stack)});receipt.errors.push({name,error:String(e.message),stack:String(e.stack)});}
}
const model=await import(pathToFileURL(path.join(root,'candidate-v1/courses/edit-distance-core.mjs')));
const originals=await import(pathToFileURL(path.join(root,'original-source/src/deck.mjs')));
const expectations=read('expected-model-records.json');
let cells=0,candidates=0;
for(const item of expectations.cases){
 check('model:'+item.id,()=>{
  const actual=model.analyzeEditDistance(item.record.source,item.record.target);
  const raw=JSON.stringify(actual);
  actualRecords.push({id:item.id,record:actual});
  assert.deepEqual(actual,item.record);
  assert.deepEqual(model.POLICY,item.record.policy);
  const cellCount=actual.cells.reduce((sum,row)=>sum+row.length,0);
  const candidateCount=actual.cells.flat().reduce((sum,cell)=>sum+cell.candidates.length,0);
  cells+=cellCount;candidates+=candidateCount;
  return{distance:actual.distance,optimalPathCount:actual.optimalPathCount,cellCount,candidateCount,alignmentSteps:actual.alignment.length,actualRecordSHA256:hash(raw),actualRecordBytes:Buffer.byteLength(raw)};
 });
}
receipt.groups.push({name:'frozen full model records',pass:checks.filter(c=>c.name.startsWith('model:')).every(c=>c.pass),cases:expectations.cases.length,prefixCells:cells,candidateMoves:candidates});
const refusals=read('expected-refusals.json');
function value(spec){
 switch(spec.kind){
  case 'string':return spec.value;case 'code-units':return String.fromCharCode(...spec.units);
  case 'undefined':return undefined;case 'null':return null;case 'number':return 42;case 'boolean':return false;
  case 'array':return [];case 'object':return {value:'x'};case 'boxed-string':return new String('x');
  case 'symbol':return Symbol('x');case 'bigint':return 1n;default:throw Error('Unknown frozen descriptor');
 }
}
for(const item of refusals.cases)check('refusal:'+item.id,()=>{let error;try{model.analyzeEditDistance(value(item.source),value(item.target));}catch(e){error=e;}assert(error,'Candidate returned a record for a refused input');return{errorName:error.name,errorMessage:error.message};});
receipt.groups.push({name:'strict input admission across both positions',pass:checks.filter(c=>c.name.startsWith('refusal:')).every(c=>c.pass),cases:refusals.cases.length});
const deckRaw=fs.readFileSync(path.join(root,'candidate-v1/courses/edit-distance.json'),'utf8');
const deck=originals.parseDeck(deckRaw),key=read('expected-course-answers.json'),questions=read('original-course-questions-only.json');
check('course:unchanged native admission',()=>{assert.equal(deck.format,'recallweave-deck/1');assert.equal(deck.items.length,14);assert.equal(deck.concepts.length,4);return{bytes:Buffer.byteLength(deckRaw),sha256:hash(deckRaw),title:deck.title,concepts:deck.concepts,parserGitBlob:admitted.originalParser.git_blob};});
for(let i=0;i<key.answers.length;i++)check('course:'+key.answers[i].id,()=>{
 const q=questions.items[i],actual=deck.items[i],expected=key.answers[i];
 for(const field of['id','concept','prompt','options'])assert.deepEqual(actual[field],q[field],field);
 assert.equal(actual.answer,expected.expectedOptionIndex);
 return{id:actual.id,answer:actual.answer,independentReason:expected.reason};
});
receipt.groups.push({name:'14 independently solved course answers through unchanged native parser',pass:checks.filter(c=>c.name.startsWith('course:')).every(c=>c.pass),questions:key.answers.length});
receipt.checks=checks;receipt.sourceAfter=tracked.map(pin);
check('custody:exact protected input bytes',()=>{assert.deepEqual(receipt.sourceAfter,receipt.sourceBefore);return{files:tracked.length};});
receipt.groups.push({name:'source and frozen input custody',pass:checks.at(-1).pass,files:tracked.length});
put('actual-model-records.json',{schema:'hamon.recallweave-edit-distance.independent-actual-model-records/1',cases:actualRecords});
put('admitted-course.json',deck);
receipt.actualModelRecords=pin('actual-model-records.json');receipt.admittedCourse=pin('admitted-course.json');
receipt.completedAt=new Date().toISOString();receipt.pass=receipt.errors.length===0;
put('native-receiving.json',receipt);
console.log(JSON.stringify({pass:receipt.pass,groups:receipt.groups,errors:receipt.errors.map(x=>({name:x.name,error:x.error})),receipt:pin('native-receiving.json'),actualModelRecords:receipt.actualModelRecords},null,2));
process.exitCode=receipt.pass?0:1;
