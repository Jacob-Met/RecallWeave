import fs from 'node:fs';
import {readFile,writeFile,mkdir,mkdtemp,rm} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
export const sha=b=>createHash('sha256').update(b).digest('hex');
export const delay=ms=>new Promise(r=>setTimeout(r,ms));
export async function until(fn,label,timeout=20000){const end=Date.now()+timeout;let last;while(Date.now()<end){try{const value=await fn();if(value)return value;}catch(e){last=e;}await delay(100);}throw Error('Timed out: '+label+(last?' / '+last.message:''));}
export async function withBrowser({output,profileParent,executable='/snap/bin/chromium'},run){
 await mkdir(output,{recursive:true});
 const profile=await mkdtemp(join(profileParent,'dc-profile-'));
 const downloads=await mkdir(join(profile,'downloads'),{recursive:true}).then(()=>join(profile,'downloads'));
 const report={startedAt:new Date().toISOString(),browserExecutable:executable,profile,downloads,pageErrors:[],requests:[],responses:[],downloadEvents:[],checks:[],observations:[]};
 let browser,socket,sessionId,sequence=0,stderr='',closed;
 const pending=new Map();
 const command=(method,params={},scoped=true)=>new Promise((resolve,reject)=>{
  const id=++sequence,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},10000);
  pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...scoped&&sessionId?{sessionId}:{}}));
 });
 const evaluate=async expression=>{const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value;};
 const click=async selector=>{
  const point=await evaluate('(()=>{const n=document.querySelector('+JSON.stringify(selector)+');if(!n)throw Error("Missing element");n.scrollIntoView({block:"center"});const r=n.getBoundingClientRect();if(!r.width||!r.height)throw Error("Hidden element");return{x:r.x+r.width/2,y:r.y+r.height/2}})()');
  for(const type of ['mouseMoved','mousePressed','mouseReleased'])await command('Input.dispatchMouseEvent',{type,...point,...type!=='mouseMoved'?{button:'left',clickCount:1}:{}});
 };
 const key=async (key,code,modifiers=0)=>{for(const type of ['keyDown','keyUp'])await command('Input.dispatchKeyEvent',{type,key,code:key,windowsVirtualKeyCode:code,nativeVirtualKeyCode:code,modifiers});};
 const type=async (selector,text)=>{await click(selector);await key('a',65,2);await command('Input.insertText',{text});};
 const viewport=async(width,height=1000)=>command('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
 const navigate=async url=>{await command('Page.navigate',{url});await until(()=>evaluate('document.readyState==="complete"'),'document complete');};
 const screenshot=async name=>{const r=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const out=join(output,name);await writeFile(out,Buffer.from(r.data,'base64'));return{path:out,sha256:sha(Buffer.from(r.data,'base64'))};};
 const check=async(name,fn)=>{try{await fn();report.checks.push({name,status:'passed'});console.log('PASS '+name);}catch(e){report.checks.push({name,status:'failed',error:e.stack});console.log('FAIL '+name+': '+e.message);}};
 try{
  browser=spawn(executable,['--headless=new','--no-sandbox','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
  closed=new Promise(resolve=>{browser.once('close',resolve);browser.once('error',resolve);});
  let launchError;browser.on('error',e=>{launchError=e;});browser.stderr.on('data',b=>{stderr=(stderr+b.toString()).slice(-12000);});
  let port,endpoint;await until(async()=>{if(launchError)throw launchError;if(browser.exitCode!==null)throw Error('Browser exited '+browser.exitCode);[port,endpoint]=(await readFile(join(profile,'DevToolsActivePort'),'utf8')).trim().split('\n');return port&&endpoint;},'browser startup');
  socket=new WebSocket('ws://127.0.0.1:'+port+endpoint);
  socket.addEventListener('message',e=>{
   const m=JSON.parse(e.data);
   if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
   else if(m.method==='Runtime.exceptionThrown')report.pageErrors.push(m.params.exceptionDetails.exception?.description??m.params.exceptionDetails.text);
   else if(m.method==='Network.requestWillBeSent')report.requests.push({url:m.params.request.url,type:m.params.type});
   else if(m.method==='Network.responseReceived')report.responses.push({url:m.params.response.url,status:m.params.response.status,mime:m.params.response.mimeType});
   else if(m.method==='Browser.downloadWillBegin'||m.method==='Browser.downloadProgress')report.downloadEvents.push({method:m.method,...m.params});
  });
  await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
  report.browser=await command('Browser.getVersion',{},false);
  await command('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:downloads,eventsEnabled:true},false);
  const {targetId}=await command('Target.createTarget',{url:'about:blank'},false);
  ({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));
  for(const method of ['Page.enable','Runtime.enable','Network.enable'])await command(method);
  await run({report,command,evaluate,click,key,type,viewport,navigate,screenshot,check,downloads,output});
  report.status=report.checks.some(x=>x.status==='failed')||report.pageErrors.length?'failed':'passed';
 }catch(e){report.status='failed';report.error=e.stack;}
 finally{
  try{
   if(socket?.readyState===1){try{await Promise.race([command('Browser.close',{},false),closed]);}catch{}}
   if(browser){await Promise.race([closed,delay(5000)]);if(browser.exitCode===null){browser.kill('SIGTERM');await Promise.race([closed,delay(5000)]);}}
   if(socket)socket.close();
   for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('receiver closed'));}pending.clear();
   await rm(profile,{recursive:true,force:true,maxRetries:8,retryDelay:150});
   report.cleanup={status:'passed',profileRemoved:!fs.existsSync(profile)};
  }catch(e){report.cleanup={status:'failed',error:e.message};report.status='failed';}
  report.finishedAt=new Date().toISOString();report.browserStderrTail=stderr;
  await writeFile(join(output,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
 }
 return report;
}
