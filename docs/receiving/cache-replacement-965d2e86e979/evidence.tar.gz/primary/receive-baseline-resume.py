from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path("/Users/me/hamon-recall-cache-965d2e86e979");ev=root/"evidence";src=root/"source"
assert shutil.disk_usage(root).free>20_000_000
assert src.is_dir() and (src/".git").is_dir()
assert subprocess.run(["git","-C",str(src),"rev-parse","--verify","HEAD"],capture_output=True).returncode!=0
p=json.loads((ev/"baseline-source-input.json").read_text())
def gh(kind,data):return hashlib.sha1(kind.encode()+b" "+str(len(data)).encode()+b"\0"+data).hexdigest()
def th(leaves):
 at={}
 for row in leaves:
  node=at;parts=row["path"].split("/")
  for part in parts[:-1]:node=node.setdefault(part,{})
  assert parts[-1] not in node
  node[parts[-1]]=(row["mode"],row["sha"])
 def walk(node):
  entries=[]
  for name,value in node.items():
   directory=isinstance(value,dict)
   mode,digest=("40000",walk(value)) if directory else value
   entries.append(((name+("/" if directory else "")).encode(),mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(digest)))
  return gh("tree",b"".join(v for _,v in sorted(entries)))
 return walk(at)
assert len(p["full_leaves"])==1347 and th(p["full_leaves"])==p["canonical_tree"]
assert not any("/cache-replacement" in "/"+v["path"] for v in p["full_leaves"])
leaves={x["path"]:x for x in p["full_leaves"]}
manifest=[]
for f in p["selected_files"]:
 target=src/f["path"];target.parent.mkdir(parents=True,exist_ok=True)
 data=f["content"].encode("utf-8")
 assert len(data)==f["expected_bytes"] and gh("blob",data)==f["git_blob"],f["path"]
 assert leaves[f["path"]]["sha"]==f["git_blob"] and leaves[f["path"]]["mode"]==f["mode"]
 assert target.read_bytes()==data
 assert (target.stat().st_mode & 0o777)==(0o755 if f["mode"]=="100755" else 0o644)
 assert target.read_bytes()==data
 manifest.append({"path":f["path"],"mode":f["mode"],"git_blob":f["git_blob"],"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
assert (src/".git").is_dir()
for key,fmt in [("user.name","%an"),("user.email","%ae")]:
 value=subprocess.check_output(["git","-C","/Users/me/hamon-ashen-gamepad-965d2e86e979/source","log","-1","--format="+fmt],text=True).strip()
 assert value
 subprocess.run(["git","-C",str(src),"config",key,value],check=True)
subprocess.run(["git","-C",str(src),"add","."],check=True)
c=subprocess.run(["git","-C",str(src),"commit","-qm","snapshot: receive unchanged RecallWeave learner and course closure"],capture_output=True,text=True);assert c.returncode==0,c.stderr
receipt={"format":"hamon-canonical-partial-source-custody/1","utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"canonical_commit":p["canonical_commit"],"canonical_tree":p["canonical_tree"],"canonical_leaves":len(p["full_leaves"]),"full_tree_reconstructed_exactly":True,"selected_files":manifest,"selected_count":len(manifest),"selected_bytes":sum(x["bytes"] for x in manifest),"local_snapshot":subprocess.check_output(["git","-C",str(src),"rev-parse","HEAD"],text=True).strip(),"local_tree":subprocess.check_output(["git","-C",str(src),"rev-parse","HEAD^{tree}"],text=True).strip(),"local_snapshot_is_canonical_ancestry":False,"source_unchanged":True,"new_capability_present":False}
(ev/"baseline-source-custody.json").write_text(json.dumps(receipt,indent=2)+"\n")
baseline="""import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const source = new URL('../source/', import.meta.url);
const { parseDeck } = await import(new URL('src/deck.mjs', source));
const { draftFromDeck, checkDraft } = await import(new URL('src/deck-author.mjs', source));
const results = [];
for (const path of ['data/deck.json', 'courses/binary-search.json']) {
 const bytes = readFileSync(new URL(path, source)); const deck = parseDeck(bytes.toString('utf8'));
 const draft = checkDraft(draftFromDeck(deck)); assert.equal(draft.ok, true); assert.deepEqual(draft.deck, deck);
 results.push({ path, title: deck.title, questions: deck.items.length, concepts: deck.concepts.length, rawBytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), nativeParseAndAuthorRoundTrip: true });
}
assert.equal(results[1].questions, 12);
console.log(JSON.stringify({ node: process.version, originalCourses: results, originalConsumerPositive: true, newCacheCourseOrExplorerPresent: false, newCapabilityAbsenceIsInventoryEvidence: true }, null, 2));
"""
(ev/"baseline-consumer.mjs").write_text(baseline)
run=subprocess.run(["/opt/homebrew/bin/node",str(ev/"baseline-consumer.mjs")],capture_output=True)
(ev/"baseline-consumer-stdout.json").write_bytes(run.stdout);(ev/"baseline-consumer-stderr.log").write_bytes(run.stderr)
assert run.returncode==0 and not run.stderr,(run.returncode,run.stderr.decode())
for f in manifest:assert hashlib.sha256((src/f["path"]).read_bytes()).hexdigest()==f["sha256"]
final={"canonical":p["canonical_commit"],"tree":p["canonical_tree"],"local_snapshot":receipt["local_snapshot"],"local_tree":receipt["local_tree"],"source_files":len(manifest),"source_bytes":receipt["selected_bytes"],"custody_sha256":hashlib.sha256((ev/"baseline-source-custody.json").read_bytes()).hexdigest(),"node_receipt":json.loads(run.stdout),"native_exit":run.returncode,"stderr_bytes":len(run.stderr),"source_unchanged":True}
(ev/"baseline-native-receiving.json").write_text(json.dumps(final,indent=2)+"\n")
print(json.dumps(final,indent=2))
