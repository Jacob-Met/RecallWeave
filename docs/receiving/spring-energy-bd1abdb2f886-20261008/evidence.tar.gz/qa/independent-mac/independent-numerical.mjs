import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
const own = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(own, '../..');
const pins = {
  'qa/independent-mac/blind-answers.json': '80e0633410ea5212797b5770c0df5ce64c6604dd3025b096c11e3093e7e68693',
  'qa/independent-mac/numerical-plan-before-source.json': '3cefb2930b52dc51948a4c73f69bc7100e309cb7343dc106280daabb5231263d',
  'qa/precandidate-contract.json': '3339c9f68665aef44c38c4dacc2e23c464557e1a8e3e0ba64dd5f627ef37ea57',
  'qa/model-conventions.md': '377ea2d4bd3bc28184c86b0db3b3e549c3afaf1413d75e6343052cab83294936',
  'source/src/spring-energy.mjs': 'a5996337164ffd9d8501a2c376a6bfdc57807ecbce4e5fa2075bbaf78d9010a1',
  'source/courses/spring-energy.json': '84c87182731e35e036d5c2b2729cee94ae65091336272547e3a791a5cab068cc',
};
function identity(relative) {
  const buffer = fs.readFileSync(path.join(root, relative));
  return { path: relative, bytes: buffer.length, sha256: crypto.createHash('sha256').update(buffer).digest('hex') };
}
const before = Object.keys(pins).map(identity);
for (const entry of before) assert.equal(entry.sha256, pins[entry.path], entry.path + ' pin before import');
const plan = JSON.parse(fs.readFileSync(path.join(own, 'numerical-plan-before-source.json'), 'utf8'));
const mod = await import(pathToFileURL(path.join(root, 'source/src/spring-energy.mjs')).href);
const { inspectOscillator, parseOscillatorInput, sampleOscillatorCycle, serializeOscillatorExperiment } = mod;
const rows = [], observations = {};
let assertionCount = 0;
function ok(value, label) { assertionCount++; assert.ok(value, label); }
function equal(actual, expected, label) { assertionCount++; assert.deepEqual(actual, expected, label); }
function close(actual, expected, label) {
  ok(Number.isFinite(actual), label + ' finite');
  ok(Math.abs(actual - expected) <= plan.relative_or_absolute_tolerance * Math.max(1, Math.abs(expected)),
    label + ': actual ' + actual + ', expected ' + expected);
}
function rejects(action, label) { assertionCount++; assert.throws(action, undefined, label); }
function run(name, operation) {
  const start = assertionCount;
  try { operation(); rows.push({ name, passed: true, assertions: assertionCount - start }); }
  catch (error) { rows.push({ name, passed: false, assertions: assertionCount - start, error: { name: error.name, message: error.message, stack: error.stack } }); }
}
const numericKeys = Object.keys(plan.vectors[0].expected);
function invariants(result, label) {
  const p = result.input;
  for (const key of numericKeys) ok(Number.isFinite(result[key]), label + ' finite ' + key);
  close(result.force, -p.stiffnessNPerM * result.position, label + ' Hooke force');
  close(result.force, p.massKg * result.acceleration, label + ' Newton force');
  close(result.position ** 2 + (result.velocity / result.omega) ** 2, p.amplitudeM ** 2, label + ' phase ellipse');
  close(result.kineticEnergy + result.potentialEnergy, result.releaseEnergy, label + ' conserved release energy');
  close(result.totalEnergy, result.kineticEnergy + result.potentialEnergy, label + ' total energy components');
  close(result.energyResidual, result.totalEnergy - result.releaseEnergy, label + ' residual');
  close(result.frequency * result.period, 1, label + ' reciprocal period');
  close(result.time / result.period, p.phaseDegrees / 360, label + ' elapsed cycle fraction');
  close(result.period, 2 * Math.PI * Math.sqrt(p.massKg / p.stiffnessNPerM), label + ' natural period');
  close(result.releaseEnergy, p.stiffnessNPerM * (p.amplitudeM ** 2) / 2, label + ' prepared energy');
  close(result.kineticEnergy, p.massKg * (result.velocity ** 2) / 2, label + ' kinetic dimensions');
  close(result.potentialEnergy, p.stiffnessNPerM * (result.position ** 2) / 2, label + ' potential dimensions');
  ok(result.kineticEnergy >= 0 && result.potentialEnergy >= 0 && result.releaseEnergy >= 0, label + ' nonnegative energies');
  ok(result.omega > 0 && result.period > 0 && result.frequency > 0, label + ' positive natural properties');
}
for (const vector of plan.vectors) run('analytical/' + vector.id, () => {
  const input = { ...vector.input }, saved = { ...input };
  const result = inspectOscillator(input);
  observations[vector.id] = result;
  equal(input, saved, 'caller input unchanged');
  equal(result.input, saved, 'admitted input values');
  for (const [field, expected] of Object.entries(vector.expected)) close(result[field], expected, vector.id + '/' + field);
  for (const field of vector.exact_zero_fields || []) ok(result[field] === 0, vector.id + '/' + field + ' exact cardinal zero');
  invariants(result, vector.id);
});
const corners = [];
run('inclusive-boundaries/all-corners', () => {
  for (const massKg of plan.boundary_plan.massKg)
    for (const stiffnessNPerM of plan.boundary_plan.stiffnessNPerM)
      for (const amplitudeM of plan.boundary_plan.amplitudeM)
        for (const phaseDegrees of plan.boundary_plan.phaseDegrees) {
          const input = { massKg, stiffnessNPerM, amplitudeM, phaseDegrees };
          const result = inspectOscillator(input);
          equal(result.input, input, 'boundary values retained');
          invariants(result, JSON.stringify(input));
          corners.push(result);
        }
});
run('zero-amplitude/rest-and-natural-period', () => {
  for (const phaseDegrees of plan.boundary_plan.zero_amplitude_phases) {
    const result = inspectOscillator({ massKg: 0.5, stiffnessNPerM: 8, amplitudeM: 0, phaseDegrees });
    for (const field of ['position','velocity','acceleration','force','kineticEnergy','potentialEnergy','totalEnergy','releaseEnergy','energyResidual'])
      ok(result[field] === 0, field + ' exactly zero at phase ' + phaseDegrees);
    close(result.omega, 4, 'rest natural omega');
    close(result.period, Math.PI / 2, 'rest natural period');
    close(result.frequency, 2 / Math.PI, 'rest natural frequency');
  }
});
const base = plan.metamorphic_plan.base;
const baseObservation = inspectOscillator(base);
const scaling = {
  mass: { input: { ...base, massKg: base.massKg * 4 }, factors: { omega: .5, period: 2, frequency: .5, time: 2, position: 1, velocity: .5, acceleration: .25, force: 1, kineticEnergy: 1, potentialEnergy: 1, totalEnergy: 1, releaseEnergy: 1 } },
  stiffness: { input: { ...base, stiffnessNPerM: base.stiffnessNPerM * 4 }, factors: { omega: 2, period: .5, frequency: 2, time: .5, position: 1, velocity: 2, acceleration: 4, force: 4, kineticEnergy: 4, potentialEnergy: 4, totalEnergy: 4, releaseEnergy: 4 } },
  amplitude: { input: { ...base, amplitudeM: base.amplitudeM * 2 }, factors: { omega: 1, period: 1, frequency: 1, time: 1, position: 2, velocity: 2, acceleration: 2, force: 2, kineticEnergy: 4, potentialEnergy: 4, totalEnergy: 4, releaseEnergy: 4 } },
};
for (const [name, control] of Object.entries(scaling)) run('independent-scaling/' + name, () => {
  const result = inspectOscillator(control.input);
  for (const [field, factor] of Object.entries(control.factors)) close(result[field], baseObservation[field] * factor, name + '/' + field);
  invariants(result, name);
});
const cycleInput = { massKg: 3, stiffnessNPerM: 12, amplitudeM: .4, phaseDegrees: 135 };
let cycle;
run('complete-cycle/73-observations', () => {
  const input = { ...cycleInput };
  cycle = sampleOscillatorCycle(input);
  equal(input, cycleInput, 'cycle input remains applied phase');
  ok(Array.isArray(cycle), 'cycle is direct array');
  equal(cycle.length, 73, 'cycle size');
  for (let i = 0; i < cycle.length; i++) {
    const expectedInput = { ...cycleInput, phaseDegrees: i * 5 };
    equal(cycle[i].input, expectedInput, 'ordered cycle input ' + i);
    invariants(cycle[i], 'cycle/' + i);
    equal(cycle[i], inspectOscillator(expectedInput), 'row equals its direct observation ' + i);
    if ([0,180,360].includes(i * 5)) {
      ok(cycle[i].velocity === 0 && cycle[i].kineticEnergy === 0, 'turning-point exact zero ' + i);
    } else if ([90,270].includes(i * 5)) {
      for (const field of ['position','force','acceleration','potentialEnergy']) ok(cycle[i][field] === 0, 'equilibrium zero ' + field);
    }
  }
  for (const field of numericKeys.filter(key => key !== 'time')) close(cycle[72][field], cycle[0][field], 'periodic endpoint/' + field);
  close(cycle[72].time - cycle[0].time, cycle[0].period, 'endpoints separated by one natural period');
});
const accepted = { massKg: 2, stiffnessNPerM: 32, amplitudeM: .2, phaseDegrees: 90 };
const functions = [inspectOscillator, sampleOscillatorCycle, serializeOscillatorExperiment];
const badWhole = [null, undefined, false, true, 4, 'inputs', [], [1,2,3,4]];
for (let i = 0; i < badWhole.length; i++) run('numeric-refusal/whole-' + i, () => {
  for (const fn of functions) rejects(() => fn(badWhole[i]), fn.name + ' rejects invalid whole input');
});
const badFields = [
  ['missing', undefined], ['null', null], ['false', false], ['true', true],
  ['numeric-string', '2'], ['NaN', NaN], ['infinity', Infinity], ['minus-infinity', -Infinity],
  ['object', {}], ['array', []], ['bigint', 2n], ['symbol', Symbol('independent-refusal')],
];
for (const key of Object.keys(accepted)) for (const [label, bad] of badFields) run('numeric-refusal/' + key + '/' + label, () => {
  const input = { ...accepted, [key]: bad };
  if (label === 'missing') delete input[key];
  for (const fn of functions) rejects(() => fn(input), fn.name + ' rejects ' + key + '/' + label);
});
function adjacentPositive(value, direction) {
  if (value === 0) return direction * Number.MIN_VALUE;
  const buffer = new ArrayBuffer(8), view = new DataView(buffer);
  view.setFloat64(0, value);
  view.setBigUint64(0, view.getBigUint64(0) + BigInt(direction));
  return view.getFloat64(0);
}
const bounds = { massKg: [.1,10], stiffnessNPerM: [1,200], amplitudeM: [0,.5], phaseDegrees: [0,360] };
for (const [key, [low, high]] of Object.entries(bounds)) for (const [label, value] of [['below', adjacentPositive(low,-1)], ['above', adjacentPositive(high,1)]]) run('numeric-refusal/' + key + '/' + label, () => {
  const input = { ...accepted, [key]: value };
  for (const fn of functions) rejects(() => fn(input), fn.name + ' rejects adjacent bound value ' + value);
});
for (const [i, control] of plan.text_positive_controls.entries()) run('text-admission/decimal-exponent-' + i, () => {
  equal(parseOscillatorInput(control.fields), control.expected, 'exact admitted decimal values');
});
const textBase = { massKg: '2', stiffnessNPerM: '32', amplitudeM: '.2', phaseDegrees: '90' };
const badText = [
  ['empty',''], ['blank',' \t\r\n'], ['missing',undefined], ['null',null], ['number',2], ['boolean',true], ['array',[]], ['object',{}],
  ['NaN','NaN'], ['infinity','Infinity'], ['negative-infinity','-Infinity'], ['overflow','1e309'],
  ['hex','0x1'], ['binary','0b1'], ['underscore','1_0'], ['suffix','1m'], ['two-dots','1.2.3'],
  ['dot','.'], ['double-minus','--1'], ['mixed-sign','+-1'], ['missing-exponent','1e'], ['missing-exponent-digits','1e+'],
];
for (const key of Object.keys(textBase)) for (const [label, value] of badText) run('text-refusal/' + key + '/' + label, () => {
  const input = { ...textBase, [key]: value };
  if (label === 'missing') delete input[key];
  rejects(() => parseOscillatorInput(input), key + '/' + label);
});
for (const [key, [low, high]] of Object.entries(bounds)) for (const [label, value] of [['below', adjacentPositive(low,-1)], ['above', adjacentPositive(high,1)]]) run('text-refusal/' + key + '/' + label, () => {
  rejects(() => parseOscillatorInput({ ...textBase, [key]: String(value) }), key + '/' + label + ' text');
});
run('text-admission/exact-length-boundary', () => {
  equal(plan.text_length_boundary.valid64.length, 64, 'frozen valid text length');
  equal(plan.text_length_boundary.invalid65.length, 65, 'frozen invalid text length');
  const admitted = parseOscillatorInput({ ...textBase, amplitudeM: plan.text_length_boundary.valid64 });
  close(admitted.amplitudeM / 1e-62, 1, '64-character decimal value');
  rejects(() => parseOscillatorInput({ ...textBase, amplitudeM: plan.text_length_boundary.invalid65 }), '65-character decimal refused');
});
let serialized;
run('serialization/deterministic-complete-SI-observation', () => {
  const input = { ...cycleInput }, previous = { ...input };
  serialized = serializeOscillatorExperiment(input);
  ok(typeof serialized === 'string' && serialized.endsWith('\n') && !serialized.endsWith('\n\n'), 'JSON text and one final LF');
  equal(serialized, serializeOscillatorExperiment(input), 'deterministic serialization');
  equal(input, previous, 'serialization input unchanged');
  const exported = JSON.parse(serialized);
  equal(exported.format, 'recallweave-spring-energy-observation/1', 'public schema');
  equal(exported.input, previous, 'exact applied input');
  equal(exported.observation, inspectOscillator(previous), 'exact applied observation');
  equal(exported.cycle, cycle, 'complete cycle, no rounded/replaced values');
  const units = { massKg:'kg', stiffnessNPerM:'N/m', amplitudeM:'m', phaseDegrees:'degrees', omega:'rad/s', period:'s', frequency:'Hz', time:'s', position:'m', velocity:'m/s', acceleration:'m/s^2', force:'N', kineticEnergy:'J', potentialEnergy:'J', totalEnergy:'J', releaseEnergy:'J', energyResidual:'J' };
  equal(exported.units, units, 'SI dimensions for every exported numeric field');
  ok(Array.isArray(exported.assumptions) && exported.assumptions.length > 0 && exported.assumptions.every(value => typeof value === 'string' && value.length > 0), 'explicit textual assumptions');
  const oldObservation = inspectOscillator(input), oldText = serialized;
  input.massKg = 6;
  equal(oldObservation.input, previous, 'accepted observation does not alias caller input');
  equal(JSON.parse(oldText).input, previous, 'earlier saved experiment remains unchanged');
});
const after = Object.keys(pins).map(identity);
run('preservation/exact-source-and-freezes', () => equal(after, before, 'all six source/contract/freeze files unchanged'));
if (serialized) fs.writeFileSync(path.join(own, 'independent-export.json'), serialized, { flag: 'wx' });
const report = {
  classification: 'Independent numerical native receiving, frozen analytical plan before candidate-source exposure; no browser or deployment claim',
  model: pins['source/src/spring-energy.mjs'],
  runtime: { node: process.version, executable: process.execPath, platform: process.platform, arch: process.arch },
  plan: before.find(row => row.path.endsWith('numerical-plan-before-source.json')),
  receiver: identity('qa/independent-mac/independent-numerical.mjs'),
  executed_at_utc: new Date().toISOString(),
  counts: { groups: rows.length, passed: rows.filter(row => row.passed).length, failed: rows.filter(row => !row.passed).length, assertions: assertionCount },
  groups: rows,
  analytical_observations: observations,
  boundary_observations: corners,
  cycle_summary: cycle ? { rows: cycle.length, maximum_absolute_energy_residual: Math.max(...cycle.map(row => Math.abs(row.energyResidual))) } : null,
  export: serialized ? identity('qa/independent-mac/independent-export.json') : null,
  before, after,
};
fs.writeFileSync(path.join(own, 'independent-numerical-receipt.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ counts: report.counts, failures: rows.filter(row => !row.passed), cycle_summary: report.cycle_summary, receiver: report.receiver, export: report.export, receipt: identity('qa/independent-mac/independent-numerical-receipt.json') }, null, 2));
process.exitCode = report.counts.failed ? 1 : 0;
