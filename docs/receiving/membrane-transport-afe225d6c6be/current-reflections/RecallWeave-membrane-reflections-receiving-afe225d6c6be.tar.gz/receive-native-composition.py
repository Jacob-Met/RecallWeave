from pathlib import Path
import subprocess,json,os,hashlib,shutil
root=Path('/dev/recall-root-afe225d6c6be');root.mkdir(exist_ok=False)
fs=os.statvfs(root);assert fs.f_bavail*fs.f_frsize>150*1024*1024
repo=root/'reference';repo.mkdir();out=root/'receiving-reflections';out.mkdir()
def git(*args,**kw):return subprocess.check_output(['git',*args],cwd=repo,stderr=subprocess.PIPE,**kw)
git('init');git('config','user.name','HAMON estate afe225d6c6be');git('config','user.email','afe225d6c6be@hamon.invalid')
bundle=root/'membrane-pr26-current-8b82cf5.bundle';b=Path('/dev/shm/hamon-afe225d6c6be-coordination-membrane-final/publication/membrane-pr26-current-8b82cf5.bundle').read_bytes();assert len(b)==832570 and hashlib.sha256(b).hexdigest()=='6a35967a0bc67ff2db1eee129769279c8c53bb4f8728992bd1fdcd741698b5ef';bundle.write_bytes(b)
env=os.environ.copy();env['GIT_TERMINAL_PROMPT']='0'
for sha,depth in [('3b3f09efbf22406a6630288ab8defe1be1f0d8c1',1),('4fb270aebc1b93322059911ddfe1febca38fbfa7',1),('8b82cf5bb95fc7faa5e835e2979df703e6e91a7b',1),('3cdebd86e69506709bcaeaeff4026deb3d1fc208',20)]:
 p=subprocess.run(['git','fetch','--depth',str(depth),'--no-tags','https://github.com/Jacob-Met/RecallWeave.git',sha],cwd=repo,env=env,capture_output=True,text=True);(out/('fetch-'+sha+'.log')).write_text(p.stdout+p.stderr)
 assert p.returncode==0,{'sha':sha,'exit':p.returncode,'tail':(p.stdout+p.stderr)[-1500:]}
 assert git('rev-parse',sha+'^{commit}').decode().strip()==sha
 print(json.dumps({'fetched':sha,'tree':git('rev-parse',sha+'^{tree}').decode().strip()}),flush=True)
p=subprocess.run(['git','bundle','verify',str(bundle)],cwd=repo,capture_output=True,text=True);(out/'bundle-verify.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout+p.stderr
git('fetch',str(bundle),'refs/heads/receiving-membrane-current-8b82cf5-afe225d6c6be:refs/heads/received-current-8b')
assert git('rev-parse','received-current-8b^{tree}').decode().strip()=='1130d0b1dc59e24b9541584d1805350c2f3a8b97'
git('checkout','-b','membrane-reflections-receiving','received-current-8b')
p=subprocess.run(['git','merge','--no-ff','--no-edit','3cdebd86e69506709bcaeaeff4026deb3d1fc208'],cwd=repo,capture_output=True,text=True);(out/'merge.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout+p.stderr
head=git('rev-parse','HEAD').decode().strip();tree=git('write-tree').decode().strip()
git('merge-base','--is-ancestor','3cdebd86e69506709bcaeaeff4026deb3d1fc208',head);git('merge-base','--is-ancestor','3b3f09efbf22406a6630288ab8defe1be1f0d8c1',head);assert not git('status','--porcelain').strip()
def pins(ref):
 result={}
 for item in git('ls-tree','-r','-z','-l',ref).split(bytes([0])):
  if not item:continue
  meta,path=item.split(bytes([9]),1);mode,kind,sha,size=meta.decode().split();assert kind=='blob';path=path.decode();result[path]={'path':path,'mode':mode,'git_blob':sha,'bytes':int(size)}
 return result
old=pins('61e3554d65d2ae78caaa6530995f0071ca4798e4');base=pins('3cdebd86e69506709bcaeaeff4026deb3d1fc208');new=pins(head)
ours=git('diff','--name-only','8b82cf5bb95fc7faa5e835e2979df703e6e91a7b','61e3554d65d2ae78caaa6530995f0071ca4798e4').decode().splitlines()
assert len(base)==871 and len(new)==931 and len(ours)==60
for name,pin in base.items():assert new[name]==pin,name
for name in ours:assert new[name]==old[name],name
assert not [x for x in new if x=='AGENTS.md' or x.endswith('/AGENTS.md')]
receipt={'kind':'Current reflections composition requires fresh membrane consumer receiving','base':'3cdebd86e69506709bcaeaeff4026deb3d1fc208','baseTree':'4d8cfac84b84818af1a7e13cfa4d569fdbbef2d6','priorNativeCandidate':'61e3554d65d2ae78caaa6530995f0071ca4798e4','nativeHead':head,'nativeTree':tree,'nativeParents':git('show','-s','--format=%P',head).decode().split(),'baseLeaves':len(base),'composedLeaves':len(new),'allBaseLeavesPreserved':len(base),'allPriorContributionPathsPreserved':len(ours),'contributionPaths':ours,'allBasePins':list(base.values()),'allComposedPins':list(new.values()),'consumerChanges':git('diff','--name-only','8b82cf5bb95fc7faa5e835e2979df703e6e91a7b','3cdebd86e69506709bcaeaeff4026deb3d1fc208','--','src','demo.html','styles.css','tools/make_demo.py').decode().splitlines(),'browserReceiving':'pending; historical consumer pass is retained and not relabeled as current'}
raw=json.dumps(receipt,indent=2,sort_keys=True).encode()+bytes([10]);(out/'source-freeze.json').write_bytes(raw)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['allBasePins','allComposedPins','contributionPaths']}),flush=True)
print(json.dumps({'sourceFreezeBytes':len(raw),'sourceFreezeSha256':hashlib.sha256(raw).hexdigest()}),flush=True)
