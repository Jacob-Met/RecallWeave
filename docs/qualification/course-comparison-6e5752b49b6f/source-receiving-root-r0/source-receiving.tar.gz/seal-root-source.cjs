const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),c=require('node:crypto'),assert=require('node:assert/strict'),os=require('node:os');
const ROOT=String.raw`C:\Users\minec\AppData\Local\Hamon\estate-6e5752b49b6f`;
const OUT=path.join(ROOT,'recall180-root-source-receiving-r0.tar.gz');
const hash=b=>c.createHash('sha256').update(b).digest('hex');
const blob=b=>c.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex');
const entries=[];
for(const [prefix,folder]of [['renderer-r0','course-comparison-source-receiving-root-r0'],['renderer-r1','course-comparison-source-receiving-root-r1']]){
 const base=path.join(ROOT,folder);
 for(const name of fs.readdirSync(base).sort()){
  const absolute=path.join(base,name),st=fs.lstatSync(absolute);if(!st.isFile())continue;
  const bytes=fs.readFileSync(absolute);entries.push({name:prefix+'/'+name,absolute,bytes,mtimeMs:st.mtimeMs});
 }
}
const selfBytes=fs.readFileSync(__filename);entries.push({name:'seal-root-source.cjs',absolute:__filename,bytes:selfBytes,mtimeMs:fs.lstatSync(__filename).mtimeMs});
assert.ok(entries.length>=25&&entries.length<45);assert.equal(new Set(entries.map(e=>e.name)).size,entries.length);
const manifest={schema:'hamon-native-exact-source-custody/1',worker:'estate-6e5752b49b6f/root',created:new Date().toISOString(),purpose:'Exact original consumer180 source receiving, source corrections, isolated loader execution, README append proof and both retained pre-Chrome resource refusals. No actual177 comparison or full browser acceptance.',files:entries.map(e=>({path:e.name,bytes:e.bytes.length,sha256:hash(e.bytes),gitBlob:blob(e.bytes)}))};
const manifestBytes=Buffer.from(JSON.stringify(manifest,null,2)+'\n');entries.push({name:'packet-manifest.json',bytes:manifestBytes});
function header(name,size){assert.ok(Buffer.byteLength(name)<=100&&!name.startsWith('/')&&!name.split('/').includes('..'));const h=Buffer.alloc(512);h.write(name,0);const oct=(v,n)=>v.toString(8).padStart(n-1,'0')+'\0';h.write(oct(0o644,8),100);h.write(oct(0,8),108);h.write(oct(0,8),116);h.write(oct(size,12),124);h.write(oct(0,12),136);h.fill(32,148,156);h[156]=48;h.write('ustar\0',257);h.write('00',263);let sum=0;for(const x of h)sum+=x;h.write(sum.toString(8).padStart(6,'0')+'\0 ',148);return h;}
const blocks=[];for(const e of entries){blocks.push(header(e.name,e.bytes.length),e.bytes,Buffer.alloc((512-e.bytes.length%512)%512));}blocks.push(Buffer.alloc(1024));
const archive=z.gzipSync(Buffer.concat(blocks),{level:9,mtime:0});
fs.writeFileSync(OUT,archive,{flag:'wx'});assert.ok(fs.readFileSync(OUT).equals(archive));
const decoded=z.gunzipSync(archive);let offset=0,seen=0;
while(offset<decoded.length){const h=decoded.subarray(offset,offset+512);if(h.every(v=>v===0))break;const s=h.toString('ascii',148,156).replace(/\0.*$/,'').trim(),stored=parseInt(s,8),copy=Buffer.from(h);copy.fill(32,148,156);let sum=0;for(const b of copy)sum+=b;assert.equal(sum,stored);const name=h.toString('utf8',0,100).split('\0')[0],size=parseInt(h.toString('ascii',124,136).split('\0')[0].trim(),8);assert.equal(String.fromCharCode(h[156]),'0');const entry=entries.find(e=>e.name===name);assert.ok(entry);const raw=decoded.subarray(offset+512,offset+512+size);assert.ok(raw.equals(entry.bytes));offset+=512+Math.ceil(size/512)*512;seen++;}
assert.equal(seen,entries.length);assert.ok(decoded.subarray(offset).every(b=>b===0));
for(const e of entries.filter(e=>e.absolute)){const st=fs.lstatSync(e.absolute);assert.equal(st.mtimeMs,e.mtimeMs);assert.ok(fs.readFileSync(e.absolute).equals(e.bytes));}
const encoded=archive.toString('base64').match(/.{1,76}/g).join('\n')+'\n';
fs.writeFileSync(OUT+'.base64',encoded,{flag:'wx'});
const receipt={schema:'recall180-root-source-native-packet/1',accepted:true,identity:{host:os.hostname(),user:os.userInfo().username,node:process.version},artifact:{path:OUT,bytes:archive.length,sha256:hash(archive),computedGitBlob:blob(archive)},manifest:{bytes:manifestBytes.length,sha256:hash(manifestBytes),computedGitBlob:blob(manifestBytes)},members:entries.length,originalFilesUnchanged:true,allDecodedHeadersAndMembersExact:true,base64:{path:OUT+'.base64',bytes:Buffer.byteLength(encoded),sha256:hash(Buffer.from(encoded)),computedGitBlob:blob(Buffer.from(encoded))},entries:manifest.files,publishing:'Native only; no Git object/ref, Actions or deployment created.'};
fs.writeFileSync(path.join(ROOT,'recall180-root-source-receiving-r0-index.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({accepted:true,artifact:receipt.artifact,manifest:receipt.manifest,members:receipt.members,filesUnchanged:true}));
