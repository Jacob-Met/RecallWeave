import pathlib,json,hashlib,subprocess,datetime,os,shutil,sys,time
R=pathlib.Path(__file__).resolve().parent
NODE=pathlib.Path('C:/Program Files/nodejs/node.exe')
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 b=v if isinstance(v,bytes) else (json.dumps(v,indent=2)+'\n').encode()
 with p.open('xb') as h:h.write(b)
guard=json.loads(subprocess.check_output(['powershell','-NoProfile','-Command',"[pscustomobject]@{c=(Get-PSDrive C).Free;d=(Get-PSDrive D).Free;memory=[int64](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1024}|ConvertTo-Json -Compress"],text=True,encoding='utf-8'))
assert guard['c']>=2**30 and guard['d']>=2**30 and guard['memory']>=2**31,guard
OUT=R/'author-native-r1';OUT.mkdir(exist_ok=False)
SOURCE=R/'candidate-r1';SOURCE.mkdir(exist_ok=False)
original=json.loads((R/'original-manifest.json').read_text())
records=[];commands=[];error=None
try:
 for item in original:
  b=(R/'original'/item['path']).read_bytes();assert pin(b)=={k:item[k] for k in ('bytes','sha256','git')}
  save(SOURCE/item['path'],b)
 packet=json.loads((R/'candidate-packet-r1.json').read_text(encoding='utf-8'))
 for item in packet['files']:save(SOURCE/item['path'],item['content'].encode())
 def manifest():
  return [dict(path=p.relative_to(SOURCE).as_posix(),**pin(p.read_bytes())) for p in sorted(SOURCE.rglob('*')) if p.is_file()]
 before=manifest();save(OUT/'before.json',before)
 for name,args in [('build',['tools/build-sorting-networks.mjs']),('build-check',['tools/build-sorting-networks.mjs','--check']),('syntax-core',['--check','courses/sorting-networks-core.mjs']),('syntax-ui',['--check','courses/sorting-networks-explorer-ui.mjs']),('model',['--test','tests/sorting-networks.test.mjs'])]:
  t=time.monotonic()
  with (OUT/(name+'.stdout')).open('xb') as out,(OUT/(name+'.stderr')).open('xb') as err:
   child=subprocess.Popen([str(NODE),*args],cwd=SOURCE,stdout=out,stderr=err)
   try:code=child.wait(timeout=60)
   except subprocess.TimeoutExpired:
    child.terminate();child.wait(timeout=10);raise
  commands.append(dict(name=name,argv=[str(NODE),*args],cwd=str(SOURCE),pid=child.pid,exit=code,seconds=time.monotonic()-t))
  if code!=0:raise RuntimeError(name+' failed: '+str(code))
 after=manifest()
 for item in before:
  assert next(x for x in after if x['path']==item['path'])==item,item['path']
 assert [x['path'] for x in after if x['path'] not in {q['path'] for q in before}]==['courses/sorting-networks-explorer.html']
 save(R/'candidate-manifest-r1.json',after)
except BaseException as e:
 error=repr(e)
finally:
 receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),guard=guard,node=pin(NODE.read_bytes()),commands=commands,error=error,passed=error is None)
 save(OUT/'receipt.json',receipt)
 print(json.dumps(receipt))
sys.exit(0 if error is None else 1)
