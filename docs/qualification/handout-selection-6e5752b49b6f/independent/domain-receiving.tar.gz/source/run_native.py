import pathlib,json,hashlib,subprocess,time,shutil,os
R=pathlib.Path('/tmp/recallweave-handout-receiving-6e5752b49b6f-native')
C=pathlib.Path('/tmp/recallweave-handout-selection-6e5752b49b6f-production/candidate')
meta=json.loads("{\n  \"format\": \"recallweave170-source-admission/1\",\n  \"repository\": \"https://github.com/Jacob-Met/RecallWeave\",\n  \"issue\": 170,\n  \"head\": \"35ba3fe7a611395016fc5c808604ea1a815dc81b\",\n  \"tree\": \"8c509b174be3e799d2265558c9e0b3720b0b63ad\",\n  \"parent\": \"698902f9c9c1d5c5023092b85b3632a7cb7a01ed\",\n  \"parentLeaves\": 2915,\n  \"untouched\": 2909,\n  \"modified\": 6,\n  \"added\": 1,\n  \"total\": 2916,\n  \"files\": [\n    {\n      \"path\": \"README.md\",\n      \"bytes\": 51905,\n      \"sha256\": \"da488b206e5b853469e1c3565182d29f0829ae02ff3bc94bcda8e82ac4506a1b\",\n      \"gitBlob\": \"464caf5854cb1eef0496e35a7054395bab0b60b7\"\n    },\n    {\n      \"path\": \"handout/handout.css\",\n      \"bytes\": 7651,\n      \"sha256\": \"c5d9d6ed8d7bb1f9c642fb8ea7ccb467afc05b6c48c36b8d310f4a6387513a3b\",\n      \"gitBlob\": \"59e0239ec4f43f603be4a91778433c9a2e9cfdd3\"\n    },\n    {\n      \"path\": \"handout/index.html\",\n      \"bytes\": 6312,\n      \"sha256\": \"c8ceec08fda5e110d7f498a9848ff17dbb1654666bc243de0a26b77bdc5466e2\",\n      \"gitBlob\": \"57d8fc708f336eb7c637a38ae5cac9c76152a75a\"\n    },\n    {\n      \"path\": \"handout.html\",\n      \"bytes\": 38458,\n      \"sha256\": \"4bfc049beea5c0156928c11122e42d03f5e2de4dcda5bc46f1241947c8c550a0\",\n      \"gitBlob\": \"901c411bd9c3707a6272df10f785d68be5279bf2\"\n    },\n    {\n      \"path\": \"src/course-handout-ui.mjs\",\n      \"bytes\": 7443,\n      \"sha256\": \"fc0631c9b78ee1c648baa2d39358951817049814b3d8e6b96f9733ffc8cca1fc\",\n      \"gitBlob\": \"d3f725b6cf0dce6e135e6ba497947a2e811d2206\"\n    },\n    {\n      \"path\": \"src/course-handout.mjs\",\n      \"bytes\": 11748,\n      \"sha256\": \"018e0d4195b9fbbbba19bb076bf20cd25d5793731508a54bcc9d7c17d04f10af\",\n      \"gitBlob\": \"4b535e29bc59da9fa2f2a74bf99da9220db45009\"\n    },\n    {\n      \"path\": \"tests/course-handout-selection.test.mjs\",\n      \"bytes\": 7625,\n      \"sha256\": \"95fa579d72e8a6a3aba4d10630dc19e89393f2622911ac38fa70ba29c737ff2b\",\n      \"gitBlob\": \"1e6b392b04977e6a021ed4d15a20bfdfe58c585c\"\n    }\n  ],\n  \"baselineValidator\": {\n    \"gitBlob\": \"f0f8a4b234489c2388f427633f548d56c6ed4c03\",\n    \"sha256\": \"621438c166ec4bfafd9d87c698a1d46cb1722f4fb92dcbb8d9f52fce682c338b\"\n  },\n  \"ownership\": {\n    \"claim\": \"https://github.com/Jacob-Met/RecallWeave/issues/170\",\n    \"completedOwnerHandoff\": \"https://github.com/Jacob-Met/RecallWeave/issues/35#issuecomment-6069368496\",\n    \"advisoryLimit\": \"440 coordination records examined; 21 PermissionError records were unreadable and remain unknown. No permission bypass or abandonment inference.\"\n  }\n}\n")
(R/'candidate-source-admission.json').write_text(json.dumps(meta,indent=2)+'\n')
def rec(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
admitted=[]
for x in meta['files']:
 p=C/x['path'];row=rec(p);assert row['bytes']==x['bytes'] and row['sha256']==x['sha256'] and row['git_blob']==x['gitBlob'],str(p);admitted.append(row)
p=C/'src/deck.mjs';row=rec(p);assert row['sha256']==meta['baselineValidator']['sha256'] and row['git_blob']==meta['baselineValidator']['gitBlob'];admitted.append(row)
for p in [R/'source/receive_model.mjs',R/'baseline/src/course-handout.mjs',R/'baseline/src/deck.mjs',pathlib.Path('/usr/bin/node')]:admitted.append(rec(p))
assert admitted[-4]['sha256']=='1b114508a110dc529da28aed7c37a2f7f963611646e888f07211acf1e8410228'
assert admitted[-1]['sha256']=='d0efb6fcb9d023ba4e2b160ec2384dc28fe4f17732141ef47f676828fa960505'
assert shutil.disk_usage(R).free>=10_000_000
cmd=['/usr/bin/node',str(R/'source/receive_model.mjs'),str(R/'baseline'),str(C),str(R/'run-r1')]
started=time.monotonic()
try:
 p=subprocess.run(cmd,capture_output=True,timeout=30);code=p.returncode;stdout=p.stdout;stderr=p.stderr;timed=False
except subprocess.TimeoutExpired as e:
 code=None;stdout=e.stdout or b'';stderr=e.stderr or b'';timed=True
(R/'run-r1.stdout').write_bytes(stdout);(R/'run-r1.stderr').write_bytes(stderr)
after=[rec(pathlib.Path(x['path'])) for x in admitted]
receipt={'argv':cmd,'exit_code':code,'timeout':timed,'seconds':time.monotonic()-started,'uid':os.getuid(),'admitted':admitted,'after':after,'unchanged':admitted==after,'stdout':rec(R/'run-r1.stdout'),'stderr':rec(R/'run-r1.stderr')}
(R/'execution-r1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'exit_code':code,'timeout':timed,'seconds':receipt['seconds'],'unchanged':receipt['unchanged'],'stdout':stdout.decode(),'stderr':stderr.decode()}))
assert not timed and code==0 and admitted==after
