# Independent DC course acceptance

Reviewer: estate_source, cohort chatgpt-astra-bd1abdb2f886-20261008.

## Accepted source

| Artifact | SHA-256 |
| --- | --- |
| Circuit model | b8a94b617e2285f8e07229f256d8c2f1c1fcbe53a6e8045f1d816e74d7fb9ba8 |
| Authored course JSON | cfe7a4586a4a97aa96356e9afe7fea5bc1e216a0aff70454476397c909058ccb |
| Corrected explorer UI | 2ea06bb70830b8d600c32c3d3192876f36aed9860fdea5d664bfe38e0f088f91 |
| Explorer template | a1af554df93dae1d58f37fb1d5f2c13694eae3e5bd3905eee470a02796adcb8b |
| Built explorer | 94dc6ea2c450bbbdd1f2ec3210c30948c0c8e9b5c974d7d1d728cb7547aee3c4 |
| Final guide | c3262be7f16448b8da30716169cee424efe3200290bee78a1ad2ca7acf83fa93 |
| Maintained learner demo.html at d202fdc8b3608c5321f83e1bf6f9a2ceb253f14b | d0819e8630ff119be2c078408907ab53e3725999c8fdf71d35deb7f230d3bcd9 |

## Independent physics and course review

Before seeing the key or explanations, I froze the 12 zero-based choices [1,2,0,3,2,0,3,1,0,2,1,3]. All match the authored key. I subsequently read all explanations, independently solved all 12 transfer prompts, and reviewed the ideal-source, fixed-ohmic-resistor, steady-state and zero-resistance-wire assumptions, quantities and units.

The original native ThinkPad model/deck-codec run completed once under Node v22.22.1, Linux x64. Six receiving groups passed. They cover six admitted manual oracle vectors, 80 admitted input triples (160 connection results), six changed-input comparisons, 27 strict numeric-object refusals, 21 text refusals and eight valid text values, CSV physical values/recomputation, and the actual maintained deck validator/serializer. Four out-of-domain oracle vectors were represented by two distinct refusals; four vectors requiring another arity were explicitly excluded. The full 14-vector rational self-check is an oracle audit. Native receipt: 6cdfa5a8e85341e8846b0cb55f4271bfdc866f4bc0281c1d82e29e3ff1614d71. No numerical-source correction or repeat run was required.

## Scientific presentation and guide

I identified the original compound SVG paths' marker-end issue from source and the SVG specification: only the final vertex of each whole path receives the end marker. The successor changes exactly two string lines into two separate series arrow paths and three parallel arrow paths. All other UI bytes match the original. Its source polarity, unbranched series loop, two parallel nodes, arrow directions, zero-voltage treatment and labels are coherent. Original UI, finding, corrected UI and exact patch are preserved.

The complete initial guide's worked examples and all answer/transfer explanations were accepted. A subsequent full-byte comparison proved the final guide changes only the importer-usage paragraph into the two recorded usage paragraphs. Scientific content remains identical. Native source/built-HTML readback matched the table above. Explorer visual/browser execution is documented by the separate estate_production receiving lane.

## Actual DC course consumer

I froze the distinct learner contract before inspecting the maintained learner source. The actual explorer-downloaded JSON was copied unchanged from the ThinkPad receiving witness. Thirteen relevant ThinkPad learner/source files matched published main d202fdc8b3608c5321f83e1bf6f9a2ceb253f14b; their pins remain the source-chain record.

No learner browser was launched on ThinkPad after its home filesystem reached zero free bytes. The original receiving driver, zero-byte wrapper-write readback and successful normal retry are preserved. The supported Mac route changed only recorded paths, the Chrome launcher and standalone-source provenance handling. The original behavioral assertions and helper bytes are unchanged.

The first actual consumer run used Node v26.3.0 on macOS arm64 and installed Chrome 154.0.8037.98, executing the exact maintained standalone demo.html directly through file:// in a dedicated profile. Transferred learner, actual downloaded JSON and final guide matched their SHA-256 and Git blob identities. This qualifies the standalone Mac surface; the 13 ThinkPad modular/source pins document its provenance.

All six receiving groups passed, with process exit 0 in 12.815828958 seconds:

- A committed bundled-course response, complete session markup, course context, progress and model displays survived DC preview and cancellation unchanged. The maintained session is held in tab memory; browser storage remained empty.
- Explicit Start activated the 12-question DC course and cleared the prior course's progress.
- All 12 canonical first responses were selected by their visible semantic values. The intentional 75 A response to dc-current-1 remained the sole first miss: 11 of 12 first responses were correct.
- A separate correct 3 A retry preserved the original first-response summary, first miss and model displays.
- The actual 9,988-byte study-notes file preserved every authored question, explanation and transfer prompt, all 12 recorded first answers and the distinct correct retry. SHA-256: d7338a9352ca1e99f2175db5771a64edfd092facb1f5453dd794df5603580b60.
- The browser reported no page errors or nonlocal requests. Executed source and course bytes were unchanged; the dedicated profile was removed.

Mac driver: f7b887bbab24fb36b6b68c4e7bf0f03409fa6690e4ce77a8830f1992ca66c356.
Mac native receipt: 672e7e62bb9934f9416966fa9e05e50389dbd5e88d4b4698750c8b7b2815b402.
Frozen consumer contract: 9bbd951d4e7e7a3ac1ddb2732ea8a9a68c3252daa27a8d5b3c881f6fc84cea30.

No behavioral assertion correction or additional browser run was needed. No production source was edited by this review lane. This acceptance binds the source identities above; the parent will provide the complete published PR head for the final conversation binding.

## Evidence layout

The archive contains original physics/blind/native receipts under physics/, original and corrected presentation evidence under presentation/, the consumer contract, environment adaptation, drivers and original Mac results under consumer/, and exact transferred execution inputs under executed-source/. MANIFEST.json records the SHA-256 and byte count of every other member. Profiles, browser caches and unrelated files are excluded.

Primary background and specification:
- https://openstax.org/books/university-physics-volume-2/pages/10-2-resistors-in-series-and-parallel
- https://openstax.org/books/university-physics-volume-2/pages/9-5-electrical-energy-and-power
- https://www.w3.org/TR/SVG2/painting.html#MarkerEndProperty
