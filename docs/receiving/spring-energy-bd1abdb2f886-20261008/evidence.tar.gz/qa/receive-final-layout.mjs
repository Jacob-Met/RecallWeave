import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {withBrowser,until,sha} from './browser-helpers-startup60.mjs';
const root='/home/jacob/recallweave-spring-energy-bd1abdb2f886-20261008';
const output=join(root,'qa/final-layout');
if(existsSync(join(output,'browser-report.json')))throw Error('Prior receipt exists.');
const pins={
 'templates/spring-energy-lab.html':'8df4b229cec435bd0d9237c4931cbfb9cfe104956e24aaecc56d53fc52bcb925',
 'courses/spring-energy-lab.html':'4c9d60ec7b75f9f73d8517c86a5641a03de50fa79bc3a8557ace58fcae992786',
 'src/spring-energy-ui.mjs':'a26d6ff2bf4a3486ce4c61dd8d957a11d6660d8f43e3c04e4de8d947477055b1',
 'src/spring-energy.mjs':'a5996337164ffd9d8501a2c376a6bfdc57807ecbce4e5fa2075bbaf78d9010a1',
 'courses/spring-energy.json':'84c87182731e35e036d5c2b2729cee94ae65091336272547e3a791a5cab068cc',
};
for(const[p,h]of Object.entries(pins))assert.equal(sha(await readFile(join(root,'source',p))),h);
await mkdir(output,{recursive:true});await writeFile(join(output,'source-before.json'),JSON.stringify(pins,null,2)+'\n');
const r=await withBrowser({output,profileParent:join(root,'qa')},async b=>{
 await b.navigate('file://'+root+'/source/courses/spring-energy-lab.html');
 await until(()=>b.evaluate('document.querySelector("#cycle-rows")?.children.length===73'),'actual lab');
 const captures=[];
 for(const width of [390,768,1240]){
  await b.viewport(width,950);
  for(const phase of [0,90,180,270]){
   await b.click('[data-phase="'+phase+'"]');
   await b.check('readable diagram and contained page at'+width+'px phase'+phase,async()=>{
    const geometry=await b.evaluate('(()=>{const s=document.querySelector("#motion-diagram"),box=s.getBoundingClientRect();return{width:innerWidth,scrollWidth:document.documentElement.scrollWidth,diagram:{left:box.left,right:box.right,top:box.top,bottom:box.bottom},labels:[...s.querySelectorAll("text")].map(n=>{const r=n.getBoundingClientRect(),m=n.getScreenCTM();return{text:n.textContent,fontPixels:parseFloat(getComputedStyle(n).fontSize)*Math.abs(m.a),left:r.left,right:r.right,top:r.top,bottom:r.bottom}}),phase:document.querySelector("#phase").value,force:document.querySelector("#force-direction").textContent,velocity:document.querySelector("#velocity-direction").textContent}})()');
    assert.equal(geometry.width,width);assert.ok(geometry.scrollWidth<=width);
    assert.equal(geometry.phase,String(phase));
    for(const label of geometry.labels){
     assert.ok(label.fontPixels>=12,label.text+' is '+label.fontPixels+'px');
     assert.ok(label.left>=geometry.diagram.left-1&&label.right<=geometry.diagram.right+1,label.text+' horizontal bounds');
     assert.ok(label.top>=geometry.diagram.top-1&&label.bottom<=geometry.diagram.bottom+1,label.text+' vertical bounds');
    }
    assert.equal(geometry.force,'F: '+({0:'left',90:'zero',180:'right',270:'zero'}[phase]));
    assert.equal(geometry.velocity,'v: '+({0:'zero',90:'left',180:'zero',270:'right'}[phase]));
    b.report.observations.push(geometry);
   });
   if((width===390&&(phase===0||phase===270))||(width===768&&phase===90)||(width===1240&&phase===180)){
    await b.click('#motion-diagram');captures.push(await b.screenshot('diagram-'+width+'-'+phase+'.png'));
   }
  }
 }
 await b.check('final presentation has no page errors or external requests',async()=>{
  assert.equal(b.report.pageErrors.length,0);assert.deepEqual(b.report.requests.filter(x=>/^https?:/.test(x.url)),[]);
 });
 b.report.captures=captures;
});
for(const[p,h]of Object.entries(pins))assert.equal(sha(await readFile(join(root,'source',p))),h);
await writeFile(join(output,'source-after.json'),JSON.stringify({pins,unchanged:true},null,2)+'\n');
console.log(JSON.stringify({status:r.status,checks:r.checks,captures:r.captures,cleanup:r.cleanup}));
process.exitCode=r.status==='passed'?0:1;
