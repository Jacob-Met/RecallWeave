import pathlib,json,base64,hashlib
R=pathlib.Path(__file__).resolve().parent
p=R/'portable-r1/sorting-networks-offline.zip';b=p.read_bytes()
assert hashlib.sha256(b).hexdigest()=='1de74462a7c755b51d6a43ccf75cee492755510eac22c1274341bdae98328c5f'
(R/'portable-r1/API-PAYLOAD.json').write_bytes((json.dumps(dict(base64=base64.b64encode(b).decode(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))+'\n').encode())
print('Prepared exact package transfer')
