import pathlib,json,hashlib,subprocess,datetime,shutil,os,platform,sys
root=pathlib.Path("/home/jacob/chatgpt-recall-refraction-713adaab")
source=root/"source"
def sha(b):return hashlib.sha256(b).hexdigest()
def write_new(p,b):
 with p.open("xb") as f:f.write(b)
def snapshot():
 return {str(p.relative_to(source)):{"bytes":p.stat().st_size,"sha256":sha(p.read_bytes()),"mtime_ns":p.stat().st_mtime_ns} for p in sorted(source.rglob("*")) if p.is_file()}
free=shutil.disk_usage(root).free
if free<32*1024*1024:raise SystemExit("admission_refused: no source preparation/test")
intake=json.loads((root/"canonical-intake.json").read_text())
original=next(f for f in intake["files"] if f["path"]=="README.md")["content"].encode()
assert (source/"README.md").read_bytes()==original,"README is not fresh baseline; do not append twice"
appendix="\n## Refraction and the critical boundary\n\n[Refraction foundations](courses/refraction-foundations.json) is an original 16-question course for the existing local deck picker. Its [worked guide](courses/refraction-foundations.md) connects normal-angle geometry, ordered refractive indices, Snell's law, equal-index and normal-incidence controls, reversibility, and the strict total-internal-reflection threshold. Import the JSON into `demo.html`, preview it, then choose **Start this deck**. Review, separate practice, reflections and study-note downloads use the unchanged learner. The ideal ray model predicts directions; it does not calculate optical power or claim measured learning gains. No catalog registration or new runtime is required.\n".encode()
write_new(root/"readme-appendix.txt",appendix)
(source/"README.md").write_bytes(original+appendix)
reviews=[
("/home/jacob/chatgpt-root-reviews-713adaab/refraction-root-blind-answers.json","root-blind-answers.json","5a7b66701fecfbc05766cc475573f811c7278646a33169c25297fa39c31bf525"),
("/home/jacob/chatgpt-refraction-blind-review-713adaab/independent-answers.json","production-blind-answers.json","e4e0ba06d9f7d4a155cb29f2d03fbcfcae309bc3e61dcdbc59798320efcd2b5d")]
course=json.loads((source/"courses/refraction-foundations.json").read_text())
blind=json.loads((root/"blind-questions.json").read_text())
assert [{k:item[k] for k in ("id","prompt","options")} for item in course["items"]]==blind["items"]
for p,name,pin in reviews:
 b=pathlib.Path(p).read_bytes();assert sha(b)==pin
 write_new(root/"custody"/name,b)
 r=json.loads(b)
 received=[x.get("option_index_zero_based",x.get("index")) for x in r["answers"]]
 assert received==[x["answer"] for x in course["items"]]
for item in intake["files"]:
 if item["path"]!="README.md":assert (source/item["path"]).read_bytes()==item["content"].encode()
assert (source/"README.md").read_bytes()[:-len(appendix)]==original
out=root/"receiving"/"node-r1";out.mkdir()
before=snapshot()
intent={"schema":"recallweave.native-course-receiving/1","started":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":["/usr/bin/node","--test","tests/refraction-course.test.mjs"],"cwd":str(source),"host":platform.node(),"platform":platform.platform(),"uid":os.getuid(),"home_available_bytes":free,"reserve_bytes":32*1024*1024,"timeout_seconds":30,"before":before,"coverage":"six maintained course/unchanged consumer tests; not browser receiving or full-repository suite"}
write_new(out/"intent.json",(json.dumps(intent,indent=2)+"\n").encode())
with (out/"stdout.txt").open("xb") as stdout,(out/"stderr.txt").open("xb") as stderr:
 try:
  p=subprocess.run(intent["command"],cwd=source,stdout=stdout,stderr=stderr,timeout=30,env={**os.environ,"NODE_DISABLE_COLORS":"1"})
  code=p.returncode;timeout=False
 except subprocess.TimeoutExpired:
  code=None;timeout=True
after=snapshot()
report={**intent,"finished":datetime.datetime.now(datetime.timezone.utc).isoformat(),"returncode":code,"timed_out":timeout,"node_version":subprocess.run(["/usr/bin/node","--version"],capture_output=True,text=True,timeout=5).stdout.strip(),"after":after,"source_bytes_and_mtimes_unchanged":before==after,"stdout":{"bytes":(out/"stdout.txt").stat().st_size,"sha256":sha((out/"stdout.txt").read_bytes())},"stderr":{"bytes":(out/"stderr.txt").stat().st_size,"sha256":sha((out/"stderr.txt").read_bytes())},"blind_reviews_match":True,"reviewer_epoch":"Both reviewers received the answer-free packet and froze their derivations before candidate exposure; this receipt compares after those freezes.","readme_inverse_sha256":sha(original),"placement_note":"Initial course write returned explicit ENOENT because the new courses parent did not yet exist. It wrote no course. Only owned parents were then created and the new course was placed."}
write_new(out/"report.json",(json.dumps(report,indent=2)+"\n").encode())
print(json.dumps({"report":str(out/"report.json"),"report_sha256":sha((out/"report.json").read_bytes()),"returncode":code,"timed_out":timeout,"source_unchanged":before==after,"stdout":(out/"stdout.txt").read_text(),"stderr":(out/"stderr.txt").read_text(),"files":before}))
sys.exit(0 if code==0 and before==after else 1)
