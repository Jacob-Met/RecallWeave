import assert from "node:assert/strict";
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, rmSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
const root = dirname(fileURLToPath(import.meta.url));
const candidate = resolve(root, "candidate");
const chrome = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const out = resolve(root, "keyboard-diagnostic");
mkdirSync(out, { recursive: false });
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, label, ms = 15000) {
  const end = Date.now() + ms;
  while (Date.now() < end) { const value = await fn(); if (value) return value; await sleep(80); }
  throw Error("Timed out: " + label);
}
const manifest = JSON.parse(readFileSync(resolve(root, "SOURCE-RECEIPT.json")));
function sourcePins() {
  return manifest.files.map(file => {
    const bytes = readFileSync(resolve(candidate, file.path));
    assert.equal(bytes.length, file.bytes, file.path);
    assert.equal(sha(bytes), file.sha256, file.path);
    return { path: file.path, sha256: file.sha256 };
  });
}
const before = sourcePins();
const admission = JSON.parse(readFileSync(resolve(root, "RUN-ADMISSION.json")));
assert(admission.freeDisk >= 268435456 && admission.freeMemory >= 536870912);
assert.equal(admission.chromeProcessCount, 0);
const receipt = { schema: "recallweave.lp-la7-browser/1", started: new Date().toISOString(), node: process.version,
 executable: process.execPath, platform: process.platform, before, admission, groups: [], checks: 0, errors: [],
 sourceUnchanged: false, status: "running", cleanup: {} };
const check = (condition, message) => { receipt.checks++; assert.ok(condition, message); };
const eq = (actual, expected, message) => { receipt.checks++; assert.deepEqual(actual, expected, message); };
const group = async (name, action) => { await action(); receipt.groups.push(name); console.log("PASS " + name); };
class CDP {
  constructor(ws) {
    this.ws = ws; this.next = 1; this.pending = new Map(); this.events = [];
    ws.addEventListener("message", event => {
      const message = JSON.parse(event.data);
      if (message.id) {
        const pending = this.pending.get(message.id);
        if (pending) {
          clearTimeout(pending.timer); this.pending.delete(message.id);
          message.error ? pending.reject(Error(JSON.stringify(message.error))) : pending.resolve(message.result);
        }
      } else this.events.push(message);
    });
  }
  static async open(url) {
    const ws = new WebSocket(url);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(Error("CDP open timeout")), 10000);
      ws.addEventListener("open", () => { clearTimeout(timer); resolve(); }, { once: true });
      ws.addEventListener("error", () => { clearTimeout(timer); reject(Error("CDP socket error")); }, { once: true });
    });
    return new CDP(ws);
  }
  send(method, params = {}, sessionId) {
    const id = this.next++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(Error("CDP timeout " + method)); }, 15000);
      this.pending.set(id, { resolve, reject, timer });
      this.ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    });
  }
  close() { this.ws.close(); }
}
const profile = resolve(out, "profile"), downloads = resolve(out, "downloads");
mkdirSync(downloads); assert(!existsSync(profile));
const args = ["--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
 "--disable-background-networking", "--disable-component-update", "--disable-default-apps", "--disable-sync",
 "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0", "--user-data-dir=" + profile,
 "--window-size=1280,960", "about:blank"];
receipt.browserCommand = { executable: chrome, args, sandboxDisablingFlags: false };
let proc, cdp, exited = false, exitInfo, log = "", main;
async function page() {
  const { targetId } = await cdp.send("Target.createTarget", { url: "about:blank" });
  const { sessionId } = await cdp.send("Target.attachToTarget", { targetId, flatten: true });
  const send = (method, params = {}) => cdp.send(method, params, sessionId);
  const evaluate = async expression => {
    const result = await send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
    if (result.exceptionDetails) throw Error("Page exception " + JSON.stringify(result.exceptionDetails));
    return result.result.value;
  };
  const value = selector => evaluate("document.querySelector(" + JSON.stringify(selector) + ")?.value");
  const text = selector => evaluate("document.querySelector(" + JSON.stringify(selector) + ")?.innerText");
  const count = selector => evaluate("document.querySelectorAll(" + JSON.stringify(selector) + ").length");
  const visible = selector => evaluate("(()=>{const e=document.querySelector(" + JSON.stringify(selector) + ");return !!e&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';})()");
  async function click(selector) {
    const point = await evaluate("(()=>{const e=document.querySelector(" + JSON.stringify(selector) + ");if(!e)throw Error('Missing selector');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();if(!r.width||!r.height)throw Error('Invisible target');return {x:r.x+r.width/2,y:r.y+r.height/2};})()");
    await send("Input.dispatchMouseEvent", { type: "mousePressed", button: "left", clickCount: 1, ...point });
    await send("Input.dispatchMouseEvent", { type: "mouseReleased", button: "left", clickCount: 1, ...point });
  }
  async function key(key, code, keyCode, modifiers = 0) {
    await send("Input.dispatchKeyEvent", { type: "rawKeyDown", key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode, modifiers });
    await send("Input.dispatchKeyEvent", { type: "keyUp", key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode, modifiers });
  }
  async function fill(selector, content) {
    await click(selector); await key("a", "KeyA", 65, 2);
    if (content === "") await key("Backspace", "Backspace", 8);
    else await send("Input.insertText", { text: content });
  }
  async function select(selector, targetValue) {
    const index = await evaluate("Array.from(document.querySelector(" + JSON.stringify(selector) + ").options).findIndex(o=>o.value===" + JSON.stringify(targetValue) + ")");
    assert(index >= 0);
    // Native select receives trusted keyboard events; no value assignment or synthetic change.
    await evaluate("document.querySelector(" + JSON.stringify(selector) + ").focus()");
    await key("Home", "Home", 36);
    for (let i = 0; i < index; i++) await key("ArrowDown", "ArrowDown", 40);
    await key("Enter", "Enter", 13);
    await until(async () => await value(selector) === targetValue, "native select " + targetValue);
  }
  async function screenshot(name) {
    const metrics = await send("Page.getLayoutMetrics");
    const size = metrics.cssContentSize;
    assert(size.width <= 1600 && size.height <= 16000);
    const shot = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: true,
      clip: { x: 0, y: 0, width: Math.ceil(size.width), height: Math.ceil(size.height), scale: 1 } });
    const bytes = Buffer.from(shot.data, "base64"); writeFileSync(resolve(out, name + ".png"), bytes);
    return { bytes: bytes.length, sha256: sha(bytes) };
  }
  async function navigate(path) {
    await send("Page.navigate", { url: pathToFileURL(path).href });
    await until(() => evaluate("document.readyState==='complete'"), "page complete");
  }
  await send("Page.enable"); await send("Runtime.enable"); await send("Network.enable"); await send("Log.enable");
  await send("Emulation.setDeviceMetricsOverride", { width: 1280, height: 960, deviceScaleFactor: 1, mobile: false });
  return { targetId, sessionId, send, evaluate, value, text, count, visible, click, key, fill, select, screenshot, navigate };
}
async function download(selector, filename) {
  const start = cdp.events.length;
  await main.click(selector);
  const begun = await until(() => cdp.events.slice(start).find(e => e.method === "Browser.downloadWillBegin"), "download event");
  eq(begun.params.suggestedFilename, filename, "actual suggested filename");
  const complete = await until(() => cdp.events.slice(start).find(e => e.method === "Browser.downloadProgress" && e.params.guid === begun.params.guid && e.params.state !== "inProgress"), "download completion");
  eq(complete.params.state, "completed", "actual download completed");
  const path = resolve(downloads, filename);
  await until(() => existsSync(path), "download bytes");
  return readFileSync(path);
}
try {
  proc = spawn(chrome, args, { stdio: ["ignore", "pipe", "pipe"], windowsHide: true });
  receipt.pid = proc.pid;
  proc.stdout.on("data", bytes => { if (log.length < 65536) log += bytes; });
  proc.stderr.on("data", bytes => { if (log.length < 65536) log += bytes; });
  proc.once("exit", (code, signal) => { exited = true; exitInfo = { code, signal }; });
  proc.once("error", error => receipt.errors.push("spawn: " + error.message));
  const active = await until(() => {
    const path = resolve(profile, "DevToolsActivePort");
    if (existsSync(path)) return readFileSync(path, "utf8").trim().split(/\r?\n/);
    if (exited) throw Error("Chrome exited before debugging");
    return null;
  }, "owned Chrome debugging file", 20000);
  cdp = await CDP.open("ws://127.0.0.1:" + active[0] + active[1]);
  receipt.browser = await cdp.send("Browser.getVersion");
  await cdp.send("Browser.setDownloadBehavior", { behavior: "allow", downloadPath: downloads, eventsEnabled: true });
  main = await page();
  const form = '<!doctype html><meta charset="utf-8"><form id="form"><label>Coefficient<input id="coefficient" value="1"></label><button type="submit">Apply</button></form><output id="count">0</output><script>window.events=[];for(const name of ["keydown","keypress","keyup"])document.addEventListener(name,e=>events.push({type:e.type,key:e.key,trusted:e.isTrusted}));document.querySelector("form").addEventListener("submit",e=>{e.preventDefault();document.querySelector("#count").textContent=String(Number(document.querySelector("#count").textContent)+1)});</script>';
  writeFileSync(resolve(out, "plain-form.html"), form);
  await main.navigate(resolve(out, "plain-form.html"));
  await main.click("#coefficient");
  await main.key("Enter", "Enter", 13);
  eq(await main.text("#count"), "0", "rawKeyDown alone does not submit an ordinary form");
  receipt.rawEnterEvents = await main.evaluate("window.events");
  const enter = async () => {
    await main.send("Input.dispatchKeyEvent", { type: "keyDown", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13, text: "\r", unmodifiedText: "\r" });
    await main.send("Input.dispatchKeyEvent", { type: "keyUp", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 });
  };
  await enter();
  eq(await main.text("#count"), "1", "character-bearing native Enter submits an ordinary form");
  receipt.allEnterEvents = await main.evaluate("window.events");
  check(receipt.allEnterEvents.every(event => event.trusted), "actual trusted input events");
  receipt.groups.push("plain form isolates missing Enter character event");
  await main.navigate(resolve(candidate, "courses/linear-programming-explorer.html"));
  await until(() => main.visible("#result"), "unchanged actual LP page");
  await main.fill("#p", "1"); await enter();
  check((await main.text("#result-title")).includes("1x + 2y"), "native character-bearing Enter applies actual LP draft");
  receipt.actualTitle = await main.text("#result-title");
  receipt.groups.push("unchanged LP form accepts actual native Enter");
  receipt.status = "passed";
} catch (error) {
  receipt.status = "failed"; receipt.errors.push(error.stack || String(error));
  if (main) { try { receipt.failureScreenshot = await main.screenshot("failure"); } catch (e) { receipt.errors.push("Failure screenshot: " + e.message); } }
} finally {
  receipt.actualDownloadEvents = cdp?.events.filter(e => e.method?.startsWith("Browser.download")) ?? [];
  if (cdp) { try { await cdp.send("Browser.close"); } catch (error) { receipt.cleanup.closeDiagnostic = error.message; } cdp.close(); }
  if (proc && !exited) {
    try { await until(() => exited, "owned Chrome exit", 10000); }
    catch { receipt.cleanup.termination = "Owned child handle only"; proc.kill(); try { await until(() => exited, "owned child termination", 5000); } catch (error) { receipt.cleanup.exitWaitError = error.message; } }
  }
  receipt.cleanup.browserExited = exited; receipt.cleanup.exit = exitInfo ?? null;
  if (exited && existsSync(profile)) {
    try { rmSync(profile, { recursive: true, force: false, maxRetries: 3, retryDelay: 250 }); receipt.cleanup.profileRemoved = !existsSync(profile); }
    catch (error) { receipt.cleanup.profileError = error.message; }
  }
  receipt.after = sourcePins(); receipt.sourceUnchanged = JSON.stringify(before) === JSON.stringify(receipt.after);
  if (!receipt.sourceUnchanged || !exited || !receipt.cleanup.profileRemoved) receipt.status = "failed";
  receipt.finished = new Date().toISOString();
  writeFileSync(resolve(out, "browser.log"), log);
  writeFileSync(resolve(out, "RECEIPT.json"), JSON.stringify(receipt, null, 2) + "\n");
  console.log(JSON.stringify({ status: receipt.status, groups: receipt.groups.length, checks: receipt.checks, errors: receipt.errors, cleanup: receipt.cleanup, sourceUnchanged: receipt.sourceUnchanged }, null, 2));
  process.exitCode = receipt.status === "passed" ? 0 : 1;
}
