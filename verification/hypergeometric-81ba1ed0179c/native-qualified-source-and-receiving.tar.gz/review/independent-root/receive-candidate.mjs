import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root='/home/jacob/hypergeometric-independent-81ba1ed0179c';
const source='/home/jacob/recall-hypergeometric-81ba1ed0179c/worktree/src/hypergeometric.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');
const freezeBytes=await readFile(root+'/expectations-frozen.json');
assert.equal(sha(freezeBytes),'3c88e8487090ce08c7e5c6795d7fc67503e0b3c25b4f3f0a00d309f558433277');
const sourceBytes=await readFile(source);
assert.equal(sha(sourceBytes),'c01c200321f131f8817caf85e281f60b8d70341115ea0928fca955e0e6aee5fe');
const frozen=JSON.parse(freezeBytes);
const startedAt=new Date().toISOString();
const api=await import(pathToFileURL(source));
const groups=[]; let failure=null;
const checkFrozen=value=>{
  if(value && typeof value==='object'){
    assert(Object.isFrozen(value),'Every result object/array must be frozen');
    for(const child of Object.values(value))checkFrozen(child);
  }
};
function equalExpected(actual,expected,path='result'){
  if(typeof expected==='number' && path.endsWith('.approximate')){
    assert(Number.isFinite(actual),path+' finite');
    assert(Math.abs(actual-expected)<=Math.max(1e-300,Math.abs(expected)*2e-14),path+' precision '+actual+' vs '+expected);
  } else if(expected && typeof expected==='object'){
    assert.equal(Array.isArray(actual),Array.isArray(expected),path+' container');
    if(Array.isArray(expected))assert.equal(actual.length,expected.length,path+' length');
    for(const [key,value] of Object.entries(expected))equalExpected(actual[key],value,path+'.'+key);
  } else assert.deepEqual(actual,expected,path);
}
try{
  const received=[];
  for(const one of frozen.cases){
    const config=structuredClone(one.expected.config), prior=structuredClone(config);
    const actual=api.distribution(config);
    equalExpected(actual,one.expected);
    assert.deepEqual(config,prior);
    checkFrozen(actual);
    assert.deepEqual(JSON.parse(JSON.stringify(actual)),actual);
    config.marked=-999;
    assert.deepEqual(actual.config,prior);
    received.push({label:one.label,result:actual});
    groups.push({name:one.label,pass:true,rows:actual.rows.length});
  }
  groups.push({name:'Every numerical case is detached, deeply frozen and JSON-safe',pass:true,cases:received.length});
  for(const one of frozen.cases){
    const selected=one.expected.config.lower;
    const text=api.observationJSON(one.expected.config,selected);
    assert(text.endsWith('\n'));
    const observed=JSON.parse(text);
    assert.equal(observed.format,'recallweave-hypergeometric-observation/1');
    assert.equal(observed.inspectedCount,selected);
    equalExpected(observed,one.expected,'observation');
  }
  groups.push({name:'Observation JSON recomputes the same exact inputs, counts and fractions',pass:true,cases:frozen.cases.length});
  const valid={population:6,marked:2,draws:3,lower:1,upper:2};
  const bad=[
    ['population zero',{...valid,population:0}],['population201',{...valid,population:201}],
    ['population fractional',{...valid,population:6.5}],['population numeric string',{...valid,population:'6'}],
    ['population boolean',{...valid,population:true}],['population NaN',{...valid,population:NaN}],
    ['population Infinity',{...valid,population:Infinity}],['marked negative',{...valid,marked:-1}],
    ['marked too large',{...valid,marked:7}],['draws negative',{...valid,draws:-1}],
    ['draws too large',{...valid,draws:7}],['lower negative',{...valid,lower:-1}],
    ['upper too large',{...valid,upper:4}],['reversed event',{...valid,lower:3,upper:2}],
    ['missing lower',{population:6,marked:2,draws:3,upper:2}],
    ['null config',null],['missing config',undefined]
  ];
  for(const [label,config] of bad)assert.throws(()=>api.distribution(config),undefined,label);
  for(const count of [-1,4,1.5,'1',true,NaN,Infinity])assert.throws(()=>api.observationJSON(valid,count));
  groups.push({name:'Invalid numerical admission and selected-count refusal',pass:true,distributionCases:bad.length,selectedCountCases:7});
  await writeFile(root+'/received-results.json',JSON.stringify(received,null,2)+'\n');
}catch(error){failure={name:error.name,message:error.message,stack:error.stack};}
const sourceAfter=await readFile(source),freezeAfter=await readFile(root+'/expectations-frozen.json');
const unchanged=sha(sourceAfter)===sha(sourceBytes)&&sha(freezeAfter)===sha(freezeBytes);
if(!unchanged)failure={name:'ProvenanceError',message:'Source or frozen expectations changed'};
const receipt={schema:'hamon.independent-mathematical-receiving.v1',startedAt,finishedAt:new Date().toISOString(),owner:'estate-81ba1ed0179c/root',candidateSource:source,candidateSha256:sha(sourceBytes),expectationsSha256:sha(freezeBytes),groups,passed:failure===null,unchanged,failure,scope:'Bounded exact numerical and admission receiving. No browser, learner, efficacy, hosted CI or integration claim.'};
await writeFile(root+'/consumer-receiving.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({passed:receipt.passed,groups:groups.length,receiptSha256:sha(await readFile(root+'/consumer-receiving.json')),failure},null,2));
if(failure)process.exitCode=1;
