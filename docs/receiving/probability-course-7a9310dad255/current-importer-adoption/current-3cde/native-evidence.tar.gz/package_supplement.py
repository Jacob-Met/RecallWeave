from pathlib import Path
import base64, datetime, gzip, hashlib, io, json, os, re, shutil, tarfile
ROOT = Path(__file__).resolve().parent
def pin(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}
def load(rel): return json.loads((ROOT / rel).read_bytes())
def put(rel, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    with (ROOT / rel).open("xb") as file: file.write(raw)
    return pin(raw)
context = load("source-manifest.json")
control = load("probability-current-control/receipt.json")
execution = load("control-execution.json")
assert control["status"] == "passed" and execution["exit_code"] == 0 and not execution["timeout"]
assert control["node"] == "v22.22.1"
assert (ROOT/"control.stderr").read_bytes() == b""
assert pin((ROOT/"probability-current-control/receipt.json").read_bytes())["sha256"] == "753052270f29610c0b76971eabda6234a9e133c9d496c8b9a33eb8881bca2ee5"
assert context["public_head"] == "3cdebd86e69506709bcaeaeff4026deb3d1fc208"
assert context["public_leaves"] == 871
assert context["current_plus_frozen_33_tree"] == "33cfcdae177c0e259810b60d97af186f74926df5"
assert context["current_plus_frozen_33_leaves"] == 904
source_records = context["physical_learner_and_course_files"]
for item in source_records:
    raw = (ROOT / "source" / item["path"]).read_bytes()
    assert pin(raw)["sha256"] == item["sha256"]
    assert control["sourceBefore"][item["path"]] == control["sourceAfter"][item["path"]] == item["sha256"]
# Every static learner import stays within the exact received module closure.
known = {item["path"] for item in source_records}
imports = []
for item in source_records:
    if not item["path"].endswith(".mjs"): continue
    text = (ROOT / "source" / item["path"]).read_text()
    for rel in re.findall(r"from\s+['\"](\./[^'\"]+)['\"]", text):
        path = str(Path(item["path"]).parent / rel).replace("/./", "/")
        assert path in known, path
        assert "numerical-precision" not in path
        imports.append({"from": item["path"], "to": path})
assessment = {
    "format": "recallweave-probability-current-assessment/1",
    "status": "accepted_at_exact_source",
    "reviewer": "7a9310dad255/memory",
    "assessed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "public_head": context["public_head"], "public_tree": context["public_tree"],
    "public_leaves": 871, "previous_qualified_parent": "8b82cf5bb95fc7faa5e835e2979df703e6e91a7b",
    "previous_prepared_tree": "bc85a715e1be4525db91d2557ff9ca34babcc440",
    "current_plus_unchanged_33_tree": context["current_plus_frozen_33_tree"],
    "current_plus_unchanged_33_leaves": 904,
    "all_current_parent_blobs_and_modes_preserved": True,
    "frozen_33_path_preparation_modified": False,
    "delta_counts": {"added": 288, "modified": 6, "deleted": 0},
    "existing_modified_paths": ["README.md", "demo.html", "src/app.mjs", "src/session-export.mjs", "styles.css", "tools/make_demo.py"],
    "source_manifest": pin((ROOT/"source-manifest.json").read_bytes()),
    "current_learner_and_course": source_records,
    "static_module_edges_verified": imports,
    "owner_browser_evidence": {
        "public_source": "3cdebd86e69506709bcaeaeff4026deb3d1fc208",
        "path": "docs/reflections-20261008-9ec02b70e5f0/independent-current-picker-d8a9",
        "original_qualified_parent": "d8a9ff81e8e5290e8daad5b4af957d4eddc0ee74",
        "qualification": "Eleven owner browser checkpoints; five imported-course controls use a different three-item deck.",
        "same_current_runtime_and_build_files": 15,
        "raw_members_verified": 46, "raw_bytes_verified": 490458,
        "actual_notes_verified": 15, "actual_traces_verified": 4,
        "executed_again_by_this_receiver": False,
        "verification": pin((ROOT/"owner-evidence-verification.json").read_bytes())
    },
    "current_probability_module_control": {
        "qualification": "One bounded actual current-module compatibility scenario using the original twelve-question course and successful browser trace.",
        "original_course_blob": "82cc4bdd8bf22afc5ca84098a0b19c3d485d2f45",
        "original_probability_browser_proof": "4487260efca6819f152435af9cf0a1b64a978d61",
        "prior_trace_member": "evidence/modular/paused-trace.json",
        "prior_trace": pin((ROOT/"inputs/probability-prior-paused-trace.json").read_bytes()),
        "contract": pin((ROOT/"control-contract.md").read_bytes()),
        "runner": pin((ROOT/"receive_probability_current.mjs").read_bytes()),
        "freeze": pin((ROOT/"control-freeze.json").read_bytes()),
        "execution": pin((ROOT/"control-execution.json").read_bytes()),
        "receipt": pin((ROOT/"probability-current-control/receipt.json").read_bytes()),
        "exit_code": 0, "elapsed_seconds": execution["elapsed_seconds"], "node": control["node"],
        "first_answers": 12, "correct_first": 10, "practice_recorded": 1, "practice_total": 2,
        "next_practice_item": "pf-i2", "canonical_reflection_paragraphs": 12,
        "full_precision_mastery_preserved": True, "prior_answer_trace_bytes_unchanged": True,
        "changed_course_refused": True, "source_files_unchanged": 16, "stderr_empty": True,
        "actual_study_notes": pin((ROOT/"probability-current-control/study-notes.txt").read_bytes()),
        "new_browser_or_user_action_claim": False
    },
    "qualification_needs": {
        "further_native_tests_for_unchanged_3cde": "none",
        "public_head_checks_and_actual_merge": "root retains the exact public branch/check/parent gate",
        "later_runtime_changes": "require their own current-source compatibility assessment"
    },
    "preserved_limits": [
        "The original probability six browser groups/eighteen downloads retain their original d8a/4487260 source.",
        "Earlier d202, c00 and 8b82 required native suites are not relabelled as 3cde runs.",
        "Reflection owner browser evidence is received and attributed, not rerun.",
        "No mathematics/content, new browser, full-suite, hosted application, learning-efficacy or deployment result is added.",
        "No Git repository object, ref, owner source or shared live state was changed by this receiver."
    ]
}
put("assessment.json", assessment)
files = []
for path in sorted(ROOT.rglob("*")):
    if path.is_file():
        assert not path.is_symlink()
        rel = str(path.relative_to(ROOT))
        assert rel not in {"native-evidence.tar.gz", "publication-payload.json", "packet-manifest.json", "publication-receipt.json"}
        files.append({"path": rel, "mode": "100755" if path.stat().st_mode & 0o111 else "100644", **pin(path.read_bytes())})
manifest = {"format": "recallweave-probability-current-native-packet/1", "files": files,
    "raw_files": len(files), "raw_bytes": sum(x["bytes"] for x in files),
    "all_files_regular": True, "manifest_is_additional_member": True}
manifest_pin = put("packet-manifest.json", manifest)
archive_path = ROOT / "native-evidence.tar.gz"
with archive_path.open("xb") as file:
    with gzip.GzipFile(filename="", mode="wb", fileobj=file, mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as archive:
            for item in files + [{"path": "packet-manifest.json", "mode": "100644", **manifest_pin}]:
                raw = (ROOT/item["path"]).read_bytes()
                assert pin(raw) == {key:item[key] for key in ["bytes","sha256","git_blob"]}
                info = tarfile.TarInfo(item["path"])
                info.size = len(raw); info.mode = int(item["mode"][-3:],8); info.mtime = 0
                info.uid = info.gid = 0; info.uname = info.gname = ""
                archive.addfile(info, io.BytesIO(raw))
with tarfile.open(archive_path,"r:gz") as archive:
    expected = {item["path"]: item for item in files}
    expected["packet-manifest.json"] = {"path":"packet-manifest.json",**manifest_pin}
    assert len(archive.getmembers()) == len(expected)
    for member in archive.getmembers():
        assert member.isfile() and member.name in expected
        assert pin(archive.extractfile(member).read()) == {key:expected[member.name][key] for key in ["bytes","sha256","git_blob"]}
archive_pin = pin(archive_path.read_bytes())
prefix = "docs/receiving/probability-course-7a9310dad255/current-importer-adoption/current-3cde/"
entries = []
for filename in ["README.md","assessment.json","native-evidence.tar.gz"]:
    raw = (ROOT/filename).read_bytes()
    entries.append({"path":prefix+filename,"mode":"100644","type":"blob","sha":pin(raw)["git_blob"],
        "sha256":pin(raw)["sha256"],"bytes":len(raw),"encoding":"base64","content":base64.b64encode(raw).decode(),
        "local_path":str(ROOT/filename)})
payload = {"format":"recallweave-proof-only-publication-payload/1","repository":"Jacob-Met/RecallWeave",
    "pull_request":19,"qualified_current_parent":context["public_head"],
    "qualified_current_parent_tree":context["public_tree"],
    "prior_33_contribution_tree_at_current":context["current_plus_frozen_33_tree"],
    "frozen_original_33_changed":False,"entries":entries,
    "publication_authority":"root only; perform fresh branch/parent checks"}
payload_pin = put("publication-payload.json",payload)
backup = Path("/tmp/hamon-7a9310dad255-recall19-integration/prepared-current-3cde")
backup.mkdir(parents=True,exist_ok=False)
for filename in ["README.md","assessment.json","native-evidence.tar.gz","publication-payload.json","packet-manifest.json"]:
    raw = (ROOT/filename).read_bytes()
    with (backup/filename).open("xb") as file:file.write(raw)
    assert (backup/filename).read_bytes() == raw
receipt = {"status":"ready","entries":[{k:v for k,v in item.items() if k!="content"} for item in entries],
    "payload":{"path":str(ROOT/"publication-payload.json"),**payload_pin},
    "backup_directory":str(backup),"backup_bytes_verified":True,
    "archive":archive_pin,"archive_members":len(files)+1,"archive_raw_bytes":sum(x["bytes"] for x in files)+manifest_pin["bytes"],
    "internal_manifest":manifest_pin,
    "public_source_unchanged":True,"source_control_not_repeated_during_packaging":True}
put("publication-receipt.json",receipt)
shutil.copyfile(ROOT/"publication-receipt.json",backup/"publication-receipt.json")
assert (ROOT/"publication-receipt.json").read_bytes() == (backup/"publication-receipt.json").read_bytes()
print(json.dumps(receipt,indent=2))
