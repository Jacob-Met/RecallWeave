import ctypes,datetime,hashlib,json,pathlib,shutil,sys
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8');E=R/'print-review-r1';E.mkdir(exist_ok=False)
class MEM(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['totalPhys','availPhys','totalPage','availPage','totalVirtual','availVirtual','availExtended']]
m=MEM();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
capacity={'CFree':shutil.disk_usage('C:/').free,'DFree':shutil.disk_usage('D:/').free,'memoryAvailable':m.availPhys};assert capacity['CFree']>=1073741824 and capacity['DFree']>=1073741824 and m.availPhys>=2147483648
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
import fitz
pdf=R/'browser-r1/worksheet-A4.pdf';before=pin(pdf);d=fitz.open(pdf);assert len(d)==3
pages=[]
for i,page in enumerate(d):
 output=E/('page-'+str(i+1)+'.png');page.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(output)
 blocks=[{'bounds':list(b[:4]),'text':b[4]} for b in page.get_text('blocks') if len(b)>4 and isinstance(b[4],str)]
 assert all(b['bounds'][0]>=0 and b['bounds'][1]>=0 and b['bounds'][2]<=page.rect.width and b['bounds'][3]<=page.rect.height for b in blocks)
 pages.append({'page':i+1,'width':page.rect.width,'height':page.rect.height,'image':{'path':str(output),**pin(output)},'textBlocks':blocks})
d.close();assert pin(pdf)==before
modules=[]
for name,module in sorted(sys.modules.items()):
 p=getattr(module,'__file__',None)
 if p and (name.startswith('fitz') or name.startswith('pymupdf')) and pathlib.Path(p).is_file():modules.append({'module':name,'path':p,**pin(pathlib.Path(p))})
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'capacity':capacity,'renderer':'existing PyMuPDF read-only; no install','version':fitz.version,'modulePins':modules,'pdfBeforeAfterExact':before,'pages':pages}
(E/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode('utf-8'));print(json.dumps({'pages':len(pages),'images':[p['image'] for p in pages],'rendererVersion':fitz.version,'receipt':pin(E/'receipt.json')}))
