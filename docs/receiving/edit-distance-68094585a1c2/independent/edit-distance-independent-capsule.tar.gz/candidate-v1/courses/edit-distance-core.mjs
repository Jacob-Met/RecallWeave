/** Unit-cost Levenshtein distance over bounded Unicode code-point sequences. */
export const POLICY = Object.freeze({
  maxCodePoints: 24,
  unit: 'Unicode code point',
  normalization: 'none',
  trim: false,
  caseFolding: false,
  costs: Object.freeze({match: 0, insert: 1, delete: 1, substitute: 1}),
  tieOrder: Object.freeze(['diagonal', 'delete', 'insert']),
  countMeaning: 'optimal monotone alignment paths'
});

export const EXAMPLES = Object.freeze([
  Object.freeze({id: 'kitten', label: 'Three edits · KITTEN → SITTING', source: 'KITTEN', target: 'SITTING'}),
  Object.freeze({id: 'deletion', label: 'Shift a suffix · ABC → AC', source: 'ABC', target: 'AC'}),
  Object.freeze({id: 'ties', label: 'Three optimal paths · AB → BA', source: 'AB', target: 'BA'}),
  Object.freeze({id: 'repeated', label: 'Repeated positions · AA → A', source: 'AA', target: 'A'}),
  Object.freeze({id: 'empty', label: 'Start with nothing · empty → ABC', source: '', target: 'ABC'}),
  Object.freeze({id: 'accents', label: 'Same appearance, different code points', source: 'é', target: 'e\u0301'}),
  Object.freeze({id: 'emoji', label: 'One symbol, several code points', source: '👩‍🔬', target: '👩'}),
  Object.freeze({id: 'spaces', label: 'Spaces are input · “ A” → “A ”', source: ' A', target: 'A '})
]);

function points(value, label) {
  if (typeof value !== 'string') throw new TypeError(label + ' must be text.');
  const result = [];
  for (const point of value) {
    const code = point.codePointAt(0);
    if (code >= 0xd800 && code <= 0xdfff) {
      throw new TypeError(label + ' contains an unpaired UTF-16 surrogate; use well-formed Unicode text.');
    }
    result.push(point);
    if (result.length > POLICY.maxCodePoints) {
      throw new RangeError(label + ' exceeds 24 Unicode code points. Shorten this input, keeping any spaces intentional.');
    }
  }
  return result;
}

/**
 * D[i][j] transforms source prefix i to target prefix j.
 * Candidate order is also the declared backtrace tie order.
 * Counts use BigInt; the public, JSON-safe record uses decimal strings.
 */
export function analyzeEditDistance(source, target) {
  const sourcePoints = points(source, 'Source');
  const targetPoints = points(target, 'Target');
  const m = sourcePoints.length, n = targetPoints.length;
  const matrix = Array.from({length: m + 1}, () => Array(n + 1).fill(0));
  const counts = Array.from({length: m + 1}, () => Array(n + 1).fill(0n));
  const cells = Array.from({length: m + 1}, () => Array(n + 1));
  for (let i = 0; i <= m; i++) {
    for (let j = 0; j <= n; j++) {
      const candidates = [];
      const add = (operation, pi, pj, stepCost) => {
        candidates.push({operation, from: [pi, pj], stepCost, totalCost: matrix[pi][pj] + stepCost, optimal: false});
      };
      if (i && j) {
        const equal = sourcePoints[i - 1] === targetPoints[j - 1];
        add(equal ? 'match' : 'substitute', i - 1, j - 1, equal ? 0 : 1);
      }
      if (i) add('delete', i - 1, j, 1);
      if (j) add('insert', i, j - 1, 1);
      const cost = candidates.length ? Math.min(...candidates.map(candidate => candidate.totalCost)) : 0;
      let count = candidates.length ? 0n : 1n;
      for (const candidate of candidates) {
        candidate.optimal = candidate.totalCost === cost;
        if (candidate.optimal) count += counts[candidate.from[0]][candidate.from[1]];
      }
      matrix[i][j] = cost;
      counts[i][j] = count;
      cells[i][j] = {i, j, cost, optimalPathCount: count.toString(), candidates};
    }
  }

  const backward = [];
  let i = m, j = n;
  while (i || j) {
    const chosen = cells[i][j].candidates.find(candidate => candidate.optimal);
    const consumesSource = chosen.operation !== 'insert';
    const consumesTarget = chosen.operation !== 'delete';
    backward.push({
      operation: chosen.operation,
      sourceIndex: consumesSource ? i - 1 : null,
      targetIndex: consumesTarget ? j - 1 : null,
      source: consumesSource ? sourcePoints[i - 1] : null,
      target: consumesTarget ? targetPoints[j - 1] : null,
      cost: chosen.stepCost,
      from: [...chosen.from],
      to: [i, j]
    });
    [i, j] = chosen.from;
  }
  const alignment = backward.reverse().map((step, index) => ({step: index + 1, ...step}));
  return {
    format: 'recallweave-edit-distance/1',
    policy: {...POLICY, costs: {...POLICY.costs}, tieOrder: [...POLICY.tieOrder]},
    source, target, sourcePoints, targetPoints,
    distance: matrix[m][n],
    optimalPathCount: counts[m][n].toString(),
    matrix, cells, alignment
  };
}
