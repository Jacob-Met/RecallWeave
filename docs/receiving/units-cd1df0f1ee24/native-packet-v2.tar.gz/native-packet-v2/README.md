# Independent native receiving: offline units explorer and current learner

The exact frozen explorer v2 passed **18 of 18 native browser receiving groups**, with five actual completed downloads, four inspected screenshots and no attempted page HTTP/HTTPS dependency, runtime error, console error or failed request. Execution used a fresh headless Chrome 154.0.8037.98 profile on macOS arm64, driven by Node 26.3.0. This was an actual native browser run, not a DOM simulation.

## Exact inputs and route

The explorer is Git blob **2b253cf3891cc1c0ba37f04bd67da74b63ec47a8**, SHA256 **7a0d130b04449b1bdc7aa4852fddc7f2ed3c21ea51d7bbdd199ae96d306a06cd**, 48,980 bytes. Its converter is the independently qualified v4 core; its UI and builder remain the frozen versions. The source author's v2 change darkens the input border. The guide's separately accepted v3 addition explains the explorer's explicit notation. The downloaded course JSON remains exactly **df0c8c8ba1f0061bbc73bcad0e9a62b257341b4bd5d6a7adbd6824820a02128e**, 13,008 bytes.

The learner is bound to actual main commit **169b618ce71d2d4702a0d2ef740821df53581ad2**, tree **96471ac3db79b3c5329a27837d92d81f34b1f318**. Its current app, notes exporter, CSS and standalone demo incorporate the existing reflection feature, and the new reflections module is included. Nine earlier learner leaves remain unchanged. The frozen preview, first-answer, practice and notes receiver ran unchanged against this newer consumer; no old-demo result is attributed to the new source. See [current learner composition](current-learner-composition.json).

The [input manifest](input-manifest.json), SHA256 **cf04a014074b97fe8780a2ccc0c091e245a6abe56ea295251c9b35bcfe72401a**, pins 31 files: 21 source files plus receiving drivers, independent inputs and provenance. Every input was verified before and after execution with identical results. The complete small [source input archive](source-input-v2.tar.gz) has SHA256 **36b300e1a08a21d6a9c52abf4365f32bb14d427a87f46336c2331c61ebbb523a** and contains that manifest plus all 31 pinned files.

The browser opened the supplied explorer and current `demo.html` directly with `file:` URLs. Its request interception would block every page HTTP/HTTPS request; none was attempted. The fresh profile was removed after browser shutdown. This establishes offline page behavior under the recorded browser configuration, not a network isolation claim about unrelated host processes.

## Receiving outcomes

| Boundary | Actual result |
| --- | --- |
| Pointer presets and keyboard input | Speed, scaled area, scaled volume, density, MJ/mJ case, a repeating exact ratio, Unicode squared units and grouped powers produced the independently expected values. |
| Exact and rounded values | `1 km/h → m/s` displayed `0.277777777778` with a rounding notice while retaining exact factor and result `5/18`. |
| Current result and export | Editing `36` to `72 km/h` replaced `10` with `20 m/s`; the second actual calculation download contained the current values. |
| Refusals | Incompatible units, zero with incompatible units, invalid case and an empty value removed the old result and disabled its calculation download. The lesson download remained usable. |
| Native learner route | The actual explorer-downloaded JSON was chosen through a native file chooser, previewed, cancelled without altering an existing lesson, chosen again and started. |
| First answers and practice | All twelve questions were answered with ten correct first answers and two intentional misses. Both retries were then correct; first-answer records and displayed model estimates remained unchanged. |
| Saved study notes | Two actual text downloads retained title, attribution, license, all explanations and transfer prompts; the second recorded separate practice answers without replacing first answers. |
| Layout | The 1280 × 900 desktop and 390 × 844 phone viewport captures were read visually. The phone had no page-level horizontal overflow. |

The imported course followed the existing learner's shuffled option order and canonical answer indices. Practice retained each question's original displayed option order. The receiver did not write reflection text or extend the newly integrated reflection feature's owner's scope.

## Read the actual evidence

- [Browser receiving trace](run-v2-01/browser-receiving.json), [native command](run-v2-01-command.json), [stdout](run-v2-01.stdout), [stderr](run-v2-01.stderr), and [launcher](run-native-v2.py).
- [Exact repeating-ratio calculation download](run-v2-01/downloads/conversion-repeating/recallweave-unit-conversion-v1.json) and [calculation after editing](run-v2-01/downloads/conversion-after-edit/recallweave-unit-conversion-v1.json).
- [Actual downloaded lesson](run-v2-01/downloads/units-lesson/units-and-dimensions.json).
- [First-answer notes](run-v2-01/downloads/learner-first-notes/recallweave-study-notes-2026-10-08.txt) and [notes after practice](run-v2-01/downloads/learner-practice-notes/recallweave-study-notes-2026-10-08.txt).
- [Desktop exact/rounded result](run-v2-01/explorer-rounded-desktop.png), [phone inputs](run-v2-01/explorer-phone-input.png), [phone calculation](run-v2-01/explorer-phone-result.png), and [current learner trace](run-v2-01/learner-first-trace-desktop.png).
- [Original explorer receiver](receiver/receive-unit-explorer.mjs) and [unchanged learner receiver](receiver/receive-course-learner.mjs).

## Attempts and practical limits

There was one native execution and no browser harness or production correction during that execution. Two local materialization attempts hit the shared scratch filesystem's capacity limit: [source-copy attempt](source-copy-enospc-attempt.json) and [evidence-transport attempt](evidence-transport-enospc-attempt.json). They occurred before execution and after successful execution respectively. The complete native source and result archives remained intact; failed local partial copies were recorded and then removed. They are not browser test failures.

The original native result archive is SHA256 **778bee95a737b7bc6162b9f2e03f1838d562f0d929a574e8217a8a2f5012db51**, 611,884 bytes. Its 21 original files remain byte-for-byte within this packet; the receiving README, acceptance/index, current-consumer receipt, input archive and local attempt receipts were added afterward. No screenshot was retouched.

This acceptance covers the frozen offline files and recorded viewport behavior. It does not claim a public deployment, physical-phone testing, a measured learning outcome or adoption in an installed application. The [artifact manifest](artifact-manifest.json) pins every file except itself.
