import {readFile,writeFile,mkdir,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname,join} from 'node:path';
import assert from 'node:assert/strict';
const root='/tmp/rw49-membrane-49f845d0dece';
const payload=JSON.parse(await readFile('/tmp/rw49-membrane-transfer-49f845d0dece.json','utf8'));
const sha256=b=>createHash('sha256').update(b).digest('hex');
const gitblob=b=>createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const course=Buffer.from(payload.course,'utf8');
assert.equal(course.length,16328);
assert.equal(sha256(course),'b9f0c657dee8d5bd2dd10cfed8d8205b464473a6b46f707c1336363dc170f800');
assert.equal(gitblob(course),payload.courseGitBlob);
for(const file of payload.files)assert.equal(gitblob(Buffer.from(file.content,'utf8')),file.gitBlobSha1,file.path);
await mkdir(root);
await mkdir(join(root,'evidence'));
await mkdir(join(root,'inputs'));
const manifest={preparedAt:new Date().toISOString(),receiverOwner:'estate-49f845d0dece/recall_import_receiving',root,runtimeSourceRef:payload.runtimeSourceRef,currentMain:payload.currentMain,courseSourceRef:payload.courseSourceRef,coursePath:'courses/membrane-transport.json',courseBytes:course.length,courseSha256:sha256(course),courseGitBlob:gitblob(course),sourceFiles:[]};
for(const file of payload.files){
 const path=join(root,'source',file.path),bytes=Buffer.from(file.content,'utf8');
 await mkdir(dirname(path),{recursive:true});await writeFile(path,bytes);
 manifest.sourceFiles.push({path:file.path,bytes:bytes.length,sha256:sha256(bytes),gitBlobSha1:gitblob(bytes),mode:'100644'});
}
await writeFile(join(root,'inputs','membrane-transport.json'),course);
await writeFile(join(root,'receive-membrane-import-trace.mjs'),payload.receiver);
manifest.receiver={path:'receive-membrane-import-trace.mjs',bytes:Buffer.byteLength(payload.receiver),sha256:sha256(Buffer.from(payload.receiver))};
await writeFile(join(root,'evidence','source-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
await writeFile(join(root,'evidence','runtime-correspondence.json'),JSON.stringify(payload.runtimeCorrespondence,null,2)+'\n');
console.log(JSON.stringify(manifest,null,2));
