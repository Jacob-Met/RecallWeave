import fs from 'node:fs';
import {spawn} from 'node:child_process';
const root='/tmp/hamon-levenshtein-68094585a1c2', project=root+'/candidate-source';
const capacity=fs.statfsSync(root);if(capacity.bavail*capacity.bsize<10000000)throw new Error('Insufficient receipt capacity.');
const args=[project+'/tools/check_edit_distance_browser.mjs','--root',project,'--browser','/usr/bin/chromium-browser','--output',root+'/browser-v1','--profile-parent','/dev/shm'];
const started=new Date().toISOString();
const stdout=fs.openSync(root+'/browser-v1.stdout.log','wx'),stderr=fs.openSync(root+'/browser-v1.stderr.log','wx');
const child=spawn(process.execPath,args,{cwd:project,stdio:['ignore',stdout,stderr]});
const running={started,runnerPid:process.pid,receiverPid:child.pid,executable:process.execPath,args,availableReceiptBytes:capacity.bavail*capacity.bsize};
fs.writeFileSync(root+'/browser-v1-running.json',JSON.stringify(running,null,2)+'\n',{flag:'wx'});
child.on('error',error=>{fs.writeFileSync(root+'/browser-v1-launch-error.txt',String(error)+'\n',{flag:'wx'});});
child.on('close',(code,signal)=>{
  const receipt={...running,finished:new Date().toISOString(),code,signal};
  fs.writeFileSync(root+'/browser-v1-exit.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
  fs.closeSync(stdout);fs.closeSync(stderr);console.log(JSON.stringify(receipt));process.exitCode=code===0?0:1;
});
console.log(JSON.stringify(running));
