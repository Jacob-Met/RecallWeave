# Independent receiving: RecallWeave stoichiometry

**Accepted for its stated educational scope.** The independent numerical and content receiver passed **109 checks, zero failures**, including **49 exact-rational numerical cases** and independently derived answers for all **12 course questions**. The recorded run used Node v22.22.1 at 2026-10-08T13:06:25.569Z. It covers the fixed-reaction, mole-input theoretical calculation and course content described below.

## Source and ownership

- Repository: https://github.com/Jacob-Met/RecallWeave ; feature issue: https://github.com/Jacob-Met/RecallWeave/issues/25
- Producer: HAMON `estate_production`, branch `estate/87eaaf0fdf63-stoichiometry`.
- Independent receiver: HAMON `estate_integration`, contribution `87eaaf0fdf63`.
- First frozen numerical/course source: `18719382ca165043037c194f4eac99a60f830cb7`, tree `8e7317066aa065b366e68f490a208ecd371d2b08`.
- Corrected product source: `0e833dca10354e94a00027196b867556ddaad31b`, tree `45dce01dd1e7d9bed51239606db2f0d958d63dc2`, parent `18719382ca165043037c194f4eac99a60f830cb7`.
- Accepted-main composition: `5e832633c4acb9fde49d2a4acfd5a25065e865bf`, tree `ab18534122ca14cb26552a1bb7eddc4efed22dcc`, parents `0e833dca10354e94a00027196b867556ddaad31b 003ce06c72fb3c7924a4414cd34053d87ae46d2f`. All five selected product-file blobs and SHA-256 values match the corrected product freeze exactly.
- Independent read-only Git-object receiving confirmed the final model, course, and UI bytes are identical to the earlier inspected source. The final HTML and renderer match the producer's corrected mobile-layout hashes. The model/course gate therefore applies unchanged to the corrected product source; it was not rerun for CSS changes.
- This packet does not modify the product or the existing app/importer. Product source snapshots retain the producer's identity.

| Final source file | SHA-256 |
|---|---|
| `src/stoichiometry.mjs` | `c25ce6ec843b9424b9d2cf70581cf02c91ded2cc17f7b598fcade9c28c347943` |
| `src/stoichiometry-ui.mjs` | `3f90d7ebc1af52d2868cc312d9b4efbb1626b06f1132524348381bcb19d45bd8` |
| `src/stoichiometry-page.mjs` | `e6935d401779a00d977bf541eccdc9c225ccaf000c912c0a34f1394511030c3e` |
| `courses/stoichiometry-foundations.json` | `0b0d499e75d02da6e18926c5366dfc76840a89cbd167cec1b5c1f839ae9110f1` |
| `courses/stoichiometry-explorer.html` | `47d1705e1a635bab153802c4f865634069b37697128c1e6a2b7a13ae66e4df6c` |

## Controls fixed before the implementation or answer keys were read

The first controls commit, `e78bdde722b905e36076fb189e4593f197c3229e`, was authored from the producer's public feature contract before reading their implementation, tests, fixtures, or answer keys. `author_controls.py` uses Python Fraction arithmetic and an independently specified chemical inventory. It generates exact expected quantities, classifications, and conservation controls in `oracle_cases.json` and `receiver_contract.json`.

The course extractor then exposed prompts and options only. The independent answer indices and rationales were committed as `674729bb4b77713686948ab539f3be6a7508abd9` before the producer's keys or explanations were revealed. `independent-course-answers.json` and both blinded extraction records preserve that sequence. Producer test files and fixtures were not read.

The first blinded extractor looked for an unconfirmed questions/cards container and returned zero prompts. That empty result was preserved. Inspection of the source container name showed the actual `items` field, after which the extractor exposed the 12 prompts without answer values. A failed native-home write during the independent answer freeze is also retained; the successful commit occurred in the receiver's own isolated tmpfs checkout before key disclosure.

## What the independent gate establishes

The model is restricted to these balanced reactions:

- 2 H₂ + O₂ → 2 H₂O
- N₂ + 3 H₂ → 2 NH₃
- 2 Mg + O₂ → 2 MgO

For each reactant, capacity is initial moles divided by its coefficient. The smallest capacity is the extent. Multiplying extent by each coefficient gives consumption or formation; initial minus consumed gives remaining material. The independent rational oracle checks those values and elemental conservation separately from the implementation's arithmetic.

The 49 numerical controls include all three reactions, both limiting sides, matched positive capacities, one absent reactant, both absent reactants, fractional extents, lower and upper input bounds, exact decimal ratios, one-millimole near ties, and examples where comparing raw amounts would choose the wrong reactant. All returned inventories remain nonnegative, and displayed amounts meet the stated eight-significant-figure rounding tolerance.

Other checks cover the balanced species metadata; admitted and refused decimal text; nontext rejection; the fixed reaction and two-amount boundary; readable worked-record line breaks; and the model's theoretical scope. Positive ties classify as matched; any zero capacity classifies separately as no-product.

All 12 independently derived course answers match the producer's key. The subsequent human review found their explanations and transfer prompts consistent with coefficient ratios, limiting/excess reasoning, matched exhaustion, zero-product cases, scaling, and conversion from mass before mole-ratio reasoning. The 12 question IDs are unique and their four prerequisite concept names are valid. This is a small beginner lesson on ideal theoretical amounts. It does not establish arbitrary equation parsing, experimental yield, reaction rate, equilibrium, or physical laboratory behavior.

The chemistry basis is consistent with [IUPAC's extent-of-reaction definition](https://goldbook.iupac.org/terms/view/E02283), [OpenStax Chemistry 2e, 4.4 Reaction Yields](https://openstax.org/books/chemistry-2e/pages/4-4-reaction-yields), and [OpenStax's chapter 4 summary](https://openstax.org/books/chemistry-2e/pages/4-summary), consulted 2026-10-08. The course wording and independent controls are original; this packet does not reproduce textbook passages.

## Offline browser evidence has separate provenance

The producer ran nine actual native-browser checkpoints for direct-file startup, calculation, input/result invalidation, genuine downloads, and corrected narrow-screen rendering. The first run exposed real mobile overflow and its screenshot was retained. The producer corrected intrinsic grid sizing, rebuilt the HTML, and measured settled content width against documentElement.clientWidth. Root independently visually accepted the corrected desktop and mobile captures. The mobile balance table intentionally scrolls within its container.

Those browser results are **producer evidence with root visual review**. This receiver did not launch a browser and does not claim an independent browser pass. Only bounded environment discovery occurred: the native home filesystem had no available space; Chromium advertised its own confined runtime directory, and a fresh empty directory could be created there. No confinement setting or existing browser profile was changed. Once root confirmed the complete browser gate, a duplicate matrix had no remaining qualification value.

## Replaying the independent gate

Use a disposable extraction of the supplied archive or a new clone of the receiver bundle. Node 22 or a compatible modern Node runtime and its standard library are sufficient:

```sh
node run-numerical-receiver.mjs
```

The command reads the included exact model/course snapshots and overwrites `numerical-content-receiving.json` in that disposable directory with the new run. Preserve the original archived report for provenance; its SHA-256 is `ff4953be7c146c4f83210507a04bea2e085f25cdee191495d711e2bc68aa9941`.

An optional first argument supplies an absolute model path. The course still comes from the included snapshot. For receiving another product revision, compare the model and course hashes with `final-source-correspondence.json` before drawing conclusions; a changed course requires deliberately receiving the changed content.

The Git bundle preserves both pre-disclosure commits and the final packet commit. The archive provides the tracked files without Git metadata. `FILE_MANIFEST.json` records every other tracked packet file's size and SHA-256. A separate handoff receipt records the final receiving commit/tree and bundle/archive hashes.
