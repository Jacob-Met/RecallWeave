#!/usr/bin/env python3
"""Freeze independent controls before reading producer source or tests."""
from fractions import Fraction
from decimal import Decimal, localcontext
import hashlib, json, pathlib, subprocess, time
root=pathlib.Path("/home/jacob/recallweave-stoich-receiving-87eaaf0fdf63")
assert root.is_dir() and not (root/".git").exists()
specs={
 "water":{"reactants":[{"formula":"H2","coefficient":2,"atoms":{"H":2}},{"formula":"O2","coefficient":1,"atoms":{"O":2}}],"products":[{"formula":"H2O","coefficient":2,"atoms":{"H":2,"O":1}}]},
 "ammonia":{"reactants":[{"formula":"N2","coefficient":1,"atoms":{"N":2}},{"formula":"H2","coefficient":3,"atoms":{"H":2}}],"products":[{"formula":"NH3","coefficient":2,"atoms":{"N":1,"H":3}}]},
 "magnesium":{"reactants":[{"formula":"Mg","coefficient":2,"atoms":{"Mg":1}},{"formula":"O2","coefficient":1,"atoms":{"O":2}}],"products":[{"formula":"MgO","coefficient":2,"atoms":{"Mg":1,"O":1}}]}
}
def exact(value):
 value=Fraction(value)
 with localcontext() as ctx:
  ctx.prec=40
  decimal=str(Decimal(value.numerator)/Decimal(value.denominator))
 return {"numerator":value.numerator,"denominator":value.denominator,"decimal":decimal}
def text_moles(mm):
 return (str(mm//1000)+"."+str(mm%1000).zfill(3)).rstrip("0").rstrip(".")
cases=[]
for reaction,spec in specs.items():
 c1,c2=[x["coefficient"] for x in spec["reactants"]]
 t=1000000//max(c1,c2)
 pairs=[
  ("both-absent",0,0),("first-absent",0,1000),("second-absent",1000,0),
  ("smallest-both",1,1),("smallest-first-largest-second",1,1000000),
  ("largest-first-smallest-second",1000000,1),("largest-both",1000000,1000000),
  ("raw-size-trap-a",7,3),("raw-size-trap-b",3,7),
  ("unequal-integer-inventory",2000,3000),
  ("matched-integer",c1*1000,c2*1000),("matched-three-mm-extents",c1*3,c2*3),
  ("largest-exact-match",c1*t,c2*t),
  ("one-mm-short-first",c1*t-1,c2*t),("one-mm-short-second",c1*t,c2*t-1)]
 if c1*t+1<=1000000: pairs.append(("one-mm-excess-first",c1*t+1,c2*t))
 if c2*t+1<=1000000: pairs.append(("one-mm-excess-second",c1*t,c2*t+1))
 for label,m1,m2 in pairs:
  n=[Fraction(m1,1000),Fraction(m2,1000)]
  capacities=[n[0]/c1,n[1]/c2]
  extent=min(capacities)
  if extent==0: classification="no-product"
  elif capacities[0]==capacities[1]: classification="matched"
  elif capacities[0]<capacities[1]: classification="first"
  else: classification="second"
  consumed=[c1*extent,c2*extent]
  remaining=[n[i]-consumed[i] for i in range(2)]
  products=[p["coefficient"]*extent for p in spec["products"]]
  elements=sorted({atom for entity in spec["reactants"]+spec["products"] for atom in entity["atoms"]})
  before={atom:sum(n[i]*r["atoms"].get(atom,0) for i,r in enumerate(spec["reactants"])) for atom in elements}
  after={atom:sum(remaining[i]*r["atoms"].get(atom,0) for i,r in enumerate(spec["reactants"]))+sum(products[i]*p["atoms"].get(atom,0) for i,p in enumerate(spec["products"])) for atom in elements}
  assert before==after and all(x>=0 for x in remaining)
  cases.append({"id":reaction+"/"+label,"reaction":reaction,"inputs":[text_moles(m1),text_moles(m2)],"input_millimoles":[m1,m2],"classification":classification,"extent":exact(extent),"initial":[exact(x) for x in n],"capacity":[exact(x) for x in capacities],"consumed":[exact(x) for x in consumed],"remaining":[exact(x) for x in remaining],"formed":[exact(x) for x in products],"atom_amounts_before":{k:exact(v) for k,v in before.items()},"atom_amounts_after":{k:exact(v) for k,v in after.items()}})
valid=[
 ("0",0),("000",0),("0.000",0),(".000",0),(".001",1),("1",1000),
 ("01.230",1230),("999.999",999999),("1000",1000000),("1000.000",1000000),
 (" \t.500\n",500),("00000000000000000000000000000000",0),("10.010",10010)]
invalid=[""," ",".", "1.", "+1","-0","-1","1e3","1E-3","Infinity","NaN","1_000","1,000","1 mol","1 0","1..0","1.0000","0.0001","1000.001","1001","000000000000000000000000000000000","١","１"]
contract={
 "schema":"independent-stoichiometry-controls/v1",
 "author":"estate-87eaaf0fdf63/integration",
 "authored_at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
 "producer_repository":"https://github.com/Jacob-Met/RecallWeave",
 "producer_issue":25,
 "producer_core_commit":"18719382ca165043037c194f4eac99a60f830cb7",
 "producer_core_tree":"8e7317066aa065b366e68f490a208ecd371d2b08",
 "producer_baseline":"4775af91ba6a5d4df787669f39b44364dd1e37ba",
 "independence":"Authored from the producer's interface/teaching contract and primary chemistry sources, before reading producer implementation, tests, fixtures, or course answer keys.",
 "amount_domain":"Decimal text, trimmed, 0..1000 mol inclusive, at most 3 fractional digits, no trailing dot/sign/exponent/unit coercion; bounded string length 32. Long outer-whitespace behavior is left unasserted because that boundary was not fully specified.",
 "reaction_specs":specs,
 "classification_values":["first","second","matched","no-product"],
 "prediction_values":["","first","second","matched","no-product"],
 "numeric_controls":[
  "Exact rational capacities and reaction extent; positive ties are distinct from any-zero no-product cases.",
  "Expected initial, consumed, remaining and product amounts; reaction coefficients multiply extent.",
  "Conservation of molar atom inventories from initial reactants to remaining reactants plus product.",
  "Nonnegative finite inventories; no reactant overconsumption; correct first/second limiting identity.",
  "Tiny amounts, fractional extents, equal decimal ratios, near ties separated by one millimole, and upper bounds.",
  "Each formatted amount stays within half a unit at its eighth significant digit, with finite parseable output."
 ],
 "content_controls":[
  "All three equations conserve every element; coefficients describe species amounts rather than changing formula subscripts.",
  "A limiting reactant is determined by available amount divided by its coefficient, not by raw smaller amount.",
  "Matched positive ratios exhaust both reactants without a single excess; any missing required reactant yields no product and consumes neither.",
  "Claims explicitly restrict outputs to ideal completion/no side reactions and theoretical amounts, without predicting actual yield, rate or equilibrium.",
  "Exactly twelve distinct course questions and four concepts; question prompts/options are inspected without answer keys, independent answers are frozen, then the supplied keys/explanations are checked.",
  "Numerical course answers are derived from the exact oracle where applicable; prompts and answer options must be unambiguous."
 ],
 "offline_workflow_controls":[
  "Open the exact generated HTML as file:// in an isolated existing native Chromium with networking disabled; no server, account or persistent application storage is required.",
  "Select reaction, enter mole amounts and optional prediction, compare, and inspect classification, capacities, consumed/product/excess quantities and element-balance rows.",
  "Changing either amount, reaction or prediction retires the displayed prior result and disables record download until successful recomparison.",
  "Invalid input exposes a clear error, leaves no active stale result, and cannot download a stale worked record.",
  "Download the actual visible worked record and verify reaction, input, prediction and computed quantities against the displayed result.",
  "Download and parse the actual twelve-question/four-concept course; compare it with the embedded course while leaving existing app/importer source untouched.",
  "Exercise a mismatched prediction, a matched outcome, a no-product outcome and an ammonia fractional-extent case."
 ],
 "primary_sources":[
  {"title":"IUPAC Gold Book: extent of reaction","url":"https://goldbook.iupac.org/terms/view/E02283","doi":"10.1351/goldbook.E02283","version":"5th edition, online version 5.0.0 (2025)","accessed":"2026-10-08","use":"Extent relates the change in each species amount to its signed stoichiometric number; our fixed forward-completion model uses the resulting positive consumption/formation ratios."},
  {"title":"OpenStax Chemistry 2e, 4.4 Reaction Yields","url":"https://openstax.org/books/chemistry-2e/pages/4-4-reaction-yields","accessed":"2026-10-08","use":"The reactant supporting less product limits the ideal product amount; excess remains. Theoretical stoichiometric amount is distinguished from actual yield."},
  {"title":"OpenStax Chemistry 2e, Chapter 4 Summary","url":"https://openstax.org/books/chemistry-2e/pages/4-summary","accessed":"2026-10-08","use":"Balanced equations conserve the number of atoms of each element. Equation coefficients define stoichiometric conversion ratios."}
 ]
}
oracle={"schema":"independent-exact-rational-stoichiometry-oracle/v1","cases":cases,"valid_parse_cases":[{"text":t,"expected_millimoles":n} for t,n in valid],"invalid_parse_cases":invalid,"nontext_rejections":[None,1,{},[]]}
(root/"receiver_contract.json").write_text(json.dumps(contract,indent=2,ensure_ascii=False)+"\n")
(root/"oracle_cases.json").write_text(json.dumps(oracle,indent=2,ensure_ascii=False)+"\n")
basis="""# Independent stoichiometry receiving controls

These controls were authored before reading the producer's implementation,
tests, fixtures, or course answer keys. The producer supplied only the fixed
reaction/domain/teaching contract, exported interface, enum values, and frozen
core pin. The numerical oracle uses Python exact fractions and an independent
species/atom inventory.

The three equations are checked for elemental conservation. Limiting identity
comes from coefficient-normalized capacities; positive ties and absent-reactant
outcomes have separate expectations. One-millimole near ties, smallest inputs,
upper bounds and fractional extents are deliberate controls against raw-amount
comparison, floating tie inference and integer truncation.

The content review will first reveal only each prompt and its options. The
receiver will record an independent answer and rationale before seeing the
embedded answer key and explanation. Browser receiving will execute the actual
direct-open HTML with a private supported Chromium profile and networking
disabled; it will inspect visible quantities and actual downloads, including
stale-result retirement.

Primary-source basis and full accepted scope are in receiver_contract.json.
All initial expected values are in oracle_cases.json; later adapters may map
the declared interface, but must not silently rewrite these controls.
"""
(root/"CONTROL_BASIS.md").write_text(basis)
commands=[
 ["git","init","--initial-branch=independent-controls"],
 ["git","add","author_controls.py","receiver_contract.json","oracle_cases.json","CONTROL_BASIS.md"],
 ["git","-c","user.name=HAMON estate-87eaaf0fdf63 integration","-c","user.email=estate-87eaaf0fdf63-integration@localhost","commit","-m","Freeze independent stoichiometry controls before producer source and tests"]
]
for args in commands:
 result=subprocess.run(args,cwd=root,text=True,capture_output=True)
 if result.returncode: raise RuntimeError(result.stdout+result.stderr)
commit=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()
tree=subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=root,text=True).strip()
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/"author_controls.py",root/"receiver_contract.json",root/"oracle_cases.json",root/"CONTROL_BASIS.md")}
receipt={"control_commit":commit,"control_tree":tree,"cases":len(cases),"valid_parse_cases":len(valid),"invalid_text_cases":len(invalid),"files_sha256":manifest,"producer_source_read":False,"producer_tests_read":False,"producer_course_keys_read":False}
(root/"initial-controls-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt))
