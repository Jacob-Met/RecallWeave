RECALLWEAVE — STABLE MATCHING
===========================

Extract this archive, keep the folder structure, and open START-HERE.html.

1. Explorer: courses/stable-matching-explorer.html
   Enter or load strict complete best-first preferences for 1–4 participants
   on each side, choose a proposing side, then Apply preferences.
   Inspect each proposal and every complete matching. Any edit retires the
   current result and observation download until you apply again.

2. Lesson: courses/stable-matching.json
   Open demo.html, choose this file under "Bring your own lesson", review
   the 12-question preview, then choose "Start this deck".
   The existing learner provides explanations, review, practice and notes.

3. Worked guide: courses/stable-matching.md
   Original examples, traces, scope limits and mathematical references.

The course/guide downloads preserve the exact original UTF-8 files.
The observation download contains the complete applied profile, all states
and complete matchings, the selected step and inspected matching, and
the hashes of the six source inputs used to build the explorer.

No server, account, provider, persistent browser storage or network request
is required by these pages. Keep downloads to retain your work.
A new page load starts a new tab-memory session.

MODEL LIMITS
------------
Strict complete equal-size one-to-one preferences only. Ordinal ranks are
not utilities. Stability does not guarantee fairness or uniqueness.
No ties, incomplete lists, capacities, policy constraints or real allocation.
Learning efficacy is not measured by this lesson.

PROVENANCE
----------
The demo learner is copied byte for byte from the independently received
RecallWeave source closure at canonical commit
1c8ece2713554f95b0e507297a34909d50222736.
The same learner bytes were preserved in the later observed canonical
698902f9c9c1d5c5023092b85b3632a7cb7a01ed.
This package contains native qualified files once its accompanying receiving
receipt is complete. It does not claim repository integration or deployment.
GitHub Actions-triggering publication is held under Jacob's estate direction.

MANIFEST.json lists exact SHA-256 and byte counts for the other six files.
The package's external custody receipt binds the ZIP and every member.
Original lesson prose/examples: CC0-1.0. Existing learner and cited works
retain their original attribution and rights.
