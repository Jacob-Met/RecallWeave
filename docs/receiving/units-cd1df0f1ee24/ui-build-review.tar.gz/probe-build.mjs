import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { buildUnitExplorer, unitExplorerPath } from './fixture/tools/build-unit-conversion-explorer.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const coursePath = join(root, 'fixture/courses/units-and-dimensions.json');
const original = readFileSync(coursePath, 'utf8');
const checks = [];
const sha256 = text => createHash('sha256').update(text).digest('hex');
function check(name, passed, detail = null) {
  checks.push({ name, passed: Boolean(passed), detail });
  if (!passed) throw new Error(name);
}
function scriptAndCourse(html) {
  const scripts = html.match(/<script\b/gi) || [];
  const endings = html.match(/<\/script\s*>/gi) || [];
  check('single_inline_script_' + checks.length, scripts.length === 1 && endings.length === 1);
  const script = html.slice(html.indexOf('<script>') + 8, html.lastIndexOf('</script>'));
  new vm.Script(script, { filename: 'standalone-explorer.js' });
  const marker = 'const unitCourseText = ';
  const start = script.indexOf(marker) + marker.length;
  if (start < marker.length || script[start] !== '"') throw new Error('Missing embedded JSON string');
  let escaped = false;
  let end = start + 1;
  for (; end < script.length; end++) {
    if (!escaped && script[end] === '"') break;
    if (!escaped && script[end] === '\\') escaped = true;
    else escaped = false;
  }
  return { script, course: JSON.parse(script.slice(start, end + 1)) };
}

const built = buildUnitExplorer();
check('frozen_output_matches', sha256(built) === '1502d8bb2a86455470ae21b08c2da21eff7296f683f8d95b6753a3708b275853', { bytes: Buffer.byteLength(built), sha256: sha256(built) });
const current = scriptAndCourse(built);
check('embedded_course_is_exact_source_text', current.course === original, { bytes: Buffer.byteLength(original), sha256: sha256(original), items: JSON.parse(original).items.length });
check('no_runtime_module_declarations', !/^\s*(?:import|export)\s/m.test(current.script));

const fixture = JSON.parse(original);
fixture.title = 'Literal </script><b>$&</b> "quoted" text \u2028 \u2029';
const sentinelText = JSON.stringify(fixture, null, 2) + '\n';
mkdirSync(join(root, 'samples'), { recursive: true });
writeFileSync(join(root, 'samples/course-script-sentinel.json'), sentinelText);
try {
  writeFileSync(coursePath, sentinelText);
  const escapedBuild = buildUnitExplorer();
  const escaped = scriptAndCourse(escapedBuild);
  check('script_delimiter_dollar_and_unicode_round_trip', escaped.course === sentinelText, { sha256: sha256(sentinelText) });
  check('sentinel_is_not_raw_html', !escapedBuild.includes('</script><b>'));
  check('derived_build_is_deterministic', buildUnitExplorer() === escapedBuild);
} finally {
  writeFileSync(coursePath, original);
}

// The stale-output guard must refuse a misleading generated page without repairing it.
const stale = built + '\n<!-- own stale-output negative control -->\n';
writeFileSync(unitExplorerPath, stale);
const child = spawnSync(process.execPath, [join(root, 'fixture/tools/build-unit-conversion-explorer.mjs'), '--check'], { encoding: 'utf8' });
writeFileSync(join(root, 'stale-check.stdout.log'), child.stdout);
writeFileSync(join(root, 'stale-check.stderr.log'), child.stderr);
check('check_rejects_stale_output', child.status !== 0 && child.stderr.includes('Rebuild the unit conversion explorer from its current sources.'), { exit: child.status });
check('failed_check_preserves_stale_bytes', readFileSync(unitExplorerPath, 'utf8') === stale);

const manifest = JSON.parse(readFileSync(join(root, 'input-manifest.json'), 'utf8'));
const mismatches = manifest.filter(file => sha256(readFileSync(join(root, 'fixture', file.path))) !== file.sha256).map(file => file.path);
check('six_frozen_fixture_inputs_restored', mismatches.length === 0, mismatches);
const result = { node: process.version, scope: 'Independent deterministic build and course-embedding probes only; no browser execution or arithmetic assertions', checks, passed: checks.filter(x => x.passed).length, failed: checks.filter(x => !x.passed).length };
writeFileSync(join(root, 'build-probe-receipt.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
