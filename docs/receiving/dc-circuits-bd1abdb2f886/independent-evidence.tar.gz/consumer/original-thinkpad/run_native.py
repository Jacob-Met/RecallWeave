import datetime, hashlib, json, pathlib, subprocess, sys, time
qa=pathlib.Path("/tmp/recallweave-dc-learner-receiving-bd1abdb2f886")
driver=qa/"receive_learner.mjs"
preflight=subprocess.run(["node","--check",str(driver)],capture_output=True,text=True)
preflight_record={"driver_sha256":hashlib.sha256(driver.read_bytes()).hexdigest(),"syntax_exit":preflight.returncode,"stdout":preflight.stdout,"stderr":preflight.stderr,"python":sys.version}
(qa/"preflight.json").write_text(json.dumps(preflight_record,indent=2)+"\n")
print(json.dumps(preflight_record),flush=True)
if preflight.returncode:
    raise SystemExit(preflight.returncode)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
start=time.monotonic()
command=["node",str(driver)]
log_path=qa/"first-process.log"
with log_path.open("x",encoding="utf-8") as log:
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line,end="",flush=True)
    code=process.wait()
receipt={"command":command,"started":started,"finished":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsed_seconds":time.monotonic()-start,"exit_code":code,"log_sha256":hashlib.sha256(log_path.read_bytes()).hexdigest(),"driver_sha256":hashlib.sha256(driver.read_bytes()).hexdigest()}
with (qa/"first-process.json").open("x",encoding="utf-8") as out:
    out.write(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
raise SystemExit(code)
