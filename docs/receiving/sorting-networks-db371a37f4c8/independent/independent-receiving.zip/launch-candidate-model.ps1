$ErrorActionPreference = 'Stop'
$root = 'D:/Hamon/receiving/recall-sorting-networks-root-db371a37f4c8'
$os = Get-CimInstance Win32_OperatingSystem
$c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='D:'"
$guard = [ordered]@{schema='recall253-root-native-guard-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;machine=[Environment]::MachineName;user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;boot=$os.LastBootUpTime.ToUniversalTime().ToString('o');freeC=[long]$c.FreeSpace;freeD=[long]$d.FreeSpace;freeMemory=[long]$os.FreePhysicalMemory*1024;floorC=1073741824;floorD=1073741824;floorMemory=2147483648}
$guard | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 "$root/CANDIDATE-MODEL-r1-GUARD.json"
if ($guard.machine -ne 'MSI' -or $guard.user -ne 'MSI\Veria' -or $guard.boot -ne '2026-10-04T04:03:32.5000000Z' -or $guard.freeC -lt $guard.floorC -or $guard.freeD -lt $guard.floorD -or $guard.freeMemory -lt $guard.floorMemory) { throw 'Identity, boot or resource guard refused' }
& 'C:/Program Files/nodejs/node.exe' 'D:/Hamon/receiving/recall-sorting-networks-root-db371a37f4c8/control-native.mjs' 'D:/Hamon/receiving/recall-sorting-networks-root-db371a37f4c8/candidate-model-spec.json'
$childCode=$LASTEXITCODE
[ordered]@{at=[DateTime]::UtcNow.ToString('o');pid=$PID;childExit=$childCode} | ConvertTo-Json | Set-Content -Encoding UTF8 'D:/Hamon/receiving/recall-sorting-networks-root-db371a37f4c8/CANDIDATE-MODEL-r1-OUTER.json'
exit $childCode
