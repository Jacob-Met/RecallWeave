import pathlib,zipfile,hashlib,json,re,os,datetime,subprocess
root=pathlib.Path('/tmp/recall-coalition-power-81ba1ed0179c');a=root/'delivery/coalition-power-offline.zip';b=root/'delivery-r2/coalition-power-offline.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(a.read_bytes())=='44b5d5afd013bc6cbdf5fd13e7fec46fcf9ef122a6cce028b1302ab59a0f2c39'
assert len(b.read_bytes())==49657 and sha(b.read_bytes())=='0032bad8f7ea4ed28d80d020012ea7ab8de6160670632d8328bbbe8db9b816be'
manifest=(root/'delivery-r2/portable-manifest.json').read_bytes();assert sha(manifest)=='affca234ea2444bb7422b03d8e4d14434dd7f3953f2485508ab6306108c9c59c'
m=json.loads(manifest);changes=[];unchanged=[]
with zipfile.ZipFile(a) as za,zipfile.ZipFile(b) as zb:
 assert za.namelist()==zb.namelist()
 for name in za.namelist():
  old=za.read(name);new=zb.read(name)
  rel=name.removeprefix('coalition-power-offline/');item=next(x for x in m['entries'] if x['path']==rel);assert len(new)==item['bytes'] and sha(new)==item['sha256']
  if old==new:unchanged.append(rel);continue
  if rel=='courses/coalition-power-explorer.html':
   before=b'button,a:focus-visible';after=b'button:focus-visible,a:focus-visible'
   assert old.count(before)==1 and old.replace(before,after)==new
   changes.append({'path':rel,'exact_delta':'Only button selector changes to button:focus-visible; all other bytes identical.','sha256':sha(new)})
   native=subprocess.run(['git','-C',str(root/'source'),'show',m['source']+':'+rel],capture_output=True,check=True);assert native.stdout==new
  elif rel=='README.txt':
   before=b'82d7317bb2fa93f8a7b5506a9efbad4448e096c7';after=m['source'].encode();assert len(after)==40
   assert old.count(before)==1 and old.replace(before,after)==new
   changes.append({'path':rel,'exact_delta':'Only native partial-history source identity advances from82d7317 to'+m['source']+'.','sha256':sha(new)})
  else:raise AssertionError(rel)
 assert len(changes)==2 and len(unchanged)==4
d={'schema':'recall-coalition-power.independent-portable-route-review-addendum/1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'estate-81ba1ed0179c/integration','status':'pass','prior_receipt_sha256':'94453b7603788f09a48a7599e586ec105070518c2599cd89b102182596bf25d6','final_archive':{'path':str(b),'bytes':len(b.read_bytes()),'sha256':sha(b.read_bytes())},'manifest_sha256':sha(manifest),'changes':changes,'unchanged':unchanged,'scope':'Only exact ZIP byte-delta/source identity receiving. All reviewed wording, relative routes, course-versus-observation distinctions and no-auto-save instructions remain unchanged. Final HTML matches the updated native source object. No browser/math/tests or source edits. Earlier R1 browser claims are not promoted to the changed HTML; coordination retains its separate focused R2 browser receipt.','requested_changes':[]}
raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();p=pathlib.Path('/run/user/1000/scpf81/coalition-portable-review-r2.json')
with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
print(json.dumps({'path':str(p),'bytes':len(raw),'sha256':sha(raw),'status':d['status']}))
