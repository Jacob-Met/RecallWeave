import os, json, pathlib, hashlib, subprocess, glob, datetime, sys, re
root = pathlib.Path('/home/jacob/recallweave-dc-circuits-bd1abdb2f886')
qa = pathlib.Path('/home/jacob/recallweave-dc-circuits-bd1abdb2f886-qa')
base = 'd202fdc8b3608c5321f83e1bf6f9a2ceb253f14b'
owned = ['courses/dc-circuits.json','courses/dc-circuits.md','courses/dc-circuits-lab.html','src/dc-circuits.mjs','src/dc-circuits-ui.mjs','templates/dc-circuits-lab.html','tools/build-dc-circuits.mjs','tests/dc-circuits.test.mjs','tests/dc-circuits-course.test.mjs']
def command(args):
    return subprocess.check_output(args, cwd=root, text=True).strip()
def file_info(path):
    raw=(root/path).read_bytes()
    return {'path':path,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'executable':bool((root/path).stat().st_mode & 0o111)}
assert command(['git','rev-parse','HEAD']) == base
assert command(['git','diff','--name-only','HEAD']) == ''
stat=os.statvfs(qa)
assert stat.f_bavail*stat.f_frsize >= 8*1024*1024, 'need 8 MiB to retain native gate evidence'
tree=subprocess.check_output(['git','ls-tree','-rz',base],cwd=root)
tracked=[]
for record in tree.split(b'\0'):
    if not record: continue
    meta,path=record.split(b'\t',1)
    mode,kind,blob=meta.decode().split()
    assert kind=='blob', 'unexpected tracked object type'
    path=os.fsdecode(path)
    entry=file_info(path)
    assert entry['git_blob']==blob, path+' differs from receiving base'
    assert entry['executable']==(mode=='100755'), path+' mode differs'
    tracked.append(entry)
before=tracked+[file_info(p) for p in owned]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
commands=[]
runs=[
 ('standalone-parity',['node','tools/build-dc-circuits.mjs','--check']),
 ('complete-node-suite',['node','--test',*sorted(glob.glob('tests/*.test.mjs',root_dir=root))]),
]
for label,args in runs:
    result=subprocess.run(args,cwd=root,capture_output=True,timeout=180)
    for stream,data in [('stdout',result.stdout),('stderr',result.stderr)]:
        path=qa/(label+'-current.'+stream)
        with open(path,'xb') as output:
            output.write(data); output.flush(); os.fsync(output.fileno())
    commands.append({'name':label,'args':args,'exit':result.returncode,
                     'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
                     'stderr_sha256':hashlib.sha256(result.stderr).hexdigest(),
                     'stdout_bytes':len(result.stdout),'stderr_bytes':len(result.stderr)})
    print(json.dumps({'gate':label,'exit':result.returncode,'summary':result.stdout.decode('utf-8',errors='replace').splitlines()[-9:]}),flush=True)
    if result.returncode: break
after=[file_info(p['path']) for p in before]
assert before==after, 'source changed during native gates'
receipt={'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'native':{'node':command(['node','--version']),'python':sys.version,'platform':sys.platform},
         'base':base,'base_tree':command(['git','rev-parse','HEAD^{tree}']),
         'original_leaf_count':len(tracked),'owned_product_count':len(owned),
         'commands':commands,'source_before':before,'source_after':after,'source_unchanged':True,
         'all_gates_pass':len(commands)==len(runs) and all(x['exit']==0 for x in commands)}
encoded=(json.dumps(receipt,indent=2)+'\n').encode()
path=qa/'native-gates-current.json'
with open(path,'xb') as output:
    output.write(encoded);output.flush();os.fsync(output.fileno())
assert path.read_bytes()==encoded
print(json.dumps({'receipt':str(path),'sha256':hashlib.sha256(encoded).hexdigest(),'bytes':len(encoded),'all_gates_pass':receipt['all_gates_pass'],'original_leaf_count':len(tracked),'owned_product_count':len(owned)}),flush=True)
if not receipt['all_gates_pass']:sys.exit(1)
