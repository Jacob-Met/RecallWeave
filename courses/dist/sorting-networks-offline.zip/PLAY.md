# Open the sorting-network lab

Extract this archive to a new folder, keeping the courses subfolder.
Open courses/sorting-networks-explorer.html in your browser.
Choose an example, choose Use example as draft, then Run network.
Follow each comparator and select any binary case to inspect a witness.
Editing the wire/value/pair draft retires the prior result until another Run.

Use the three download buttons to keep the accepted configuration, complete
observation and fixed lesson. Open demo.html, choose the downloaded lesson,
review its preview and explicitly Start this deck. The learner is the exact
unchanged canonical RecallWeave standalone consumer.

No server, installation, account or network connection is required for the lab
or learner. The reference hyperlink is optional and external. Nothing is saved
automatically. Configuration JSON is an inspection/reuse artifact; this page
does not import it. The guide describes the exact bounds and model.

Original source: Jacob-Met/RecallWeave
ec07bf3989132130759e5c00c6cb02eef19709d3
tree a839b6877bf2824f134443829d1ce62e1bd79e50
Source scope: issue253, all new sorting-network paths; shared learner unchanged.

Author native and consumer checks are complete. Independent receiving and
root acceptance remain pending at this package creation. That dated status
will be supplemented by final qualification rather than silently rewritten.
Keep this original ZIP and source manifest for recovery.
