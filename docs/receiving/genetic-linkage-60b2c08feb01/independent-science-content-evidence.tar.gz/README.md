# Independent linkage scientific and content receiving

Accepted exact sources: model9d3c6f7e, clarified course5a345bb6 and guide6b156ad6. Read independent-review.json for full identities, results and limits. Browser/learner integration is a separate receiver's lane.

Chronology is retained rather than collapsed:
1. The exact seven-member pre-candidate mathematical capsule208aa76f froze assumptions, independent analytic oracle and driver, with receiver-only calibration.
2. The exact nine-member blind capsuleced54154 contains prompts1edf and twelve independently solved answers69ac, sealed before full original course/key disclosure.
3. Original coursec44 passed the native schema/literal/answer check. Manual receiving then found three under-explicit symmetry premises in standalone questions; the correct key/arithmetic was not rejected.
4. Corrected course5a345 adds only the three authorized prefix sentences. A separate targeted receipt admits it and verifies every other field unchanged. Removing those literal prefixes also restores the entire original UTF-8 source.
5. The unchanged frozen model receiver ran once on model9d3c and passed all five groups. Guide6b156 was fully reviewed without new product execution.

Native evidence records actual argv, exit, stdout/stderr and before/after source identities. The actual independent runtime was Nodev24.19.0 on Linux; a Node20+ usage statement does not mean a Node20 matrix ran. No browser or hostedAction was executed here.

The receiver directory contains runnable copies of the frozen scripts and native deck validator. Scripts accept source paths explicitly; raw historical private paths describe where those real runs occurred. Do not confuse a later replay with the preserved first results.

The two original nested freeze archives are byte-identical to their canonical Git blobs. members.json lists byte length, Git blob SHA1 and SHA256 for every other regular archive member; no escaping paths or symlinks are included.
