#!/usr/bin/env python3
"""Verify this archive's exact payload without extracting or executing it."""
import hashlib,json,sys,tarfile
with tarfile.open(sys.argv[1],"r:gz") as archive:
    records=archive.getmembers()
    names=[entry.name for entry in records]
    assert len(names)==len(set(names)), "duplicate archive name"
    assert all(entry.isfile() and not entry.name.startswith("/") and ".." not in entry.name.split("/") for entry in records), "unexpected archive entry"
    manifest=json.load(archive.extractfile("archive-manifest.json"))
    expected={member["path"]:member for member in manifest["payload"]}
    assert set(names)==set(expected)|{"archive-manifest.json"}, "payload names differ"
    for name,pin in expected.items():
        data=archive.extractfile(name).read()
        assert len(data)==pin["bytes"], name
        assert hashlib.sha256(data).hexdigest()==pin["sha256"],name
        assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==pin["gitBlob"],name
print(json.dumps({"status":"pass","payloadMembers":len(expected),"archiveEntries":len(names)}))
