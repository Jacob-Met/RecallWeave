import datetime,hashlib,importlib.util,json,pathlib,shutil,subprocess,os
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
known=[4380,6084,3816,4420,22932,22928,10192,4176,26480,18356,28040,22636,24296,27992,29076,23212,12184]
command="$ids=@("+','.join(map(str,known))+");$mine=$PID;@{known=@(Get-CimInstance Win32_Process | Where-Object {$_.ProcessId -in $ids} | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine);namespace=@(Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -like '*recall-genotype-counts-db371a37f4c8*' -and $_.ProcessId -ne $mine -and $_.ProcessId -ne "+str(os.getpid())+" -and $_.Name -ne 'powershell.exe'} | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine)} | ConvertTo-Json -Depth 5 -Compress"
p=subprocess.run(['powershell','-NoProfile','-Command',command],capture_output=True,timeout=20);assert p.returncode==0
c=json.loads(p.stdout.decode('utf-8-sig'));assert not c['namespace']
rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'knownPids':known,'census':c,'tmpAbsent':not (R/'browser-r1/tmp').exists(),'controller':json.loads((R/'browser-controller-r1.json').read_text()),'existingPdfTools':{name:(importlib.util.find_spec(name).origin if importlib.util.find_spec(name) else None) for name in ['fitz','pypdf','pdfplumber','pypdfium2']},'existingPdfExecutables':{name:shutil.which(name) for name in ['pdftoppm','pdfinfo']}}
assert rec['tmpAbsent'];assert rec['controller']['wrapperExit']==0
(R/'BROWSER-CLOSURE-r1.json').write_bytes((json.dumps(rec,indent=2)+'\n').encode());print(json.dumps(rec))
