const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');

const source = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3]);
const browserBin = process.argv[4];
fs.mkdirSync(output, {recursive: true});
process.env.TMPDIR = path.join(output, 'temporary');
fs.mkdirSync(process.env.TMPDIR, {recursive: true});
const {chromium} = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'playwright'));
const manifest = JSON.parse(fs.readFileSync(process.argv[5]));
const expected = {...manifest.changedSha256, ...manifest.preservedSha256};
function hashes() {
  return Object.fromEntries(Object.keys(expected).map(name => [name, crypto.createHash('sha256').update(fs.readFileSync(path.join(source, name))).digest('hex')]));
}

function smallDeck(title = 'Independent course B') {
  return {
    format:'recallweave-deck/1', title, attribution:'Independent receiving fixture', license:'Synthetic verification content',
    concepts:['toString', 'constructor'], items:[
      {id:'a', concept:'toString', prerequisites:[], prompt:'Choose the explicitly recorded observation.', options:['A guess','An assumption','The record'], answer:2, explanation:'The record is the specified observation.', transfer:'Name an observation before an action.'},
      {id:'b', concept:'constructor', prerequisites:['toString'], prompt:'Which option keeps the stated order?', options:['Observe, then decide','Decide, then guess'], answer:0, explanation:'This fixture asks for observation before decision.', transfer:'State the two steps.'}
    ]
  };
}

function maximumDeck() {
  const base = smallDeck();
  base.title = 'L'.repeat(160);
  base.attribution = 'A'.repeat(2000);
  base.license = 'License '.repeat(250);
  base.concepts = Array.from({length:32}, (_,i) => i === 0 ? 'C'.repeat(80) : `Concept ${i}`);
  const item = base.items[0];
  base.items = Array.from({length:100}, (_,i) => ({...item, id:`q${String(i).padStart(3,'0')}`, concept:base.concepts[i % 32], prerequisites:i % 32 ? [base.concepts[i % 32 - 1]] : [], prompt:`Question ${i}: choose its stated record.`, options:['Wrong','Record'], answer:1}));
  Object.assign(base.items[0], {prompt:'P'.repeat(2000), options:['W'.repeat(1000),'R'.repeat(1000)], explanation:'E'.repeat(4000), transfer:'T'.repeat(2000)});
  assert.ok(Buffer.byteLength(JSON.stringify(base)) < 262144);
  return base;
}

const mime = {'.html':'text/html', '.mjs':'text/javascript', '.css':'text/css', '.json':'application/json'};
const server = http.createServer((req,res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    const target = path.resolve(source, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!target.startsWith(source + path.sep)) {res.writeHead(403); return res.end();}
    const data = fs.readFileSync(target);
    res.writeHead(200, {'Content-Type':mime[path.extname(target)] || 'application/octet-stream'});res.end(data);
  } catch {res.writeHead(404);res.end();}
});

(async () => {
  const receipt = {candidate:manifest.candidate, base:manifest.base, checks:[], errors:[], source_before:hashes()};
  assert.deepEqual(receipt.source_before, expected);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  let browser;
  try {
    browser = await chromium.launch({headless:true, executablePath:browserBin, args:['--no-sandbox','--disable-dev-shm-usage']});
    receipt.browser = browser.version();
    for (const [surface,url] of [['modular',origin+'/index.html'],['standalone','file://'+path.join(source,'demo.html')]]) {
      const context = await browser.newContext({viewport:{width:390,height:844}});
      await context.addInitScript(() => {
        let seed = 41;
        Math.random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
      });
      const page = await context.newPage();
      const errors=[], external=[];
      page.on('pageerror', error => errors.push(String(error)));
      page.on('request', request => { if (/^https?:/.test(request.url()) && !request.url().startsWith(origin+'/')) external.push(request.url()); });
      await page.goto(url);
      await page.locator('#start-button').waitFor();
      const upload = async deck => page.locator('#deck-file').setInputFiles({name:'course.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(deck))});
      const checkWidth = async label => {const sizes=await page.evaluate(() => ({width:innerWidth,scroll:document.documentElement.scrollWidth}));assert.ok(sizes.scroll <= sizes.width+1, `${surface} ${label}: ${JSON.stringify(sizes)}`);};

      await upload(maximumDeck());
      await page.locator('#start-deck').waitFor();
      assert.equal(await page.locator('#deck-preview ol > li').count(), 100);
      await checkWidth('maximum preview');
      await page.locator('#start-deck').click();
      assert.equal(await page.locator('#step-count').innerText(), '0 / 100');
      assert.equal(await page.locator('.mastery-row').count(), 32);
      assert.equal(await page.locator('.question-card h2').innerText(), 'P'.repeat(2000));
      await checkWidth('maximum question');
      await page.locator('[data-choice="0"]').click();
      await checkWidth('maximum feedback');
      assert.equal(await page.locator('#step-count').innerText(), '1 / 100');
      receipt.checks.push(`${surface}: maximum accepted content renders and answers without phone overflow`);

      await upload(smallDeck());
      await page.locator('#start-deck').waitFor();
      await page.locator('#next-button').click();
      await page.locator('[data-choice="1"]').click();
      assert.equal(await page.locator('#step-count').innerText(), '2 / 100');
      assert.equal(await page.locator('#deck-preview-title').innerText(), 'Independent course B');
      const live = await page.locator('#session-content').innerHTML();
      await page.locator('#cancel-deck').click();
      assert.equal(await page.locator('#session-content').innerHTML(), live);
      assert.equal(await page.locator('#step-count').innerText(), '2 / 100');
      receipt.checks.push(`${surface}: a staged deck permits current learning; cancellation preserves the later answer`);

      await upload(smallDeck());
      await page.locator('#start-deck').click();
      assert.equal(await page.locator('#step-count').innerText(), '0 / 2');
      const firstOrder = await page.locator('[data-choice]').evaluateAll(buttons => buttons.map(button => Number(button.dataset.choice)));
      assert.deepEqual([...firstOrder].sort(), [0, 1, 2]);
      await page.locator('[data-choice="0"]').click();
      await page.locator('#next-button').click();
      await page.locator('[data-choice="0"]').click();
      await page.locator('#next-button').click();
      assert.match(await page.locator('#first-try-summary').innerText(), /1 of 2/);
      assert.equal(await page.locator('.review-item').count(),2);
      const mastery = await page.locator('.mastery-row output').allTextContents();
      await page.locator('#practice-button').click();
      assert.deepEqual(await page.locator('[data-practice-choice]').evaluateAll(buttons => buttons.map(button => Number(button.dataset.practiceChoice))), firstOrder);
      await page.locator('[data-practice-choice="2"]').click();
      await page.locator('#practice-next').click();
      assert.deepEqual(await page.locator('.mastery-row output').allTextContents(), mastery);
      assert.match(await page.locator('#first-try-summary').innerText(), /1 of 2/);
      receipt.checks.push(`${surface}: explicit switch uses imported answers and object-key concepts; practice leaves first evidence unchanged`);

      const saveNotes = async name => {
        const promised = page.waitForEvent('download');
        await page.locator('#save-notes-button').click();
        const download = await promised;
        assert.equal(await download.failure(), null);
        const saved = path.join(output, surface + '-' + name + '.txt');
        await download.saveAs(saved);
        return fs.readFileSync(saved, 'utf8');
      };
      const notes = await saveNotes('imported-practice');
      assert.ok(notes.includes('Independent course B'));
      assert.ok(notes.includes('Independent receiving fixture'));
      assert.ok(notes.includes('Synthetic verification content'));
      assert.ok(notes.includes('Your first answer: A guess'));
      assert.ok(notes.includes('Correct answer: The record'));
      assert.ok(notes.includes('Practice answer: The record'));
      assert.match(notes, /1 of 2 connections correct on the first try/);
      assert.match(notes, /Complete: 1 of 1 practice answers recorded; 1 correct on retry/);
      assert.ok(notes.includes('toString:'));
      assert.ok(notes.includes('constructor:'));
      assert.ok(!notes.includes('OpenStax'));
      receipt.checks.push(`${surface}: actual imported study-note download keeps canonical first choices, corrected practice and selected metadata`);
      const completed = await page.locator('#session-content').innerHTML();
      await upload(smallDeck('Same filename, different course'));
      await page.locator('#start-deck').waitFor();
      assert.equal(await page.locator('#deck-preview-title').innerText(),'Same filename, different course');
      assert.equal(await page.locator('#session-content').innerHTML(),completed);
      await page.locator('#cancel-deck').click();
      await page.locator('#reset-button').click();
      assert.equal(await page.locator('#lesson-description').innerText(),'Independent course B');
      assert.equal(await page.locator('#step-count').innerText(),'0 / 2');
      const six = smallDeck('Six choices after the same question IDs');
      six.attribution = 'Second deck attribution';
      six.license = 'Second deck license';
      six.items[0].options = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five ✓'];
      six.items[0].answer = 5;
      six.items[1].options = ['Later wrong', 'Later correct'];
      six.items[1].answer = 1;
      await upload(six);
      await page.locator('#start-deck').click();
      const sixOrder = await page.locator('[data-choice]').evaluateAll(buttons => buttons.map(button => Number(button.dataset.choice)));
      assert.deepEqual([...sixOrder].sort(), [0, 1, 2, 3, 4, 5]);
      assert.deepEqual(await page.locator('.choice-key').allTextContents(), ['A', 'B', 'C', 'D', 'E', 'F']);
      await page.locator('[data-choice="5"]').click();
      await page.locator('#next-button').click();
      await page.locator('[data-choice="1"]').click();
      await page.locator('#next-button').click();
      assert.match(await page.locator('#first-try-summary').innerText(), /2 of 2/);
      const laterNotes = await saveNotes('reused-ids-six-choices');
      assert.ok(laterNotes.includes(six.title));
      assert.ok(laterNotes.includes(six.attribution));
      assert.ok(laterNotes.includes(six.license));
      assert.ok(laterNotes.includes('Your first answer: Five ✓'));
      assert.ok(laterNotes.includes('Your first answer: Later correct'));
      assert.ok(!laterNotes.includes('A guess'));
      assert.ok(!laterNotes.includes('Independent course B'));
      assert.match(laterNotes, /No missed connections in the first session/);
      receipt.checks.push(`${surface}: reused question IDs with six new canonical choices reset answer presentation and exported content`);
      await page.locator('#use-bundled-deck').click();
      await page.locator('#start-deck').click();
      assert.equal(await page.locator('#step-count').innerText(),'0 / 6');
      assert.match(await page.locator('#lesson-subject').innerText(),/BIOLOGY/);
      receipt.checks.push(`${surface}: same-name import needs explicit start; reset retains selected content; bundled return resets coherently`);
      await checkWidth('restored bundled');
      await page.waitForFunction(() => document.querySelector('#progress-fill').getBoundingClientRect().width < 1);
      await page.screenshot({path:path.join(output, surface+'-restored.png')});
      assert.deepEqual(errors,[]);
      assert.deepEqual(external,[]);
      await context.close();
    }
  } catch (error) {receipt.errors.push(error.stack || String(error));process.exitCode=1;}
  finally {
    if (browser) await browser.close();
    await new Promise(resolve => server.close(resolve));
    receipt.source_after=hashes();receipt.source_unchanged=JSON.stringify(receipt.source_before)===JSON.stringify(receipt.source_after);
    if (!receipt.source_unchanged) process.exitCode=1;
    fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
    console.log(JSON.stringify({checks:receipt.checks,errors:receipt.errors,source_unchanged:receipt.source_unchanged}));
  }
})().catch(error => {console.error(error);process.exitCode=1;server.close();});
