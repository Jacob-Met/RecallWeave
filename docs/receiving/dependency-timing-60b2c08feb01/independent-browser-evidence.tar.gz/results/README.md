# Independent browser receiving — dependency timing

This packet qualifies the frozen RecallWeave timing page and source blob set recorded in `independent-review.json`. It is evidence-only. No production file, Git index, canonical branch, provider account, or remote application was changed by this receiver.

## What actually ran

The final receiver launched Chromium 153.0.8010.0 through the existing Playwright installation and served the exact 51,991-byte native standalone HTML over an isolated loopback HTTP server. It passed nine browser groups and verified five real browser downloads, including complete expected JSON objects and their exact UTF-8 serialization. Only two same-origin page GETs occurred; no off-origin attempt, browser error or console error was observed. The final 375px sequence used native Tab, Control+A, keyboard text entry and Enter for calculation/download. Its full PNG was subsequently displayed and inspected; see `results/visual-inspection.json`.

The original contract, hand-derived fixtures and expected trace bytes were frozen before the new timing UI/model was inspected. The helper imports neither production timing code nor the author harness. Source rendering was consulted only after concrete receiver assertion failures to distinguish valid presentation from a test mistake.

## Preserved receiver mistakes

All three actual exit-1 receipts, logs, execution configurations and exact executed drivers are retained. They are not product failures:

1. The original row-header comparison included the separate zero-duration milestone marker. The receiver was corrected to bind the literal `.job-name` span and assert the marker separately.
2. A subsequent step began before the previous download's existing 500ms cleanup/duplicate guard re-enabled the button. The receiver now waits, for at most 3 seconds, for native readiness before starting the distinct edit-invalidation probe.
3. A redundant literal-name count searched the whole timing table, which legitimately repeats names in dependent prerequisite cells. It now counts the row name span and separately requires zero parsed `b` elements.

No timing, trace-byte, cycle, duration-refusal or changed-input expectation was weakened. The final successful raw receipt remains unchanged. Its `configuration.contractHashes.driver` annotation is stale from attempt 3; `results/execution-annotation.json` explains this precisely. Actual final driver bytes were hashed before invocation and are preserved as SHA256 `6fa3faae54d6e81b096eb94bd3bc8b2590131207ef9f0f518d533b02d768f378`.

## Archive verification and replay

`archive-manifest.json` records each member's byte length and SHA256. Verify those bytes before interpreting the evidence. The packet contains the complete seven-file receiving export, every executed receiver version, frozen contracts, three raw failure records, all captured traces and the inspected PNG. Source SHA1 Git blob identities are recorded independently from SHA256.

The raw execution config contains historical private absolute paths. For an optional local replay, copy it outside the evidence packet, set only `sourceRoot`, `outputRoot`, `playwrightModule`, `chromium` to valid local paths, and correct the documented driver annotation to the actual final driver hash. Keep `sourceFiles`, `sourcePin`, `entry`, all contracts and all expectations exact. Then run `node harness/receive-browser.mjs <copied-config.json>`. Use an output directory outside the source export and a writable temporary profile directory. This receiving already executed successfully; no additional replay is needed for the qualified source.

The first two receiving exports actually executed the repository's native builder and reproduced the author's exact generated SHA256 `84929ded09872b14a69da310c50bcfe899ca2fae6d601d98e1063b317b9a0393`. The last two attempts copied that shared frozen HTML and rechecked the exact bytes, avoiding redundant author/build gates.

## Qualification boundary

This packet establishes the actual UI/trace/state behavior for the exact recorded source set. The separate mathematical receiver and maintained native tests establish broader model coverage. This packet does not assert a later branch/head or unseen browser platform is qualified. The installed receiving font renders the Chinese test glyph as a fallback box; DOM identity, accessible labels and UTF-8 trace bytes remain exact. The table's own horizontal scroll region is intentional and stays within the 375px document.
