#!/usr/bin/env python3
"""Independent counting oracle. No product implementation or answer key is imported."""
import datetime as dt
import hashlib
import itertools
import json
import math
import platform
import sys
import time

MODELS = ("ordered-reuse", "ordered-distinct", "unordered-distinct", "unordered-reuse")
PAGE_SIZE = 24

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def analytical_count(n, k, model):
    if k == 0:
        return 1
    if n == 0:
        return 0
    if model == "ordered-reuse":
        return n ** k
    if model == "ordered-distinct":
        return 0 if k > n else math.perm(n, k)
    if model == "unordered-distinct":
        return 0 if k > n else math.comb(n, k)
    return math.comb(n + k - 1, k)

def enumerate_labels(alphabet, k, model):
    if model == "ordered-reuse":
        return itertools.product(alphabet, repeat=k)
    if model == "ordered-distinct":
        return itertools.permutations(alphabet, k)
    if model == "unordered-distinct":
        return itertools.combinations(alphabet, k)
    return itertools.combinations_with_replacement(alphabet, k)

def multiplicity(labels, alphabet, k, model):
    counts = [labels.count(label) for label in alphabet]
    value = 1 if model.startswith("ordered-") else math.factorial(k) // math.prod(math.factorial(c) for c in counts)
    return counts, value

def row_record(labels, ordinal, alphabet, k, model):
    counts, ways = multiplicity(labels, alphabet, k, model)
    return {
        "ordinal": str(ordinal),
        "labels": list(labels),
        "typeCounts": counts,
        "orderedRepresentations": str(ways),
    }

def invalid_arguments(bound):
    return [
        {"kind": "bigint", "value": "-1"},
        {"kind": "bigint", "value": str(bound)},
        {"kind": "bigint", "value": str(bound + 1)},
        {"kind": "bigint", "value": "100000000000000000000000000000000000000000000000000000000000000000000000000000000"},
        {"kind": "number", "value": 0},
        {"kind": "string", "value": "0"},
        {"kind": "boolean", "value": False},
        {"kind": "null", "value": None},
    ]

def case(n, k, model):
    alphabet = tuple("ABCDEFGH"[:n])
    expected_count = analytical_count(n, k, model)
    page_count = max(1, (expected_count + PAGE_SIZE - 1) // PAGE_SIZE)
    page_indices = sorted({0, page_count // 2, page_count - 1})
    selected_indices = sorted({
        index for index in (0, 1, 23, 24, 25, expected_count // 2, expected_count - 2, expected_count - 1)
        if 0 <= index < expected_count
    })
    required = set(selected_indices)
    for page in page_indices:
        required.update(range(page * PAGE_SIZE, min(expected_count, (page + 1) * PAGE_SIZE)))
    captured = {}
    digest = hashlib.sha256()
    observed = 0
    previous = None
    weighted_count = 0
    for index, labels in enumerate(enumerate_labels(alphabet, k, model)):
        require(len(labels) == k, (n, k, model, "row length"))
        require(all(label in alphabet for label in labels), (n, k, model, "alphabet"))
        require(previous is None or previous < labels, (n, k, model, "lexicographic order", index))
        if model.startswith("unordered-"):
            require(tuple(sorted(labels)) == labels, (n, k, model, "canonical unordered row"))
        if model.endswith("-distinct"):
            require(len(set(labels)) == len(labels), (n, k, model, "distinct types"))
        digest.update(("".join(labels) + "\n").encode("ascii"))
        if model.startswith("unordered-"):
            counts, ways = multiplicity(labels, alphabet, k, model)
            require(sum(counts) == k, (n, k, model, "type-count sum"))
            weighted_count += ways
        else:
            weighted_count += 1
        if index in required:
            captured[index] = row_record(labels, index + 1, alphabet, k, model)
        previous = labels
        observed += 1
    require(observed == expected_count, (n, k, model, "enumeration vs closed-form", observed, expected_count))
    require(set(captured) == required, (n, k, model, "selected-row completeness"))
    ordered_model = "ordered-distinct" if model.endswith("-distinct") else "ordered-reuse"
    weighted_expected = analytical_count(n, k, ordered_model) if model.startswith("unordered-") else expected_count
    require(weighted_count == weighted_expected, (n, k, model, "multiplicity cross-check", weighted_count, weighted_expected))
    pages = []
    for page in page_indices:
        start = page * PAGE_SIZE
        stop = min(expected_count, start + PAGE_SIZE)
        rows = [captured[index] for index in range(start, stop)]
        pages.append({
            "argument": {"kind": "bigint", "value": str(page)},
            "expected": {
                "total": str(expected_count),
                "page": str(page),
                "pageCount": str(page_count),
                "firstOrdinal": rows[0]["ordinal"] if rows else None,
                "lastOrdinal": rows[-1]["ordinal"] if rows else None,
                "rows": rows,
            },
        })
    return {
        "input": {"n": n, "k": k, "model": model},
        "count": str(expected_count),
        "enumerationCount": str(observed),
        "enumerationSha256": digest.hexdigest(),
        "enumerationEncoding": "Concatenate each fixed-length A-H row then ASCII LF; an empty row is LF.",
        "weightedCount": str(weighted_count),
        "weightedExpected": str(weighted_expected),
        "pages": pages,
        "outcomes": [
            {"argument": {"kind": "bigint", "value": str(index)}, "expectedRow": captured[index]}
            for index in selected_indices
        ],
        "invalidOutcomeArguments": invalid_arguments(expected_count),
        "invalidPageArguments": invalid_arguments(page_count),
        "expectedIndexError": "RangeError",
        "defaultPage": "0",
    }

def build(contract_bytes):
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    clock = time.monotonic()
    contract = json.loads(contract_bytes)
    require(contract["models"] == list(MODELS), "contract model names")
    require(contract["pageSize"] == PAGE_SIZE, "contract page size")
    cases = [case(n, k, model) for n in range(9) for k in range(7) for model in MODELS]
    require(len(cases) == 252, "252 cases")
    require(len({(x["input"]["n"], x["input"]["k"], x["input"]["model"]) for x in cases}) == 252, "unique inputs")
    summary = {
        "status": "passed",
        "cases": len(cases),
        "enumeratedRows": sum(int(x["enumerationCount"]) for x in cases),
        "analyticalCountsMatched": len(cases),
        "multiplicityCrossChecksMatched": len(cases),
        "selectedPages": sum(len(x["pages"]) for x in cases),
        "selectedPageRows": sum(len(p["expected"]["rows"]) for x in cases for p in x["pages"]),
        "selectedOutcomeChecks": sum(len(x["outcomes"]) for x in cases),
        "expectedRangeRefusals": sum(len(x["invalidOutcomeArguments"]) + len(x["invalidPageArguments"]) for x in cases),
        "emptySelectionCases": sum(x["count"] == "0" for x in cases),
        "zeroLengthCases": sum(x["input"]["k"] == 0 for x in cases),
        "maximumCount": str(max(int(x["count"]) for x in cases)),
        "fullOutcomeRowsStored": False,
        "startedUTC": started,
        "finishedUTC": dt.datetime.now(dt.timezone.utc).isoformat(),
        "elapsedSeconds": time.monotonic() - clock,
    }
    document = {
        "format": "memory-counting-blind-oracle-v1",
        "contractSha256": hashlib.sha256(contract_bytes).hexdigest(),
        "pageSize": PAGE_SIZE,
        "caseOrder": "n ascending, k ascending, models in declared order",
        "summary": summary,
        "cases": cases,
    }
    receipt = {
        **summary,
        "python": sys.version,
        "executable": sys.executable,
        "platform": platform.platform(),
        "independentMechanism": "Python itertools enumeration cross-checked with math.comb, math.perm and integer powers; weighted unordered outcomes reconstruct ordered counts.",
        "productImplementationImported": False,
        "productKeyRead": False,
        "declaredDataInputs": ["CONTRACT.json"],
    }
    print(json.dumps(receipt, sort_keys=True))
    return document, receipt
