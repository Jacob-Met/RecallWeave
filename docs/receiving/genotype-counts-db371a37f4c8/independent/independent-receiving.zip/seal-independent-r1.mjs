import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import zlib from 'node:zlib';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';
const root=path.dirname(fileURLToPath(import.meta.url)),dest=path.join(root,'independent-sealed'),read=p=>fs.readFileSync(p),parse=n=>JSON.parse(read(path.join(root,n)).toString('utf8').replace(/^\uFEFF/,''));
const pin=p=>{const b=read(p),s=fs.statSync(p,{bigint:true});return {bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),git:crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex'),mtime_ns:s.mtimeNs.toString()};};
assert.equal(parse('CANDIDATE-CLOSE-r1-EXIT.json').exitCode,0);assert.equal(parse('CANDIDATE-CLOSE-r1-OUTER.json').exitCode,0);assert.equal(parse('INDEPENDENT-REPORT.json').independence.authoredTestsOrResultsRead,false);
fs.mkdirSync(dest,{recursive:false});
const excludedDirectories=new Set(['tmp','independent-sealed']);
function walk(dir,prefix=''){const found=[];for(const e of fs.readdirSync(dir,{withFileTypes:true})){const rel=prefix?prefix+'/'+e.name:e.name;if(!prefix&&(excludedDirectories.has(e.name)||e.name.startsWith('INDEPENDENT-SEAL-r1')))continue;if(e.isDirectory())found.push(...walk(path.join(dir,e.name),rel));else{assert.ok(e.isFile(),rel);found.push({path:rel,...pin(path.join(dir,e.name))});}}return found;}
const files=walk(root).sort((a,b)=>Buffer.compare(Buffer.from(a.path),Buffer.from(b.path)));
assert.ok(files.length>100);assert.ok(files.every(x=>!/(?:^|\/)tests?\//i.test(x.path)&&!x.path.includes('authored')));assert.equal(new Set(files.map(x=>x.path.toLowerCase())).size,files.length);
const manifest={schema:'recall261-independent-archive-manifest-v1',at:new Date().toISOString(),pid:process.pid,parent:process.ppid,originalFreeze:pin(path.join(root,'ORIGINAL-FREEZE.json')),report:pin(path.join(root,'INDEPENDENT-REPORT.json')),files,payloadBytes:files.reduce((s,x)=>s+x.bytes,0),excluded:['tmp/','independent-sealed/','active INDEPENDENT-SEAL-r1 process outputs; complete records are bound in final audit'],authoredTestsOrResultsRead:false};
const manifestBytes=Buffer.from(JSON.stringify(manifest,null,2)+'\n');fs.writeFileSync(path.join(dest,'SEALED-MANIFEST.json'),manifestBytes,{flag:'wx'});
const crcTable=Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
const crc=b=>{let c=0xffffffff;for(const v of b)c=crcTable[(c^v)&255]^(c>>>8);return (c^0xffffffff)>>>0;};
const members=[...files.map(f=>({name:f.path,data:read(path.join(root,f.path))})),{name:'SEALED-MANIFEST.json',data:manifestBytes}],local=[],central=[];let offset=0;
for(const m of members){
 const name=Buffer.from(m.name,'utf8'),packed=zlib.deflateRawSync(m.data,{level:9}),checksum=crc(m.data),lh=Buffer.alloc(30),ch=Buffer.alloc(46);
 lh.writeUInt32LE(0x04034b50);lh.writeUInt16LE(20,4);lh.writeUInt16LE(0x800,6);lh.writeUInt16LE(8,8);lh.writeUInt16LE(33,12);lh.writeUInt32LE(checksum,14);lh.writeUInt32LE(packed.length,18);lh.writeUInt32LE(m.data.length,22);lh.writeUInt16LE(name.length,26);
 ch.writeUInt32LE(0x02014b50);ch.writeUInt16LE(0x314,4);ch.writeUInt16LE(20,6);ch.writeUInt16LE(0x800,8);ch.writeUInt16LE(8,10);ch.writeUInt16LE(33,14);ch.writeUInt32LE(checksum,16);ch.writeUInt32LE(packed.length,20);ch.writeUInt32LE(m.data.length,24);ch.writeUInt16LE(name.length,28);ch.writeUInt32LE((0o100644<<16)>>>0,38);ch.writeUInt32LE(offset,42);
 local.push(lh,name,packed);central.push(ch,name);offset+=lh.length+name.length+packed.length;
}
const cd=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(members.length,8);end.writeUInt16LE(members.length,10);end.writeUInt32LE(cd.length,12);end.writeUInt32LE(offset,16);
fs.writeFileSync(path.join(dest,'independent-receiving.zip'),Buffer.concat([...local,cd,end]),{flag:'wx'});
const python='C:/Users/Veria/AppData/Local/Programs/Python/Python311/python.exe',verification=spawnSync(python,[path.join(root,'verify-independent-zip.py'),root],{cwd:root,encoding:'utf8',timeout:60000,windowsHide:true});
fs.writeFileSync(path.join(dest,'archive-verification.stdout'),verification.stdout??'',{flag:'wx'});fs.writeFileSync(path.join(dest,'archive-verification.stderr'),verification.stderr??'',{flag:'wx'});
assert.equal(verification.status,0,verification.stderr);const checked=JSON.parse(verification.stdout);assert.equal(checked.status,'passed');
for(const f of files)assert.deepEqual(pin(path.join(root,f.path)),{bytes:f.bytes,sha256:f.sha256,git:f.git,mtime_ns:f.mtime_ns},f.path);
const record={schema:'recall261-independent-native-seal-v1',at:new Date().toISOString(),pid:process.pid,parent:process.ppid,status:'sealed before authored-result disclosure',report:pin(path.join(root,'INDEPENDENT-REPORT.json')),manifest:pin(path.join(dest,'SEALED-MANIFEST.json')),archive:pin(path.join(dest,'independent-receiving.zip')),verification:{...checked,childExit:verification.status,childPID:verification.pid,pythonExecutable:{path:python,...pin(python)}},filesStillExact:files.length,sourceProductReexecuted:false,authoredTestsOrResultsRead:false};
fs.writeFileSync(path.join(dest,'INDEPENDENT-SEAL.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
const objects=[['independent-receiving.zip',path.join(dest,'independent-receiving.zip'),'base64'],['SEALED-MANIFEST.json',path.join(dest,'SEALED-MANIFEST.json'),'utf-8'],['INDEPENDENT.md',path.join(root,'INDEPENDENT.md'),'utf-8'],['INDEPENDENT-SEAL.json',path.join(dest,'INDEPENDENT-SEAL.json'),'utf-8']].map(([name,p,encoding])=>({name,path:p,encoding,...pin(p),content:read(p).toString(encoding==='base64'?'base64':'utf8')}));
fs.writeFileSync(path.join(dest,'UPLOAD.json'),JSON.stringify({schema:'recall261-native-sealed-upload-v1',objects},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:record.status,files:files.length,members:members.length,objects:objects.map(({content,...x})=>x),verification:record.verification}));
