import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const root='/Users/me/Developer/chatgpt-root-integration-713adaab';
const owner='/Users/me/Developer/recallweave-quantum-states-20261009-713adaab';
const source=path.join(owner,'candidate');
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const oraclePath=path.join(root,'learning-independent-full-traces-r1.json');
const oracleBytes=fs.readFileSync(oraclePath);
assert.equal(digest(oracleBytes),'e7a6c2e56592fb12a9277c7ae6dcfe654c6f463a1c85dd98bb562fa69f91e81d');
const oracle=JSON.parse(oracleBytes);
const freezePath=path.join(owner,'candidate-source-r1.json');
const freezeBytes=fs.readFileSync(freezePath);
assert.equal(digest(freezeBytes),'cbda64aecc883ed5aacfde1ee9b2eeb7588d80733d54bf2005762f9d942f8b10');
const freeze=JSON.parse(freezeBytes);
const snapshot=()=>Object.fromEntries(freeze.files.map(x=>{
 const p=path.join(source,x.path),b=fs.readFileSync(p),s=fs.statSync(p,{bigint:true});
 assert.equal(digest(b),x.sha256);assert.equal(b.length,x.bytes);
 return [x.path,{bytes:b.length,sha256:digest(b),mtime_ns:String(s.mtimeNs)}];
}));
const before=snapshot();
assert.equal(before['courses/quantum-states-core.mjs'].sha256,'14e37e8f6a9ecb9fc912a68c5cd795a11377e1b53ef4d071da10e44e47c76ff9');
const space=fs.statfsSync(root,{bigint:true});
assert(space.bavail*space.bsize>64n*1024n*1024n);
const results=[],refusals=[];
const deepFreeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(deepFreeze);Object.freeze(x);}return x;};
const close=(a,b,label)=>assert(typeof a==='number'&&Number.isFinite(a)&&Math.abs(a-b)<=1e-12,label+': '+a+' vs '+b);
let failure=null,after=null,apiCalls=0;
try {
 const {simulateCircuit}=await import(pathToFileURL(path.join(source,'courses/quantum-states-core.mjs')));
 assert.equal(typeof simulateCircuit,'function');
 for(const c of oracle.quantum){
  const input=structuredClone(c.input),raw=JSON.stringify(input);deepFreeze(input);
  apiCalls++;
  const actual=simulateCircuit(input);
  assert.equal(JSON.stringify(input),raw);
  assert.equal(typeof actual.schema,'string');assert(actual.schema.length>0);
  assert.deepEqual(actual.basis_order,['00','01','10','11']);
  assert.equal(actual.initial,input.initial);assert.deepEqual(actual.gates,input.gates);
  assert.equal(actual.steps.length,c.expected_steps.length,c.id+' complete N+1 trace');
  for(let n=0;n<actual.steps.length;n++){
   const a=actual.steps[n],e=c.expected_steps[n];
   assert.equal(a.index,e.index);assert.deepEqual(a.gate,e.gate);
   assert.equal(a.amplitudes.length,4);assert.equal(a.probabilities.length,4);
   for(let k=0;k<4;k++){
    assert.equal(a.amplitudes[k].length,2);
    for(let j=0;j<2;j++)close(a.amplitudes[k][j],e.amplitudes[k][j],c.id+' step'+n+' amplitude'+k+'/'+j);
    close(a.probabilities[k],e.probabilities[k],c.id+' step'+n+' probability'+k);
   }
   for(const q of ['q0','q1']){
    assert.equal(a.marginals[q].length,2);
    for(let k=0;k<2;k++)close(a.marginals[q][k],e.marginals[q][k],c.id+' marginal'+q+'/'+k);
   }
   close(a.norm_squared,e.norm_squared,c.id+' norm');
  }
  results.push({id:c.id,passed:true,input:c.input,actual});
 }
 const invalid=[
  {id:'null_root',input:null},
  {id:'extra_root_key',input:{initial:'00',gates:[],extra:true}},
  {id:'nonbasis',input:{initial:'02',gates:[]}},
  {id:'boolean_target',input:{initial:'00',gates:[{gate:'X',target:true}]}},
  {id:'self_CNOT',input:{initial:'00',gates:[{gate:'CNOT',control:0,target:0}]}},
  {id:'single_gate_extra_control',input:{initial:'00',gates:[{gate:'H',target:0,control:1}]}},
  {id:'over_24_gates',input:{initial:'00',gates:Array.from({length:25},()=>({gate:'H',target:0}))}}
 ];
 for(const c of invalid){
  const raw=JSON.stringify(c.input);deepFreeze(c.input);apiCalls++;
  assert.throws(()=>simulateCircuit(c.input),c.id);
  assert.equal(JSON.stringify(c.input),raw);
  refusals.push({id:c.id,passed:true});
 }
 after=snapshot();assert.deepEqual(after,before);
 assert.equal(digest(fs.readFileSync(oraclePath)),digest(oracleBytes));
 assert.equal(digest(fs.readFileSync(freezePath)),digest(freezeBytes));
}catch(e){failure={name:e.name,message:e.message,stack:e.stack};try{after=snapshot();}catch(x){after={error:x.message};}}
const receipt={
 schema:'hamon.quantum.root.independent-receiving.v1',at:new Date().toISOString(),actor:'chatgpt:/root/713adaab',
 native:{host:os.hostname(),node:process.version,executable:process.execPath,uid:process.getuid()},
 oracle:{sha256:digest(oracleBytes),path:oraclePath,source_blind_freeze:'2026-10-09T03:31:41.553842+00:00'},
 source_freeze_sha256:digest(freezeBytes),driver_sha256:digest(fs.readFileSync(new URL(import.meta.url))),
 original_expected_cases:26,original_expected_steps:100,valid_cases_passed:results.length,
 valid_steps_compared:results.reduce((n,x)=>n+x.actual.steps.length,0),refusal_cases_passed:refusals.length,
 api_calls:apiCalls,results,refusals,source_before:before,source_after:after,failure,
 limits:'One native Node process; dense-matrix model receiving and representative admission only. No CLI/browser/download/learner/installed or efficacy claim.'
};
const out=path.join(root,'quantum-root-independent-receiving-r1.json');
const bytes=Buffer.from(JSON.stringify(receipt,null,2)+'\n');
const fd=fs.openSync(out,'wx');try{fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
console.log(JSON.stringify({path:out,bytes:bytes.length,sha256:digest(bytes),valid_cases_passed:results.length,valid_steps_compared:receipt.valid_steps_compared,refusals_passed:refusals.length,api_calls:apiCalls,source_unchanged:!failure,failure}));
if(failure)process.exitCode=2;
