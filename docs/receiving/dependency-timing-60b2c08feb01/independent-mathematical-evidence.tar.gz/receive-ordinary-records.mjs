import assert from 'node:assert/strict';
import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname, join, resolve} from 'node:path';
import {pathToFileURL, fileURLToPath} from 'node:url';
import {checkOrdinaryDurationRecords} from './ordinary-records-clarification.mjs';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const pin = file => {const bytes = readFileSync(file); return {path: file, bytes: bytes.length, sha256: sha(bytes)};};
const model = resolve(process.argv[2]), output = resolve(process.argv[3]);
const receipt = {schema: 'recallweave.dependency-timing.ordinary-data-clarification.v1',
  declared: '2026-10-08; after original oracle freeze, without altering it',
  passed: false, source: pin(model), graph: pin(join(dirname(model), 'dependency-plan.mjs')),
  driver: pin(fileURLToPath(import.meta.url)),
  helper: pin(join(dirname(fileURLToPath(import.meta.url)), 'ordinary-records-clarification.mjs')),
  errors: []};
try {
  assert.equal(receipt.source.sha256, '68a29880bea40c1364245e74f0fcbd285770891554ccb6a6ea7a7b1efa6efc6f');
  assert.equal(receipt.graph.sha256, 'fea26b701e2e394c86309d4e2d1927c7743205b17210d1b50c8676faaeb27b10');
  const {analyzeTiming} = await import(pathToFileURL(model).href);
  receipt.result = checkOrdinaryDurationRecords(analyzeTiming);
  assert.equal(pin(model).sha256, receipt.source.sha256);
  assert.equal(pin(receipt.graph.path).sha256, receipt.graph.sha256);
  receipt.source_preserved = true;
  receipt.passed = true;
} catch(error) {
  receipt.errors.push({name: error.name, message: error.message, stack: error.stack});
  process.exitCode = 1;
}
writeFileSync(output, JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify({passed: receipt.passed, refusal_cases: receipt.result?.refusal_cases,
  accepted_controls: receipt.result?.accepted_controls, errors: receipt.errors}));
