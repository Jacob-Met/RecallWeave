import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';

const source = path.resolve(process.argv[2]);
const out = path.resolve(process.argv[3]);
fs.mkdirSync(out, { recursive: true });
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const gitBlob = bytes => crypto.createHash('sha1').update(Buffer.from('blob ' + bytes.length + '\0')).update(bytes).digest('hex');
const read = relative => fs.readFileSync(path.join(source, relative), 'utf8');
const pin = relative => {
  const bytes = fs.readFileSync(path.join(source, relative));
  return { bytes: bytes.length, sha256: hash(bytes), gitBlob: gitBlob(bytes) };
};
const inputs = ['src/dependency-plan.mjs', 'src/dependency-timing.mjs', 'src/dependency-timing-ui.mjs',
  'courses/dependency-timing.template.html', 'courses/dependency-timing.html',
  'tools/build-dependency-timing.mjs', 'courses/dependency-graphs.md'];
const before = Object.fromEntries(inputs.map(relative => [relative, pin(relative)]));
const receipt = { node: process.version, source, inputs: before, checks: [] };
try {
  const { buildDependencyTiming, renderDependencyTiming } = await import(pathToFileURL(path.join(source, 'tools/build-dependency-timing.mjs')).href);
  const expected = buildDependencyTiming();
  assert.equal(read('courses/dependency-timing.html'), expected);
  const explicit = renderDependencyTiming({
    template: read('courses/dependency-timing.template.html'),
    graphSource: read('src/dependency-plan.mjs'),
    timingSource: read('src/dependency-timing.mjs'),
    uiSource: read('src/dependency-timing-ui.mjs'),
  });
  assert.equal(explicit, expected);
  const scripts = [...expected.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/giu)];
  assert.equal(scripts.length, 1);
  new vm.Script(scripts[0][1], { filename: 'actual-generated-timing-inline.js' });
  assert.equal(/<script\b[^>]*\bsrc=/iu.test(expected), false);
  assert.equal(expected.includes('@@TIMING_SCRIPT@@'), false);
  receipt.checks.push({ name: 'Exact generated HTML equals both native build paths and contains one parseable inline script without external script delivery', passed: true });

  const direct = spawnSync(process.execPath, [path.join(source, 'tools/build-dependency-timing.mjs'), '--check'], { cwd: source, encoding: 'utf8' });
  assert.equal(direct.status, 0, direct.stderr);
  assert.equal(direct.stdout, 'Dependency timing page matches its exact native graph, timing and UI sources.\n');
  const alias = path.join(out, 'timing-builder-alias.mjs');
  fs.symlinkSync(path.join(source, 'tools/build-dependency-timing.mjs'), alias);
  const linked = spawnSync(process.execPath, [alias, '--check'], { cwd: out, encoding: 'utf8' });
  fs.unlinkSync(alias);
  assert.equal(linked.status, 0, linked.stderr);
  assert.equal(linked.stdout, direct.stdout);
  receipt.cli = { direct: { status: direct.status, stdout: direct.stdout, stderr: direct.stderr },
    symlink: { status: linked.status, stdout: linked.stdout, stderr: linked.stderr } };
  receipt.checks.push({ name: 'Direct and symlink CLI --check both actually run and confirm generated-source equality', passed: true });

  assert.equal(before['src/dependency-plan.mjs'].gitBlob, 'ad667b4a93b93a755b5f36460c1a5653884a6f7b');
  const addition = 'For an optional extension beyond these twelve questions, open the\n' +
    '[offline critical-path timing companion](dependency-timing.html). Add bounded\n' +
    'integer durations to see earliest/latest times, total slack and all critical\n' +
    'branches under unlimited parallelism, then download the exact timing trace.\n' +
    'Durations use abstract time units; this does not estimate calendars or staffing.\n\n';
  const guide = read('courses/dependency-graphs.md');
  assert.equal(guide.split(addition).length, 2);
  assert.equal(gitBlob(Buffer.from(guide.replace(addition, ''))), 'db049913ece54e1d675ae53eb395120d876ccc36');
  receipt.checks.push({ name: 'Original graph model is exact and removing the one guide pointer restores the entire original guide byte-for-byte', passed: true });

  const after = Object.fromEntries(inputs.map(relative => [relative, pin(relative)]));
  assert.deepEqual(after, before);
  receipt.sourceUnchanged = true;
  receipt.passed = true;
} catch (error) {
  receipt.passed = false;
  receipt.error = error.stack;
  process.exitCode = 1;
} finally {
  fs.writeFileSync(path.join(out, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ passed: receipt.passed, checks: receipt.checks.length, output: out, sourceUnchanged: receipt.sourceUnchanged }));
}
