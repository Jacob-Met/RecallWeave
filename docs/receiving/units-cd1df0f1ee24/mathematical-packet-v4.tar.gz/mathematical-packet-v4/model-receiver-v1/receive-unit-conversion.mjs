import assert from 'node:assert/strict';
import {readFileSync, writeFileSync, mkdirSync} from 'node:fs';
import {resolve, join} from 'node:path';
import {pathToFileURL, fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

const here = fileURLToPath(new URL('.', import.meta.url));
const source = resolve(process.env.UNITS_MODEL_PATH);
const output = resolve(process.env.UNITS_RECEIVING_OUTPUT);
const sourceExpected = process.env.UNITS_MODEL_SHA256;
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const oraclePath = resolve(here, '../receiving-contract-v1/units-oracles.json');
const addendumPath = join(here, 'course-prefix-addendum.json');
const sourceBytes = readFileSync(source);
const oracleBytes = readFileSync(oraclePath);
const addendumBytes = readFileSync(addendumPath);
assert.equal(sha(sourceBytes), sourceExpected, 'exact candidate input gate');
assert.equal(sha(oracleBytes), 'cf7b8c172ad42f3fb1e02972d7fd3552c9ad35e6fb727d736d7ec0d8d4694a04', 'original independently frozen oracles');
assert.equal(sha(addendumBytes), '5162d6309ab738cd8a8d32dd116411f2ea48efaecd4645de18af4d4d19e83084', 'blind-course case addendum');
const oracle = JSON.parse(oracleBytes);
const addendum = JSON.parse(addendumBytes);
const {parseUnitExpression, convertUnits} = await import(pathToFileURL(source).href);
assert.equal(typeof parseUnitExpression, 'function');
assert.equal(typeof convertUnits, 'function');
mkdirSync(output, {recursive: false});
const receipt = {
  schema: 'recallweave-independent-model-receiving/1',
  runAt: new Date().toISOString(), node: process.version,
  source: {path: source, bytes: sourceBytes.length, sha256: sha(sourceBytes)},
  inputs: {runnerSHA256: sha(readFileSync(fileURLToPath(import.meta.url))), oracleSHA256: sha(oracleBytes), addendumSHA256: sha(addendumBytes)},
  limits: 'Expected values come from the frozen receiving data. Authored tests are neither read nor imported. This is model acceptance, not browser or course acceptance.',
  checks: []
};
const results = new Map();
const rational = (actual, expected, label) => {
  assert.ok(actual && typeof actual === 'object', label);
  assert.equal(actual.numerator, expected.numerator, label + ' numerator');
  assert.equal(actual.denominator, expected.denominator, label + ' denominator');
  assert.ok(BigInt(actual.denominator) > 0n, label + ' denominator positive');
};
function check(id, kind, work) {
  try { const actual = work(); receipt.checks.push({id, kind, pass: true, actual}); }
  catch (error) { receipt.checks.push({id, kind, pass: false, error: {name: error.name, message: error.message, stack: error.stack}}); }
}
for (const item of [...oracle.conversions, ...addendum.conversions]) {
  check(item.id, 'exact-conversion', () => {
    const from = parseUnitExpression(item.from);
    const to = parseUnitExpression(item.to);
    assert.deepEqual(from.dimensions, item.dimension, 'source dimensions');
    assert.deepEqual(to.dimensions, item.dimension, 'target dimensions');
    for (const power of [...from.dimensions, ...to.dimensions]) assert.ok(Number.isInteger(power) && !Object.is(power, -0), 'canonical integer dimension power');
    const result = convertUnits(item.value, item.from, item.to);
    rational(result.factor, item.scaleRatio, 'conversion scale');
    rational(result.result, item.exactTargetValue, 'converted value');
    const serial = JSON.stringify(result);
    assert.ok(serial && JSON.parse(serial), 'JSON-safe result');
    results.set(item.id, result);
    return {from, to, result};
  });
}
for (const item of oracle.incompatible) {
  check(item.id, 'incompatible-refusal', () => {
    assert.deepEqual(parseUnitExpression(item.from).dimensions, item.sourceDimension);
    assert.deepEqual(parseUnitExpression(item.to).dimensions, item.targetDimension);
    let error;
    try { convertUnits(item.value, item.from, item.to); } catch (caught) { error = caught; }
    assert.ok(error instanceof Error, 'incompatible pair must be refused');
    assert.match(error.message, /dimension|incompatib/i, 'reason identifies dimensional mismatch');
    return {message: error.message};
  });
}
for (const item of [...oracle.invalidInputs, ...addendum.invalidInputs]) {
  check(item.id, 'invalid-input-refusal', () => {
    let error;
    try { convertUnits(item.value, item.from, item.to); } catch (caught) { error = caught; }
    assert.ok(error instanceof Error && error.message.length, 'invalid input must be refused with an explanation');
    return {message: error.message};
  });
}
for (const [id, expected] of [['speed-repeating', 5 / 18], ['rate-repeating', 1 / 60]]) {
  check(id + '-display', 'rounded-display', () => {
    const result = results.get(id);
    assert.ok(result, 'the exact conversion must first pass');
    assert.equal(result.display.rounded, true, 'nonterminating decimal is marked rounded');
    assert.equal(result.display.significant_digits, 12);
    const value = Number(result.display.text);
    assert.ok(Number.isFinite(value) && value !== 0, 'visible decimal is finite and nonzero');
    assert.ok(Math.abs((value - expected) / expected) <= 5e-12, '12-digit display is consistent with the exact value');
    return result.display;
  });
}
check('small-nonzero-display', 'display-value', () => {
  const result = results.get('cube-small');
  assert.ok(result);
  assert.equal(Number(result.display.text), 0.000002);
  assert.equal(result.display.rounded, false);
  return result.display;
});
check('zero-display', 'display-value', () => {
  const result = results.get('zero-value');
  assert.ok(result);
  assert.equal(Number(result.display.text), 0);
  assert.equal(result.display.rounded, false);
  return result.display;
});
check('energy-prefix-billionfold', 'case-contrast', () => {
  const large = results.get('mega-energy-case').result;
  const small = results.get('milli-energy-case').result;
  assert.equal(BigInt(large.numerator) * BigInt(small.denominator), 1000000000n * BigInt(large.denominator) * BigInt(small.numerator));
  return addendum.caseContrast;
});
assert.equal(sha(readFileSync(source)), sourceExpected, 'candidate remained unchanged');
assert.equal(sha(readFileSync(oraclePath)), receipt.inputs.oracleSHA256, 'oracles remained unchanged');
assert.equal(sha(readFileSync(addendumPath)), receipt.inputs.addendumSHA256, 'addendum remained unchanged');
receipt.summary = {checks: receipt.checks.length, passed: receipt.checks.filter(x => x.pass).length, failed: receipt.checks.filter(x => !x.pass).length};
writeFileSync(join(output, 'model-receiving.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify({...receipt.summary, output, sourceSHA256: receipt.source.sha256}));
process.exitCode = receipt.summary.failed ? 1 : 0;
