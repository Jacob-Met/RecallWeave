# Independent LP model receiving

Verdict: PASS for the exact bounded continuous model, SHA25663e3a3661c0c3e1ab7da3eedd2aa3ed72c2de479ee7e29973d75de9dfdc1e18d. Eighteen independent native Node22.22.1 groups passed. This receipt does not qualify the UI, authored lesson, native learner import, browser behavior or hosted workflows; those remain separate.

The14 hand-derived cases and expectations were committed before candidate source/test inspection at c882a1231082e06e82d2b18ac17d73c1a66e4d9c. An independently written Python Fraction oracle then agreed with every hand-supplied vertex set, optimum value and complete optimal set, without a mathematical correction, and was committed at f3d60ec0cf0143e66399a200963ec8e41f6c4594.

The exact cases cover unique fractional max/min, tied edge, zero-objective polygon, line/point feasible sets, degenerate rectangles, infeasibility, zero-normal rows, duplicate/redundant/parallel inequalities and the admitted8-row/66-pair boundary. The receiver compared every one of254 pair records, every exact coordinate/objective/slack/active boundary/originating pair, full optimal vertex sets and complete-set coverage. It also checked counterclockwise polygon boundaries modulo starting rotation.

One public-label clarification was recorded before candidate execution: the original oracle used region to describe a whole optimal feasible line. The API kind describes geometry, so this case is segment with wholeRegion=true. Its coordinates, objective value and complete optimal set were unchanged. API-LABEL-CLARIFICATION.json preserves the distinction; HAND-CASES.json and FRACTION-ORACLE.json remain byte-identical to their earlier commits. No source correction was requested or made.

Four further independent groups verified:
- Row permutation and positive integer scaling preserve geometry and optima while retaining admitted rows.
- Exact API fields, numeric types, input ranges and constraint count refuse invalid problems and admit range endpoints.
- Literal integer grammar and inclusive4096-character/32-token-character/8-row limits, signed-zero normalization and form round trip.
- Preset validity and deep immutability.

All model cases additionally checked detached admitted-problem copies, frozen nested output, source-pair preservation, JSON observation inspection state and rejection of an unknown inspected vertex. The mathematical core was imported from an isolated byte-exact copy; no author tests were read or run.

Raw receiving: model-v1/RESULTS.json SHA2561602e4b610d0b6cadd512d04a658e7e83dec4981dc00c52cd112ee1c6fa3a4ce. The actual Node process exited0. All14 complete model outputs are preserved beside the receipt. The copied and author runtime sources stayed unchanged.

The native course validator was received independently from exact original source, but the new lesson's keys have not yet been read. The next content step is to solve a blinded prompt/options copy before revealing its keys, then run the unchanged validator. No further model tests are needed while this source stays exact.

Primary mathematical background read:David Karger, MIT6.854 Notes11, sections1.3–1.5, https://courses.csail.mit.edu/6.854/21/Notes/n11-lp.html. The finite rectangle makes the problem bounded; independent active boundaries identify candidate vertices and an attained vertex optimum exists for a nonempty bounded feasible set. Hand-derived cases and receiving code are original. No unboundedness, integer-programming or physical/resource-allocation claim is made.
