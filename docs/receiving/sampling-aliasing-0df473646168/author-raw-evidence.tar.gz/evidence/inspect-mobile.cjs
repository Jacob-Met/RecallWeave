const fs = require('node:fs/promises');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
async function main() {
  const root = path.resolve(__dirname, '..');
  const destination = path.join(__dirname, 'mobile-before-fix');
  await fs.mkdir(destination);
  await fs.mkdir(path.join(destination, 'tmp'));
  process.env.TMPDIR = path.join(destination, 'tmp');
  const { chromium } = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'playwright'));
  const source = path.join(root, 'candidate/courses/sampling-aliasing-lab.html');
  await fs.copyFile(source, path.join(destination, 'source.html'));
  const browser = await chromium.launch({ executablePath: '/workspace/scratch/0c6c4d37eb0f/native-product-worker/browser-runtime/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  try {
    const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
    await page.goto(pathToFileURL(source).href);
    await page.locator('#sa-table-detail summary').click();
    const result = await page.evaluate(() => ({ viewport: innerWidth, document: document.documentElement.scrollWidth, wide: [...document.querySelectorAll('body *')].map(element => ({ tag: element.tagName, id: element.id, className: typeof element.className === 'string' ? element.className : '', left: element.getBoundingClientRect().left, right: element.getBoundingClientRect().right, width: element.getBoundingClientRect().width })).filter(x => x.right > innerWidth || x.width > innerWidth) }));
    await fs.writeFile(path.join(destination, 'bounds.json'), JSON.stringify(result, null, 2) + '\n');
    await page.screenshot({ path: path.join(destination, 'mobile.png'), fullPage: true });
    process.stdout.write(JSON.stringify(result) + '\n');
  } finally { await browser.close(); }
}
main().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
