  await group('Keyboard focus outline belongs only to the focused control',async()=>{
   const initial=await b.evaluate('[...document.querySelectorAll("button")].map(e=>({id:e.id,style:getComputedStyle(e).outlineStyle,width:getComputedStyle(e).outlineWidth}))');
   assert.ok(initial.every(x=>x.style==='none'||x.width==='0px'));
   await b.key('Tab');
   assert.equal(await b.evaluate('document.activeElement.id'),'course-save');
   assert.deepEqual(await b.evaluate('(()=>{const e=document.activeElement,s=getComputedStyle(e);return {visible:e.matches(":focus-visible"),style:s.outlineStyle,width:s.outlineWidth};})()'),{visible:true,style:'solid',width:'3px'});
   assert.equal(await b.evaluate('[...document.querySelectorAll("button")].filter(e=>getComputedStyle(e).outlineStyle!=="none"&&getComputedStyle(e).outlineWidth!=="0px").length'),1);
  });
