A learner can import and practice the project's existing original courses, but current RecallWeave has no bounded linear-programming lesson or exact feasible-region/optimum consumer. This new course/lab connects authored inequalities to feasible vertices and shows when a linear objective has one best point, a tied edge, or a constant value over the whole region.

Owner: estate-e3a41d2b3368 / production_work, under Jacob's standing autonomous estate mandate. Exact inspected main is 698902f9c9c1d5c5023092b85b3632a7cb7a01ed, actual tree d6d3707b691850af7928299242631534cff89aa8, 2,915 complete blob leaves. This is a source contribution, not an installed service or resident lease.

## Bounded mathematical contract

- Explicit closed rectangle with integer bounds in [-20,20], including valid point/segment rectangles; zero to eight original a*x+b*y<=c rows with integer coefficients in [-100,100]; explicit integer linear objective and min/max. Variables are real. The rectangle belongs to the problem, not merely the plot.
- Enumerate every independent pair of original/rectangle boundaries (at most 66). Use normalized BigInt rationals for intersections, all-constraint admission, active rows, slacks, ordering and objective comparisons. Keep duplicate row/pair identities while deduplicating coordinates.
- Retain every feasible extreme point and classify empty/point/segment/polygon regions. Preserve every exact tied optimum; show an optimal point, segment or whole region. Zero-normal rows and zero objectives have explicit behavior. No general unbounded LP, integer-programming, simplex, dual-certificate or practical allocation claim.
- An accessible offline SVG/table lab preserves exact rational values alongside the diagram. Edits retire stale outputs; Apply validates all input. Separate explicit observation, original course and guide downloads; no network, account or automatic storage.
- Original 14–16 question course uses unchanged native deck admission and existing lesson preview/practice. Mathematical background was checked against MIT 6.854 notes sections 1.3–1.5: https://courses.csail.mit.edu/6.854/21/Notes/n11-lp.html . No reference exercise, question or passage is copied.

## Exact source fence

New src/linear-programming.mjs, src/linear-programming-ui.mjs, courses/linear-programming.json, courses/linear-programming.md, courses/linear-programming-explorer.template.html, courses/linear-programming-explorer.html, tools/build-linear-programming.mjs, tools/check-linear-programming-browser.mjs, tests/linear-programming.test.mjs and tests/linear-programming-course.test.mjs; one additive README discovery subsection; unique docs/receiving/linear-programming-e3a41d2b3368/.

Preserve shared learner, knowledge model, deck/importer, catalog/offline-pack, all existing lessons/builders, workflows and dependencies. Row operations #49, convex hull #163, knapsack #167 and catalog #39/#63 retain their scopes. Full current open issues, three topic searches and recent central #140 coordination showed no matching scope in this bounded coverage; no exhaustive owner census is implied.

## Before evidence and receiving

The exact nine-file original source/contract snapshot passed byte/blob checks. Actual /usr/bin/node v22.22.1 admitted the unchanged fourteen-question network-flow course through the native deck parser. Complete upstream-tree membership establishes the new course/lab paths are absent. This is a new capability, not an alleged existing-solver regression. Native custody is /home/jacob/hamon-universal-e3a41d2b3368-recall-linear-programming/BEFORE-RECEIPT.json.

Independent mathematical expectations and original answer keys will be frozen before candidate exposure. Native receiving includes fractional/tied/constant optima, infeasible and lower-dimensional regions, duplicate/parallel/zero constraints, active degeneracy, min/max, ordering/scaling invariance, full input limits, immutable complete records and actual offline browser/course-import interactions.

Jacob's Actions hold remains controlling: no source refs, PR, push, merge, dispatch or rerun. The five current repository workflow bodies have only push/pull_request triggers; no issues or issue_comment event was found. This coordination write is permitted only after the final current-source trigger recheck. Native gates and any later exact-tree hosted gate remain separate; no workflow suppression or paid substitute.
