const fs0=require('node:fs'),crypto0=require('node:crypto');const base0='/Users/me/hamon-native-406d0fb04c43/recallweave-weighted-intervals';const old0=fs0.readFileSync(base0+'/evidence/author-gates-v1/source/tests/weighted-intervals.test.mjs','utf8'),new0=fs0.readFileSync(base0+'/candidate/tests/weighted-intervals.test.mjs','utf8');const needle0="const notes = createStudyNotes({deck, review, mastery, practice, exportedAt: new Date('2026-10-08T00:00:00Z')});";const expected0=old0.replace(needle0,needle0.slice(0,-1)+'.text;');if(expected0!==new0)throw new Error('Unexpected authored test change');fs0.writeFileSync(base0+'/evidence/author-test-correction.json',JSON.stringify({format:'recallweave-author-test-correction/1',reason:'createStudyNotes returns {filename, mediaType, text}; original assertion incorrectly passed the object to assert.match.',originalAssertionsPreserved:true,onlyEdit:'Read the maintained .text return field.',originalSha256:crypto0.createHash('sha256').update(old0).digest('hex'),correctedSha256:crypto0.createHash('sha256').update(new0).digest('hex')},null,2)+'\n',{flag:'wx'});
const fs=require('node:fs'),p=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const root='/Users/me/hamon-native-406d0fb04c43/recallweave-weighted-intervals';const source=p.join(root,'candidate');
const evidence=p.join(root,'evidence','author-gates-v2');fs.mkdirSync(evidence,{recursive:true});
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const paths=JSON.parse(fs.readFileSync(p.join(root,'source-intake-receipt.json'),'utf8')).files;
const before=paths.map(f=>({path:f.path,sha256:hash(fs.readFileSync(p.join(source,f.path)))}));const runs=[];
for(const [name,args] of [['build',['tools/build_weighted_intervals_explorer.mjs']],['tests',['--test','tests/weighted-intervals.test.mjs']]]){
 const r=cp.spawnSync('/opt/homebrew/bin/node',args,{cwd:source,env:{PATH:'/opt/homebrew/bin:/usr/bin:/bin',LANG:'en_US.UTF-8'},encoding:'utf8',timeout:60000,maxBuffer:2000000});
 fs.writeFileSync(p.join(evidence,name+'.stdout.txt'),r.stdout||'',{flag:'wx'});fs.writeFileSync(p.join(evidence,name+'.stderr.txt'),r.stderr||'',{flag:'wx'});
 runs.push({name,args,exitCode:r.status,signal:r.signal,error:r.error?.message||null,stdoutSha256:hash(r.stdout||''),stderrSha256:hash(r.stderr||'')});
 if(r.status!==0)break;
}
const after=paths.map(f=>({path:f.path,sha256:hash(fs.readFileSync(p.join(source,f.path)))}));
const receipt={format:'recallweave-weighted-intervals-author-gates/1',timestamp:new Date().toISOString(),node:process.version,canonicalBaseline:'3cdebd86e69506709bcaeaeff4026deb3d1fc208',source,before,after,inheritedUnchanged:JSON.stringify(before)===JSON.stringify(after),runs};
fs.writeFileSync(p.join(evidence,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({inheritedUnchanged:receipt.inheritedUnchanged,runs,evidence}));if(runs.some(r=>r.exitCode!==0))process.exitCode=1;