An equally likely fixed-size subset is a different model from independent draws. This contribution adds an original 14-question hypergeometric lesson and a self-contained explorer that makes the subset counts visible.

The learner applies a population of 1–200 distinct tokens, a marked count, a sample size and an inclusive marked-count event. The page exposes support limits, exact combination factors and counts, reduced probabilities, expectation and finite-population variance. Impossible counts and empty/one-token/census boundaries remain explicit. Row inspection shows a clearly labelled deterministic example subset, while draft edits retire prior results. Exact observations, course JSON and the worked guide can be downloaded without network or storage. The course uses the unchanged RecallWeave importer, feedback, review, practice and notes.

Source qualification:
- Original 99 unchanged selected learner/deck/author tests pass; candidate 107 pass, including 8 new groups.
- Exact production counts, events and moments agree with 818 independently enumerated labelled-subset configurations through N=12. Independent addition-only Pascal controls cover N=200 counts beyond Number's exact integer range.
- The 14-question key was independently answered and frozen before exposure to the answer key/core. Subsequent source review accepted all explanations and worked transfers.
- Actual offline Chromium 153 passes 14 groups with 5 exact downloads, desktop/390px layout, full course import, all 14 feedback/review prompts, a separate practice retry and study notes.
- Seven-file offline ZIP is extracted byte-for-byte and passes 3 further actual start-page/link/course-download/learner-import checks.
- No page exceptions, external requests, storage writes or source changes were observed. The initial incomplete Enter event in the receiver is retained alongside the corrected receiving.
- The full repository suite has not been claimed as run; all 33 unchanged source inputs used by the selected native qualification remain exact on current main 698902f9.

Current native composition preserves all 2,914 unrelated leaves of the 2,915-leaf parent and all original current README bytes, with only one additive README section and ten new product/test/receiver paths. The complete source overlay, partial local Git bundle and qualification evidence remain native.

Publication is held under the current owner instruction not to trigger GitHub Actions. No remote source branch, PR, merge or workflow has been created for this contribution. The local Git snapshot is partial input ancestry and must never be pushed as a replacement for the full canonical repository. Any later integration must revalidate current ownership/source and preserve the full canonical tree under an expressly permitted route.
