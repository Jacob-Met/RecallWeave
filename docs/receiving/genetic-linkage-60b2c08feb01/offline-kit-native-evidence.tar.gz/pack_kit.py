#!/usr/bin/env python3
"""Package already frozen lesson bytes. No browser, model or learner execution."""
import argparse, hashlib, html.parser, io, json, pathlib, posixpath, re, stat, urllib.parse, zipfile

EXPECTED = {
    "demo.html": "ef7bc3e27e7f161d917ced6a457fad8822802f3f",
    "courses/genetic-linkage.json": "5a345bb64da2c8bfc6821352d5fbec5c9bf3e183",
    "courses/genetic-linkage.md": "6b156ad665c7298dcfd0552acf4df879c8993720",
    "courses/genetic-linkage-lab.html": "5ba8c756f029207ee2042e45da3d7823d9fe5535",
    "courses/mendelian-inheritance.json": "b3c1635fa5fa3f841dfdba0bb02d4557223d65f1",
    "courses/mendelian-inheritance.md": "4baa34f6deb3a85d4bc0e0c39228510f19c36665",
    "courses/mendelian-inheritance-lab.html": "191778dc2686ede93d0ce9e71547f25513b8cd37",
}
BASE = "698902f9c9c1d5c5023092b85b3632a7cb7a01ed"

def identity(body):
    return {"bytes": len(body),
            "git": hashlib.sha1(b"blob " + str(len(body)).encode() + b"\0" + body).hexdigest(),
            "sha256": hashlib.sha256(body).hexdigest()}

class Page(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.ids = set()
        self.styles = []
        self.in_style = False
        self.external_assets = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.add(attrs["id"])
        if tag == "a" and "name" in attrs:
            self.ids.add(attrs["name"])
        for key in ("href", "src", "action", "poster", "xlink:href"):
            if attrs.get(key):
                self.links.append((tag, key, attrs[key]))
                if tag in ("script", "link", "img", "iframe", "source") and urllib.parse.urlsplit(attrs[key]).scheme in ("http", "https"):
                    self.external_assets.append(attrs[key])
        if attrs.get("srcset"):
            for choice in attrs["srcset"].split(","):
                self.links.append((tag, "srcset", choice.strip().split()[0]))
        if attrs.get("style"):
            self.styles.append(attrs["style"])
        if tag == "style":
            self.in_style = True
    def handle_endtag(self, tag):
        if tag == "style":
            self.in_style = False
    def handle_data(self, data):
        if self.in_style:
            self.styles.append(data)

def collect_links(name, body):
    text = body.decode("utf-8")
    if name.endswith(".html"):
        page = Page()
        page.feed(text)
        for css in page.styles:
            for target in re.findall(r"url\(\s*['\"]?([^)'\"]+)", css):
                page.links.append(("style", "url", target.strip()))
        assert not page.external_assets, (name, page.external_assets)
        assert not any(re.search(r"@import\b", style) for style in page.styles), name
        return page.links, page.ids
    if name.endswith(".md"):
        # These two pinned guides use inline Markdown links, without reference definitions.
        clean = re.sub(r"\x60\x60\x60[^\n]*\n[\s\S]*?\x60\x60\x60", "", text)
        assert not re.search(r"^\s*\[[^\]]+\]:", clean, re.M), name
        links = [("markdown", "link", match) for match in re.findall(r"\[[^\]]*\]\(([^)]+)\)", clean)]
        ids = set()
        for line in clean.splitlines():
            if line.startswith("#"):
                heading = re.sub(r"[^\w\s-]", "", line.lstrip("#").strip().lower())
                ids.add(re.sub(r"\s+", "-", heading))
        return links, ids
    return [], set()

def zip_bytes(members):
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, body in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return output.getvalue()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=pathlib.Path)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    parser.add_argument("--receipt", required=True, type=pathlib.Path)
    args = parser.parse_args()
    source = {name: (args.root / name).read_bytes() for name in EXPECTED}
    for name, body in source.items():
        assert identity(body)["git"] == EXPECTED[name], name
    source_before = {name: identity(body) for name, body in source.items()}
    manifest = {
        "format": "recallweave-genetic-linkage-offline-kit/1",
        "repository": "Jacob-Met/RecallWeave",
        "claim": "https://github.com/Jacob-Met/RecallWeave/issues/198",
        "inheritedBase": BASE,
        "sourceFreeze": "a7b1124e899edd0d80dd42fd30737e6f1b9168e7",
        "assets": {name: {**identity(body),
            "source": "https://api.github.com/repos/Jacob-Met/RecallWeave/git/blobs/" + EXPECTED[name],
            "lineage": "frozen issue198 addition" if name.startswith("courses/genetic-linkage") else "unchanged inherited asset at " + BASE}
            for name, body in sorted(source.items())},
        "courseDeclarations": {name: {key: json.loads(source[name])[key] for key in ("title", "attribution", "license")}
            for name in ("courses/genetic-linkage.json", "courses/mendelian-inheritance.json")},
        "licenseBoundary": "Course declarations are copied verbatim and apply as stated. Referenced sources retain their terms. This package assigns no blanket license to learner or companion code.",
        "opening": "Extract all files, preserve paths, open START-HERE.html. Select courses/genetic-linkage.json explicitly in demo.html, preview, then Start this deck.",
        "closure": "Two lesson families, their exact standalone labs/guides/course JSON and unchanged learner. Developer maintenance commands in guides require the full repository, which is not included.",
        "scope": "Static packaging and byte/link verification only; no additional browser, learner, model, Windows or installed-runtime execution.",
        "checksums": "SHA256SUMS covers every other ZIP member; hashes are not authenticated signatures."
    }
    members = dict(source)
    for name in ("START-HERE.html", "README.txt"):
        members[name] = (args.root / name).read_bytes()
    members["SOURCE-MANIFEST.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
    members["SHA256SUMS"] = "".join(identity(body)["sha256"] + "  " + name + "\n" for name, body in sorted(members.items())).encode()
    assert len(members) == 11
    assert len({name.casefold() for name in members}) == len(members)
    for name in members:
        path = pathlib.PurePosixPath(name)
        assert not path.is_absolute() and all(part not in ("", ".", "..") for part in path.parts)
        assert "\\" not in name and ":" not in name and posixpath.normpath(name) == name
    document_links = {}
    ids = {}
    for name, body in members.items():
        document_links[name], ids[name] = collect_links(name, body)
    local = []
    external = []
    for name, links in document_links.items():
        for tag, attribute, raw_target in links:
            target = urllib.parse.urlsplit(raw_target)
            record = {"from": name, "tag": tag, "attribute": attribute, "target": raw_target}
            if target.scheme or target.netloc:
                assert target.scheme in ("https", "http", "mailto", "data", "blob"), record
                external.append(record)
                continue
            assert not target.path.startswith("/"), record
            destination = posixpath.normpath(posixpath.join(posixpath.dirname(name), urllib.parse.unquote(target.path))) if target.path else name
            assert destination in members, {**record, "resolved": destination}
            if target.fragment:
                assert urllib.parse.unquote(target.fragment) in ids[destination], {**record, "resolved": destination}
            local.append({**record, "resolved": destination, "fragmentChecked": bool(target.fragment)})
    first = zip_bytes(members)
    assert first == zip_bytes(members), "Nondeterministic ZIP"
    with zipfile.ZipFile(io.BytesIO(first)) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == sorted(members)
        for info in archive.infolist():
            assert stat.S_ISREG(info.external_attr >> 16)
            assert stat.S_IMODE(info.external_attr >> 16) == 0o644
            assert info.create_system == 3 and not info.is_dir() and info.flag_bits & 1 == 0
            assert archive.read(info.filename) == members[info.filename]
        for line in archive.read("SHA256SUMS").decode().splitlines():
            digest, name = line.split("  ", 1)
            assert identity(archive.read(name))["sha256"] == digest
    source_after = {name: identity((args.root / name).read_bytes()) for name in EXPECTED}
    assert source_before == source_after
    with args.output.open("xb") as handle:
        handle.write(first)
    assert args.output.read_bytes() == first
    receipt = {
        "format": "recallweave-genetic-linkage-packaging-receipt/1",
        "archive": identity(first), "members": {name: identity(body) for name, body in sorted(members.items())},
        "sourceBefore": source_before, "sourceAfter": source_after,
        "deterministicRebuildEqual": True, "regular0644Entries": True, "safeUniqueNames": True,
        "allArchiveMembersReadBackEqual": True, "checksumsVerified": len(members) - 1,
        "localLinks": local, "externalOptionalLinks": external,
        "dynamicLinksReview": "Both labs and demo have no literal external script/style/media assets. Script href assignments use locally generated Blob URLs; file inputs and downloaded user records are not packaged asset dependencies.",
        "limits": "Static packaging only. No course, model, learner or browser gate rerun and no Windows/installed adoption claim."
    }
    with args.receipt.open("xb") as handle:
        handle.write((json.dumps(receipt, ensure_ascii=False, indent=2) + "\n").encode())
    print(json.dumps({"archive": receipt["archive"], "members": len(members),
        "checksums": receipt["checksumsVerified"], "localLinks": len(local), "externalLinks": len(external),
        "receipt": identity(args.receipt.read_bytes())}))
if __name__ == "__main__":
    main()
