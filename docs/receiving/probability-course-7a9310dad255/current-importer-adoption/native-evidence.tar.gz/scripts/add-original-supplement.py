import json,hashlib,os,shutil
from pathlib import Path
root=Path("/tmp/hamon-7a9310dad255-recall19-integration")
candidate=root/"candidate"
new=candidate/"docs/receiving/probability-course-7a9310dad255/current-importer-adoption"
def pin(data):
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
def tree_id(rows):
    tree={}
    for row in rows:
        node=tree;parts=row["path"].split("/")
        for part in parts[:-1]:node=node.setdefault(part,{})
        assert parts[-1] not in node
        node[parts[-1]]=(row["mode"],row["git_blob"])
    def emit(node):
        data=b""
        for name,item in sorted(node.items(),key=lambda x:(x[0]+("/" if isinstance(x[1],dict) else "")).encode()):
            mode,sha=("40000",emit(item)) if isinstance(item,dict) else item
            data+=mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(sha)
        return hashlib.sha1(b"tree "+str(len(data)).encode()+b"\0"+data).hexdigest()
    return emit(tree)
def snapshot():
    rows=[]
    for p in sorted(candidate.rglob("*")):
        assert not p.is_symlink(),str(p)
        if p.is_file():rows.append({"path":str(p.relative_to(candidate)),"mode":"100755" if p.stat().st_mode&0o111 else "100644",**pin(p.read_bytes())})
    return rows
before=json.loads((root/"course-composed-source-manifest.json").read_text())
assert snapshot()==before["files"]
new.mkdir()
readme=(root/"current-adoption-README.md").read_bytes()
(new/"README.md").write_bytes(readme)
for src,dest,sha in [
("/tmp/hamon-7a9310dad255-recall19-review/adoption-assessment.json","independent-assessment.json","f94933c191a09838769398342d3819768a95f1a7094d12b76b482bb5d6206bcd"),
("/tmp/hamon-7a9310dad255-recall19-review/current-d202-adoption-supplement.json","current-d202-compatibility.json","1a18ed4a835a0b6851faed39209b32260f00507f0aafc6aba9bdb64eda11af9f")]:
    data=Path(src).read_bytes();assert pin(data)["sha256"]==sha
    with (new/dest).open("xb") as f:f.write(data)
after=snapshot();assert len(after)==475
old={x["path"]:x for x in before["files"]};actual={x["path"]:x for x in after}
assert all(actual[p]==x for p,x in old.items())
manifest={"repository":"Jacob-Met/RecallWeave","current_head":before["current_head"],"current_tree":before["current_tree"],"course_head":before["course_head"],"source_tree":tree_id(after),"files":after,"original_472_preserved":True,"source_label":"d202 current source + exact original 28 course files + three additive adoption documents; before required native checks"}
with (root/"pre-ci-source-manifest.json").open("x") as f:json.dump(manifest,f,indent=2);f.write("\n")
print(json.dumps({"source_tree":manifest["source_tree"],"file_count":len(after),"original_472_preserved":True,"supplement":[x for x in after if x["path"] not in old],"manifest":pin((root/"pre-ci-source-manifest.json").read_bytes())},indent=2))
