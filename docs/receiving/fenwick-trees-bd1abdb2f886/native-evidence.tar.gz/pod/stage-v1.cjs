const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),cp=require("node:child_process");
const root="/home/ubuntu/hamon-receiving-bd1abdb2f886-20261009/fenwick";
const input=JSON.parse(fs.readFileSync(path.join(root,"input-v1.json")));
const hash=b=>crypto.createHash("sha256").update(b).digest("hex");
const git=b=>crypto.createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
const pin=p=>{const b=fs.readFileSync(p);return{bytes:b.length,sha256:hash(b),git_blob:git(b),mode:(fs.statSync(p).mode&511).toString(8)};};
async function binary(p){const sha=crypto.createHash("sha256");let bytes=0;for await(const chunk of fs.createReadStream(p)){bytes+=chunk.length;sha.update(chunk);}return{path:p,resolved:fs.realpathSync(p),bytes,sha256:sha.digest("hex"),mode:(fs.statSync(p).mode&511).toString(8)};}
function guard(){
 const cgroup=fs.readFileSync("/proc/self/cgroup","utf8").trim();if(cgroup!==input.expected_cgroup)throw Error("Admitted cgroup drift");
 const mem=Number(/^MemAvailable:\s+(\d+)/m.exec(fs.readFileSync("/proc/meminfo","utf8"))[1])*1024,s=fs.statfsSync(root),disk=s.bavail*s.bsize;
 const pressure=Object.fromEntries(["memory","io"].map(n=>[n,fs.readFileSync("/proc/pressure/"+n,"utf8")]));
 if(mem<2147483648||disk<268435456||Number(/^full avg10=([\d.]+)/m.exec(pressure.memory)[1])>2||Number(/^full avg10=([\d.]+)/m.exec(pressure.io)[1])>10)throw Error("Native resource guard");
 const cg=path.join("/sys/fs/cgroup",cgroup.slice(3));const events=fs.readFileSync(cg+"/memory.events","utf8");if(/^oom(?:_kill|_group_kill)? [1-9]/m.test(events))throw Error("Observed cgroup OOM");
 return{cgroup,memory_available:mem,disk_available:disk,pressure,cgroup_memory_max:fs.readFileSync(cg+"/memory.max","utf8").trim(),cgroup_memory_events:events};
}
(async()=>{
 const receipt=path.join(root,"staging-v1.json");if(fs.existsSync(receipt))throw Error("Read prior staging result; do not replay");
 const result={schema:"recallweave-fenwick-pod-staging/v1",at:new Date().toISOString(),guard:guard(),input:pin(path.join(root,"input-v1.json")),controller:pin(__filename),commands:[]};
 if(result.input.git_blob!=="b0130d5c3fb9f962d2c657472c90ba9f7e36ac8d")throw Error("Input packet mismatch");
 for(const f of input.files){if(!/^(product|consumer|receivers)\/[A-Za-z0-9._/-]+$/.test(f.path)||f.path.split("/").includes(".."))throw Error("Bad source path");const p=path.join(root,f.path),b=Buffer.from(f.content);if(git(b)!==f.git_blob)throw Error("Exact source mismatch "+f.path);if(fs.existsSync(p))throw Error("Fresh files required");fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:"wx",mode:420});}
 const sourcePins=()=>Object.fromEntries(input.files.map(f=>[f.path,pin(path.join(root,f.path))]));
 result.source_before=sourcePins();
 const env={...process.env,XDG_DATA_HOME:path.join(root,"xdg/data"),XDG_CONFIG_HOME:path.join(root,"xdg/config"),XDG_CACHE_HOME:path.join(root,"xdg/cache"),TMPDIR:path.join(root,"tmp")};
 for(const key of["XDG_DATA_HOME","XDG_CONFIG_HOME","XDG_CACHE_HOME","TMPDIR"])fs.mkdirSync(env[key],{recursive:true,mode:448});
 fs.mkdirSync(path.join(root,"profiles"),{mode:448});fs.mkdirSync(path.join(root,"helper-qa"));
 result.runtime={node:await binary(process.execPath),chrome_wrapper:await binary("/usr/bin/google-chrome"),chrome_binary:await binary("/opt/google/chrome/chrome"),node_version:process.version,platform:process.platform,arch:process.arch};
 const version=cp.spawnSync("/usr/bin/google-chrome",["--version"],{env,encoding:"utf8",timeout:10000});if(version.status!==0)throw Error("Chrome metadata failed");result.runtime.chrome_version=version.stdout.trim();result.runtime.chrome_version_stderr=version.stderr;
 const helper=path.join(root,"receivers/fenwick-trees-browser-helpers.mjs"),tests=path.join(root,"receivers/lifecycle-tests.mjs");
 const args=[tests,helper],start=Date.now();const run=cp.spawnSync(process.execPath,args,{cwd:root,env,encoding:"utf8",timeout:600000,maxBuffer:2*1024*1024});
 for(const name of["stdout","stderr"])fs.writeFileSync(path.join(root,"helper-qa/"+name+".txt"),run[name]||"",{flag:"wx"});
 result.commands.push({argv:[process.execPath,...args],outer_timeout_ms:600000,exit:run.status,signal:run.signal,error:run.error?String(run.error):null,milliseconds:Date.now()-start,stdout:pin(path.join(root,"helper-qa/stdout.txt")),stderr:pin(path.join(root,"helper-qa/stderr.txt"))});
 if(run.status===0){result.helper_report=JSON.parse(run.stdout);fs.writeFileSync(path.join(root,"helper-qa/report.json"),run.stdout,{flag:"wx"});}
 result.source_after=sourcePins();result.guard_after=guard();
 result.pass=run.status===0&&!run.error&&JSON.stringify(result.source_before)===JSON.stringify(result.source_after);
 fs.writeFileSync(receipt,JSON.stringify(result,null,2)+"\n",{flag:"wx"});console.log(JSON.stringify({pass:result.pass,summary:result.helper_report?.summary,commands:result.commands,receipt:pin(receipt),guard:result.guard_after,runtime:result.runtime}));process.exitCode=result.pass?0:1;
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
