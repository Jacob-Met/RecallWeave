import pathlib,json,hashlib,subprocess,datetime
root=pathlib.Path("/Users/me/hamon-recallweave-current-learner-receiving-68094585a1c2")
source=root/"source"
projection=json.loads((root/"source-projection.json").read_text())
def pins():
 return {name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in projection["source_files"]}
before=pins()
assert all(before[name]==row["sha256"] for name,row in projection["source_files"].items())
argv=["/opt/homebrew/bin/node",str(source/"tools/check-mendelian-inheritance-browser.mjs"),"--root",str(source),
 "--playwright","/Users/me/longwater-author-tests-566d51f04b31/node_modules/playwright/index.mjs",
 "--browser","/Applications/Google Chrome.app/Contents/MacOS/Google Chrome","--output",str(root/"browser-v1")]
record={"format":"recallweave-current-learner-native-execution/1","parent":projection["parent"],"parent_tree":projection["parent_tree"],
 "argv":argv,"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_before":before}
with (root/"browser-v1.log").open("wb") as log:
 try:
  result=subprocess.run(argv,cwd=source,stdout=log,stderr=subprocess.STDOUT,timeout=150)
  record["exit_code"]=result.returncode
 except subprocess.TimeoutExpired:record["exit_code"]="timeout"
record["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
record["source_after"]=pins()
record["source_stable"]=record["source_before"]==record["source_after"]
(root/"browser-execution-v1.json").write_text(json.dumps(record,indent=2)+"\n")
browser_report=root/"browser-v1"/"browser-report.json"
if browser_report.is_file():
 b=json.loads(browser_report.read_text())
 record["browser_summary"]={"status":b["status"],"checkpoints":len(b["checks"]),"learner_variants":[x["label"] for x in b.get("learnerRuns",[])],
 "downloads":len(b["downloads"]),"screenshots":len(b["screenshots"]),"page_errors":b["pageErrors"],"console_errors":b["consoleErrors"],"dialogs":b["dialogs"],
 "runner_source_stable":b["sourcePinsStable"]}
print(json.dumps({k:v for k,v in record.items() if k not in ["source_before","source_after"]}),flush=True)
