#!/usr/bin/env node
/**
 * Optional direct-file receiving for the original edit-distance explorer and its course.
 * Node 22+ and an installed Chromium-family browser; no npm dependency.
 * CDP transport follows the repository's existing browser-check convention.
 */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import {readFile, writeFile, mkdir, mkdtemp, rm, readdir, statfs} from 'node:fs/promises';
import {dirname, join, resolve} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

const args = process.argv.slice(2);
const option = (name, fallback) => args.includes(name) ? args[args.indexOf(name) + 1] : fallback;
const project = resolve(option('--root', join(dirname(fileURLToPath(import.meta.url)), '..')));
const executable = option('--browser', 'chromium');
const output = resolve(option('--output', join(project, 'edit-distance-browser-check')));
await mkdir(output, {recursive: true});
assert.deepEqual(await readdir(output), [], 'Use a new empty output directory; earlier receipts are preserved.');
const profileParent = resolve(option('--profile-parent', output));
const capacity = await statfs(profileParent);
assert.ok(capacity.bavail * capacity.bsize > 150000000, 'Admit a bounded private browser profile only when capacity is available.');
const profile = await mkdtemp(join(profileParent, 'hamon-edit-distance-profile-'));
const downloadEvents = [];
const sourcePaths = [
  "courses/edit-distance-core.mjs",
  "courses/edit-distance-ui.mjs",
  "courses/edit-distance-explorer.template.html",
  "courses/edit-distance-explorer.html",
  "courses/edit-distance.json",
  "courses/edit-distance.md",
  "tools/build_edit_distance_explorer.mjs",
  "tools/check_edit_distance_browser.mjs",
  "tests/edit-distance.test.mjs",
  "README.md",
  "demo.html"
];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const pins = async () => Object.fromEntries(await Promise.all(sourcePaths.map(async path => [path, hash(await readFile(join(project, path)))])));
const report = {
  format: 'recallweave-edit-distance-author-browser/1', status: 'running',
  started: new Date().toISOString(), node: process.version, project, executable,
  sourceSha256: await pins(), checks: [], captures: [], downloads: [], pageErrors: [], requests: [], profileParent, profileCapacityBytes: capacity.bavail * capacity.bsize
};
let browser, socket, sessionId, sequence = 0, browserLog = '';
const pending = new Map();
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(check, label) {
  let last;
  for (let index = 0; index < 180; index++) {
    try { if (await check()) return; } catch (error) { last = error; }
    await pause(100);
  }
  throw new Error('Timed out: ' + label + (last ? ' (' + last.message + ')' : ''));
}
function command(method, params = {}, scoped = true) {
  const id = ++sequence;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(new Error('CDP timeout: ' + method)); }, 10000);
    pending.set(id, {resolve, reject, timer});
    socket.send(JSON.stringify({id, method, params, ...(scoped && sessionId ? {sessionId} : {})}));
  });
}
async function evaluate(expression) {
  const response = await command('Runtime.evaluate', {expression, returnByValue: true, awaitPromise: true});
  if (response.exceptionDetails) throw new Error(response.exceptionDetails.exception?.description ?? response.exceptionDetails.text);
  return response.result.value;
}
async function key(name) {
  const codes = {Enter: 13, Tab: 9, Backspace: 8, Home: 36, ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39};
  assert.ok(Object.hasOwn(codes, name), 'Known keyboard command');
  for (const type of ['keyDown', 'keyUp']) await command('Input.dispatchKeyEvent', {
    type, key: name, code: name, windowsVirtualKeyCode: codes[name], nativeVirtualKeyCode: codes[name],
    ...(name === 'Enter' && type === 'keyDown' ? {text: '\r', unmodifiedText: '\r'} : {})
  });
}
async function activate(selector) {
  assert.equal(await evaluate('!!document.querySelector(' + JSON.stringify(selector) + ')'), true);
  assert.notEqual(await evaluate('document.querySelector(' + JSON.stringify(selector) + ').disabled'), true);
  await evaluate('document.querySelector(' + JSON.stringify(selector) + ').focus()');
  await key('Enter');
}
async function input(selector, text) {
  await evaluate('(()=>{const e=document.querySelector(' + JSON.stringify(selector) + ');e.focus();e.select();})()');
  if (text) await command('Input.insertText', {text});
  else await key('Backspace');
  assert.equal(await evaluate('document.querySelector(' + JSON.stringify(selector) + ').value'), text);
}
async function loadExample(name) {
  const index = await evaluate('[...document.querySelector("#example").options].findIndex(option=>option.value===' + JSON.stringify(name) + ')');
  assert.ok(index >= 0);
  await evaluate('document.querySelector("#example").focus()');
  await key('Home');
  for (let item = 0; item < index; item++) await key('ArrowDown');
  await key('Tab');
  assert.equal(await evaluate('document.querySelector("#example").value'), name);
  await activate('#load-example');
}
const text = selector => evaluate('document.querySelector(' + JSON.stringify(selector) + ').textContent');
async function state() {
  return evaluate('({source:document.querySelector("#source")?.value,target:document.querySelector("#target")?.value,distance:document.querySelector("#distance")?.textContent,paths:document.querySelector("#path-count")?.textContent,selected:document.querySelector("#cell-title")?.textContent,step:document.querySelector("#step-status")?.textContent,error:document.querySelector("#input-error")?.textContent,downloadDisabled:document.querySelector("#download-comparison")?.disabled,active:document.activeElement.id,pageWidth:document.documentElement.scrollWidth,width:innerWidth})');
}
async function capture(name, selector) {
  if (selector) await evaluate('document.querySelector(' + JSON.stringify(selector) + ').scrollIntoView({block:"start"})');
  const {data} = await command('Page.captureScreenshot', {format: 'png', captureBeyondViewport: false});
  const bytes = Buffer.from(data, 'base64');
  await writeFile(join(output, name), bytes, {flag: 'wx'});
  report.captures.push({path: name, bytes: bytes.length, sha256: hash(bytes), viewport: await evaluate('({width:innerWidth,height:innerHeight,scrollY})')});
}
const passed = name => { report.checks.push(name); console.log('PASS ' + name); };

async function downloadControl(selector, label) {
  const folder = join(output, 'downloads', label);
  await mkdir(folder, {recursive: true});
  await command('Browser.setDownloadBehavior', {behavior: 'allow', downloadPath: folder, eventsEnabled: true}, false);
  const start = downloadEvents.length;
  await activate(selector);
  await waitFor(() => downloadEvents.slice(start).some(event => event.method === 'Browser.downloadProgress' && event.params.state === 'completed'), label + ' physical download');
  const begin = downloadEvents.slice(start).find(event => event.method === 'Browser.downloadWillBegin');
  assert.ok(begin, 'The browser emitted a download identity.');
  const file = join(folder, begin.params.suggestedFilename);
  let bytes;
  await waitFor(async () => { bytes = await readFile(file); return bytes.length > 0; }, label + ' downloaded bytes');
  report.downloads.push({label,filename:begin.params.suggestedFilename,path:file,bytes:bytes.length,sha256:hash(bytes),events:downloadEvents.slice(start)});
  return {file,bytes};
}
const url = pathToFileURL(join(project, 'courses/edit-distance-explorer.html')).href;
try {
  browser = spawn(executable, [
    '--headless=new', '--no-sandbox', '--disable-gpu', '--disable-background-networking',
    '--disable-component-update', '--disable-sync', '--no-first-run', '--no-default-browser-check',
    '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0',
    '--user-data-dir=' + profile, 'about:blank'
  ], {stdio: ['ignore', 'ignore', 'pipe']});
  browser.stderr.on('data', data => { browserLog = (browserLog + data.toString()).slice(-16000); });
  let launchError;
  browser.on('error', error => { launchError = error; });
  let port, endpoint;
  await waitFor(async () => {
    if (launchError) throw launchError;
    if (browser.exitCode !== null) throw new Error('Browser exited ' + browser.exitCode);
    [port, endpoint] = (await readFile(join(profile, 'DevToolsActivePort'), 'utf8')).trim().split('\n');
    return Boolean(port && endpoint);
  }, 'isolated native browser startup');
  socket = new WebSocket('ws://127.0.0.1:' + port + endpoint);
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id) {
      const entry = pending.get(message.id);
      if (!entry) return;
      pending.delete(message.id); clearTimeout(entry.timer);
      if (message.error) entry.reject(new Error(message.error.message)); else entry.resolve(message.result);
    } else if (message.method === 'Browser.downloadWillBegin' || message.method === 'Browser.downloadProgress') {
      downloadEvents.push(message);
    } else if (message.method === 'Runtime.exceptionThrown') {
      report.pageErrors.push(message.params.exceptionDetails.exception?.description ?? message.params.exceptionDetails.text);
    } else if (message.method === 'Network.requestWillBeSent') report.requests.push(message.params.request.url);
  });
  await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, {once: true});
    socket.addEventListener('error', reject, {once: true});
  });
  report.browser = await command('Browser.getVersion', {}, false);
  const {targetId} = await command('Target.createTarget', {url: 'about:blank'}, false);
  ({sessionId} = await command('Target.attachToTarget', {targetId, flatten: true}, false));
  await command('Page.enable'); await command('Runtime.enable'); await command('Network.enable');
  await command('Network.setBlockedURLs', {urls: ['http://*', 'https://*', 'ws://*', 'wss://*']});
  await command('Emulation.setDeviceMetricsOverride', {width: 1360, height: 1100, deviceScaleFactor: 1, mobile: false});
  await command('Page.navigate', {url});
  await waitFor(() => evaluate('document.readyState==="complete"&&document.querySelectorAll("#prefix-matrix button").length===56'), 'offline explorer startup');
  assert.equal(await text('#distance'), '3');
  assert.equal(await text('#lengths'), '6 → 7');
  assert.equal(await text('#step-status'), '0 of 7 alignment columns revealed');
  assert.equal(await evaluate('document.documentElement.scrollWidth>innerWidth'), false);
  await capture('01-default-desktop.png');
  const firstCourse = await downloadControl('#download-course', 'course-before-edits');
  const originalCourse = await readFile(join(project, 'courses/edit-distance.json'));
  assert.deepEqual(firstCourse.bytes, originalCourse);
  passed('direct-file startup exposes the complete KITTEN/SITTING prefix matrix and downloads the exact fixed course');

  await activate('#next-step');
  assert.equal(await text('#cell-title'), 'D[1][1] = 1');
  assert.match(await text('#alignment-columns'), /substitute · \+1 · total 1/);
  await activate('#show-all');
  assert.equal(await text('#step-status'), '7 of 7 alignment columns revealed');
  assert.match(await text('#alignment-summary'), /Consumed 6 source and 7 target code points; running cost 3/);
  await activate('#previous-step');
  assert.equal(await text('#step-status'), '6 of 7 alignment columns revealed');
  passed('real keyboard step controls connect forward alignment columns to consumed prefixes and cumulative cost');

  await loadExample('ties');
  assert.equal(await text('#distance'), '2'); assert.equal(await text('#path-count'), '3');
  assert.equal(await evaluate('document.querySelectorAll("#candidate-list li.optimal").length'), 3);
  assert.match(await text('#tie-note'), /There is a tie/);
  await activate('#prefix-matrix button[data-i="2"][data-j="2"]');
  await key('ArrowLeft');
  assert.equal(await text('#cell-title'), 'D[2][1] = 1');
  assert.equal(await evaluate('document.activeElement.dataset.i+","+document.activeElement.dataset.j'), '2,1');
  await key('ArrowUp');
  assert.equal(await text('#cell-title'), 'D[1][1] = 1');
  await activate('#show-all');
  assert.equal(await evaluate('document.querySelectorAll("#alignment-columns li").length'), 2);
  const tieDownload = await downloadControl('#download-comparison', 'three-ties');
  const tieRecord = JSON.parse(tieDownload.bytes.toString('utf8'));
  assert.equal(tieRecord.distance, 2); assert.equal(tieRecord.optimalPathCount, '3');
  assert.deepEqual(tieRecord.matrix, [[0,1,2],[1,1,1],[2,1,2]]);
  assert.deepEqual(tieRecord.alignment.map(step=>step.operation), ['substitute','substitute']);
  assert.deepEqual(tieRecord.cells[2][2].candidates.map(candidate=>candidate.optimal), [true,true,true]);
  await capture('02-tie-inspection-desktop.png', '#matrix-title');
  passed('all three AB/BA ties survive inspection, arrow navigation and the complete physical JSON download');

  await loadExample('repeated'); await activate('#show-all');
  const repeated = JSON.parse((await downloadControl('#download-comparison', 'repeated-position')).bytes.toString('utf8'));
  assert.equal(repeated.optimalPathCount, '2');
  assert.deepEqual(repeated.alignment.map(step=>[step.operation,step.sourceIndex,step.targetIndex]), [['delete',0,null],['match',1,0]]);
  passed('the declared backward tie choice yields deletion of the first repeated source position');

  await input('#source', 'A'.repeat(25));
  assert.equal((await state()).downloadDisabled, true);
  assert.match(await text('#draft-state'), /previous comparison/);
  await activate('#compare');
  assert.equal(await evaluate('document.activeElement.id'), 'input-error');
  assert.equal(await evaluate('document.querySelector("#source").getAttribute("aria-invalid")'), 'true');
  assert.match(await text('#input-error'), /exceeds 24 Unicode code points/);
  assert.equal((await state()).source, 'A'.repeat(25));
  assert.equal((await state()).distance, '1');
  assert.equal((await state()).downloadDisabled, true);
  assert.equal(await evaluate('document.querySelector("#download-course").disabled'), false);
  await input('#source', 'ABC'); await input('#target', 'AC'); await activate('#compare');
  assert.equal(await text('#distance'), '1');
  assert.equal(await evaluate('document.querySelector("#input-error").hidden'), true);
  assert.equal((await state()).downloadDisabled, false);
  passed('oversized drafts remain visible, focus an explicit refusal, retain the previous table and block stale comparison download until recovery');

  await input('#source', ''); await input('#target', ''); await activate('#compare');
  assert.equal(await text('#distance'), '0'); assert.equal(await text('#path-count'), '1');
  assert.equal(await evaluate('document.querySelectorAll("#prefix-matrix button").length'), 1);
  assert.equal(await evaluate('document.querySelector("#next-step").disabled'), true);
  assert.equal(await evaluate('document.querySelector("#show-all").disabled'), true);
  const empty = JSON.parse((await downloadControl('#download-comparison', 'empty')).bytes.toString('utf8'));
  assert.deepEqual(empty.matrix, [[0]]); assert.deepEqual(empty.alignment, []);
  passed('empty/empty is a real zero-cost result with one empty path, no fabricated step and an exact export');

  await loadExample('accents'); await activate('#show-all');
  const accent = JSON.parse((await downloadControl('#download-comparison', 'combining-accent')).bytes.toString('utf8'));
  assert.equal(accent.distance, 2); assert.equal(accent.optimalPathCount, '2');
  assert.deepEqual(accent.targetPoints.map(point=>point.codePointAt(0)), [0x65,0x301]);
  assert.deepEqual(accent.alignment.map(step=>[step.operation,step.sourceIndex,step.targetIndex]), [['insert',null,0],['substitute',0,1]]);
  assert.match(await text('#alignment-columns'), /U\+0301/);
  await loadExample('emoji'); await activate('#show-all');
  assert.equal(await text('#lengths'), '3 → 1'); assert.equal(await text('#distance'), '2');
  assert.match(await text('#alignment-columns'), /zero width joiner/);
  assert.match(await text('#alignment-columns'), /U\+1F52C/);
  passed('decomposed accents and joined emoji remain literal code-point problems with visible indexed labels');

  await input('#source', '😀'.repeat(24)); await input('#target', ''); await activate('#compare');
  assert.equal(await text('#lengths'), '24 → 0'); assert.equal(await text('#distance'), '24');
  assert.equal(await evaluate('document.querySelectorAll("#prefix-matrix button").length'), 25);
  await input('#source', '<b>é😀\n A'); await input('#target', '<b>é😀 A'); await activate('#compare'); await activate('#show-all');
  assert.equal(await text('#distance'), '1');
  assert.equal(await evaluate('document.querySelector("#applied-source b")===null'), true);
  assert.equal(await text('#applied-source'), JSON.stringify('<b>é😀\n A'));
  const literal = JSON.parse((await downloadControl('#download-comparison', 'literal-markup-whitespace')).bytes.toString('utf8'));
  assert.equal(literal.source, '<b>é😀\n A'); assert.equal(literal.target, '<b>é😀 A');
  assert.equal(literal.distance, 1);
  assert.match(await text('#alignment-columns'), /line feed/);
  const afterCourse = await downloadControl('#download-course', 'course-after-edits');
  assert.deepEqual(afterCourse.bytes, firstCourse.bytes);
  passed('24 supplementary code points are admitted and literal markup/line feeds cannot change the DOM or fixed course bytes');

  await command('Emulation.setDeviceMetricsOverride', {width:320,height:844,deviceScaleFactor:1,mobile:false});
  assert.equal(await evaluate('document.documentElement.scrollWidth>innerWidth'), false);
  const geometry=await evaluate('({page:document.documentElement.scrollWidth,width:innerWidth,matrix:[document.querySelector(".matrix-scroll").clientWidth,document.querySelector(".matrix-scroll").scrollWidth],inputs:[...document.querySelectorAll("textarea")].map(e=>({width:e.getBoundingClientRect().width,height:e.getBoundingClientRect().height})),buttons:[...document.querySelectorAll("#previous-step,#next-step,#show-all")].map(e=>e.getBoundingClientRect().height)})');
  assert.ok(geometry.matrix[1]>geometry.matrix[0]);assert.ok(geometry.inputs.every(item=>item.width>100&&item.height>=44));assert.ok(geometry.buttons.every(value=>value>=44));
  report.compactGeometry=geometry;
  await capture('03-literal-compact.png', '#matrix-title');
  await command('Page.reload', {ignoreCache:true});
  await waitFor(()=>evaluate('document.querySelector("#source")?.value==="KITTEN"'), 'tab-only comparison reset');
  assert.equal(await text('#distance'), '3');
  passed('320px layout keeps table scrolling local and reload starts a fresh tab-only comparison');

  await command('Emulation.setDeviceMetricsOverride',{width:1360,height:1100,deviceScaleFactor:1,mobile:false});
  await command('Page.navigate',{url:pathToFileURL(join(project,'demo.html')).href});
  await waitFor(()=>evaluate('document.readyState==="complete"&&!!document.querySelector("#deck-file")'), 'unchanged standalone learner');
  const {root:documentRoot}=await command('DOM.getDocument',{depth:0});
  const {nodeId}=await command('DOM.querySelector',{nodeId:documentRoot.nodeId,selector:'#deck-file'});
  await command('DOM.setFileInputFiles',{nodeId,files:[afterCourse.file]});
  await waitFor(()=>evaluate('!document.querySelector("#deck-preview").hidden'), 'actual downloaded course preview');
  const deck=JSON.parse(afterCourse.bytes.toString('utf8'));
  assert.equal(await text('#deck-preview-title'),deck.title);
  assert.match(await text('.deck-preview-count'),/14 questions · 4 concepts/);
  assert.equal(await text('#step-count'),'0 / 6');
  await activate('#start-deck');
  assert.equal(await text('#step-count'),'0 / 14');
  await activate('#start-button');
  report.firstSession=[];
  for(let index=0;index<14;index++){
    const prompt=await text('#session-content h2'), item=deck.items.find(item=>item.prompt===prompt);
    assert.ok(item,'A displayed native learner question belongs to the downloaded course.');
    const choice=[0,5,9].includes(index)?(item.answer+1)%item.options.length:item.answer;
    await activate('[data-choice="'+choice+'"]');
    assert.ok((await text('#feedback-slot')).includes(item.explanation));
    assert.ok((await text('#feedback-slot')).includes(item.transfer));
    report.firstSession.push({index,item:item.id,choice,correct:choice===item.answer,prompt});
    await activate('#next-button');
  }
  assert.match(await text('#first-try-summary'),/11 of 14/);
  assert.equal(await evaluate('document.querySelectorAll(".review-item").length'),14);
  const mastery=await evaluate('[...document.querySelectorAll(".mastery-row output")].map(e=>e.textContent)');
  await activate('.review-item summary');
  const reflection='A gap consumes only one side. <b>literal</b> é 😀\nI will inspect prefixes before choosing an edit.';
  const application='Compare code points explicitly; the same glyph can have different representations.';
  await input('#reflection-0',reflection);await input('#application-reflection',application);
  await activate('#practice-button');
  report.practice=[];
  for(let index=0;index<3;index++){
    const prompt=await text('#session-content h2'), item=deck.items.find(item=>item.prompt===prompt);
    assert.ok(item);
    await activate('[data-practice-choice="'+item.answer+'"]');
    report.practice.push({item:item.id,choice:item.answer});
    await activate('#practice-next');
  }
  assert.match(await text('#practice-status'),/3 of 3 correctly on retry/);
  assert.match(await text('#first-try-summary'),/11 of 14/);
  assert.deepEqual(await evaluate('[...document.querySelectorAll(".mastery-row output")].map(e=>e.textContent)'),mastery);
  assert.equal(await evaluate('document.querySelector("#reflection-0").value'),reflection);
  assert.equal(await evaluate('document.querySelector("#application-reflection").value'),application);
  const notes=await downloadControl('#save-notes-button','study-notes');
  const noteText=notes.bytes.toString('utf8');
  assert.match(noteText,/11 of 14 connections correct on the first try/);
  assert.match(noteText,/Complete: 3 of 3 practice answers recorded; 3 correct on retry/);
  assert.ok(noteText.includes(deck.attribution)&&noteText.includes(application)&&noteText.includes('<b>literal</b> é 😀'));
  assert.ok(deck.items.every(item=>noteText.includes(item.prompt)&&noteText.includes(item.explanation)));
  await capture('04-unchanged-learner-review.png','#first-try-summary');
  passed('the physically downloaded course completes unchanged preview/start, 14 native questions, separate three-item practice, literal reflections and complete study-note download');

  assert.deepEqual(report.pageErrors,[]);
  assert.deepEqual(report.requests.filter(url=>/^(https?|wss?):/i.test(url)),[]);
  assert.deepEqual(await pins(),report.sourceSha256);
  passed('all watched source bytes are unchanged and both direct-file product pages make no external requests or runtime exceptions');
  report.status='passed';
} catch (error) {
  report.status = 'failed'; report.error = error.stack || String(error); process.exitCode = 1;
  if (socket && sessionId) {
    try { report.failureState = await state(); await capture('failure.png'); }
    catch (captureError) { report.captureError = String(captureError); }
  }
  console.error(report.error);
} finally {
  report.finished = new Date().toISOString();
  try {
    report.sourceAfter = await pins();
    report.sourceUnchanged = JSON.stringify(report.sourceAfter) === JSON.stringify(report.sourceSha256);
    await writeFile(join(output, 'browser.log'), browserLog, {flag: 'wx'});
    await writeFile(join(output, 'receipt.json'), JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
  } catch (error) {
    process.exitCode = 1; console.error('Could not preserve browser evidence: ' + String(error));
  } finally {
    if (socket) { try { await command('Browser.close', {}, false); } catch {} socket.close(); }
    if (browser && browser.exitCode === null) { browser.kill(); await pause(300); }
    for (const entry of pending.values()) { clearTimeout(entry.timer); entry.reject(new Error('Browser check finished.')); }
    pending.clear();
    await rm(profile, {recursive: true, force: true});
  }
  console.log(JSON.stringify({status: report.status, checks: report.checks.length, output}));
}
