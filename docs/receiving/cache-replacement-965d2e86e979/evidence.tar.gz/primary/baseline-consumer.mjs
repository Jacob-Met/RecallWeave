import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const source = new URL('../source/', import.meta.url);
const { parseDeck } = await import(new URL('src/deck.mjs', source));
const { draftFromDeck, checkDraft } = await import(new URL('src/deck-author.mjs', source));
const results = [];
for (const path of ['data/deck.json', 'courses/binary-search.json']) {
 const bytes = readFileSync(new URL(path, source)); const deck = parseDeck(bytes.toString('utf8'));
 const draft = checkDraft(draftFromDeck(deck)); assert.equal(draft.ok, true); assert.deepEqual(draft.deck, deck);
 results.push({ path, title: deck.title, questions: deck.items.length, concepts: deck.concepts.length, rawBytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), nativeParseAndAuthorRoundTrip: true });
}
assert.equal(results[1].questions, 12);
console.log(JSON.stringify({ node: process.version, originalCourses: results, originalConsumerPositive: true, newCacheCourseOrExplorerPresent: false, newCapabilityAbsenceIsInventoryEvidence: true }, null, 2));
