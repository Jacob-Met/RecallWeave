import fs from "node:fs/promises";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import {pathToFileURL} from "node:url";
const root="/home/jacob/stable-matching-independent-integration-81ba1ed0179c";
const source="/home/jacob/recall-stable-matching-81ba1ed0179c/source/src/stable-matching.mjs";
const hash=x=>crypto.createHash("sha256").update(x).digest("hex");
const frozen=await fs.readFile(root+"/expectations-frozen.json");
assert.equal(hash(frozen),"23fda0db8d80359c0dcbb1b1cc7006cc291f3f54bb697ae12fe902cae8dd89bf");
const sourceBefore=hash(await fs.readFile(source));
assert.equal(sourceBefore,"53e80279fcca73a348714bf974548bb81e76b888e3a0945099fcccb9107bd5ee");
const expected=JSON.parse(frozen),producer=await import(pathToFileURL(source)),checks=[],failures=[],received=[];
const profile=(p,side)=>({leftPreferences:structuredClone(p.leftPreferences),rightPreferences:structuredClone(p.rightPreferences),proposingSide:side});
function frozenDeep(x){if(x&&typeof x==="object"){assert.ok(Object.isFrozen(x));Object.values(x).forEach(frozenDeep);}}
function inspection(row){
 return {leftMatching:row.leftMatching,rightMatching:row.rightMatching,leftRanks:row.leftRanks,rightRanks:row.rightRanks,
 blockingPairs:row.blockingPairs.map(b=>({left:b.left,right:b.right,leftCurrentPartner:b.leftCurrent,rightCurrentPartner:b.rightCurrent,leftCurrentRank:b.leftCurrentRank,leftAlternativeRank:b.leftCandidateRank,rightCurrentRank:b.rightCurrentRank,rightAlternativeRank:b.rightCandidateRank})),stable:row.stable};
}
function test(name,fn){try{fn();checks.push(name);}catch(e){failures.push({name,error:String(e.stack??e)});}}
for(const p of expected.profiles)for(const side of ["left","right"])test(p.id+" / "+side,()=>{
 const input=profile(p,side),before=structuredClone(input),trace=producer.traceStableMatching(input),n=p.leftPreferences.length;
 const all=p.completeMatchings.map(inspection);
 assert.deepEqual(producer.listCompleteMatchings(input),all);
 for(const row of all)assert.deepEqual(producer.inspectMatching(input,row.leftMatching),row);
 assert.deepEqual(trace.profile,before);assert.equal(trace.size,n);
 assert.deepEqual(trace.matchings,all);
 const selected=p[side+"ProposingFinal"];
 assert.deepEqual(trace.final,all.find(x=>JSON.stringify(x.leftMatching)===JSON.stringify(selected)));
 assert.deepEqual(trace.stableMatchingIndices,all.flatMap((x,i)=>x.stable?[i]:[]));
 assert.deepEqual(trace.proposerBestRanks,p[side==="left"?"bestLeftRanks":"bestRightRanks"]);assert.equal(trace.proposerOptimal,true);
 assert.equal(trace.states.length,trace.proposalCount+1);assert.ok(trace.proposalCount<=n*n);
 assert.equal(trace.states[0].action,null);assert.deepEqual(trace.states[0].leftMatching,Array(n).fill(null));
 assert.deepEqual(trace.states[0].rightMatching,Array(n).fill(null));assert.deepEqual(trace.states[0].nextChoiceIndices,Array(n).fill(0));
 const proposals=new Set(),best=Array(n).fill(null),cursors=Array(n).fill(0);
 const proposerPrefs=side==="left"?p.leftPreferences:p.rightPreferences,receiverPrefs=side==="left"?p.rightPreferences:p.leftPreferences;
 trace.states.forEach((state,i)=>{
  assert.equal(state.step,i);
  assert.equal(new Set(state.leftMatching.filter(x=>x!==null)).size,state.leftMatching.filter(x=>x!==null).length);
  assert.deepEqual(state.rightMatching,Array.from({length:n},(_,j)=>state.leftMatching.includes(j)?state.leftMatching.indexOf(j):null));
  const proposerMatching=side==="left"?state.leftMatching:state.rightMatching;
  assert.deepEqual([...state.freeProposers].sort((a,b)=>a-b),proposerMatching.flatMap((x,j)=>x===null?[j]:[]));
  if(i){
   const a=state.action,previous=trace.states[i-1];
   const free=side==="left"?previous.leftMatching:previous.rightMatching;
   assert.equal(a.proposerIndex,free.findIndex(x=>x===null));
   assert.equal(a.receiverIndex,proposerPrefs[a.proposerIndex][cursors[a.proposerIndex]]);
   const key=a.proposerIndex+"/"+a.receiverIndex;assert.ok(!proposals.has(key));proposals.add(key);cursors[a.proposerIndex]++;
   const prior=best[a.receiverIndex];
   if(prior===null||receiverPrefs[a.receiverIndex].indexOf(a.proposerIndex)<receiverPrefs[a.receiverIndex].indexOf(prior))best[a.receiverIndex]=a.proposerIndex;
   const held=side==="left"?state.rightMatching:state.leftMatching;
   assert.deepEqual(held,best);assert.deepEqual(state.nextChoiceIndices,cursors);
  }
 });
 const hand=expected.handTraces.find(x=>x.profile===p.id&&x.side===side);
 if(hand){
  assert.equal(trace.proposalCount,hand.proposalCount);
  hand.steps.forEach(([proposer,receiver,decision,displaced,matching],i)=>{
   const state=trace.states[i+1],previous=trace.states[i];
   const previousProposer=side==="left"?previous.rightMatching[receiver]:previous.leftMatching[receiver];
   assert.deepEqual(state.leftMatching,matching);
   assert.deepEqual(state.action,{proposerIndex:proposer,receiverIndex:receiver,decision,previousProposerIndex:previousProposer,displacedProposerIndex:displaced,
    proposerChoiceRank:proposerPrefs[proposer].indexOf(receiver)+1,receiverRankOfProposal:receiverPrefs[receiver].indexOf(proposer)+1,
    receiverRankOfPrevious:previousProposer===null?null:receiverPrefs[receiver].indexOf(previousProposer)+1});
  });
 }
 assert.deepEqual(input,before);frozenDeep(trace);
 input.leftPreferences[0].reverse();input.rightPreferences[0].reverse();assert.deepEqual(trace.profile,before);
 received.push({id:p.id,side,trace});
});
test("frozen strict profile admission controls",()=>{
 const base=profile(expected.profiles[1],"left"),cases=[null,[],{}, {...base,leftPreferences:undefined},{...base,rightPreferences:undefined},
 {...base,leftPreferences:[],rightPreferences:[]},{...base,leftPreferences:Array.from({length:5},()=>[0,1,2,3,4]),rightPreferences:Array.from({length:5},()=>[0,1,2,3,4])},
 {...base,rightPreferences:[[0]]},{...base,leftPreferences:[[0,1]]},{...base,leftPreferences:[[0,0],[1,0]]},
 {...base,leftPreferences:[[0],[1,0]]},{...base,leftPreferences:[[0,1,2],[1,0]]}];
 for(const value of [-1,2,.5,"0",true,NaN,Infinity])cases.push({...base,leftPreferences:[[value,1],[1,0]]});
 const sparse=[,1];cases.push({...base,leftPreferences:[sparse,[1,0]]});
 const missingRow=Array(2);missingRow[0]=[0,1];cases.push({...base,leftPreferences:missingRow});
 for(const proposingSide of [undefined,"LEFT","other"])cases.push({...base,proposingSide});
 for(const input of cases)assert.throws(()=>producer.traceStableMatching(input));
});
test("complete matching admission refuses malformed permutations",()=>{
 const p=profile(expected.profiles[1],"left");
 for(const matching of [null,[0,0],[0],[0,1,2],[,1],[-1,1],[2,0],["0",1],[true,1],[NaN,1],[Infinity,1]])assert.throws(()=>producer.inspectMatching(p,matching));
});
const after=hash(await fs.readFile(source));assert.equal(after,sourceBefore);assert.equal(hash(await fs.readFile(root+"/expectations-frozen.json")),hash(frozen));
await fs.writeFile(root+"/received-candidate.json",JSON.stringify(received,null,2)+"\n");
const receipt={schema:"hamon.independent_consumer_receiving.v1",at:new Date().toISOString(),node:process.version,success:failures.length===0,source,source_sha256:sourceBefore,source_unchanged:true,frozen_expectations_sha256:hash(frozen),checks,failures,scope:"Exact five-profile/39-permutation inspection, both proposer sides, seven manually frozen traces, partial-state invariants, strict admission and detached frozen results. No author tests or course read; no browser/full-suite claim."};
await fs.writeFile(root+"/consumer-receiving.json",JSON.stringify(receipt,null,2)+"\n");
console.log(JSON.stringify(receipt));if(failures.length)process.exitCode=1;
