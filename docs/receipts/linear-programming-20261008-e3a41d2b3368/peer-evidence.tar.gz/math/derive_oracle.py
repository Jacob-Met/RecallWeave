from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import datetime,hashlib,json,os
root=Path(__file__).resolve().parent
assert not (root/"FRACTION-ORACLE.json").exists(),"oracle exists; inspect before replaying"
v=os.statvfs(root);assert v.f_bavail*v.f_frsize>16*1024*1024,"capacity refusal"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/"HAND-CASES.json")=="ae370ccedb847728c2ef7311c81f26c0b643e9c5ac50459d28d5e05eb4773781"
def fmt(f):return str(F(f))
def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
def hull(points):
 if len(points)<=1:return points[:]
 lower=[];upper=[]
 for p in points:
  while len(lower)>=2 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
  lower.append(p)
 for p in reversed(points):
  while len(upper)>=2 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
  upper.append(p)
 return lower[:-1]+upper[:-1]
def derive(problem):
 b=problem["bounds"];obj=problem["objective"]
 boundaries=[("x-min",-1,0,-b["xmin"]),("x-max",1,0,b["xmax"]),("y-min",0,-1,-b["ymin"]),("y-max",0,1,b["ymax"])]
 boundaries += [(f"C{i+1}",c["a"],c["b"],c["c"]) for i,c in enumerate(problem["constraints"])]
 coordinates={};pairs=[]
 for left,right in combinations(boundaries,2):
  aid,a,b,c=left;bid,d,e,f=right
  pair={"boundaries":[aid,bid]}
  if (a,b)==(0,0) or (d,e)==(0,0):
   pair["kind"]="zero-normal"
  elif a*e-b*d==0:
   pair["kind"]="coincident" if a*f==d*c and b*f==e*c else "parallel"
  else:
   determinant=a*e-b*d
   x,y=F(c*e-b*f,determinant),F(a*f-c*d,determinant)
   violations=[id for id,aa,bb,cc in boundaries if aa*x+bb*y>cc]
   pair.update({"kind":"intersection","coordinates":[fmt(x),fmt(y)],"feasible":not violations,"violated":violations})
   if not violations:coordinates.setdefault((x,y),[]).append([aid,bid])
  pairs.append(pair)
 points=sorted(coordinates)
 vertices=[]
 for i,(x,y) in enumerate(points):
  slacks={id:fmt(cc-aa*x-bb*y) for id,aa,bb,cc in boundaries}
  active=[id for id,s in slacks.items() if F(s)==0]
  vertices.append({"id":f"V{i+1}","x":fmt(x),"y":fmt(y),"objective":fmt(obj["p"]*x+obj["q"]*y),"slacks":slacks,"active":active,"pairs":coordinates[(x,y)]})
 boundary=hull(points)
 kind="empty" if not boundary else "point" if len(boundary)==1 else "segment" if len(boundary)==2 else "polygon"
 optimum=None
 if points:
  values=[F(v["objective"]) for v in vertices]
  best=(min if obj["sense"]=="min" else max)(values)
  indices=[i for i,value in enumerate(values) if value==best]
  whole=len(indices)==len(points)
  opt_kind="point" if len(indices)==1 else "region" if whole else "segment"
  optimum={"value":fmt(best),"vertices":[[fmt(points[i][0]),fmt(points[i][1])] for i in indices],"kind":opt_kind,"wholeRegion":whole}
 return {"boundaries":[{"id":id,"a":a,"b":b,"c":c} for id,a,b,c in boundaries],"pairs":pairs,"vertices":vertices,"region":kind,"boundary":[[fmt(x),fmt(y)] for x,y in boundary],"optimum":optimum}
cases=json.loads((root/"HAND-CASES.json").read_text())
results=[]
for case in cases:
 actual=derive(case["problem"])
 compact={"vertices":[[v["x"],v["y"]] for v in actual["vertices"]],"region":actual["region"],"optimum":actual["optimum"]}
 expected=case["expected"]
 assert compact==expected,(case["id"],compact,expected)
 m=4+len(case["problem"]["constraints"])
 assert len(actual["pairs"])==m*(m-1)//2
 results.append({"id":case["id"],"status":"hand_expected_matches_fraction_derivation","result":actual})
out={"schema":"e3.recall-lp.fraction-oracle/1","created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"status":"pass","cases":results,"hand_cases_sha256":sha(root/"HAND-CASES.json"),"generator_sha256":sha(Path(__file__)),"candidate_source_read":False,"author_tests_read":False,"scope":"independent rational derivation cross-checks already-committed hand values; no candidate import/execution"}
p=root/"FRACTION-ORACLE.json"
with p.open("x") as f:json.dump(out,f,indent=2,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
print(json.dumps({"status":"pass","cases":len(results),"pairs":sum(len(r["result"]["pairs"]) for r in results),"oracle_sha256":sha(p),"oracle_bytes":p.stat().st_size,"generator_sha256":sha(Path(__file__))}))
