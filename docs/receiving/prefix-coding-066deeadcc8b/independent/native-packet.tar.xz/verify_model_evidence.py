#!/usr/bin/env python3
"""Recompute preserved model results without importing or executing the product."""
from pathlib import Path
import gzip, hashlib, json, importlib.util, sys, math, copy

def need(ok, message):
    if not ok: raise ValueError(message)

def sha(b): return hashlib.sha256(b).hexdigest()

def js_numbers(value):
    if isinstance(value,float) and value.is_integer(): return int(value)
    if isinstance(value,list): return [js_numbers(x) for x in value]
    if isinstance(value,dict): return {k:js_numbers(v) for k,v in value.items()}
    return value

def js_json(value):
    return (json.dumps(js_numbers(value),ensure_ascii=False,indent=2)+'\n').encode()

def canonical_model(e):
    acc=0; steps=[]
    for i,s in enumerate(e['merges']):
        cost=e['nodes'][s['parent']]['count']; acc+=cost
        steps.append(dict(index=i+1,**s,addedCost=cost,accumulatedCost=acc))
    return {'rows':e['symbols'],
      'nodes':[dict(id=n['id'],weight=n['count'],symbol=n['symbol'],left=n['left'],right=n['right']) for n in e['nodes']],
      'root':e['root'],'steps':steps,
      'codebook':[dict(symbol=c['symbol'],count=c['count'],code=c['bits'],length=c['length'],cost=c['count']*c['length']) for c in e['codebook']],
      'totals':dict(totalCount=e['totalCount'],payloadBits=e['weightedBits'],fixedWidth=e['fixedWidth'],
         fixedPayloadBits=e['fixedBits'],averageBits=e['averageBits'],savedPayloadBits=e['fixedBits']-e['weightedBits'],mergeWeightSum=e['weightedBits'])}

def message(model,symbols):
    codes={x['symbol']:x['code'] for x in model['codebook']}; bits=''; segments=[]
    for symbol in symbols:
        code=codes[symbol]; start=len(bits);bits+=code
        segments.append(dict(symbol=symbol,code=code,start=start,end=len(bits)))
    return dict(bits=bits,symbols=symbols,segments=segments)

def verify_model_record(report, fixture):
    need(report.get('harnessError') is None,'model execution error')
    need(len(report['cases'])==1101 and len(report['invalidModels'])==27 and len(report['protocolCases'])==23,'model cohort counts')
    need(report['passedChecks']==6779 and report['failedChecks']==0 and len(report['checks'])==6779,'model check counts')
    need(all(x['ok'] is True for x in report['checks']),'unsuccessful planned model check')
    need(len({x['name'] for x in report['checks']})==6779,'duplicate model checks')
    need(report['sourceBeforeSha256']==report['sourceAfterSha256'],'model source movement')
    seen=set()
    for actual,item in zip(report['cases'],fixture['cases']):
        need(actual['name']==item['name'] and actual['kind']==item['kind'] and actual['input']==item['rows'],'cohort identity')
        need(actual['name'] not in seen,'duplicate model cohort');seen.add(actual['name'])
        expected=canonical_model(item['expected'])
        need(actual['actual']==expected,'complete model differs from exhaustive witness: '+item['name'])
        codes=[c['code'] for c in expected['codebook']]
        need(all(i==j or not b.startswith(a) for i,a in enumerate(codes) for j,b in enumerate(codes)),'prefix collision')
        need(sum(c['count']*len(c['code']) for c in expected['codebook'])==expected['totals']['payloadBits'],'weighted arithmetic')
        labels=[r['symbol'] for r in expected['rows']]
        wanted=message(expected,labels+labels[::-1]+labels[-1:])
        need(actual['encoded']==wanted and actual['decoded']==wanted,'actual message/trace')
        example={'format':'recallweave.prefix-coding/1','model':expected,'inspection':{'step':len(expected['steps'])},'decoding':wanted}
        data=js_json(example)
        need(actual['serializedBytes']==len(data) and actual['serializedSha256']==sha(data),'actual complete export bytes: '+item['name'])
    names=['validateRows','buildCode','encodeSymbols','decodeBits','serializeExample']
    for actual,item in zip(report['invalidModels'],fixture['invalid_models']):
        need(actual['name']==item['name'] and actual['sourceFixture']==item,'invalid input identity')
        need(list(actual['refusals'])==names,'five API refusal boundaries')
        for outcome in actual['refusals'].values():
            need(isinstance(outcome.get('name'),str) and bool(outcome.get('message')),'missing actual refusal')
    protocols=report['protocolCases']
    need(len({p['name'] for p in protocols})==23,'protocol identities')
    need(protocols[0]['name']=='empty-encoder' and protocols[0]['result']=={'bits':'','symbols':[],'segments':[]},'empty encode')
    need(protocols[1]['name']=='empty-decoder' and protocols[1]['result']=={'bits':'','symbols':[],'segments':[]},'empty decode')
    need(protocols[2]['name']=='512-symbol-encoder-boundary' and protocols[2]['result']['symbols']==512,'encode limit')
    need(protocols[3]['name']=='4096-bit-decoder-boundary' and protocols[3]['result']=={'bits':4096,'symbols':4096},'decode limit')
    for p in protocols[4:]: need(bool(p['result']['message']) and bool(p['result']['name']),'protocol refusal')
    negatives=report['negativeControls']
    need(len(negatives)==2 and all(n['rejected'] for n in negatives),'model controlled negatives')
    need(negatives[0]['claimedCost']==11 and negatives[0]['optimalCost']==9 and 'exhaustive full-tree minimum' in negatives[0]['error']['message'],'nonoptimal code rejected for cost')
    need('not prefix-free' in negatives[1]['error']['message'],'collision rejection')
    return {'positive_models':len(seen),'full_exports_recomputed':len(seen),'invalid_models':27,'API_refusals':135,'protocol_cases':23,'checks':6779,'controlled_negatives':2}

def main():
    root=Path(sys.argv[1]); report_path=Path(sys.argv[2]); output=Path(sys.argv[3])
    raw=gzip.decompress((root/'oracle-fixtures.json.gz').read_bytes())
    need(sha(raw)=='c8b7e50a7c90e0bada790b349862042405e513dc21e09aaadf2a080a777ee913','frozen oracle fixture')
    need(sha((root/'oracle.py').read_bytes())=='01b04c69436f9e6d18c7e408faeaf47a98b4d413f8ac5b80857ad4280c86ec5f','frozen independent oracle source')
    spec=importlib.util.spec_from_file_location('review_oracle',root/'oracle.py');oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
    fixture=json.loads(raw)
    regenerated=(json.dumps(oracle.make_fixture(),ensure_ascii=True,separators=(',',':'))+'\n').encode()
    need(regenerated==raw,'exhaustive fixture regeneration')
    report=json.loads(report_path.read_bytes()); outcome=verify_model_record(report,fixture)
    # Repair accounting in an in-memory altered record: compare raw mathematical
    # result anyway, rather than trusting the saved checks or summary.
    altered=copy.deepcopy(report)
    altered['cases'][0]['actual']['totals']['payloadBits']+=1
    rejected=False
    try: verify_model_record(altered,fixture)
    except ValueError as exc:
        need('complete model differs' in str(exc),'semantic negative rejected at unrelated gate')
        rejected=True
    need(rejected,'semantic negative was accepted')
    value={'schema':'recall-prefix-model-raw-verification-v1','source_sha256':report['sourceBeforeSha256'],
       'report_sha256':sha(report_path.read_bytes()),'oracle_fixture_sha256':sha(raw),'oracle_regenerated_exactly':True,
       'recomputed':outcome,'altered_raw_payload_rejected':True,'product_execution':False}
    output.write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps(value))
if __name__=='__main__':main()
