GENETIC LINKAGE — OFFLINE RECALLWEAVE LESSON KIT

1. Extract the entire ZIP. Keep demo.html beside the courses/ directory.
   Open START-HERE.html from the extracted folder. Do not open files from
   inside a ZIP preview.

2. For the lab, open courses/genetic-linkage-lab.html with JavaScript
   enabled. Choose chromosome phase and a whole recombinant-gamete
   percentage from 0 through 50, then choose Apply cross. Editing retires
   the prior result; reloading resets the lab. Download an observation
   explicitly to retain the applied cross.

3. For the lesson, open demo.html. The learner initially has its own
   built-in lesson; no course is automatically imported. Choose the local
   courses/genetic-linkage.json file using the learner's JSON chooser.
   Verify the preview title "Linked genes: same genotype, different
   gametes", 12 questions and 4 concepts. Choose Start this deck.

4. Previewing does not replace a lesson. Starting the deck replaces the
   current lesson and its practice context. After answering, inspect the
   review, try a separate practice round and download study notes to keep
   first attempts, practice and written reflections. Use the learner's
   own explicit save/download controls to retain your work.

5. The lab's course download equals the included genetic-linkage.json.
   Its genetic-linkage-observation.json is a different format: an exact
   applied cross record, not an importable course.

6. courses/genetic-linkage.md is the worked guide. Open Markdown files in
   a text editor or Markdown viewer if the browser does not render them.
   The earlier Mendelian lab, its separate 12-question JSON course and
   guide are also included under courses/mendelian-inheritance*.
   Import that course explicitly if you want the introductory lesson.

The labs and learner require JavaScript. No installation, account or
network service is needed for the included files. Scientific reference
links in the guides are external and optional. Developer build/test
commands in the guides require the full repository; they are not needed
to use this kit.

Scientific scope: ideal hypothetical diploid plants, two autosomal loci,
fixed AaBb x aabb testcross, equal class/allele assumptions. Probabilities
are not quotas for finite samples. Recombinant-gamete fraction is not a
crossover-event count or physical distance. A 50% fraction does not locate
the genes on chromosomes.

SOURCE-MANIFEST.json records exact asset origins, byte hashes and the
course license/attribution strings. SHA256SUMS covers all ten other
members. Checksums detect changes; they are not authenticated signatures.
Original course text is CC0-1.0 as declared in each course; referenced
sources retain their terms. This kit does not relicense application code.

This is a static package of frozen assets. Archive membership, exact
source bytes and local links were checked. Packaging is not an additional
browser run, installed application, Windows execution claim or evidence
of learning effectiveness.
