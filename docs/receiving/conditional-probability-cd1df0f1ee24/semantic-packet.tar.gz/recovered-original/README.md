# Conditional-probability lab: independent preimplementation contract

This packet freezes mathematical expectations and a receiving route before any new lab implementation or authored test was read. It is qualification preparation, not a product implementation or a passing product receipt.

## Frozen files

- `contract-v1.json`: semantics, UI/output obligations, authority, preserved scopes, current access limitation.
- `semantic-oracles-v1.json`:22finite tables ×16exact probability questions =352probability values, plus22independence values.
- `generate-oracles-v1.py`: independent standard-library Fraction generator. It imports no application code.
- `learner-route-v1.json`: unchanged probability-course identity, current learner pins and one fixed actual import/review/practice route.
- `manifest-v1.json`: byte sizes, SHA-256 and Git blob identities of this freeze.

The oracle JSON is a receiver-owned fixture representation. It does not prescribe a public application function, DOM selector or export schema.

## Cell meaning and exactness

Cell order is **A∩B, A∩notB, notA∩B, neither**. For counts x,y,z,w, total N=x+y+z+w; A=x+y; B=x+z. Every query contains explicit numerator/denominator cell indices. Defined probabilities are reduced `numerator/denominator` strings. JSON null means mathematically undefined, never zero.

Defaults9,1,99,891 give P(A|B)=1/12, P(B|A)=9/10 and P(A)=1/100. The denominator identifies the conditioning population. A zero conditioning group makes only those conditionals undefined.

When N>0, independence is exactly x*N=(x+y)*(x+z), equivalently x*w=y*z. An empty or certain event can satisfy this definition even when a conditional is undefined. For N=0 there is no normalized finite distribution, so independence is undefined. The near-equality fixture889,890,890,891 yields3164840 versus3164841 and must remain dependent. Rounded displays cannot decide that identity.

The table describes fictional or supplied counts. Nothing in the receiving contract treats arithmetic independence as a causal or population inference.

## Native route and current limitation

The previously qualified native route is Mac0e3d582f, Node, installed headless Chromium and Puppeteer, with a new own profile/download directory. Its read-only status check returned offline; an earlier capacity check timed out. No lab implementation was supplied, no native lab tests ran, and no browser result is claimed.

Local storage is scarce. This first freeze contains only compact receiver inputs and provenance. Canvas's completed archive20701c97… remains unchanged. Existing probability course/guide, catalogs, learner/importer and BKT PR94 remain outside the production fence.

Count bounds/lexical details and lab API/selectors remain pending the author's public interface. A later additive adapter may map the frozen expectations to that interface; it must not replace mathematical expectations to fit the code.

## Reference

MIT18.05 Reading3, Jeremy Orloff and Jonathan Bloom:
https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/mit18_05_s22_class03-prep.pdf

Used for the nonzero conditioning denominator and formal joint-product definition. The fixtures and receiver are independently authored. Existing project/course identity is recorded as immutable GitHub source pins in the JSON files.
