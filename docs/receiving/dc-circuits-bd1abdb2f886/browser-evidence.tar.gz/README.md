# Independent DC explorer browser receiving

**Accepted:** final standalone lab SHA-256 `94dc6ea2c450bbbdd1f2ec3210c30948c0c8e9b5c974d7d1d728cb7547aee3c4`, with UI `2ea06bb70830b8d600c32c3d3192876f36aed9860fdea5d664bfe38e0f088f91`.

The independent semantic contract was frozen before candidate source inspection. Actual Chromium 153 opened the standalone HTML through `file://`; all interaction used browser text, pointer or keyboard events. Tables were read from visible text, not the model's internal values. No page HTTP request or page exception occurred in the tested paths, and every owned browser profile was removed.

## What the evidence establishes

The first full run qualified the initial numerical and interaction behavior: independently calculated 12 V / 100 Ω / 200 Ω series and parallel values, displayed current/voltage/power relationships, changed resistances and topology, equal/unequal presets, zero voltage, invalid edits clearing tables and the diagram, recovery, an actual exact-byte course download during invalid input, and the 390-pixel layout.

Source review and the preserved screenshots identified a real presentation defect: a compound path gave only the final current indicator an arrowhead. The author changed only two SVG string lines. Mechanical reversal of those splits restores both the original complete UI and standalone HTML to their original recorded hashes. Model, course, template and builder bytes are unchanged. The final focused run verifies two correctly directed series arrows and three parallel arrows, their disappearance at zero voltage, and the corrected desktop/mobile presentation.

The final keyboard run proves actual Tab/input/radio/Enter operation with visible focus and a trusted keydown → keypress → click sequence. Two separately completed browser CSV downloads at 6 V and 12 V have the correct, different unrounded values in all 13 columns. The real course download equals all 11,662 original JSON bytes. The final keyboard process exited zero and passed all four recorded checks.

There was no unnecessary repeat of unchanged numerical cases after the arrow-only source correction. Acceptance combines the specifically identified results below; it does not relabel an earlier failed process as a passing whole run.

## Run history and harness corrections

| Preserved run | Recorded result | Interpretation |
| --- | --- | --- |
| `v1/browser-report.json` | 12 checks passed, 3 failed; exit 1 | Original numerical/input/layout receiving. Its screenshots retain the missing arrowheads. CSV column binding omitted the actual R1/R2 header spelling; the first Enter helper omitted the normal text/keypress payload, so the keyboard download checks did not activate the buttons. |
| `v2-focused/browser-report.json` | 9 checks passed, 1 failed; exit 1 | The original CSV is independently validated from its actual saved bytes; final arrows, guide, layout and keyboard JSON pass. The second CSV actually completed, but reused an existing filename and the directory-name watcher missed it. |
| `v2-keyboard/browser-report.json` | 4 checks passed, 0 failed; exit 0 | Each download has its own owned destination. Both changed-value CSVs and the exact course file are preserved after actual completion. No assertion about their contents was relaxed. |

The original and corrected helpers and all three runners are retained. `harness-corrections.diff` shows the Enter-event change. `harness-history.json` records the header binding and per-download-directory corrections. Full browser events, raw logs, download witnesses and screenshots remain in their corresponding run directories.

## Visual review

The receiver visually inspected the original and final desktop parallel views and 390-pixel controls/series/parallel views. In v1, the source I and parallel I1 indicators lacked heads while I2 had one. In v2, the source arrows point right, the series return points left and both parallel branch arrows point down. Polarity, resistor labels, units, relationship text and tables remain readable. The page has no horizontal overflow at 390 pixels. Original and final images are included without modification.

## Source and guide boundary

`source/v1/` contains the original UI and HTML, reconstructed by reversing the two SVG splits and verified against the original frozen hashes and first browser report. The final HTML/UI and unchanged model/course/template/builder are also included. This construction is explicit in `source-composition.json`; it is not represented as a separately saved original filesystem snapshot.

The actual guide-open observation belongs to guide SHA-256 `9bb92cf5892a05238655f570b73f15e81017177a694ba828313d1a6562f1f245`. The author subsequently updated its learner-import usage paragraph. These browser receipts do not qualify that newer paragraph or the newly merged learner/importer. Another receiving lane owns that consumer workflow. The earlier guide's complete bytes were not copied into this archive; its observed URL, heading and hash remain in the raw report.

The proof covers this standalone explorer and its actual exported files. It does not claim a public deployment or another learner/importer run. The scripts preserve their original native paths and exact pins for audit; a replay elsewhere requires an explicit path adaptation while retaining the semantic assertions. The manifest binds every archived member except itself by byte size and SHA-256. Profiles and caches are excluded.

Receiver: `chatgpt-astra-bd1abdb2f886-20261008 / estate_production`.
