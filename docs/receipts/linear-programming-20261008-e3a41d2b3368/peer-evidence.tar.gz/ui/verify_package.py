import os, pathlib, json, hashlib, re, base64, subprocess, datetime
from html.parser import HTMLParser
P=pathlib.Path(__file__).resolve().parent
A=pathlib.Path('/home/jacob/hamon-universal-e3a41d2b3368-recall-linear-programming')
C=A/'candidate'
paths=['src/linear-programming-ui.mjs','courses/linear-programming-explorer.template.html','courses/linear-programming-explorer.html','tools/build-linear-programming.mjs','src/linear-programming.mjs','courses/linear-programming.json','courses/linear-programming.md','src/deck.mjs']
expected={'src/linear-programming-ui.mjs':'f6f8eb3729c49f52b6abb56ee14e358afb3bdb737f94ea6bc0bf64c9b0dc691a','courses/linear-programming-explorer.template.html':'ae6fe6991b77334b7ed0107ca35a9e8091a4115ca8cec762e5128c488f85578d','courses/linear-programming-explorer.html':'a0e64d648b19b0d3cea8fbf321cc318d811acfc7e376e5553ba41e7fcb2cb66f','tools/build-linear-programming.mjs':'b0adb7a1ffad90abef8e14ca5f9b30b8e0ab0078b20dde497711ebfef5391500','courses/linear-programming.md':'fa3a0f5a133189ef3a52cd933060245703185f2fcd69327207128dae06fe4e5d','src/deck.mjs':'621438c166ec4bfafd9d87c698a1d46cb1722f4fb92dcbb8d9f52fce682c338b'}
raw={name:(C/name).read_bytes() for name in paths}
sha=lambda b:hashlib.sha256(b).hexdigest()
for name,pin in expected.items(): assert sha(raw[name])==pin,name
text={name:data.decode('utf8') for name,data in raw.items()}
core=text['src/linear-programming.mjs'];ui=text['src/linear-programming-ui.mjs'];template=text['courses/linear-programming-explorer.template.html'];html=text['courses/linear-programming-explorer.html']
names=['LIMITS','validateProblem','parseProblem','problemFields','solveProblem','observationJSON','PRESETS']
assert re.findall(r'^export (?:function|const) (\w+)',core,re.M)==names
line='import { PRESETS, parseProblem, problemFields, solveProblem, observationJSON } from "./linear-programming.mjs";\n'
assert ui.startswith(line)
script='(() => {\nconst { '+', '.join(names)+' } = (() => {\n'+re.sub(r'^export (?=function|const)','',core,flags=re.M)+'\nreturn { '+', '.join(names)+' };\n})();\n'+ui[len(line):]+'\n})();\n'
assert not re.search(r'</script',script,re.I)
rebuilt=template
for marker,content in {'@@COURSE_BASE64@@':base64.b64encode(raw['courses/linear-programming.json']).decode(),'@@GUIDE_BASE64@@':base64.b64encode(raw['courses/linear-programming.md']).decode(),'@@SCRIPT@@':script}.items():
 assert rebuilt.count(marker)==1
 rebuilt=rebuilt.replace(marker,content)
assert rebuilt==html
class Doc(HTMLParser):
 def __init__(self):
  super().__init__();self.ids={};self.labels=[];self.scripts=[];self.active=None;self.loads=[];self.handlers=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:
   assert a['id'] not in self.ids,a['id'];self.ids[a['id']]={'tag':tag,**a}
  if tag=='label' and 'for' in a:self.labels.append(a['for'])
  if tag=='script':
   self.active={'attrs':a,'text':''};self.scripts.append(self.active)
  if (tag in ('script','img','iframe','audio','video','source') and 'src' in a) or (tag=='link' and a.get('rel')=='stylesheet'):self.loads.append((tag,a))
  self.handlers.extend((tag,k) for k in a if k.startswith('on'))
 def handle_endtag(self,tag):
  if tag=='script':self.active=None
 def handle_data(self,s):
  if self.active is not None:self.active['text']+=s
doc=Doc();doc.feed(html)
assert len(doc.scripts)==3 and not doc.loads and not doc.handlers
assert all(label in doc.ids for label in doc.labels)
assert doc.ids['plot']['role']=='img' and doc.ids['plot']['aria-labelledby']=='plot-title plot-description'
assert doc.ids['status']['role']=='status' and doc.ids['error']['role']=='alert'
for ident in set(re.findall(r'byId\("([^"]+)"\)',ui)):assert ident in doc.ids,ident
for ident,path in [('course-data','courses/linear-programming.json'),('guide-data','courses/linear-programming.md')]:
 s=next(x for x in doc.scripts if x['attrs'].get('id')==ident)
 assert base64.b64decode(s['text'].strip(),validate=True)==raw[path]
assert doc.scripts[-1]['text'].strip()==script.strip()
node='/usr/bin/node';env=dict(os.environ,NODE_DISABLE_COMPILE_CACHE='1')
commands=[]
r=subprocess.run([node,str(C/'tools/build-linear-programming.mjs'),'--check'],cwd=C,text=True,capture_output=True,timeout=20,env=env)
commands.append({'command':[node,'tools/build-linear-programming.mjs','--check'],'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,commands[-1]
js="""import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const [deckPath,htmlPath]=process.argv.slice(1);
const {parseDeck}=await import(pathToFileURL(deckPath));
const html=await readFile(htmlPath,'utf8');
const encoded=html.match(/<script id="course-data" type="application\\/octet-stream">([^<]+)<\\/script>/)[1];
const course=Buffer.from(encoded.trim(),'base64').toString('utf8');
const deck=parseDeck(course);
if(deck.items.length!==16 || !Object.isFrozen(deck))throw Error('Unexpected learner result');
console.log(JSON.stringify({format:deck.format,title:deck.title,items:deck.items.length,concepts:deck.concepts.length,frozen:Object.isFrozen(deck)}));
"""
r=subprocess.run([node,'--input-type=module','-e',js,str(C/'src/deck.mjs'),str(C/'courses/linear-programming-explorer.html')],text=True,capture_output=True,timeout=20,env=env)
commands.append({'command':'Node ESM: actual embedded course bytes through unchanged native parseDeck','exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,commands[-1]
for name,data in raw.items():assert (C/name).read_bytes()==data,name
before=(A/'baseline/tools/build-network-flow.mjs').read_bytes()
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pass':True,'source':[{'path':name,'sha256':sha(data),'bytes':len(data)} for name,data in raw.items()],'maintained_builder':{'path':str(A/'baseline/tools/build-network-flow.mjs'),'sha256':sha(before)},'embedded_source_exact':True,'embedded_course_and_guide_exact':True,'static_dom_ids':len(doc.ids),'explicit_labels':len(doc.labels),'automatic_resource_loads':doc.loads,'inline_event_handlers':doc.handlers,'commands':commands,'source_unchanged':True,'node':subprocess.check_output([node,'--version'],text=True).strip(),'scope':'Source and offline packaging/embedded consumer acceptance only. No browser, rendered, OS keyboard or download completion claim. No math or lesson test repetition. Original network-flow template/UI absent from retained baseline; original builder was inspected.'}
with (P/'PACKAGE-RESULT.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(receipt))
