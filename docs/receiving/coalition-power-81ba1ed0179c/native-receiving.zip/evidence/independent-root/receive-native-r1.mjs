import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {oracle,namedGames,exhaustiveGames} from './oracle-before-candidate.mjs';
const root=path.dirname(new URL(import.meta.url).pathname),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const coreBytes=fs.readFileSync(root+'/candidate/coalition-power-core.mjs');
assert.equal(coreBytes.length,3233);assert.equal(sha(coreBytes),'bfd11c80dd2a9f45061080a0beb12cd44431e9eccf34cd0579facf7cc48c74af');
const oracleBytes=fs.readFileSync(root+'/oracle-before-candidate.mjs'),expectationBytes=fs.readFileSync(root+'/expectations-before-candidate.json');
assert.equal(sha(oracleBytes),'e87865e4f3bd6da8f619a090796565b1a2333dd7cc5c657305de32e52db0e86d');
assert.equal(sha(expectationBytes),'a4a9346e3f46c84c3230eb4da7fb29abaa0a4bfee2b80761c2d83657e4ca3c1b');
const {analyzeGame}=await import('./candidate/coalition-power-core.mjs');
const out={schema:'hamon.coalition-power.independent-native-receiving/1',worker:'estate-81ba1ed0179c/root',startedAt:new Date().toISOString(),node:process.version,coreSha256:sha(coreBytes),oracleSha256:sha(oracleBytes),expectationsSha256:sha(expectationBytes),candidateBodyReadBeforeExecution:false,courseKeysReadBeforeFrozenAnswers:false,authorTestsReadOrRun:false,rootBrowserRuns:0,groups:[],named:[],refusals:[]};
function check(name,fn,target=out.groups){try{target.push({name,passed:true,...(fn()||{})});}catch(e){target.push({name,passed:false,error:String(e),stack:e.stack?.slice(0,3500)});}}
function fields(actual){assert.deepEqual(Object.keys(actual).sort(),['format','model','input','coalitions','players','summary','assumptions'].sort());const {assumptions,...rest}=actual;assert(assumptions!==undefined&&assumptions!==null);return rest;}
function compare(weights,quota){const input=Object.freeze([...weights]),actual=analyzeGame(input,quota),expected=oracle(weights,quota);assert.deepEqual(fields(actual),expected);assert.deepEqual(input,weights);return actual;}
for(const c of namedGames)check(c.name,()=>{const a=compare(c.weights,c.quota);return{weights:c.weights,quota:c.quota,swingCounts:a.players.map(p=>p.swing_count),absolute:a.players.map(p=>p.absolute_swing_probability.text),normalized:a.players.map(p=>p.normalized_banzhaf_share.text),coalitionRows:a.coalitions.length,completeComputableObjectSha256:sha(JSON.stringify(fields(a)))};},out.named);
check('All10 named games match every computable output field',()=>{assert.equal(out.named.length,10);assert(out.named.every(x=>x.passed));return{cases:10};});
check('Independent exhaustive weights0..3,1..4players,every positive quota',()=>{
 const digest=crypto.createHash('sha256');let games=0,coalitionRows=0;
 for(const {weights,quota}of exhaustiveGames()){const a=compare(weights,quota);digest.update(JSON.stringify(fields(a))+'\n');games++;coalitionRows+=a.coalitions.length;}
 assert.equal(games,1878);assert.equal(coalitionRows,27084);return{games,coalitionRows,completeComputableObjectsSha256:digest.digest('hex')};
});
check('All6 ordinal permutations retain each original identity',()=>{
 const orders=[[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]],old=[6,4,2],counts=[3,1,1];
 for(const order of orders){const weights=order.map(i=>old[i]),a=compare(weights,7);a.players.forEach((p,i)=>{assert.equal(p.index,i+1);assert.equal(p.label,'ABC'[i]);assert.equal(p.weight,weights[i]);assert.equal(p.swing_count,counts[order[i]]);});}
 return{permutations:orders.length};
});
const hole=[1,,2];
const invalid=[
['no weights',undefined,1],['null weights',null,1],['string weights','1',1],['object weights',{0:1,length:1},1],['typed weights',new Uint8Array([1]),1],['empty weights',[],1],['seven players',[1,1,1,1,1,1,1],2],['all zero',[0,0],1],['hole',hole,1],
['boolean weight',[true],1],['string weight',['1'],1],['null weight',[null],1],['object weight',[{}],1],['NaN weight',[NaN],1],['positive infinity weight',[Infinity],1],['negative infinity weight',[-Infinity],1],['fractional weight',[1.5],1],['negative weight',[-1,2],1],['weight above20',[21],1],['negative zero weight',[-0,1],1],
['missing quota',[1],undefined],['null quota',[1],null],['boolean quota',[1],true],['string quota',[1],'1'],['object quota',[1],{}],['NaN quota',[1],NaN],['positive infinity quota',[1],Infinity],['negative infinity quota',[1],-Infinity],['fractional quota',[1,1],1.5],['negative quota',[1],-1],['zero quota',[1],0],['negative zero quota',[1],-0],['quota beyond total',[1,1],3]
];
for(const [name,weights,quota]of invalid)check(name,()=>{
 const before=structuredClone(weights),quotaBefore=structuredClone(quota);let caught;
 try{analyzeGame(weights,quota);}catch(e){caught=e;}
 assert(caught instanceof Error,'Invalid fixture unexpectedly admitted');assert(caught.message.length>0);assert.deepEqual(weights,before);assert.deepEqual(quota,quotaBefore);
 return{error:caught.message,inputPreserved:true};
},out.refusals);
check('All33 strict refusal cases preserve inputs',()=>{assert.equal(invalid.length,33);assert.equal(out.refusals.length,33);assert(out.refusals.every(x=>x.passed));return{cases:33};});
check('Fresh results have no shared nested mutable records across calls',()=>{
 const input=[6,4,2],a=analyzeGame(input,7),b=analyzeGame(input,7),before=structuredClone(b),seen=new Set();
 function collect(x){if(x&&typeof x==='object'){if(seen.has(x))return;seen.add(x);Object.values(x).forEach(collect);}}collect(a);
 let checked=0;function separate(x){if(x&&typeof x==='object'){assert(!seen.has(x),'Result calls share a nested record/array');checked++;Object.values(x).forEach(separate);}}separate(b);
 assert.notEqual(a.input.weights,input);a.input.weights[0]=99;a.coalitions[0].members.push(99);a.players[0].swing_without_masks.push(999);a.players[0].absolute_swing_probability.numerator=-9;a.summary.total_swings=0;if(Array.isArray(a.assumptions))a.assumptions.push('changed');
 assert.deepEqual(input,[6,4,2]);assert.deepEqual(b,before);assert.deepEqual(analyzeGame(input,7),before);
 return{nestedObjectsChecked:checked};
});
check('Frozen manual denominator anchors agree with the independent oracle',()=>{
 const spec=JSON.parse(expectationBytes);
 for(const c of spec.manualAnchors){const a=oracle(c.weights,c.quota);assert.deepEqual(a.players.map(p=>p.swing_count),c.swings);assert.deepEqual(a.players.map(p=>p.absolute_swing_probability.text),c.absolute);assert.deepEqual(a.players.map(p=>p.normalized_banzhaf_share.text),c.normalized);}
 return{anchors:spec.manualAnchors.length};
});
check('Candidate and frozen oracle sources remain exact',()=>{
 assert.equal(sha(fs.readFileSync(root+'/candidate/coalition-power-core.mjs')),sha(coreBytes));assert.equal(sha(fs.readFileSync(root+'/oracle-before-candidate.mjs')),sha(oracleBytes));assert.equal(sha(fs.readFileSync(root+'/expectations-before-candidate.json')),sha(expectationBytes));return{files:3};
});
out.finishedAt=new Date().toISOString();out.passed=[...out.groups,...out.named,...out.refusals].every(x=>x.passed);
const text=JSON.stringify(out,null,2)+'\n',file=root+'/native-receiving-r1.json';
fs.writeFileSync(file,text,{flag:'wx'});const fd=fs.openSync(file,'r');fs.fsyncSync(fd);fs.closeSync(fd);assert.equal(fs.readFileSync(file,'utf8'),text);
console.log(JSON.stringify({path:file,bytes:Buffer.byteLength(text),sha256:sha(text),passed:out.passed,groups:out.groups,namedPassed:out.named.filter(x=>x.passed).length,refusalsPassed:out.refusals.filter(x=>x.passed).length,failures:[...out.groups,...out.named,...out.refusals].filter(x=>!x.passed)}));
