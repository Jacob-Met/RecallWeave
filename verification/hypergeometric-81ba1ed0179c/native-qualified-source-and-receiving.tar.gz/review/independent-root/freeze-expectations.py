from pathlib import Path
from fractions import Fraction
from itertools import combinations
from math import comb
import json,hashlib,datetime
root=Path('/home/jacob/hypergeometric-independent-81ba1ed0179c')
root.mkdir(exist_ok=True)
def ratio(f):
    return {'numerator':str(f.numerator),'denominator':str(f.denominator),'approximate':float(f)}
def choose(n,k):
    return comb(n,k) if 0<=k<=n else 0
vectors=[(1,0,0,0,0),(1,1,1,1,1),(5,2,3,1,2),(6,2,3,1,2),(8,5,3,2,2),(10,0,6,1,6),(10,10,6,0,5),(17,6,17,6,6),(200,100,100,45,55),(200,199,1,0,0),(9,4,0,0,0)]
cases=[]
for N,K,n,a,b in vectors:
    total=comb(N,n)
    counts=[choose(K,x)*choose(N-K,n-x) for x in range(n+1)]
    methods=['Python math.comb exact arbitrary integers; fractions.Fraction reduction']
    if N<=17:
        enumerated=[0]*(n+1)
        # Labelled population: indices 0..K-1 are marked. Each unordered subset appears once.
        for sample in combinations(range(N),n):
            enumerated[sum(i<K for i in sample)]+=1
        assert enumerated==counts
        methods.append('Independent explicit enumeration of labelled population subsets')
    mean=sum((Fraction(x*c,total) for x,c in enumerate(counts)),Fraction())
    variance=sum((Fraction(c,total)*(x-mean)**2 for x,c in enumerate(counts)),Fraction())
    assert mean==Fraction(n*K,N)
    assert variance==(Fraction(n*K*(N-K)*(N-n),N*N*(N-1)) if N>1 else Fraction())
    rows=[{'markedCount':x,'unmarkedCount':n-x,'markedWays':str(choose(K,x)),'unmarkedWays':str(choose(N-K,n-x)),'favourableSubsets':str(c),'possible':c>0,'inEvent':a<=x<=b,'probability':ratio(Fraction(c,total))} for x,c in enumerate(counts)]
    favourable=sum(counts[a:b+1])
    expected={'config':{'population':N,'marked':K,'draws':n,'lower':a,'upper':b},'support':{'minimum':max(0,n-(N-K)),'maximum':min(n,K)},'totalSubsets':str(total),'rows':rows,'event':{'lower':a,'upper':b,'favourableSubsets':str(favourable),'probability':ratio(Fraction(favourable,total))},'mean':ratio(mean),'variance':ratio(variance)}
    cases.append({'label':f'N{N}-K{K}-n{n}-event{a}-{b}','methods':methods,'expected':expected})
assert cases[3]['expected']['rows'][0]['favourableSubsets']=='4'
assert [r['favourableSubsets'] for r in cases[3]['expected']['rows']]==['4','12','4','0']
assert cases[3]['expected']['event']['probability']['numerator']=='4'
assert cases[3]['expected']['event']['probability']['denominator']=='5'
out={'schema':'hamon.independent-mathematical-expectations.v1','frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':'estate-81ba1ed0179c/root','repository':'Jacob-Met/RecallWeave','topic':'hypergeometric','candidateAccessBeforeFreeze':False,'receivedBeforeFreeze':'Operator contract and public API shape only; candidate source, author expectations and implementation unread.','cases':cases,'properties':['Frozen detached result at every object/array depth','Input object unchanged','All rows retained including impossible counts','JSON serialization preserves every exact integer/fraction string','Uniform unordered labelled-subset model only'],'admissionControls':['Population 0,201,fraction,string,bool,NaN,Infinity','Marked less than0 or greater than population','Draws less than0 or greater than population','Event lower less than0 or upper greater than draws or reversed','Missing required fields and invalid inspected counts'],'tolerance':'Each approximate value relative error <= 2e-14 (absolute floor 1e-300); exact strings and every other field compare exactly.'}
p=root/'expectations-frozen.json'
assert not p.exists(), 'Do not overwrite an existing independent freeze'
p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cases':len(cases),'candidateAccessBeforeFreeze':False}))
