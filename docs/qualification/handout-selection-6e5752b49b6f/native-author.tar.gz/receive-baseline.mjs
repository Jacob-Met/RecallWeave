import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createHandout,createHandoutDocument} from './baseline/src/course-handout.mjs';
const deck=JSON.parse(await readFile(new URL('./fixture.json',import.meta.url),'utf8'));
const requested=['__proto__',' q spaced '];
const oldDefault=createHandout(deck);
const actual=createHandout(deck,'worksheet',requested);
assert.deepEqual(actual,oldDefault);
assert.equal(actual.questions.length,4);
assert.deepEqual(actual.questions.map(q=>q.number),[1,2,3,4]);
const documents={};
for(const kind of ['worksheet','answer-key']){
 const text=createHandoutDocument(deck,kind);
 await writeFile(new URL('./baseline-'+kind+'.html',import.meta.url),text);
 documents[kind]={bytes:Buffer.byteLength(text),sha256:createHash('sha256').update(text).digest('hex')};
}
const receipt={baseline:'698902f9c9c1d5c5023092b85b3632a7cb7a01ed',node:process.version,requested,actualNumbers:actual.questions.map(q=>q.number),actualIds:actual.questions.map(q=>q.id),desiredNumbers:[2,3],missingSelectionCapabilityConfirmed:true,legacyDocuments:documents};
await writeFile(new URL('./baseline-result.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt));