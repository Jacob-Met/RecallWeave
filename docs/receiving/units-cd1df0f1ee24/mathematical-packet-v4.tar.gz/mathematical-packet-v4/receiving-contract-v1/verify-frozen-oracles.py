#!/usr/bin/env python3
"""Check frozen explicit receiving cases; never import or parse the author model."""
import json
from fractions import Fraction
from pathlib import Path
p = Path(__file__).resolve().parent
data = json.loads((p / 'units-oracles.json').read_text())
def expression(factors):
    scale = Fraction(1)
    dimensions = [0, 0, 0]
    for symbol, exponent in factors:
        atom = data['atoms'][symbol]
        scale *= Fraction(*map(int, atom['scale'])) ** exponent
        dimensions = [a + exponent * b for a, b in zip(dimensions, atom['dimension'])]
    return scale, dimensions
for case in data['conversions']:
    source_scale, source_dims = expression(case['sourceFactors'])
    target_scale, target_dims = expression(case['targetFactors'])
    assert source_dims == target_dims == case['dimension'], case['id']
    factor = source_scale / target_scale
    written_factor = Fraction(int(case['scaleRatio']['numerator']), int(case['scaleRatio']['denominator']))
    result = Fraction(case['value']) * factor
    written_result = Fraction(int(case['exactTargetValue']['numerator']), int(case['exactTargetValue']['denominator']))
    assert factor == written_factor, (case['id'], factor, written_factor)
    assert result == written_result, (case['id'], result, written_result)
for case in data['incompatible']:
    assert case['sourceDimension'] != case['targetDimension'], case['id']
print(json.dumps({'oracleIntegrity': 'pass', 'exactConversions': len(data['conversions']), 'incompatibleDimensions': len(data['incompatible']), 'inputRefusalCasesFrozen': len(data['invalidInputs']), 'implementationImported': False}))
