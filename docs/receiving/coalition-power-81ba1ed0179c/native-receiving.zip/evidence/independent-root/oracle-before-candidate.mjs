import assert from 'node:assert/strict';
export function fraction(a,b){let x=a,y=b;while(y){[x,y]=[y,x%y];}return{numerator:a/x,denominator:b/x,text:(a/x)+'/'+(b/x)};}
export function oracle(weights,quota){
 const n=weights.length,all=[];
 function visit(i,members,total,mask){if(i===n){all.push({mask,members:[...members],weight:total,winning:total>=quota,critical_members:total>=quota?members.filter(j=>total-weights[j-1]<quota):[]});return;}
 visit(i+1,members,total,mask);members.push(i+1);visit(i+1,members,total+weights[i],mask+2**i);members.pop();}
 visit(0,[],0,0);all.sort((a,b)=>a.mask-b.mask);
 const swings=weights.map((w,i)=>all.filter(c=>c.critical_members.includes(i+1)).map(c=>c.mask-2**i).sort((a,b)=>a-b));
 const totalSwings=swings.reduce((n,a)=>n+a.length,0);
 const players=weights.map((w,i)=>({index:i+1,label:'ABCDEF'[i],weight:w,swing_count:swings[i].length,swing_without_masks:swings[i],absolute_swing_probability:fraction(swings[i].length,2**(n-1)),normalized_banzhaf_share:fraction(swings[i].length,totalSwings)}));
 assert(totalSwings>0);
 return{format:'recallweave-coalition-power-analysis/1',model:'bounded-integer-weighted-coalitions/1',input:{weights:[...weights],quota,player_count:n,total_weight:weights.reduce((a,b)=>a+b,0)},coalitions:all,players,summary:{coalition_count:2**n,winning_count:all.filter(c=>c.winning).length,losing_count:all.filter(c=>!c.winning).length,total_swings:totalSwings,other_player_coalitions:2**(n-1)}};
}
export const namedGames=[
{name:'authored-default',weights:[6,4,2],quota:7},
{name:'equal-power-unequal-weights',weights:[4,3,2],quota:5},
{name:'positive-weight-dummy',weights:[5,3,1],quota:7},
{name:'dictator',weights:[6,2,1],quota:6},
{name:'unanimity',weights:[2,2,2],quota:6},
{name:'appended-zero-player',weights:[6,4,2,0],quota:7},
{name:'leading-zero-player',weights:[0,1],quota:1},
{name:'one-player',weights:[1],quota:1},
{name:'six-maximum-weights',weights:[20,20,20,20,20,20],quota:60},
{name:'mixed-zeros-and-near-quota',weights:[0,20,0,1,1,1],quota:21}
];
export function* exhaustiveGames(){
 for(let n=1;n<=4;n++){const a=Array(n).fill(0);
 function* fill(i){if(i===n){const total=a.reduce((x,y)=>x+y,0);for(let quota=1;quota<=total;quota++)yield {weights:[...a],quota};return;}
 for(let w=0;w<=3;w++){a[i]=w;yield*fill(i+1);}}
 yield*fill(0);}
}
