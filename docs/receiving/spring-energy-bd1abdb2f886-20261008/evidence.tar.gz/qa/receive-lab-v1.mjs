import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, readdir, copyFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { withBrowser, until, sha, delay } from './browser-helpers.mjs';

const root = '/home/jacob/recallweave-spring-energy-bd1abdb2f886-20261008';
const sourceRoot = join(root, 'source'), output = join(root, 'qa/lab-browser-v1');
if (existsSync(join(output, 'browser-report.json'))) throw Error('Refusing to overwrite a prior browser receipt.');
const expected = {
 'courses/spring-energy-lab.html':'59eb341757e44767cd937f6ba0f2fac3c9bf8b9efdb6d76b5460e9af49433680',
 'courses/spring-energy.json':'84c87182731e35e036d5c2b2729cee94ae65091336272547e3a791a5cab068cc',
 'courses/spring-energy.md':'5e61b161bb32e78a0b4dfdff0d956890fb56fb99e5b35da88c07d810e11cd08b',
 'src/spring-energy.mjs':'a5996337164ffd9d8501a2c376a6bfdc57807ecbce4e5fa2075bbaf78d9010a1',
 'src/spring-energy-ui.mjs':'a26d6ff2bf4a3486ce4c61dd8d957a11d6660d8f43e3c04e4de8d947477055b1',
 'templates/spring-energy-lab.html':'655e992adc4738aff21ebb5eafbbd5d205aaaffec97eaea9d1dfc9bdf2aee14b',
 'tools/build-spring-energy.mjs':'0058c5ff10d431ba75909e925d0bf26819aa28137b59491eee1fd303a4b0e38c',
 'tests/spring-energy.test.mjs':'e5e4f8f869da4796eec2c3c34947fabe612fb2499cb4da8eee3be3211f4de8f8',
 'tests/spring-energy-course.test.mjs':'b0c4b3b56ad306364f0cb2eaca607db44ea646f6c9e0fe2bc2b9cb6451678da3',
};
const before = {};
for (const [path, hash] of Object.entries(expected)) {
 const bytes = await readFile(join(sourceRoot, path));
 assert.equal(sha(bytes), hash, path); before[path] = { bytes: bytes.length, sha256: hash };
}
const head = execFileSync('git', ['rev-parse','HEAD'], {cwd:sourceRoot,encoding:'utf8'}).trim();
assert.equal(head,'f42ad22e069b5ed3b2d85ea0573b84fef121d254');
await mkdir(output, {recursive:true});
await writeFile(join(output,'source-before.json'),JSON.stringify({head,node:process.version,executable:process.execPath,files:before},null,2)+'\n');
const near = (actual,expected,label) => assert.ok(Number.isFinite(actual) && Math.abs(actual-expected)<=0.00001*Math.max(1,Math.abs(expected)),label+': '+actual+' vs '+expected);
const report = await withBrowser({output,profileParent:join(root,'qa')}, async b => {
 const {command,evaluate,click,key,type,viewport,navigate,screenshot,check} = b;
 const captures=[];
 const text = selector => evaluate('document.querySelector('+JSON.stringify(selector)+').textContent');
 const value = selector => text(selector).then(Number.parseFloat);
 const metric = name => value('[data-value="'+name+'"]');
 const appliedSnapshot = () => evaluate('JSON.stringify({summary:document.querySelector("#applied-summary").textContent,values:[...document.querySelectorAll("[data-value]")].map(n=>n.textContent),phase:document.querySelector("#phase-readout").textContent,rows:document.querySelector("#cycle-rows").textContent,diagram:document.querySelector("#diagram-description").textContent})');
 const setFields = async values => {for(const [id,value]of Object.entries(values))await type('#'+id,String(value));await click('#apply');};
 const reset = async()=>click('#reset');
 const focusByTab = async selector => {
  for(let i=0;i<35;i++){
   if(await evaluate('document.activeElement===document.querySelector('+JSON.stringify(selector)+')'))return;
   await key('Tab',9);
  }
  throw Error('Tab traversal did not reach '+selector);
 };
 const download = async (selector,name,folder) => {
  const destination=join(output,folder);await mkdir(destination,{recursive:true});
  await command('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:destination,eventsEnabled:true},false);
  await click(selector);
  const path=join(destination,name);await until(async()=>existsSync(path)&&!(await readdir(destination)).some(n=>n.endsWith('.crdownload')),'completed '+name);
  const bytes=await readFile(path);b.report.observations.push({download:folder+'/'+name,bytes:bytes.length,sha256:sha(bytes)});
  return {path,bytes};
 };
 await viewport(1240,1000);
 await navigate(pathToFileURL(join(sourceRoot,'courses/spring-energy-lab.html')).href);
 await until(()=>evaluate('document.querySelector("#cycle-rows")?.children.length===73'),'73 rendered observations');
 await check('default release displays the frozen signed state and full table',async()=>{
  for(const[k,v]of Object.entries({position:.2,velocity:0,acceleration:-5,force:-10,totalEnergy:1,releaseEnergy:1,omega:5}))near(await metric(k),v,k);
  assert.equal(await evaluate('document.querySelectorAll("#cycle-rows tr").length'),73);
  assert.equal(await evaluate('document.querySelector("#force-vector").getAttribute("visibility")'),'visible');
  assert.equal(await evaluate('document.querySelector("#velocity-vector").getAttribute("visibility")'),'hidden');
  assert.equal(await evaluate('document.documentElement.scrollWidth<=innerWidth'),true);
  captures.push(await screenshot('01-default-desktop.png'));
 });
 await check('all canonical buttons produce the correct signs, energies and zero arrows',async()=>{
  for(const[p,x,v,a,f,k,u]of [[0,.2,0,-5,-10,0,1],[90,0,-1,0,0,1,0],[180,-.2,0,5,10,0,1],[270,0,1,0,0,1,0],[360,.2,0,-5,-10,0,1]]){
   await click('[data-phase="'+p+'"]');
   for(const[name,n]of Object.entries({position:x,velocity:v,acceleration:a,force:f}))near(await metric(name),n,name+' at'+p);
   near(await value('#kinetic-value'),k,'K');near(await value('#potential-value'),u,'U');
   assert.equal(await evaluate('document.querySelector("#force-vector").getAttribute("visibility")'),f===0?'hidden':'visible');
   assert.equal(await evaluate('document.querySelector("#velocity-vector").getAttribute("visibility")'),v===0?'hidden':'visible');
  }
  assert.match(await text('#elapsed'),/1 of a natural period/);
 });
 await check('same position has opposite velocity at45 and315 degrees',async()=>{
  await reset();await setFields({phase:45});
  const left={x:await metric('position'),v:await metric('velocity'),f:await metric('force'),k:await value('#kinetic-value')};
  await setFields({phase:315});
  near(await metric('position'),left.x,'same displacement');near(await metric('velocity'),-left.v,'opposite velocity');
  near(await metric('force'),left.f,'same restoring force');near(await value('#kinetic-value'),left.k,'same kinetic energy');
  assert.match(await text('#velocity-direction'),/right/);assert.match(await text('#force-direction'),/left/);
 });
 await check('real tab and arrow events preserve fractional phase and apply documented endpoints',async()=>{
  await reset();await setFields({phase:12.5});await focusByTab('#phase-slider');
  assert.equal(await evaluate('document.querySelector("#phase-slider").value'),'12.5');
  await key('ArrowRight',39);assert.equal(await evaluate('document.querySelector("#phase").value'),'13.5');
  await key('Home',36);assert.equal(await evaluate('document.querySelector("#phase").value'),'0');
  await key('PageUp',33);assert.equal(await evaluate('document.querySelector("#phase").value'),'15');
  await key('End',35);assert.equal(await evaluate('document.querySelector("#phase").value'),'360');
  await key('ArrowRight',39);assert.equal(await evaluate('document.querySelector("#phase").value'),'360');
  await key('ArrowLeft',37);assert.equal(await evaluate('document.querySelector("#phase").value'),'359');
 });
 await check('drafts and invalid Apply preserve the accepted release and disable model downloads',async()=>{
  await reset();const snapshot=await appliedSnapshot();const events=b.report.downloadEvents.length;
  await type('#mass','0');await type('#phase','90');
  assert.equal(await evaluate('document.querySelector("#phase-controls").disabled'),true);
  assert.equal(await evaluate('document.querySelector("#download-experiment").disabled'),true);
  assert.match(await text('#draft-status'),/Unapplied edits/);
  await click('[data-phase="270"]');await click('#download-experiment');await delay(150);
  assert.equal(await appliedSnapshot(),snapshot);assert.equal(b.report.downloadEvents.length,events);
  await click('#apply');assert.match(await text('#input-error'),/Mass must be between/);assert.equal(await appliedSnapshot(),snapshot);
  captures.push(await screenshot('02-invalid-draft-desktop.png'));
  await type('#mass','4');await click('#apply');near(await metric('velocity'),-Math.SQRT1_2,'atomic new mass and phase');
  assert.equal(await evaluate('document.querySelector("#phase-controls").disabled'),false);
 });
 await check('empty, malformed, nonfinite and out-of-range edits fail without an applied-state mutation',async()=>{
  for(const invalid of ['', '0x2','Infinity','1e309','11','-1']){
   await reset();const previous=await appliedSnapshot();await type('#mass',invalid);await click('#apply');
   assert.equal(await appliedSnapshot(),previous,invalid);assert.equal(await evaluate('document.querySelector("#input-error").hidden'),false);
  }
 });
 await check('actual preset controls show separate mass stiffness and amplitude comparisons',async()=>{
  for(const[preset,t,e,m,k,a]of [['heavy',2,1,8,50,.2],['stiff',.5,4,2,200,.2],['large',1,4,2,50,.4]]){
   await reset();await click('[data-preset="'+preset+'"]');
   const inputs=await evaluate('Object.fromEntries([...document.querySelectorAll("#parameters input")].map(n=>[n.name,Number(n.value)]))');
   assert.deepEqual(inputs,{massKg:m,stiffnessNPerM:k,amplitudeM:a,phaseDegrees:0});
   near(await metric('period'),2*Math.PI/5*t,'preset period');near(await metric('releaseEnergy'),e,'preset energy');
   assert.match(await text('#comparison'),new RegExp('Period ×'+String(t).replace('.','\\.')+'; release energy ×'+e));
  }
 });
 await check('zero amplitude is a finite resting display with undefined fractions and no arrows',async()=>{
  await reset();await setFields({amplitude:0,phase:135});
  for(const name of ['position','velocity','acceleration','force','totalEnergy','releaseEnergy'])assert.equal(await metric(name),0,name);
  assert.match(await text('#energy-note'),/Zero amplitude/);
  assert.match(await text('#kinetic-fraction'),/undefined/);assert.match(await text('#potential-fraction'),/undefined/);
  assert.equal(await evaluate('document.querySelector("#force-vector").getAttribute("visibility")'),'hidden');
  assert.equal(await evaluate('document.querySelector("#velocity-vector").getAttribute("visibility")'),'hidden');
  near(await metric('period'),2*Math.PI/5,'natural period of resting system');
  assert.doesNotMatch(await text('#energy-title'),/NaN|Infinity/);
  await click('#energy-title');captures.push(await screenshot('03-zero-energy.png'));
 });
 await check('actual experiment downloads are deterministic and carry full applied precision and all73 rows',async()=>{
  await reset();await setFields({mass:1.3,stiffness:37,amplitude:.13,phase:27.5});
  const first=await download('#download-experiment','spring-energy-experiment.json','experiment-first');
  const second=await download('#download-experiment','spring-energy-experiment.json','experiment-repeat');
  assert.deepEqual(first.bytes,second.bytes);
  const data=JSON.parse(first.bytes);
  assert.equal(data.format,'recallweave-spring-energy-observation/1');
  assert.deepEqual(data.input,{massKg:1.3,stiffnessNPerM:37,amplitudeM:.13,phaseDegrees:27.5});
  assert.deepEqual(data.observation.input,data.input);assert.equal(data.cycle.length,73);
  assert.deepEqual(data.cycle.map(r=>r.input.phaseDegrees),Array.from({length:73},(_,i)=>i*5));
  const theta=27.5*Math.PI/180,omega=Math.sqrt(37/1.3);
  near(data.observation.position,.13*Math.cos(theta),'unrounded exported x');
  near(data.observation.velocity,-.13*omega*Math.sin(theta),'unrounded exported v');
  assert.equal(data.units.force,'N');assert.equal(data.units.frequency,'Hz');
  assert.equal(data.cycle[0].position,.13);assert.equal(data.cycle[18].position,0);assert.equal(data.cycle[54].position,0);
  assert.equal(data.cycle[72].time,data.observation.period);
 });
 await check('the lesson downloaded during an invalid draft is the exact admitted course',async()=>{
  await type('#mass','invalid');
  const actual=await download('#download-course','spring-energy.json','course');
  assert.deepEqual(actual.bytes,await readFile(join(sourceRoot,'courses/spring-energy.json')));
  assert.equal(sha(actual.bytes),expected['courses/spring-energy.json']);
  assert.equal(JSON.parse(actual.bytes).items.length,12);
  b.report.actualCoursePath=actual.path;
 });
 await check('390px phone view retains labels, geometry and keyboard-scrollable full cycle',async()=>{
  await reset();await viewport(390,844);await click('[data-phase="270"]');
  assert.equal(await evaluate('innerWidth'),390);
  assert.equal(await evaluate('document.documentElement.scrollWidth<=innerWidth'),true);
  assert.equal(await evaluate('(()=>{const r=document.querySelector("#motion-diagram").getBoundingClientRect();return r.left>=0&&r.right<=innerWidth})()'),true);
  for(const selector of ['#apply','#reset','#download-course','#download-experiment']){
   assert.equal(await evaluate('(()=>{const r=document.querySelector('+JSON.stringify(selector)+').getBoundingClientRect();return r.width>0&&r.left>=0&&r.right<=innerWidth})()'),true,selector);
  }
  await click('#motion-title');captures.push(await screenshot('04-phone-motion-270.png'));
  await click('#energy-title');captures.push(await screenshot('05-phone-energy-270.png'));
  await click('.table-region');
  const before=await evaluate('document.querySelector(".table-region").scrollLeft');
  await key('ArrowRight',39);await delay(200);
  assert.ok(await evaluate('document.querySelector(".table-region").scrollLeft')>before);
  captures.push(await screenshot('06-phone-cycle-scroll.png'));
 });
 await check('source stays local and no script error or external request occurs',async()=>{
  assert.equal(b.report.pageErrors.length,0);
  assert.deepEqual(b.report.requests.filter(r=>/^https?:/.test(r.url)),[]);
 });
 b.report.captures=captures;
});
const after={};
for(const path of Object.keys(before)){const bytes=await readFile(join(sourceRoot,path));after[path]={bytes:bytes.length,sha256:sha(bytes)};}
const unchanged=JSON.stringify(before)===JSON.stringify(after);
await writeFile(join(output,'source-after.json'),JSON.stringify({head,files:after,unchanged},null,2)+'\n');
console.log(JSON.stringify({status:report.status,checks:report.checks,sourceUnchanged:unchanged,actualCoursePath:report.actualCoursePath,cleanup:report.cleanup}));
process.exitCode=report.status==='passed'&&unchanged?0:1;
