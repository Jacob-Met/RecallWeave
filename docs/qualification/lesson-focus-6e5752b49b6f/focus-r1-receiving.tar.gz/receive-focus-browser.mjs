import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';

const args = process.argv.slice(2);
assert.equal(args.length % 2, 0, 'Use paired --root/--output/--browser/--playwright arguments');
const options = Object.fromEntries(args.reduce((pairs, value, index) => index % 2 ? pairs : [...pairs, [value.replace(/^--/, ''), args[index + 1]]], []));
const root = resolve(options.root), output = resolve(options.output);
await mkdir(output, { recursive: true });
const temporary = resolve(output, 'owned-browser-temporary');
await mkdir(temporary, { recursive: true });
process.env.TMPDIR = temporary;
const { chromium } = createRequire(import.meta.url)(options.playwright);
const { MAX_DECK_BYTES, parseDeck, validateDeck } = await import(pathToFileURL(resolve(root, 'src/deck.mjs')));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const sourcePaths = ['focus/index.html', 'focus/focus.css', 'focus.html', 'src/course-focus.mjs', 'src/course-focus-ui.mjs', 'src/deck.mjs',
  'tools/make_focus.py', 'index.html', 'demo.html', 'src/app.mjs', 'src/deck-picker.mjs', 'src/knowledge.mjs', 'src/review.mjs', 'src/answer-order.mjs', 'src/session-export.mjs', 'data/deck.json', 'styles.css'];
const sources = Object.fromEntries(await Promise.all(sourcePaths.map(async path => [path, hash(await readFile(resolve(root, path)))])));
const report = { source_commit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  source_sha256: sources, receiver_sha256: hash(await readFile(new URL(import.meta.url))), node: process.version,
  cases: [], downloads: [], screenshots: [], external_requests: [], page_errors: [] };

function item(id, concept, dependencies, answer) {
  return { id, concept, prerequisites: dependencies, prompt: `${id}: literal <em data-focus-injection="yes">café</em>\nChoose a connection.`,
    options: ['First “choice”', 'Second <choice>', 'Third / choice', 'Fourth & choice', 'Fifth choice', 'Sixth choice'], answer,
    explanation: `${id}: original explanation with "quotes"\nand a second line.`, transfer: `${id}: explain the connection in your own words.` };
}
const source = validateDeck({ title: 'Source “course” <literal>', attribution: 'Original fixture author\nSource <em data-focus-injection="yes">text</em>', license: 'Fixture only — permission text unchanged',
  concepts: ['Application', 'Independent topic', 'Foundations', 'Comparison', 'Measurement', 'Downstream extension'],
  items: [item('apply-a', 'Application', ['Comparison'], 2), item('unrelated', 'Independent topic', [], 5),
    item('measure', 'Measurement', ['Foundations'], 1), item('apply-b', 'Application', ['Measurement'], 0),
    item('foundation', 'Foundations', [], 3), item('compare', 'Comparison', ['Foundations'], 4),
    item('extension', 'Downstream extension', ['Application'], 2)] });
const expectedIds = ['apply-a', 'measure', 'apply-b', 'foundation', 'compare'];
function expected(title) {
  return { format: source.format, title, attribution: source.attribution, license: source.license,
    concepts: ['Application', 'Foundations', 'Comparison', 'Measurement'], items: source.items.filter(item => expectedIds.includes(item.id)) };
}
function payload(deck, name = 'lesson-source.json') {
  return { name, mimeType: 'application/json', buffer: Buffer.isBuffer(deck) ? deck : Buffer.from(typeof deck === 'string' ? deck : JSON.stringify(deck)) };
}
const server = createServer(async (request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
  if (pathname === '/favicon.ico') { response.writeHead(204); response.end(); return; }
  const file = resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
  if (!file.startsWith(root + sep)) { response.writeHead(403); response.end(); return; }
  try {
    const bytes = await readFile(file);
    response.writeHead(200, { 'Content-Type': (({ '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json' })[extname(file)] || 'application/octet-stream') + '; charset=utf-8' });
    response.end(bytes);
  } catch { response.writeHead(404); response.end(); }
});
await new Promise(done => server.listen(0, '127.0.0.1', done));
const origin = 'http://127.0.0.1:' + server.address().port;
let browser, context, page;
let modularDownload, standaloneDownload;

async function button(id, target = page) { await target.locator(id).focus(); await target.locator(id).press('Enter'); }
async function choose(file) {
  const event = page.waitForEvent('filechooser');
  await button('#open-source');
  await (await event).setFiles(file);
}
async function use(file) {
  await choose(file);
  await page.locator('#source-preview').waitFor({ state: 'visible' });
  await button('#use-source');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'targets-heading');
}
async function select(index) { await page.locator('#focus-target-' + index).focus(); await page.keyboard.press('Space'); }
async function state() {
  return page.evaluate(() => ({ source: document.querySelector('#source-title').textContent,
    title: document.querySelector('#focus-title').value,
    targets: [...document.querySelectorAll('#target-concepts input')].map(input => input.checked),
    summary: document.querySelector('#selection-summary').textContent,
    inclusions: document.querySelector('#included-concepts').textContent,
    items: [...document.querySelectorAll('#included-questions details')].map(row => row.dataset.itemId),
    disabled: document.querySelector('#download-focus').disabled,
    help: document.querySelector('#download-help').textContent }));
}
async function capture(name, selector) {
  if (selector) await page.locator(selector).scrollIntoViewIfNeeded();
  await page.screenshot({ path: resolve(output, name) });
  report.screenshots.push(name);
}
async function noOverflow(target = page) {
  const dimensions = await target.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }));
  assert.ok(dimensions.scroll <= dimensions.width, JSON.stringify(dimensions));
  return dimensions;
}
async function saveDownload(target, selector, filename) {
  const event = target.waitForEvent('download');
  await button(selector, target);
  const download = await event;
  assert.equal(await download.failure(), null);
  const stream = await download.createReadStream();
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  const bytes = Buffer.concat(chunks);
  await writeFile(resolve(output, filename), bytes);
  const record = { filename, suggested_filename: download.suggestedFilename(), bytes: bytes.length, sha256: hash(bytes) };
  report.downloads.push(record);
  return { bytes, record };
}
async function open(standalone = false) {
  await context?.close();
  context = await browser.newContext({ acceptDownloads: true, viewport: { width: standalone ? 390 : 1280, height: standalone ? 844 : 960 } });
  await context.route('**/*', route => {
    const url = route.request().url();
    if (url.startsWith(origin + '/') || url.startsWith(pathToFileURL(root + '/').href) || url.startsWith('blob:') || url.startsWith('data:')) return route.continue();
    report.external_requests.push(url); return route.abort();
  });
  if (standalone) await context.setOffline(true);
  page = await context.newPage();
  page.on('pageerror', error => report.page_errors.push(String(error)));
  await page.goto(standalone ? pathToFileURL(resolve(root, 'focus.html')).href : origin + '/focus/');
  await page.locator('#open-source').waitFor();
}
async function run(name, operation) {
  try { const detail = await operation(); report.cases.push({ name, passed: true, detail }); console.log('PASS ' + name); }
  catch (error) { report.cases.push({ name, passed: false, error: error.stack }); throw error; }
}
async function installControlledReads() {
  await page.evaluate(() => {
    const original = File.prototype.text;
    window.focusReadControls = new Map();
    window.focusReads = [];
    File.prototype.text = function () {
      window.focusReads.push(this.name);
      if (this.name.startsWith('unreadable-')) return Promise.reject(new Error('Authored read refusal'));
      if (!this.name.startsWith('held-')) return original.call(this);
      const file = this;
      return new Promise((resolve, reject) => {
        window.focusReadControls.set(file.name, async fail => {
          if (fail) reject(new Error('Late authored read refusal'));
          else resolve(await original.call(file));
          await Promise.resolve();
        });
      });
    };
  });
}
async function release(name, fail = false) {
  await page.evaluate(async ([name, fail]) => {
    await window.focusReadControls.get(name)(fail);
    await new Promise(done => requestAnimationFrame(done));
  }, [name, fail]);
}

async function receiveLearner(download, standalone) {
  const learner = await context.newPage();
  learner.on('pageerror', error => report.page_errors.push(String(error)));
  await learner.goto(standalone ? pathToFileURL(resolve(root, 'demo.html')).href : origin + '/index.html');
  await button('#start-button', learner);
  await button('[data-choice="0"]', learner);
  const original = await learner.locator('#session-content').innerHTML();
  const file = payload(download.bytes, download.record.filename);
  await learner.locator('#deck-file').setInputFiles(file);
  await learner.locator('#start-deck').waitFor();
  assert.equal(await learner.locator('#session-content').innerHTML(), original);
  await button('#cancel-deck', learner);
  assert.equal(await learner.locator('#session-content').innerHTML(), original);
  await learner.locator('#deck-file').setInputFiles(file);
  await learner.locator('#start-deck').waitFor();
  const deck = parseDeck(download.bytes.toString('utf8'));
  assert.equal(await learner.locator('#deck-preview-title').textContent(), deck.title);
  assert.ok((await learner.locator('.deck-preview-attribution').textContent()).includes(deck.attribution));
  await button('#start-deck', learner);
  const firstAnswers = [];
  for (let index = 0; index < deck.items.length; index++) {
    const prompt = await learner.locator('.question-card h2').textContent();
    const question = deck.items.find(item => item.prompt === prompt);
    assert.ok(question && !firstAnswers.some(answer => answer.id === question.id));
    const choice = index % 2 ? (question.answer + 1) % question.options.length : question.answer;
    await button(`[data-choice="${choice}"]`, learner);
    assert.ok((await learner.locator('#feedback-slot').textContent()).includes(question.explanation));
    firstAnswers.push({ id: question.id, choice, correct: choice === question.answer });
    await button('#next-button', learner);
  }
  assert.equal(await learner.locator('.review-item').count(), 5);
  const firstSummary = await learner.locator('#first-try-summary').textContent();
  assert.match(firstSummary, /3 of 5/);
  const mastery = await learner.locator('.mastery-box').textContent();
  for (let index = 0; index < firstAnswers.length; index++) {
    const answer = firstAnswers[index];
    const question = deck.items.find(item => item.id === answer.id);
    const row = learner.locator('.review-item').nth(index);
    await row.locator('summary').click();
    assert.deepEqual(await row.locator('dd').allTextContents(), [question.options[answer.choice], question.options[question.answer]]);
  }
  await button('#practice-button', learner);
  const misses = firstAnswers.filter(answer => !answer.correct);
  for (const miss of misses) {
    const question = deck.items.find(item => item.id === miss.id);
    assert.equal(await learner.locator('.practice-card h2').textContent(), question.prompt);
    await button(`[data-practice-choice="${question.answer}"]`, learner);
    const next = learner.locator('#practice-feedback button');
    await next.focus(); await next.press('Enter');
  }
  assert.equal(await learner.locator('#first-try-summary').textContent(), firstSummary);
  assert.equal(await learner.locator('.mastery-box').textContent(), mastery);
  const notes = await saveDownload(learner, '#save-notes-button', (standalone ? 'standalone' : 'modular') + '-study-notes.txt');
  const text = notes.bytes.toString('utf8');
  for (const question of deck.items) {
    assert.ok(text.includes(question.prompt)); assert.ok(text.includes(question.options[question.answer]));
    assert.ok(text.includes(question.explanation)); assert.ok(text.includes(question.transfer));
  }
  assert.ok(text.includes(deck.attribution));
  for (const id of ['unrelated', 'extension']) assert.ok(!text.includes(source.items.find(item => item.id === id).prompt));
  await noOverflow(learner);
  await learner.close();
  return { firstAnswers, retries: misses.map(answer => answer.id), firstSummary, notes: notes.record };
}

function exactBoundarySource() {
  const draft = { title: 'T', attribution: 'A', license: 'L', concepts: ['Topic'], items: [] };
  for (let index = 0; index < 30; index++) {
    const question = item('q-' + index, 'Topic', [], index % 6);
    question.prompt = 'é'.repeat(1000); question.explanation = 'e'.repeat(4000); question.transfer = 't'.repeat(1000);
    draft.items.push(question);
  }
  let remaining = MAX_DECK_BYTES - Buffer.byteLength(JSON.stringify(validateDeck(draft)));
  for (const question of draft.items) {
    for (const field of ['prompt', 'transfer']) {
      const count = Math.min(2000 - question[field].length, remaining);
      question[field] += 'z'.repeat(count); remaining -= count;
    }
  }
  assert.equal(remaining, 0);
  const bytes = Buffer.from(JSON.stringify(validateDeck(draft)));
  assert.equal(bytes.length, MAX_DECK_BYTES);
  return bytes;
}

try {
  browser = await chromium.launch({ executablePath: options.browser, headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-background-networking'] });
  report.browser_version = browser.version();
  await open();
  await run('actual source preview, explicit use, two dependency branches and literal content', async () => {
    await choose(payload(source));
    await page.locator('#source-preview').waitFor({ state: 'visible' });
    assert.equal(await page.locator('#focus-editor').isHidden(), true);
    assert.equal(await page.locator('#source-preview-title').textContent(), source.title);
    assert.equal(await page.evaluate(() => document.activeElement.id), 'source-preview-title');
    await button('#use-source');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'targets-heading');
    await select(0);
    assert.deepEqual((await state()).items, expectedIds);
    assert.equal(await page.locator('.inclusion .target-badge').count(), 1);
    assert.equal(await page.locator('.inclusion .badge:not(.target-badge)').count(), 3);
    assert.equal(await page.locator('#download-focus').isDisabled(), true);
    await page.locator('#focus-title').fill('Focused café “connections”');
    assert.equal(await page.locator('#download-focus').isDisabled(), false);
    assert.equal(await page.locator('[data-focus-injection]').count(), 0);
    await page.locator('.question summary').first().click();
    await capture('modular-focus.png', '#focus-preview-heading');
    return { selection: await state(), layout: await noOverflow() };
  });
  await run('real checked downloads preserve source and answer identity across selection revisions', async () => {
    modularDownload = await saveDownload(page, '#download-focus', 'modular.focus.json');
    assert.deepEqual(parseDeck(modularDownload.bytes.toString('utf8')), expected('Focused café “connections”'));
    await select(2);
    assert.equal(await page.locator('.target-badge').count(), 2);
    const promoted = await saveDownload(page, '#download-focus', 'promoted.focus.json');
    assert.deepEqual(promoted.bytes, modularDownload.bytes);
    await select(0);
    assert.deepEqual((await state()).items, ['foundation']);
    await page.locator('#focus-title').fill('');
    assert.equal(await page.locator('#download-focus').isDisabled(), true);
    let unexpected = 0;
    const onDownload = () => unexpected++;
    page.on('download', onDownload);
    await page.locator('#download-focus').evaluate(button => button.click());
    await page.evaluate(() => new Promise(done => requestAnimationFrame(done)));
    assert.equal(unexpected, 0);
    page.off('download', onDownload);
    await button('#clear-targets');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'select-all');
    assert.deepEqual((await state()).items, []);
    await select(0); await page.locator('#focus-title').fill('Focused café “connections”');
    const repeat = await saveDownload(page, '#download-focus', 'repaired.focus.json');
    assert.deepEqual(repeat.bytes, modularDownload.bytes);
    return { initial: modularDownload.record, promoted: promoted.record, repaired: repeat.record, preventedStaleDownloads: true };
  });
  await installControlledReads();
  await run('cancel, invalid, oversized and unreadable file choices retain the checked current selection', async () => {
    const before = await state();
    await choose(payload({ ...source, title: 'Another source' }, 'other.json'));
    await page.locator('#source-preview').waitFor({ state: 'visible' });
    await button('#cancel-source');
    assert.deepEqual(await state(), before);
    assert.equal(await page.evaluate(() => document.activeElement.id), 'open-source');
    for (const file of [payload('{', 'malformed.json'), payload({ format: 'recallweave-author-draft/1', draft: {} }, 'draft.json'),
      payload(Buffer.alloc(MAX_DECK_BYTES + 1), 'oversized.json'), payload(source, 'unreadable-source.json')]) {
      await choose(file);
      await page.locator('#file-status[data-error="true"]').waitFor();
      assert.deepEqual(await state(), before);
      assert.equal(await page.locator('#source-preview').isHidden(), true);
      assert.equal(await page.evaluate(() => document.activeElement.id), 'open-source');
    }
    const reads = await page.evaluate(() => window.focusReads);
    assert.ok(!reads.includes('oversized.json'), 'oversized file must be rejected before File.text');
    return { preserved: before, oversizedReadAvoided: true };
  });
  await run('newer choices, cancel events and continued editing retire asynchronous file reads', async () => {
    const before = await state();
    const newer = { ...source, title: 'Newer local source' };
    await choose(payload(source, 'held-valid.json'));
    await choose(payload(newer, 'newer.json'));
    await page.locator('#source-preview').waitFor({ state: 'visible' });
    await release('held-valid.json');
    assert.equal(await page.locator('#source-preview-title').textContent(), newer.title);
    assert.deepEqual(await state(), before);
    await button('#cancel-source');
    await choose(payload(source, 'held-failure.json'));
    await choose(payload('{', 'newer-invalid.json'));
    await page.locator('#file-status[data-error="true"]').waitFor();
    const latestError = await page.locator('#file-status').textContent();
    await release('held-failure.json', true);
    assert.equal(await page.locator('#file-status').textContent(), latestError);
    await choose(payload(source, 'held-cancel.json'));
    await page.locator('#source-file').dispatchEvent('cancel');
    await release('held-cancel.json');
    assert.equal(await page.locator('#source-preview').isHidden(), true);
    assert.deepEqual(await state(), before);
    await choose(payload(newer, 'held-edit.json'));
    await page.locator('#focus-title').fill('Continue current work');
    await release('held-edit.json');
    assert.equal(await page.locator('#source-preview').isHidden(), true);
    assert.match(await page.locator('#file-status').textContent(), /continued editing/);
    assert.equal((await state()).title, 'Continue current work');
    await choose(payload(newer)); await page.locator('#source-preview').waitFor({ state: 'visible' });
    await select(2);
    assert.equal(await page.locator('#source-preview').isHidden(), true);
    await select(2); await page.locator('#focus-title').fill('Focused café “connections”');
    assert.deepEqual(await state(), before);
    return { lateSuccessSuperseded: true, lateFailureIgnored: true, cancelEventRetired: true, currentEditRetiredReadAndPreview: true };
  });
  await run('download-start refusal preserves a ready selection for retry', async () => {
    const before = await state();
    await page.evaluate(() => { window.originalCreateObjectURL = URL.createObjectURL; URL.createObjectURL = () => { throw new Error('Authored download refusal'); }; });
    await button('#download-focus');
    assert.match(await page.locator('#download-status').textContent(), /could not start/);
    assert.deepEqual(await state(), before);
    await page.evaluate(() => { URL.createObjectURL = window.originalCreateObjectURL; });
    const retry = await saveDownload(page, '#download-focus', 'download-retry.focus.json');
    assert.deepEqual(retry.bytes, modularDownload.bytes);
    return retry.record;
  });
  await run('actual downloaded modular file previews without replacing progress, then completes learning and retry', () => receiveLearner(modularDownload, false));
  await run('exact UTF-8 cap survives actual upload/download; a longer title retires ready bytes', async () => {
    const boundary = exactBoundarySource();
    await use(payload(boundary, 'exact-boundary.json'));
    await select(0); await page.locator('#focus-title').fill('T');
    const exact = await saveDownload(page, '#download-focus', 'exact-boundary.focus.json');
    assert.deepEqual(exact.bytes, boundary);
    await page.locator('#focus-title').fill('TT');
    assert.equal(await page.locator('#download-focus').isDisabled(), true);
    assert.match(await page.locator('#download-help').textContent(), /256 KiB/);
    await page.locator('#focus-title').fill('T');
    assert.equal(await page.locator('#download-focus').isDisabled(), false);
    await use(payload(source));
    return { inputSha256: hash(boundary), downloaded: exact.record, oneByteGrowthRefused: true };
  });
  await open(true);
  await run('standalone offline phone uses labeled keyboard controls and contains long literal source text', async () => {
    const longSource = { ...source, title: 'λ'.repeat(160) };
    const filename = '長'.repeat(70) + '.json';
    await choose(payload(longSource, filename));
    await page.locator('#source-preview').waitFor({ state: 'visible' });
    assert.equal(await page.locator('#source-preview-title').textContent(), longSource.title);
    await noOverflow();
    await capture('phone-incoming.png', '#source-preview-title');
    await button('#use-source');
    await page.keyboard.press('Tab');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'focus-target-0');
    await page.keyboard.press('Space');
    await page.locator('#focus-title').focus();
    await page.keyboard.insertText('Focused café “connections”');
    standaloneDownload = await saveDownload(page, '#download-focus', 'standalone.focus.json');
    assert.deepEqual(standaloneDownload.bytes, modularDownload.bytes);
    await capture('phone-focus.png', '#focus-preview-heading');
    assert.equal(await page.locator('[data-focus-injection]').count(), 0);
    const layout = await noOverflow();
    await page.reload();
    assert.equal(await page.locator('#focus-editor').isHidden(), true);
    return { layout, downloaded: standaloneDownload.record, noAutomaticPersistence: true };
  });
  await run('actual standalone download completes offline imported learning, canonical review and retry', () => receiveLearner(standaloneDownload, true));
  assert.deepEqual(report.external_requests, []);
  assert.deepEqual(report.page_errors, []);
  report.passed = true;
} catch (error) {
  report.passed = false;
  report.error = error.stack;
  if (page && !page.isClosed()) {
    try { await capture('failure.png'); report.failureBody = await page.locator('body').innerText(); } catch {}
  }
  process.exitCode = 1;
} finally {
  await browser?.close();
  await new Promise(done => server.close(done));
  const after = Object.fromEntries(await Promise.all(sourcePaths.map(async path => [path, hash(await readFile(resolve(root, path)))])));
  report.sources_unchanged = JSON.stringify(after) === JSON.stringify(sources);
  if (!report.sources_unchanged) { report.passed = false; process.exitCode = 1; }
  await writeFile(resolve(output, 'receiving.json'), JSON.stringify(report, null, 2) + '\n');
  await rm(temporary, { recursive: true, force: true });
  console.log(JSON.stringify({ passed: report.passed, groups: report.cases.length, downloads: report.downloads.length, source: report.source_commit, output }));
}
