import ctypes, datetime, hashlib, json, os, pathlib, platform, shutil, subprocess, sys, traceback
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
P=R/'ORIGINAL-STAGING.json'
E=R/'original-native-r1'
E.mkdir(exist_ok=False)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):
 b=p.read_bytes()
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(name,o): (E/name).write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
class MEM(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['totalPhys','availPhys','totalPage','availPage','totalVirtual','availVirtual','availExtended']]
m=MEM();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
u=ctypes.create_unicode_buffer(256);n=ctypes.c_ulong(256);assert ctypes.windll.advapi32.GetUserNameW(u,ctypes.byref(n))
receipt={'started':now(),'wrapperPid':os.getpid(),'status':'started','machine':platform.node(),'user':u.value,'python':sys.version,'pythonExecutable':sys.executable,'pythonPin':pin(pathlib.Path(sys.executable)),'capacity':{'CFree':shutil.disk_usage('C:/').free,'DFree':shutil.disk_usage('D:/').free,'memoryAvailable':m.availPhys},'guard':{'C':1073741824,'D':268435456,'memory':2147483648},'children':[]}
save('receipt.json',receipt)
try:
 assert platform.node().upper()=='MSI' and u.value=='Veria'
 assert receipt['pythonPin']['sha256']=='5f7b89a612c9b8af1d6456cdfcd1dbe5ca630849e79aebced9bee9a6694952ec'
 assert receipt['capacity']['CFree']>=1073741824 and receipt['capacity']['DFree']>=268435456 and m.availPhys>=2147483648
 packet=json.loads(P.read_text(encoding='utf-8'))
 original=R/'original';original.mkdir(exist_ok=False)
 manifest=[]
 for entry in packet['donorFiles']:
  src=pathlib.Path(packet['donorRoot'])/entry['path'];b=src.read_bytes();pp=pin(src)
  assert pp['bytes']==entry['bytes'] and pp['git']==entry['git'],entry['path']
  dst=original/entry['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
  assert dst.read_bytes()==b
  manifest.append({'path':entry['path'],**pp,'source':'read-only exact canonical donor'})
 for entry in packet['extraFiles']:
  b=entry['content'].encode('utf-8');dst=original/entry['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);pp=pin(dst)
  assert pp['git']==entry['git'],entry['path']
  manifest.append({'path':entry['path'],**pp,'source':'GitHub exact canonical blob'})
 (R/'ORIGINAL-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
 (R/'CONTRACT.md').write_text(packet['contract'],encoding='utf-8')
 node=pathlib.Path(r'C:/Program Files/nodejs/node.exe');nodepin=pin(node)
 assert nodepin['sha256']=='3602f2bb1a10f2cbab4c36886218a33c1ab3db87290e73b033c46c77147d0237'
 observer=R/'original-only.mjs'
 observer.write_text("""import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const root=process.argv[2];
const {parseDeck,serializeDeck}=await import(pathToFileURL(root+'/src/deck.mjs').href);
const text=fs.readFileSync(root+'/courses/mendelian-inheritance.json','utf8');
const deck=parseDeck(text);
assert.equal(deck.items.length,12);
assert.equal(deck.concepts.length,4);
assert.deepEqual(parseDeck(serializeDeck(deck)),deck);
assert.ok(Object.isFrozen(deck)&&Object.isFrozen(deck.items)&&deck.items.every(x=>Object.isFrozen(x)));
const originalItems=JSON.parse(text).items;
assert.deepEqual(deck.items,originalItems);
console.log(JSON.stringify({node:process.version,pid:process.pid,groups:['original12questions4concepts','completeNativeRoundtrip','immutableSnapshot','allOriginalItemFieldsExact'],title:deck.title}));
""",encoding='utf-8')
 tmp=R/'tmp';tmp.mkdir()
 env=os.environ.copy();env.update({'TEMP':str(tmp),'TMP':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'})
 argv=[str(node),str(observer),str(original)]
 with (E/'stdout.txt').open('wb') as out,(E/'stderr.txt').open('wb') as err:
  child=subprocess.Popen(argv,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
  receipt['children'].append({'pid':child.pid,'argv':argv,'cwd':str(R),'envDelta':{'TEMP':str(tmp),'TMP':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'}});save('receipt.json',receipt)
  try: code=child.wait(timeout=20)
  except subprocess.TimeoutExpired: child.kill();code=child.wait();receipt['timeout']=True
 receipt['children'][-1]['exitCode']=code;assert code==0,'Original native child failed'
 assert (E/'stderr.txt').read_bytes()==b''
 result=json.loads((E/'stdout.txt').read_text(encoding='utf-8'));receipt['originalObservation']=result
 assert result['node']=='v24.19.0'
 after=[]
 for e in manifest:
  p=pin(original/e['path']);assert p['git']==e['git'] and p['sha256']==e['sha256'] and p['bytes']==e['bytes'];after.append({'path':e['path'],**p})
 receipt.update({'status':'passed','finished':now(),'canonical':packet['canonical'],'node':{'path':str(node),**nodepin},'sourceBefore':manifest,'sourceAfter':after,'contract':pin(R/'CONTRACT.md'),'manifest':pin(R/'ORIGINAL-MANIFEST.json'),'observer':pin(observer),'stdout':pin(E/'stdout.txt'),'stderr':pin(E/'stderr.txt'),'candidatePresent':False})
 shutil.rmtree(tmp);receipt['ownedTempRemoved']=True
 save('receipt.json',receipt)
 offer={'format':'recall-genotype-counts-original-only/1','canonical':packet['canonical'],'claim':packet['issue'],'root':str(R),'originalRoot':str(original),'contract':{'path':str(R/'CONTRACT.md'),**pin(R/'CONTRACT.md')},'manifest':{'path':str(R/'ORIGINAL-MANIFEST.json'),**pin(R/'ORIGINAL-MANIFEST.json')},'sourceCount':len(manifest),'sourceBytes':sum(x['bytes'] for x in manifest),'nativeOriginalReceipt':{'path':str(E/'receipt.json'),**pin(E/'receipt.json')},'node':{'path':str(node),**nodepin},'python':{'path':sys.executable,**pin(pathlib.Path(sys.executable))},'independence':'Only canonical source and public pre-authoring contract. No candidate, question, key or authored-test body exists. The original-only observer is author baseline evidence, not a required independent expected oracle.'}
 (R/'ORIGINAL-ONLY-OFFER.json').write_text(json.dumps(offer,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':'passed','offer':pin(R/'ORIGINAL-ONLY-OFFER.json'),'receipt':pin(E/'receipt.json'),'sourceCount':len(manifest),'sourceBytes':sum(x['bytes'] for x in manifest),'wrapperPid':os.getpid(),'childPid':child.pid}))
except BaseException as ex:
 receipt.update({'status':'failed','finished':now(),'error':str(ex),'traceback':traceback.format_exc()});save('receipt.json',receipt);raise
