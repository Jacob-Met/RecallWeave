import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const R=path.dirname(fileURLToPath(import.meta.url)),m=JSON.parse(fs.readFileSync(path.join(R,'candidate-runtime-manifest-r1.json'),'utf8'));
const original=JSON.parse(fs.readFileSync(path.join(R,'original-admission-input.json'),'utf8')).files;
const sha=b=>createHash('sha256').update(b).digest('hex'),git=b=>createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const target=path.join(R,'candidate-runtime-r1');assert.equal(fs.existsSync(target),false);fs.mkdirSync(target);
const rows=[];
for(const e of m.files){
 assert.ok(!e.path.startsWith('tests/')&&!e.path.endsWith('check-absorbing-walk-browser.mjs'));
 const s=path.join(m.sourceRoot,e.path),d=path.join(target,e.path),bytes=fs.readFileSync(s);
 assert.equal(bytes.length,e.bytes);assert.equal(sha(bytes),e.sha256);assert.equal(git(bytes),e.git);
 const prior=original.find(x=>x.path===e.path);
 if(prior&&e.path!=='README.md')assert.equal(e.sha256,prior.sha256);
 if(e.path==='README.md')assert.ok(bytes.subarray(0,fs.readFileSync(path.join(R,'original/README.md')).length).equals(fs.readFileSync(path.join(R,'original/README.md'))));
 fs.mkdirSync(path.dirname(d),{recursive:true});fs.writeFileSync(d,bytes);assert.deepEqual(fs.readFileSync(s),bytes);assert.deepEqual(fs.readFileSync(d),bytes);rows.push(e);
}
const course=JSON.parse(fs.readFileSync(path.join(target,'courses/absorbing-walk.json'),'utf8'));
const blind={sourceSha256:m.files.find(e=>e.path==='courses/absorbing-walk.json').sha256,title:course.title,concepts:course.concepts,items:course.items.map(({id,concept,prompt,options})=>({id,concept,prompt,options}))};
fs.writeFileSync(path.join(R,'blind-course-prompts-r1.json'),JSON.stringify(blind,null,2)+'\n');
const receipt={at:new Date().toISOString(),files:rows.length,bytes:rows.reduce((s,e)=>s+e.bytes,0),allSourceCopyAndExistingPinsExact:true,readmeAppendOnly:true,authorTestsExcluded:true,answerFieldsNotExposed:true,oracleSha256:sha(fs.readFileSync(path.join(R,'finite-walk-oracle-r1.json'))),harnessSha256:sha(fs.readFileSync(path.join(R,'receive-candidate-native-r1.mjs')))};
fs.writeFileSync(path.join(R,'candidate-admission-r1.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
