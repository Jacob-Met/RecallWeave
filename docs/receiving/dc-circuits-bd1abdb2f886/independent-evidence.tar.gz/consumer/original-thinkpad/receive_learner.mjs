import assert from 'node:assert/strict';
import fs from 'node:fs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';

const qa='/tmp/recallweave-dc-learner-receiving-bd1abdb2f886';
const visible='/home/jacob/recallweave-dc-learner-receiving-bd1abdb2f886';
const root='/home/jacob/recallweave-dc-circuits-bd1abdb2f886';
const output=join(qa,'first-run');
const coursePath=join(visible,'course-from-explorer.json');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const contractBytes=await readFile(join(qa,'learner-consumer-contract.json'));
assert.equal(sha(contractBytes),'9bbd951d4e7e7a3ac1ddb2732ea8a9a68c3252daa27a8d5b3c881f6fc84cea30');
const contract=JSON.parse(contractBytes);
const pins=JSON.parse(await readFile(join(qa,'learner-native-source-pins.json')));
const helperBytes=await readFile(join(qa,'browser-helpers.mjs'));
assert.equal(sha(helperBytes),'03ceb9845d9ff65eb8f76609473831a506e5850634399d298ab8ae575fcce051');
const {withBrowser,until}=await import(pathToFileURL(join(qa,'browser-helpers.mjs')).href);
assert.equal(execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),contract.requested_current_main);
assert.equal(fs.existsSync(output),false,'First-run output must not be reused');
const sourcePins=async()=>{
 const rows=[];
 for(const expected of pins.files){
  const bytes=await readFile(join(root,expected.path));
  assert.equal(sha(bytes),expected.sha256,'Source pin '+expected.path);
  rows.push({path:expected.path,bytes:bytes.length,sha256:sha(bytes)});
 }
 for(const path of [coursePath,contract.received_course_path,join(root,'courses/dc-circuits.json')]){
  const bytes=await readFile(path);
  assert.equal(sha(bytes),contract.course_sha256,'Course pin '+path);
  rows.push({path,bytes:bytes.length,sha256:sha(bytes)});
 }
 return rows;
};
const before=await sourcePins();
const course=JSON.parse(await readFile(coursePath,'utf8'));
assert.equal(course.items.length,12);
const oracleById=new Map(contract.first_answer_oracle.map(item=>[item.id,item]));
const itemByPrompt=new Map(course.items.map(item=>[item.prompt,item]));
assert.equal(itemByPrompt.size,12);
for(const item of course.items){
 const oracle=oracleById.get(item.id);
 assert.ok(oracle,'Missing frozen oracle '+item.id);
 assert.equal(item.answer,oracle.correct_index);
 assert.equal(item.options[item.answer],oracle.correct_value);
 if(!oracle.correct)assert.equal(item.options[oracle.chosen_index],oracle.chosen_value);
}
const observations={adaptation:'The maintained learner stores this session in tab memory. Preservation is checked through the exact session DOM, course context, progress/model displays and empty browser storage; no persistence or reload restoration is claimed.',firstAnswers:[],screenshots:[]};
const report=await withBrowser({output,profileParent:visible},async api=>{
 const {evaluate,click,command,navigate,viewport,screenshot,report,downloads}=api;
 report.contractSha256=sha(contractBytes);
 report.sourceHead=contract.requested_current_main;
 report.receivedCourseSha256=contract.course_sha256;
 report.interactions=[];
 const step=async(name,action)=>{
  try{await action();report.checks.push({name,status:'passed'});console.log('PASS '+name);}
  catch(error){report.checks.push({name,status:'failed',error:error.stack});throw error;}
 };
 const clickUser=async selector=>{report.interactions.push({kind:'pointer-click',selector});await click(selector);};
 const state=()=>evaluate('(()=>({title:document.title,lesson:document.querySelector("#lesson-description").textContent,sessionMarkup:document.querySelector("#session-content").innerHTML,progress:document.querySelector(".progress-row").innerHTML,traceControls:document.querySelector("#trace-archive").innerHTML,storage:{local:Object.fromEntries(Object.entries(localStorage)),session:Object.fromEntries(Object.entries(sessionStorage))}}))()');
 const chooseFile=async()=>{
  const {root:documentNode}=await command('DOM.getDocument',{depth:0});
  const {nodeId}=await command('DOM.querySelector',{nodeId:documentNode.nodeId,selector:'#deck-file'});
  assert.ok(nodeId);
  report.interactions.push({kind:'native-file-input',selector:'#deck-file',path:coursePath});
  await command('DOM.setFileInputFiles',{nodeId,files:[coursePath]});
  await until(()=>evaluate('Boolean(document.querySelector("#start-deck"))&&!document.querySelector("#deck-preview").hidden'),'DC preview');
 };
 const choices=async attribute=>evaluate('Array.from(document.querySelectorAll("['+attribute+']")).map((b,position)=>({position,canonical:Number(b.dataset.'+(attribute==='data-choice'?'choice':'practiceChoice')+'),text:b.textContent.slice(b.querySelector(".choice-key").textContent.length).trim(),disabled:b.disabled}))');
 const reviewRows=()=>evaluate('Array.from(document.querySelectorAll(".review-item")).map(n=>({prompt:n.querySelector(".review-prompt").textContent,status:n.querySelector(".review-status").textContent,answers:Array.from(n.querySelectorAll(".review-answers dd")).map(x=>x.textContent),body:n.querySelector(".review-body").textContent,practice:n.querySelector(".review-practice-answer")?.textContent??null}))');
 let existing;
 await step('Real current learner, existing committed session and explicit preview preservation',async()=>{
  await viewport(1280,1000);
  await navigate(pathToFileURL(join(root,'demo.html')).href);
  await until(()=>evaluate('Boolean(document.querySelector("#trace-archive-panel"))'),'maintained learner initialized');
  assert.equal(await evaluate('location.protocol'),'file:');
  assert.deepEqual((await state()).storage,{local:{},session:{}});
  await clickUser('#start-button');
  await until(()=>evaluate('document.querySelectorAll("[data-choice]").length===4'),'bundled question');
  observations.seed={prompt:await evaluate('document.querySelector("#session-content h2").textContent'),options:await choices('data-choice'),canonicalChoice:0};
  await clickUser('[data-choice="0"]');
  await until(()=>evaluate('Boolean(document.querySelector("#next-button"))&&document.querySelector("[role=progressbar]").getAttribute("aria-valuenow")==="1"'),'committed bundled answer');
  existing=await state();
  observations.existingSession={...existing,sessionMarkupSha256:sha(Buffer.from(existing.sessionMarkup))};
  assert.match(existing.progress,/1 \/ 6/);
  await chooseFile();
  const preview=await evaluate('(()=>({title:document.querySelector("#deck-preview-title").textContent,count:document.querySelector(".deck-preview-count").textContent,prompts:Array.from(document.querySelectorAll("#deck-preview li strong")).map(x=>x.textContent),attribution:document.querySelector(".deck-preview-attribution").textContent,license:document.querySelector(".deck-preview-license").textContent}))()');
  assert.equal(preview.title,course.title);
  assert.match(preview.count,/12 questions · 4 concepts/);
  assert.deepEqual(preview.prompts,course.items.map(item=>item.prompt));
  assert.equal(preview.attribution,'Attribution supplied in the deck: '+course.attribution);
  assert.equal(preview.license,'License supplied in the deck: '+course.license);
  assert.deepEqual(await state(),existing,'Preview changed existing learner state');
  observations.preview=preview;
  observations.screenshots.push(await screenshot('01-preview-preserves-session.png'));
 });
 await step('Cancel preserves existing session; only Start activates the DC course',async()=>{
  await clickUser('#cancel-deck');
  await until(()=>evaluate('document.querySelector("#deck-preview").hidden'),'cancelled preview');
  assert.deepEqual(await state(),existing,'Cancel changed existing learner state');
  assert.equal(await evaluate('document.querySelector("#deck-file").value'),'');
  assert.match(await evaluate('document.querySelector("#deck-status").textContent'),/current session is unchanged/);
  await chooseFile();
  assert.deepEqual(await state(),existing,'Second preview changed existing learner state');
  await clickUser('#start-deck');
  await until(()=>evaluate('document.querySelectorAll("[data-choice]").length===4&&document.querySelector("[role=progressbar]").getAttribute("aria-valuemax")==="12"'),'DC first question');
  const started=await state();
  assert.equal(started.lesson,course.title);
  assert.equal(started.title,course.title+' — RecallWeave');
  assert.notEqual(started.sessionMarkup,existing.sessionMarkup);
  assert.equal(await evaluate('document.querySelector("[role=progressbar]").getAttribute("aria-valuenow")'),'0');
  assert.equal(await evaluate('document.querySelector("#deck-preview").hidden'),true);
  assert.equal(await evaluate('document.querySelectorAll("#feedback-slot .feedback").length'),0);
  observations.started={title:started.title,lesson:started.lesson,progress:await evaluate('document.querySelector("#step-count").textContent')};
 });
 await step('All 12 canonical first answers: 11 correct and one deliberate miss',async()=>{
  const visited=new Set();
  for(let index=0;index<12;index++){
   const prompt=await evaluate('document.querySelector("#session-content h2").textContent');
   const item=itemByPrompt.get(prompt);
   assert.ok(item,'Unexpected DC prompt '+prompt);
   assert.equal(visited.has(item.id),false,'Repeated first-session item '+item.id);
   visited.add(item.id);
   const oracle=oracleById.get(item.id);
   const expectedValue=oracle.correct?oracle.correct_value:oracle.chosen_value;
   const expectedCanonical=oracle.correct?oracle.correct_index:oracle.chosen_index;
   const displayed=await choices('data-choice');
   const matching=displayed.filter(choice=>choice.text===expectedValue);
   assert.equal(matching.length,1,'Semantic choice missing '+item.id);
   assert.equal(matching[0].canonical,expectedCanonical,'Canonical/display choice mismatch '+item.id);
   assert.equal(matching[0].disabled,false);
   await clickUser('[data-choice="'+matching[0].canonical+'"]');
   await until(()=>evaluate('Boolean(document.querySelector("#next-button"))'),'answer feedback '+item.id);
   const feedback=await evaluate('(()=>({text:document.querySelector("#feedback-slot .feedback").textContent,strong:document.querySelector("#feedback-slot .feedback strong").textContent,now:Number(document.querySelector("[role=progressbar]").getAttribute("aria-valuenow")),choices:Array.from(document.querySelectorAll("[data-choice]")).map(n=>({canonical:Number(n.dataset.choice),disabled:n.disabled,classes:n.className}))}))()');
   assert.equal(feedback.strong,oracle.correct?'That connection holds.':'Here’s the correction.');
   assert.equal(feedback.now,index+1);
   assert.ok(feedback.text.includes(item.explanation));
   assert.ok(feedback.text.includes(item.transfer));
   assert.ok(feedback.choices.every(choice=>choice.disabled));
   const selected=feedback.choices.find(choice=>choice.canonical===expectedCanonical);
   assert.ok(selected.classes.split(/\s+/).includes(oracle.correct?'correct':'incorrect'));
   observations.firstAnswers.push({sequence:index+1,item:item.id,choice:expectedCanonical,value:expectedValue,correct:oracle.correct,displayedOptions:displayed,feedback:feedback.strong});
   if(!oracle.correct)observations.screenshots.push(await screenshot('02-intentional-first-miss.png'));
   await clickUser('#next-button');
   if(index<11)await until(()=>evaluate('Boolean(document.querySelector(".question-card"))&&!document.querySelector("#next-button")'),'next unanswered DC item');
   else await until(()=>evaluate('Boolean(document.querySelector("#first-try-summary"))'),'completed learning trace');
  }
  assert.equal(visited.size,12);
  assert.equal(observations.firstAnswers.filter(answer=>answer.correct).length,11);
  const rows=await reviewRows();
  assert.equal(rows.length,12);
  for(const row of rows){
   const item=itemByPrompt.get(row.prompt),oracle=oracleById.get(item.id);
   assert.deepEqual(row.answers,[oracle.correct?oracle.correct_value:oracle.chosen_value,oracle.correct_value]);
   assert.equal(row.status,(oracle.correct?'Correct':'Needs review')+' · first try');
   assert.equal(row.practice,null);
  }
  observations.firstResults={summary:await evaluate('document.querySelector("#first-try-summary").textContent'),masteryMarkup:await evaluate('document.querySelector(".mastery-box").innerHTML'),rows};
  assert.match(observations.firstResults.summary,/11 of 12 connections on the first try/);
  assert.match(await evaluate('document.querySelector("#practice-button").textContent'),/Practice 1 missed connection/);
 });
 await step('Correct retry stays separate from the initial miss and original model state',async()=>{
  await clickUser('#practice-button');
  await until(()=>evaluate('document.querySelectorAll("[data-practice-choice]").length===4'),'single missed practice question');
  assert.equal(await evaluate('document.querySelector("#session-content h2").textContent'),course.items.find(item=>item.id==='dc-current-1').prompt);
  const displayed=await choices('data-practice-choice');
  const firstDisplay=observations.firstAnswers.find(answer=>answer.item==='dc-current-1').displayedOptions;
  assert.deepEqual(displayed.map(({disabled,...choice})=>choice),firstDisplay.map(({disabled,...choice})=>choice));
  const chosen=displayed.filter(choice=>choice.text==='3 A');
  assert.equal(chosen.length,1);
  assert.equal(chosen[0].canonical,1);
  await clickUser('[data-practice-choice="1"]');
  await until(()=>evaluate('Boolean(document.querySelector("#practice-next"))'),'correct retry feedback');
  assert.equal(await evaluate('document.querySelector("#practice-feedback .feedback strong").textContent'),'That connection holds on retry.');
  await clickUser('#practice-next');
  await until(()=>evaluate('Boolean(document.querySelector("#first-try-summary"))'),'trace after retry');
  assert.equal(await evaluate('document.querySelector("#first-try-summary").textContent'),observations.firstResults.summary);
  assert.equal(await evaluate('document.querySelector(".mastery-box").innerHTML'),observations.firstResults.masteryMarkup);
  const rows=await reviewRows();
  assert.equal(rows.filter(row=>row.status==='Needs review · first try').length,1);
  const missed=rows.find(row=>itemByPrompt.get(row.prompt).id==='dc-current-1');
  assert.deepEqual(missed.answers,['75 A','3 A']);
  assert.equal(missed.status,'Needs review · first try');
  assert.ok(missed.practice.includes('Practice answer · correct on retry'));
  assert.ok(missed.practice.endsWith('3 A'));
  assert.equal(await evaluate('document.querySelector("#practice-status").textContent'),'You answered 1 of 1 correctly on retry.');
  observations.retry={item:'dc-current-1',choice:1,value:'3 A',firstAnswer:missed.answers[0],firstStatus:missed.status,practiceText:missed.practice,firstSummaryUnchanged:true,modelDisplayUnchanged:true};
  await clickUser('.review-item:has(.needs-review) summary');
  observations.screenshots.push(await screenshot('03-first-and-retry-separate.png'));
 });
 await step('Actual study-notes download preserves all authored DC material and recorded choices',async()=>{
  await command('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:downloads,eventsEnabled:true},false);
  await clickUser('#save-notes-button');
  const started=await until(()=>report.downloadEvents.find(event=>event.method==='Browser.downloadWillBegin'),'study notes download began');
  await until(()=>report.downloadEvents.some(event=>event.method==='Browser.downloadProgress'&&event.guid===started.guid&&event.state==='completed'),'study notes download completed');
  assert.equal(basename(started.suggestedFilename),started.suggestedFilename);
  assert.match(started.suggestedFilename,/^recallweave-study-notes-\d{4}-\d{2}-\d{2}\.txt$/);
  const bytes=await readFile(join(downloads,started.suggestedFilename));
  const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  assert.ok(bytes.length>1000);
  assert.ok(text.startsWith('RecallWeave — study notes\n'+course.title+'\nSaved: '));
  assert.ok(text.includes('\n11 of 12 connections correct on the first try.\n'));
  assert.ok(text.includes('\nComplete: 1 of 1 practice answers recorded; 1 correct on retry.\n'));
  const section=text.split('\nREVIEW THE CONNECTIONS\n')[1].split('\nDECK ATTRIBUTION\n')[0].trim();
  const blocks=section.split(/\n\n(?=\d+\. )/);
  assert.equal(blocks.length,12);
  for(const item of course.items){
   const matching=blocks.filter(block=>block.split('\n')[0].endsWith('. '+item.prompt));
   assert.equal(matching.length,1,'Notes question '+item.id);
   const block=matching[0],oracle=oracleById.get(item.id);
   assert.ok(block.includes('\nYour first answer: '+(oracle.correct?oracle.correct_value:oracle.chosen_value)+'\n'));
   assert.ok(block.includes('\nFirst try: '+(oracle.correct?'correct':'needs review')+'\n'));
   assert.ok(block.includes('\nCorrect answer: '+oracle.correct_value+'\n'));
   assert.ok(block.includes('\nExplanation: '+item.explanation+'\n'));
   assert.ok(block.includes('\nApply the idea: '+item.transfer));
   if(item.id==='dc-current-1'){
    assert.ok(block.includes('\nPractice answer: 3 A\n'));
    assert.ok(block.endsWith('Practice result: correct on retry'));
   }else assert.equal(block.includes('\nPractice answer:'),false);
  }
  assert.ok(text.includes('\nDECK ATTRIBUTION\n'+course.attribution+'\n'+course.license+'\n'));
  assert.equal((text.match(/^Your first answer: /gm)??[]).length,12);
  assert.equal((text.match(/^First try: needs review$/gm)??[]).length,1);
  assert.equal((text.match(/^Practice answer: /gm)??[]).length,1);
  await writeFile(join(output,'study-notes.txt'),bytes,{flag:'wx'});
  observations.notes={suggestedFilename:started.suggestedFilename,bytes:bytes.length,sha256:sha(bytes),questions:12,firstCorrect:11,firstMisses:1,practiceAnswers:1,correctRetries:1,allAuthoredExplanationsAndTransfersPreserved:true};
  assert.equal(await evaluate('document.querySelector("#first-try-summary").textContent'),observations.firstResults.summary);
 });
 await step('Offline native browser, empty storage, and unchanged received course/source',async()=>{
  assert.deepEqual((await state()).storage,{local:{},session:{}});
  assert.equal(report.pageErrors.length,0);
  const nonlocal=report.requests.filter(request=>!['file:','blob:','data:','about:'].some(prefix=>request.url.startsWith(prefix)));
  assert.deepEqual(nonlocal,[]);
  assert.deepEqual(await sourcePins(),before);
  observations.network={requests:report.requests,nonlocalRequests:nonlocal.length,pageErrors:report.pageErrors.length};
 });
 report.receiving=observations;
 await writeFile(join(output,'observations.json'),JSON.stringify(observations,null,2)+'\n',{flag:'wx'});
});
const after=await sourcePins();
const receipt={schema:'independent-dc-learner-receipt/1',at:new Date().toISOString(),node:process.version,platform:process.platform,architecture:process.arch,sourceHead:contract.requested_current_main,driverSha256:sha(await readFile(fileURLToPath(import.meta.url))),helperSha256:sha(helperBytes),contractSha256:sha(contractBytes),courseSha256:contract.course_sha256,sourceBefore:before,sourceAfter:after,sourceUnchanged:JSON.stringify(before)===JSON.stringify(after),status:report.status,checks:report.checks,firstAnswers:observations.firstAnswers,retry:observations.retry,notes:observations.notes,browser:report.browser,cleanup:report.cleanup,browserReportSha256:sha(await readFile(join(output,'browser-report.json')))};
await writeFile(join(output,'native-receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:receipt.status,checks:receipt.checks,driverSha256:receipt.driverSha256,nativeReceiptSha256:sha(await readFile(join(output,'native-receipt.json'))),notes:receipt.notes,cleanup:receipt.cleanup},null,2));
process.exitCode=receipt.status==='passed'?0:1;
