const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),out=path.join(__dirname,'newton-receiving');fs.mkdirSync(out,{recursive:true});
const label=process.argv[2]||'author-initial';
const inputs=['src/newton-method.mjs','src/newton-method-ui.mjs','courses/newton-method.json','courses/newton-method.md','courses/newton-method-explorer.template.html','tools/build-newton-method.mjs','tests/newton-method.test.mjs','tests/newton-method-course.test.mjs'];
const pin=()=>Object.fromEntries(inputs.map(file=>{const b=fs.readFileSync(path.join(root,file));return [file,{bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')}];}));
const before=pin(),runs=[],startedAt=new Date().toISOString();
function run(name,args){const start=new Date().toISOString();const r=cp.spawnSync(process.execPath,args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024,env:process.env});fs.writeFileSync(path.join(out,label+'-'+name+'.log'),(r.stdout||'')+(r.stderr||''));const item={name,args,startedAt:start,finishedAt:new Date().toISOString(),status:r.status,error:r.error?.message};runs.push(item);console.log(JSON.stringify(item));return r.status===0;}
let success=run('build',['tools/build-newton-method.mjs']);
if(success)success=run('focused',['--test','tests/newton-method.test.mjs','tests/newton-method-course.test.mjs']);
if(success)success=run('full',['--test',...fs.readdirSync(path.join(root,'tests')).filter(name=>name.endsWith('.test.mjs')).sort().map(name=>'tests/'+name)]);
const after=pin(),artifact=path.join(root,'courses/newton-method-explorer.html');const bytes=fs.existsSync(artifact)?fs.readFileSync(artifact):null;
const receipt={startedAt,finishedAt:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,before,after,inputsUnchanged:JSON.stringify(before)===JSON.stringify(after),artifact:bytes?{path:'courses/newton-method-explorer.html',bytes:bytes.length,sha256:crypto.createHash('sha256').update(bytes).digest('hex')}:null,runs};
fs.writeFileSync(path.join(out,label+'.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));process.exitCode=success&&receipt.inputsUnchanged?0:1;
