#!/usr/bin/env python3
"""Recompute independent detached explorer evidence without executing product code."""
from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as ET,copy,struct,sys

NATIVE='/Users/me/recall-prefix-review-066deeadcc8b/'
HTML_SHA='1bbec3f25e91a57b50520274f53c29e5e08859a86a0cf6d646f4760c6f27e2b0'
FIXTURE_SHA='84ca47b48786c2edf47eea5a053e5fd973b985b0033c151e923d2af42d044290'
def need(value,message):
    if not value:raise ValueError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def js(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def own_module(files,name):
    s={'__name__':'independent_saved_'+name,'__file__':name};exec(compile(files[name],name,'exec'),s);return s
def symbols(model,node_id):
    n=model['nodes'][node_id]
    return [n['symbol']] if n['symbol'] is not None else symbols(model,n['left'])+symbols(model,n['right'])
def tree_nodes(model,roots):
    seen=set()
    def visit(i):
        need(i not in seen,'duplicate node in expected forest');seen.add(i);n=model['nodes'][i]
        if n['symbol'] is None:visit(n['left']);visit(n['right'])
    for i in roots:visit(i)
    return seen
def description(model,i):
    n=model['nodes'][i]
    return (js(n['symbol'])+' count '+str(n['weight'])) if n['symbol'] is not None else (
      'count '+str(n['weight'])+', zero to ('+description(model,n['left'])+'), one to ('+description(model,n['right'])+')')
def verify_svg(raw,model,step):
    svg=ET.fromstring(raw);roots=model['steps'][step-1]['after'] if step else model['steps'][0]['before']
    expected=tree_nodes(model,roots);groups=svg.findall('g')
    actual={int(g.attrib['data-node-id']):g for g in groups}
    need(len(actual)==len(groups) and set(actual)==expected,'SVG active forest membership')
    need(svg.attrib.get('role')=='img' and svg.attrib.get('aria-labelledby')=='tree-title tree-description','SVG accessible identity')
    need(svg.find('desc').text=='; '.join(description(model,i) for i in roots),'SVG complete accessible literal tree')
    title='Separate symbol trees before merging' if step==0 else 'Code forest after merge '+str(step)
    need(svg.find('title').text==title,'SVG current-step title')
    positions={}
    for i,g in actual.items():
        n=model['nodes'][i];texts={t.attrib.get('class'):t.text for t in g.findall('text')}
        if n['symbol'] is None:
            c=g.find('circle');need(c is not None and texts.get('node-count')==str(n['weight']),'SVG internal weight')
            positions[i]=(float(c.attrib['cx']),float(c.attrib['cy']))
            need(g.find('title').text=='Combined tree · count '+str(n['weight']),'SVG internal title')
        else:
            r=g.find('rect');need(r is not None,'SVG leaf shape')
            positions[i]=(float(r.attrib['x'])+float(r.attrib['width'])/2,float(r.attrib['y'])+float(r.attrib['height'])/2)
            label=n['symbol'][:7]+('…' if len(n['symbol'])>7 else '')
            need(texts.get('leaf-label')==js(label) and texts.get('leaf-count')==str(n['weight']),'SVG literal visible leaf/weight')
            need(g.find('title').text==js(n['symbol'])+' · count '+str(n['weight']),'SVG complete leaf title')
    edges=[];children=list(svg)
    for index,p in enumerate(children):
        if p.tag!='path':continue
        m=re.fullmatch(r'M([-\d.]+),([-\d.]+) L([-\d.]+),([-\d.]+)',p.attrib['d'])
        need(m is not None,'SVG edge is a finite straight segment');x1,y1,x2,y2=map(float,m.groups())
        def closest(x,y):return min(positions,key=lambda i:(positions[i][0]-x)**2+(positions[i][1]-y)**2)
        parent,child=closest(x1,y1),closest(x2,y2)
        need(index+1<len(children) and children[index+1].tag=='text' and children[index+1].attrib.get('class')=='edge-bit','SVG edge has its bit label')
        bit=children[index+1].text;edges.append((parent,child,bit))
        need(y2>y1 and positions[parent][1]<positions[child][1],'SVG edges go toward descendant depth')
        need((bit=='0' and positions[child][0]<positions[parent][0]) or (bit=='1' and positions[child][0]>positions[parent][0]),'SVG left/right bit orientation')
    expected_edges={(i,n[side],bit) for i in expected for n in [model['nodes'][i]] if n['symbol'] is None for side,bit in [('left','0'),('right','1')]}
    need(len(edges)==len(set(edges)) and set(edges)==expected_edges,'SVG graph edges differ from oracle')
    return len(actual),len(edges)
def verify_snapshot(s,model,step,phase):
    need(s['documentWidth']<=s['width']+1 and s['fixtureTags']==0,'snapshot viewport or interpreted markup')
    need(s['localStorageKeys']==[] and s['sessionStorageKeys']==[],'snapshot browser persistence')
    need(s['labels']==[r['symbol'] for r in model['rows']],'literal editor values')
    need(s['courseDownloadDisabled'] is False,'lesson export independently available')
    if phase=='invalid-count':
        need(s['counts'][0]=='1.5' and s['book']==[] and s['queue']==[],'invalid count retains no derived table')
        need(len(list(ET.fromstring(s['svg'])))==0 and s['payload']=='—' and s['fixedPayload']=='—','invalid count retains no graph/cost')
        need(s['downloadDisabled'] is True and bool(s['inputError'].strip()) and s['bits']=='' and s['decoded']=='','invalid count retires export/decoder')
        return 0,0
    need([int(x) for x in s['counts']]==[r['count'] for r in model['rows']],'visible counts')
    expected_book=[[js(c['symbol']),str(c['count']),c['code'],str(c['length']),str(c['cost'])] for c in model['codebook']]
    need(s['book']==expected_book,'complete visible final codebook')
    t=model['totals'];need(s['payload']==str(t['payloadBits']) and s['fixedPayload']==str(t['fixedPayloadBits']),'visible exact payload arithmetic')
    avg=re.fullmatch(r'(\d+) / (\d+) ≈ (\d+\.\d{4})',s['average'])
    need(avg is not None and int(avg[1])==t['payloadBits'] and int(avg[2])==t['totalCount'] and abs(float(avg[3])-t['averageBits'])<=0.0000500001,'exact average fraction/qualified rounding')
    roots=model['steps'][step-1]['after'] if step else model['steps'][0]['before']
    expected_queue=[[js(symbols(model,i)),str(model['nodes'][i]['weight']),'Next pair' if len(roots)>1 and j<2 else ''] for j,i in enumerate(roots)]
    need(s['queue']==expected_queue,'queue literal membership, order and next-pair identity')
    wanted_step=('Before merging · '+str(len(roots))+' trees') if step==0 else ('Merge '+str(step)+' of '+str(len(model['steps']))+' · '+str(len(roots))+(' tree' if len(roots)==1 else ' trees'))
    need(s['step']==wanted_step,'current visible step')
    need(not s['inputError'],'valid counts not rejected')
    if phase=='invalid-decoder':
        need(s['bits']=='2' and s['decoded']=='' and s['trace']==[] and s['downloadDisabled'] is True,'invalid decoder retires current export')
    else:need(s['downloadDisabled'] is False,'valid example download')
    if phase in ('rebuilt','repaired','finished'):
        need(s['bits']=='' and s['decoded']=='[]' and s['trace']==[],'edits/reset empty decoder')
    return verify_svg(s['svg'],model,step)
def verify(files):
    data=lambda n:files[n];doc=lambda n:json.loads(data(n))
    model_helper=own_module(files,'verify_model_evidence.py');oracle=own_module(files,'oracle.py')
    fixture=doc('explorer-fixtures.json');need(sha(data('explorer-fixtures.json'))==FIXTURE_SHA,'pre-candidate explorer fixture')
    need(fixture['candidate_inspected'] is False and len(fixture['cases'])==11,'fixture chronology/count')
    by_name={x['name']:x for x in fixture['cases']}
    for c in fixture['cases']:need(c['expected']==oracle['deterministic_witness'](c['rows']),'independent explorer oracle regeneration')
    freeze=doc('ui-v2/candidate-v2-freeze.json')
    need(sha(data('ui-v2/candidate-v2-freeze.json'))=='626654f57ba2e0e69d7a38f582cdd24aef416fa77afcf33a38923ce6c3a32932','candidate source freeze')
    custody=doc('ui-v2/custody.json');tree=doc('evidence/canonical-tree.json');leaves={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    need(len(custody['source'])==46 and len(freeze['source'])==10 and len(freeze['canonical_unchanged_files'])==36,'UI source closure')
    for p,row in custody['source'].items():
        b=data('ui-v2/source/'+p);git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        need(len(b)==row['bytes'] and sha(b)==row['sha256'] and git==row['git_blob'],'frozen UI source bytes')
        if p in freeze['source']:need(freeze['source'][p]=={'bytes':len(b),'sha256':sha(b),'git_blob':git},'authored source freeze mapping')
        else:need(git==freeze['canonical_unchanged_files'][p]==leaves[p]['sha'],'canonical 36-file source mapping')
    html=data('ui-v2/source/courses/prefix-coding-explorer.html');need(sha(html)==HTML_SHA and len(html)==49715,'delivered HTML')
    src=lambda p:data('ui-v2/source/'+p).decode()
    model=re.sub(r'^export ','',src('src/prefix-coding.mjs'),flags=re.M)
    ui=re.sub(r'^export ','',re.sub(r'^import [^\n]+\n','',src('src/prefix-coding-ui.mjs'),count=1),flags=re.M)
    literal=js(src('courses/prefix-coding.json')).replace('<',r'\u003c').replace('\u2028',r'\u2028').replace('\u2029',r'\u2029')
    rebuilt=src('templates/prefix-coding-explorer.html')
    for marker,text in [('/* PREFIX_MODEL */',model),('/* PREFIX_DECK */','const LESSON_JSON = '+literal+';'),('/* PREFIX_UI */',ui)]:
        need(rebuilt.count(marker)==1,'exact standalone marker');rebuilt=rebuilt.replace(marker,re.sub(r'</script',r'<\\/script',text,flags=re.I))
    need(rebuilt.encode()==html==data('ui-v2-rebuild/courses/prefix-coding-explorer.html'),'independent and actual builder output')
    need(data('ui-v2/source/src/prefix-coding.mjs')==data('model-v2/prefix-coding.mjs'),'accepted model preserved in UI')
    for p in ['courses/prefix-coding.json','courses/prefix-coding.md','tests/prefix-coding-course.test.mjs']:
        need(data('ui-v2/source/'+p)==data('course-v1/'+p),'accepted course preserved in UI')
    old=data('receive_explorer_v2.mjs');new=data('receive_explorer_v3.mjs')
    need(sha(old)=='9df103f2decfb0f7fb757edc4d73f19582681e16cca0169ce6389ed4e8a00bd9' and sha(new)=='8d424f1794683e3e6d4d60f4e3c6fa48c768e61bb922cfa7d23b5ce0c3273b88','executed observer identities')
    need(old.replace(b"   await page.locator('#step-reset').click();const backDisabled",b"   if(model.steps.length>1)await page.locator('#step-reset').click();const backDisabled",1)==new,'only two-symbol observer correction')
    subset=doc('explorer-boundary-fixture.json');need(subset['cases']==[by_name['scalar-label-boundary']],'one unchanged boundary-case fixture')
    reports=[('ui-v2-explorer',217,2,11),('ui-v2-boundary',23,0,1)]
    complete={};states=nodes=edges=download_count=0;recorded_reports=[]
    for directory,passed,failed,count in reports:
        report=doc(directory+'/report.json')
        need(report['passedChecks']==passed and report['failedChecks']==failed and len(report['cases'])==count,'original/supplement counts')
        need(sum(bool(x['ok']) for x in report['checks'])==passed and len(report['checks'])==passed+failed,'check bookkeeping')
        need(report['sourceHtmlSha256']==report['sourceAfterSha256']==HTML_SHA,'served original HTML binding')
        need(report['courseSha256']==report['courseAfterSha256']==sha(data('course-v1/courses/prefix-coding.json')),'course input binding')
        need(not report['pageErrors'] and not report['blockedRequests'] and not report.get('harnessError'),'browser errors/network/harness')
        failures=[x['name'] for x in report['checks'] if not x['ok']]
        need(failures==(['scalar-label-boundary:browser-complete','all-declared-cases-complete'] if failed else []),'only attributed original observer failures')
        if failed:need(len(report['negativeControls'])==1 and report['negativeControls'][0]['rejected'] is True,'actual altered-export control')
        for c in report['cases']:
            item=by_name[c['name']];m=model_helper['canonical_model'](item['expected'])
            need(c['rows']==item['rows'] and c['width']==item['width'],'actual case/viewport identity')
            need(doc(directory+'/'+c['name']+'/case.json')==c,'complete individual raw case')
            need(data(directory+'/'+c['name']+'/detached/explorer.html')==html,'only detached HTML source')
            last_step=0
            for state in c['states']:
                phase=state['phase'];last_step=state.get('step',last_step);s=state['observation']
                n,e=verify_snapshot(s,m,last_step,phase);states+=1;nodes+=n;edges+=e
                if phase=='decoded':
                    wanted=model_helper['message'](m,[r['symbol'] for r in m['rows']])
                    need(s['bits']==wanted['bits'] and json.loads(s['decoded'])==wanted['symbols'],'actual decoded symbol order')
                    need(s['trace']==['Bits '+str(z['start']+1)+'–'+str(z['end'])+': '+z['code']+' → '+js(z['symbol']) for z in wanted['segments']],'actual readable one-based inclusive trace')
            if 'observerError' in c:
                need(c['name']=='scalar-label-boundary' and len(c['states'])==3 and c['states'][-1]['step']==0 and 'step-reset' in c['observerError'],'original interrupted two-symbol context')
                continue
            need(c['name'] not in complete,'duplicate complete cohort');complete[c['name']]=directory
            need(c['states'][-1]['phase']=='finished','complete cohort ends finished')
            for name in ['viewport.png','full-page.png']:
                b=data(directory+'/'+c['name']+'/'+name)
                need(b[:8]==b'\x89PNG\r\n\x1a\n','actual PNG capture')
                w,h=struct.unpack('>II',b[16:24]);need(w==item['width'] and h>=900,'actual screenshot viewport')
        for request in report['requests']:
            need(request['method']=='GET' and request['url']=='file://'+NATIVE+directory+'/'+request['case']+'/detached/explorer.html','only actual detached document request')
        need(len(report['requests'])==count,'one request per actual detached context')
        for d in report['downloads']:
            need(d['path'].startswith(NATIVE+directory+'/'),'download path custody')
            name=d['path'][len(NATIVE):];b=data(name)
            need(len(b)==d['bytes'] and sha(b)==d['sha256'],'actual download bytes')
            cohort=name.split('/')[1]
            if d['label']=='lesson-during-invalid-example':
                need(b==data('course-v1/courses/prefix-coding.json') and d['suggestedFilename']=='prefix-coding.json','actual independent literal lesson download')
            else:
                need(d['label']=='worked-example' and d['suggestedFilename']=='prefix-coding-example.json','actual example filename')
                m=model_helper['canonical_model'](by_name[cohort]['expected'])
                wanted={'format':'recallweave.prefix-coding/1','model':m,'inspection':{'step':len(m['steps'])//2},'decoding':model_helper['message'](m,[r['symbol'] for r in m['rows']])}
                need(json.loads(b)==wanted and b==model_helper['js_json'](wanted),'exact browser example model and serialized bytes')
            download_count+=1
        recorded_reports.append({'directory':directory,'passed':passed,'failed':failed,'cases':count,'sha256':sha(data(directory+'/report.json'))})
    need(set(complete)==set(by_name) and download_count==12,'all 11 independent cohorts/12 actual downloads')
    keyboard=doc('ui-v2-keyboard/report.json')
    need(keyboard['htmlSha256']==keyboard['sourceAfterSha256']==HTML_SHA and keyboard['fixtureSha256']==FIXTURE_SHA,'keyboard source/fixture identity')
    need(keyboard['passed']==10 and keyboard['failed']==0 and all(c['ok'] for c in keyboard['checks']) and not keyboard['errors'],'keyboard actual results')
    need([c['name'] for c in keyboard['cases']]==['eight-equal','skew-seven'] and len(keyboard['requests'])==2,'bounded keyboard cohorts')
    for c in keyboard['cases']:
        m=model_helper['canonical_model'](by_name[c['name']]['expected']);left=c['states'][0];right=c['states'][1]
        need(left['phase']=='left' and left['focused'] and left['tabindex']==0 and left['scrollWidth']>left['width'],'focusable wide forest')
        need(right['phase']=='right' and right['focused'] and right['left']>0 and right['left']+right['width']>=right['scrollWidth']-1,'right arrow reaches all horizontal content')
        need(c['keys'] and all(k in ('ArrowRight','ArrowDown') for k in c['keys']),'only keyboard navigation')
        for s in c['states']:
            need(s['documentWidth']<=s['viewport']+1,'keyboard surface stays in viewport')
            verify_svg(s['svg'],m,len(m['steps']))
        if len(c['states'])==3:need(c['states'][2]['top']>left['top'] and 'ArrowDown' in c['keys'],'vertical keyboard movement')
    negative=[]
    sample=doc('ui-v2-explorer/report.json')['cases'][0]['states'][1]['observation']
    m=model_helper['canonical_model'](by_name['declared-default']['expected'])
    altered=re.sub(r'(<text[^>]+class="edge-bit"[^>]*>)0(</text>)',r'\g<1>1\2',sample['svg'],count=1)
    need(altered!=sample['svg'],'prepared graph negative')
    try:verify_svg(altered,m,1)
    except ValueError as e:
        need('orientation' in str(e) or 'graph edges' in str(e),'graph negative semantic boundary');negative.append('changed actual SVG edge bit')
    need(len(negative)==1,'altered graph accepted')
    tie=next(c for c in doc('ui-v2-explorer/report.json')['cases'] if c['name']=='leaf-parent-tie')
    s=copy.deepcopy(tie['states'][0]['observation']);s['queue'][0][0],s['queue'][1][0]=s['queue'][1][0],s['queue'][0][0]
    try:verify_snapshot(s,model_helper['canonical_model'](by_name['leaf-parent-tie']['expected']),0,'rebuilt')
    except ValueError as e:
        need('queue literal membership' in str(e),'queue negative semantic boundary');negative.append('equal-weight queue labels swapped')
    need(len(negative)==2,'altered queue accepted')
    for stem,code,driver in [('ui-v2-explorer',1,'receive_explorer_v2.mjs'),('ui-v2-boundary',0,'receive_explorer_v3.mjs'),('ui-v2-keyboard',0,'receive_tree_keyboard.mjs')]:
        p=doc('evidence/'+stem+'-process.json')
        need(p['returncode']==code and p['argv'][1]==NATIVE+driver and p['argv'][2]==NATIVE+'ui-v2/source/courses/prefix-coding-explorer.html','actual process/source command')
        for kind in ['stdout','stderr']:
            z=p[kind];b=data(z['path'][len(NATIVE):]);need(len(b)==z['bytes'] and sha(b)==z['sha256'],'actual process stdout/stderr')
    return {'schema':'recall-prefix-independent-explorer-verification-v1','html_sha256':HTML_SHA,'source_files':46,'canonical_files':36,
      'actual_builder_and_independent_reconstruction_exact':True,'actual_reports':recorded_reports,'complete_input_cohorts':11,'saved_states_recomputed':states,
      'saved_svg_node_occurrences':nodes,'saved_svg_edge_occurrences':edges,'actual_downloads':12,'worked_example_downloads':11,'exact_course_downloads':1,
      'keyboard_cohorts':2,'keyboard_checks':10,'observer_correction':'skip redundant already-zero two-symbol reset; source unchanged',
      'semantic_raw_negatives':negative,'product_execution_during_verification':False}
def main():
    import verify_foundation as f
    root=Path(sys.argv[1]);out=verify(f.logical_files(root));b=(json.dumps(out,indent=2)+'\n').encode();Path(sys.argv[2]).write_bytes(b);print(b.decode())
if __name__=='__main__':main()
