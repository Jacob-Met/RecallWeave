#!/usr/bin/env node
/** New-course receiving through the unchanged accepted RecallWeave author page. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, mkdtemp, rm } from 'node:fs/promises';
import { extname, join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const arg = (key, fallback) => process.argv.includes(key) ? process.argv[process.argv.indexOf(key) + 1] : fallback;
const project = resolve(arg('--root', '../source'));
const output = resolve(arg('--output', './author-browser'));
const executable = arg('--browser', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
await mkdir(output, { recursive: true });
const downloadsPath = join(output, 'downloads'); await mkdir(downloadsPath, { recursive: true });
const profile = await mkdtemp(join(output, 'profile-'));
const coursePath = join(project, 'courses/binary-search.json');
const courseRaw = await readFile(coursePath, 'utf8');
const { parseDeck, serializeDeck } = await import(pathToFileURL(join(project, 'src/deck.mjs')));
const course = parseDeck(courseRaw);
const report = { status: 'running', project, courseSha256: createHash('sha256').update(courseRaw).digest('hex'),
  node: process.version, checks: [], downloads: [], captures: [], sourceSha256: {}, pageErrors: [], externalRequests: [] };
const sourcePaths = ['author.html', 'author/index.html', 'author/author.css', 'src/deck.mjs',
  'src/deck-author.mjs', 'src/deck-author-loader.mjs', 'src/deck-author-ui.mjs', 'tools/make_author.py'];
for (const name of sourcePaths) report.sourceSha256[name] = createHash('sha256').update(await readFile(join(project, name))).digest('hex');

const server = createServer(async (request, response) => {
  try {
    const name = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    const path = resolve(project, `.${name}`);
    if (!path.startsWith(project + '/')) { response.writeHead(403).end(); return; }
    const body = await readFile(path);
    const mime = { '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json' }[extname(path)] ?? 'application/octet-stream';
    response.writeHead(200, { 'Content-Type': mime + '; charset=utf-8' }).end(body);
  } catch { response.writeHead(404).end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const base = `http://127.0.0.1:${server.address().port}`;
let browser, socket, sessionId, targetId, sequence = 0, browserLog = '';
const pending = new Map(), downloads = new Map();
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function until(check, label) {
  let last;
  for (let i = 0; i < 160; i++) {
    try { if (await check()) return; } catch (error) { last = error; }
    await delay(100);
  }
  throw new Error(`Timed out: ${label}${last ? ': ' + last.message : ''}`);
}
function command(method, params = {}, scoped = true) {
  const id = ++sequence;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(new Error('CDP timeout ' + method)); }, 10000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params, ...(scoped && sessionId ? { sessionId } : {}) }));
  });
}
async function evaluate(expression) {
  const result = await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
  return result.result.value;
}
async function activate(selector) {
  assert.ok(await evaluate(`!!document.querySelector(${JSON.stringify(selector)})`), selector);
  await evaluate(`document.querySelector(${JSON.stringify(selector)}).focus()`);
  for (const type of ['keyDown', 'keyUp']) await command('Input.dispatchKeyEvent', {
    type, key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13,
    ...(type === 'keyDown' ? { text: '\r', unmodifiedText: '\r' } : {})
  });
}
async function documentAt(url, width = 1280) {
  if (targetId) await command('Target.closeTarget', { targetId }, false);
  ({ targetId } = await command('Target.createTarget', { url: 'about:blank' }, false));
  ({ sessionId } = await command('Target.attachToTarget', { targetId, flatten: true }, false));
  for (const method of ['Page.enable', 'Runtime.enable', 'Network.enable']) await command(method);
  await command('Emulation.setDeviceMetricsOverride', { width, height: width === 390 ? 844 : 1000, deviceScaleFactor: 1, mobile: false });
  await command('Page.navigate', { url });
  await until(() => evaluate(`document.readyState === 'complete' && document.URL === ${JSON.stringify(url)} && !!document.querySelector('#open-deck')`), 'author document');
}
async function choose(path) {
  const { root } = await command('DOM.getDocument');
  const { nodeId } = await command('DOM.querySelector', { nodeId: root.nodeId, selector: '#open-deck' });
  await command('DOM.setFileInputFiles', { nodeId, files: [path] });
  await until(() => evaluate("!document.querySelector('#open-preview').hidden"), 'incoming course preview');
}
const meta = () => evaluate("['title','attribution','license'].map(id=>document.querySelector('#deck-'+id).value)");
function passed(name, details = {}) { report.checks.push({ name, ...details }); console.log('PASS ' + name); }
async function capture(name, selector) {
  await evaluate(`document.querySelector(${JSON.stringify(selector)}).scrollIntoView({block:'start'})`);
  const { data } = await command('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  const bytes = Buffer.from(data, 'base64'); await writeFile(join(output, name), bytes);
  report.captures.push({ name, sha256: createHash('sha256').update(bytes).digest('hex') });
}

async function receive(label, url, width) {
  await documentAt(url, width);
  const before = await meta();
  await choose(coursePath);
  assert.equal(await evaluate("document.querySelector('#open-preview-title').textContent"), `Open “${course.title}”?`);
  assert.match(await evaluate("document.querySelector('#open-preview-summary').textContent"), /12 questions · 4 concepts/);
  assert.deepEqual(await meta(), before);
  await activate('#cancel-open');
  assert.deepEqual(await meta(), before);
  assert.equal(await evaluate("document.querySelector('#open-preview').hidden"), true);
  passed(label + ': actual course preview and cancellation preserve the editor');

  await choose(coursePath);
  await activate('#replace-draft');
  assert.deepEqual(await meta(), [course.title, course.attribution, course.license]);
  assert.equal(await evaluate("document.querySelector('#question-picker').options.length"), course.items.length);
  const observed = [];
  for (let index = 0; index < course.items.length; index++) {
    await evaluate(`{const select=document.querySelector('#question-picker');select.selectedIndex=${index};select.dispatchEvent(new Event('change',{bubbles:true}));}`);
    const value = await evaluate(`({prompt:document.querySelector('#question-prompt').value,
      options:[...document.querySelectorAll('#option-list textarea')].map(node=>node.value),
      answer:[...document.querySelectorAll('#option-list input[type=radio]')].findIndex(node=>node.checked),
      concept:document.querySelector('#question-concept').selectedOptions[0].textContent,
      prerequisites:[...document.querySelectorAll('#question-prerequisites-list label')].filter(node=>node.querySelector('input').checked).map(node=>node.querySelector('span').textContent),
      explanation:document.querySelector('#question-explanation').value,
      transfer:document.querySelector('#question-transfer').value})`);
    const expected = course.items[index];
    assert.deepEqual(value, { prompt: expected.prompt, options: expected.options, answer: expected.answer,
      concept: expected.concept, prerequisites: expected.prerequisites, explanation: expected.explanation, transfer: expected.transfer });
    observed.push({ id: expected.id, ...value });
  }
  await writeFile(join(output, label + '-editor-content.json'), JSON.stringify(observed, null, 2) + '\n');
  passed(label + ': all twelve editor questions retain exact text, choices, answer identity and links');

  await activate('#check-draft');
  assert.equal(await evaluate("document.querySelector('#author-error').hidden"), true);
  assert.equal(await evaluate("document.querySelector('#author-preview').hidden"), false);
  const preview = await evaluate(`([...document.querySelectorAll('#preview-content details')].map(node=>({
    prompt:node.querySelector('.preview-prompt').textContent,
    options:[...node.querySelectorAll('.preview-options li')].map(option=>option.firstChild.textContent),
    answer:[...node.querySelectorAll('.preview-options li')].findIndex(option=>option.classList.contains('correct')),
    detail:[...node.querySelectorAll('.preview-detail')].map(paragraph=>paragraph.lastChild.textContent)
  })))`);
  assert.deepEqual(preview, course.items.map(question => ({ prompt: question.prompt, options: question.options,
    answer: question.answer, detail: [question.explanation, question.transfer] })));
  assert.equal(await evaluate('document.documentElement.scrollWidth > innerWidth'), false);
  await capture(label + '-preview.png', '#author-preview');
  passed(label + ': accepted author preview displays the full course with no viewport overflow');

  const known = new Set(downloads.keys());
  await activate('#download-deck');
  let download;
  await until(() => { download = [...downloads.values()].find(value => !known.has(value.guid) && value.state === 'completed'); return !!download; }, 'actual course download');
  const path = join(downloadsPath, download.guid);
  const bytes = await readFile(path);
  const exported = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  assert.equal(exported, serializeDeck(course));
  assert.deepEqual(parseDeck(exported), course);
  const name = label + '-authored-course.json'; await writeFile(join(output, name), bytes);
  report.downloads.push({ name, filename: download.suggestedFilename, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
  await documentAt(url, width);
  await choose(path); await activate('#replace-draft'); await activate('#check-draft');
  assert.equal(await evaluate("document.querySelector('#preview-content details:last-of-type .preview-prompt').textContent"), course.items.at(-1).prompt);
  assert.equal(await evaluate("document.querySelector('#question-picker').options.length"), 12);
  passed(label + ': actual checked download reopens and retains the canonical course');
}

try {
  browser = spawn(executable, ['--headless=new', '--no-sandbox', '--disable-gpu', '--disable-background-networking',
    '--disable-component-update', '--disable-sync', '--no-first-run', '--no-default-browser-check',
    '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', `--user-data-dir=${profile}`, 'about:blank'], { stdio: ['ignore', 'ignore', 'pipe'] });
  browser.stderr.on('data', bytes => { browserLog = (browserLog + bytes.toString()).slice(-6000); });
  let port, endpoint;
  await until(async () => {
    if (browser.exitCode !== null) throw new Error('Browser exited: ' + browserLog);
    [port, endpoint] = (await readFile(join(profile, 'DevToolsActivePort'), 'utf8')).trim().split('\n');
    return !!(port && endpoint);
  }, 'Chrome startup');
  socket = new WebSocket(`ws://127.0.0.1:${port}${endpoint}`);
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id) {
      const request = pending.get(message.id); if (!request) return;
      pending.delete(message.id); clearTimeout(request.timer);
      if (message.error) request.reject(new Error(message.error.message)); else request.resolve(message.result);
    } else if (message.method === 'Browser.downloadWillBegin' || message.method === 'Browser.downloadProgress') {
      const value = message.params; downloads.set(value.guid, { ...downloads.get(value.guid), ...value });
    } else if (message.method === 'Runtime.exceptionThrown') {
      report.pageErrors.push(message.params.exceptionDetails.exception?.description ?? message.params.exceptionDetails.text);
    } else if (message.method === 'Network.requestWillBeSent') {
      const { request } = message.params;
      const allowed = request.url.startsWith(base + '/') || request.url.startsWith(pathToFileURL(project + '/').href) || /^(data|blob):/.test(request.url);
      if (!allowed) report.externalRequests.push(request.url);
    }
  });
  await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
  report.browser = await command('Browser.getVersion', {}, false);
  await command('Browser.setDownloadBehavior', { behavior: 'allowAndName', downloadPath: downloadsPath, eventsEnabled: true }, false);
  await receive('desktop-http', base + '/author/index.html', 1280);
  await receive('phone-file', pathToFileURL(join(project, 'author.html')).href, 390);
  assert.deepEqual(report.pageErrors, []);
  assert.deepEqual(report.externalRequests, []);
  for (const path of sourcePaths) assert.equal(createHash('sha256').update(await readFile(join(project, path))).digest('hex'), report.sourceSha256[path]);
  assert.equal(createHash('sha256').update(await readFile(coursePath)).digest('hex'), report.courseSha256);
  passed('accepted renderer sources and course bytes remain unchanged; no external request or page error');
  report.status = 'passed';
} catch (error) {
  report.status = 'failed'; report.error = error.stack; process.exitCode = 1;
} finally {
  report.browserLog = browserLog;
  await writeFile(join(output, 'receipt.json'), JSON.stringify(report, null, 2) + '\n');
  if (socket?.readyState === WebSocket.OPEN) {
    try { await command('Browser.close', {}, false); } catch { }
    socket.close();
  }
  for (const request of pending.values()) { clearTimeout(request.timer); request.reject(new Error('Receiver closed')); }
  pending.clear(); browser?.kill('SIGTERM');
  await new Promise(resolve => server.close(resolve));
  await delay(300); await rm(profile, { recursive: true, force: true, maxRetries: 3 });
  console.log(JSON.stringify({ status: report.status, checks: report.checks.length, downloads: report.downloads.length, error: report.error, receipt: join(output, 'receipt.json') }));
}
