# Public wire schema — absorbing walk, 2026-10-09
This additive binding gives field names to issue206's original semantics; it changes no mathematical or UI requirement. Original contract is preserved beside this file.

analyzeWalk(input) returns:
{
  format: "recallweave-absorbing-walk/1",
  input: {upper,start,rightNumerator,rightDenominator,horizon},
  probabilities: {right: Fraction,left: Fraction},
  eventual: [{start,left: Fraction,right: Fraction,expectedSteps: Fraction}, ... for starts 0..upper],
  frames: [{
    step,
    distribution: [Fraction, ... states 0..upper],
    firstArrival: {left: Fraction,right: Fraction},
    absorbed: {left: Fraction,right: Fraction},
    survival: Fraction,
    truncatedExpectedSteps: Fraction,
    expectedExcessSteps: Fraction,
    contributions: [{from,to,probability: Fraction,mass: Fraction}, ...]
  }, ...]
}
Fraction is exactly {numerator: string,denominator: string}; each is a reduced integer ratio with positive denominator. No BigInt escapes into JSON. For a valid input the model never mutates that input. Refusal throws an Error with an explanatory message. Export is {...analysis,selectedStep} serialized with two-space indentation and a final LF.

Default: upper6,start3,rightNumerator1,rightDenominator2,horizon12.
Teaching presets: Fair center (default); Near the left boundary (6,1,1,2,12); Right bias (4,2,2,3,12); Always left (6,3,0,1,8); Already absorbed (6,6,1,2,8). Parentheses list the five input fields in the order stated above. No example selection changes the fixed course or guide.

Public browser hooks: #walk-form with integer inputs named exactly like the input fields; #apply; #preset (select) plus #load-preset; #step; navigation #first/#previous/#next/#last; #download-experiment/#download-course/#download-guide. #status announces applied, dirty or invalid state. #results is hidden until valid Apply. Tables #distribution-table, #arrival-table, #eventual-table, #contribution-table provide complete text equivalents; selected-step output #step-label. The implementation may add ordinary presentation elements without changing these meanings.
