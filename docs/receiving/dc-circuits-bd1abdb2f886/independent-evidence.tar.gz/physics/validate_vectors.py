"""Audit independent, manually authored exact values; does not import app code."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

path = Path(__file__).with_name("conservation-vectors.json")
raw = path.read_bytes()
packet = json.loads(raw)
for case in packet["cases"]:
    v = F(case["voltage"])
    rs = list(map(F, case["resistors"]))
    req, total_i = F(case["equivalent"]), F(case["source_current"])
    currents = list(map(F, case["branch_currents"]))
    voltages = list(map(F, case["branch_voltages"]))
    powers = list(map(F, case["branch_powers"]))
    assert len(rs) == len(currents) == len(voltages) == len(powers), case["name"]
    assert all(r > 0 for r in rs), case["name"]
    assert v == total_i * req, case["name"]
    assert F(case["source_power"]) == v * total_i == sum(powers), case["name"]
    for r, i, drop, power in zip(rs, currents, voltages, powers):
        assert drop == i * r, case["name"]
        assert power == i * drop == i * i * r == drop * drop / r, case["name"]
    if case["mode"] == "series":
        assert req == sum(rs), case["name"]
        assert all(i == total_i for i in currents), case["name"]
        assert sum(voltages) == v, case["name"]
    else:
        assert 1 / req == sum(1 / r for r in rs), case["name"]
        assert sum(currents) == total_i, case["name"]
        assert all(drop == v for drop in voltages), case["name"]
print(json.dumps({"kind":"independent-oracle-self-check", "cases":len(packet["cases"]),
                  "all_exact_rational_checks_pass":True,
                  "vectors_sha256":hashlib.sha256(raw).hexdigest(),
                  "driver_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "candidate_source_read_or_executed":False}, indent=2))
