# Preset application control — additive public clarification

Dated 2026-10-09, before independent candidate admission. Original contract, API addendum and public preset bytes remain unchanged.

The example dropdown chooses which preset is pending. The explicit **Use example as draft** action applies that preset and retires any accepted result. It never runs automatically. The full sequence is choose example → Use example as draft → Run network. Changing wire/value/comparator text retires the accepted result immediately. Browsing the example dropdown alone does not change those configuration fields or the accepted result.

The shorter issue phrase “Preset selection changes the draft only” describes application of a preset; it did not spell out the separate apply control. This clarification resolves that wording before independent browser expectations are bound. No mathematical bound, pair sequence, trace or download rule is changed.
