#!/usr/bin/env python3
"""Record one real native process without changing its inputs or outcome."""
import argparse, hashlib, json, os, pathlib, subprocess, sys, time
p=argparse.ArgumentParser()
p.add_argument("--record",type=pathlib.Path,required=True)
p.add_argument("command",nargs=argparse.REMAINDER)
a=p.parse_args()
cmd=a.command[1:] if a.command[:1]==["--"] else a.command
if not cmd or a.record.exists(): raise SystemExit("Require a new process record and command")
start=time.monotonic()
r=subprocess.run(cmd,capture_output=True,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"})
stdout=a.record.with_suffix(".stdout.bin"); stderr=a.record.with_suffix(".stderr.bin")
stdout.write_bytes(r.stdout); stderr.write_bytes(r.stderr)
receipt=dict(argv=cmd,returncode=r.returncode,elapsed_s=time.monotonic()-start,executable=sys.executable,cwd=str(pathlib.Path.cwd()),stdout=dict(path=str(stdout),bytes=len(r.stdout),sha256=hashlib.sha256(r.stdout).hexdigest()),stderr=dict(path=str(stderr),bytes=len(r.stderr),sha256=hashlib.sha256(r.stderr).hexdigest()))
a.record.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt))
print(r.stdout.decode("utf-8",errors="replace"))
if r.stderr: print(r.stderr.decode("utf-8",errors="replace"),file=sys.stderr)
raise SystemExit(r.returncode)
