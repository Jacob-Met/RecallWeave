import pathlib,json,subprocess,hashlib
root=pathlib.Path("/tmp/recallweave-handout-selection-6e5752b49b6f-production")
candidate=root/"candidate"
for name,text in json.loads((root/"candidate-input.json").read_text()).items():
 p=candidate/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding="utf-8")
commands=[["/usr/bin/node","--check","src/course-handout.mjs"],["/usr/bin/node","--check","src/course-handout-ui.mjs"],["/usr/bin/node","--check","tests/course-handout-selection.test.mjs"],["python3","-B","tools/make_handout.py"],["/usr/bin/node","--test","--test-concurrency=1","tests/course-handout-selection.test.mjs","tests/course-handout.test.mjs","tests/course-handout-bundle.test.mjs"]]
receipts=[]
for index,command in enumerate(commands):
 r=subprocess.run(command,cwd=candidate,capture_output=True,timeout=60)
 (root/f"native-r2-{index}.stdout").write_bytes(r.stdout);(root/f"native-r2-{index}.stderr").write_bytes(r.stderr)
 row={"command":command,"exit":r.returncode,"stdoutSha256":hashlib.sha256(r.stdout).hexdigest(),"stderrSha256":hashlib.sha256(r.stderr).hexdigest()}
 receipts.append(row);print(json.dumps(row),flush=True)
 if r.returncode:
  print(r.stdout.decode(errors="replace")+r.stderr.decode(errors="replace"),flush=True);break
(root/"native-r2.json").write_text(json.dumps(receipts,indent=2)+"\n")
