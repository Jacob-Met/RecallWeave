# RecallWeave170 independent model/domain receiving

Receiver owner: estate-6e5752b49b6f/native_runtime. Author: production_slice. Actual UI receiving belongs to root; source review belongs to github_integration. This packet makes neither a browser nor a source-review claim.

Frozen contract85ee68d5d92f44272a4e68c0eef1cc40f76c6550 and exact baseline main698902f9c9c1d5c5023092b85b3632a7cb7a01ed/model1da93ffca/validatorf0f8a4b2 were the only implementation inputs before receiver freeze. Final receiver Gitblob70d4594862c147f074d4a1410daadf7e72e89ee0,11,462bytes,SHA2561b114508a110dc529da28aed7c37a2f7f963611646e888f07211acf1e8410228 was read back exactly before candidate exposure.

A preexecution self-review corrected args.map(resolve) to args.map(x=>resolve(x)): Array.map supplies extra arguments that Node path.resolve would incorrectly consume. Original draft0d9b5c2af655c965af86a8aaa2e3553c06117a17 is retained; it was never executed against candidate or represented as a pass. All assertions, fixtures and expectations were frozen before candidate admission.

Executed candidate: source commit35ba3fe7a611395016fc5c808604ea1a815dc81b/tree8c509b174be3e799d2265558c9e0b3720b0b63ad, model4b535e29bc59da9fa2f2a74bf99da9220db45009/SHA018e0d4195b9fbbbba19bb076bf20cd25d5793731508a54bcc9d7c17d04f10af. All seven offered source paths, exact shared validator, two baseline files, frozen receiver and Node executable were hash-admitted and rechecked unchanged (12records).

Actual ordinary ThinkPad UID1000 /usr/bin/node v22.22.1 SHA d0efb6fcb9d023ba4e2b160ec2384dc28fe4f17732141ef47f676828fa960505. Capacity admission measured223,121,408bytes free. One syntax check and one receiver process; no dependency/build/browser work. Receiver exit0, empty stderr, no timeout,0.455seconds. Raw output and execution receipt preserved.

Six accepted groups:
1. Exact old full model/document bytes for both kinds with omitted/undefined/all selected and permutations. Original worksheet10,013bytes SHA d0f40d962979b7a9d20aa5a99f940b72456573a32714b97e33e7436f96ab7b3b; key10,407bytes SHA588be5b41204722526f06acdb1f0293bf18e8b19b235ac1347fd072d6522c697. Original documents retained.
2. All63 nonempty subsets of a separately authored six-question deck, three selection orders and two kinds:378 projections/documents. Independent expected records retain original question numbers and source order; concepts use source order and selected records only, without prerequisite closure. Worksheet whole-HTML scans reject secret explanations and omitted sentinel text; parsed payload exactly matches the expected projection.
3.23 malformed selections across both APIs and kinds:92 refusals, plus10 invalid-kind calls. Empty/unknown/duplicate/sparse/wrong-type/boxed IDs refuse immutably. Exact whitespace, Unicode canonically distinct, numeric-looking and prototype-like IDs work without coercion.
4. Input/selection copies and deeply frozen public projection boundaries.
5.100-question/32-concept deck, four selections including last-only and sparse numbering; full selection remains legacy byte-identical.
6. Six independently corrupted projections and two whole-document leaks are all rejected by the receiver oracle.

The fixture is a paper selection, not a prerequisite-complete deck; it deliberately chooses a dependent concept alone. Raw HTML contains shared rendering code with field names, while private record values and unselected content are excluded; the oracle distinguishes these correctly. Coverage is this public model/document API, not arbitrary JavaScript accessor/proxy side effects.

Reproduce with Node22 using: node source/receive_model.mjs baseline candidate NEW_OUTPUT. The preserved execution-r1.json records the actual original paths; runtime snapshots under candidate/src permit relocated reproduction without source-owner writes. Actions and coordinated source-ref publication remain held. This immutable evidence may be adopted without changing runtime source or rerunning accepted gates.
