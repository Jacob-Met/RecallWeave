import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { chromium } from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const source = path.resolve(process.argv[2]);
const out = path.resolve(process.argv[3]);
fs.mkdirSync(out, { recursive: true });
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const blob = bytes => crypto.createHash('sha1').update(Buffer.from('blob ' + bytes.length + '\0')).update(bytes).digest('hex');
function pins() {
  const result = {};
  for (const relative of [
    'src/dependency-plan.mjs', 'src/dependency-timing.mjs', 'src/dependency-timing-ui.mjs',
    'courses/dependency-timing.template.html', 'courses/dependency-timing.html',
    'tools/build-dependency-timing.mjs', 'courses/dependency-graphs.md',
  ]) {
    const bytes = fs.readFileSync(path.join(source, relative));
    result[relative] = { bytes: bytes.length, sha256: sha(bytes), gitBlob: blob(bytes) };
  }
  return result;
}
const receipt = {
  kind: 'author-native-file-browser',
  source: pins(), assertions: [], downloads: [],
  requests: [], externalAttempts: [], pageErrors: [], consoleErrors: [],
};
let browserInstance;
let context;
const temporary = fs.mkdtempSync(path.join(out, 'browser-runtime-'));
process.env.TMPDIR = temporary;
const expectedGraph = {
  jobs: ['Outline', 'Design', 'Draft', 'Publish', 'Appendix'],
  edges: [['Outline', 'Design'], ['Outline', 'Draft'], ['Design', 'Publish'], ['Draft', 'Publish'], ['Outline', 'Publish']],
};
const expectedRows = [
  { job: 'Outline', duration: 2, earliestStart: 0, earliestFinish: 2, latestStart: 0, latestFinish: 2, totalSlack: 0, critical: true },
  { job: 'Design', duration: 3, earliestStart: 2, earliestFinish: 5, latestStart: 2, latestFinish: 5, totalSlack: 0, critical: true },
  { job: 'Draft', duration: 3, earliestStart: 2, earliestFinish: 5, latestStart: 2, latestFinish: 5, totalSlack: 0, critical: true },
  { job: 'Publish', duration: 0, earliestStart: 5, earliestFinish: 5, latestStart: 5, latestFinish: 5, totalSlack: 0, critical: true },
  { job: 'Appendix', duration: 1, earliestStart: 0, earliestFinish: 1, latestStart: 4, latestFinish: 5, totalSlack: 4, critical: false },
];
const expectedEdges = [['Outline', 'Design'], ['Outline', 'Draft'], ['Design', 'Publish'], ['Draft', 'Publish']];
try {
  browserInstance = await chromium.launch({
    executablePath: '/workspace/scratch/3e50c5ad22c5/production/browser/chromium',
    headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'],
    downloadsPath: path.join(temporary, 'downloads'),
  });
  receipt.browserVersion = browserInstance.version();
  context = await browserInstance.newContext({ viewport: { width: 1280, height: 960 }, acceptDownloads: true });
  await context.route('**/*', async route => {
    const url = route.request().url();
    if (url.startsWith('file:') || url.startsWith('blob:') || url.startsWith('data:')) await route.continue();
    else { receipt.externalAttempts.push(url); await route.abort('blockedbyclient'); }
  });
  context.on('request', request => receipt.requests.push({ method: request.method(), url: request.url() }));
  const page = await context.newPage();
  page.on('pageerror', error => receipt.pageErrors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') receipt.consoleErrors.push(message.text()); });
  const entry = pathToFileURL(path.join(source, 'courses/dependency-timing.html')).href;
  receipt.entry = entry;
  await page.goto(entry, { waitUntil: 'load' });
  await page.locator('#calculate-timing').waitFor({ state: 'visible' });
  assert.equal(await page.locator('#timing-empty').isVisible(), true);
  assert.equal(await page.locator('#timing-results').isVisible(), false);
  assert.equal(await page.locator('#download-trace').isDisabled(), true);
  assert.equal(await page.getByLabel('Duration for Publish', { exact: true }).inputValue(), '0');
  receipt.assertions.push({ name: 'Actual offline file opens with an uncalculated editable draft', passed: true });

  await page.getByRole('button', { name: 'Calculate timing', exact: true }).click();
  await page.locator('#acyclic-results').waitFor({ state: 'visible' });
  assert.equal(await page.locator('#project-duration').innerText(), '5');
  assert.equal(await page.locator('#critical-count').innerText(), '4');
  const tableRows = await page.locator('#timing-rows tr').evaluateAll(rows => rows.map(row => ({
    job: row.dataset.job,
    ...Object.fromEntries([...row.querySelectorAll('td[data-field]')].map(cell => [
      cell.dataset.field, cell.dataset.field === 'critical' ? row.dataset.critical === 'true' : Number(cell.textContent.replaceAll(',', '')),
    ])),
  })));
  assert.deepEqual(tableRows, expectedRows);
  assert.deepEqual(await page.locator('#critical-edges li').evaluateAll(rows => rows.map(row => [row.dataset.from, row.dataset.to])), expectedEdges);
  assert.equal(await page.locator('.timeline-row[data-job="Publish"] .milestone').count(), 2);
  await page.locator('#all-dependencies summary').click();
  assert.equal(await page.locator('#dependency-rows tr[data-from="Outline"][data-to="Publish"] td').last().innerText(), 'Not a critical link');
  await page.locator('#all-dependencies summary').click();
  const firstEvent = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download timing trace (.json)', exact: true }).click();
  const first = await firstEvent;
  assert.equal(first.suggestedFilename(), 'recallweave-dependency-timing.json');
  const firstPath = path.join(out, 'timing-original.json');
  await first.saveAs(firstPath);
  const firstBytes = fs.readFileSync(firstPath);
  const firstTrace = JSON.parse(firstBytes.toString('utf8'));
  assert.equal(firstTrace.schema, 'recallweave-dependency-timing/1');
  assert.deepEqual(firstTrace.input.graph, expectedGraph);
  assert.deepEqual(firstTrace.input.durations, expectedRows.map(({ job, duration }) => ({ job, duration })));
  assert.deepEqual(firstTrace.result.timing.rows, expectedRows);
  assert.deepEqual(firstTrace.result.timing.criticalEdges, expectedEdges);
  assert.equal(firstTrace.result.timing.projectDuration, 5);
  assert.equal(firstTrace.assumptions.parallelism, 'unlimited');
  assert.equal(firstTrace.assumptions.timeUnit, 'abstract time units');
  assert.equal(firstBytes.toString('utf8'), JSON.stringify(firstTrace, null, 2) + '\n');
  receipt.downloads.push({ path: firstPath, bytes: firstBytes.length, sha256: sha(firstBytes), body: firstTrace });
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.screenshot({ path: path.join(out, 'timing-desktop.png'), fullPage: true });
  const screenshot = fs.readFileSync(path.join(out, 'timing-desktop.png'));
  receipt.screenshot = { file: 'timing-desktop.png', bytes: screenshot.length, sha256: sha(screenshot) };
  receipt.assertions.push({ name: 'Parallel tie, zero milestone, non-tight shortcut and real trace download agree with the declared five-job example', passed: true });

  await page.getByLabel('Duration for Appendix', { exact: true }).fill('6');
  assert.equal(await page.locator('#timing-results').isVisible(), false);
  assert.equal(await page.locator('#timing-rows tr').count(), 0);
  assert.equal(await page.locator('#project-duration').innerText(), '');
  assert.equal(await page.locator('#download-trace').isDisabled(), true);
  await page.getByRole('button', { name: 'Calculate timing', exact: true }).click();
  assert.equal(await page.locator('#project-duration').innerText(), '6');
  assert.equal(await page.locator('#critical-count').innerText(), '1');
  assert.deepEqual(await page.locator('#critical-jobs li').allTextContents(), ['Appendix']);
  assert.equal(await page.locator('#critical-edges li').count(), 0);
  const secondEvent = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download timing trace (.json)', exact: true }).click();
  const second = await secondEvent;
  const secondPath = path.join(out, 'timing-longer-independent-job.json');
  await second.saveAs(secondPath);
  const secondBytes = fs.readFileSync(secondPath);
  const secondTrace = JSON.parse(secondBytes.toString('utf8'));
  assert.equal(secondTrace.result.timing.projectDuration, 6);
  assert.deepEqual(secondTrace.result.timing.criticalJobs, ['Appendix']);
  assert.deepEqual(secondTrace.result.timing.criticalEdges, []);
  assert.deepEqual(secondTrace.input.durations.at(-1), { job: 'Appendix', duration: 6 });
  assert.equal(sha(fs.readFileSync(firstPath)), sha(firstBytes));
  receipt.downloads.push({ path: secondPath, bytes: secondBytes.length, sha256: sha(secondBytes), body: secondTrace });
  await page.getByRole('button', { name: 'Reset to two-branch example', exact: true }).click();
  assert.equal(await page.getByLabel('Duration for Appendix', { exact: true }).inputValue(), '1');
  assert.equal(await page.locator('#timing-results').isVisible(), false);
  assert.equal(await page.locator('#download-trace').isDisabled(), true);
  receipt.assertions.push({ name: 'A longer independent job changes the actual finish/critical set; prior result is cleared and prior downloaded bytes remain exact; reset returns an uncalculated draft', passed: true });

  assert.deepEqual(receipt.externalAttempts, []);
  assert.deepEqual(receipt.pageErrors, []);
  assert.deepEqual(receipt.consoleErrors, []);
  assert.deepEqual(pins(), receipt.source);
  receipt.sourceUnchanged = true;
  receipt.passed = true;
} catch (error) {
  receipt.passed = false;
  receipt.error = error.stack;
  process.exitCode = 1;
} finally {
  if (context) await context.close().catch(error => { receipt.cleanupError = error.message; process.exitCode = 1; });
  if (browserInstance) await browserInstance.close().catch(error => { receipt.cleanupError = error.message; process.exitCode = 1; });
  receipt.finalSource = pins();
  receipt.sourceUnchanged = JSON.stringify(receipt.finalSource) === JSON.stringify(receipt.source);
  fs.rmSync(temporary, { recursive: true, force: true });
  fs.writeFileSync(path.join(out, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ passed: receipt.passed, groups: receipt.assertions.length, externalAttempts: receipt.externalAttempts.length, pageErrors: receipt.pageErrors, consoleErrors: receipt.consoleErrors, sourceUnchanged: receipt.sourceUnchanged, output: out }));
}
