import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,readdir,lstat,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {join,dirname} from 'node:path';
import {spawnSync} from 'node:child_process';
const root='/Users/me/hamon-native-406d0fb04c43/recallweave-weighted-intervals-independent';
const publicRoot=join(root,'publication/independent'),stage=join(root,'artifact-staging'),verify=join(root,'artifact-readback');
const sha=b=>createHash('sha256').update(b).digest('hex'),blob=b=>createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
for(const path of ['receive-math.mjs','receive-browser-v2.mjs','receive-current-consumer.mjs','answer-review.json'])await copyFile(join(root,path),join(publicRoot,path));
const dirs=['baseline','candidate','current-consumer','setup-failures','browser-baseline','browser-current-343d20'];
const files=['preflight.json','baseline-receiving.json','candidate-freeze-v1.json','candidate-receiving.json','current-consumer-pins.json','current-consumer-receiving.json','current-app-diff.patch','current-artifact-parity.json','math-self-check.json','math-receipt.json','math-oracle-freeze.json','oracle-freeze.json','browser-adapter-freeze.json','current-oracle-freeze.json','transport-control.json','transport-control-v2.json','builder-check.log','browser-process.log','browser-current-process.log','browser-baseline-config.json','browser-current-config.json','evidence-summary.json','answer-review.json','receive-math.mjs','receive-browser.mjs','receive-browser-v2.mjs','receive-current-consumer.mjs','check-transport.mjs','check-transport-v2.mjs','freeze-oracles.mjs','freeze-browser-adapter.mjs','intake-baseline.mjs','intake-candidate.mjs','intake-current-consumer.mjs','summarize-evidence.mjs','seal-packet.mjs'];
async function walk(base,prefix=''){const output=[];for(const name of (await readdir(join(base,prefix))).sort()){const path=prefix?prefix+'/'+name:name;const info=await lstat(join(base,path));if(info.isDirectory())output.push(...await walk(base,path));else{assert.ok(info.isFile(),'regular file '+path);output.push(path);}}return output;}
for(const dir of dirs)for(const path of await walk(join(root,dir)))files.push(dir+'/'+path);
files.sort();assert.equal(new Set(files).size,files.length);await mkdir(stage);await mkdir(verify);
const members=[];
for(const path of files){const b=await readFile(join(root,path)),target=join(stage,path);await mkdir(dirname(target),{recursive:true});await copyFile(join(root,path),target);members.push({path,bytes:b.length,sha256:sha(b)});}
const artifactManifest={format:'recallweave-independent-artifact-manifest/1',files:members};
const manifestBytes=Buffer.from(JSON.stringify(artifactManifest,null,2)+'\n');await writeFile(join(stage,'artifact-manifest.json'),manifestBytes,{flag:'wx'});
const archive=join(publicRoot,'independent-artifacts.tar.gz');
const packed=spawnSync('/usr/bin/tar',['--format','ustar','--uid','0','--gid','0','--uname','root','--gname','root','-czf',archive,'-C',stage,'.'],{encoding:'utf8',env:{PATH:'/usr/bin:/bin',COPYFILE_DISABLE:'1'}});
await writeFile(join(root,'archive-pack.log'),packed.stdout+packed.stderr+'\nexit='+packed.status+'\n',{flag:'wx'});assert.equal(packed.status,0);
const extracted=spawnSync('/usr/bin/tar',['-xzf',archive,'-C',verify,'--no-same-owner','--no-same-permissions'],{encoding:'utf8',env:{PATH:'/usr/bin:/bin',COPYFILE_DISABLE:'1'}});
await writeFile(join(root,'archive-readback.log'),extracted.stdout+extracted.stderr+'\nexit='+extracted.status+'\n',{flag:'wx'});assert.equal(extracted.status,0);
assert.deepEqual((await walk(verify)).sort(),[...files,'artifact-manifest.json'].sort());
assert.deepEqual(await readFile(join(verify,'artifact-manifest.json')),manifestBytes);
for(const entry of members){const b=await readFile(join(verify,entry.path));assert.equal(b.length,entry.bytes);assert.equal(sha(b),entry.sha256);}
const publicFiles=[];
for(const path of (await readdir(publicRoot)).sort()){const b=await readFile(join(publicRoot,path));publicFiles.push({path,mode:'100644',type:'blob',bytes:b.length,sha256:sha(b),gitBlob:blob(b)});}
const packet={format:'recallweave-independent-packet-manifest/1',status:'sealed-and-readback-verified',sourceProjection:'c1e774b77eec859e34f06a2b96f960ebaf6ff919',currentConsumer:'343d20e38fb619c5eea2ec588b61c5f26fea714b',publicationBaseRuntimeEquivalence:'ab7e2dddc03dd2629b7d67c291217c946772d10c',artifactMembers:members.length+1,checksummedOriginals:members.length,artifactManifestSha256:sha(manifestBytes),files:publicFiles};
await writeFile(join(publicRoot,'manifest.json'),JSON.stringify(packet,null,2)+'\n',{flag:'wx'});
const manifest=await readFile(join(publicRoot,'manifest.json'));publicFiles.push({path:'manifest.json',mode:'100644',type:'blob',bytes:manifest.length,sha256:sha(manifest),gitBlob:blob(manifest)});
publicFiles.sort((a,b)=>a.path.localeCompare(b.path));
const publication={format:'recallweave-independent-publication-overlay/1',prefix:'docs/receiving/weighted-intervals-20261008-406d0fb04c43/independent',nativeRoot:publicRoot,status:'sealed-and-readback-verified',leaves:publicFiles,artifactMembers:members.length+1,checksummedOriginals:members.length};
const publicationBytes=Buffer.from(JSON.stringify(publication,null,2)+'\n');await writeFile(join(root,'publication-manifest.json'),publicationBytes,{flag:'wx'});
const receipt={status:publication.status,publicLeaves:publicFiles.length,artifactMembers:members.length+1,checksummedOriginals:members.length,publicationManifestSha256:sha(publicationBytes),archive:publicFiles.find(f=>f.path==='independent-artifacts.tar.gz'),nativeRoot:publicRoot,sourceFilesUnchanged:true};
for(const path of ['candidate-receiving.json','current-consumer-receiving.json']){const receipt=JSON.parse(await readFile(join(root,path)));const entries=receipt.leaves??receipt.files;const dir=path.startsWith('candidate')?'candidate':'current-consumer';for(const f of entries)assert.equal(sha(await readFile(join(root,dir,f.path))),f.sha256);}
await writeFile(join(root,'packet-receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
