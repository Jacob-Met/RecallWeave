import fs from 'node:fs';
import {spawn} from 'node:child_process';
const root='/home/jacob/hamon-levenshtein-68094585a1c2-browser', project=root+'/source';
const capacity=fs.statfsSync(root);if(capacity.bavail*capacity.bsize<300000000)throw new Error('Insufficient private home-profile capacity.');
const args=[project+'/tools/check_edit_distance_browser.mjs','--root',project,'--browser','/snap/bin/chromium','--output',root+'/browser-v2','--profile-parent',root];
const started=new Date().toISOString();
const stdout=fs.openSync(root+'/browser-v2.stdout.log','wx'),stderr=fs.openSync(root+'/browser-v2.stderr.log','wx');
const child=spawn(process.execPath,args,{cwd:project,stdio:['ignore',stdout,stderr]});
const running={started,runnerPid:process.pid,receiverPid:child.pid,executable:process.execPath,args,availableReceiptBytes:capacity.bavail*capacity.bsize};
fs.writeFileSync(root+'/browser-v2-running.json',JSON.stringify(running,null,2)+'\n',{flag:'wx'});
child.on('error',error=>{fs.writeFileSync(root+'/browser-v2-launch-error.txt',String(error)+'\n',{flag:'wx'});});
child.on('close',(code,signal)=>{
  const receipt={...running,finished:new Date().toISOString(),code,signal};
  fs.writeFileSync(root+'/browser-v2-exit.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
  fs.closeSync(stdout);fs.closeSync(stderr);console.log(JSON.stringify(receipt));process.exitCode=code===0?0:1;
});
console.log(JSON.stringify(running));
