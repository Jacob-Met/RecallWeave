import hashlib,json,os,re,signal,subprocess,sys,time,shutil
from pathlib import Path
ROOT=Path('/home/jacob/snap/chromium/common/recallweave-sql-picker-3dab-20261008')
OUT=ROOT/'controller-v1'
assert shutil.disk_usage('/home/jacob').free>67108864
OUT.mkdir(exist_ok=False)
script=ROOT/'receive_sql_picker_v1.mjs'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='244a84390351acd584d93caf71e2161a58fab62bcd37dacda5a6329b6d5908d3'
assert hashlib.sha256((ROOT/'source-pins.json').read_bytes()).hexdigest()=='cd3ac584ba13276e37a13148f6d86e56b36087d76650a39a70552aab6b9b9c5e'
command=['/usr/bin/node',str(script),'--browser','/snap/bin/chromium','--output',str(ROOT/'receiving-v1')]
receipt={'command':command,'status':'running','started':time.time(),'source_head':'d8a9ff81e8e5290e8daad5b4af957d4eddc0ee74'}
p=subprocess.Popen(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
print('SQL_PICKER_NATIVE_STARTED node_pid='+str(p.pid),flush=True)
try:
 stdout,stderr=p.communicate(timeout=180)
except subprocess.TimeoutExpired:
 receipt['timeout']=True
 os.killpg(p.pid,signal.SIGTERM)
 try:stdout,stderr=p.communicate(timeout=5)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
(OUT/'stdout.log').write_bytes(stdout)
(OUT/'stderr.log').write_bytes(stderr)
receipt['exit_code']=p.returncode
receipt['marker']=bool(re.search(rb'^SQL_PICKER_OK checks=10 failures=0$',stdout,re.M))
receipt['receiver_unchanged']=hashlib.sha256(script.read_bytes()).hexdigest()=='244a84390351acd584d93caf71e2161a58fab62bcd37dacda5a6329b6d5908d3'
report_path=ROOT/'receiving-v1/receiving.json'
if report_path.exists():
 report=json.loads(report_path.read_text())
 receipt['report']={'sha256':hashlib.sha256(report_path.read_bytes()).hexdigest(),'status':report['status'],'checks':len(report['checks']),'profile_removed':report.get('profileRemoved'),'before_after_equal':report.get('before')==report.get('after')}
receipt['status']='passed' if p.returncode==0 and receipt['marker'] and receipt['receiver_unchanged'] and receipt.get('report',{}).get('status')=='passed' else 'failed'
receipt['elapsed_seconds']=time.time()-receipt['started']
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(stdout.decode(errors='replace'),end='',flush=True)
print(stderr.decode(errors='replace'),end='',flush=True)
print('SQL_PICKER_NATIVE_'+receipt['status'].upper()+' '+json.dumps(receipt),flush=True)
sys.exit(0 if receipt['status']=='passed' else 1)
