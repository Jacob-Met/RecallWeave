const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),git='C:\\Program Files\\Git\\cmd\\git.exe';
const base='567425f209cdf8e8cf9767faac9bfd3003af3e65',expectedReadme='fe2a3b2f578f9ec8c55f32d7443083c70d7c65e0c8cdf7d4073b680289394fc0';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),read=p=>fs.readFileSync(path.join(root,p));
const head=cp.execFileSync(git,['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim();if(head!==base)throw Error('Unexpected author base');
const gates=JSON.parse(read('.git/newton-receiving/author-configured.json'));
for(const [file,pin]of Object.entries(gates.after)){const b=read(file);if(b.length!==pin.bytes||hash(b)!==pin.sha256)throw Error('Frozen source changed '+file);}
const artifact=read(gates.artifact.path);if(hash(artifact)!==gates.artifact.sha256)throw Error('Frozen explorer changed');
const originalReadme=read('README.md');if(hash(originalReadme)!==expectedReadme)throw Error('README baseline changed');
const packet=path.join(root,'docs/receiving/newton-method-c77045b4');if(fs.existsSync(packet))throw Error('Packet already exists; inspect before retry');
const groups=[
{name:'independent-browser',root:'C:\\Users\\minec\\hamon-newton-receiving-c77045b4\\publication',files:[
['README.md','3bf653c479436af07ba77436a00e71c99180b2c042d8e8ff2fdbe6a54e2e7855'],
['acceptance.json','aad184d4cc362e326816521c6cc5e514ad3b786dea0ec69520952fda07c39298'],
['MANIFEST.json','e09a82ab7599b7db09a4f9a1b6efe1ef1fc778aa70c417ca0c4d926e6e9a349b'],
['receiving.bundle','09f4bccad535b9579da049dc4cf7fdcb93098013a7e5e120545a8e9fdda2c193']]},
{name:'independent-math',root:'C:\\Users\\minec\\hamon-newton-math-receiving-c77045b4-publication',files:[
['README.md','a88e73b913cdfd9c2669a0625beb3d11431baf277cd90f8629d3faa4a56cd72a'],
['REVIEW.json','4d23df93d64a5d4f74d63b7081465c6ac056134f8108350c202bdf964603be33'],
['independent-math.bundle','df07d9f9adfac5e930e50f6b1e49b1a064bfa6aa18ee740f8251b1140e5ebef9'],
['manifest.json','a116e43feb363f0412c35074bbdee36da9ba98f3c7512fed929802a670a4ece2']]}];
for(const g of groups)for(const [file,sha256]of g.files)if(hash(fs.readFileSync(path.join(g.root,file)))!==sha256)throw Error('Independent packet mismatch '+g.name+'/'+file);
const addition=[
'## Newton’s method: follow the tangent, inspect the result','',
'Open the **[Newton method explorer](courses/newton-method-explorer.html)** directly in a browser. Choose one of eight examples or enter a polynomial of degree at most three and an exact starting value. Follow each tangent intercept, inspect the exact residual and derivative, and compare an approaching square root, a horizontal tangent, an exact two-cycle and a repeated root. Every completed point is retained in a downloadable exact record.','',
'An exact root, a zero slope away from a root, a repeated cycle, a chosen step limit and an arithmetic limit have separate outcomes. Rounded plotting coordinates never determine those outcomes. Editing any input retires the previous record until the next explicit run.','',
'Download the **[twelve-question lesson](courses/newton-method.json)** from the explorer or this link, then use the existing learner’s file preview and **Start this deck** controls. The **[worked guide](courses/newton-method.md)** derives the tangent update and the original examples, with exact fractions and explicit limits. The explorer includes the exact lesson and guide download bytes and works as a standalone local file.','',
'Build with node tools/build-newton-method.mjs; add --check to verify its generated page. Run the focused checks with node --test tests/newton-method.test.mjs tests/newton-method-course.test.mjs. The [receiving packet](docs/receiving/newton-method-c77045b4/README.md) contains independent mathematical and actual browser/course evidence.',''].join('\n');
fs.writeFileSync(path.join(root,'README.md'),Buffer.concat([originalReadme,Buffer.from('\n'+addition)]));fs.mkdirSync(packet,{recursive:true});
const copied=[];
for(const g of groups){const target=path.join(packet,g.name);fs.mkdirSync(target);for(const [file,sha256]of g.files){const b=fs.readFileSync(path.join(g.root,file));fs.writeFileSync(path.join(target,file),b);if(hash(fs.readFileSync(path.join(target,file)))!==sha256)throw Error('Copied packet mismatch');copied.push({path:g.name+'/'+file,bytes:b.length,sha256});}}
const summary=relative=>read(relative).toString('utf8').split('\n').filter(line=>/^ℹ (?:tests|pass|fail|cancelled|skipped|todo)/.test(line));
const qualification={
schema:'recallweave.newton.author-qualification.v1',at:new Date().toISOString(),owner:'hamon-ultra-20261008-c77045b4-lead',issue:134,baseline:base,baselineTree:'a877e5d5eb1953aa2389ea75ef7cad96da321c1a',status:'native-qualified-hosted-integration-pending',
sourcePins:{...gates.after,[gates.artifact.path]:{bytes:artifact.length,sha256:hash(artifact)}},
readme:{originalSha256:expectedReadme,originalPrefixPreserved:read('README.md').subarray(0,originalReadme.length).equals(originalReadme),afterSha256:hash(read('README.md'))},
native:{node:gates.node,platform:gates.platform,focused:22,focusedExit:0,buildExit:0,
 originalFull:{exit:1,summary:summary('.git/newton-receiving/author-initial-full.log'),cause:'Existing tests could not launch python3 on the default Windows PATH.'},
 configuredFull:{exit:1,summary:summary('.git/newton-receiving/author-configured-full.log'),cause:'Exactly one pre-existing SQL test expects LF-only stdout; the successful native SQLite builder prints CRLF. No existing test or product source was changed to hide it.'},
 runtimeMapping:'Hash-identical private copy of existing Python3.13.15 named python3.exe; child-process-only PATH/PYTHON/PYTHONHOME/UTF-8 stdio. No shared runtime change.'},
independentMath:{status:'accepted',cases:165,exactPointRecords:677,exactStepRecords:512,refusals:43,mutationFailures:{stepSign:142,derivative:149,rootPrecedence:7},drawingIndependent:true,packet:'independent-math/REVIEW.json'},
independentBrowser:{status:'accepted',groups:5,presets:8,questions:12,physicalDownloads:3,relativeLearnerBaseline:base,sourceUnchanged:true,networkRequests:0,exceptions:0,packet:'independent-browser/acceptance.json'},
scope:'New standalone Newton model, UI, exact generated explorer, original course and guide, focused tests and builder; additive README only outside new paths. Existing learner/importer/catalog sources unchanged.',
limits:['No hosted CI, merge, deployment or live HTTP claim at this native packet stage.','No general convergence guarantee or measured learning benefit is asserted.'],independentFiles:copied};
fs.writeFileSync(path.join(packet,'qualification.json'),JSON.stringify(qualification,null,2)+'\n');
const guide=[
'# Newton method: original lesson and exact offline explorer','',
'This packet records source and native receiving for RecallWeave issue #134. The original product contains a twelve-question lesson, worked guide and self-contained editable cubic-polynomial explorer. Its signed BigInt rational recurrence retains exact values and derivatives, each completed tangent correction, and distinct root, zero-slope, cycle, step-limit and arithmetic-limit outcomes. Approximate plotting never decides an outcome.','',
'## Exact source and native author checks','',
'qualification.json pins all nine product/build/test inputs and the additive README. Baseline: 567425f209cdf8e8cf9767faac9bfd3003af3e65, tree a877e5d5eb1953aa2389ea75ef7cad96da321c1a. Core SHA-256: 29f9abdec9fc010e906527285c73e022d7eeaab64a6d7ca145834577bd0f8447. Generated explorer: 57,620 bytes, SHA-256 4d989c2d4f36c932628a849f595bb7102fc4fa1f4faa0b3c58002b1ad41fe88b.','',
'The Node24.21.0 Windows build and all 22 focused model/course/bundle checks pass. The first full repository attempt retains missing-python3 failures. A private, hash-identical executable alias resolved that receiver environment limitation. The configured full run passes 582 of 583 tests: one inherited SQL assertion requires LF-only stdout, while the successful native SQLite builder emits CRLF. Its original log and exact assertion are retained. This is not a green full Windows suite; no existing test was edited. Normal hosted checks and final incoming composition are separate integration gates.','',
'## Independent mathematical receiving','',
'The independent Fraction contract and oracle were frozen before core intake. All 165 cases match 677 exact points and 512 complete steps, including four arithmetic-limit witnesses; all 43 invalid/nonfinite probes refuse. Sign, derivative and root-precedence mutations cause 142, 149 and 7 failures. Poisoning the drawing conversion leaves all accepted results and refusals intact. Read independent-math/REVIEW.json and its README for actual runtime, pins and scope. The complete bundle retains the pre-intake contract, oracle, raw runs and mutations. A Linux freeze command whose readback timed out stays unconfirmed; mathematical execution is explicitly the separate Windows native run.','',
'## Independent browser and actual lesson receiving','',
'Actual Chrome154 on Windows opened the standalone file from a path containing spaces and Unicode. Five groups cover all eight presets, independently calculated tangent witnesses, keyboard navigation, every-input retirement, invalid input, arithmetic limits, three physical downloads, and the relative learner’s preview/Start/all twelve questions. One deliberately wrong answer produced the expected correction; the final score was 11/12. All nine source inputs stayed exact; no browser exceptions or network requests were observed. Both the receiver and lead inspected desktop/phone screenshots. Read independent-browser/acceptance.json; its complete bundle contains source copies, helper, screenshots and physically downloaded files.','',
'## Restore and repeat','',
'Unzip author-receiving.zip using archive-manifest.json, which pins every member. Restore each independent receiver with git clone from its complete .bundle file and follow its README. Original artifacts and failures also remain in native custody. From the project root, rebuild with node tools/build-newton-method.mjs, check with node tools/build-newton-method.mjs --check, and run node --test tests/newton-method.test.mjs tests/newton-method-course.test.mjs. Ordinary repository CI runs its complete tests separately.','',
'The original mathematics and teaching prose refer to [OpenStax Calculus Volume 1, section 4.9](https://openstax.org/books/calculus-volume-1/pages/4-9-newtons-method). No textbook exercise, prose passage or figure was copied. UI, graphics, worked calculations and questions are original. Existing AI disclosure and project licensing guidance remain in force.',''].join('\n');
fs.writeFileSync(path.join(packet,'README.md'),guide);
const files=[];
function add(relative,name){const b=read(relative);files.push({source:relative,path:name||relative,bytes:b.length,sha256:hash(b)});}
for(const file of fs.readdirSync(path.join(root,'.git/newton-receiving')).sort())if(fs.statSync(path.join(root,'.git/newton-receiving',file)).isFile())add('.git/newton-receiving/'+file,'runs/'+file);
for(const file of fs.readdirSync(path.join(root,'.git')).sort())if(/^(?:run-newton.*|newton-baseline|prepare-newton-publication)\.cjs$/.test(file))add('.git/'+file,'methods/'+file);
for(const file of [...Object.keys(gates.after),gates.artifact.path])add(file,'source/'+file);
fs.writeFileSync(path.join(root,'.git/newton-author-archive-input.json'),JSON.stringify({schema:'recallweave.newton.author-archive.v1',at:new Date().toISOString(),files},null,2)+'\n');
console.log(JSON.stringify({prepared:true,head,productFiles:9,independentFiles:copied.length,authorArchiveMembers:files.length,readmePrefixPreserved:qualification.readme.originalPrefixPreserved,fullNative:qualification.native.configuredFull,packet}));
