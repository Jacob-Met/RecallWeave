from pathlib import Path
import gzip, hashlib, io, json, tarfile
root = Path("/home/jacob/hamon-probability-cd1df0f1ee24")
evidence = root / "source-author-evidence"
pins = json.loads((evidence / "source-manifest-v1.json").read_text())
members = {}
for pin in pins:
    data = (root / "candidate" / pin["path"]).read_bytes()
    assert len(data) == pin["bytes"]
    assert hashlib.sha256(data).hexdigest() == pin["sha256"]
    members["qualified/" + pin["path"]] = data
for name in ["README.md", "receipt-v1.json", "model-tests-v1-rdc.txt", "model-tests-v1-tool-response.json", "source-manifest-v1.json", "seal_author_v1.py"]:
    members["evidence/" + name] = (evidence / name).read_bytes()
def pin(name, data):
    return {"path":name, "bytes":len(data), "sha256":hashlib.sha256(data).hexdigest(), "git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
manifest = {"version":1,"scope":"Every archive member except this manifest itself","members":[pin(name,data) for name,data in sorted(members.items())]}
manifest_data = (json.dumps(manifest,indent=2)+"\n").encode()
(evidence / "member-manifest-v1.json").write_bytes(manifest_data)
members["member-manifest.json"] = manifest_data
archive = evidence / "probability-author-v1.tar.gz"
with archive.open("xb") as target:
    with gzip.GzipFile(filename="",fileobj=target,mode="wb",mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode="w") as tar:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,"r:gz") as tar:
    actual=tar.getmembers()
    assert len(actual)==len(members)
    for item in actual:
        assert item.isfile() and tar.extractfile(item).read()==members[item.name]
seal={"archive":pin(archive.name,archive.read_bytes()),"members":len(members),"all_member_bytes_verified":True,"member_manifest":pin("member-manifest-v1.json",manifest_data),"source_pins":pins}
(evidence / "archive-seal-v1.json").write_text(json.dumps(seal,indent=2)+"\n")
print(json.dumps(seal,indent=2))
