import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { parseDeck } from './baseline/src/deck.mjs';
import { initialMastery, selectNextItem, updateMastery } from './baseline/src/knowledge.mjs';
import { createReview, beginPractice, currentPracticeItem, answerPractice } from './baseline/src/review.mjs';

const deck = parseDeck(readFileSync(new URL('./baseline/courses/least-squares.json', import.meta.url), 'utf8'));
const mastery = initialMastery(deck.concepts), asked = new Set(), answers = [];
while (asked.size < deck.items.length) {
  const item = selectNextItem(deck.items, asked, mastery);
  assert.ok(item && !asked.has(item.id));
  const choice = answers.length === 0 ? (item.answer + 1) % item.options.length : item.answer;
  mastery[item.concept] = updateMastery(mastery[item.concept], choice === item.answer);
  asked.add(item.id); answers.push({ item: item.id, choice });
}
assert.equal(selectNextItem(deck.items, asked, mastery), null);
const review = createReview(deck.items, answers);
let practice = beginPractice(review);
assert.equal(practice.items.length, 1);
const missed = currentPracticeItem(practice);
practice = answerPractice(practice, missed.id, missed.answer);
assert.equal(currentPracticeItem(practice), null);
assert.equal(review.filter(x => !x.correct).length, 1);
console.log(JSON.stringify({control:'unchanged native lesson, full adaptive sequence, review and retry',questions:asked.size,firstAttemptMisses:1,retryCorrect:practice.answers[0].correct,runtime:process.version}));
try {
  await import('./baseline/src/polynomial-interpolation.mjs');
  throw new Error('Unexpected existing interpolation module');
} catch (error) {
  assert.equal(error.code, 'ERR_MODULE_NOT_FOUND');
  console.log(JSON.stringify({originalCapability:'interpolation model absent',code:error.code,message:error.message}));
}
const child = spawnSync(process.execPath, ['baseline/tools/interpolate-polynomial.mjs', '--help'], {cwd:new URL('.',import.meta.url),encoding:'utf8'});
assert.equal(child.status, 1);
assert.match(child.stderr, /MODULE_NOT_FOUND/);
assert.equal(child.stdout, '');
console.log(JSON.stringify({originalCapability:'native interpolation command absent',status:child.status,stdout:child.stdout,stderr:child.stderr}));
