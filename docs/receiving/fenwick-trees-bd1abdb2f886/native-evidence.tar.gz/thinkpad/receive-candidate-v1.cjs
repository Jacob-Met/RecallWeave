const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),cp=require("node:child_process");
const root="/home/jacob/recallweave-fenwick-bd1abdb2f886-20261008";
const source=path.join(root,"candidate-v1"),qa=path.join(root,"candidate-v1-qa");
const hash=(b)=>crypto.createHash("sha256").update(b).digest("hex");
const git=(b)=>crypto.createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
const pin=(p)=>{const b=fs.readFileSync(p);return{bytes:b.length,sha256:hash(b),git_blob:git(b),mode:(fs.statSync(p).mode&511).toString(8)};};
const result={schema:"recallweave-fenwick-first-native/v1",at:new Date().toISOString(),pass:false,commands:[]};
try{
 const space=fs.statfsSync(root);if(space.bavail*space.bsize<134217728)throw Error("128MiB reserve");
 if(fs.existsSync(source)||fs.existsSync(qa))throw Error("Fresh candidate/QA required; inspect prior execution");
 fs.mkdirSync(source);fs.mkdirSync(qa);
 const packet=JSON.parse(fs.readFileSync(path.join(root,"source-candidate-v1.json"),"utf8"));
 const originals=["src/deck.mjs","courses/euclidean-algorithm.json"];
 const originalPins=()=>Object.fromEntries(originals.map(name=>[name,pin(path.join(root,"original",name))]));
 result.original_before=originalPins();result.input=pin(path.join(root,"source-candidate-v1.json"));result.runtime={execPath:process.execPath,version:process.version,platform:process.platform,arch:process.arch};result.capacity_before=space.bavail*space.bsize;
 const admitted=new Set(["src/fenwick-trees.mjs","src/fenwick-trees-ui.mjs","templates/fenwick-trees-explorer.html","tools/build-fenwick-trees.mjs","tests/fenwick-trees.test.mjs","courses/fenwick-trees.md","courses/fenwick-trees.json"]);
 if(packet.files.length!==admitted.size)throw Error("Candidate closure mismatch");
 for(const entry of packet.files){
  if(!admitted.delete(entry.path))throw Error("Unadmitted/duplicate source path");
  const dst=path.join(source,entry.path);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,entry.content,{flag:"wx",mode:420});
 }
 fs.copyFileSync(path.join(root,"original/src/deck.mjs"),path.join(source,"src/deck.mjs"));
 const sourcePaths=packet.files.map(x=>x.path).concat("src/deck.mjs");
 const sourcePins=()=>Object.fromEntries(sourcePaths.map(name=>[name,pin(path.join(source,name))]));
 result.source_before=sourcePins();result.controller=pin(__filename);
 const commands=[
  ["tests",["--test","tests/fenwick-trees.test.mjs"]],
  ["ui-syntax",["--check","src/fenwick-trees-ui.mjs"]],
  ["build",["tools/build-fenwick-trees.mjs"]],
  ["build-check",["tools/build-fenwick-trees.mjs","--check"]]
 ];
 for(const [name,args]of commands){
  const started=Date.now();const run=cp.spawnSync(process.execPath,args,{cwd:source,encoding:"utf8",timeout:30000,maxBuffer:2*1024*1024});
  const output={name,argv:[process.execPath,...args],exit:run.status,signal:run.signal,error:run.error?String(run.error):null,milliseconds:Date.now()-started};
  for(const stream of["stdout","stderr"]){const p=path.join(qa,name+"."+stream+".txt");fs.writeFileSync(p,run[stream]||"",{flag:"wx"});output[stream]=pin(p);}
  result.commands.push(output);if(run.status!==0||run.error)throw Error("Native command failed: "+name);
 }
 result.source_after=sourcePins();result.original_after=originalPins();
 if(JSON.stringify(result.source_before)!==JSON.stringify(result.source_after)||JSON.stringify(result.original_before)!==JSON.stringify(result.original_after))throw Error("Source drift");
 result.artifact=pin(path.join(source,"courses/fenwick-trees-explorer.html"));
 result.pass=true;
}catch(error){result.error=String(error.stack);process.exitCode=1;}
finally{
 if(fs.existsSync(qa)){fs.writeFileSync(path.join(qa,"execution.json"),JSON.stringify(result,null,2)+"\n",{flag:"wx"});console.log(JSON.stringify({pass:result.pass,error:result.error,commands:result.commands,receipt:pin(path.join(qa,"execution.json")),artifact:result.artifact}));}
 else console.error(result.error);
}
