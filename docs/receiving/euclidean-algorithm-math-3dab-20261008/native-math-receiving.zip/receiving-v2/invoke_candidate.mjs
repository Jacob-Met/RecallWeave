import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const [corePath, oraclePath] = process.argv.slice(2);
const core = await import(pathToFileURL(corePath).href);
const oracle = JSON.parse(readFileSync(oraclePath, 'utf8'));
const records = oracle.vectors.map(({a,b}) => core.computeEuclid(a,b));
process.stdout.write(JSON.stringify({
  runtime:{node:process.version,platform:process.platform,arch:process.arch},
  module:corePath,format:core.EUCLID_TRACE_FORMAT,
  maximum:core.EUCLID_MAX_INPUT.toString(),records
},null,2)+'\n');
