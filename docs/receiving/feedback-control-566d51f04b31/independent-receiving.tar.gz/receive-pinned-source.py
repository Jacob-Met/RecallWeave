from pathlib import Path
from fractions import Fraction as F
import subprocess,hashlib,json,datetime
review=Path('/home/jacob/hamon-research-build/recall-feedback-control-review-566d51f04b31-coordination')
source=Path('/tmp/recall-feedback-control-566d51f04b31/source')
pin='fb70ca282005db75b01512160625fbb66e39ae94'
expected={'courses/feedback-control.json':'65ca9c4a49f9131985a81b4250873eca0a73108458e0e0adb366878dbbaa7e1e','src/feedback-control.mjs':'5fa64d93e5f1d641a6ed9ba771a54decbe97532eaa390652a2de8801482713a5'}
(review/'source').mkdir(exist_ok=False)
rows=[]
for path,h in expected.items():
 data=(source/path).read_bytes()
 committed=subprocess.check_output(['git','show',pin+':'+path],cwd=source)
 assert data==committed and hashlib.sha256(data).hexdigest()==h,path
 dest=review/'source'/Path(path).name;dest.write_bytes(data)
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 rows.append({'path':path,'copied_as':str(dest.relative_to(review)),'bytes':len(data),'sha256':h,'git_blob':blob})
answers=json.loads((review/'blind-solved-answers.json').read_bytes())
course=json.loads((source/'courses/feedback-control.json').read_bytes())
matches=[]
for answer,item in zip(answers['answers'],course['items']):
 assert answer['id']==item['id'] and answer['zero_based_option']==item['answer']
 matches.append({'id':item['id'],'matched_zero_based_option':item['answer']})
bounds=[]
for name,a,k,r,d,x0,offset in [('negative-extreme',F(0),F(3),F(2),F(1,2),F(-2),F(-1)),('positive-extreme',F(5,4),F(0),F(2),F(1,2),F(2),F(1))]:
 q=a-k;c=k*r+d;star=c/(1-q);n=60
 final=star+q**n*(x0-star);compared=star+q**n*(x0+offset-star)
 bounds.append({'name':name,'settings':{'a':float(a),'gain':float(k),'reference':float(r),'disturbance':float(d),'initial':float(x0),'offset':float(offset),'steps':n},'expected_final':float(final),'expected_compared':float(compared),'expected_analytical_difference':float(offset*q**n),'exact_final':str(final),'exact_compared':str(compared)})
report={'status':'Exact source copied only after blind answers and expectations frozen','native_bounded_capture':pin,'observed_source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip(),'source_files':rows,'blind_answer_receipt_sha256':hashlib.sha256((review/'blind-solved-answers.json').read_bytes()).hexdigest(),'blind_numeric_receipt_sha256':hashlib.sha256((review/'blind-course-numeric-oracles.json').read_bytes()).hexdigest(),'blind_matches':matches,'note':'Only the two requested frozen files are received; root is implementing UI and learner flow in parallel.'}
p=review/'source-receiving.json';p.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
p2=review/'domain-edge-oracles.json';p2.write_text(json.dumps({'boundary':'Cases selected after reading the explicit admitted parameter domain; values independently calculated from the prior rational closed-form derivation. No authored tests read.','cases':bounds},sort_keys=True,indent=2)+'\n')
print(json.dumps({'blind_answer_matches':len(matches),'source_files':rows,'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
