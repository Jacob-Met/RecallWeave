import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const root=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const parse=n=>JSON.parse(fs.readFileSync(path.join(root,n),'utf8').replace(/^\uFEFF/,''));
const pin=p=>{const b=fs.readFileSync(p),s=fs.statSync(p,{bigint:true});return {bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),git:crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex'),mtime_ns:s.mtimeNs.toString()};};
const admission=parse('ORIGINAL-ADMISSION.json'),browser=parse('ORIGINAL-BROWSER-r1.json'),exit=parse('ORIGINAL-BROWSER-r1-EXIT.json'),closure=parse('ORIGINAL-CLOSURE-r1.json');
assert.equal(admission.status,'passed');assert.equal(browser.status,'passed');assert.equal(exit.exitCode,0);assert.equal(browser.browserClosed,true);assert.equal(closure.ownedNamespace.length,0);assert.equal(closure.currentlyPresentHistoricalNumbers.length,0);
for(const f of admission.source){assert.deepEqual(pin(path.join(root,'original',f.path)),{...f.receiver});assert.deepEqual(pin(path.join(parse('ADMISSION-INPUT.json').original.original_root,f.path)),{...f.source});}
for(const d of admission.donor.files)assert.deepEqual(pin(path.join(admission.donor.root,d.path)),{bytes:d.bytes,sha256:d.sha256,git:d.git,mtime_ns:d.mtime_ns});
assert.equal(pin(admission.node.path).sha256,admission.node.sha256);assert.equal(pin(admission.edge.path).sha256,admission.edge.sha256);
const notesPath=path.join(root,'downloads/original-study-notes.txt'),notes=fs.readFileSync(notesPath,'utf8'),notesPin=pin(notesPath);
assert.equal(notesPin.sha256,'227908866db6b5c85a7dcd6c0d6ca0bff69fcd30c2bd31b1fedfe35dc80fba73');assert.equal(notesPin.bytes,1758);
const fixture=parse('ORIGINAL-DECK.json'),choices=browser.groups[2].result.answered,checks=[];
for(const [index,item]of fixture.items.entries()){
  const start=notes.indexOf((index+1)+'. '+item.prompt+'\n');assert.ok(start>=0);
  const stop=index+1<fixture.items.length?notes.indexOf('\n'+(index+2)+'. ',start):notes.indexOf('\nYOUR APPLICATION REFLECTION',start);assert.ok(stop>start);
  const block=notes.slice(start,stop),choice=choices.find(x=>x.id===item.id);assert.ok(choice);
  assert.ok(block.includes('Your first answer: '+item.options[choice.choice]+'\n'));
  assert.ok(block.includes('First try: '+(choice.correct?'correct':'needs review')+'\n'));
  assert.ok(block.includes('Correct answer: '+item.options[item.answer]+'\n'));
  if(!choice.correct){assert.ok(block.includes('Practice answer: '+item.options[item.answer]+'\n'));assert.ok(block.includes('Practice result: correct on retry\n'));}
  checks.push({id:item.id,firstChoice:choice.choice,firstChoiceText:item.options[choice.choice],correct:choice.correct,postPracticeDownloadExact:true});
}
const correction={at:new Date().toISOString(),status:'passed from retained actual download',rawDOMFirstAnswers:browser.groups[2].result.firstAnswers,DOMComparisonIsVacuous:true,rawReceiptModified:false,browserRerun:false,notes:notesPin,checks,scope:'Post-practice first-answer content binds the actual download to independent pre-frozen fixture plus recorded native choices. Empty hidden-DOM strings are excluded from acceptance.'};
fs.writeFileSync(path.join(root,'ORIGINAL-OBSERVATION-CORRECTION.json'),JSON.stringify(correction,null,2)+'\n',{flag:'wx'});
function walk(dir,prefix=''){let arr=[];for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(['original','tmp'].includes(prefix?prefix+'/'+e.name:e.name))continue;const rel=prefix?prefix+'/'+e.name:e.name;if(rel.startsWith('ORIGINAL-FREEZE-r1'))continue;if(e.isDirectory())arr.push(...walk(path.join(dir,e.name),rel));else if(e.isFile())arr.push({path:rel,...pin(path.join(dir,e.name))});else throw Error('Nonregular receiver artifact '+rel);}return arr;}
const artifacts=walk(root).sort((a,b)=>a.path.localeCompare(b.path));assert.ok(!artifacts.some(f=>f.path.startsWith('candidate/')));
const result={schema:'recall253-original-first-independent-freeze-v1',at:new Date().toISOString(),pid:process.pid,parent:process.ppid,status:'passed',source_commit:admission.source_commit,source_tree:admission.source_tree,originalFiles:admission.source.length,originalBytes:admission.source.reduce((s,f)=>s+f.source.bytes,0),source:admission.source,donor:admission.donor,node:admission.node,edge:admission.edge,originalModel:admission.independent_math,originalBrowser:{groups:browser.groups.map(g=>({name:g.name,status:g.status})),browserVersion:browser.browserVersion,exitCode:exit.exitCode,closed:browser.browserClosed,capturesDirectlyViewedByRoot:true,captures:browser.captures},closure,course:{blindQuestions:12,rootAnswers:12,answerKeysOrExplanationsRead:false,blind:pin(path.join(root,'COURSE-BLIND.json')),answers:pin(path.join(root,'COURSE-ANSWERS.json'))},observerCorrection:correction,presetClarification:pin(path.join(root,'PRESET-CONTROL-CLARIFICATION.md')),artifacts,candidateSourceRead:false,candidateTestsOrOutcomesRead:false,candidateReadyForSeparateAdmission:true};
fs.writeFileSync(path.join(root,'ORIGINAL-FREEZE.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:'passed',at:result.at,pid:process.pid,originalFiles:result.originalFiles,artifacts:artifacts.length,courseAnswers:12,observerCorrection:true}));
