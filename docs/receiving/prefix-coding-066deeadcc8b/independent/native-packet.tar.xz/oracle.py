#!/usr/bin/env python3
"""Pre-candidate prefix-code oracle: exhaustive full-binary-tree partitions.

Optimal costs do not use the two-smallest merge. A separate two-queue trace
implements only the promised deterministic witness, checked against that cost.
"""
from __future__ import annotations
from functools import lru_cache
from itertools import product
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def optimal_cost(weights):
    """Enumerate both-child leaf partitions for every nonempty labeled subset.

    Every full binary tree has one such partition at its root. Each child gains
    one depth, adding sum(weights) at that root; recurse over both subtrees.
    A fixed least-index leaf belongs to the left subset to remove mirror copies.
    Positive weights allow unary vertices to be contracted without improvement
    loss, so full trees suffice for the minimum nonempty binary prefix code.
    """
    weights = tuple(weights)
    @lru_cache(None)
    def visit(mask):
        if mask & (mask - 1) == 0:
            return 0
        first = mask & -mask
        total = sum(w for i,w in enumerate(weights) if mask & (1 << i))
        best = None
        subset = (mask - 1) & mask
        while subset:
            other = mask ^ subset
            if subset & first and other:
                candidate = visit(subset) + visit(other) + total
                if best is None or candidate < best:
                    best = candidate
            subset = (subset - 1) & mask
        require(best is not None, 'no binary partition')
        return best
    require(len(weights) >= 2 and all(isinstance(w,int) and w > 0 for w in weights), 'oracle domain')
    return visit((1 << len(weights)) - 1)


def deterministic_witness(rows):
    # Python orders Unicode strings by scalar value, unlike JavaScript's default
    # UTF-16 code-unit order. No normalization or trimming is applied.
    symbols = sorted((dict(r) for r in rows), key=lambda r:r['symbol'])
    nodes = {i:{'id':i,'count':r['count'],'symbol':r['symbol'],'left':None,'right':None}
             for i,r in enumerate(symbols)}
    leaves = sorted(nodes, key=lambda i:(nodes[i]['count'],i))
    branches = []
    steps = []
    def queue():
        return sorted(leaves + branches, key=lambda i:(nodes[i]['count'],i))
    def pop():
        if not leaves:
            return branches.pop(0)
        if not branches:
            return leaves.pop(0)
        if (nodes[leaves[0]]['count'],leaves[0]) <= (nodes[branches[0]]['count'],branches[0]):
            return leaves.pop(0)
        return branches.pop(0)
    while len(leaves) + len(branches) > 1:
        before = queue()
        left, right = pop(), pop()
        parent = len(nodes)
        nodes[parent] = {'id':parent,'count':nodes[left]['count']+nodes[right]['count'],
                         'symbol':None,'left':left,'right':right}
        branches.append(parent)
        require(all(nodes[a]['count'] <= nodes[b]['count'] for a,b in zip(branches,branches[1:])), 'two-queue monotonicity')
        steps.append({'before':before,'left':left,'right':right,'parent':parent,'after':queue()})
    root = queue()[0]
    codes = {}
    def walk(node_id, bits):
        node = nodes[node_id]
        if node['symbol'] is not None:
            codes[node['symbol']] = bits
        else:
            walk(node['left'],bits+'0');walk(node['right'],bits+'1')
    walk(root,'')
    total_count = sum(r['count'] for r in symbols)
    weighted_bits = sum(r['count']*len(codes[r['symbol']]) for r in symbols)
    fixed_width = (len(symbols)-1).bit_length()
    require(weighted_bits == optimal_cost([r['count'] for r in symbols]), 'deterministic witness is not globally optimal')
    codebook = [{'symbol':r['symbol'],'count':r['count'],'bits':codes[r['symbol']],
                 'length':len(codes[r['symbol']])} for r in symbols]
    return {'symbols':symbols,'nodes':list(nodes.values()),'root':root,'merges':steps,'codebook':codebook,
            'totalCount':total_count,'weightedBits':weighted_bits,'fixedWidth':fixed_width,
            'fixedBits':fixed_width*total_count,'averageBits':weighted_bits/total_count}


def make_fixture():
    cases = []
    for n in range(2,7):
        for weights in product(range(1,4),repeat=n):
            rows = [{'symbol':chr(65+i),'count':w} for i,w in enumerate(weights)]
            cases.append({'name':'exhaustive-'+str(n)+'-'+''.join(map(str,weights)),
                          'kind':'exhaustive-positive-count-vector','rows':rows,'expected':deterministic_witness(rows)})
    special = [
        ('original-worked',[('A',7),('B',3),('C',2),('D',2)]),
        ('skew-seven',[(chr(65+i),w) for i,w in enumerate([10000,1,1,2,3,5,8])]),
        ('eight-equal',[(chr(65+i),10000) for i in range(8)]),
        ('eight-fibonacci',[(chr(65+i),w) for i,w in enumerate([1,1,2,3,5,8,13,21])]),
        ('leaf-parent-tie',[('a',2),('b',1),('c',1),('d',4)]),
        ('all-count-bounds',[('maximum',10000),('minimum',1)]),
        ('scalar-order',[('\U00010000',2),('\ue000',2),('Z',2),('\U0001f600',2)]),
        ('literal-spaces',[(' a',2),('a',2),('a ',2),('\ta\n',2)]),
        ('normalization-distinct',[('\u00e9',2),('e\u0301',2),('E',2)]),
        ('object-property-labels',[('__proto__',1),('constructor',1),('toString',1),('hasOwnProperty',1)]),
        ('literal-markup',[('<b id=prefix-x>x</b>',3),('&"\'',2),('\u03a9',1)]),
        ('scalar-label-boundary',[('\U0001f600'*24,2),('a'*24,1)]),
    ]
    for name, pairs in special:
        rows = [{'symbol':s,'count':w} for s,w in pairs]
        cases.append({'name':name,'kind':'consequential-positive-boundary','rows':rows,
                      'expected':deterministic_witness(rows)})
    invalid = [
        {'name':'null-rows','rows':None}, {'name':'object-rows','rows':{}}, {'name':'string-rows','rows':'A'},
        {'name':'empty-rows','rows':[]}, {'name':'single-row','rows':[{'symbol':'A','count':1}]},
        {'name':'nine-rows','rows':[{'symbol':str(i),'count':1} for i in range(9)]},
    ]
    base = [{'symbol':'A','count':1},{'symbol':'B','count':2}]
    for name, patch in [('duplicate',{'symbol':'B'}),('empty-symbol',{'symbol':''}),
                        ('blank-symbol',{'symbol':' \t\n'}),('unicode-blank-symbol',{'symbol':'\u00a0'}),
                        ('scalar-label-too-long',{'symbol':'\U0001f600'*25}),
                        ('unpaired-high-surrogate',{'symbol':'\ud800'}),('unpaired-low-surrogate',{'symbol':'\udfff'}),
                        ('embedded-unpaired-surrogate',{'symbol':'a\ud800b'}),('non-string-symbol',{'symbol':3}),
                        ('zero-count',{'count':0}),('negative-count',{'count':-1}),('fraction-count',{'count':1.5}),
                        ('too-large-count',{'count':10001}),('string-count',{'count':'2'}),
                        ('boolean-count',{'count':True}),('null-count',{'count':None})]:
        invalid.append({'name':name,'rows':[{**base[0],**patch},dict(base[1])]})
    invalid.extend([{'name':'nan-count','javascriptValue':'NaN'}, {'name':'positive-infinity-count','javascriptValue':'Infinity'},
                    {'name':'negative-infinity-count','javascriptValue':'-Infinity'},
                    {'name':'undefined-row','javascriptValue':'undefined-row'}, {'name':'array-row','rows':[[],base[1]]}])
    return {'schema':'recall-prefix-independent-oracle-fixtures-v1','candidate_inspected':False,
            'mathematical_oracle':'Exhaustive labeled full-binary-tree root partitions, memoized by leaf subset; no greedy choice in minimum-cost oracle.',
            'exhaustive_vectors':1089,'cases':cases,'invalid_models':invalid,
            'encoder_contract':{'maximum_symbols':512,'empty_allowed':True,'unknown_symbols':'reject','non_array':'reject'},
            'decoder_contract':{'maximum_bits':4096,'alphabet':'01','empty_result':[],
                                'unfinished_codeword':'reject','non_string':'reject','whitespace':'reject'},
            'negative_control':{'weights':[1,2,3],'exhaustive_minimum':optimal_cost([1,2,3]),
                                'largest_first_merge_cost':11,'must_reject_nonoptimal_witness':True}}


if __name__ == '__main__':
    result = make_fixture()
    out = Path(__file__).with_name('oracle-fixtures.json')
    data = (json.dumps(result,ensure_ascii=True,separators=(',',':'))+'\n').encode()
    out.write_bytes(data)
    print(json.dumps({'fixture':str(out),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                      'exhaustive_vectors':result['exhaustive_vectors'],'positive_cases':len(result['cases']),
                      'invalid_models':len(result['invalid_models']), 'application_runs':0,
                      'negative_control':result['negative_control']}))
