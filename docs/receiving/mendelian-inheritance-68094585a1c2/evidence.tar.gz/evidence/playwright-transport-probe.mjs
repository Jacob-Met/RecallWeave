import {chromium} from '/Users/me/hamon-towerops-decision-trace-68094585a1c2/ci-browser-venv/lib/python3.13/site-packages/playwright/driver/package/index.mjs';
import {createServer} from 'node:http';
import {readFile, writeFile} from 'node:fs/promises';
import {resolve, extname} from 'node:path';
const project='/Users/me/hamon-recallweave-inheritance-68094585a1c2/source';
const report={checks:[],requests:[],errors:[],responses:[]};
const server=createServer(async(req,res)=>{
  report.requests.push('server '+req.url);
  try{
    const path=resolve(project,'.'+new URL(req.url,'http://local').pathname);
    const bytes=await readFile(path);
    const types={'.html':'text/html;charset=utf-8','.mjs':'text/javascript;charset=utf-8','.css':'text/css','.json':'application/json'};
    res.writeHead(200,{'Content-Type':types[extname(path)]??'application/octet-stream','Content-Length':bytes.length});res.end(bytes);
  }catch(error){res.writeHead(404);res.end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port;
let browser;
try{
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 report.version=browser.version();
 const page=await browser.newPage();
 page.on('request',r=>report.requests.push('browser '+r.url()));
 page.on('response',r=>report.responses.push({url:r.url(),status:r.status()}));
 page.on('pageerror',e=>report.errors.push(e.message));
 for(const [path,selector] of [['/index.html','#start-button'],['/courses/mendelian-inheritance-lab.html','#preset-one-test']]){
   const response=await page.goto(origin+path,{waitUntil:'domcontentloaded',timeout:15000});
   await page.locator(selector).waitFor();
   report.checks.push({path,status:response.status(),title:await page.title()});
 }
 report.status='passed';
}catch(error){report.status='failed';report.error=error.stack;process.exitCode=1;}
finally{
 await browser?.close();
 server.closeAllConnections();
 await new Promise(resolve=>server.close(resolve));
 await writeFile('/Users/me/hamon-recallweave-inheritance-68094585a1c2/evidence/playwright-transport-probe.json',JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report,null,2));
}
