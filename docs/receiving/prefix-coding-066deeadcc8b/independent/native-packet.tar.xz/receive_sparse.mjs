import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
const [source,out]=process.argv.slice(2); const bytes=await fs.readFile(source);const api=await import(pathToFileURL(source));
const rows=[{symbol:'A',count:1},{symbol:'B',count:2}];
const cases=[['sparse-model-rows',()=>api.validateRows([,{symbol:'B',count:2}])],['one-hole-message',()=>api.encodeSymbols(rows,Array(1))],['known-hole-known-message',()=>api.encodeSymbols(rows,['A',,'B'])]];
const report={source,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),contract:'Every validated row must be an admitted object; every encoded message position must be a known symbol, with no silent omission.',cases:[]};
for(const [name,fn] of cases){try{const value=fn();report.cases.push({name,refused:false,returned:value,ownKeys:Object.keys(name==='sparse-model-rows'?value:value.symbols),length:name==='sparse-model-rows'?value.length:value.symbols.length});}catch(e){report.cases.push({name,refused:true,error:e.message});}}
report.summary={cases:report.cases.length,refused:report.cases.filter(x=>x.refused).length};await fs.writeFile(out,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));process.exitCode=report.summary.refused===report.summary.cases?0:1;
