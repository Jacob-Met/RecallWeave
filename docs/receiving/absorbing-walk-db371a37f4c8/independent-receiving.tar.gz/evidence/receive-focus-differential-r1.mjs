import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {chromium} from '/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8/source/node_modules/playwright/index.mjs';
const R=path.dirname(fileURLToPath(import.meta.url)),O=path.join(R,'focus-differential-r1');fs.mkdirSync(O);const r={started:new Date().toISOString(),pid:process.pid,cases:[],sourceChanged:false};const save=()=>fs.writeFileSync(path.join(O,'receipt.json'),JSON.stringify(r,null,2)+'\n');
for(const variant of ['default','software']){
 let browser;const group={variant,checks:[]};r.cases.push(group);save();
 try{browser=await chromium.launch({executablePath:'/snap/bin/chromium',headless:true,chromiumSandbox:true,timeout:45000,...(variant==='software'?{args:['--disable-gpu']}:{})});
 for(const text of ['Incoming mass: 3/8 x 2/3 = 1/4. Literal <&>', 'Incoming mass: 3/8 × 2/3 = 1/4. Literal <&> 日本語 🌊']){
 const entry={text,started:new Date().toISOString(),milestones:[]};group.checks.push(entry);save();const context=await browser.newContext();const page=await context.newPage();page.setDefaultTimeout(6000);page.on('crash',()=>{entry.crashed=true;save();});
 try{await page.setContent('<!doctype html><title>Independent plain textarea observer</title><textarea id="first"></textarea><textarea id="second"></textarea>');entry.milestones.push('plain page ready');save();await page.locator('#first').fill(text);entry.milestones.push('first fill returned');save();await page.locator('#second').fill('A finite horizon is not an eventual stopping guarantee.');entry.values=await page.locator('textarea').evaluateAll(xs=>xs.map(x=>x.value));entry.pass=true;}catch(e){entry.error=String(e);}finally{await context.close().catch(e=>{entry.closeError=String(e)});entry.finished=new Date().toISOString();save();}
 }
 }catch(e){group.error=String(e);}finally{if(browser)await browser.close().catch(e=>{group.closeError=String(e)});group.finished=new Date().toISOString();save();}
}
r.finished=new Date().toISOString();save();console.log(JSON.stringify(r));
