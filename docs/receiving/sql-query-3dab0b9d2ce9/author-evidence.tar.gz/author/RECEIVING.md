# SQL course and explorer: native receiving

**The standalone teaching page passed actual Chromium receiving.** The final process exited 0 with `SQL_BROWSER_OK checks=8 failures=0`, and its controller reported `SQL_NATIVE_PASSED source_inputs=13`. The existing Mac SQLite engine had already executed all 22 prepared queries, and the five focused Node tests passed with zero failures or skips.

## Exact candidate

The source is frozen at `/workspace/scratch/3dab0b9d2ce9/estate-runtime/recallweave-sql/frozen-v3/repo`. Its 13-input manifest is `source-pins-v3.json`, SHA-256 `bf206f0e57730ef563b40d041e38dc24f587885e888ac55d64581c9d11b58f69`. Eight files are new SQL contribution paths; five are unchanged published RecallWeave dependencies from main `4775af91ba6a5d4df787669f39b44364dd1e37ba`. No app, importer, default course, authoring module, model, or other course file is modified.

- Authored source: `f9237bb99138e9da94c0a1149605ef3b19987899594d6742d0261ade68f5b6f3`.
- Downloaded course: `e5fbe1589409876871d1358e6287eb95d2cdd624a5d8da1e1a0a2871801f4512`.
- Standalone page: `65b208cd4b80eb0df87d64e2e493f47a14e07174ecdece0beeafb2d960a5c454`.
- SQLite builder: `e8767a3dbaa32a78c6e10e091e36eb2967bc0d823102641ce5a796899463f6b8`.
- Final browser receiver: `8c4f898b80b971b828ef193cc2e1562ac661f875d8ffba6d15975fd622b9ec92`.

All twelve inputs other than the browser receiver remain identical across frozen v1, v2, and v3. The only earlier question correction replaced an assumption about the “next” adaptive question with the name of the intended NULL example. The independent semantic review records that change separately.

## What was received

The course contains twelve original questions over ten fictional input rows. Every manually chosen correct option is checked against a real SQLite execution before the course or explorer is generated. The browser selects a finite catalog of 22 prepared SQL queries; it has no editable SQL field. Its optional prediction concerns the number of SELECT result rows, which is deliberately distinguished from an aggregate value such as COUNT(*) inside one result row.

Mac receiving used Python 3.13.7 / SQLite 3.50.4 and Node 26.3.0. The `--check` build matched the saved artifacts exactly. Five tests received the published deck format; every canonical course/default query binding; native adaptive selection, shuffled answer identity, immutable first answers, review, practice and saved notes; refusal of changed answers or invalid/multiple statements without replacing artifacts; and stale-output refusal.

Final browser receiving used the existing ThinkPad Node 22.22.1 / Chromium 153.0.8010.47, one empty isolated profile, and a temporary loopback server. The eight groups cover:

1. All four station rows, six reading rows, and twelve example choices.
2. All 22 exact SQL/column/row/explanation bindings, including empty results.
3. Optional correct and incorrect predictions, aggregate values versus output rows, and reset before a changed query.
4. Actual keyboard selection of an example, threshold, and ON placement; Enter activation, labels, minimum control size, and retained focus.
5. Real completed downloads of the exact course JSON and complete practice SQL.
6. The 390 px layout and keyboard access to horizontally scrollable result columns.
7. A fresh direct-file page after the HTTP server closed, including threshold 30's empty WHERE result versus four retained ON placeholders, and a completed exact course download.
8. No external page request or uncaught JavaScript exception, with all 13 input hashes unchanged afterward.

The final browser exited and its own temporary profile was removed. No existing personal browser profile, account, credential store, service, live database, or project checkout was used as fixture state.

## Reading this packet

- `mac/receiving/author-v1/receipt.json`, `sqlite.stdout`, and `native-contracts.stdout` retain the successful content/native-module receiving.
- `thinkpad/receiving/author-thinkpad-v5/receipt.json` records the exact browser command, normal exit, marker, and 13 before/after source hashes.
- `thinkpad/receiving/author-thinkpad-v5/browser/browser-report.json` records the actual browser version, eight groups, three completed download hashes, source guards, page requests, screenshots, and successful profile cleanup.
- The three final PNGs are beside that report. The mobile group-table frame was captured after an actual right-arrow scroll, so its leading column is intentionally partly outside the scroll region. The result's full columns and rows were separately compared exactly. The focus outline and scrollbar show the tested keyboard route.

The three frames from the preceding cleanup-failed run are byte-identical to the final frames; `native-image-pins.json` retains both original native paths and all six hashes. The copies here may share local storage but retain the exact original bytes. The independent reviewer should issue its own disposition, rather than infer one from this author packet.

## Preserved unsuccessful receiving

None of these earlier runs is counted as the final accepted browser run:

| Attempt | Observation | Consequence |
|---|---|---|
| Mac v1 | Chrome 154 returned its version, then Page.navigate timed out before any product assertion; display-link diagnostics were retained. | Browser acceptance remained pending; the successful SQLite and Node stages were retained. |
| Mac minimal control | A tiny authored page eventually produced its expected DOM, but the process needed termination after 20 seconds. | No clean-runtime or product acceptance was inferred. |
| ThinkPad controller v1 | A receiving-script string replacement caused a Python parse error before execution. | Exact failed controller retained; no browser was started by it. |
| ThinkPad author v2 | An 8-second DevTools startup bound expired before product assertions. | Receiver v2 adopted the already-qualified local Chromium launcher pattern: empty-profile basic password backend, disabled extensions, a 45-second startup bound, and its own child's local stderr endpoint. No browser sandbox or account settings were changed. |
| ThinkPad author v3 | All eight product groups passed, then temporary-profile removal threw ENOTEMPTY. | Exit 1 and missing terminal marker/report remained a failed receiving run. Source guards, raw output, screenshots, and completed downloads were preserved. |
| Native v3 copy attempt / controller v4 | ENOSPC prevented the new copy and left a zero-byte controller file before execution. | No browser receiving occurred. Only two stale profiles from this lane were later removed after the prior owned browser PID was absent; no other owner's files were cleaned. |
| Final ThinkPad author v5 | Receiver v3 allowed graceful browser exit, bounded its own profile-removal retries, and retained failure reporting even if cleanup failed. | All eight groups, exact source guards, the terminal marker, exit 0, and profile cleanup passed. |

The final executed controller is `thinkpad/native_receive_thinkpad_v5.py`, SHA-256 `32f2dc7d76241635fbd888675e76d2139a928f79d2a12c268afa426d8943a3a0`. Its local workspace copy initially hit ENOSPC; this packet receives the actual complete native file and verifies its bytes. The frozen product files were not changed by that failed evidence-copy operation.

## Limits and ownership

Public source scope is [RecallWeave issue 22](https://github.com/Jacob-Met/RecallWeave/issues/22). The standalone explorer is usable directly as a saved file. The course is admitted by the exact published deck validator and the native learner/review/notes functions, but the final app file-picker composition remains with issue 7 and has not yet been received with this course. This packet makes no claim of final importer adoption, deployment, learning efficacy, or a new assessment model. The existing app and all other owners' courses remain untouched.

Source publication still requires current ownership/tree preservation and the session root's coordinated GitHub window. This packet records exact receiving, not publication or merge.
