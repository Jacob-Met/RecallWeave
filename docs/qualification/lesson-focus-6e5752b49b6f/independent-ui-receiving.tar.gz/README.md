# RecallWeave focused-lesson independent receiving

## Result

Accepted corrected source `ff99f4085b25d82227d33eb76d9f707e158a90e8`, tree `641ed0a76364125df45f21c8919d669ee863ce59`, with no open finding in this bounded review. The original source `3904c2f384d7f8fd4225d6ffbc2f4c89e6eae0ed` produced a real accessibility counterexample; both original failure and unchanged-receiver corrected pass are retained.

Reviewer: HAMON contributor `6e5752b49b6f/production_slice`. Author: the independent `github_integration` lane. Root separately qualified the model and byte-limit reference cases. This packet adds UI/source and actual-file receiving; it does not claim a repeat of either root's core matrix or the author's nine browser groups.

## Actual action-identity challenge

The shared checked-deck format preserves distinct raw concept strings. Our synthetic deck contains `Shared topic`, `Shared\\ttopic`, and `Branch`; Branch depends only on the tab-containing concept. The two similar names select different original questions.

The unchanged `receive-action-labels.mjs` ran against each exact standalone file in a separate native Mac browser context. On R1 it recorded three checkboxes but only two unique accessible names, although independent selections correctly produced different questions. This is an actionable identity failure, not a change requested to the validator.

R2 retains each literal name and visibly adds Source concept 1/2/3. The actual accessibility names are unique. The same receiver also confirms that the first two choices still select their separate original questions and that Branch includes only the second concept as its prerequisite. Inclusion and direct-reason text use matching source numbers. We visually inspected both preserved checkbox screenshots. The R1 failure is not relabeled as a pass.

- Actual peer browser: Chromium **151.0.7922.34**, Node **26.3.0**, Darwin arm64.
- R1 HTML SHA-256: `c59ed2377ee8a6359ef49aa9f9a451f4fb987dd55a512340c99e4b48806715f2`.
- R2 HTML SHA-256: `525a89161daa4cd0b40f7e291e801ec33d8afdc0f46bfb5e2adcc920e7e67c59`.
- Unchanged receiver SHA-256: `3bbd798168ed97f3eec3f2f3cd70ec3c27c077988232db308aa256e48305b880`.
- Original receipt: `r1/receiving.json`; corrected receipt: `r2/receiving.json`.
- Both source checks were unchanged after execution. No page errors or external requests. Native browser contexts closed and owned temporary profiles removed.
- The snapshots under `sources/` are losslessly gzip-compressed original bytes; decompress before invoking the browser receiver. Its runtime paths are explicit borrowed Mac dependencies. The original invocation used `/tmp/recallweave-focus-review-6e5752b49b6f-production`. The receipt's absolute paths describe that executed provenance.

## Source and actual-download review

`receive-files.mjs` passed six independent groups and wrote `source-and-downloads.json`. The receiver reconstructs literal expected focused content from the authored fixture; it does not import the focus model or the author's expected-selection helper.

1. Admitted all **17** source hashes from the original actual browser receipt against the immutable original Git source, and admitted the author's executed harness hash.
2. Verified all **eight actual download** hashes and lengths. All five ordinary focused JSON downloads exactly equal a separately specified full deck: title, attribution, license, original concept/item order, prompts, choices, answer indexes, explanations, transfers, and prerequisite arrays.
3. Independently parsed the actual **262,144-byte** downloaded boundary file with the unchanged checked-deck validator. It has the reported 30 questions and identical input/download hash. This is actual-file admission, not another byte-limit generator test.
4. Read both actual learner-note downloads. They differ only in Saved timestamp; their five review records match original canonical answers/content, the recorded three of five first answers, and both correct retries. Attribution/license remain literal, and unrelated/downstream excluded question prompts are absent.
5. Compared fresh GitHub current-main inventory `c00bd1f31c353698957d2ebad311334536cdef98` with R2: all **495 non-README leaves and modes** preserved, eight expected files added, only README changed among existing paths. All **11 executed browser consumer** files match the original qualified source. R2 changes exactly the numbered-reference UI and generated HTML from `55fda259c0627e7f8d977a43b34e9eaf830f85ac`; the model, shared validator, style, template, builder, and tests remain identical.
6. Ran read-only standalone parity against the corrected modular sources.

The fresh, non-truncated API inventory is preserved losslessly as `current-main-tree.json.gz`. Source/file replay requires the original and corrected repositories, plus the author's original receiving directory:

```sh
node receive-files.mjs ORIGINAL_REPO CORRECTED_REPO AUTHOR_RECEIVING OUTPUT_JSON
```

The original author's actual nine browser groups ran on Chromium **153.0.8010.0** and Node **24.19.0**, source 3904. This peer review separately read its complete harness and receipt, the actual exported files, and the modular, phone-incoming, and phone-focus images. It found the reported preview/cancel/current-source, read-revision, continued-edit, invalid-title/stale-ready, and download-refusal checks consistent with their concrete assertions. The uploaded source/download/learner path uses the actual produced file. File cancellation is a dispatched DOM cancel event; injected File.text and URL failures test controlled refusal paths. No OS chooser Escape or real hardware failure claim is made.

The original 3904 broad browser provenance stays unchanged. The only corrected runtime behavior is visible/source-number reference labeling, separately received above; identical consumer/model/source leaves and generated parity support composition. The phone screenshot of the long source title shows wrapping and a cropped continuation, not every control in one frame.

## Source reasoning

Source review confirms that a new file choice increments the revision before the asynchronous read, checks the revision on success and failure, refuses excessive File.size before reading, and requires explicit Use to replace the current source. Cancel and continued editing retire pending read/preview state. Rendering clears ready bytes before recomputing and download revalidates immediately; invalid selection/title/size cannot download an older snapshot. Content uses text nodes. Select-all/clear move focus to the remaining actionable button; source admission and cancellation focus their relevant headings/buttons. The ordinal repair changes no selection, model, admission, or download handler.

## Preservation

All members are hashed in `evidence-manifest.json`. Original native receiver, receipts, and PNG files were transported byte-for-byte and verified against native SHA-256. The packet is destined for the feature's existing Git-backed qualification area. The author may compose these unchanged source files onto a later main; such a composition needs its own leaf-preservation readback and does not change these executed pins.

