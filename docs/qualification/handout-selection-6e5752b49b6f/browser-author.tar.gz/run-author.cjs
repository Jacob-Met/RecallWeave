'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),{spawn}=require('node:child_process'),assert=require('node:assert/strict');
const root=__dirname,hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const input=JSON.parse(fs.readFileSync(path.join(root,'input.json'),'utf8')),node=input.runtime.node.path;
const receipt={format:'handout-selection-native-controller/1',identityBoundary:'Existing NT AUTHORITY\\SYSTEM connector route; no identity or execution-policy changes.',started:new Date().toISOString(),node:process.version,executable:process.execPath,phases:[],status:'running',priorRefusal:{command:'powershell.exe -NoProfile -File run-author.ps1',result:'SecurityError / UnauthorizedAccess: running scripts is disabled on this system.',effect:'No hydration or browser execution occurred. Refused script is not read or evaluated by this controller.'}};
const put=()=>fs.writeFileSync(path.join(root,'node-controller-r1.json'),JSON.stringify(receipt,null,2)+'\n',{encoding:'utf8'});
async function phase(name,args,limit){
 const started=Date.now(),stdout=[],stderr=[];let timedOut=false,error=null;
 const child=spawn(node,args,{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});
 receipt.phases.push({name,args,pid:child.pid,limitMs:limit,status:'running'});put();
 const timer=setTimeout(()=>{timedOut=true;const killer=spawn(path.join(process.env.SystemRoot,'System32','taskkill.exe'),['/PID',String(child.pid),'/T','/F'],{windowsHide:true,stdio:'ignore'});killer.on('error',e=>{error=String(e);});},limit);
 child.stdout.on('data',x=>stdout.push(x));child.stderr.on('data',x=>stderr.push(x));child.on('error',e=>{error=String(e);});
 const ended=await new Promise(resolve=>child.on('close',(code,signal)=>resolve({code,signal})));clearTimeout(timer);
 const out=Buffer.concat(stdout),err=Buffer.concat(stderr);
 fs.writeFileSync(path.join(root,name+'.stdout'),out);fs.writeFileSync(path.join(root,name+'.stderr'),err);
 Object.assign(receipt.phases.at(-1),{...ended,timedOut,error,durationMs:Date.now()-started,stdoutBytes:out.length,stdoutSha256:hash(out),stderrBytes:err.length,stderrSha256:hash(err),status:ended.code===0&&!timedOut&&!error?'passed':'failed'});put();
 assert.equal(timedOut,false,name+' time bound');assert.equal(error,null,name+' spawn');assert.equal(ended.code,0,name+' actual exit');
}
(async()=>{
 try{
  assert.equal(path.resolve(process.execPath).toLowerCase(),path.resolve(node).toLowerCase());
  receipt.nodeSha256=hash(fs.readFileSync(node));assert.equal(receipt.nodeSha256,input.runtime.node.sha256);
  receipt.controllerSha256=hash(fs.readFileSync(__filename));receipt.inputSha256=hash(fs.readFileSync(path.join(root,'input.json')));
  receipt.resources={freeMemory:os.freemem(),freeDisk:Number(fs.statfsSync(root).bavail)*Number(fs.statfsSync(root).bsize)};
  assert.ok(receipt.resources.freeMemory>2*1024**3);assert.ok(receipt.resources.freeDisk>1024**3);
  put();await phase('hydrate-native-r1',['--max-old-space-size=384',path.join(root,'hydrate.cjs')],30000);
  await phase('syntax-native-r1',['--check',path.join(root,'receive-browser-r1.mjs')],30000);
  await phase('browser-native-r1',['--max-old-space-size=384',path.join(root,'receive-browser-r1.mjs'),'--root',path.join(root,'source'),'--browser',input.runtime.chrome.path,'--output',path.join(root,'browser-r1'),'--manifest',path.join(root,'expected.json')],240000);
  receipt.status='passed';
 }catch(e){receipt.status='failed';receipt.error=e.stack??String(e);process.exitCode=1;}
 finally{receipt.finished=new Date().toISOString();put();console.log(JSON.stringify(receipt));}
})();