import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const inputs = JSON.parse(await readFile(join(root, 'public-source-inputs.json'), 'utf8'));
const started = new Date().toISOString();
const receipt = {format:'recallweave-existing-pages-public-receiving/1', started_at:started, node:process.version,
  source:inputs, redirects:[], assets:[], errors:[], decision:'pending'};
const hash = (name, bytes) => createHash(name).update(bytes).digest('hex');
const gitBlob = bytes => createHash('sha1').update('blob '+bytes.length+'\0').update(bytes).digest('hex');
const headers = response => Object.fromEntries(['date','server','location','content-type','content-length','last-modified','etag','cache-control','age','x-github-request-id'].flatMap(k => response.headers.has(k) ? [[k,response.headers.get(k)]] : []));
await mkdir(join(root,'served'), {recursive:true});
try {
  for (const path of ['', 'courses/mendelian-inheritance.json']) {
    const url = 'https://jacob-met.github.io/RecallWeave/'+path;
    const response = await fetch(url,{redirect:'manual',signal:AbortSignal.timeout(15000)});
    const bytes = Buffer.from(await response.arrayBuffer());
    const expected = 'https://jacobmetoyer.com/RecallWeave/'+path;
    const row = {url, at:new Date().toISOString(),status:response.status, headers:headers(response),
      body_bytes:bytes.length, body_sha256:hash('sha256',bytes),expected_location:expected,
      accepted:[301,302,307,308].includes(response.status) && response.headers.get('location')===expected};
    receipt.redirects.push(row);
    console.log(JSON.stringify({redirect:url,status:row.status,location:response.headers.get('location'),accepted:row.accepted}));
  }
  for (const asset of inputs.assets) {
    const url = 'https://jacobmetoyer.com/RecallWeave/'+asset.path;
    const response = await fetch(url,{redirect:'error',signal:AbortSignal.timeout(15000)});
    const bytes = Buffer.from(await response.arrayBuffer());
    const destination = join(root,'served',asset.path);
    await mkdir(dirname(destination),{recursive:true});
    await writeFile(destination,bytes);
    const row={path:asset.path,url,at:new Date().toISOString(),status:response.status,headers:headers(response),
      bytes:bytes.length,sha256:hash('sha256',bytes),git_blob:gitBlob(bytes),expected_git_blob:asset.sha,
      expected_bytes:asset.size,accepted:response.status===200 && bytes.length===asset.size && gitBlob(bytes)===asset.sha};
    receipt.assets.push(row);
    console.log(JSON.stringify({asset:row.path,status:row.status,bytes:row.bytes,git_blob:row.git_blob,accepted:row.accepted}));
  }
} catch(error) {
  receipt.errors.push({name:error.name,message:error.message,cause:error.cause?.message ?? null});
}
receipt.finished_at=new Date().toISOString();
receipt.decision=receipt.errors.length===0 && receipt.redirects.length===2 && receipt.redirects.every(x=>x.accepted) && receipt.assets.length===inputs.assets.length && receipt.assets.every(x=>x.accepted) ? 'accepted' : 'not-accepted';
receipt.limits=['Exact receiving covers only the twenty-one declared assets, not every deployed leaf.',
  'Existing Pages logs identify the deployed commit separately from the selected public byte checks.',
  'No learner browser run, configuration change, credentials, TLS exception, or deployment request was performed.'];
await writeFile(join(root,'public-receiving.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({decision:receipt.decision,errors:receipt.errors,finished_at:receipt.finished_at}));
process.exitCode=receipt.decision==='accepted'?0:1;
