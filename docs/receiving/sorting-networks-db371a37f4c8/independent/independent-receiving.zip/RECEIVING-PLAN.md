# RecallWeave #253 — independent receiving freeze plan

Root receiver: estate-db371a37f4c8. Exact original ec07bf3989132130759e5c00c6cb02eef19709d3 / a839b6877bf2824f134443829d1ce62e1bd79e50. The 23-file closure was independently matched to the complete actual Git tree before native admission. Candidate source, authored tests, answer keys and outcomes are unread.

## Independent mathematical expectations

LITERAL-GOLD.json contains independently hand-derived full vectors and strict swap flags for the three public presets, equal/negative values, six nonadjacent wires, empty networks and the 30-comparator boundary. The missing-final-comparator network has exactly four binary witnesses: ordinals 5,6,9,10 (0101,0110,1001,1010), all output 0101. Full three/four-wire presets pass 8/8 and16/16. Empty six-wire network passes only the seven monotone binary vectors.

The separately authored reference-oracle.mjs will use conditional exchange, enumerated binary words and ordinary numeric permutation sorting, never candidate code. It will retain every step and every binary case according to the public API. Insertion schedules for each n=2..6 and all n! distinct-value permutations independently check the reference model and candidate generality. This is bounded algorithm receiving, not a performance benchmark. The threshold proof is checked directly; primary support is Har-Peled §§24.2–24.3, https://sarielhp.org/teach/notes/algos/files/24_sortnet.pdf, directly opened by root.

The programmatic boundary will accept exact {wires,values,comparators}, 2..6 wires,0..30 ordered pairs, inclusive[-999,999] integers and negative-zero normalization; reject missing/extra fields, invalid types/lengths/numeric values, invalid or reversed wire pairs and31 comparators. The text boundary follows the pre-admission API addendum: signed ASCII decimals, whitespace-separated values, exactly two tokens per comparator row, interior blank-row refusal, permitted empty whole comparator editor, explicit length limits. Public configuration snapshots must copy/freeze nested arrays and preserve the full accepted observation after caller mutations.

## Independent course answers

COURSE-BLIND.json contains all12 prompts/options with no answer keys or explanations. COURSE-ANSWERS.json records root's independently selected indices and reasons before full course or candidate source disclosure. After source admission, compare every key and explanation against these answers and the scoped mathematics; do not infer correctness from the unchanged parser.

## Original native boundary

Before candidate exposure, rehash/copy the exact23 originals to a new root-private directory. Rehash every173 existing Playwright donor file and installed Node/Edge executable; no install, server or registry/PATH changes. Fresh MSI/Veria/boot/resource guard enforces C>=1GiB,D>=1GiB,memory>=2GiB. Original Node parser receiving covers the independent two-question fixture, complete immutable copy/roundtrip and malformed later-item refusal.

Direct-open the unchanged original demo in installed headless Edge with ordinary sandbox-enabled pipe transport, own D temp/profile and offline context. Import and cancel the valid fixture without changing a begun bundled session; refuse a malformed later item without changing it; explicitly start the valid fixture, answer one wrong and one right, complete review, retry the missed question, preserve first answers, write and download exact notes. Capture desktop1360x900 and phone390x844 controls and record actual bounds. No physical-device claim.

## Candidate receiving after original freeze and course-answer freeze

Semantic adapter names may be mapped to the published API only; literal gold and reference logic remain exact. Compare complete trace and binary observations, every case ordinal/failure list, parsed editor values and exact JSON formatting. Do not truncate expected cases. Preserve all refusals and failed observers.

Actual direct-open shipped lab: explicit initial Run; all three public presets; authored/binary trace switching leaves draft/config intact; complete64-row six-wire table; a30-comparator view; every draft field and preset retires result plus config/observation downloads until a successful explicit Run; invalid edit/refusal shows no stale acceptance. Fixed lesson download stays available. Download actual configuration, full observation and exact lesson and compare bytes/values. Observe only file/blob/data requests, no persistent storage writes; scoped screenshot/render checks cover desktop1360x900 and phone390x844, with genuine horizontal table/diagram scrolling permitted if controls stay usable.

Import the actual shipped12-question course into the exact unchanged learner, explicitly start, answer from root's frozen keys (one deliberate first error), complete all12, inspect review/correction, practice the missed item, enter/download notes, verify original first-answer trace unchanged. This is native software/subject receiving, not learning efficacy.

No candidate checks or gameplay are to be repeated just to repair evidence serialization. Close owned native processes by actual identity/creation; preserve mismatched transport or PID reuse. Seal exact source, original freezes, observations, screenshots, downloads and corrections only after meaningful results are known. No ref/PR/main/tag/Actions operation belongs to this receiving phase.
