import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const source=process.env.UNITS_MODEL_PATH;
const sourceSHA=createHash('sha256').update(readFileSync(source)).digest('hex');
assert.equal(sourceSHA,process.env.UNITS_MODEL_SHA256);
const {parseUnitExpression,convertUnits}=await import(pathToFileURL(source).href);
const cases=[
 {expression:'(cm^2)^3',target:'m^6',dimensions:[6,0,0],numerator:'1',denominator:'1000000000000'},
 {expression:'(m^2)^-1',target:'m^-2',dimensions:[-2,0,0],numerator:'1',denominator:'1'},
 {expression:'(cm^3)^0',target:'1',dimensions:[0,0,0],numerator:'1',denominator:'1'},
 {expression:'(cm/s)^2',target:'m^2/s^2',dimensions:[2,0,-2],numerator:'1',denominator:'10000'}
];
const results=[];
for(const c of cases){
 const original=parseUnitExpression(c.expression), converted=convertUnits('1',c.expression,c.target);
 assert.deepEqual(original.dimensions,c.dimensions);
 assert.equal(converted.result.numerator,c.numerator);
 assert.equal(converted.result.denominator,c.denominator);
 let reparsed,error;
 try{reparsed=parseUnitExpression(original.normalized);}catch(e){error={name:e.name,message:e.message};}
 const equivalent=!!reparsed && JSON.stringify(reparsed.dimensions)===JSON.stringify(original.dimensions)&&reparsed.scale.numerator===original.scale.numerator&&reparsed.scale.denominator===original.scale.denominator;
 results.push({input:c,original,converted,normalizedReparse:reparsed??null,error:error??null,equivalent});
}
const receipt={sourceSHA,source,cases:results,criterion:'For these short inputs, serializing a normalized expression must retain grouping and be parseable with the same dimensions and exact scale. This probes normalization semantics; original arithmetic remains separately recorded.'};
writeFileSync(process.env.UNITS_PROBE_OUTPUT,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({sourceSHA,passed:results.filter(x=>x.equivalent).length,failed:results.filter(x=>!x.equivalent).length,normalizations:results.map(x=>({input:x.input.expression,normalized:x.original.normalized,equivalent:x.equivalent}))}));
process.exitCode=results.every(x=>x.equivalent)?0:1;
