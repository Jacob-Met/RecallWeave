'use strict';
// Independent current-main adapter probes. Production files are read-only inputs.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {createHash}=require('node:crypto'),{pathToFileURL}=require('node:url');
const {chromium}=require('/home/jacob/.cache/returnby-backup-8b336fefde84/node_modules/playwright');
const root=__dirname, source=path.join(root,'source'), output=path.join(root,'evidence');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'source-manifest.json')));
const sourceNames=new Set(manifest.files.map(x=>x.path));
const sha=b=>createHash('sha256').update(b).digest('hex');
const digest=p=>sha(fs.readFileSync(p));
const receipt={started:new Date().toISOString(),base:manifest.receiving_base,manifestSha256:digest(path.join(root,'source-manifest.json')),groups:[],surfaces:[],jsErrors:[],externalRequests:[]};
const save=()=>fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
function verifySources(stage){
  for(const f of manifest.files){const b=fs.readFileSync(path.join(source,f.path));assert.equal(sha(b),f.sha256,f.path);assert.equal(createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex'),f.blob,f.path);}
  receipt[stage]={verifiedFiles:manifest.files.length};
}
function deck(label){
 const counts=label==='A'?[2,3,4]:[6,2,2], answers=label==='A'?[1,2,3]:[5,0,1];
 return {format:'recallweave-deck/1',title:'Shared course title — explicit version required',
   attribution:'Synthetic '+label+'-only review fixture',license:label+'-only fixture license',
   concepts:[label+'-only concept'],items:counts.map((count,i)=>({
     id:'same-id-'+i,concept:label+'-only concept',prerequisites:[],
     prompt:label+'-only question '+i+' with the same public ID as the other version.',
     options:Array.from({length:count},(_,j)=>label+'-only canonical '+i+':'+j+' <literal> & "quoted"'),
     answer:answers[i],explanation:label+'-only explanation '+i,transfer:label+'-only transfer '+i
   }))};
}
const A=deck('A'),B=deck('B');
for(const [label,value]of[['A',A],['B',B]])fs.writeFileSync(path.join(root,'fixtures','same-title-'+label+'.json'),JSON.stringify(value,null,2)+'\n');
const mime={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.json':'application/json'};
const server=http.createServer((req,res)=>{
 try{const n=decodeURIComponent(new URL(req.url,'http://localhost').pathname).replace(/^\//,'')||'index.html';
 if(!sourceNames.has(n)){res.writeHead(404);res.end();return;}
 res.writeHead(200,{'Content-Type':mime[path.extname(n)]||'application/octet-stream'});res.end(fs.readFileSync(path.join(source,n)));
 }catch{res.writeHead(404);res.end();}
});
let browser,origin;
async function activate(page,selector){
 const target=page.locator(selector);await target.focus();assert.equal(await target.evaluate(n=>n===document.activeElement),true,'Focused '+selector);await page.keyboard.press('Enter');
}
async function uploadDeck(page,value,start=true){
 await page.locator('#deck-file').setInputFiles({name:'same-course.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(value))});
 await page.locator('#start-deck').waitFor({state:'visible'});
 assert.equal(await page.locator('#deck-preview-title').textContent(),value.title);
 if(start){await activate(page,'#start-deck');await page.locator('[data-choice]').first().waitFor({state:'visible'});}
}
async function ensureTracePanel(page){
 if(await page.locator('#trace-archive-panel').getAttribute('open')===null)await activate(page,'#trace-archive-panel > summary');
}
async function firstSession(page,value,choiceFor){
 const sequence=[];
 for(let i=0;i<value.items.length;i++){
  const prompt=await page.locator('.question-card h2').textContent(),item=value.items.find(x=>x.prompt===prompt);assert(item);assert(!sequence.includes(item.id));
  const choice=choiceFor(item);sequence.push(item.id);
  await activate(page,'[data-choice="'+choice+'"]');await activate(page,'#next-button');
 }
 await page.locator('#first-try-summary').waitFor({state:'visible'});return sequence;
}
async function practiceAnswer(page,value){
 const prompt=await page.locator('.practice-card h2').textContent(),item=value.items.find(x=>x.prompt===prompt);assert(item,'Current practice must come from selected course');
 const actual=await page.locator('[data-practice-choice]').evaluateAll(ns=>ns.map(n=>({canonical:Number(n.dataset.practiceChoice),text:[...n.childNodes].filter(x=>x.nodeType===Node.TEXT_NODE).map(x=>x.textContent).join('')})));
 assert.equal(actual.length,item.options.length);for(const v of actual)assert.equal(v.text,item.options[v.canonical]);
 await activate(page,'[data-practice-choice="'+item.answer+'"]');return item.id;
}
async function saveTrace(page,observed,label){
 await ensureTracePanel(page);assert.equal(await page.locator('#save-trace-button').isEnabled(),true);
 const pending=page.waitForEvent('download');await activate(page,'#save-trace-button');const file=await pending;
 assert.match(file.suggestedFilename(),/^recallweave-learning-trace-\d{4}-\d{2}-\d{2}\.json$/);
 const destination=path.join(observed.directory,label+'.json');await file.saveAs(destination);assert.equal(await file.failure(),null);
 const bytes=fs.readFileSync(destination),document=JSON.parse(bytes);assert.equal(document.format,'recallweave.learning-trace');
 const result={label,file:destination,bytes:bytes.length,sha256:sha(bytes),document};
 observed.downloads.push({label,path:path.relative(root,destination),bytes:result.bytes,sha256:result.sha256});
 return result;
}
function sameState(actual,expected){
 const {savedAt:a,...left}=actual,{savedAt:b,...right}=expected;assert.deepEqual(left,right,'Every archived state field except save timestamp must be preserved');
}
async function loadTrace(page,archive,{delayName,expectError=false}={}){
 await ensureTracePanel(page);
 const name=delayName||'same-trace.json';
 await page.locator('#trace-file').setInputFiles({name,mimeType:'application/json',buffer:fs.readFileSync(archive.file)});
 if(delayName){
  await page.waitForFunction(name=>globalThis.__independentTraceReads.pending.some(x=>x.name===name&&!x.released),name);
  assert.match(await page.locator('#trace-restore-status').textContent(),/Reading/);return;
 }
 if(expectError){await page.waitForFunction(()=>/different course|could not be read|not supported/.test(document.getElementById('trace-restore-status').textContent));return;}
 await page.locator('#trace-preview').waitFor({state:'visible'});assert.match(await page.locator('#trace-restore-status').textContent(),/Preview ready/);
}
async function releaseRead(page,name){
 await page.evaluate(async name=>{
  const item=globalThis.__independentTraceReads.pending.find(x=>x.name===name&&!x.released);if(!item)throw new Error('No delayed read '+name);await item.release();
 },name);
}
async function assertPaused(page,total,count){
 assert.match(await page.locator('#practice-status').textContent(),new RegExp('Practice paused: '+count+' of '+total+' answered'));
 assert.equal(await page.locator('#practice-button').isVisible(),true);
}
async function group(name,run){
 const started=Date.now();
 try{const evidence=await run();receipt.groups.push({name,passed:true,milliseconds:Date.now()-started,evidence});console.log('PASS '+name);}
 catch(e){receipt.groups.push({name,passed:false,milliseconds:Date.now()-started,error:e.stack});throw e;}
 finally{save();}
}
async function prepareTraces(page,observed){
 await uploadDeck(page,A);await firstSession(page,A,item=>(item.answer+1)%item.options.length);
 await activate(page,'#practice-button');const firstPracticeA=await practiceAnswer(page,A);await activate(page,'#back-to-review');
 const pausedA=await saveTrace(page,observed,'A-paused-original');
 await activate(page,'#practice-button');
 for(let i=1;i<A.items.length;i++){await practiceAnswer(page,A);await activate(page,'#practice-next');}
 const completeA=await saveTrace(page,observed,'A-completed-original');
 assert.equal(completeA.document.practice.answers.length,3);assert.deepEqual(completeA.document.firstAnswers,pausedA.document.firstAnswers);assert.deepEqual(completeA.document.mastery,pausedA.document.mastery);
 await uploadDeck(page,B);await firstSession(page,B,item=>item.id==='same-id-2'?item.answer:(item.answer+1)%item.options.length);
 await activate(page,'#practice-button');const firstPracticeB=await practiceAnswer(page,B);await activate(page,'#back-to-review');
 const pausedB=await saveTrace(page,observed,'B-paused-original');
 assert.equal(pausedB.document.practice.answers.length,1);
 return {pausedA,completeA,pausedB,firstPracticeA,firstPracticeB};
}
async function runSurface(surface){
 const observed={surface,directory:path.join(output,surface),downloads:[],delayedReads:[]};fs.mkdirSync(observed.directory,{recursive:true});receipt.surfaces.push(observed);
 const ctx=await browser.newContext({viewport:{width:1280,height:960},acceptDownloads:true});
 await ctx.addInitScript(()=>{
  Math.random=()=>0;
  const original=File.prototype.text;
  globalThis.__independentTraceReads={pending:[]};
  File.prototype.text=function(){
   if(!this.name.startsWith('delay-'))return original.call(this);
   const file=this;
   return new Promise((resolve,reject)=>{
    const item={name:file.name,released:false,release:async()=>{item.released=true;try{resolve(await original.call(file));}catch(error){reject(error);}}};
    globalThis.__independentTraceReads.pending.push(item);
   });
  };
 });
 const fileUrl=pathToFileURL(path.join(source,'demo.html')).href;
 await ctx.route('**/*',route=>{
  const url=route.request().url();if(url.startsWith(origin+'/')||url===fileUrl||url.startsWith('blob:')||url.startsWith('data:'))return route.continue();
  receipt.externalRequests.push({surface,url});return route.abort();
 });
 const page=await ctx.newPage();page.setDefaultTimeout(7000);page.on('pageerror',e=>receipt.jsErrors.push({surface,error:e.message}));
 try{
  await page.goto(surface==='modular'?origin+'/index.html':fileUrl);await page.locator('#start-button').waitFor();
  const {pausedA,completeA,pausedB,firstPracticeB}=await prepareTraces(page,observed);
  await group(surface+': a delayed old-course read cannot supersede the replacement course or its newer trace preview',async()=>{
   await uploadDeck(page,A);
   await loadTrace(page,pausedA,{delayName:'delay-old-course-A.json'});
   await uploadDeck(page,B);
   assert.equal(await page.locator('#trace-preview').isHidden(),true);assert.match(await page.locator('#trace-restore-status').textContent(),/lesson changed/);
   assert.equal(await page.locator('#step-count').textContent(),'0 / 3');
   await loadTrace(page,pausedB);
   const preview=await page.locator('#trace-preview-summary').textContent(),lesson=await page.locator('#session-content').innerHTML();
   await releaseRead(page,'delay-old-course-A.json');
   assert.equal(await page.locator('#trace-preview').isVisible(),true);assert.equal(await page.locator('#trace-preview-summary').textContent(),preview);
   assert.match(await page.locator('#trace-restore-status').textContent(),/Preview ready/);assert.equal(await page.locator('#session-content').innerHTML(),lesson);
   await activate(page,'#restore-trace-confirm');await assertPaused(page,2,1);
   const restored=await saveTrace(page,observed,'B-after-stale-A-read');sameState(restored.document,pausedB.document);
   return {oldCourse:'A',activeCourse:'B',sameTitle:A.title===B.title,sameItemIds:A.items.map(i=>i.id),restoredSha256:restored.sha256};
  });
  await group(surface+': staged replacement leaves restore explicit; starting it invalidates the old course preview',async()=>{
   await uploadDeck(page,A);await loadTrace(page,pausedA);
   const before=await page.locator('#session-content').innerHTML();
   await uploadDeck(page,B,false);
   assert.equal(await page.locator('#trace-preview').isVisible(),true);assert.equal(await page.locator('#session-content').innerHTML(),before);
   await activate(page,'#restore-trace-confirm');await assertPaused(page,3,1);
   assert.equal(await page.locator('#start-deck').isVisible(),true);
   const restored=await saveTrace(page,observed,'A-restored-with-B-staged');sameState(restored.document,pausedA.document);
   await loadTrace(page,completeA);
   assert.match(await page.locator('#trace-preview-summary').textContent(),/Practice: 3 of 3/);
   await activate(page,'#start-deck');
   assert.equal(await page.locator('#trace-preview').isHidden(),true);assert.equal(await page.locator('#trace-file').inputValue(),'');
   assert.match(await page.locator('#trace-restore-status').textContent(),/lesson changed/);
   assert.match(await page.locator('.question-card h2').textContent(),/^B-only/);assert.equal(await page.locator('#step-count').textContent(),'0 / 3');
   assert.equal(await page.locator('#save-trace-button').isDisabled(),true);
   return {stagedCourse:'B',restoredCourse:'A',startedCourse:'B',restoredSha256:restored.sha256};
  });
  await group(surface+': same-title same-ID foreign completion is rejected, and restored current practice resumes only remaining current choices',async()=>{
   const before=await page.locator('#session-content').innerHTML();
   await loadTrace(page,completeA,{expectError:true});
   assert.match(await page.locator('#trace-restore-status').textContent(),/different course or course version/);
   assert.equal(await page.locator('#trace-preview').isHidden(),true);assert.equal(await page.locator('#session-content').innerHTML(),before);
   await loadTrace(page,pausedB);await activate(page,'#restore-trace-confirm');await assertPaused(page,2,1);
   await loadTrace(page,pausedB); // A preview can coexist with an unchanged paused state.
   await activate(page,'#practice-button');
   assert.equal(await page.locator('#trace-preview').isVisible(),true,'Entering practice without answering has not changed the archived trace');
   const resumed=await practiceAnswer(page,B);assert.notEqual(resumed,firstPracticeB);
   assert.equal(await page.locator('#trace-preview').isHidden(),true,'Recorded practice invalidates stale preview');
   assert.match(await page.locator('#trace-restore-status').textContent(),/lesson changed/);
   await activate(page,'#practice-next');assert.match(await page.locator('#practice-status').textContent(),/2 of 2 correctly on retry/);
   const complete=await saveTrace(page,observed,'B-completed-after-restore');
   assert.deepEqual(complete.document.firstAnswers,pausedB.document.firstAnswers);assert.deepEqual(complete.document.mastery,pausedB.document.mastery);
   assert.deepEqual(complete.document.practice.answers.slice(0,1),pausedB.document.practice.answers);
   assert.equal(complete.document.practice.answers.length,2);assert.deepEqual(new Set(complete.document.practice.answers.map(x=>x.item)).size,2);
   for(const answer of complete.document.practice.answers)assert.equal(answer.choice,B.items.find(x=>x.id===answer.item).answer);
   assert.equal(await page.locator('#practice-button').count(),0);
   return {foreignRejected:true,firstPractice:firstPracticeB,resumedItem:resumed,firstAnswersAndMasteryPreserved:true,completeSha256:complete.sha256};
  });
  await group(surface+': restarting the current imported course cancels delayed restore, and completed restore remains completed',async()=>{
   await uploadDeck(page,A);await loadTrace(page,completeA);await activate(page,'#restore-trace-confirm');
   assert.match(await page.locator('#practice-status').textContent(),/3 of 3 correctly on retry/);
   await loadTrace(page,pausedA,{delayName:'delay-restart-A.json'});
   await activate(page,'#reset-button');
   assert.equal(await page.locator('#start-button').isVisible(),true);assert.equal(await page.locator('#step-count').textContent(),'0 / 3');
   assert.match(await page.locator('#lesson-map').textContent(),/A-only concept/);
   await releaseRead(page,'delay-restart-A.json');
   assert.equal(await page.locator('#trace-preview').isHidden(),true);assert.match(await page.locator('#trace-restore-status').textContent(),/lesson changed/);
   assert.equal(await page.locator('#save-trace-button').isDisabled(),true);
   const before=await page.locator('#session-content').innerHTML();
   await loadTrace(page,completeA);assert.equal(await page.locator('#session-content').innerHTML(),before);
   await activate(page,'#restore-trace-confirm');
   assert.match(await page.locator('#practice-status').textContent(),/3 of 3 correctly on retry/);assert.equal(await page.locator('#practice-button').count(),0);
   assert.match(await page.locator('#first-try-summary').textContent(),/0 of 3/);
   const restored=await saveTrace(page,observed,'A-completed-after-restart');sameState(restored.document,completeA.document);
   return {course:'A',restartProgress:'0 / 3',restoredPracticeAnswers:restored.document.practice.answers.length,completeSha256:restored.sha256};
  });
  observed.delayedReads=await page.evaluate(()=>globalThis.__independentTraceReads.pending.map(({name,released})=>({name,released})));
  assert.equal(observed.delayedReads.length,2);assert(observed.delayedReads.every(x=>x.released));
 }finally{await ctx.close();}
}
(async()=>{
 try{
  verifySources('sourceBefore');await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;
  browser=await chromium.launch({headless:true,executablePath:'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome',
   args:['--no-sandbox','--disable-dev-shm-usage'],env:{...process.env,TMPDIR:'/dev/shm/rw490f-ir2tmp'}});
  receipt.browser=browser.version();receipt.node=process.version;receipt.harnessSha256=digest(__filename);
  for(const surface of ['modular','standalone'])await runSurface(surface);
  assert.equal(receipt.jsErrors.length,0);assert.equal(receipt.externalRequests.length,0);receipt.passed=true;
 }catch(e){receipt.passed=false;receipt.error=e.stack;console.error(e.stack);process.exitCode=1;}
 finally{
  if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));
  try{verifySources('sourceAfter');}catch(e){receipt.passed=false;receipt.sourceError=e.stack;process.exitCode=1;}
  receipt.finished=new Date().toISOString();save();
  console.log(JSON.stringify({passed:receipt.passed,groups:receipt.groups.map(x=>({name:x.name,passed:x.passed})),downloads:receipt.surfaces.reduce((n,x)=>n+x.downloads.length,0),jsErrors:receipt.jsErrors,externalRequests:receipt.externalRequests}));
 }
})();
