import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import cp from 'node:child_process';
import crypto from 'node:crypto';

const source = path.resolve(process.argv[2] || '/dev/shm/estate-60b2c08feb01-recall-graph/source');
const output = path.resolve(process.argv[3] || '/dev/shm/estate-60b2c08feb01-recall-graph/evidence/native-final');
const temporary = fs.mkdtempSync('/dev/estate-60b2c08feb01-graph-native-');
const git = args => cp.execFileSync('git', args, { cwd: source, encoding: 'utf8' }).trim();
const sha256 = data => crypto.createHash('sha256').update(data).digest('hex');
const gitBlob = data => crypto.createHash('sha1').update(`blob ${data.length}\0`).update(data).digest('hex');
const head = git(['rev-parse', 'HEAD']);
const tree = git(['rev-parse', 'HEAD^{tree}']);
const entries = git(['ls-tree', '-rz', head]).split('\0').filter(Boolean).map(row => {
  const [meta, name] = row.split('\t');
  const [mode, type, sha] = meta.split(' ');
  return { path: name, mode, type, sha };
});
const native = entries.filter(item => item.type === 'blob' &&
  !item.path.startsWith('docs/') && !item.path.startsWith('research/') && !item.path.startsWith('.github/') &&
  !/\.(png|jpg|jpeg|pdf|tar\.gz|zip|svg)$/u.test(item.path));
fs.mkdirSync(output, { recursive: true });
const receipt = { head, tree, node: process.version, sourcePins: {}, commands: [], allPass: false };
try {
  assert.equal(git(['status', '--porcelain']), '', 'The source checkout is frozen.');
  for (const item of native) {
    const bytes = cp.execFileSync('git', ['cat-file', 'blob', item.sha], { cwd: source });
    assert.equal(gitBlob(bytes), item.sha);
    const destination = path.join(temporary, item.path);
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    fs.writeFileSync(destination, bytes);
    fs.chmodSync(destination, item.mode === '100755' ? 0o755 : 0o644);
    receipt.sourcePins[item.path] = { gitBlob: item.sha, bytes: bytes.length, sha256: sha256(bytes) };
    if (fs.existsSync(path.join(source, item.path))) {
      assert.equal(sha256(fs.readFileSync(path.join(source, item.path))), sha256(bytes), `Materialized source: ${item.path}`);
    }
  }
  const run = (name, command, args) => {
    const result = cp.spawnSync(command, args, { cwd: temporary, encoding: 'utf8', env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' } });
    const log = (result.stdout || '') + (result.stderr || '');
    fs.writeFileSync(path.join(output, `${name}.log`), log);
    const record = { name, command, args, exitCode: result.status, signal: result.signal, error: result.error?.message, logBytes: Buffer.byteLength(log), logSha256: sha256(log), tail: log.split('\n').slice(-12).join('\n') };
    receipt.commands.push(record);
    return record;
  };
  const tests = fs.readdirSync(path.join(temporary, 'tests')).filter(name => name.endsWith('.test.mjs')).sort().map(name => `tests/${name}`);
  run('tests', process.execPath, ['--test', ...tests]);
  run('companion-build-check', process.execPath, ['tools/build-dependency-graphs.mjs', '--check']);
  const originalDemo = fs.readFileSync(path.join(temporary, 'demo.html'));
  const demo = run('existing-demo-build', 'python', ['-B', 'tools/make_demo.py']);
  demo.exactOriginalDemoPreserved = originalDemo.equals(fs.readFileSync(path.join(temporary, 'demo.html')));
  receipt.allSourceUnchanged = Object.entries(receipt.sourcePins).every(([name, pin]) =>
    sha256(fs.readFileSync(path.join(temporary, name))) === pin.sha256);
  assert.equal(git(['rev-parse', 'HEAD']), head);
  assert.equal(git(['status', '--porcelain']), '');
  receipt.allPass = receipt.commands.every(command => command.exitCode === 0) && demo.exactOriginalDemoPreserved && receipt.allSourceUnchanged;
} catch (error) {
  receipt.failure = { message: error.message, stack: error.stack };
} finally {
  fs.rmSync(temporary, { recursive: true, force: true });
  receipt.privateExportRemoved = true;
  receipt.harnessSha256 = sha256(fs.readFileSync(new URL(import.meta.url)));
  fs.writeFileSync(path.join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ head, tree, allPass: receipt.allPass, files: Object.keys(receipt.sourcePins).length, commands: receipt.commands, failure: receipt.failure, receipt: path.join(output, 'receipt.json') }));
}
process.exitCode = receipt.allPass ? 0 : 1;
