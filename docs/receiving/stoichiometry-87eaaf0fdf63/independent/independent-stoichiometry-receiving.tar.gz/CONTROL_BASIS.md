# Independent stoichiometry receiving controls

These controls were authored before reading the producer's implementation,
tests, fixtures, or course answer keys. The producer supplied only the fixed
reaction/domain/teaching contract, exported interface, enum values, and frozen
core pin. The numerical oracle uses Python exact fractions and an independent
species/atom inventory.

The three equations are checked for elemental conservation. Limiting identity
comes from coefficient-normalized capacities; positive ties and absent-reactant
outcomes have separate expectations. One-millimole near ties, smallest inputs,
upper bounds and fractional extents are deliberate controls against raw-amount
comparison, floating tie inference and integer truncation.

The content review will first reveal only each prompt and its options. The
receiver will record an independent answer and rationale before seeing the
embedded answer key and explanation. Browser receiving will execute the actual
direct-open HTML with a private supported Chromium profile and networking
disabled; it will inspect visible quantities and actual downloads, including
stale-result retirement.

Primary-source basis and full accepted scope are in receiver_contract.json.
All initial expected values are in oracle_cases.json; later adapters may map
the declared interface, but must not silently rewrite these controls.
