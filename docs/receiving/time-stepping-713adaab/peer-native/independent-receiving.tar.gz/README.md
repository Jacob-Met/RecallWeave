# Independent time-stepping mathematical receiving

This packet receives the frozen scalar teaching model from RecallWeave issue 204. The author core is preserved under received-source/ solely for exact source custody. No author source file was edited.

The receiver was frozen before core implementation inspection or import. It uses root's previously frozen, independent Python Fraction closed-form traces, not the author's tests. One actual native Node v26.3.0 process made 34 simulate API calls: 13 valid calls (nine parameter cases and four shared-endpoint refinements) plus 21 refusal calls. It checked all 244 returned states, 2,726 numerical comparisons and four cross-case obligations. All passed on the first execution, with exit 0 and empty stderr.

The original tolerance is 1e-12 absolute plus 2e-12 relative. Index/time, schemas, classification and mathematical-zero expectations are exact; nonzero expected values retain sign. The full result and raw exceptions remain in node.stdout.json. Counts of comparisons and API calls are not counts of independent empirical trials.

All 21 tracked input files, including all ten final author source files, preserved byte hashes and mtimes across receiving. before-map.json and after-map.json retain the exact observed source paths and identities. process-intent.json binds the actual executable bytes, argv and deadline; process-started.json and receipt.json bind the completed child. The namespace was admitted at a 128 MiB disk reserve under a 4 MiB total budget, without installs.

This is mathematical model receiving only. Browser, UI, course, learner, download and hosted integration gates remain separate. There is no whole-domain precision, physical-fit or measured learning-benefit claim. No product replay or harness correction occurred. Stored absolute paths describe the actual execution, not a portable-path guarantee; any future receiving must preserve these bytes and explicitly document path adaptation.

The compressed capsule contains every pre-seal payload with a separate exact manifest. All archive members were reopened and compared byte-for-byte. No corpus or unrelated operational data is included.
