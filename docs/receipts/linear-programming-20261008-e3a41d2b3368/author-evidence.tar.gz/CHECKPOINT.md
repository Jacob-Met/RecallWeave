Native source checkpoint: original bounded continuous linear-programming course and lab.

25 authored model/course/build tests passed. Independent model18 groups and16 blind lesson answers passed on exact model63e3a366/course d251a3bc. Browser gate remains incomplete: first actual rendering passed before snap-private-temp download failure; second launch timed out. Both raw receipts and original driver retained. No GitHub source/ref/PR or Actions execution.
