import pathlib,json,hashlib,subprocess,time,shutil,datetime
root=pathlib.Path("/Users/me/Developer/recallweave-quantum-states-20261009-713adaab")
source=root/"candidate";out=root/"receiving"/"native-r1"
free=shutil.disk_usage(root).free
assert free>=139460608,("capacity",free)
assert not out.exists();out.mkdir(parents=True)
def digest(b):return hashlib.sha256(b).hexdigest()
def inventory():
 return {p.relative_to(source).as_posix():{"bytes":p.stat().st_size,"sha256":digest(p.read_bytes()),"mtime_ns":p.stat().st_mtime_ns} for p in sorted(source.rglob("*")) if p.is_file()}
before=inventory()
cmd=["/opt/homebrew/bin/node","--test","--test-reporter=tap","--test-reporter-destination=stdout","--test-reporter=junit","--test-reporter-destination="+str(out/"junit.xml"),str(source/"tests/quantum-states.test.mjs")]
(root/"receiving"/"native-r1"/"intent.json").write_text(json.dumps({"command":cmd,"before":before,"free":free,"timeout":30},indent=2)+"\n")
started=time.monotonic()
try:
 p=subprocess.run(cmd,cwd=source,capture_output=True,timeout=30)
 (out/"stdout.txt").write_bytes(p.stdout);(out/"stderr.txt").write_bytes(p.stderr)
 result={"exit":p.returncode,"stdout_sha256":digest(p.stdout),"stderr_sha256":digest(p.stderr),"elapsed":time.monotonic()-started}
except subprocess.TimeoutExpired as error:
 (out/"stdout.txt").write_bytes(error.stdout or b"");(out/"stderr.txt").write_bytes(error.stderr or b"")
 result={"timeout":True,"elapsed":time.monotonic()-started}
checks=[]
for rel in ["courses/quantum-states-core.mjs","courses/quantum-states-ui.mjs"]:
 c=subprocess.run(["/opt/homebrew/bin/node","--check",str(source/rel)],capture_output=True,timeout=10)
 checks.append({"path":rel,"exit":c.returncode,"stdout":c.stdout.decode(),"stderr":c.stderr.decode()})
blindpath=pathlib.Path("/Users/me/Developer/chatgpt-root-integration-713adaab/quantum-root-blind-answers-r1.json")
blindraw=blindpath.read_bytes()
assert digest(blindraw)=="ce40613283c06b71ae3eda0925b5c14a0cbc79cd0185efd8ff8acd7a6f4fda7a"
course=json.loads((source/"courses/quantum-states.json").read_bytes())
answers={a["id"]:a["option_index"] for a in json.loads(blindraw)["answers"]}
comparison=[{"id":i["id"],"independent":answers[i["id"]],"authored":i["answer"],"match":answers[i["id"]]==i["answer"]} for i in course["items"]]
after=inventory()
report={"schema":"quantum-native-author-receiving/1","utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source":str(source),"command":cmd,"result":result,"syntax":checks,"blind_answer_comparison":comparison,"blind_answer_sha256":digest(blindraw),"before":before,"after":after,"source_bytes_and_mtimes_unchanged":before==after,"browser_started":False,"independent_root_matrix_receiver":"pending root-owned run"}
report["passed"]=result.get("exit")==0 and all(c["exit"]==0 for c in checks) and all(x["match"] for x in comparison) and before==after
raw=(json.dumps(report,indent=2)+"\n").encode();(out/"report.json").write_bytes(raw)
print(json.dumps({"passed":report["passed"],"exit":result.get("exit"),"syntax":checks,"blind_answers":len(comparison),"unchanged":before==after,"report_sha256":digest(raw),"report":str(out/"report.json")}))
raise SystemExit(0 if report["passed"] else 1)
