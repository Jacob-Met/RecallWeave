// Independent receiving review: real keyboard input, files, page code, and downloads.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const { pathToFileURL } = require('node:url');

const root = path.resolve(__dirname);
const source = path.join(root, 'source');
const output = path.join(root, 'evidence');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'source-manifest.json'), 'utf8'));
const expected = { ...manifest.changedSha256, ...manifest.preservedSha256 };
const browserBin = process.env.BROWSER_BIN;
const { chromium } = require(path.join(process.env.REVIEW_PLAYWRIGHT_ROOT, 'playwright'));
fs.mkdirSync(output);

function sha(content) { return crypto.createHash('sha256').update(content).digest('hex'); }
function hashes() {
  return Object.fromEntries(Object.keys(expected).map(name => [name, sha(fs.readFileSync(path.join(source, name)))]));
}
function makeDeckA() {
  const counts = [2, 3, 6];
  return {
    format: 'recallweave-deck/1', title: 'Deck A — shuffle and export α',
    attribution: 'A-only independent fixture attribution', license: 'A-only fixture license',
    concepts: ['Evidence α'],
    items: counts.map((count, index) => ({
      id: ['a', 'b', 'c'][index], concept: 'Evidence α', prerequisites: [],
      prompt: `A-only question ${index + 1}: use the recorded option.`,
      options: Array.from({ length: count }, (_, option) => `A-only ${count}-option choice ${option} <literal> & "quoted"`),
      answer: [0, 2, 0][index],
      explanation: `A-only explanation for the ${count}-option question.`,
      transfer: `A-only transfer ${index + 1}: describe the recorded choice.`,
    })),
  };
}
function makeDeckB() {
  return {
    format: 'recallweave-deck/1', title: 'Deck B — replacement β',
    attribution: 'B-only receiving fixture attribution', license: 'B-only fixture license',
    concepts: ['Transfer β'],
    items: [{
      id: 'c', concept: 'Transfer β', prerequisites: [],
      prompt: 'B-only replacement reuses a six-option question ID with two new choices.',
      options: ['B-only canonical zero ✓', 'B-only canonical one ✗'], answer: 0,
      explanation: 'B-only canonical zero is the recorded answer.', transfer: 'B-only transfer: keep source identity.',
    }],
  };
}
const A = makeDeckA();
const B = makeDeckB();
fs.writeFileSync(path.join(output, 'deck-A.json'), JSON.stringify(A, null, 2));
fs.writeFileSync(path.join(output, 'deck-B.json'), JSON.stringify(B, null, 2));

const mime = { '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  try {
    const name = decodeURIComponent(new URL(req.url, 'http://localhost').pathname).replace(/^\//, '') || 'index.html';
    if (!Object.hasOwn(expected, name)) { res.writeHead(404); res.end(); return; }
    const bytes = fs.readFileSync(path.join(source, name));
    res.writeHead(200, { 'Content-Type': mime[path.extname(name)] || 'application/octet-stream' });
    res.end(bytes);
  } catch { res.writeHead(404); res.end(); }
});

async function activate(page, selector) {
  const element = page.locator(selector);
  await element.focus();
  assert.equal(await element.evaluate(node => node === document.activeElement), true);
  await page.keyboard.press('Enter');
}
async function choices(page, practice = false) {
  return page.locator(practice ? '[data-practice-choice]' : '[data-choice]').evaluateAll(buttons => buttons.map(button => ({
    label: button.querySelector('.choice-key').textContent,
    text: [...button.childNodes].filter(node => node.nodeType === Node.TEXT_NODE).map(node => node.textContent).join(''),
  })));
}
async function answerByPosition(page, position, practice = false) {
  const buttons = page.locator(practice ? '[data-practice-choice]' : '[data-choice]');
  await buttons.first().focus();
  for (let step = 0; step < position; step++) await page.keyboard.press('Tab');
  assert.equal(await buttons.nth(position).evaluate(node => node === document.activeElement), true);
  await page.keyboard.press('Enter');
}
async function upload(page, deck) {
  await page.locator('#deck-file').setInputFiles({ name: 'same-lesson.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(deck)) });
  await page.locator('#start-deck').waitFor();
  assert.equal(await page.locator('#deck-preview-title').innerText(), deck.title);
}
async function download(page, directory, label) {
  const pending = page.waitForEvent('download');
  await activate(page, '#save-notes-button');
  const transfer = await pending;
  assert.equal(await transfer.failure(), null);
  assert.match(transfer.suggestedFilename(), /^recallweave-study-notes-\d{4}-\d{2}-\d{2}\.txt$/);
  const file = path.join(directory, label + '.txt');
  await transfer.saveAs(file);
  const bytes = fs.readFileSync(file);
  return { file, filename: transfer.suggestedFilename(), bytes: bytes.length, sha256: sha(bytes), text: bytes.toString('utf8') };
}

(async () => {
  const receipt = {
    candidate: manifest.candidate, base: manifest.base,
    harness_sha256: sha(fs.readFileSync(__filename)), node: process.version,
    checks: [], failures: [], source_before: hashes(), surfaces: [],
  };
  assert.deepEqual(receipt.source_before, expected);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  let browser;
  try {
    browser = await chromium.launch({ executablePath: browserBin, headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    receipt.browser = browser.version();
    for (const surface of ['modular', 'standalone']) {
      const directory = path.join(output, surface);
      fs.mkdirSync(directory);
      const context = await browser.newContext({ viewport: { width: 390, height: 844 }, acceptDownloads: true });
      await context.addInitScript(() => {
        window.__reviewEntropy = 0;
        Math.random = () => window.__reviewEntropy;
      });
      const page = await context.newPage();
      page.setDefaultTimeout(5000);
      const errors = [];
      const network = [];
      const standalone = pathToFileURL(path.join(source, 'demo.html')).href;
      const observations = { surface, orders: [], downloads: [], errors, network };
      page.on('pageerror', error => errors.push(String(error)));
      await page.route('**/*', route => {
        const url = route.request().url();
        const allowed = url.startsWith(origin + '/') || url === standalone;
        network.push({ url, action: allowed ? 'local source' : 'aborted' });
        return allowed ? route.continue() : route.abort();
      });
      let stage = 'keyboard-canonical-identity';
      try {
        await page.goto(surface === 'modular' ? origin + '/index.html' : standalone);
        await page.locator('#start-button').waitFor();
        await upload(page, A);
        await activate(page, '#start-deck');
        const firstOrders = new Map();
        const questionOrder = [];
        for (let index = 0; index < A.items.length; index++) {
          const prompt = await page.locator('.question-card h2').innerText();
          const item = A.items.find(candidate => candidate.prompt === prompt);
          assert.ok(item && !questionOrder.includes(item.id));
          questionOrder.push(item.id);
          const visible = await choices(page);
          const rotated = [...item.options.slice(1), item.options[0]];
          assert.deepEqual(visible.map(option => option.text), rotated);
          assert.deepEqual(visible.map(option => option.label), Array.from({ length: item.options.length }, (_, position) => String.fromCharCode(65 + position)));
          assert.equal(await page.locator('.choice literal').count(), 0, 'option markup is literal text');
          firstOrders.set(item.id, visible);
          observations.orders.push({ phase: 'first-session', item: item.id, visible });
          await answerByPosition(page, 0);
          assert.match(await page.locator('#feedback-slot strong').innerText(), /correction/);
          await activate(page, '#next-button');
        }
        assert.match(await page.locator('#first-try-summary').innerText(), /0 of 3/);
        const originalMastery = await page.locator('.mastery-row output').allTextContents();
        const first = await download(page, directory, 'first-session');
        observations.downloads.push({ ...first, text: undefined });
        for (const item of A.items) {
          assert.ok(first.text.includes(`Your first answer: ${item.options[1]}`));
          assert.ok(first.text.includes(`Correct answer: ${item.options[item.answer]}`));
        }
        assert.match(first.text, /0 of 3 connections correct on the first try/);
        const exportedOrder = questionOrder.map(id => first.text.indexOf(A.items.find(item => item.id === id).prompt));
        assert.ok(exportedOrder.every((position, index) => position >= 0 && (index === 0 || position > exportedOrder[index - 1])));
        receipt.checks.push(`${surface}: visible keyboard positions preserve canonical answer identity across 2/3/6 options and actual study-note bytes`);

        stage = 'practice-entropy-and-staged-deck';
        await page.evaluate(() => { window.__reviewEntropy = 0.999999; });
        await activate(page, '#practice-button');
        const answerPractice = async () => {
          const prompt = await page.locator('.practice-card h2').innerText();
          const item = A.items.find(candidate => candidate.prompt === prompt);
          assert.ok(item);
          const visible = await choices(page, true);
          assert.deepEqual(visible, firstOrders.get(item.id), 'practice keeps the first-session order despite changed entropy');
          observations.orders.push({ phase: 'practice-under-changed-entropy', item: item.id, visible });
          const correctPosition = visible.findIndex(option => option.text === item.options[item.answer]);
          assert.ok(correctPosition >= 0);
          await answerByPosition(page, correctPosition, true);
          assert.match(await page.locator('#practice-feedback strong').first().innerText(), /holds on retry/);
        };
        await answerPractice();
        await activate(page, '#back-to-review');
        const paused = await download(page, directory, 'paused-practice');
        observations.downloads.push({ ...paused, text: undefined });
        assert.match(paused.text, /Paused: 1 of 3 practice answers recorded; 1 correct on retry/);
        const pausedMarkup = await page.locator('#session-content').innerHTML();
        await upload(page, B);
        assert.equal(await page.locator('#session-content').innerHTML(), pausedMarkup);
        await activate(page, '#practice-button');
        const resumedMarkup = await page.locator('#session-content').innerHTML();
        await activate(page, '#cancel-deck');
        assert.equal(await page.locator('#session-content').innerHTML(), resumedMarkup);
        for (let index = 1; index < A.items.length; index++) {
          await answerPractice();
          await activate(page, '#practice-next');
        }
        assert.deepEqual(await page.locator('.mastery-row output').allTextContents(), originalMastery);
        assert.match(await page.locator('#first-try-summary').innerText(), /0 of 3/);
        const complete = await download(page, directory, 'completed-practice');
        observations.downloads.push({ ...complete, text: undefined });
        assert.match(complete.text, /Complete: 3 of 3 practice answers recorded; 3 correct on retry/);
        for (const item of A.items) {
          assert.ok(complete.text.includes(`Your first answer: ${item.options[1]}`));
          assert.ok(complete.text.includes(`Practice answer: ${item.options[item.answer]}`));
        }
        assert.equal(sha(fs.readFileSync(first.file)), first.sha256);
        receipt.checks.push(`${surface}: changed entropy and a staged/cancelled same-name replacement preserve paused practice order, first answers, and model estimates`);

        stage = 'fresh-reset-and-explicit-replacement';
        await upload(page, B);
        await activate(page, '#reset-button');
        assert.equal(await page.locator('#lesson-description').innerText(), A.title);
        await activate(page, '#start-button');
        const resetPrompt = await page.locator('.question-card h2').innerText();
        const resetItem = A.items.find(item => item.prompt === resetPrompt);
        assert.deepEqual((await choices(page)).map(option => option.text), resetItem.options, 'fresh session consumes changed entropy');
        assert.notDeepEqual(await choices(page), firstOrders.get(resetItem.id));
        await activate(page, '#start-deck');
        assert.equal(await page.locator('#lesson-description').innerText(), B.title);
        assert.equal(await page.locator('.question-card h2').innerText(), B.items[0].prompt);
        assert.deepEqual((await choices(page)).map(option => option.text), B.items[0].options, 'replacement reuses ID with a fresh two-option map');
        await answerByPosition(page, 0);
        await activate(page, '#next-button');
        const replacement = await download(page, directory, 'replacement-session');
        observations.downloads.push({ ...replacement, text: undefined });
        assert.ok(replacement.text.includes(B.title));
        assert.ok(replacement.text.includes(B.attribution));
        assert.ok(replacement.text.includes(B.license));
        assert.ok(replacement.text.includes(`Your first answer: ${B.items[0].options[0]}`));
        assert.ok(!replacement.text.includes('A-only'));
        assert.match(replacement.text, /1 of 1 connections correct on the first try/);
        assert.equal(replacement.filename, first.filename, 'normal same-day notes can share a suggested filename');
        assert.equal(sha(fs.readFileSync(first.file)), first.sha256);
        assert.equal(sha(fs.readFileSync(complete.file)), complete.sha256);
        await page.evaluate(() => { window.__reviewEntropy = 0; });
        await activate(page, '#reset-button');
        assert.equal(await page.locator('#lesson-description').innerText(), B.title);
        await activate(page, '#start-button');
        assert.deepEqual((await choices(page)).map(option => option.text), [...B.items[0].options].reverse());
        observations.orders.push({ phase: 'reset-selected-replacement', visible: await choices(page) });
        assert.deepEqual(errors, []);
        receipt.checks.push(`${surface}: fresh reset rebuilds option order, explicit same-name replacement uses new canonical content, and earlier downloaded notes remain intact`);
      } catch (error) {
        const failure = { surface, stage, error: String(error.stack || error) };
        receipt.failures.push(failure);
        try { await page.screenshot({ path: path.join(directory, 'failure.png') }); } catch {}
        console.log(JSON.stringify(failure));
      } finally {
        observations.finalText = await page.locator('#session-content').innerText().catch(() => '');
        fs.writeFileSync(path.join(directory, 'observations.json'), JSON.stringify(observations, null, 2));
        receipt.surfaces.push({ surface, errors });
        await context.close();
      }
    }
  } finally {
    await browser?.close();
    await new Promise(resolve => server.close(resolve));
  }
  receipt.source_after = hashes();
  assert.deepEqual(receipt.source_after, expected);
  receipt.source_unchanged = true;
  receipt.accepted = receipt.checks.length === 6 && receipt.failures.length === 0 && receipt.surfaces.every(surface => surface.errors.length === 0);
  fs.writeFileSync(path.join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ accepted: receipt.accepted, checks: receipt.checks, failures: receipt.failures }));
  process.exitCode = receipt.accepted ? 0 : 1;
})().catch(error => { console.error(error); process.exitCode = 2; });
