const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),cp=require("node:child_process");
const root="/home/ubuntu/hamon-receiving-bd1abdb2f886-20261009/fenwick",phase=process.argv[2];
if(!["explorer","consumer"].includes(phase))throw Error("Choose explorer or consumer");
const out=path.join(root,"browser-"+phase+"-v1"),receipt=path.join(root,"browser-"+phase+"-execution-v1.json");
const input=JSON.parse(fs.readFileSync(path.join(root,"input-v1.json"))),stage=JSON.parse(fs.readFileSync(path.join(root,"staging-v1.json")));
const hash=b=>crypto.createHash("sha256").update(b).digest("hex");
const git=b=>crypto.createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
const pin=p=>{const b=fs.readFileSync(p);return{bytes:b.length,sha256:hash(b),git_blob:git(b),mode:(fs.statSync(p).mode&511).toString(8)};};
async function binary(p){const sha=crypto.createHash("sha256");let bytes=0;for await(const b of fs.createReadStream(p)){bytes+=b.length;sha.update(b);}return{path:p,resolved:fs.realpathSync(p),bytes,sha256:sha.digest("hex"),mode:(fs.statSync(p).mode&511).toString(8)};}
const sources=()=>Object.fromEntries(input.files.map(f=>[f.path,pin(path.join(root,f.path))]));
function guard(){
 const cgroup=fs.readFileSync("/proc/self/cgroup","utf8").trim();if(cgroup!==input.expected_cgroup)throw Error("Admitted cgroup drift");
 const memory=Number(/^MemAvailable:\s+(\d+)/m.exec(fs.readFileSync("/proc/meminfo","utf8"))[1])*1024,s=fs.statfsSync(root),disk=s.bavail*s.bsize;
 const pressure=Object.fromEntries(["memory","io"].map(n=>[n,fs.readFileSync("/proc/pressure/"+n,"utf8")]));
 if(memory<2147483648||disk<268435456||Number(/^full avg10=([\d.]+)/m.exec(pressure.memory)[1])>2||Number(/^full avg10=([\d.]+)/m.exec(pressure.io)[1])>10)throw Error("Native resource guard");
 const events=fs.readFileSync(path.join("/sys/fs/cgroup",cgroup.slice(3),"memory.events"),"utf8");if(/^oom(?:_kill|_group_kill)? [1-9]/m.test(events))throw Error("Observed cgroup OOM");
 return{at:new Date().toISOString(),cgroup,memory_available:memory,disk_available:disk,pressure,cgroup_memory_events:events};
}
(async()=>{
 if(fs.existsSync(out)||fs.existsSync(receipt))throw Error("Read prior phase; no replay");
 if(phase==="consumer"){const first=JSON.parse(fs.readFileSync(path.join(root,"browser-explorer-execution-v1.json")));if(!first.pass)throw Error("Explorer and cleanup must pass first");}
 const beforeGuard=guard(),before=sources();if(JSON.stringify(before)!==JSON.stringify(stage.source_after))throw Error("Source staging drift");
 const runtime={};for(const k of["node","chrome_wrapper","chrome_binary"]){runtime[k]=await binary(stage.runtime[k].path);if(JSON.stringify(runtime[k])!==JSON.stringify(stage.runtime[k]))throw Error("Runtime binary drift");}
 const profileParent=path.join(root,"profiles");if(fs.readdirSync(profileParent).length)throw Error("Prior owned profile requires receiving/cleanup first");
 fs.mkdirSync(out);
 const result={schema:"recallweave-fenwick-pod-browser-execution/v1",phase,started_at:new Date().toISOString(),status:"running",outer_timeout_ms:600000,guard_before:beforeGuard,source_before:before,runtime_before:runtime,node_version:process.version,chrome_version:stage.runtime.chrome_version,controller:pin(__filename),signals:[]};
 const save=()=>{const temp=receipt+".tmp";fs.writeFileSync(temp,JSON.stringify(result,null,2)+"\n");fs.renameSync(temp,receipt);};save();
 const common=["--output",out,"--profile-parent",profileParent,"--browser-executable","/usr/bin/google-chrome"];
 const args=phase==="explorer"?[path.join(root,"receivers/fenwick-trees-browser.mjs"),"--html",path.join(root,"product/courses/fenwick-trees-explorer.html"),"--course",path.join(root,"product/courses/fenwick-trees.json"),"--expectations",path.join(root,"receivers/independent-expectations.json"),...common]:
 [path.join(root,"receivers/fenwick-trees-consumer.mjs"),"--demo",path.join(root,"consumer/demo.html"),"--downloaded-course",path.join(root,"browser-explorer-v1/fenwick-trees.json"),"--source-course",path.join(root,"product/courses/fenwick-trees.json"),...common];
 const env={...process.env,XDG_DATA_HOME:path.join(root,"xdg/data"),XDG_CONFIG_HOME:path.join(root,"xdg/config"),XDG_CACHE_HOME:path.join(root,"xdg/cache"),TMPDIR:path.join(root,"tmp")};
 result.argv=[process.execPath,...args];result.environment=Object.fromEntries(["XDG_DATA_HOME","XDG_CONFIG_HOME","XDG_CACHE_HOME","TMPDIR"].map(k=>[k,env[k]]));
 const stdout=fs.openSync(path.join(out,"stdout.txt"),"wx"),stderr=fs.openSync(path.join(out,"stderr.txt"),"wx");
 const child=cp.spawn(process.execPath,args,{cwd:root,env,detached:true,stdio:["ignore",stdout,stderr]});fs.closeSync(stdout);fs.closeSync(stderr);
 result.child_pid=child.pid;result.owned_process_group=child.pid;save();console.log(JSON.stringify({phase,child_pid:child.pid,argv:result.argv,receipt}));
 let timedOut=false,cleanupTimer;
 const timer=setTimeout(()=>{timedOut=true;result.outer_timeout=true;save();if(child.exitCode===null&&child.signalCode===null&&Number.isInteger(child.pid)){try{process.kill(-child.pid,"SIGTERM");result.signals.push({group:child.pid,signal:"SIGTERM",reason:"Own detached receiver group exceeded 600s"});}catch(e){result.signal_error=String(e);}save();cleanupTimer=setTimeout(()=>{if(child.exitCode===null&&child.signalCode===null){try{process.kill(-child.pid,"SIGKILL");result.signals.push({group:child.pid,signal:"SIGKILL",reason:"Own receiver group did not exit after TERM"});}catch(e){result.signal_error=String(e);}save();}},5000);}},600000);
 const end=await new Promise(resolve=>{child.once("error",error=>resolve({error:String(error)}));child.once("close",(code,signal)=>resolve({code,signal}));});clearTimeout(timer);clearTimeout(cleanupTimer);
 result.exit=end.code??null;result.signal=end.signal??null;result.error=end.error??null;result.outer_timeout=timedOut;
 result.stdout=pin(path.join(out,"stdout.txt"));result.stderr=pin(path.join(out,"stderr.txt"));
 const reportPath=path.join(out,"browser-report.json");if(fs.existsSync(reportPath)){result.report=pin(reportPath);const r=JSON.parse(fs.readFileSync(reportPath));result.browser_summary={status:r.status,checks:r.checks,cleanup:r.cleanup,spawnedBrowserExit:r.spawnedBrowserExit,browser:r.browser,images:r.images,downloads:r.savedDownloads,answers:r.answers?.length};}
 result.source_after=sources();result.runtime_after={};for(const k of["node","chrome_wrapper","chrome_binary"])result.runtime_after[k]=await binary(stage.runtime[k].path);
 result.profiles_after=fs.readdirSync(profileParent);result.guard_after=guard();
 const summary=result.browser_summary;
 result.pass=end.code===0&&!end.error&&!timedOut&&summary?.status==="passed"&&summary.cleanup?.status==="passed"&&summary.cleanup?.profileRemoved&&summary.spawnedBrowserExit?.exited&&result.profiles_after.length===0&&JSON.stringify(before)===JSON.stringify(result.source_after)&&JSON.stringify(runtime)===JSON.stringify(result.runtime_after);
 result.status=result.pass?"passed":"failed";result.finished_at=new Date().toISOString();save();console.log(JSON.stringify({phase,pass:result.pass,exit:result.exit,checks:summary?.checks,cleanup:summary?.cleanup,profiles_after:result.profiles_after,receipt:pin(receipt)}));process.exitCode=result.pass?0:1;
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
