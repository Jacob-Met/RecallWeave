import assert from 'node:assert/strict';
import {readFile,stat,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const blob=b=>createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex');
export async function receiveV2Delta(api,carrier){
 const {report,evaluate,activate,chooseFile,waitFor,navigate,download,capture,passed,key}=api;
 const root=join(carrier,'source-v2'),mbytes=await readFile(join(carrier,'reference/subject-v2.json')),manifest=JSON.parse(mbytes);
 assert.equal(sha(mbytes),'502b773c2fa8813e632820c2f334379c2aa7092587f6d6502dc06c1d89acb54e');
 const observe=async()=>{
  const actual={};
  for(const expected of manifest.files){
   const p=join(root,expected.path),b=await readFile(p),s=await stat(p);
   const row={sha256:sha(b),git_blob:blob(b),bytes:b.length,mode:s.mode&0o111?'100755':'100644'};
   for(const k of Object.keys(row))assert.equal(row[k],expected[k],expected.path+' '+k);
   actual[expected.path]=row;
  }
  const walk=async(folder,prefix='')=>{const paths=[];for(const e of await readdir(folder,{withFileTypes:true})){const p=prefix+e.name;if(e.isDirectory())paths.push(...await walk(join(folder,e.name),p+'/'));else{assert.ok(e.isFile());paths.push(p);}}return paths;};
  assert.deepEqual((await walk(root)).sort(),Object.keys(actual).sort());return actual;
 };
 const delta=report.correctedCourse={source:root,manifest:sha(mbytes),before:await observe(),status:'running'};
 try{
  const {parseDeck}=await import(pathToFileURL(join(root,'src/deck.mjs')));
  const bytes=await readFile(join(root,'courses/euclidean-algorithm.json')),deck=parseDeck(bytes.toString('utf8'));
  const item=deck.items.find(i=>i.id==='euclid-division-3');assert.ok(item);
  const prompt='When a nonnegative integer a is divided by a positive integer b, which condition gives the full allowed range of the Euclidean remainder r?';
  assert.equal(item.prompt,prompt);assert.equal(item.answer,1);
  await navigate(pathToFileURL(join(root,'courses/euclidean-algorithm-explorer.html')).href,390,844,'#download-course');
  assert.equal(await evaluate("document.querySelector('#results').hidden"),true);
  const course=await download('#download-course','v2-actual-euclidean-algorithm.json');
  assert.deepEqual(course.bytes,bytes);assert.equal(course.suggestedFilename,'euclidean-algorithm.json');
  assert.equal(await evaluate("document.querySelector('#results').hidden"),true);
  delta.actualDownload={name:course.name,path:course.path,sha256:course.sha256,bytes:bytes.length};
  await navigate(pathToFileURL(join(root,'demo.html')).href,390,844,'#start-button');
  await waitFor(()=>evaluate("!!document.querySelector('#trace-archive-panel')"),'V2 native learner initialized');
  const before=await evaluate("({session:document.querySelector('#session-content').innerHTML,progress:document.querySelector('#step-count').textContent,title:document.title})");
  await chooseFile('#deck-file',course.path);
  await waitFor(()=>evaluate("!document.querySelector('#deck-preview').hidden"),'V2 course preview');
  const preview=await evaluate("({prompts:[...document.querySelectorAll('.deck-questions strong')].map(e=>e.textContent),title:document.querySelector('#deck-preview-title').textContent})");
  assert.deepEqual(preview.prompts,deck.items.map(x=>x.prompt));assert.equal(preview.prompts[2],prompt);assert.equal(preview.title,deck.title);
  assert.deepEqual(await evaluate("({session:document.querySelector('#session-content').innerHTML,progress:document.querySelector('#step-count').textContent,title:document.title})"),before);
  await api.tabTo('#start-deck');await key('Enter');
  await waitFor(()=>evaluate("!!document.querySelector('.question-card h2')"),'V2 explicit Start');
  const preceding=[];
  for(let n=0;n<12;n++){
   const visible=await evaluate("document.querySelector('.question-card h2').textContent");
   if(visible===prompt)break;
   const previous=deck.items.find(x=>x.prompt===visible);assert.ok(previous);assert.ok(!preceding.some(x=>x.item===previous.id));
   const wrong=(previous.answer+1)%previous.options.length;
   preceding.push({item:previous.id,choice:wrong});
   await activate('[data-choice="'+wrong+'"]');await key('Enter');
  }
  assert.equal(await evaluate("document.querySelector('.question-card h2').textContent"),prompt);
  assert.ok(preceding.length<12);
  const choices=await evaluate("[...document.querySelectorAll('[data-choice]')].map(e=>({choice:Number(e.dataset.choice),text:e.textContent.slice(1)}))");
  for(const choice of choices)assert.equal(choice.text,item.options[choice.choice]);
  assert.equal(await evaluate('document.documentElement.scrollWidth > innerWidth'),false);
  await capture('v2-corrected-question.png','.question-card');
  await activate('[data-choice="'+item.answer+'"]');
  const feedback=await evaluate("document.querySelector('#feedback-slot').textContent");
  assert.ok(feedback.includes(item.explanation));assert.ok(feedback.includes(item.transfer));
  delta.preview=preview;delta.preceding=preceding;delta.changedQuestion={id:item.id,prompt,answer:item.answer,choices,feedback};
  delta.status='passed';
  passed('V2 actual embedded lesson download and explicit file import preserve all 12 items; the corrected remainder-range prompt, unchanged choices and correct feedback render in the native 390px learner');
 }finally{
  delta.after=await observe();assert.deepEqual(delta.after,delta.before);
 }
}
