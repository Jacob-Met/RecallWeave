# Missing arrowheads in compound SVG paths

Independent source review found one presentation defect before accepting the final diagram.

| Reviewed source | SHA-256 |
| --- | --- |
| `src/dc-circuits-ui.mjs` | `f236151d3fba828a28e64686045469744ec041872add220eddf068f64d05c4f3` |
| `templates/dc-circuits-lab.html` | `a1af554df93dae1d58f37fb1d5f2c13694eae3e5bd3905eee470a02796adcb8b` |

The UI creates each connection's orange current indicators as a single SVG path containing several separate `M` subpaths. The template assigns `marker-end: url(#current-tip)` to that path. Under the [SVG 2 marker rules, section 13.7.2](https://www.w3.org/TR/SVG2/painting.html#MarkerEndProperty), the end marker belongs to the last vertex of the entire path. It does not repeat at each subpath's end.

Consequently the series drawing's top source-current segment lacks an arrowhead, while the bottom return-current segment has one. In the parallel drawing, source-current and R1-current segments lack arrowheads; only the final R2-current segment receives one. This is a source/specification finding; actual-browser observation belongs to the separate browser receiver.

The intended directions are physically correct: source current travels right from the marked positive terminal, series return current travels left toward the negative terminal, and both parallel branch currents travel downward toward the common negative bus. The resistor placement, same-node parallel connections, unbranched series loop and polarity labels are also correct.

The bounded correction is to use a separate path or line for each intended current arrow, preserving its coordinates and existing marker style. The two series indicators and three parallel indicators then each receive an end marker. No numerical model, course answer, physical formula, input range or wire topology needs to change.

The original source copies remain `presentation-v1-ui.mjs` and `presentation-v1-template.html`. The already accepted native model/course receipt remains unchanged; final presentation acceptance will bind to the corrected UI and rebuilt standalone artifact.
