import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import { gzipSync } from "node:zlib";
import assert from "node:assert/strict";
const root = path.dirname(fileURLToPath(import.meta.url));
const sha = b => createHash("sha256").update(b).digest("hex");
const pin = p => { const b = fs.readFileSync(p); return { bytes: b.length, sha256: sha(b), gitBlob: createHash("sha1").update("blob " + b.length + "\0").update(b).digest("hex") }; };
const read = p => JSON.parse(fs.readFileSync(path.join(root, p), "utf8"));
const first = read("browser-v1/RECEIPT.json"), diagnostic = read("keyboard-diagnostic/RECEIPT.json"), rest = read("browser-v2-remaining/RECEIPT.json");
assert.equal(first.status, "failed"); assert.equal(first.groups.length, 6); assert.equal(first.checks, 47);
assert(first.errors[0].includes("keyboard applies draft"));
assert.equal(diagnostic.status, "passed"); assert.equal(diagnostic.groups.length, 2);
assert.equal(rest.status, "passed"); assert.equal(rest.groups.length, 4);
assert(first.sourceUnchanged && diagnostic.sourceUnchanged && rest.sourceUnchanged);
assert.deepEqual(first.before, rest.after);
const cleanup = read("CLEANUP-RECEIPT.json");
assert.equal(cleanup.chromeProcessCount, 0);
assert(cleanup.originalProfileAbsent && cleanup.diagnosticProfileAbsent && cleanup.remainingProfileAbsent);
const acceptance = {
 schema: "recallweave.lp-native-browser-acceptance/1",
 status: "passed by composition of retained completed groups on identical source",
 repository: "Jacob-Met/RecallWeave", sourceMain: "698902f9c9c1d5c5023092b85b3632a7cb7a01ed",
 sourceTree: "d6d3707b691850af7928299242631534cff89aa8",
 nativeSourceCheckpoint: "14b89db87f3f8bcf8907efef06fe6eb9fbd932db",
 generatedArtifact: pin(path.join(root, "candidate/courses/linear-programming-explorer.html")),
 runtime: { node: first.node, executable: first.executable, chrome: first.browser, sandboxDisabled: false },
 completedGroups: [...first.groups, ...rest.groups],
 assertions: { firstCompletedGroups: 46, firstFollowingFailedReceiverAssertion: 1, remainingIncludingPriorDownloadReadback: 17, separateKeyboardDiagnostic: 4 },
 firstRun: { receipt: "browser-v1/RECEIPT.json", ...pin(path.join(root, "browser-v1/RECEIPT.json")),
  disposition: "Overall run remains failed. Its six completed groups are retained; assertion47 omitted the Enter character event in raw CDP." },
 diagnostic: { receipt: "keyboard-diagnostic/RECEIPT.json", ...pin(path.join(root, "keyboard-diagnostic/RECEIPT.json")),
  conclusion: "rawKeyDown alone did not submit an ordinary form; native keyDown carrying carriage-return text submitted that form and the unchanged LP form. All observed keyboard events were trusted." },
 remainingRun: { receipt: "browser-v2-remaining/RECEIPT.json", ...pin(path.join(root, "browser-v2-remaining/RECEIPT.json")),
  disposition: "Only the remaining four groups ran after receiver correction, using the exact earlier actual course download for native learner import." },
 coverage: ["All seven original presets and exact complete optimal sets", "Draft invalidation, refusal and recovery", "Fractional observation plus course/guide real downloads and byte parity", "Native keyboard form and vertex selection", "390px mobile layout and print-media capture", "Actual downloaded course preview/start/answer feedback in unchanged learner", "No external page requests, runtime errors or automatic browser storage"],
 visualInspection: ["Desktop fractional view inspected", "390px complete pair-table view inspected; no document horizontal overflow", "Print-media capture inspected; no physical printer or PDF pagination claim", "Actual native learner feedback screenshot inspected"],
 limitations: ["Native receiving of isolated files; no hosted delivery, installed adoption or source merge claimed", "Both earlier Linux browser failures remain in the original ThinkPad checkpoint", "Current-parent composition and any required hosted gates remain pending under Actions hold"],
 sourceFiles: rest.after, cleanup, completed: rest.finished
};
fs.writeFileSync(path.join(root, "ACCEPTANCE.json"), JSON.stringify(acceptance, null, 2) + "\n", { flag: "wx" });
fs.writeFileSync(path.join(root, "README.md"), "# Linear-programming native browser receiving\n\nThis packet receives the exact original RecallWeave bounded continuous LP page and its unchanged learner consumer. Open candidate/courses/linear-programming-explorer.html directly to use the lab; candidate/learner/demo.html is the pinned original learner used for receiving.\n\nAll ten planned browser groups are qualified by composition on identical source: six completed groups in browser-v1, then four in browser-v2-remaining. The first run is honestly retained as failed at its following raw-CDP Enter assertion. The separate ordinary-form diagnostic proves the missing Enter character event and receives the unchanged app with the corrected native event. No source edit or repeated first-six suite occurred. Source pins, actual downloads, screenshots, logs and cleanup receipts remain available.\n\nChrome used a new owned profile for each bounded run, with its sandbox intact. All three child processes exited0; profiles were removed. Source and learner bytes remain exact. Model/lesson and independent UI/package receipts live in the linked ThinkPad source checkpoint; this packet does not repeat those tests. Source integration and hosted gates are pending under the Actions hold.\n");
const excludes = new Set(["FILES.json", "lp-la7-receiving.tar.gz", "lp-la7-receiving.tar.gz.b64", "ARCHIVE-RECEIPT.json"]);
const files = [];
function walk(dir, rel = "") {
 for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a,b) => a.name.localeCompare(b.name))) {
  const name = rel ? rel + "/" + entry.name : entry.name;
  if (!rel && excludes.has(entry.name)) continue;
  if (entry.isSymbolicLink()) throw Error("Unexpected link");
  if (entry.isDirectory()) { assert.notEqual(entry.name, "profile"); walk(path.join(dir, entry.name), name); }
  else if (entry.isFile()) files.push({ path: name, ...pin(path.join(dir, entry.name)) });
  else throw Error("Unexpected file type");
 }
}
walk(root);
fs.writeFileSync(path.join(root, "FILES.json"), JSON.stringify({ schema: "recallweave.lp-la7-files/1", files }, null, 2) + "\n");
const members = [...files.map(f => f.path), "FILES.json"].sort();
const chunks = [];
for (const name of members) {
 const bytes = fs.readFileSync(path.join(root, name)); const header = Buffer.alloc(512);
 assert(Buffer.byteLength(name) <= 100);
 header.write(name, 0, 100, "utf8"); header.write("0000644\0", 100); header.write("0000000\0", 108); header.write("0000000\0", 116);
 header.write(bytes.length.toString(8).padStart(11,"0") + "\0", 124); header.write("00000000000\0",136); header.fill(32,148,156); header.write("0",156);
 header.write("ustar\0",257); header.write("00",263);
 const sum = header.reduce((a,b) => a+b,0); header.write(sum.toString(8).padStart(6,"0")+"\0 ",148);
 chunks.push(header, bytes, Buffer.alloc((512-bytes.length%512)%512));
}
chunks.push(Buffer.alloc(1024));
const archive = gzipSync(Buffer.concat(chunks), { level: 9 });
fs.writeFileSync(path.join(root, "lp-la7-receiving.tar.gz"), archive);
fs.writeFileSync(path.join(root, "lp-la7-receiving.tar.gz.b64"), archive.toString("base64") + "\n");
const result = { schema: "recallweave.lp-la7-archive/1", regularMembers: members.length, archive: pin(path.join(root,"lp-la7-receiving.tar.gz")), manifest: pin(path.join(root,"FILES.json")), acceptance: pin(path.join(root,"ACCEPTANCE.json")), noLinks: true, noProfiles: true };
fs.writeFileSync(path.join(root, "ARCHIVE-RECEIPT.json"), JSON.stringify(result,null,2)+"\n");
console.log(JSON.stringify(result,null,2));
