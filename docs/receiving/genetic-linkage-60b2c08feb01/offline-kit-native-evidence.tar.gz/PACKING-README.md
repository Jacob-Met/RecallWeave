# Static packaging provenance

This packet contains the exact Python standard-library packer and its first native process result. It packages seven frozen product assets and adds four delivery files. It does not run any model, learner, JavaScript or browser.

The output ZIP is `genetic-linkage-offline-kit.zip`, Git blob `86cb9d2ffbf6348ae74192d54f9d598090937153`, 76,301 bytes, SHA-256 `afde4abeb509b7a2cf5836d396e864ebfb5a69b238a40bd2d54752f357b4068f`. The ZIP is supplied separately, not duplicated inside this evidence archive.

All eleven regular 0644 entries were read back and compared against their prepared bytes. Ten checksums cover every member except the checksum file itself. The gate resolves all 27 literal local HTML/Markdown links and fragments and records nine optional external scientific links. Static source inspection found no external script/style/media assets and only Blob URL assignments for dynamic download links. This is a static dependency-closure claim, not a browser execution claim.

The packer orders entries, uses fixed timestamps and builds twice in memory; those two archives were byte-identical in the recorded Python/zlib environment. It checks safe distinct names, rejects unsupported reference-style Markdown in the pinned guides, checks CRCs, validates source Git hashes before and after, and refuses to overwrite its output or receipt. Cross-version compressor byte identity is not inferred.

To replay using already available Python, extract the separately supplied kit into an owned directory, then choose fresh output paths:

```sh
python -B pack_kit.py --root /owned/extracted-kit --output /owned/repacked.zip --receipt /owned/repacking.json
```

The exact opening HTML/text are included. Their product links preserve native relative layout; developer build commands in the unchanged guides require the repository and are explicitly outside this learner kit. No extra prerequisite asset beyond the earlier Mendelian family was needed.

The original first stdout, empty stderr, process record and packaging receipt are unmodified. This packet adds no learner acceptance, installed adoption, Windows execution, Actions result or learning-effectiveness claim. Those qualification boundaries remain separate.
