$ErrorActionPreference = 'Stop'
$root = 'D:/Hamon/receiving/recall-genotype-counts-root-db371a37f4c8'
$os = Get-CimInstance Win32_OperatingSystem
$c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='D:'"
$guard = [ordered]@{schema='recall261-root-native-guard-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;machine=[Environment]::MachineName;user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;boot=$os.LastBootUpTime.ToUniversalTime().ToString('o');freeC=[long]$c.FreeSpace;freeD=[long]$d.FreeSpace;freeMemory=[long]$os.FreePhysicalMemory*1024;floorC=1073741824;floorD=1073741824;floorMemory=2147483648}
$guard | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 "$root/ORIGINAL-FREEZE-r1-GUARD.json"
if ($guard.machine -ne 'MSI' -or $guard.user -ne 'MSI\Veria' -or $guard.boot -ne '2026-10-04T04:03:32.5000000Z' -or $guard.freeC -lt $guard.floorC -or $guard.freeD -lt $guard.floorD -or $guard.freeMemory -lt $guard.floorMemory) { throw 'Identity, boot or resource guard refused' }

$all = @(Get-CimInstance Win32_Process)
$self = $all | Where-Object ProcessId -eq $PID
$ignored = @($PID,$self.ParentProcessId)
$known = @(12164,25328,14444,7476)
$present = @($all | Where-Object { $_.ProcessId -in $known } | ForEach-Object {[ordered]@{pid=[int]$_.ProcessId;name=$_.Name;creation=$_.CreationDate.ToUniversalTime().ToString('o');command=$_.CommandLine}})
$owned = @($all | Where-Object { $_.ProcessId -notin $ignored -and $_.CommandLine -and $_.CommandLine.Replace('\','/').Contains($root) } | ForEach-Object {[ordered]@{pid=[int]$_.ProcessId;name=$_.Name;creation=$_.CreationDate.ToUniversalTime().ToString('o');command=$_.CommandLine}})
[ordered]@{schema='recall261-original-delayed-closure-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;parent=$self.ParentProcessId;knownNumbers=$known;knownPresent=$present;ownedNamespace=$owned;signalsSent=@()} | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 "$root/ORIGINAL-CLOSURE.json"
& 'C:/Program Files/nodejs/node.exe' "$root/control-native.mjs" "$root/original-freeze-r1-control.json"
$code = $LASTEXITCODE
[ordered]@{schema='recall261-native-outer-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;exitCode=$code} | ConvertTo-Json | Set-Content -Encoding UTF8 "$root/ORIGINAL-FREEZE-r1-OUTER.json"
exit $code
