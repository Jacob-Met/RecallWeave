# Genetic-linkage author evidence

The new course and offline companion let a learner compare chromosome phase and exact gamete probabilities for AaBb × aabb, while preserving the original independent-assortment lesson.

This capsule records the author work for [RecallWeave #198](https://github.com/Jacob-Met/RecallWeave/issues/198) on base `698902f9c9c1d5c5023092b85b3632a7cb7a01ed`, under public contract `dc43bbd25c189252f70d6d4d3eab48f244d0a5b0`. It contains the ten new product files, one unchanged execution dependency (`src/deck.mjs`), and original raw author results. Source identities are in `evidence/source-freeze.json`.

The first model run passed eight maintained groups on Node 24.19.0. The first course/build gate then passed the deterministic builder, direct `--check`, and five maintained course/build groups. The latter includes exact embedded-course/generated-page parity, strict command-line flags, alias invocation, stale output, duplicate markers, unsupported declarations and script-closing refusal. No inherited source was edited.

The first ordinary browser run passed three groups in Chromium 153.0.8010.0: initially unapplied controls followed by coupling at 20%; actual observation/course downloads with exact bytes; and draft-edit retirement. It opened the generated file directly, observed one local file request, no page/console errors, and unchanged source hashes. The full-page screenshot was visually inspected for readable layout, labels and table values. This author gate does not substitute for the separately frozen independent repulsion/endpoints/lifetime/keyboard/learner receiver.

The original course and prompts were sealed before independent answers. All twelve keys matched that blind exercise. A subsequent manual context review found three standalone adaptive questions needed explicit class-symmetry premises. The correction consists only of three sentence prefixes; keys, options, explanations, transfers and every other field remain unchanged. The original course and prompts, revised projection, exact diff and correction receipt are retained. This was a genuine wording correction after a passing original native course check, not an arithmetic failure. Independent records remain separately attributable.

To inspect or replay in an isolated directory, preserve `source/` relative paths. With an existing Node installation:

```sh
cd source
node --test tests/genetic-linkage.test.mjs
node tools/build-genetic-linkage.mjs --check
node --test tests/genetic-linkage-course.test.mjs
```

The original commands and timestamps are recorded in the receipts. For the bounded browser check, set `PLAYWRIGHT_MODULE` to an existing Playwright module file and `CHROMIUM_EXECUTABLE` to an existing Chromium executable, then run:

```sh
node tools/check-genetic-linkage-browser.mjs --output /your/owned/browser-evidence
```

No install is performed. Choose an owned output directory with room for a temporary profile and screenshot. The author's actual paths are retained as provenance, not portable runtime requirements.

The captured course download equals the source JSON. The observation is a separate record with exact applied raw text, assumptions and reduced fractions; it is not a deck. Both physical download files remain in the raw browser directory. Source and archive member hashes support byte verification, not authenticated provenance.

These are focused native and browser results. They do not establish full-repository CI, deployed availability, Windows execution, learning effectiveness, or predictions about real organisms. No Actions, provider operations, runtime installation, automatic storage or network services were used. Root owns current-base composition and publication; separate independent packets own scientific/content and broader browser acceptance.
