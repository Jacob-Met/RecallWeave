import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const R=path.dirname(fileURLToPath(import.meta.url)), input=JSON.parse(fs.readFileSync(path.join(R,'original-admission-input.json'),'utf8'));
const out=path.join(R,'original');assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);
const hash=(b,algorithm='sha256')=>createHash(algorithm).update(b).digest('hex');
const git=b=>hash(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b]),'sha1');
const files=[];
for(const e of input.files){
 const source=path.join(input.sourceRoot,e.path),target=path.join(out,e.path),before=fs.readFileSync(source);
 assert.equal(before.length,e.bytes);assert.equal(hash(before),e.sha256);assert.equal(git(before),e.git);
 fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,before);
 assert.deepEqual(fs.readFileSync(source),before);assert.deepEqual(fs.readFileSync(target),before);
 files.push({...e,source,target,beforeAfterExact:true});
}
const schema=fs.readFileSync(input.publicSchemaPath);assert.equal(hash(schema),input.publicSchemaSha256);fs.writeFileSync(path.join(R,'PUBLIC-SCHEMA.md'),schema);
const receipt={at:new Date().toISOString(),canonical:input.canonical,files,sourceBytes:files.reduce((n,e)=>n+e.bytes,0),node:{version:process.version,executable:process.execPath,sha256:hash(fs.readFileSync(process.execPath))},contractSha256:hash(fs.readFileSync(path.join(R,'CONTRACT.md'))),schemaSha256:hash(schema),candidateRead:false};
fs.writeFileSync(path.join(R,'original-admission-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({files:files.length,bytes:receipt.sourceBytes,node:receipt.node,allExact:true}));
