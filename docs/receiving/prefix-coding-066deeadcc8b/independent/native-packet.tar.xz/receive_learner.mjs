#!/usr/bin/env node
// Independent receiving of an actual local deck in the unchanged learner.
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';

const [sourceDir,coursePath,outDir,playwrightEntry,mode='candidate']=process.argv.slice(2);
if(!sourceDir||!coursePath||!outDir||!playwrightEntry)throw new Error('Usage: receive_learner.mjs LEARNER_ROOT COURSE_JSON OUT PLAYWRIGHT_ENTRY [baseline|candidate]');
const root=path.resolve(outDir);await fs.mkdir(root,{recursive:false});
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const json=(name,value)=>fs.writeFile(path.join(root,name),JSON.stringify(value,null,2)+'\n');
async function collect(dir,prefix=''){
 const files={};for(const item of await fs.readdir(dir,{withFileTypes:true})){
  const name=prefix+item.name,full=path.join(dir,item.name);
  if(item.isDirectory())Object.assign(files,await collect(full,name+'/'));
  else if(item.isFile())files[name]=await fs.readFile(full);
  else throw new Error('Unexpected nonregular learner source '+name);
 }return files;
}
const source=await collect(path.resolve(sourceDir));
const sourceMap=Object.fromEntries(Object.entries(source).map(([name,b])=>[name,{bytes:b.length,sha256:hash(b)}]));
const courseBytes=await fs.readFile(coursePath),course=JSON.parse(courseBytes);
const report={schema:'recall-prefix-independent-learner-browser-v1',argv:process.argv,node:process.version,
 sourceRoot:path.resolve(sourceDir),sourceBefore:sourceMap,coursePath:path.resolve(coursePath),courseSha256:hash(courseBytes),
 courseRole:mode==='baseline'?'existing binary-search control':'new authored prefix-coding course',
 checks:[],answers:[],served:[],requests:[],blockedRequests:[],pageErrors:[],downloads:[],capabilityControls:[]};
const check=(name,ok,detail=null)=>report.checks.push({name,ok:Boolean(ok),detail});
let browser,server,context;
const mime={'.html':'text/html;charset=utf-8','.mjs':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.json':'application/json;charset=utf-8','.md':'text/plain;charset=utf-8'};
async function download(page,label){
 const pending=page.waitForEvent('download');await page.locator('#save-notes-button').click();const dl=await pending;
 const destination=path.join(root,label+'.txt');await dl.saveAs(destination);const data=await fs.readFile(destination);
 const row={name:label,path:destination,bytes:data.length,sha256:hash(data),suggestedFilename:dl.suggestedFilename()};report.downloads.push(row);
 check(label+':text-download',row.suggestedFilename.endsWith('.txt')&&data.length>100);
 return data.toString('utf8');
}
try{
 const {chromium}=await import(pathToFileURL(playwrightEntry));
 server=http.createServer((req,res)=>{
  let name;try{name=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname).slice(1)||'index.html';}catch{res.writeHead(400).end('Bad path');return;}
  const data=source[name];if(req.method!=='GET'||!data){report.served.push({method:req.method,path:name,status:404});res.writeHead(404,{'Content-Type':'text/plain'}).end('Not found');return;}
  report.served.push({method:'GET',path:name,status:200,bytes:data.length,sha256:hash(data)});
  res.writeHead(200,{'Content-Type':mime[path.extname(name)]||'application/octet-stream','Cache-Control':'no-store'});res.end(data);
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;report.origin=origin;
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  args:['--no-first-run','--disable-background-networking','--disable-component-update','--disable-sync']});report.browser=await browser.version();
 context=await browser.newContext({viewport:{width:375,height:900},acceptDownloads:true});
 await context.route('**/*',route=>{const url=route.request().url();if(url.startsWith(origin+'/'))return route.continue();report.blockedRequests.push(url);return route.abort();});
 const page=await context.newPage();page.on('pageerror',e=>report.pageErrors.push(e.message));page.on('request',r=>report.requests.push({method:r.method(),url:r.url()}));
 await page.goto(origin+'/index.html',{waitUntil:'load'});await page.locator('#start-button').waitFor();
 await page.locator('#deck-file').setInputFiles(path.resolve(coursePath));await page.locator('#start-deck').waitFor({state:'visible'});
 check('twelve-question-course',course.items.length===12);
 check('actual-file-preview-title',await page.locator('#deck-preview-title').textContent()===course.title);
 check('preview-count',await page.locator('#deck-preview li').count()===course.items.length);
 const preview=await page.locator('#deck-preview').textContent();check('preview-attribution-and-license',preview.includes(course.attribution)&&preview.includes(course.license));
 await page.locator('#deck-preview summary').focus();await page.keyboard.press('Enter');
 check('preview-keyboard-disclosure',await page.locator('#deck-preview details').getAttribute('open')!==null);
 await page.screenshot({path:path.join(root,'preview-375.png'),fullPage:true});
 await page.locator('#start-deck').focus();await page.keyboard.press('Enter');
 const asked=new Set();
 for(let index=0;index<course.items.length;index++){
  const heading=page.locator('#session-content .question-card h2');await heading.waitFor({state:'visible'});
  const prompt=await heading.textContent(),item=course.items.find(x=>x.prompt===prompt);assert(item,'actual question is in supplied deck');assert(!asked.has(item.id),'question repeated');asked.add(item.id);
  const choices=page.locator('#session-content [data-choice]');check('question-'+index+':all-options-visible',await choices.count()===item.options.length);
  for(let i=0;i<item.options.length;i++)check('question-'+index+':literal-option-'+i,(await page.locator('[data-choice="'+i+'"]').textContent()).includes(item.options[i]));
  const choice=index<3?(item.answer+1)%item.options.length:item.answer;
  await page.locator('[data-choice="'+choice+'"]').focus();await page.keyboard.press('Enter');
  await page.locator('#next-button').waitFor({state:'visible'});const feedback=await page.locator('#feedback-slot').textContent();
  check('question-'+index+':complete-feedback',feedback.includes(item.explanation)&&feedback.includes(item.transfer));
  check('question-'+index+':answered-progress',await page.locator('[role="progressbar"]').getAttribute('aria-valuenow')===String(index+1));
  report.answers.push({index,id:item.id,prompt,choice,answer:item.answer,correct:choice===item.answer,feedback});
  if(index===0)await page.screenshot({path:path.join(root,'first-feedback-375.png'),fullPage:true});
  await page.locator('#next-button').focus();await page.keyboard.press('Enter');
 }
 await page.locator('#first-try-summary').waitFor({state:'visible'});
 const summary=await page.locator('#first-try-summary').textContent(),mastery=await page.locator('.mastery-box output').allTextContents();
 check('complete-unique-questions',asked.size===12);check('first-attempt-result',summary.includes('9 of 12'));
 check('complete-review',await page.locator('.review-item').count()===12);
 const notes=[];
 for(let i=0;i<3;i++){
  const detail=page.locator('.review-item').nth(i);await detail.locator('summary').focus();await page.keyboard.press('Enter');
  const field=detail.locator('[data-reflection-item]'),id=await field.getAttribute('data-reflection-item');
  const value='Receiver reflection '+i+': <b id=prefix-note>literal</b> & Ω\nA separate explanation of a connection.';
  await field.fill(value);notes.push({id,value});
 }
 const application='Receiver application: prefix-free payload accounting is separate from framing.\nKeep my literal <tag> & Ω note.';
 await page.locator('#application-reflection').fill(application);
 check('reflection-markup-is-literal',await page.locator('#prefix-note').count()===0);
 const before=await download(page,'study-notes-before-practice');
 for(const item of course.items)check('notes:complete-course-item:'+item.id,before.includes(item.prompt)&&before.includes(item.options[item.answer])&&before.includes(item.explanation)&&before.includes(item.transfer));
 for(const note of notes)check('notes:literal-reflection:'+note.id,note.value.split('\n').every(line=>before.includes(line)));
 check('notes:literal-application',application.split('\n').every(line=>before.includes(line)));
 check('notes:attribution-and-license',before.includes(course.attribution)&&before.includes(course.license));
 await page.locator('#practice-button').focus();await page.keyboard.press('Enter');
 const missed=report.answers.filter(x=>!x.correct);
 for(let i=0;i<missed.length;i++){
  const prompt=await page.locator('.practice-card h2').textContent(),item=course.items.find(x=>x.prompt===prompt);
  check('practice-order-'+i,item?.id===missed[i].id);assert(item);
  await page.locator('[data-practice-choice="'+item.answer+'"]').focus();await page.keyboard.press('Enter');
  await page.locator('#practice-next').waitFor({state:'visible'});await page.locator('#practice-next').focus();await page.keyboard.press('Enter');
 }
 await page.locator('#first-try-summary').waitFor({state:'visible'});
 check('practice-preserves-first-summary',await page.locator('#first-try-summary').textContent()===summary);
 check('practice-preserves-estimates',JSON.stringify(await page.locator('.mastery-box output').allTextContents())===JSON.stringify(mastery));
 check('practice-recorded-separately',(await page.locator('#practice-status').textContent()).includes('3 of 3'));
 const after=await download(page,'study-notes-after-practice');
 check('after-notes-first-answer-identity',after.includes('9 of 12 connections correct on the first try.'));
 check('after-notes-practice-separate',after.includes('3 of 3 practice answers recorded; 3 correct on retry.'));
 for(const note of notes)check('after-notes-reflection:'+note.id,note.value.split('\n').every(line=>after.includes(line)));
 const observation=await page.evaluate(()=>({title:document.title,text:document.body.innerText,viewport:innerWidth,
  documentWidth:document.documentElement.scrollWidth,localStorageKeys:Object.keys(localStorage),sessionStorageKeys:Object.keys(sessionStorage)}));
 report.finalObservation=observation;await json('final-observation.json',observation);await fs.writeFile(path.join(root,'final-dom.html'),await page.content());
 check('375px-document-layout',observation.documentWidth<=376);check('fresh-private-storage',!observation.localStorageKeys.length&&!observation.sessionStorageKeys.length);
 await page.screenshot({path:path.join(root,'complete-375.png'),fullPage:true});await page.screenshot({path:path.join(root,'viewport-375.png'),fullPage:false});
 if(mode==='baseline'){
  const absent=['src/prefix-coding.mjs','courses/prefix-coding.json','courses/prefix-coding.md','courses/prefix-coding-explorer.html'];
  const control=await context.newPage();
  for(const name of absent){const response=await control.goto(origin+'/'+name,{waitUntil:'load'});const status=response.status(),text=await control.locator('body').innerText();report.capabilityControls.push({path:name,status,text});check('baseline-prefix-capability-absent:'+name,status===404&&text==='Not found');}
  await control.close();
 }
 check('no-application-errors',report.pageErrors.length===0,report.pageErrors);check('no-external-requests',report.blockedRequests.length===0,report.blockedRequests);
}catch(e){report.harnessError=e.stack||String(e);check('learner-receiving-complete',false,report.harnessError);}
finally{
 if(context)await context.close();if(browser)await browser.close();if(server)await new Promise(resolve=>server.close(resolve));
 const after=await collect(path.resolve(sourceDir));report.sourceAfter=Object.fromEntries(Object.entries(after).map(([name,b])=>[name,{bytes:b.length,sha256:hash(b)}]));
 check('unchanged-learner-source',JSON.stringify(report.sourceBefore)===JSON.stringify(report.sourceAfter));
 report.courseAfterSha256=hash(await fs.readFile(coursePath));check('unchanged-course-bytes',report.courseAfterSha256===report.courseSha256);
 report.passedChecks=report.checks.filter(x=>x.ok).length;report.failedChecks=report.checks.filter(x=>!x.ok).length;
 await json('report.json',report);console.log(JSON.stringify({mode,questions:report.answers.length,downloads:report.downloads.length,passedChecks:report.passedChecks,failedChecks:report.failedChecks,harnessError:report.harnessError,report:path.join(root,'report.json')}));
 process.exitCode=report.failedChecks?1:0;
}
