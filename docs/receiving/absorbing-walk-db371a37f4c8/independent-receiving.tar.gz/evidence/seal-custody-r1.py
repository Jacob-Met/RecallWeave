import pathlib,json,hashlib,datetime,os,re,tarfile,gzip,io,shutil,stat,base64
R=pathlib.Path(__file__).parent;S=R/'seal-r1';assert not S.exists();S.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest=json.loads((R/'candidate-runtime-manifest-r1.json').read_text())['files']
for e in manifest:
 b=(R/'source'/e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
assert sha((R/'absorbing-walk-portable.zip').read_bytes())=='a928a859470c668f8e313d839f11d0f31e781aaa4367a03441d6bcb70eb70426'
assert sha((R/'ROOT-VISUAL-REVIEW.json').read_bytes())=='3debead032e66da39c0955b5f4320c43e7f7f80d712563910f7231bbcc3b2122'
assert json.loads((R/'browser-r5/receipt.json').read_text())['pass']
assert json.loads((R/'browser-wrapper-r5/receipt.json').read_text())['exit']==0
known=set()
for p in list(R.glob('browser-wrapper-*/browser.log'))+list(R.glob('focus-wrapper-*/browser.log')):
 known.update(map(int,re.findall(r'pid=(\d+)',p.read_text())))
for p in list(R.glob('browser-wrapper-*/receipt.json'))+list(R.glob('focus-wrapper-*/receipt.json')):
 v=json.loads(p.read_text());known.update([v['wrapper'],v['node']]);assert not v.get('remaining') and not v.get('delayedRemaining');assert v['profileRemoved'] and v['cacheRemoved'];assert not (p.parent/'tmp').exists()
alive=[i for i in sorted(known) if pathlib.Path('/proc',str(i)).exists()]
assert not alive
dep=pathlib.Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8/source/node_modules')
d=[]
for p in [dep/'playwright/index.mjs',dep/'playwright/package.json',dep/'playwright-core/package.json',dep/'playwright-core/lib/coreBundle.js',pathlib.Path('/usr/bin/node')]:
 b=p.read_bytes();d.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
assert json.loads((dep/'playwright/package.json').read_text())['version']=='1.62.1'
assert d[3]['sha256']=='9393fa79e1c67c74edc26b610d65a4f7ed73d345a762465cc88340a33a2454ac'
(R/'dependency-final-binding.json').write_text(json.dumps({'at':now(),'timing':'Post-run reconciliation against previously qualified locked donor; prelaunch entry hash is separately in package admission. No invented full dependency before snapshot.','files':d},indent=2)+'\n')
excluded=['seal-r1/**','msi-custody.base64','msi-custody.json.gz']
files=[]
for p in sorted(R.rglob('*')):
 rel=p.relative_to(R).as_posix()
 if rel.startswith('seal-r1/') or rel in excluded:continue
 if p.is_dir():continue
 assert p.is_file() and not p.is_symlink(),rel
 b=p.read_bytes();files.append({'path':rel,'bytes':len(b),'sha256':sha(b),'mode':oct(p.stat().st_mode&0o777)})
m={'schema':'recall-independent-custody/1','created':now(),'root':str(R),'files':files,'fileCount':len(files),'totalBytes':sum(e['bytes'] for e in files),'excludedRedundantOrSelfContainers':excluded}
mb=(json.dumps(m,indent=2)+'\n').encode();(S/'independent-manifest.json').write_bytes(mb)
with (S/'independent-receiving.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,b in [('MANIFEST.json',mb)]+[('evidence/'+e['path'],(R/e['path']).read_bytes()) for e in files]:
    i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;i.uid=i.gid=i.mtime=0;t.addfile(i,io.BytesIO(b))
with tarfile.open(S/'independent-receiving.tar.gz','r:gz') as t:
 members=t.getmembers();assert len(members)==len(files)+1;assert all(x.isfile() and not x.name.startswith('/') and '..' not in pathlib.PurePosixPath(x.name).parts for x in members);assert t.extractfile('MANIFEST.json').read()==mb
 for e in files:assert sha(t.extractfile('evidence/'+e['path']).read())==e['sha256']
assert all(sha((R/e['path']).read_bytes())==e['sha256'] for e in files)
shutil.copyfile(R/'INDEPENDENT.md',S/'INDEPENDENT.md')
def pin(p):b=p.read_bytes();return {'path':p.name,'bytes':len(b),'sha256':sha(b),'gitBlob':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()}
seal={'schema':'recall-independent-seal/1','at':now(),'files':len(files),'archiveMembers':len(files)+1,'sourceFiles':29,'artifacts':[pin(S/p) for p in ['independent-receiving.tar.gz','INDEPENDENT.md','independent-manifest.json']],'allPayloadBeforeAfterExact':True,'archiveReadbackExact':True}
(S/'independent-seal.json').write_text(json.dumps(seal,indent=2)+'\n')
audit={'schema':'recall-independent-final-audit/1','at':now(),'archiveMembers':len(files)+1,'payloadFiles':len(files),'payloadBytes':m['totalBytes'],'allPayloadBeforeAfterExact':True,'allArchiveMembersVerified':True,'runtimeSourceFilesExact':29,'portablePackageExact':True,'rootVisualReviewExact':True,'knownBrowserAndWrapperPids':sorted(known),'alive':alive,'ownedProfilesRemoved':True,'qualifiedScope':'Frozen mathematics and ordinary no-reflection consumer; R1-R4 extra stress-probe failures remain unqualified with original reproduction.','artifacts':[pin(S/p) for p in ['independent-receiving.tar.gz','INDEPENDENT.md','independent-manifest.json','independent-seal.json']]}
(S/'independent-final-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
objects=[pin(S/p) for p in ['independent-receiving.tar.gz','INDEPENDENT.md','independent-manifest.json','independent-seal.json','independent-final-audit.json']]
(S/'objects.json').write_text(json.dumps(objects,indent=2)+'\n');(S/'archive.base64').write_text(base64.b64encode((S/'independent-receiving.tar.gz').read_bytes()).decode()+'\n')
print(json.dumps({'files':len(files),'objects':objects}))
