# Independent exact bounded LP receiving expectations

Reviewer:autonomous-e3a41d2b3368/local_recovery.
Status:frozen before reading candidate implementation or author tests.
Claim:https://github.com/Jacob-Met/RecallWeave/issues/174.
Original main:698902f9c9c1d5c5023092b85b3632a7cb7a01ed.
Contract SHA256:b40d6fc6531ad178e01d3dc7fb7b38845ca23e21c763514b1c3399f07debc435.

## Hand-derived mathematical cases

HAND-CASES.json is authoritative and contains14 independently derived inputs, complete exact feasible vertex sets, region kinds, optimum values, complete optimal-set representations and explanations. It covers fractional unique max/min, a tied edge, a zero objective on a polygon, feasible lines with varying and constant objectives, a constraint-defined point, degenerate box line/point, infeasibility, zero-normal tautologies/contradiction, duplicate/redundant/parallel rows, and all8 admitted rows with range endpoints.

All numbers are integers or normalized rational strings with positive denominators. Expected vertex coordinates are manually supplied. A separate Python Fraction calculation will cross-check those claims before inspecting the candidate; any discrepancy is an oracle correction preserved before candidate receiving, not a product finding.

A segment optimum means every convex combination of its endpoints is optimal. A whole-region optimum means every feasible point is optimal; listing its vertices is its finite representation, not the complete set of individual optimal points. In a feasible line a nonzero objective can be constant; wholeRegion must then be true. A singleton has kind point and wholeRegion true, even for a nonzero objective.

## Exact geometry and provenance checks

Every unordered pair of the4 box boundaries and0..8 authored rows must be represented once, up to66 total pairs. Zero-normal, parallel-distinct and coincident pairs must remain distinguishable. Independent pairs produce exact rational intersections; every feasibility test uses all admitted inequalities, including zero-normal contradictions.

Duplicate coordinates must not erase originating pairs or authored constraint identities. At every feasible vertex, objective values and slacks must equal exact substitution; active boundaries are exactly zero slack, including a tautology0<=0. The row0<=7 is inactive with slack7. A negative zero is numerical zero.

The vertex list is ordered by exact x, then exact y and receives V1... IDs. Polygon boundary order must represent the counterclockwise convex boundary; its starting rotation is cosmetic. For segments and points no spurious area, extra vertex or missing endpoint is allowed. Row permutation and positive integer rescaling preserve geometric/optimal sets when remaining inside declared input bounds; source row identities change only according to the admitted reordered input.

Outputs and admitted problem copies must be deeply frozen and detached from caller input. No BigInt may escape a JSON observation. Mutation attempts must not alter another result. Rendering conversion to Number does not qualify Number-based feasibility, equality or optimality.

## Declared admission boundaries

The exact-known-key API accepts plain objects/arrays and numeric integers only. Bounds are within[-20,20], minima<=maxima;0..8 constraints and integer row/objective coefficients within[-100,100]; sense is min or max. Reject missing/extra fields, wrong container/types, non-integers, nonfinite values, inverted/out-of-range bounds and9 rows.

The author's pre-implementation text contract trims whitespace then uses /^[+-]?\d+$/ with at most32 trimmed characters per token. +1,01 and-0 are admitted; zero normalizes numerically. Decimals, exponents, expressions and hexadecimal text are refused. Constraint text admits at most4096 UTF-16 characters, splits LF/CRLF/CR, ignores blank lines, requires exactly3 comma-separated integer fields on every nonblank row and permits at most8 rows. Exact limits are inclusive. Tests will use this explicit contract, not infer acceptance from implementation.

## Native authored lesson receiving

The unchanged original src/deck.mjs at Gitblobf0f8a4b234489c2388f427633f548d56c6ed4c03/SHA621438c166ec4bfafd9d87c698a1d46cb1722f4fb92dcbb8d9f52fce682c338b defines recallweave-deck/1, a256KiB UTF-8 parse limit, original content fields, unique concepts/question IDs/options, zero-based answer indices and acyclic concept prerequisites.

When the new14–16-question lesson is frozen, independently solve its prompts/options with answer keys and explanations initially hidden; then compare the authored key and assess explanations separately. Run the unchanged exact native validator once. Do not substitute candidate model output for lesson correctness, copy reference exercises, change the learner or repeat existing learner-session tests owned by another lane.

## Scope and mathematical basis

The rectangle is part of the admitted problem, not a plot viewport. This review makes no claim about unbounded LPs, integer optimization, simplex, dual certificates or real resource-allocation advice. No hosted workflow or GitHub source write is authorized.

Primary reference read:David Karger, MIT6.854 Notes11, sections1.3–1.5:
https://courses.csail.mit.edu/6.854/21/Notes/n11-lp.html
The notes explain convex halfspace intersections, independent active boundaries, and the existence of a vertex optimum for a nonempty bounded feasible LP. The hand-derived problems and receiving expectations here are original; no reference exercise, diagram or passage is copied.
