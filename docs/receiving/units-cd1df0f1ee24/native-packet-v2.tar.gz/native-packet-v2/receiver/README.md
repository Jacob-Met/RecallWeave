# Independent receiving contract: units and dimensions

This is a receiving contract for the new additive RecallWeave course and offline explorer. It is frozen before the receiver has inspected the new converter, its UI, or the authored course answer key. Root owns the converter; estate_source owns the twelve original questions and worked guide. This contract does not claim that the candidate exists or has passed.

## Source and custody

The inspected learner and integrated lab are exact source from `003ce06c72fb3c7924a4414cd34053d87ae46d2f`, tree `7ae4800657652f213a22a459e6e0fff35591909c`. At the fresh `5c6e5b4ee4b928b01466ffe1ff67ceeca44fb9cc` read, all 400 prior leaves remain exact and only six binary-search receiving files were added. See [intake pins](../intake-manifest-003ce.json) and [current composition](../current-source-composition.json).

The current consumer is `src/deck.mjs`, `src/deck-picker.mjs`, `src/app.mjs`, `src/review.mjs`, and `src/session-export.mjs`, reached through modular `index.html` or existing direct-open `demo.html`. The source intake contains the first three modules and the page. The latter consumer dependencies will be frozen at the receiving input, without edits.

The existing pattern is `courses/measurement-uncertainty-lab.template.html`, `src/measurement-uncertainty.mjs`, `src/measurement-uncertainty-ui.mjs`, and `tools/build-measurement-lab.mjs`. That model treats the entered unit as a label and explicitly does not convert it. Its uncertainty owner retains its course, model and evidence.

The new lane changes no existing app, importer, knowledge model, course catalog, or other course. Ownership absence is bounded by the inspected current project issues, all 332 HAMON140 comments, full source tree, and 256 readable native advisory records. Six advisory records were unreadable, including one generic worker record; no escalation or claim of universal absence is made.

## A. Arithmetic and dimensional acceptance

[units-oracles.json](units-oracles.json) supplies 24 original conversions, eight incompatible pairs, eight input refusals, and four display/state checks. Each conversion has separately written exact expected numerator/denominator pairs and an integer dimension vector in length, mass, time order. The accompanying Python verifier uses explicit factor tuples and Fraction arithmetic; it does not parse unit expressions or import the implementation.

The explorer must distinguish dimension from scale: centimetres and metres have the same length dimension but different factors; centimetres/metres has dimension one and scale 1/100. Powers apply to the entire unit, including its prefix. Quotients subtract powers and divide factors. A zero input still cannot convert length to time.

Exact scale ratios and exact decimal-input products must remain inspectable as exact values. Repeating decimal displays must be marked approximate or rounded. A formatted zero cannot replace a small nonzero result. Rounded decimal display is not used as the numerical oracle. This is exact arithmetic on declared teaching inputs, not a claim of measurement precision.

Unknown or unsupported unit syntax must be refused. The bounded explorer need not model offsets such as Celsius, arbitrary semantic quantity kinds, or every SI unit. An equal dimension vector alone does not prove a physical law or distinguish all same-dimension quantities; the course and UI must not imply otherwise.

## B. Original course review

The questions-only packet will be frozen independently by the author and solved before answers or explanations are disclosed. Record a selected canonical option, working, and any ambiguity for each item. Afterwards compare every key and explanation against those solutions. Check that each prompt has one defensible answer under its stated assumptions, its distractors reflect plausible errors, and its transfer request actually asks the learner to use the idea.

Admit the exact course through the unchanged `parseDeck` contract, including attribution/license, full concept coverage, acyclic prerequisites, unique IDs, and the existing 256 KiB cap. Serialization must not alter the accepted content. Authoring balance or passing shape tests does not substitute for solving the questions.

## C. Actual offline learner use

Use a fresh native Chromium profile and an exact pinned receiving source. Open the explorer as a local file with network requests denied. Calculate a scaled area or cube, a compound rate, an incompatible pair, and a repeating-ratio case; inspect actual visible results and errors. Editing must retire or clearly stale an earlier result. Check desktop and phone layout through actual screenshots.

Click the explorer's normal deck-download control and preserve the actual downloaded bytes, filename, and SHA256. They must match the authored JSON exactly. Then open the existing direct-open `demo.html`, choose that downloaded file with the native file chooser, inspect the title, prompts, concept counts, attribution and license in preview, and click **Start this deck**.

Answer all twelve items through the existing rendered controls. Select at least two known wrong canonical answers to exercise review and practice. Locate items by prompt/ID and options by canonical choice value; do not assume shuffled display position. Verify explanations and transfers, correct and selected answer associations, first-try counts, and all item IDs exactly once.

Save actual study notes before practice. Enter missed-connection practice, complete the two retries, return to the trace, and save notes again. First answers and first-session model state must remain unchanged; practice is separately identified. Imported course title, attribution, license, explanations and transfers must appear in the actual downloaded notes. Preserve raw downloads and screenshots.

One bounded modular importer positive may follow to bind the unchanged current consumer, without rerunning other owners' importer race/trace suites. Cancellation or invalid import must preserve the current lesson; use only a focused control necessary for this receiving flow.

## D. Provenance and limits

Freeze source leaves, test inputs, driver, numerical oracles and source version before execution. Preserve real process results, all failed attempts and harness corrections. Claim baseline absence separately from candidate acceptance. A later parent with identical runtime can receive a bounded composition positive rather than a full duplicate suite.

The exact-ratio oracles draw only on the primary BIPM and NIST references linked inside the JSON. Their calculations and examples are original. No runtime provider, learner-data upload, efficacy claim, changed learning model, deployment, or existing owner's work is included.
