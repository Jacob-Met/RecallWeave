# RecallWeave polynomial interpolation — local native receiving

Scope: [issue172](https://github.com/Jacob-Met/RecallWeave/issues/172),
estate-e82707f2bc62/source_discovery. Immutable original source is
`698902f9c9c1d5c5023092b85b3632a7cb7a01ed`.

## Product

The new dependency-free Node core computes a complete exact rational
divided-difference triangle, Newton and monomial coefficients, original-node
reproduction and selected evaluations. Its terminal command admits a bounded
UTF-8 JSON file or stdin and supports complete JSON or text output. An original
18-question course and worked guide use the unchanged native lesson contract.

Five new author paths are source payloads: the core, command, JSON course,
Markdown guide and focused test. The independent native test and fixture are
also supplied unchanged. `README-section.txt` is an unapplied additive section,
not a claimed composition of the current complete README. The payload changes
no existing learner, catalog, model, review, browser, dependency or workflow.

## Preserved original evidence

The first tmpfs hydration stopped with ENOSPC before any native execution. Its
4,096-byte incomplete deck file is unaccepted; the setup receipt records its
actual hash. It is retained separately from the later complete source hydration.
No candidate existed when the successful original witness ran.

`original-native.mjs` then executed the immutable existing sixteen-question
least-squares course through the real validator, adaptive selector, full first
answers, review and a missed-item retry in Node24.19.0. It also recorded the
actual missing interpolation import and missing native command. This establishes
an absent additive capability, not an erroneous result from an original solver.
Original stdout SHA256 is
`615526142377472d1da0729d5b6a30bc367782301c4d40c2e1b88b059172e931`;
stderr is empty. The standalone witness returned0 because it asserted those
expected boundaries; its missing-command child actually returned1.

## Qualified local results

Author native receiving: **13/13 methods pass**, no failures/skips. It covers
exact nonuniform/fractional and degree-seven reconstruction, permutation and
degree behavior, immutable/fresh input evidence, typed/sparse/accessor/limit
refusals, actual file/stdin/literal-dash processes, text, valid64KiB input,
oversize/UTF-8/JSON/argument/read failures, and all18 new course questions through
the unchanged native adaptive/review/practice flow. All13 CLI child processes
are assertions in the preserved test. Source hashes in `source-freeze-v1.json`
were captured after that author run; they are not represented as a before/after
manifest from it.

Independent receiving froze its protocol, rational fixture and exact portable
test before reading the candidate. The original passed its one native lesson
control and failed five missing-feature prerequisites. The unchanged test then
passed **6/6** on core`1e84c2d5` and CLI`a38ebfee`, with source/test/fixture bytes
unchanged before and after. It includes a separately computed complete cubic
triangle, effective-degree and permutation controls, exact type/duplicate and
pre-reduction refusals, genuine file/stdin/`./-`, boundary-size and malformed
input receiving, and an actual `/dev/full` output-I/O refusal. Its five-file
delivery remains byte-identical; the nested archive preserves every original
baseline/candidate member. Original missing prerequisites are not recast as
executed baseline CLI assertions.

Root independently solved all18 question-only prompts before opening the key.
The key matches all18 answers and meanings. Its cyclic canonical answer indices
do not impose a cyclic visible answer pattern: pinned existing
`src/answer-order.mjs` performs per-item Fisher–Yates ordering, and the unchanged
app renders stored permutations in both first-pass and practice views. This is
source evidence, not a new DOM/browser run. The complete blind proof and the
original question-only file are retained.

## Limits and held work

The core and CLI implement exact bounded mathematical interpolation. They do
not establish unknown-function accuracy, measurement quality, model fit outside
nodes, physical behavior or learner effectiveness. Inputs/results may be
mathematically synthetic; no participant data or inference engine was used.

No new browser interface is included or qualified. The existing lesson's native
parser/selector/review execution does not establish visual or file-picker
acceptance. There is no claimed hosted run, full-current-repository suite,
merge, deployment or catalog registration.

Jacob's no-GitHub-Actions direction is retained. All five workflow files at the
original/current claim cut were read; they subscribe to main pushes and pull
requests, not issues or issue comments. The ordinary issue172 claim was the
only external mutation in this lane. No Git objects/refs/PR, workflow suppression,
dispatch, rerun or merge was performed. Any later custody or integration action
requires fresh source/ownership/trigger receiving and the standing hold remains.

## Reproduce within the selected native slice

The held archive includes the exact four original source/control files under
`baseline/`, the new source and tests under `candidate/`, and original evidence
under `author/`. It is a selected source/evidence packet, not a complete Git
checkout or a substitute source base.

```sh
node original-native.mjs
node --test candidate/tests/polynomial-interpolation.test.mjs
node --test candidate/tests/polynomial-interpolation-receiving.test.mjs
node candidate/tools/interpolate-polynomial.mjs --help
```

Use the complete original Git source and unchanged maintained gates for any
future repository integration. Existing exact native receipts need not be
rerun merely to reproduce this archive.
