import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

const args = process.argv.slice(2);
assert.equal(args.length % 2, 0);
const options = Object.fromEntries(args.reduce((all, value, index) => index % 2 ? all : [...all, [value.replace(/^--/, ''), args[index + 1]]], []));
const root = resolve(options.root), output = resolve(options.output);
await mkdir(output, { recursive: true });
const temporary = resolve(options.temporary || output + '/owned-browser-temporary');
await mkdir(temporary, { recursive: true });
process.env.TMPDIR = temporary;
const { chromium } = createRequire(import.meta.url)(options.playwright);
const source = JSON.parse(await readFile(options.manifest, 'utf8'));
assert.deepEqual(source.missing ?? [], []);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
for (const row of source.files) assert.equal(hash(await readFile(resolve(root, row.path))), row.sha256, row.path);
const bytes = await readFile(options.input);
assert.equal(bytes.length, 3285);
assert.equal(hash(bytes), '544dced1fc8c909dd2a8353fe28bb7235effb5e871a38eebcdf377b3cd505475');
const deck = JSON.parse(bytes.toString('utf8'));
assert.deepEqual(deck.items.map(item => item.id), ['apply-a', 'measure', 'apply-b', 'foundation', 'compare']);
const report = {
  source_commit: source.commit, source_tree: source.tree, source_files: source.files,
  input: { path: resolve(options.input), bytes: bytes.length, sha256: hash(bytes) },
  receiver_sha256: hash(await readFile(new URL(import.meta.url))), node: process.version,
  scope: 'Actual previously exported focused lesson through current imported-course, unfinished-lesson and reflection controls; no codec/model oracle or prior broad UI suite replay.',
  cases: [], downloads: [], screenshots: [], page_errors: [], external_requests: []
};
const noteFor = id => 'Resume keeps my ' + id + ' connection: <literal> café "evidence"\nSecond line for ' + id + '.';
const application = 'My focused-lesson notebook survives resume: <em>literal</em>\nKeep the retained ideas connected.';
const genericPrompt = 'Choose one connection from this deck and explain how it relates to another idea in your own words.';
const file = { name: 'actual-focused-lesson.json', mimeType: 'application/json', buffer: bytes };
const server = createServer(async (request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
  if (pathname === '/favicon.ico') { response.writeHead(204); response.end(); return; }
  const path = resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
  if (!path.startsWith(root + sep)) { response.writeHead(403); response.end(); return; }
  try {
    const data = await readFile(path);
    response.writeHead(200, { 'Content-Type': (({ '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json' })[extname(path)] || 'application/octet-stream') + '; charset=utf-8' });
    response.end(data);
  } catch { response.writeHead(404); response.end(); }
});
await new Promise(done => server.listen(0, '127.0.0.1', done));
const origin = 'http://127.0.0.1:' + server.address().port;
let browser;
async function button(page, selector) { const control = page.locator(selector); await control.focus(); await control.press('Enter'); }
async function previewDeck(page) {
  await page.locator('#deck-file').setInputFiles(file);
  await page.locator('#start-deck').waitFor({ state: 'visible' });
  assert.equal(await page.locator('#deck-preview-title').textContent(), deck.title);
}
async function previewLesson(page, data) {
  await page.locator('#lesson-file').setInputFiles({ name: 'actual-saved-focused-lesson.json', mimeType: 'application/json', buffer: data });
  await page.locator('#lesson-preview').waitFor({ state: 'visible' });
  assert.ok((await page.locator('#lesson-preview-summary').textContent()).includes(deck.title));
  assert.match(await page.locator('#lesson-preview-summary').textContent(), /2 of 5 questions answered; 3 remaining/);
  assert.match(await page.locator('#lesson-preview').textContent(), /reflections already in this tab stay as they are/);
}
async function download(page, selector, filename) {
  const event = page.waitForEvent('download');
  await button(page, selector);
  const actual = await event;
  assert.equal(await actual.failure(), null);
  const chunks = [];
  for await (const chunk of await actual.createReadStream()) chunks.push(chunk);
  const data = Buffer.concat(chunks);
  await writeFile(resolve(output, filename), data);
  const record = { filename, bytes: data.length, sha256: hash(data), suggested_filename: actual.suggestedFilename() };
  report.downloads.push(record);
  return { data, record };
}
async function currentWriting(page) {
  return page.evaluate(() => ({
    notes: [...document.querySelectorAll('[data-reflection-item]')].map(field => [field.dataset.reflectionItem, field.value]),
    application: document.querySelector('#application-reflection')?.value,
    first_summary: document.querySelector('#first-try-summary')?.textContent,
    mastery: document.querySelector('.mastery-box')?.textContent
  }));
}
async function currentQuestion(page) {
  const prompt = await page.locator('.question-card h2').textContent();
  const item = deck.items.find(item => item.prompt === prompt);
  assert.ok(item, 'The current prompt belongs to the actual exported focused file.');
  const order = await page.locator('[data-choice]').evaluateAll(nodes => nodes.map(node => Number(node.dataset.choice)));
  return { item, order };
}
function withoutSavedAt(doc) { const copy = structuredClone(doc); delete copy.savedAt; return copy; }
function assertNotes(text, answers, withWriting) {
  for (const value of [deck.title, deck.attribution, deck.license, genericPrompt]) assert.ok(text.includes(value), value);
  assert.ok(text.includes('3 of 5 connections correct on the first try.'));
  assert.ok(text.includes('Not started. 2 missed connections are available for practice.'));
  assert.deepEqual(text.match(/^Practice answer:.*$/gm), ['Practice answer: not recorded.', 'Practice answer: not recorded.'], 'Resume retains explicit unrecorded retry markers, with no old practice choices.');
  for (const answer of answers) {
    const item = deck.items.find(item => item.id === answer.id);
    for (const value of [item.prompt, 'Your first answer: ' + item.options[answer.choice], 'Correct answer: ' + item.options[item.answer], item.explanation, item.transfer]) assert.ok(text.includes(value), item.id + ': ' + value);
    for (const line of noteFor(item.id).split('\n')) assert.equal(text.includes('  > ' + line), withWriting);
  }
  for (const line of application.split('\n')) assert.equal(text.includes('  > ' + line), withWriting);
}
try {
  browser = await chromium.launch({ executablePath: options.browser, headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-background-networking'] });
  report.browser_version = browser.version();
  for (const standalone of [false, true]) {
    const mode = standalone ? 'standalone-phone' : 'modular';
    const context = await browser.newContext({ acceptDownloads: true, viewport: { width: standalone ? 390 : 1280, height: standalone ? 844 : 960 } });
    await context.route('**/*', route => {
      const url = route.request().url();
      if (url.startsWith(origin + '/') || url.startsWith(pathToFileURL(root + '/').href) || url.startsWith('blob:') || url.startsWith('data:')) return route.continue();
      report.external_requests.push(url); return route.abort();
    });
    if (standalone) await context.setOffline(true);
    const page = await context.newPage();
    page.on('pageerror', error => report.page_errors.push(String(error)));
    try {
      await page.goto(standalone ? pathToFileURL(resolve(root, 'demo.html')).href : origin + '/index.html');
      await button(page, '#start-button');
      await button(page, '[data-choice="0"]');
      const original = await page.locator('#session-content').innerHTML();
      await previewDeck(page);
      assert.equal(await page.locator('#session-content').innerHTML(), original);
      await button(page, '#cancel-deck');
      assert.equal(await page.locator('#session-content').innerHTML(), original);
      await previewDeck(page);
      await button(page, '#start-deck');
      await page.locator('#lesson-archive-panel > summary').click();
      const firstAnswers = [], orders = {};
      let saved;
      for (let index = 0; index < deck.items.length; index++) {
        const { item, order } = await currentQuestion(page);
        assert.ok(!firstAnswers.some(answer => answer.id === item.id));
        orders[item.id] = order;
        const choice = index % 2 ? (item.answer + 1) % item.options.length : item.answer;
        await button(page, '[data-choice="' + choice + '"]');
        firstAnswers.push({ id: item.id, choice, correct: choice === item.answer });
        if (index === 1) {
          saved = await download(page, '#save-lesson-button', mode + '-two-answer-feedback.json');
          const document = JSON.parse(saved.data);
          assert.deepEqual(document.deck, deck);
          assert.equal(document.format, 'recallweave.unfinished-lesson');
          assert.equal(document.presentation.phase, 'feedback');
          assert.equal(document.presentation.itemId, item.id);
          assert.deepEqual(document.firstAnswers.map(answer => ({ id: answer.item, choice: answer.choice })), firstAnswers.map(({ id, choice }) => ({ id, choice })));
        }
        await button(page, '#next-button');
      }
      const savedDocument = JSON.parse(saved.data);
      assert.deepEqual(savedDocument.presentation.optionOrders, orders);
      assert.equal(firstAnswers.filter(answer => answer.correct).length, 3);
      for (const answer of firstAnswers) {
        const field = page.locator('[data-reflection-item="' + answer.id + '"]');
        await field.locator('xpath=ancestor::details[1]').locator('summary').click();
        await field.fill(noteFor(answer.id));
      }
      await page.locator('#application-reflection').fill(application);
      await button(page, '#practice-button');
      for (const answer of firstAnswers.filter(answer => !answer.correct)) {
        const item = deck.items.find(item => item.id === answer.id);
        assert.equal(await page.locator('.practice-card h2').textContent(), item.prompt);
        await button(page, '[data-practice-choice="' + item.answer + '"]');
        await button(page, '#practice-feedback button');
      }
      assert.match(await page.locator('#practice-status').textContent(), /2 of 2 correctly on retry/);
      const writing = await currentWriting(page);
      await previewLesson(page, saved.data);
      assert.deepEqual(await currentWriting(page), writing);
      await previewDeck(page);
      assert.deepEqual(await currentWriting(page), writing);
      await button(page, '#cancel-deck');
      assert.ok(await page.locator('#lesson-preview').isVisible());
      await button(page, '#resume-lesson-cancel');
      assert.deepEqual(await currentWriting(page), writing);
      await previewLesson(page, saved.data);
      if (standalone) {
        await page.locator('#lesson-preview').scrollIntoViewIfNeeded();
        await page.screenshot({ path: resolve(output, 'phone-resume-focused-notebook.png') });
        report.screenshots.push('phone-resume-focused-notebook.png');
      }
      await button(page, '#resume-lesson-confirm');
      assert.equal(await page.locator('#step-count').textContent(), '2 / 5');
      const lastPrefix = firstAnswers[1], lastItem = deck.items.find(item => item.id === lastPrefix.id);
      assert.equal(await page.locator('.question-card h2').textContent(), lastItem.prompt);
      assert.ok((await page.locator('#feedback-slot').textContent()).includes(lastItem.explanation));
      assert.ok(await page.locator('[data-choice]').evaluateAll(nodes => nodes.every(node => node.disabled)));
      assert.deepEqual((await currentQuestion(page)).order, savedDocument.presentation.optionOrders[lastItem.id]);
      const resumed = await download(page, '#save-lesson-button', mode + '-resaved-feedback.json');
      assert.deepEqual(withoutSavedAt(JSON.parse(resumed.data)), withoutSavedAt(savedDocument));
      for (const answer of firstAnswers.slice(2)) {
        await button(page, '#next-button');
        const { item, order } = await currentQuestion(page);
        assert.equal(item.id, answer.id);
        assert.deepEqual(order, savedDocument.presentation.optionOrders[item.id]);
        await button(page, '[data-choice="' + answer.choice + '"]');
      }
      await button(page, '#next-button');
      assert.deepEqual(await currentWriting(page), writing);
      assert.match(await page.locator('#practice-status').textContent(), /Try each of the 2 missed connections once more/);
      assert.equal(await page.locator('.review-practice-answer').count(), 0);
      const notes = await download(page, '#save-notes-button', mode + '-resumed-notebook.txt');
      assertNotes(notes.data.toString('utf8'), firstAnswers, true);
      await previewLesson(page, saved.data);
      await previewDeck(page);
      await button(page, '#start-deck');
      assert.equal(await page.locator('#lesson-preview').isVisible(), false);
      assert.match(await page.locator('#lesson-restore-status').textContent(), /lesson changed/);
      assert.equal(await page.locator('#step-count').textContent(), '0 / 5');
      const freshQuestion = await page.locator('#session-content').innerHTML();
      await button(page, '#use-bundled-deck');
      const bundledQuestion = await page.locator('#session-content').innerHTML();
      assert.notEqual(bundledQuestion, freshQuestion);
      await page.locator('#lesson-file').setInputFiles({ name: 'focused-against-wrong-course.json', mimeType: 'application/json', buffer: saved.data });
      await page.waitForFunction(() => !document.querySelector('#lesson-restore-status').textContent.includes('Reading'));
      assert.equal(await page.locator('#lesson-preview').isVisible(), false);
      const mismatch = await page.locator('#lesson-restore-status').textContent();
      assert.match(mismatch, /current lesson is unchanged/);
      assert.equal(await page.locator('#session-content').innerHTML(), bundledQuestion);
      await previewDeck(page);
      await button(page, '#start-deck');
      await previewLesson(page, saved.data);
      await button(page, '#resume-lesson-confirm');
      for (const answer of firstAnswers.slice(2)) {
        await button(page, '#next-button');
        assert.equal((await currentQuestion(page)).item.id, answer.id);
        await button(page, '[data-choice="' + answer.choice + '"]');
      }
      await button(page, '#next-button');
      const cleared = await currentWriting(page);
      assert.deepEqual(cleared.notes.map(([, value]) => value), ['', '', '', '', '']);
      assert.equal(cleared.application, '');
      const freshNotes = await download(page, '#save-notes-button', mode + '-fresh-course-resumed.txt');
      assertNotes(freshNotes.data.toString('utf8'), firstAnswers, false);
      const dimensions = await page.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }));
      assert.ok(dimensions.scroll <= dimensions.width, JSON.stringify(dimensions));
      report.cases.push({ name: mode, passed: true, firstAnswers, saved_feedback: saved.record, resaved_feedback: resumed.record,
        notebook_notes: notes.record, fresh_course_notes: freshNotes.record, source_mismatch_message: mismatch, dimensions,
        preserved_reflections: writing.notes, application: writing.application,
        assertions: ['real exported focused file admitted only on Start', 'two-answer feedback save is the actual downloaded file',
          'preview/cancel preserves current notebook and completed practice', 'explicit resume preserves canonical prefix, permutations and exact saved mastery',
          'continued answer order and notebook match before resume; old practice is reset', 'same-course Start retires pending resume',
          'saved focused lesson is refused against the bundled source', 'fresh course import clears notebook before explicit resume'] });
      console.log('PASS ' + mode);
    } catch (error) { report.cases.push({ name: mode, passed: false, error: error.stack }); throw error; }
    finally { await context.close(); }
  }
  assert.deepEqual(report.page_errors, []);
  assert.deepEqual(report.external_requests, []);
  for (const row of source.files) assert.equal(hash(await readFile(resolve(root, row.path))), row.sha256, row.path + ' unchanged');
  assert.equal(hash(await readFile(options.input)), report.input.sha256);
  report.passed = true;
} catch (error) { report.passed = false; report.error = error.stack; process.exitCode = 1; }
finally {
  await browser?.close();
  await new Promise(done => server.close(done));
  await rm(temporary, { recursive: true, force: true });
  await writeFile(resolve(output, 'receiving.json'), JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ passed: report.passed, cases: report.cases.length, downloads: report.downloads.length, output }));
