const assert = require('node:assert/strict');
const vm = require('node:vm');
const {createHash,webcrypto}=require('node:crypto');
const fs=require('node:fs');
const input=JSON.parse(process.argv[1]);
const start=performance.now();
const record={schema:'recallweave180-root-isolated-loader-receiving/1',worker:'estate-6e5752b49b6f/root',node:process.version,platform:process.platform,execPath:process.execPath,scope:'Exact page and unchanged deck source compiled as ESM in one Node vm context. The unreceived177 module is a linked refusal sentinel, not a comparator; zero sentinel calls are required. Only file admission, captured identity, slot lifecycle, immutability and pre-comparison refusal are exercised. No comparison semantics, report creation/download, product browser, native LA7 runtime, or generated-page acceptance.',groups:[],source:[],accepted:false,coreSentinelCalls:0};
const sha=b=>createHash('sha256').update(b).digest('hex');
const plain=x=>JSON.parse(JSON.stringify(x));
const freezeCheck=x=>{if(x&&typeof x==='object'){assert.equal(Object.isFrozen(x),true);Object.values(x).forEach(freezeCheck);}};
const pause=()=>new Promise(r=>setImmediate(r));
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return{promise,resolve,reject};}
function bytesBuffer(b){return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);}
function file(name,raw,extra={}){const bytes=Buffer.from(raw);return{name,size:bytes.length,arrayBuffer:async()=>bytesBuffer(bytes),...extra};}
const d={format:'recallweave-deck/1',title:'  Literal 日本語 title ',attribution:'Root isolated receiving fixture',license:'CC0',concepts:['C'],items:[{id:' a  b ',concept:'C',prerequisites:[],prompt:'Literal <source> prompt',options:['A','B'],answer:1,explanation:'The exact answer is B.',transfer:'Apply this exact idea.'}]};
const text=JSON.stringify(d),raw=Buffer.from(text),changed=Buffer.from(JSON.stringify({...d,title:'Later accepted copy'})),MAX=262144;
function group(name,details={}){record.groups.push({name,accepted:true,...details});}
(async()=>{
 for(const f of [input.page,input.deck]){const b=Buffer.from(f.text);assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256);assert.equal(createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex'),f.gitBlob);record.source.push({path:f.path,bytes:f.bytes,sha256:f.sha256,gitBlob:f.gitBlob});}
 const context=vm.createContext({TextEncoder,TextDecoder,ArrayBuffer,Uint8Array,crypto:webcrypto,Error});
 const sentinel=new vm.SyntheticModule(['compareCourses'],function(){this.setExport('compareCourses',()=>{record.coreSentinelCalls++;throw new Error('UNRECEIVED_177_COMPARATOR_MUST_NOT_BE_CALLED');});},{context,identifier:'unreceived-owner177-refusal-sentinel'});
 const deck=new vm.SourceTextModule(input.deck.text,{context,identifier:input.deck.path+'@'+input.deck.gitBlob});
 const pageModule=new vm.SourceTextModule(input.page.text,{context,identifier:input.page.path+'@'+input.page.gitBlob});
 await pageModule.link(spec=>{if(spec==='./deck.mjs')return deck;if(spec==='./course-comparison.mjs')return sentinel;throw new Error('Unexpected import '+spec);});
 await pageModule.evaluate();const create=pageModule.namespace.createCourseComparisonPage;
 const page=create();assert.equal(page.state().canCompare,false);assert.throws(()=>page.compare(),/Load an earlier and a revised course first/);
 assert.equal((await page.load('before',file(' earlier  <copy>.json',raw))).status,'accepted');
 assert.deepEqual(plain(page.state().slots.before),{name:' earlier  <copy>.json',bytes:raw.length,sha256:sha(raw),title:d.title,questions:1,concepts:1});
 assert.equal(page.state().canCompare,false);assert.throws(()=>page.compare(),/Load an earlier and a revised course first/);
 assert.equal((await page.load('after',file('revised.json',Buffer.from('\n'+text+'\n')))).status,'accepted');
 assert.equal(page.state().canCompare,true);assert.notEqual(page.state().slots.before.sha256,page.state().slots.after.sha256);
 const originalView=page.state();freezeCheck(originalView);
 assert.equal(Reflect.set(originalView.slots.before,'name','changed'),false);assert.equal(Reflect.set(originalView.pending,'before',true),false);
 assert.deepEqual(Object.keys(originalView.slots.before),['name','bytes','sha256','title','questions','concepts']);assert.equal(page.state().slots.before.name,' earlier  <copy>.json');
 group('captured UTF-8 identity and frozen public state',{utf8Bytes:raw.length,sha256:sha(raw),distinctByteSpelling:true,privateSourceNotExposed:true});
 let reads=0;const preBad=[
 {name:'large.json',size:MAX+1,arrayBuffer:async()=>{reads++;return bytesBuffer(raw);}},
 {name:'negative.json',size:-1,arrayBuffer:async()=>{reads++;return bytesBuffer(raw);}},
 {name:'fraction.json',size:1.5,arrayBuffer:async()=>{reads++;return bytesBuffer(raw);}},
 {name:'nan.json',size:NaN,arrayBuffer:async()=>{reads++;return bytesBuffer(raw);}},
 {name:3,size:raw.length,arrayBuffer:async()=>{reads++;return bytesBuffer(raw);}},
 {name:'missing-reader.json',size:raw.length}
 ];
 for(const f of preBad){assert.equal((await page.load('before',f)).status,'refused');assert.equal(page.state().slots.before.sha256,sha(raw));assert.equal(page.state().pending.before,false);assert.match(page.state().errors.before,/previous accepted copy is still loaded/);}
 assert.equal(reads,0);const beforeCancel=plain(page.state());assert.equal((await page.load('before',null)).status,'cancelled');assert.deepEqual(plain(page.state()),beforeCancel);assert.equal((await page.load('before',undefined)).status,'cancelled');assert.deepEqual(plain(page.state()),beforeCancel);
 await assert.rejects(()=>page.load('unknown',file('x',raw)),/earlier or revised course role/);assert.throws(()=>page.clear('unknown'),/earlier or revised course role/);assert.deepEqual(plain(page.state()),beforeCancel);
 group('pre-read refusals, cancellation and exact role guard',{preReadRefusals:preBad.length,actualPreReadCalls:reads});
 const oversized=Buffer.concat([raw,Buffer.alloc(MAX+1-raw.length,32)]);
 const malformed=[
 ['captured-overflow.json',oversized,{size:1},/captured file must be no larger/],
 ['bad-utf8.json',Buffer.from([0xc3,0x28]),{},/not valid UTF-8/],
 ['bom.json',Buffer.concat([Buffer.from([0xef,0xbb,0xbf]),raw]),{},/not valid JSON/],
 ['invalid-json.json',Buffer.from('{'),{},/not valid JSON/],
 ['invalid-deck.json',Buffer.from(JSON.stringify({...d,items:[]})),{},/items must contain/],
 ['duplicate-id.json',Buffer.from(JSON.stringify({...d,items:[d.items[0],d.items[0]]})),{},/duplicates another question ID/],
 ['wrong-capture.json',raw,{arrayBuffer:async()=>new Uint8Array(raw)},/captured file must be/],
 ['read-error.json',raw,{arrayBuffer:async()=>{throw new Error('CONTROLLED_READ_ERROR');}},/CONTROLLED_READ_ERROR/]
 ];
 for(const [name,b,extra,message]of malformed){assert.equal((await page.load('before',file(name,b,extra))).status,'refused');assert.equal(page.state().slots.before.sha256,sha(raw));assert.match(page.state().errors.before,message);assert.equal(page.state().canCompare,true);}
 const bounded=create();const edge=Buffer.concat([raw,Buffer.alloc(MAX-raw.length,32)]);assert.equal(edge.length,MAX);assert.equal((await bounded.load('before',file('exact-256KiB.json',edge))).status,'accepted');assert.equal(bounded.state().slots.before.bytes,MAX);assert.equal(bounded.state().slots.before.sha256,sha(edge));assert.equal((await bounded.load('after',file('one-byte-too-large.json',oversized))).status,'refused');assert.equal(bounded.state().slots.after,null);
 group('fatal decoding, unchanged parser and both raw-size boundaries',{capturedRefusals:malformed.length,exactCapAccepted:MAX,oneByteOverRefused:MAX+1,leadingBomRetainedForParser:true});
 const race=create(),a=deferred(),b=deferred();const first=race.load('before',file('late-earlier.json',raw,{arrayBuffer:()=>a.promise}));assert.equal(race.state().pending.before,true);
 const other=race.load('after',file('pending-revised.json',raw,{arrayBuffer:()=>b.promise}));
 assert.throws(()=>race.compare(),/Wait until both file reads finish/);
 assert.equal((await race.load('before',file('new-earlier.json',changed))).status,'accepted');assert.equal(race.state().pending.after,true);a.resolve(bytesBuffer(raw));assert.equal((await first).status,'stale');assert.equal(race.state().slots.before.name,'new-earlier.json');
 b.resolve(bytesBuffer(raw));assert.equal((await other).status,'accepted');assert.equal(race.state().canCompare,true);
 const c=deferred();const retired=race.load('before',file('cleared-late.json',raw,{arrayBuffer:()=>c.promise}));race.clear('before');assert.equal(race.state().slots.before,null);assert.equal(race.state().pending.before,false);c.resolve(bytesBuffer(raw));assert.equal((await retired).status,'stale');assert.equal(race.state().slots.before,null);assert.equal(race.state().slots.after.name,'pending-revised.json');
 group('independent slot versions and stale arrayBuffer completions',{lateReplacement:'stale',clearRetirement:'stale',otherRolePreserved:true});
 let digestCalls=0;const oldDigest=deferred();const digestPage=create({digest:async b=>{digestCalls++;if(digestCalls===1)return oldDigest.promise;return sha(b);}});
 const prior=digestPage.load('before',file('old-digest.json',raw));await pause();assert.equal(digestCalls,1);assert.equal(digestPage.state().pending.before,true);
 assert.equal((await digestPage.load('before',file('new-digest.json',changed))).status,'accepted');oldDigest.resolve(sha(raw));assert.equal((await prior).status,'stale');assert.equal(digestPage.state().slots.before.sha256,sha(changed));
 let currentDigest=sha(raw);const digestFailure=create({digest:async()=>currentDigest});assert.equal((await digestFailure.load('before',file('good.json',raw))).status,'accepted');
 for(const bad of ['BAD', 'A'.repeat(64), 1, null]){currentDigest=bad;assert.equal((await digestFailure.load('before',file('bad-digest.json',changed))).status,'refused');assert.equal(digestFailure.state().slots.before.sha256,sha(raw));assert.match(digestFailure.state().errors.before,/could not be fingerprinted/);}
 const rejectDigest=deferred(),clearedDigest=create({digest:()=>rejectDigest.promise});const p=clearedDigest.load('after',file('cleared-digest.json',raw));await pause();clearedDigest.clear('after');rejectDigest.reject(new Error('RETIRED_DIGEST_ERROR'));assert.equal((await p).status,'stale');assert.equal(clearedDigest.state().slots.after,null);assert.equal(clearedDigest.state().errors.after,'');
 group('stale digest completion and fingerprint-refusal recovery',{invalidDigestRefusals:4,retiredDigestFailureIgnored:true,digestCalls});
 assert.equal(originalView.slots.before.name,' earlier  <copy>.json');assert.equal((await page.load('before',file('accepted-new.json',changed))).status,'accepted');assert.equal(page.state().slots.before.title,'Later accepted copy');assert.equal(originalView.slots.before.title,d.title);assert.equal(page.state().errors.before,'');page.clear('after');assert.equal(page.state().canCompare,false);assert.equal(page.state().slots.after,null);assert.equal(page.state().report,null);freezeCheck(page.state());
 assert.equal(record.coreSentinelCalls,0);group('previous frozen snapshots and clean final recovery',{comparisonSentinelCalls:record.coreSentinelCalls,comparisonSemanticsExecuted:false});
 record.accepted=true;
})().catch(e=>{record.failure={name:e.name,message:e.message,stack:e.stack};process.exitCode=1;}).finally(()=>{record.elapsedMs=performance.now()-start;process.stdout.write(JSON.stringify(record,null,2)+'\n');});
