# Original learner observation correction — no rerun

The original browser R1's hidden review-answer DOM query returned two empty strings before and after practice. Its equality comparison is vacuous and does not establish first-answer preservation. Preserve that raw receipt and its overly broad boolean unchanged.

The actual recorded first choices were origin-a option0 ([2, 1], wrong) and origin-b option1 (3, right). The actual downloaded notes are1,758bytes, SHA256227908866db6b5c85a7dcd6c0d6ca0bff69fcd30c2bd31b1fedfe35dc80fba73. They retain those exact first choices/statuses, the distinct origin-a practice answer ([1, 2], correct on retry), both explanations and the reflections. Native freeze will independently parse those retained note blocks against the frozen original fixture and recorded choice events. That existing download supplies the post-practice first-answer evidence; the empty DOM array supplies none. The nonempty first-summary/mastery comparisons remain valid.

No source, browser run or raw artifact is modified or repeated. Candidate learner receiving will query complete DOM text content and literal review fields, avoiding this hidden-innerText observer.
