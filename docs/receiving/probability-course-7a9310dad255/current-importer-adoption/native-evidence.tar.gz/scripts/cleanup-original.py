import json,hashlib,shutil,base64,time
from pathlib import Path
r=Path("/tmp/hamon-7a9310dad255-recall19-integration")
def pin(p):
 d=p.read_bytes();return {"path":str(p),"bytes":len(d),"sha256":hashlib.sha256(d).hexdigest()}
removed=[]
for name,sha in [("current-d202.tar.gz","f2b213288ab4589ef2ca54c5d317ce10663ab183fd8ca3acde38ea10dd258341"),("course-226.tar.gz","cc7e5ce073113d4f595e20f32493722708244378bdb6ebbea99667d03d382ead")]:
 p=r/name;item=pin(p);assert item["sha256"]==sha
 removed.append(item);p.unlink()
p=r/"current-c00/public-current-c00.tar.gz";item=pin(p)
item["failure_role"]="Incomplete public source transport from the exact failed EDQUOT capture; no source was extracted."
removed.append(item);p.unlink()
rows=[]
for p in sorted((r/"course-overlay").rglob("*")):
 if p.is_file():
  relative=p.relative_to(r/"course-overlay");other=r/"candidate"/relative
  assert p.read_bytes()==other.read_bytes() and (p.stat().st_mode&0o777)==(other.stat().st_mode&0o777)
  rows.append(pin(p))
assert len(rows)==28
removed.append({"path":str(r/"course-overlay"),"files":28,"bytes":sum(x["bytes"] for x in rows),"verified_against":"exact retained original contribution in frozen d202 candidate","entries":rows})
shutil.rmtree(r/"course-overlay")
receipt={"at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"reason":"Recover from EDQUOT by removing only this worker's reproducible public-source transports and one exact duplicate overlay. Full baseline, qualified candidate, immutable patch, raw native qualification and accepted assessments remain.","removed":removed,"released_bytes":sum(x["bytes"] for x in removed)}
with (r/"quota-cleanup-receipt.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
print(json.dumps({"released_bytes":receipt["released_bytes"],"receipt":pin(r/"quota-cleanup-receipt.json")},indent=2))
