#!/usr/bin/env node
// Independent receiving scaffold, authored from the frozen public contract.
// No production model, UI implementation, or author harness is imported.
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, realpath, stat } from 'node:fs/promises';
import { resolve, relative, sep, extname, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { handCase, assertTraceBytes, sha256, gitBlob } from './trace-contract.mjs';

const configPath = process.argv[2];
assert(configPath, 'Usage: node receive-browser.mjs <frozen-execution-config.json>');
const config = JSON.parse(await readFile(configPath, 'utf8'));
assert.equal(config.status, 'frozen', 'Scaffold must not execute before source/configuration freeze');
assert(config.sourceRoot && config.entry && config.outputRoot && config.sourcePin);
assert(Array.isArray(config.sourceFiles) && config.sourceFiles.length > 0);
assert(config.sourceFiles.some(row => row.path === config.entry), 'Generated standalone HTML must be source-pinned');
const sourceRoot = await realpath(config.sourceRoot);
const outputRoot = resolve(config.outputRoot);
assert(!outputRoot.startsWith(sourceRoot + sep), 'Evidence must be outside the product source tree');
await mkdir(outputRoot, { recursive: true });
const report = {
  schema: 'recallweave-timing-independent-browser/1', startedAt: new Date().toISOString(),
  sourcePin: config.sourcePin, contractHashes: config.contractHashes, configuration: config,
  checks: [], requests: [], pageErrors: [], consoleErrors: [], downloads: [], nativeInputs: [],
  browserDownloads: [], servedFiles: [], sourceBefore: [], sourceAfter: [], ok: false,
};
async function pinSources() {
  const pins = [];
  for (const row of config.sourceFiles) {
    const path = resolve(sourceRoot, row.path);
    assert(path.startsWith(sourceRoot + sep), 'Source pin escapes selected root');
    const bytes = await readFile(path);
    assert.equal(gitBlob(bytes), row.gitBlob, 'Git blob mismatch for ' + row.path);
    if (row.sha256) assert.equal(sha256(bytes), row.sha256, 'SHA256 mismatch for ' + row.path);
    pins.push({ path: row.path, bytes: bytes.length, gitBlob: gitBlob(bytes), sha256: sha256(bytes) });
  }
  return pins;
}
const checkpoint = async () => writeFile(join(outputRoot, 'receipt.json'), JSON.stringify(report, null, 2) + '\n');
async function group(name, body) {
  const startedAt = new Date().toISOString();
  try {
    const detail = await body();
    report.checks.push({ name, passed: true, startedAt, finishedAt: new Date().toISOString(), detail });
    console.log('PASS ' + name);
  } catch (error) {
    report.checks.push({ name, passed: false, startedAt, error: String(error), stack: error.stack });
    throw error;
  } finally { await checkpoint(); }
}
let server, browser, context, page, origin;
let downloadSequence = 0;
function containedPath(url) {
  const pathname = decodeURIComponent(new URL(url, origin).pathname);
  const path = resolve(sourceRoot, '.' + pathname);
  assert(path === sourceRoot || path.startsWith(sourceRoot + sep), 'URL escapes selected source');
  return path;
}
async function serve() {
  server = createServer(async (request, response) => {
    try {
      if (!['GET', 'HEAD'].includes(request.method)) { response.writeHead(405).end(); return; }
      const path = containedPath(request.url);
      const bytes = await readFile(path);
      const type = ({ '.html': 'text/html; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8' })[extname(path)] || 'application/octet-stream';
      report.servedFiles.push({ path: relative(sourceRoot, path), bytes: bytes.length, sha256: sha256(bytes) });
      response.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' });
      response.end(request.method === 'HEAD' ? undefined : bytes);
    } catch (error) { response.writeHead(error.code === 'ENOENT' ? 404 : 400).end(); }
  });
  await new Promise((yes, no) => { server.once('error', no); server.listen(0, '127.0.0.1', yes); });
  origin = 'http://127.0.0.1:' + server.address().port;
}
const visible = selector => page.locator(selector).isVisible();
async function assertDraft() {
  assert.equal(await visible('#timing-results'), false, 'Edited/draft results must not remain visible');
  assert.equal(await page.locator('#download-trace').isDisabled(), true, 'Draft download must be disabled');
}
async function setCase(testCase, spellings = new Map()) {
  await page.locator('#jobs-input').fill(testCase.graph.jobs.join('\n'));
  await page.locator('#edges-input').fill(testCase.graph.edges.map(([a, b], i) => a + (i % 2 ? ' → ' : ' -> ') + b).join('\n'));
  assert.equal(await page.locator('#duration-inputs input[data-job]').count(), testCase.graph.jobs.length);
  for (const row of [...testCase.durations].reverse()) {
    await page.getByLabel('Duration for ' + row.job, { exact: true }).fill(spellings.get(row.job) ?? String(row.duration));
  }
  report.nativeInputs.push({ case: testCase.name, graph: testCase.graph, durations: testCase.durations, spellings: [...spellings] });
  await assertDraft();
}
async function calculate() {
  await page.getByRole('button', { name: 'Calculate timing', exact: true }).click();
}
async function assertVisibleTiming(testCase) {
  assert.equal(await visible('#acyclic-results'), true);
  assert.equal(await visible('#cycle-results'), false);
  assert.equal(await page.locator('#download-trace').isDisabled(), false);
  const projectDuration = (await page.locator('#project-duration').innerText()).trim();
  assert.equal(projectDuration, String(testCase.timing.projectDuration), 'Visible project duration must match the hand calculation');
  const rows = await page.locator('#timing-rows tr[data-job]').evaluateAll(elements => elements.map(element => ({
    job: element.dataset.job,
    criticalFlag: element.dataset.critical,
    visibleJob: element.querySelector('th .job-name')?.textContent.trim(),
    milestoneLabel: element.querySelector('th .milestone-label')?.textContent.trim() ?? null,
    fields: Object.fromEntries([...element.querySelectorAll('td[data-field]')].map(cell => [cell.dataset.field, cell.textContent.trim()])),
  })));
  assert.deepEqual(rows.map(row => row.job), testCase.graph.jobs);
  for (let i = 0; i < rows.length; i++) {
    const actual = rows[i], expected = testCase.timing.rows[i];
    assert.equal(actual.visibleJob, expected.job, 'The literal job name must be visible');
    assert.equal(actual.milestoneLabel, expected.duration === 0 ? 'Milestone · duration 0' : null, 'Zero-duration milestone annotation stays separate from the literal name');
    for (const field of ['duration', 'earliestStart', 'earliestFinish', 'latestStart', 'latestFinish', 'totalSlack'])
      assert.equal(actual.fields[field], String(expected[field]), expected.job + ':' + field);
    assert.equal(actual.fields.critical, expected.critical ? 'Critical · zero slack' : 'Has slack', 'Visible critical status must match the row');
    assert.equal(actual.criticalFlag, String(expected.critical));
  }
  const criticalJobs = await page.locator('#critical-jobs li[data-job]').evaluateAll(xs => xs.map(x => x.dataset.job));
  const criticalEdges = await page.locator('#critical-edges li[data-from][data-to]').evaluateAll(xs => xs.map(x => [x.dataset.from, x.dataset.to]));
  assert.deepEqual(criticalJobs, testCase.timing.criticalJobs);
  assert.deepEqual(criticalEdges, testCase.timing.criticalEdges);
  return { projectDuration, rows, criticalJobs, criticalEdges };
}
async function captureTrace(testCase, keyboard = false) {
  const pending = page.waitForEvent('download');
  if (keyboard) await page.keyboard.press('Enter');
  else await page.getByRole('button', { name: 'Download timing trace (.json)', exact: true }).click();
  const download = await pending;
  assert.equal(download.suggestedFilename(), 'recallweave-dependency-timing.json');
  const file = 'trace-' + (++downloadSequence) + '-' + testCase.name + '.json';
  await download.saveAs(join(outputRoot, file));
  assert.equal(await download.failure(), null);
  const bytes = await readFile(join(outputRoot, file));
  const receipt = assertTraceBytes(bytes, testCase);
  report.downloads.push({ file, ...receipt });
  await page.waitForFunction(() => !document.querySelector('#download-trace').disabled, null, { timeout: 3000 });
  report.downloads.at(-1).nativeReadyAfterCleanup = true;
  return bytes;
}
async function tabTo(locator) {
  for (let attempt = 0; attempt < 80; attempt++) {
    if (await locator.evaluate(element => element === document.activeElement)) return;
    await page.keyboard.press('Tab');
  }
  throw Error('Public control was not reachable by keyboard Tab');
}
async function keyboardReplace(locator, value) {
  await tabTo(locator);
  await page.keyboard.press('Control+A');
  await page.keyboard.insertText(value);
}
try {
  report.sourceBefore = await pinSources();
  await serve();
  const { chromium } = await import(pathToFileURL(config.playwrightModule).href);
  browser = await chromium.launch({ executablePath: config.chromium, headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  report.browserVersion = browser.version();
  context = await browser.newContext({ acceptDownloads: true, viewport: { width: 1280, height: 900 } });
  await context.route('**/*', route => {
    const url = route.request().url(), allowed = url.startsWith(origin + '/');
    report.requests.push({ url, method: route.request().method(), allowed });
    return allowed ? route.continue() : route.abort('blockedbyclient');
  });
  page = await context.newPage();
  page.on('pageerror', error => report.pageErrors.push(String(error)));
  page.on('console', message => { if (message.type() === 'error') report.consoleErrors.push(message.text()); });
  page.on('download', download => report.browserDownloads.push({ filename: download.suggestedFilename() }));
  await page.goto(origin + '/' + config.entry, { waitUntil: 'load' });

  await group('initial example is an uncalculated draft', async () => {
    await assertDraft();
    assert.equal(await page.locator('#calculate-timing').isDisabled(), false);
    return { storedResult: false, downloads: report.browserDownloads.length };
  });
  const tied = handCase('tied');
  await group('literal duration entry and both critical branches', async () => {
    await setCase(tied, new Map([['Right', ' 002 '], ['__proto__', '000']]));
    await calculate();
    return assertVisibleTiming(tied);
  });
  await group('actual deterministic trace bytes preserve the exact analyzed input and result', async () => {
    const first = await captureTrace(tied), second = await captureTrace(tied);
    assert(first.equals(second), 'Unchanged downloads must be byte-identical');
    return { bytes: first.length, sha256: sha256(first), repeats: 2 };
  });
  await group('same-task edit invalidates download before activation and recomputes changed slack', async () => {
    const downloadsBefore = report.browserDownloads.length;
    const immediate = await page.getByLabel('Duration for Right', { exact: true }).evaluate(element => {
      element.value = '1';
      element.dispatchEvent(new Event('input', { bubbles: true }));
      const button = document.querySelector('#download-trace'), results = document.querySelector('#timing-results');
      const state = { disabled: button.disabled, resultsHidden: results.hidden || getComputedStyle(results).display === 'none' };
      button.click();
      return state;
    });
    assert.deepEqual(immediate, { disabled: true, resultsHidden: true });
    await assertDraft();
    await calculate();
    const changed = handCase('right-one');
    const display = await assertVisibleTiming(changed);
    assert.equal(report.browserDownloads.length, downloadsBefore, 'Invalidated native click must not create a download');
    await captureTrace(changed);
    return { immediate, display };
  });
  await group('cyclic edits refuse timing and cannot export the old DAG', async () => {
    const cycle = handCase('tied');
    cycle.graph.edges.push(['Finish', 'Left']);
    await setCase(cycle);
    await calculate();
    assert.equal(await visible('#cycle-results'), true);
    assert.equal(await visible('#acyclic-results'), false);
    assert.equal(await page.locator('#download-trace').isDisabled(), true);
    const cycleText = await page.locator('#cycle-groups').innerText();
    assert(cycleText.includes('Finish') && cycleText.includes('Left'));
    return { cycleText, blockedText: await page.locator('#blocked-jobs').innerText() };
  });
  await group('strict duration grammar refuses invalid drafts without a stale export', async () => {
    await setCase(tied);
    const observed = [];
    for (const value of ['', '-1', '+1', '1.0', '1e2', '1,000', '1000001']) {
      await page.getByLabel('Duration for Right', { exact: true }).fill(value);
      await calculate();
      assert.equal(await page.locator('#download-trace').isDisabled(), true);
      assert.equal(await visible('#acyclic-results'), false);
      const error = (await page.locator('#timing-error').innerText()).trim();
      assert(error.length > 0, 'Invalid duration requires a visible explanation');
      observed.push({ value, error });
    }
    return observed;
  });
  await group('all-zero literal-markup jobs retain zero timing without HTML interpretation', async () => {
    const zero = handCase('literal-zero');
    await setCase(zero);
    await calculate();
    const display = await assertVisibleTiming(zero);
    assert.equal((await page.locator('#timing-rows th .job-name').allTextContents()).filter(name => name === '<b>零</b>').length, 1);
    assert.equal(await page.locator('#timing-rows b').count(), 0, 'Literal job markup must not become a DOM element');
    await captureTrace(zero);
    return display;
  });
  await group('examples clear the old analysis and require an explicit new calculation', async () => {
    await page.locator('[data-example="branches"]').click();
    await assertDraft();
    await page.locator('[data-example="milestones"]').click();
    await assertDraft();
    return { downloadDisabled: true };
  });
  await group('375px keyboard entry calculation and download retain the literal result', async () => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.reload({ waitUntil: 'load' });
    await assertDraft();
    const zero = handCase('literal-zero');
    await keyboardReplace(page.locator('#jobs-input'), zero.graph.jobs.join('\n'));
    await keyboardReplace(page.locator('#edges-input'), zero.graph.edges.map(([a, b]) => a + ' -> ' + b).join('\n'));
    for (const { job } of zero.durations) await keyboardReplace(page.getByLabel('Duration for ' + job, { exact: true }), '0');
    await tabTo(page.getByRole('button', { name: 'Calculate timing', exact: true }));
    await page.keyboard.press('Enter');
    await assertVisibleTiming(zero);
    await tabTo(page.getByRole('button', { name: 'Download timing trace (.json)', exact: true }));
    await captureTrace(zero, true);
    const layout = await page.evaluate(() => ({ width: innerWidth, documentWidth: document.documentElement.scrollWidth, bodyWidth: document.body.scrollWidth }));
    assert(layout.documentWidth <= layout.width + 1 && layout.bodyWidth <= layout.width + 1, 'Document overflows the narrow viewport');
    const screenshot = 'keyboard-375px.png';
    await page.screenshot({ path: join(outputRoot, screenshot), fullPage: true });
    const bytes = await readFile(join(outputRoot, screenshot));
    report.screenshot = { file: screenshot, bytes: bytes.length, sha256: sha256(bytes), visualInspection: 'pending human-model inspection after execution' };
    return { layout, keyboardOnly: true, screenshot: report.screenshot };
  });
  assert.equal(report.downloads.length, 5);
  assert.equal(report.browserDownloads.length, report.downloads.length, 'Every actual download must be independently verified');
  assert.deepEqual(report.pageErrors, []);
  assert(report.requests.every(row => row.allowed), 'Unexpected off-origin request');
  assert(report.servedFiles.some(row => row.path === config.entry && row.sha256 === report.sourceBefore.find(pin => pin.path === config.entry).sha256));
  report.ok = true;
} catch (error) {
  report.error = String(error);
  report.stack = error.stack;
} finally {
  if (context) await context.close().catch(error => { report.cleanupError = String(error); });
  if (browser) await browser.close().catch(error => { report.cleanupError = String(error); });
  if (server) await new Promise(resolveClose => server.close(resolveClose));
  try {
    report.sourceAfter = await pinSources();
    assert.deepEqual(report.sourceAfter, report.sourceBefore);
    report.sourceUnchanged = true;
  } catch (error) { report.sourceUnchanged = false; report.sourceError = String(error); }
  report.ok = report.ok && report.sourceUnchanged && !report.cleanupError;
  report.finishedAt = new Date().toISOString();
  await checkpoint();
  console.log(JSON.stringify({ ok: report.ok, checks: report.checks.length, downloads: report.downloads.length, sourceUnchanged: report.sourceUnchanged, error: report.error, outputRoot }));
}
process.exitCode = report.ok ? 0 : 1;
