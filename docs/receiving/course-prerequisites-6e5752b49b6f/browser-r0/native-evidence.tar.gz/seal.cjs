'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const root=String.raw`C:\Users\jacob\AppData\Local\Hamon\estate-6e5752b49b6f\recall-prerequisite-browser-root-r0`;
const own=__dirname;
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=b=>crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const stamp=(name,b,s)=>({path:name,bytes:b.length,sha256:sha(b),gitBlob:git(b),mtimeMs:s.mtimeMs,mode:s.mode});
const cap=fs.statfsSync(own);assert(os.freemem()>=256*1024**2);assert(cap.bavail*cap.bsize>=64*1024**2);
assert.equal(sha(fs.readFileSync(process.execPath)),'63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088');
let entries=[],dirs=[];
function walk(dir,rel=''){for(const n of fs.readdirSync(dir).sort()){const file=path.join(dir,n),r=(rel?rel+'/':'')+n,s=fs.lstatSync(file);assert(!s.isSymbolicLink());if(s.isDirectory()){dirs.push(r);walk(file,r);}else{assert(s.isFile());const b=fs.readFileSync(file);entries.push({name:'original/'+r,data:b,record:stamp(r,b,s)});}}}
walk(root);assert(!dirs.some(n=>n.includes('owned-profile')));assert(entries.reduce((s,x)=>s+x.data.length,0)<16*1024**2);
const get=n=>entries.find(x=>x.record.path===n).data;
assert.equal(sha(get('browser-receiving-r0.json')),'06606144f3a3e9fecd698e6c932098f78f0899a21261605df3b18d4065aed621');
const run=JSON.parse(get('browser-receiving-r0.json')),exe=JSON.parse(get('browser-execution-r0.json'));
assert.equal(run.accepted,false);assert.equal(run.groups.length,1);assert.equal(run.downloads.length,0);assert.equal(exe.exitCode,1);
assert.equal(run.inputsUnchanged,true);assert.equal(run.browserClose.code,0);assert.equal(run.launcherClose.code,0);assert.equal(run.ownProfileRemoved,true);
for(const item of [...run.before,...run.fixturePins,...run.artifacts]){
 if(!item.path.toLowerCase().startsWith(root.toLowerCase()+'\\'))continue;
 const rel=path.relative(root,item.path).replaceAll('\\','/'),actual=entries.find(x=>x.record.path===rel)?.record;
 assert(actual,rel);assert.equal(actual.bytes,item.bytes);assert.equal(actual.sha256,item.sha256);assert.equal(actual.gitBlob,item.gitBlob);
}
assert.deepEqual(run.before,run.after);
const readme='RecallWeave196 original browser receiving R0 failure custody\n\nThis packet preserves every regular file in the frozen root, including original source, controller/observer, references, fixtures, logs, JSON observations and two original PNGs. No source, browser, screenshot or download was rerun/regenerated. The browser receiver failed at the native keyboard witness disclosure assertion (true stayed true), after the initial-empty group and before any download. The receipt remains accepted=false; this is NOT whole-browser or product acceptance. Browser.close/actual retained-handle exit and own-profile cleanup are recorded as successful in the failed run. A later corrected event attempt is separate. The suspected synthetic Enter event issue is not proved by this custody operation.\n\nThe external runtime executables are identified by original receipts, not copied into this packet. Original source/output bytes are rehashed against recorded inputs/artifacts and once more after packaging. Empty original directories are recorded in the manifest. This tar uses UTF-8 ustar names and retains payload bytes; tar timestamps/uid/mode are neutral packaging metadata, while original file metadata are in manifest.json.\n';
const custody={format:'recall196-original-browser-r0-custody/1',at:new Date().toISOString(),root,scope:'Frozen failed browser attempt; no execution or regeneration',runtime:{execPath:process.execPath,node:process.version,sha256:sha(fs.readFileSync(process.execPath)),user:os.userInfo().username},capacity:{freeMemoryBytes:os.freemem(),freeDiskBytes:cap.bavail*cap.bsize},sourceReceipt:{bytes:get('browser-receiving-r0.json').length,sha256:sha(get('browser-receiving-r0.json')),gitBlob:git(get('browser-receiving-r0.json'))},accepted:false,originalFiles:entries.length,originalDirectories:dirs,sourceAndArtifactAdmission:true,failedAt:run.failure,recordedBrowserClose:run.browserClose,recordedOwnProfileRemoved:run.ownProfileRemoved};
entries.push({name:'README.md',data:Buffer.from(readme)});
entries.push({name:'custody.json',data:Buffer.from(JSON.stringify(custody,null,2)+'\n')});
entries.push({name:'seal.cjs',data:fs.readFileSync(__filename)});
const manifest={format:'recall196-custody-manifest/1',originalRoot:root,originalRecords:entries.filter(x=>x.record).map(x=>x.record),originalDirectories:dirs,members:entries.map(x=>({path:x.name,bytes:x.data.length,sha256:sha(x.data),gitBlob:git(x.data)}))};
entries.push({name:'manifest.json',data:Buffer.from(JSON.stringify(manifest,null,2)+'\n')});
function tarEntry(e){const h=Buffer.alloc(512);assert(Buffer.byteLength(e.name)<100);h.write(e.name,0,100,'utf8');const oct=(off,len,n)=>h.write(n.toString(8).padStart(len-1,'0')+'\0',off,len,'ascii');oct(100,8,0o644);oct(108,8,0);oct(116,8,0);oct(124,12,e.data.length);oct(136,12,0);h.fill(32,148,156);h[156]=48;h.write('ustar\0',257,6);h.write('00',263,2);const sum=h.reduce((a,b)=>a+b,0);h.write(sum.toString(8).padStart(6,'0')+'\0 ',148,8);return [h,e.data,Buffer.alloc((512-e.data.length%512)%512)];}
const raw=Buffer.concat([...entries.flatMap(tarEntry),Buffer.alloc(1024)]),archive=zlib.gzipSync(raw,{level:9});
const archivePath=path.join(own,'recall196-original-browser-r0.tar.gz');fs.writeFileSync(archivePath,archive,{flag:'wx'});
const back=zlib.gunzipSync(fs.readFileSync(archivePath));let off=0,count=0;
while(back[off]){const h=back.subarray(off,off+512);const name=h.subarray(0,100).toString('utf8').split('\0')[0],size=parseInt(h.subarray(124,136).toString().replace(/\0.*$/,''),8),e=entries[count++];assert.equal(name,e.name);assert.deepEqual(back.subarray(off+512,off+512+size),e.data);off+=512+Math.ceil(size/512)*512;}assert.equal(count,entries.length);
for(const e of entries.filter(x=>x.record)){const f=path.join(root,e.record.path),b=fs.readFileSync(f),s=fs.statSync(f);assert.deepEqual(stamp(e.record.path,b,s),e.record);}
const b64=archive.toString('base64').match(/.{1,16384}/g).join('\n')+'\n';
fs.writeFileSync(path.join(own,'recall196-original-browser-r0.tar.gz.b64'),b64,{flag:'wx'});
fs.writeFileSync(path.join(own,'README.md'),readme,{flag:'wx'});
fs.writeFileSync(path.join(own,'custody.json'),entries.find(x=>x.name==='custody.json').data,{flag:'wx'});
fs.writeFileSync(path.join(own,'manifest.json'),entries.find(x=>x.name==='manifest.json').data,{flag:'wx'});
const result={format:'recall196-r0-archive/1',archive:archivePath,bytes:archive.length,sha256:sha(archive),gitBlob:git(archive),mirror:{bytes:Buffer.byteLength(b64),sha256:sha(Buffer.from(b64)),gitBlob:git(Buffer.from(b64)),lines:b64.trimEnd().split('\n').length},members:entries.length,originalFiles:manifest.originalRecords.length,allMembersReadbackVerified:true,allOriginalBytesAndMetadataUnchanged:true};
fs.writeFileSync(path.join(own,'archive-receipt.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
