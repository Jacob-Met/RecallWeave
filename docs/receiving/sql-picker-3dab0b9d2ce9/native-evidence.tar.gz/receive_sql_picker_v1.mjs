#!/usr/bin/env node
// SQL-course receiving of the exact public learner; no application source edits.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, mkdtemp, rm } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const option = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const root = resolve(option('--root', join(here, 'repo')));
const output = resolve(option('--output', join(here, 'receiving-v1')));
const browserPath = option('--browser', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
const sourceManifestPath = resolve(option('--manifest', join(here, 'source-pins.json')));
const sha = value => createHash('sha256').update(value).digest('hex');
const manifestBytes = await readFile(sourceManifestPath);
const manifest = JSON.parse(manifestBytes);
assert.equal(manifest.learner_head, 'd8a9ff81e8e5290e8daad5b4af957d4eddc0ee74');
const sources = Object.entries(manifest.files).filter(([, pin]) => pin.kind === 'runtime');
assert.equal(sources.length, 14);
const coursePath = join(root, 'courses/sql-query-foundations.json');
const courseBytes = await readFile(coursePath);
assert.equal(sha(courseBytes), 'e5fbe1589409876871d1358e6287eb95d2cdd624a5d8da1e1a0a2871801f4512');
const { parseDeck } = await import(pathToFileURL(join(root, 'src/deck.mjs')));
const course = parseDeck(courseBytes.toString('utf8'));
assert.equal(course.items.length, 12);
const byPrompt = new Map(course.items.map(item => [item.prompt, item]));
assert.equal(byPrompt.size, 12);
const missedIds = new Set(['sql-04-null-equals', 'sql-12-left-where']);
const report = {
  status: 'running', learnerHead: manifest.learner_head, learnerTree: manifest.learner_tree,
  courseHead: manifest.course_head, courseSha256: sha(courseBytes),
  sourceManifestSha256: sha(manifestBytes), receiverSha256: sha(await readFile(fileURLToPath(import.meta.url))),
  node: process.version, platform: process.platform, checks: [], surfaces: [], downloads: [], screenshots: [],
  limits: 'Actual file input through DOM.setFileInputFiles; no claim of operating or canceling the OS chooser. Only this authored SQL course and isolated downloaded traces are selected.'
};
async function guard() {
  const actual = {};
  for (const [path, pin] of sources) {
    const bytes = await readFile(join(root, path));
    actual[path] = sha(bytes);
    assert.equal(actual[path], pin.sha256, `source changed: ${path}`);
    assert.equal(createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${bytes.length}\0`), bytes])).digest('hex'), pin.git_blob, path);
  }
  assert.equal(sha(await readFile(fileURLToPath(import.meta.url))), report.receiverSha256);
  return actual;
}
report.before = await guard();
await mkdir(output); // Every run, profile, server, and download belongs exclusively to this receiver.
const downloadsPath = join(output, 'downloads'); await mkdir(downloadsPath);
const profile = await mkdtemp(join(output, 'profile-'));
const assets = new Map(await Promise.all(sources.map(async ([path]) => [path, await readFile(join(root, path))])));
const requests = [], errors = [], downloads = new Map(), pending = new Map();
let browser, socket, sessionId, targetId, sequence = 0, browserLog = '', serverClosed = false;
const sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
const server = createServer((request, response) => {
  const path = decodeURIComponent(new URL(request.url, 'http://localhost').pathname).slice(1) || 'index.html';
  if (!assets.has(path)) { response.writeHead(404).end(); return; }
  const mime = path.endsWith('.html') ? 'text/html' : path.endsWith('.css') ? 'text/css' : path.endsWith('.json') ? 'application/json' : 'text/javascript';
  response.writeHead(200, {'Content-Type': `${mime}; charset=utf-8`, 'Cache-Control': 'no-store'}).end(assets.get(path));
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const base = `http://127.0.0.1:${server.address().port}`;
async function waitFor(check, label) {
  let last;
  for (let attempt = 0; attempt < 120; attempt++) {
    try { if (await check()) return; } catch (error) { last = error; }
    await sleep(80);
  }
  throw new Error(`Timed out: ${label}${last ? ` (${last.message})` : ''}`);
}
function command(method, params = {}, scoped = true) {
  const id = ++sequence;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`CDP timeout: ${method}`)); }, 15000);
    pending.set(id, {resolve, reject, timer});
    socket.send(JSON.stringify({id, method, params, ...(scoped && sessionId ? {sessionId} : {})}));
  });
}
async function evaluate(expression) {
  const result = await command('Runtime.evaluate', {expression, returnByValue: true, awaitPromise: true});
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
  return result.result.value;
}
async function key(name) {
  const code = {Enter: 13, Tab: 9, ' ': 32}[name];
  for (const type of ['keyDown', 'keyUp']) await command('Input.dispatchKeyEvent', {
    type, key: name, code: name === ' ' ? 'Space' : name, windowsVirtualKeyCode: code, nativeVirtualKeyCode: code,
    ...(type === 'keyDown' && name === 'Enter' ? {text: '\r', unmodifiedText: '\r'} : {})
  });
}
async function activate(selector) {
  assert.equal(await evaluate(`(() => {const e=document.querySelector(${JSON.stringify(selector)}); if(!e || e.disabled) return false; e.scrollIntoView({block:'center'}); e.focus(); return document.activeElement === e;})()`), true, `focus ${selector}`);
  await key('Enter');
}
async function openArchive() {
  if (!await evaluate('document.querySelector("#trace-archive-panel").open')) await activate('#trace-archive-panel > summary');
  assert.equal(await evaluate('document.querySelector("#trace-archive-panel").open'), true);
}
async function chooseFile(selector, path) {
  const {root: documentRoot} = await command('DOM.getDocument');
  const {nodeId} = await command('DOM.querySelector', {nodeId: documentRoot.nodeId, selector});
  assert.ok(nodeId, `native file input ${selector}`);
  await command('DOM.setFileInputFiles', {nodeId, files: [path]});
}
async function newDocument(url, width) {
  if (targetId) await command('Target.closeTarget', {targetId}, false);
  ({targetId} = await command('Target.createTarget', {url: 'about:blank'}, false));
  ({sessionId} = await command('Target.attachToTarget', {targetId, flatten: true}, false));
  for (const method of ['Page.enable', 'Runtime.enable', 'Network.enable']) await command(method);
  await command('Network.setCacheDisabled', {cacheDisabled: true});
  await command('Emulation.setDeviceMetricsOverride', {width, height: 1000, deviceScaleFactor: 1, mobile: false});
  await command('Page.navigate', {url});
  await waitFor(() => evaluate(`document.URL === ${JSON.stringify(url)} && !!document.querySelector('#deck-file') && !!document.querySelector('#save-trace-button') && !!document.querySelector('#start-button')`), 'public learner module ready');
}
async function importSql(label, capture = false) {
  const before = await evaluate('document.querySelector("#session-content").innerHTML');
  await chooseFile('#deck-file', coursePath);
  await waitFor(() => evaluate('!!document.querySelector("#start-deck")'), 'SQL file preview');
  const preview = await evaluate(`({title:document.querySelector('#deck-preview-title').textContent,count:document.querySelector('.deck-preview-count').textContent,prompts:[...document.querySelectorAll('#deck-preview ol strong')].map(e=>e.textContent),attribution:document.querySelector('.deck-preview-attribution').textContent,license:document.querySelector('.deck-preview-license').textContent,session:document.querySelector('#session-content').innerHTML,focus:document.activeElement.id})`);
  assert.equal(preview.title, course.title);
  assert.match(preview.count, /sql-query-foundations\.json · 12 questions · 4 concepts$/);
  assert.deepEqual(preview.prompts, course.items.map(item => item.prompt));
  assert.equal(preview.attribution, `Attribution supplied in the deck: ${course.attribution}`);
  assert.equal(preview.license, `License supplied in the deck: ${course.license}`);
  assert.equal(preview.session, before, 'preview must not start or replace the lesson');
  assert.equal(preview.focus, 'deck-preview-title');
  if (capture) await screenshot(`${label}-preview.png`, '#deck-picker-title');
  await activate('#start-deck');
  await waitFor(() => evaluate('!!document.querySelector("[data-choice]")'), 'explicit SQL start');
  assert.equal(await evaluate('document.title'), `${course.title} — RecallWeave`);
  assert.equal(await evaluate('document.querySelector("#lesson-description").textContent'), course.title);
  assert.equal(await evaluate('document.querySelector("#step-count").textContent'), '0 / 12');
  assert.deepEqual(await evaluate('[...document.querySelectorAll("#lesson-map .deck-concept")].map(e=>e.textContent)'), course.concepts);
  assert.equal(await evaluate('document.querySelector("#deck-preview").hidden'), true);
}
async function question(practice = false) {
  const actual = await evaluate(`({prompt:document.querySelector('#session-content h2').textContent,options:[...document.querySelectorAll('${practice ? '[data-practice-choice]' : '[data-choice]'}')].map(e=>({choice:Number(e.dataset.${practice ? 'practiceChoice' : 'choice'}),text:[...e.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>n.textContent).join(''),key:e.querySelector('.choice-key').textContent}))})`);
  const item = byPrompt.get(actual.prompt);
  assert.ok(item, 'rendered question must belong to the exact SQL course');
  assert.equal(actual.options.length, item.options.length);
  assert.deepEqual([...actual.options.map(option => option.choice)].sort((a,b) => a-b), item.options.map((_, index) => index));
  for (const [position, option] of actual.options.entries()) {
    assert.equal(option.text, item.options[option.choice]);
    assert.equal(option.key, String.fromCharCode(65 + position));
  }
  return {item, order: actual.options.map(option => option.choice)};
}
async function answerQuestion(item, choice, practice = false) {
  await activate(`[data-${practice ? 'practice-choice' : 'choice'}="${choice}"]`);
  await waitFor(() => evaluate(`!!document.querySelector('${practice ? '#practice-next' : '#next-button'}')`), 'answer feedback');
  const feedback = await evaluate(`document.querySelector('${practice ? '#practice-feedback' : '#feedback-slot'} .feedback').textContent`);
  assert.ok(feedback.includes(item.explanation), item.id + ' exact explanation');
  assert.ok(feedback.includes(item.transfer), item.id + ' exact transfer');
  const correctChoice = await evaluate(`Number(document.querySelector('${practice ? '[data-practice-choice]' : '[data-choice]'}.correct').dataset.${practice ? 'practiceChoice' : 'choice'})`);
  assert.equal(correctChoice, item.answer, 'canonical answer survives display shuffling');
}
async function reviewSnapshot() {
  return evaluate(`({summary:document.querySelector('#first-try-summary').textContent,mastery:[...document.querySelectorAll('.mastery-row')].map(e=>e.textContent),rows:[...document.querySelectorAll('.review-item')].map(e=>({prompt:e.querySelector('.review-prompt').textContent,first:e.querySelector('.review-answers dd').textContent,correct:e.querySelectorAll('.review-answers dd')[1].textContent,explanation:e.querySelector('.review-body > p').textContent,transfer:e.querySelector('.review-transfer').textContent})),attribution:document.querySelector('.source-note').textContent})`);
}
function verifyReview(snapshot, firstAnswers) {
  assert.match(snapshot.summary, /10 of 12 connections on the first try/);
  assert.equal(snapshot.rows.length, 12);
  for (const [index, answer] of firstAnswers.entries()) {
    const item = course.items.find(item => item.id === answer.item), row = snapshot.rows[index];
    assert.equal(row.prompt, item.prompt); assert.equal(row.first, item.options[answer.choice]);
    assert.equal(row.correct, item.options[item.answer]); assert.equal(row.explanation, item.explanation);
    assert.equal(row.transfer, `Apply the idea: ${item.transfer}`);
  }
  assert.ok(snapshot.attribution.includes(course.attribution));
  assert.ok(snapshot.attribution.includes(course.license));
}
async function download(selector, name, kind) {
  const before = new Set(downloads.keys());
  await activate(selector);
  let completed;
  await waitFor(() => { completed = [...downloads.values()].find(value => !before.has(value.guid) && value.state === 'completed'); return !!completed; }, `physical ${kind} download`);
  assert.match(completed.suggestedFilename, kind === 'trace' ? /^recallweave-learning-trace-\d{4}-\d{2}-\d{2}\.json$/ : /^recallweave-study-notes-\d{4}-\d{2}-\d{2}\.txt$/);
  const path = join(downloadsPath, completed.guid), bytes = await readFile(path);
  await writeFile(join(output, name), bytes, {flag: 'wx'});
  report.downloads.push({name, nativePath: path, suggestedFilename: completed.suggestedFilename, sha256: sha(bytes), bytes: bytes.length});
  return {path, bytes, value: kind === 'trace' ? JSON.parse(bytes) : bytes.toString('utf8')};
}
function verifyNotes(text, firstAnswers, practiceAnswers) {
  assert.ok(text.includes(course.title)); assert.ok(text.includes('10 of 12 connections correct on the first try.'));
  assert.ok(text.includes(course.attribution)); assert.ok(text.includes(course.license));
  assert.equal((text.match(/^\d+\. /gm) ?? []).length, 12);
  const sections = text.split(/\n\d+\. /).slice(1);
  for (const [index, answer] of firstAnswers.entries()) {
    const item = course.items.find(item => item.id === answer.item), section = sections[index];
    assert.ok(section.startsWith(item.prompt + '\n'));
    for (const field of [`Your first answer: ${item.options[answer.choice]}\n`, `Correct answer: ${item.options[item.answer]}\n`, `Explanation: ${item.explanation}\n`, `Apply the idea: ${item.transfer}\n`]) assert.ok(section.includes(field), item.id + ' notes field');
    const retry = practiceAnswers.find(value => value.item === item.id);
    if (retry) assert.ok(section.includes(`Practice answer: ${item.options[retry.choice]}\n`));
    else if (missedIds.has(item.id)) assert.ok(section.includes('Practice answer: not recorded.\n'));
  }
}
async function screenshot(name, selector) {
  await evaluate(`document.querySelector(${JSON.stringify(selector)}).scrollIntoView({block:'start'})`);
  assert.equal(await evaluate('document.documentElement.scrollWidth > innerWidth'), false, 'document must fit viewport');
  const {data} = await command('Page.captureScreenshot', {format: 'png', captureBeyondViewport: false});
  const bytes = Buffer.from(data, 'base64'); await writeFile(join(output, name), bytes, {flag: 'wx'});
  report.screenshots.push({name, sha256: sha(bytes), bytes: bytes.length});
}
function passed(name) { report.checks.push(name); console.log('PASS ' + name); }
async function receiveSurface(name, url, width) {
  await newDocument(url, width);
  await importSql(name, true);
  passed(`${name}: exact local file preview and explicit twelve-question course start`);
  const firstAnswers = [], displayedOrders = [], seen = new Set();
  for (let index = 0; index < 12; index++) {
    const {item, order} = await question(); assert.ok(!seen.has(item.id)); seen.add(item.id);
    const choice = missedIds.has(item.id) ? (item.answer + 1) % item.options.length : item.answer;
    await answerQuestion(item, choice);
    firstAnswers.push({item: item.id, choice}); displayedOrders.push({item: item.id, order});
    assert.equal(await evaluate('document.querySelector("#step-count").textContent'), `${index + 1} / 12`);
    await activate('#next-button');
  }
  assert.deepEqual([...seen].sort(), course.items.map(item => item.id).sort());
  assert.ok(displayedOrders.some(value => value.order.some((choice, index) => choice !== index)), 'receiving must actually encounter shuffled display positions');
  await waitFor(() => evaluate('!!document.querySelector("#first-try-summary")'), 'complete SQL session');
  const initialReview = await reviewSnapshot(); verifyReview(initialReview, firstAnswers);
  passed(`${name}: all twelve canonical first answers, complete review, supplied attribution and shuffled display mapping`);
  await activate('#practice-button');
  const {item: practiceItem, order: firstPracticeOrder} = await question(true);
  assert.ok(missedIds.has(practiceItem.id));
  const practiceAnswers = [{item: practiceItem.id, choice: practiceItem.answer}];
  await answerQuestion(practiceItem, practiceItem.answer, true);
  await activate('#back-to-review');
  assert.equal(await evaluate('document.querySelector("#practice-status").textContent'), 'Practice paused: 1 of 2 answered. Resume with the next unanswered prompt.');
  assert.deepEqual(await reviewSnapshot(), initialReview, 'practice preserves original review and estimates');
  const pausedNotes = await download('#save-notes-button', `${name}-paused-notes.txt`, 'notes');
  verifyNotes(pausedNotes.value, firstAnswers, practiceAnswers);
  assert.ok(pausedNotes.value.includes('Paused: 1 of 2 practice answers recorded; 1 correct on retry.'));
  await openArchive();
  const pausedTrace = await download('#save-trace-button', `${name}-paused-trace.json`, 'trace');
  assert.deepEqual(pausedTrace.value.deck, course);
  assert.deepEqual(pausedTrace.value.firstAnswers, firstAnswers);
  assert.deepEqual(pausedTrace.value.practice, {answers: practiceAnswers});
  assert.deepEqual(Object.keys(pausedTrace.value.mastery).sort(), [...course.concepts].sort());
  assert.ok(Object.values(pausedTrace.value.mastery).every(value => Number.isFinite(value) && value >= 0 && value <= 1));
  passed(`${name}: physical SQL notes and completed-first-session trace preserve separately paused practice`);

  // A fresh document starts with the bundled course; a saved SQL trace must not switch it.
  await newDocument(url, width);
  await openArchive();
  await chooseFile('#trace-file', pausedTrace.path);
  await waitFor(() => evaluate('document.querySelector("#trace-restore-status").textContent.includes("different course")'), 'SQL trace refused against bundled course');
  assert.equal(await evaluate('document.querySelector("#trace-preview").hidden'), true);
  assert.equal(await evaluate('document.querySelector("#step-count").textContent'), '0 / 6');
  await importSql(name + '-fresh');
  const preRestorePrompt = await evaluate('document.querySelector("#session-content h2").textContent');
  await openArchive(); await chooseFile('#trace-file', pausedTrace.path);
  await waitFor(() => evaluate('!document.querySelector("#trace-preview").hidden'), 'same exact SQL course trace preview');
  assert.equal(await evaluate('document.querySelector("#session-content h2").textContent'), preRestorePrompt);
  assert.equal(await evaluate('document.querySelector("#step-count").textContent'), '0 / 12');
  const tracePreview = await evaluate('document.querySelector("#trace-preview-summary").textContent');
  assert.ok(tracePreview.startsWith(course.title + ' — saved '));
  assert.ok(tracePreview.includes('First try: 10 of 12 connections correct. Practice: 1 of 2 answers recorded.'));
  await activate('#restore-trace-confirm');
  await waitFor(() => evaluate('document.querySelector("#trace-restore-status").textContent.startsWith("Trace restored." )'), 'explicit saved SQL trace restore');
  assert.deepEqual(await reviewSnapshot(), initialReview);
  assert.equal(await evaluate('document.querySelector("#practice-status").textContent'), 'Practice paused: 1 of 2 answered. Resume with the next unanswered prompt.');
  passed(`${name}: fresh document refuses wrong-course restore then explicitly restores exact SQL answers and paused practice`);
  await activate('#practice-button');
  const {item: remaining, order: resumedOrder} = await question(true);
  assert.ok(missedIds.has(remaining.id)); assert.notEqual(remaining.id, practiceItem.id);
  practiceAnswers.push({item: remaining.id, choice: remaining.answer});
  await answerQuestion(remaining, remaining.answer, true); await activate('#practice-next');
  assert.equal(await evaluate('document.querySelector("#practice-status").textContent'), 'You answered 2 of 2 correctly on retry.');
  assert.deepEqual(await reviewSnapshot(), initialReview);
  const finalNotes = await download('#save-notes-button', `${name}-restored-notes.txt`, 'notes');
  verifyNotes(finalNotes.value, firstAnswers, practiceAnswers);
  assert.ok(finalNotes.value.includes('Complete: 2 of 2 practice answers recorded; 2 correct on retry.'));
  await openArchive();
  const finalTrace = await download('#save-trace-button', `${name}-restored-trace.json`, 'trace');
  assert.deepEqual(finalTrace.value.deck, pausedTrace.value.deck);
  assert.deepEqual(finalTrace.value.firstAnswers, firstAnswers);
  assert.deepEqual(finalTrace.value.mastery, pausedTrace.value.mastery, 'full precision estimates survive restore and practice');
  assert.deepEqual(finalTrace.value.practice, {answers: practiceAnswers});
  await screenshot(`${name}-restored-review.png`, '#session-content');
  report.surfaces.push({name, url, width, firstAnswers, displayedOrders, practiceAnswers, firstPracticeOrder, resumedOrder, mastery: finalTrace.value.mastery});
  passed(`${name}: resumed remaining retry and fresh physical exports retain all original SQL first answers and full precision estimates`);
}
async function closeServer() {
  if (serverClosed) return;
  server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); serverClosed = true;
}
function waitForBrowserExit(milliseconds) {
  if (!browser || browser.exitCode !== null || browser.signalCode !== null) return Promise.resolve(true);
  return new Promise(resolve => {
    const finish = () => { clearTimeout(timer); browser.off('exit', finish); resolve(true); };
    const timer = setTimeout(() => { browser.off('exit', finish); resolve(false); }, milliseconds);
    browser.once('exit', finish);
  });
}
try {
  browser = spawn(browserPath, ['--headless=new', '--disable-gpu', '--disable-background-networking', '--disable-component-update', '--disable-sync', '--disable-extensions', '--password-store=basic', '--no-first-run', '--no-default-browser-check', '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', `--user-data-dir=${profile}`, 'about:blank'], {stdio: ['ignore', 'ignore', 'pipe']});
  browser.stderr.on('data', bytes => { browserLog += bytes.toString(); });
  const endpoint = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Browser startup timeout: ${browserLog.slice(-3000)}`)), 45000);
    browser.once('error', error => {clearTimeout(timer); reject(error);});
    browser.once('exit', code => {clearTimeout(timer); reject(new Error(`Browser exited during startup: ${code}`));});
    browser.stderr.on('data', () => {const found = browserLog.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/); if(found){clearTimeout(timer);resolve(found[1]);}});
  });
  socket = new WebSocket(endpoint);
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id) {
      const request = pending.get(message.id); if (!request) return;
      pending.delete(message.id); clearTimeout(request.timer);
      if (message.error) request.reject(new Error(message.error.message)); else request.resolve(message.result);
    } else if (message.method === 'Browser.downloadWillBegin' || message.method === 'Browser.downloadProgress') {
      const value = message.params; downloads.set(value.guid, {...downloads.get(value.guid), ...value});
    } else if (message.method === 'Runtime.exceptionThrown') errors.push(message.params.exceptionDetails.exception?.description ?? message.params.exceptionDetails.text);
    else if (message.method === 'Network.requestWillBeSent') requests.push(message.params.request.url);
  });
  await new Promise((resolve, reject) => {socket.addEventListener('open', resolve, {once:true});socket.addEventListener('error', reject, {once:true});});
  report.browser = await command('Browser.getVersion', {}, false);
  await command('Browser.setDownloadBehavior', {behavior: 'allowAndName', downloadPath: downloadsPath, eventsEnabled: true}, false);
  await receiveSurface('modular', base + '/index.html', 1280);
  await closeServer();
  await receiveSurface('standalone', pathToFileURL(join(root, 'demo.html')).href, 390);
  assert.deepEqual(errors, []);
  const externalRequests = requests.filter(url => !url.startsWith(base + '/') && !url.startsWith('file:') && !url.startsWith('blob:') && url !== 'about:blank');
  assert.deepEqual(externalRequests, []);
  report.pageErrors = errors; report.pageRequests = requests; report.serverClosedBeforeStandalone = serverClosed;
  report.status = 'passed';
} catch (error) {
  report.status = 'failed'; report.error = error.stack; report.pageErrors = errors; report.pageRequests = requests;
  console.error(error.stack);
} finally {
  if (socket?.readyState === WebSocket.OPEN) {
    try { await command('Browser.close', {}, false); } catch (error) { report.browserCloseMessage = error.message; }
    socket.close();
  }
  for (const request of pending.values()) clearTimeout(request.timer);
  pending.clear();
  if (!await waitForBrowserExit(4000)) {browser.kill('SIGTERM'); await waitForBrowserExit(2000);}
  if (browser?.exitCode === null && browser?.signalCode === null) {browser.kill('SIGKILL'); await waitForBrowserExit(2000);}
  report.browserExit = {code: browser?.exitCode, signal: browser?.signalCode};
  await closeServer();
  if (browser?.exitCode !== null || browser?.signalCode !== null) {
    try {await rm(profile, {recursive: true, force: true, maxRetries: 3, retryDelay: 100});report.profileRemoved = true;}
    catch (error) {report.status = 'failed';report.cleanupError = error.message;}
  } else {report.status = 'failed';report.cleanupError = 'Owned browser did not exit; profile retained.';}
  try {report.after = await guard();} catch (error) {report.status = 'failed';report.guardError = error.message;}
  await writeFile(join(output, 'browser.stderr'), browserLog, {flag:'wx'});
  await writeFile(join(output, 'receiving.json'), JSON.stringify(report, null, 2) + '\n', {flag:'wx'});
}
console.log(`SQL_PICKER_${report.status === 'passed' ? 'OK' : 'FAILED'} checks=${report.checks.length} failures=${report.status === 'passed' ? 0 : 1}`);
process.exitCode = report.status === 'passed' ? 0 : 1;
