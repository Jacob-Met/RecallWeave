import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import puppeteer from '/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
import {receiveLearner} from './receive-course-learner.mjs';

const input=process.env.LEARNER_RECEIVING_INPUT;
const output=process.env.LEARNER_RECEIVING_OUTPUT;
const expectedManifest=process.env.LEARNER_INPUT_MANIFEST_SHA256;
const courseFile='/Users/me/hamon-recall-units-receiving-cd1df0f1ee24/run-v2-01/downloads/units-lesson/units-and-dimensions.json';
assert.ok(input&&output&&expectedManifest);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
await fs.mkdir(output,{recursive:false});
await fs.mkdir(join(output,'downloads'),{recursive:false});
const profile=output+'-profile';
const result={schema:'hamon.recallweave.units.current-learner-receiving.v1',startedAt:new Date().toISOString(),head:'e49aee89dc6ecf579f1c9152f32f826bf6f9d8b7',tree:'2a9cfa00c9a3f18ffa834335abb609c1cd7cc989',sourceManifestSHA256:expectedManifest,route:'direct-file current demo; original explorer-downloaded course selected through native chooser',blockedNetwork:[],pageErrors:[],consoleErrors:[],downloads:[],environment:{node:process.version,platform:process.platform,architecture:process.arch}};
let browser,page;
async function verify(){
 const raw=await fs.readFile(join(input,'input-manifest.json'));
 assert.equal(sha(raw),expectedManifest);
 const manifest=JSON.parse(raw);
 for(const item of manifest.files){
  const b=await fs.readFile(join(input,item.path));
  assert.equal(b.length,item.bytes,item.path);
  assert.equal(sha(b),item.sha256,item.path);
 }
 const course=await fs.readFile(courseFile);
 assert.equal(course.length,13008);
 assert.equal(sha(course),'df0c8c8ba1f0061bbc73bcad0e9a62b257341b4bd5d6a7adbd6824820a02128e');
 return {manifest,originalDownloadedCourse:{path:courseFile,bytes:course.length,sha256:sha(course)}};
}
async function download(p,selector,name){
 const directory=join(output,'downloads',name);
 await fs.mkdir(directory,{recursive:false});
 const cdp=await p.createCDPSession();
 try{
  await cdp.send('Page.setDownloadBehavior',{behavior:'allow',downloadPath:directory});
  await p.click(selector);
  let filename;
  const deadline=Date.now()+8000;
  while(Date.now()<deadline){
   const files=await fs.readdir(directory);
   if(files.length===1&&!files[0].endsWith('.crdownload')&&!files[0].endsWith('.tmp')){filename=files[0];break;}
   await new Promise(resolve=>setTimeout(resolve,50));
  }
  assert.ok(filename,'actual completed notes download: '+name);
  const path=join(directory,filename),b=await fs.readFile(path);
  const file={path,name:filename,bytes:b.length,sha256:sha(b),text:b.toString('utf8')};
  result.downloads.push({kind:name,path:path.slice(output.length+1),name:filename,bytes:b.length,sha256:file.sha256});
  await p.$eval('#first-try-summary',node=>node.scrollIntoView({block:'start'}));
  return file;
 }finally{await cdp.detach();}
}
try{
 result.sourceBefore=await verify();
 const course=JSON.parse(await fs.readFile(courseFile,'utf8'));
 const blindSolutions=JSON.parse(await fs.readFile(join(input,'receiver/solutions-before-key-v1.json'),'utf8'));
 browser=await puppeteer.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,userDataDir:profile,args:['--no-first-run','--no-default-browser-check','--disable-background-networking'],defaultViewport:{width:1280,height:900,deviceScaleFactor:1}});
 result.environment.browser=await browser.version();
 page=await browser.newPage(); await page.setRequestInterception(true);
 page.on('request',request=>{
  if(/^https?:/i.test(request.url())){result.blockedNetwork.push(request.url());request.abort('internetdisconnected').catch(()=>{});}
  else request.continue().catch(()=>{});
 });
 page.on('pageerror',error=>result.pageErrors.push(String(error.stack||error)));
 page.on('console',message=>{if(message.type()==='error')result.consoleErrors.push(message.text());});
 result.learner=await receiveLearner(page,{source:join(input,'source'),courseFile,course,blindSolutions,output,download});
 assert.deepEqual(result.blockedNetwork,[]);
 assert.deepEqual(result.pageErrors,[]);
 assert.deepEqual(result.consoleErrors,[]);
 result.passed=true;
}catch(error){
 result.passed=false;result.error=String(error.stack||error);
 if(page){try{await page.screenshot({path:join(output,'failure.png'),fullPage:false});}catch(captureError){result.captureError=String(captureError);}}
}finally{
 try{result.sourceAfter=await verify();assert.deepEqual(result.sourceAfter,result.sourceBefore);}
 catch(error){result.passed=false;result.sourceAfterError=String(error.stack||error);}
 if(browser)await browser.close();
 await fs.rm(profile,{recursive:true,force:true});
 result.finishedAt=new Date().toISOString();
 await fs.writeFile(join(output,'current-learner-receiving.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({passed:result.passed,head:result.head,firstAnswers:result.learner?.firstAnswers?.length||0,practiceAnswers:result.learner?.practiceAnswers?.length||0,downloads:result.downloads.length,output,error:result.error||null}));
 process.exitCode=result.passed?0:1;
}
