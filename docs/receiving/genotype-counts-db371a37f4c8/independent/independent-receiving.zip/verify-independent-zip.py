import pathlib,json,zipfile,hashlib,sys
r=pathlib.Path(sys.argv[1]);d=r/'independent-sealed';m=json.loads((d/'SEALED-MANIFEST.json').read_text(encoding='utf-8'))
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest(),'mtime_ns':str(p.stat().st_mtime_ns)}
with zipfile.ZipFile(d/'independent-receiving.zip') as z:
 infos=z.infolist();names=[i.filename for i in infos]
 assert len(names)==len(m['files'])+1 and len(set(x.lower() for x in names))==len(names)
 assert set(names)==set(f['path'] for f in m['files'])|{'SEALED-MANIFEST.json'}
 assert z.read('SEALED-MANIFEST.json')==(d/'SEALED-MANIFEST.json').read_bytes()
 for f in m['files']:
  n=f['path'];p=pathlib.PurePosixPath(n);assert not p.is_absolute() and all(x not in ('','..','.') for x in p.parts) and '\\' not in n and ':' not in n
  info=z.getinfo(n);assert not info.is_dir() and ((info.external_attr>>16)&0o170000)==0o100000
  b=z.read(n);assert b==(r/n).read_bytes()
  assert pin(r/n)=={k:f[k] for k in ['bytes','sha256','git','mtime_ns']}
print(json.dumps({'status':'passed','payloads':len(m['files']),'members':len(infos),'allMemberBytesAndNativeStatsExact':True,'archive':pin(d/'independent-receiving.zip')}))
