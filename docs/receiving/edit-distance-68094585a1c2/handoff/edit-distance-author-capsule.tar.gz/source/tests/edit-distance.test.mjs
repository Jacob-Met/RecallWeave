import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {POLICY, EXAMPLES, analyzeEditDistance} from '../courses/edit-distance-core.mjs';
import {parseDeck, serializeDeck} from '../src/deck.mjs';
import {initialMastery, selectNextItem, updateMastery} from '../src/knowledge.mjs';
import {createReview, beginPractice, currentPracticeItem, answerPractice} from '../src/review.mjs';
import {createStudyNotes} from '../src/session-export.mjs';

const root = new URL('../', import.meta.url);
const deckText = await readFile(new URL('courses/edit-distance.json', root), 'utf8');
const deck = parseDeck(deckText);
// Manually reasoned examples frozen before implementation in the author public contract.
const manualExamples = [
  {
    "source": "",
    "target": "",
    "distance": 0,
    "pathCount": "1",
    "matrix": [
      [
        0
      ]
    ],
    "operations": []
  },
  {
    "source": "",
    "target": "ABC",
    "distance": 3,
    "pathCount": "1",
    "matrix": [
      [
        0,
        1,
        2,
        3
      ]
    ],
    "operations": [
      "insert",
      "insert",
      "insert"
    ]
  },
  {
    "source": "ABC",
    "target": "",
    "distance": 3,
    "pathCount": "1",
    "matrix": [
      [
        0
      ],
      [
        1
      ],
      [
        2
      ],
      [
        3
      ]
    ],
    "operations": [
      "delete",
      "delete",
      "delete"
    ]
  },
  {
    "source": "KITTEN",
    "target": "SITTING",
    "distance": 3,
    "operations": [
      "substitute",
      "match",
      "match",
      "match",
      "substitute",
      "match",
      "insert"
    ],
    "note": "Path count deliberately not frozen from an unproved mental calculation."
  },
  {
    "source": "AB",
    "target": "BA",
    "distance": 2,
    "pathCount": "3",
    "matrix": [
      [
        0,
        1,
        2
      ],
      [
        1,
        1,
        1
      ],
      [
        2,
        1,
        2
      ]
    ],
    "operations": [
      "substitute",
      "substitute"
    ]
  },
  {
    "source": "AA",
    "target": "A",
    "distance": 1,
    "pathCount": "2",
    "matrix": [
      [
        0,
        1
      ],
      [
        1,
        0
      ],
      [
        2,
        1
      ]
    ],
    "operations": [
      "delete",
      "match"
    ]
  },
  {
    "source": "A",
    "target": "AA",
    "distance": 1,
    "pathCount": "2",
    "matrix": [
      [
        0,
        1,
        2
      ],
      [
        1,
        0,
        1
      ]
    ],
    "operations": [
      "insert",
      "match"
    ]
  },
  {
    "source": "ABC",
    "target": "AC",
    "distance": 1,
    "pathCount": "1",
    "matrix": [
      [
        0,
        1,
        2
      ],
      [
        1,
        0,
        1
      ],
      [
        2,
        1,
        1
      ],
      [
        3,
        2,
        1
      ]
    ],
    "operations": [
      "match",
      "delete",
      "match"
    ]
  },
  {
    "source": "é",
    "target": "é",
    "distance": 2,
    "pathCount": "2",
    "matrix": [
      [
        0,
        1,
        2
      ],
      [
        1,
        1,
        2
      ]
    ],
    "operations": [
      "insert",
      "substitute"
    ],
    "note": "Canonical alignment inserts U+0065, then substitutes U+00E9 with U+0301."
  },
  {
    "source": "👩‍🔬",
    "target": "👩",
    "distance": 2,
    "pathCount": "1",
    "operations": [
      "match",
      "delete",
      "delete"
    ],
    "note": "Three source code points: U+1F469, U+200D, U+1F52C."
  },
  {
    "source": "cat",
    "target": "Cat",
    "distance": 1,
    "pathCount": "1",
    "operations": [
      "substitute",
      "match",
      "match"
    ]
  },
  {
    "source": " A",
    "target": "A ",
    "distance": 2,
    "pathCount": "3",
    "operations": [
      "substitute",
      "substitute"
    ]
  },
  {
    "source": "AAAAAAAAAAAAAAAAAAAAAAAA",
    "target": "",
    "distance": 24,
    "pathCount": "1",
    "operations": [
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete",
      "delete"
    ]
  }
];

/** Independent exhaustive path enumeration: no dynamic-programming table or memoization. */
function enumeratePaths(a, b) {
  let minimum = Infinity, count = 0n, canonical = null;
  const path = [];
  function precedesFromEnd(candidate, earlier) {
    for (let x = candidate.length - 1, y = earlier.length - 1; x >= 0 && y >= 0; x--, y--) {
      if (candidate[x] !== earlier[y]) return candidate[x] < earlier[y];
    }
    return candidate.length < earlier.length;
  }
  function visit(i, j, cost) {
    if (i === a.length && j === b.length) {
      if (cost < minimum) { minimum = cost; count = 1n; canonical = [...path]; }
      else if (cost === minimum) {
        count++;
        if (precedesFromEnd(path, canonical)) canonical = [...path];
      }
      return;
    }
    // Traverse forward in a different order from the product's backtrace.
    if (j < b.length) { path.push(2); visit(i, j + 1, cost + 1); path.pop(); }
    if (i < a.length) { path.push(1); visit(i + 1, j, cost + 1); path.pop(); }
    if (i < a.length && j < b.length) { path.push(0); visit(i + 1, j + 1, cost + (a[i] === b[j] ? 0 : 1)); path.pop(); }
  }
  visit(0, 0, 0);
  return {distance: minimum, count: count.toString(), canonical};
}

function replay(result) {
  let i = 0, j = 0, cost = 0, produced = '';
  for (const [index, step] of result.alignment.entries()) {
    assert.equal(step.step, index + 1);
    assert.deepEqual(step.from, [i, j]);
    if (step.operation === 'insert') {
      assert.equal(step.source, null); assert.equal(step.sourceIndex, null);
      assert.equal(step.target, result.targetPoints[j]); assert.equal(step.targetIndex, j);
      assert.equal(step.cost, 1); produced += step.target; j++;
    } else if (step.operation === 'delete') {
      assert.equal(step.source, result.sourcePoints[i]); assert.equal(step.sourceIndex, i);
      assert.equal(step.target, null); assert.equal(step.targetIndex, null);
      assert.equal(step.cost, 1); i++;
    } else {
      assert.ok(['match', 'substitute'].includes(step.operation));
      assert.equal(step.source, result.sourcePoints[i]); assert.equal(step.sourceIndex, i);
      assert.equal(step.target, result.targetPoints[j]); assert.equal(step.targetIndex, j);
      assert.equal(step.operation, step.source === step.target ? 'match' : 'substitute');
      assert.equal(step.cost, step.source === step.target ? 0 : 1);
      produced += step.target; i++; j++;
    }
    cost += step.cost;
    assert.deepEqual(step.to, [i, j]);
  }
  assert.deepEqual([i, j], [result.sourcePoints.length, result.targetPoints.length]);
  assert.equal(produced, result.target);
  assert.equal(cost, result.distance);
}

test('all thirteen pre-implementation manual examples retain distance, full named tables and canonical operations', () => {
  for (const fixture of manualExamples) {
    const result = analyzeEditDistance(fixture.source, fixture.target);
    assert.equal(result.distance, fixture.distance, JSON.stringify(fixture));
    if (fixture.pathCount) assert.equal(result.optimalPathCount, fixture.pathCount);
    if (fixture.matrix) assert.deepEqual(result.matrix, fixture.matrix);
    assert.deepEqual(result.alignment.map(step => step.operation), fixture.operations);
    replay(result);
  }
});

test('961 binary-string pairs agree with independent complete path enumeration, including every prefix and canonical tie', () => {
  const strings = [''];
  for (let length = 1; length <= 4; length++) {
    for (let value = 0; value < 2 ** length; value++) strings.push(value.toString(2).padStart(length, '0'));
  }
  const references = new Map();
  for (const a of strings) for (const b of strings) references.set(JSON.stringify([a, b]), enumeratePaths([...a], [...b]));
  let comparisons = 0;
  for (const a of strings) for (const b of strings) {
    const result = analyzeEditDistance(a, b), expected = references.get(JSON.stringify([a, b]));
    assert.equal(result.distance, expected.distance, JSON.stringify([a, b]));
    assert.equal(result.optimalPathCount, expected.count);
    assert.deepEqual(result.alignment.map(step => step.operation === 'delete' ? 1 : step.operation === 'insert' ? 2 : 0), expected.canonical);
    for (let i = 0; i <= a.length; i++) for (let j = 0; j <= b.length; j++) {
      const prefix = references.get(JSON.stringify([a.slice(0, i), b.slice(0, j)]));
      assert.equal(result.matrix[i][j], prefix.distance);
      assert.equal(result.cells[i][j].cost, prefix.distance);
      assert.equal(result.cells[i][j].optimalPathCount, prefix.count);
    }
    replay(result); comparisons++;
  }
  assert.equal(comparisons, 961);
});

test('the selected AB/BA cell retains all three true ties and exact predecessor evidence', () => {
  assert.deepEqual(analyzeEditDistance('AB', 'BA').cells[2][2], {
    i: 2, j: 2, cost: 2, optimalPathCount: '3',
    candidates: [
      {operation: 'substitute', from: [1, 1], stepCost: 1, totalCost: 2, optimal: true},
      {operation: 'delete', from: [1, 2], stepCost: 1, totalCost: 2, optimal: true},
      {operation: 'insert', from: [2, 1], stepCost: 1, totalCost: 2, optimal: true}
    ]
  });
  assert.deepEqual(analyzeEditDistance('', '').cells[0][0], {i: 0, j: 0, cost: 0, optimalPathCount: '1', candidates: []});
});

test('representation is literal over code points, including whitespace, astral text and combining marks', () => {
  for (const value of [' A ', '<b>&"😀', '\tA\r\n', 'é', 'e\u0301', '👩‍🔬', '-']) {
    const result = analyzeEditDistance(value, value);
    assert.equal(result.source, value); assert.equal(result.target, value);
    assert.equal(result.distance, 0); assert.equal(result.optimalPathCount, '1');
    assert.deepEqual(result.sourcePoints, [...value]);
    assert.deepEqual(JSON.parse(JSON.stringify(result)), result);
    replay(result);
  }
  assert.deepEqual(analyzeEditDistance('👩‍🔬', '👩').sourcePoints.map(p => p.codePointAt(0)), [0x1f469, 0x200d, 0x1f52c]);
  assert.equal(analyzeEditDistance('cat', 'Cat').distance, 1);
  assert.equal(analyzeEditDistance('é', 'e\u0301').distance, 2);
});

test('the 24-code-point limit admits supplementary characters and rejects oversized or malformed text before a result', () => {
  assert.equal(analyzeEditDistance('😀'.repeat(24), '').distance, 24);
  assert.equal(analyzeEditDistance('', '😀'.repeat(24)).targetPoints.length, 24);
  for (const value of ['A'.repeat(25), '😀'.repeat(25)]) {
    assert.throws(() => analyzeEditDistance(value, ''), RangeError);
    assert.throws(() => analyzeEditDistance('', value), RangeError);
  }
  for (const value of [null, undefined, 12, {}, [], new String('A')]) {
    assert.throws(() => analyzeEditDistance(value, ''), TypeError);
    assert.throws(() => analyzeEditDistance('', value), TypeError);
  }
  for (const value of [String.fromCharCode(0xd800), String.fromCharCode(0xdc00), 'A' + String.fromCharCode(0xd800) + 'B']) {
    assert.throws(() => analyzeEditDistance(value, ''), TypeError);
    assert.throws(() => analyzeEditDistance('', value), TypeError);
  }
});

test('downloadable result fields and policy are detached from subsequent calculations and immutable examples', () => {
  const before = JSON.stringify(EXAMPLES);
  const result = analyzeEditDistance('AA', 'A');
  assert.deepEqual(Object.keys(result), ['format', 'policy', 'source', 'target', 'sourcePoints', 'targetPoints', 'distance', 'optimalPathCount', 'matrix', 'cells', 'alignment']);
  assert.equal(result.format, 'recallweave-edit-distance/1');
  assert.deepEqual(result.policy.costs, {match: 0, insert: 1, delete: 1, substitute: 1});
  result.policy.costs.delete = 88; result.policy.tieOrder.reverse(); result.matrix[2][1] = 99; result.sourcePoints[0] = 'X';
  assert.equal(POLICY.costs.delete, 1);
  assert.deepEqual(POLICY.tieOrder, ['diagonal', 'delete', 'insert']);
  assert.equal(analyzeEditDistance('AA', 'A').distance, 1);
  assert.equal(JSON.stringify(EXAMPLES), before);
});

test('the original fourteen-question course is canonical, referenced, complete and independent of experiments', () => {
  assert.equal(serializeDeck(deck), deckText);
  assert.equal(deck.items.length, 14);
  assert.deepEqual(deck.concepts, ['Allowed edits', 'Prefix subproblems', 'Alignments and ties', 'Representation and limits']);
  assert.deepEqual([0, 1, 2, 3].map(answer => deck.items.filter(item => item.answer === answer).length), [4, 3, 4, 3]);
  assert.ok(deck.items.every(item => item.explanation.length > 180 && item.transfer.length > 80));
  assert.match(deck.attribution, /Original questions/);
  assert.match(deck.attribution, /10\.1145\/321796\.321811/);
  assert.match(deck.license, /CC BY 4\.0/);
});

test('the course completes unchanged native adaptive selection, review, separate practice and complete notes export', () => {
  const asked = new Set(), mastery = initialMastery(deck.concepts), answers = [];
  for (let index = 0; index < deck.items.length; index++) {
    const item = selectNextItem(deck.items, asked, mastery);
    assert.ok(item);
    const choice = [0, 5, 9].includes(index) ? (item.answer + 1) % item.options.length : item.answer;
    answers.push({item: item.id, choice}); asked.add(item.id);
    mastery[item.concept] = updateMastery(mastery[item.concept], choice === item.answer);
  }
  assert.equal(selectNextItem(deck.items, asked, mastery), null);
  const review = createReview(deck.items, answers);
  const original = JSON.stringify({review, mastery, answers});
  let practice = beginPractice(review);
  assert.equal(practice.items.length, 3);
  for (let index = 0; index < 2; index++) {
    const item = currentPracticeItem(practice);
    practice = answerPractice(practice, item.id, item.answer);
  }
  const notes = createStudyNotes({deck, review, mastery, practice, exportedAt: new Date('2026-10-08T00:00:00Z')}).text;
  assert.match(notes, /11 of 14 connections correct on the first try/);
  assert.match(notes, /Paused: 2 of 3 practice answers recorded; 2 correct on retry/);
  assert.ok(deck.items.every(item => notes.includes(item.prompt) && notes.includes(item.explanation)));
  assert.ok(notes.includes(deck.attribution));
  assert.equal(JSON.stringify({review, mastery, answers}), original);
});

test('the generated direct-file page contains the exact fixed course and maintained model/UI with no external dependency', async () => {
  const result = execFileSync(process.execPath, [fileURLToPath(new URL('tools/build_edit_distance_explorer.mjs', root)), '--check'], {encoding: 'utf8'});
  assert.match(result, /PASS: explorer matches/);
  const html = await readFile(new URL('courses/edit-distance-explorer.html', root), 'utf8');
  const embedded = html.match(/<script id="course-data" type="application\/json">([\s\S]*?)<\/script>/);
  assert.ok(embedded);
  assert.equal(JSON.stringify(JSON.parse(embedded[1]), null, 2) + '\n', deckText);
  assert.doesNotMatch(html, /<script[^>]+src=|<link[^>]+href=["']https?:|import\s.+from\s+['"]/);
});
