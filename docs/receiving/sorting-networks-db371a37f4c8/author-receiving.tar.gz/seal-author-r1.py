import pathlib,json,hashlib,tarfile,io,datetime,os
R=pathlib.Path(__file__).resolve().parent
O=R/'author-custody-r1';O.mkdir(exist_ok=False)
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
assert json.loads((R/'browser-r2/artifacts/receipt.json').read_text())['error'] is None
assert (R/'portable-r1/receipt.json').is_file()
assert not list((R/'browser-r1/tmp').rglob('*')) and not list((R/'browser-r2/tmp').rglob('*'))
paths=[p for p in sorted(R.rglob('*')) if p.is_file() and O not in p.parents]
rows=[]
for p in paths:
 assert not p.is_symlink()
 b=p.read_bytes();st=p.stat()
 rows.append(dict(path=p.relative_to(R).as_posix(),**pin(b),mtime_ns=str(st.st_mtime_ns)))
manifest=(json.dumps(dict(root=str(R),files=rows),indent=2)+'\n').encode()
(O/'MANIFEST.json').write_bytes(manifest)
target=O/'author-receiving.tar.gz'
with tarfile.open(target,'x:gz',compresslevel=9) as tar:
 for row in rows:
  b=(R/row['path']).read_bytes();assert pin(b)=={k:row[k] for k in ('bytes','sha256','git')}
  info=tarfile.TarInfo(row['path']);info.size=len(b);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(b))
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(manifest);info.mode=0o644;info.mtime=0
 tar.addfile(info,io.BytesIO(manifest))
with tarfile.open(target,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 assert len({m.name for m in members})==len(members)
 for m in members:
  assert m.isfile() and not m.name.startswith(('/', '\\')) and '..' not in pathlib.PurePosixPath(m.name).parts
  b=tar.extractfile(m).read()
  if m.name=='MANIFEST.json':assert b==manifest
  else:
   row=next(q for q in rows if q['path']==m.name);assert pin(b)=={k:row[k] for k in ('bytes','sha256','git')}
for row in rows:
 p=R/row['path'];assert pin(p.read_bytes())=={k:row[k] for k in ('bytes','sha256','git')};assert str(p.stat().st_mtime_ns)==row['mtime_ns']
receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),payloads=len(rows),members=len(rows)+1,archive=pin(target.read_bytes()),manifest=pin(manifest),all_members_reverified=True,all_source_bytes_and_times_exact=True)
(O/'SEAL.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
