# Independent conditional-probability semantic receiving

The immutable model passed the original independently frozen expectations on its first product execution: **165 fixtures passed, zero failed**, covering30table fixtures/480exact ratios/30independence outcomes and135admission fixtures. The admission fixtures are each observed through their parser and every corresponding full-table input position; these are integration observations within135fixtures, not extra independently authored cases.

The run used Node22.22.1 and semantic receiverV2. The exact source was5,445bytes, SHA-25651750dc91155e2f2e44b8db3abdbed7d4ece565b128e1827d4c760c55305e58d, Gitblobf4ef2afd8ae36c81fa2acabd846c0adcf6f8b3a4. The original expectations and source were checked before and after execution. Process exit0; stderr0bytes. No authored model tests were inspected by this receiver.

## Evidence

- [Run receipt](runs/model-v1-01/receipt.json) contains every fixture outcome, raw public result/error observation and source/fixture pins.
- [Process receipt](runs/model-v1-01/process-receipt.json), [stdout](runs/model-v1-01/process-stdout.log) and [stderr](runs/model-v1-01/process-stderr.log) preserve the actual native execution.
- [Executed model](source/conditional-probability.mjs) is the exact qualified source.
- [Executed receiverV2](harness/semantic-receiver-v2.mjs) and [public API mapping](harness/public-api-final.json) preserve the adapter. [V1](harness/semantic-receiver-v1.mjs) remains as an unexecuted predecessor. V2 only improves failure-evidence encoding; it changes no qualification comparison.
- [Original semantic expectations](recovered-original/semantic-oracles-v1.json), [large-count expectations](recovered-admission/high-count-oracles-v1.json) and [admission fixtures](recovered-admission/admission-cases-v1.json) predate product implementation.
- [Initial contract](recovered-original/contract-v1.json) and [learner route](recovered-original/learner-route-v1.json) remain exact historical files.
- [UI/template static review](ui-review-v1/static-review-receipt.json) and [builder static review](builder-review-v1/static-builder-review-receipt.json) found no material blockers in their pinned source versions. These are source reviews, not browser/build passes.
- [Earlier consumer binding](consumer-binding-8317-from-transcript.json) preserves the actual source read at8317dcf. It is not a claim about currentmain or an executed learner journey.

## Preservation history

The initial tool-memory archives were lost before disk materialization because the local filesystem was full. Their generating code and hash receipts survived in the visible conversation. Both complete archives were reconstructed and matched every original file, manifest and archive hash exactly before this product execution.

[Memory-loss boundary](memory-loss-boundary.json), [original archive recovery](original-recovery-receipt.json), [admission archive recovery](admission-recovery-receipt.json), and [storage failure](recovery-storage-failure.json) retain that history. [Initial native transfer](initial-transfer-receipt.json), [prepared receiver checks](prepared-receiver-receipt.json), and [own tmpfs copy](tmpfs-receiver-copy-receipt.json) bind the saved bytes. Historical paths and access states inside the original files were preserved verbatim.

The original archives are [semantic contract](reconstructed-preimplementation-v1.tar.gz), SHAe58720bccc076d758c56b1188d2e719e1e8c577240a9b9af26894ed8944fe42e, and [admission addendum](reconstructed-admission-v1.tar.gz), SHAe1f65c953532faab8cfad619226a38f36c51ebec9597c9dd2c603cf71fe2298e.

## Scope

The browser/actual-download/layout/learner gates belong to the separate native browser receiver. This packet makes no browser, deployment, integration or release claim. Source and expectations are sealed here; no production changes or GitHub writes were made by this receiving lane.
