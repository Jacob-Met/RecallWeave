# Model conventions before implementation

Each Apply defines a separately prepared ideal release. The chosen phase denotes a point in that new trajectory; the previous motion is not continued and no intervention work budget is modeled.

The origin is the fixed equilibrium of one horizontal massless Hooke-law spring. The point mass is released at positive maximum displacement, initially at rest. There is no friction or external drive. Mass, stiffness and amplitude are positive/nonnegative within the explicit classroom input domain.

Cardinal phases use their exact mathematical sine/cosine values. Other phases use ordinary JavaScript Number trigonometry. The natural period is a system parameter; a zero-amplitude resting block has no observed cycle. Energy fractions are undefined when total energy is zero and must be labelled without division.

The schematic has a fixed displacement axis. Velocity and spring-force arrows indicate direction only; their numerical values carry magnitude and units. Changing a parameter is a new comparison experiment, not an animation of a physical intervention.
