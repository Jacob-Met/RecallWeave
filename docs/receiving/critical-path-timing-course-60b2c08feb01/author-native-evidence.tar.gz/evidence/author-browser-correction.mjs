import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=process.cwd(),out=resolve(root,'evidence/browser-correction');
await mkdir(out,{recursive:true});
const digest=b=>({bytes:b.length,sha256:createHash('sha256').update(b).digest('hex'),gitBlob:createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex')});
const expected=JSON.parse(await readFile(resolve(root,'evidence/browser-source-pins.json'),'utf8'));
expected['courses/critical-path-timing.json']='49a84feea08ec76de711557e172ccbc6c5c744e9';
async function pins(){return Object.fromEntries(await Promise.all(Object.keys(expected).map(async p=>[p,digest(await readFile(resolve(root,p)))])));}
const receipt={schema:'critical-path-course-explanation-correction/1',command:'node evidence/author-browser-correction.mjs',startedAt:new Date().toISOString(),node:process.version,previousDeck:'fc4efe9846256cc95170eba94f854cc550a6e4ac',currentDeck:expected['courses/critical-path-timing.json'],boundary:'Bounded actual current-deck import and native question progression, stopping after corrected ct-early-3 feedback. It does not replay or relabel the original full journey.',requests:[],served:[],pageErrors:[],consoleErrors:[],observedQuestions:[],downloads:0};
let browser,context;const pending=[];
try{
 receipt.before=await pins();for(const[p,v]of Object.entries(receipt.before))assert.equal(v.gitBlob,expected[p]);
 const deck=JSON.parse(await readFile(resolve(root,'courses/critical-path-timing.json'),'utf8')),old=JSON.parse(await readFile(resolve(root,'evidence/course-initial-fc4efe98.json'),'utf8'));
 const target=deck.items.find(x=>x.id==='ct-early-3'), prior=old.items.find(x=>x.id==='ct-early-3');
 assert.equal(target.explanation,"Draft finishes at 2+3=5 and Review finishes at 2+4=6. Pack needs both, so its earliest start is max(5,6)=6. Time 5 waits for only Draft; time 7 is Pack's finish, not its start; time 9 adds Prep and both branch durations as if Draft and Review were serial.");
 const correctedBack=structuredClone(deck);correctedBack.items.find(x=>x.id===target.id).explanation=prior.explanation;assert.deepEqual(correctedBack,old,'Only corrected explanation may differ');
 receipt.exactDelta={item:target.id,field:'explanation',before:prior.explanation,after:target.explanation};
 browser=await chromium.launch({executablePath:'/workspace/scratch/3e50c5ad22c5/production/browser/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 receipt.browser=browser.version();context=await browser.newContext({viewport:{width:1280,height:900},acceptDownloads:true});
 context.on('request',r=>receipt.requests.push({url:r.url(),method:r.method()}));
 await context.route(/^https?:/,r=>r.abort('blockedbyclient'));
 const page=await context.newPage();page.on('pageerror',e=>receipt.pageErrors.push(e.message));page.on('console',m=>{if(m.type()==='error')receipt.consoleErrors.push(m.text());});page.on('download',()=>receipt.downloads++);
 page.on('response',r=>{if(r.request().isNavigationRequest())pending.push((async()=>receipt.served.push({url:r.url(),status:r.status(),...digest(await r.body())}))());});
 await page.goto(pathToFileURL(resolve(root,'demo.html')).href);
 await page.locator('#deck-file').setInputFiles(resolve(root,'courses/critical-path-timing.json'));await page.locator('#start-deck').waitFor({state:'visible'});
 assert.deepEqual(await page.locator('.deck-questions li > strong').allTextContents(),deck.items.map(x=>x.prompt));await page.locator('#start-deck').click();
 let found=false;
 for(let count=0;count<deck.items.length;count++){
  const prompt=await page.locator('.question-card h2').textContent(),item=deck.items.find(x=>x.prompt===prompt);assert.ok(item);
  const choice=item.answer;receipt.observedQuestions.push({id:item.id,choice});
  await page.locator('[data-choice="'+choice+'"]').click();await page.locator('#next-button').waitFor({state:'visible'});
  if(item.id===target.id){
   const feedback=await page.locator('#feedback-slot').textContent();
   assert.ok(feedback.includes(target.explanation));assert.ok(!feedback.includes('adds the two branch finish times'));
   assert.ok(feedback.includes(target.transfer));assert.ok(feedback.includes('Correct answer: Time 6'));assert.equal(await page.locator('[data-choice]:enabled').count(),0);
   receipt.renderedFeedback=feedback;found=true;break;
  }
  await page.locator('#next-button').click();
 }
 assert.equal(found,true);assert.equal(receipt.downloads,0);assert.deepEqual(receipt.pageErrors,[]);assert.deepEqual(receipt.consoleErrors,[]);assert.equal(receipt.requests.filter(r=>/^https?:/.test(r.url)).length,0);
 await Promise.all(pending);assert.equal(receipt.served.length,1);assert.equal(receipt.served[0].gitBlob,expected['demo.html']);
 receipt.after=await pins();assert.deepEqual(receipt.after,receipt.before);receipt.status='pass';
}catch(e){receipt.status='fail';receipt.failure={name:e.name,message:e.message,stack:e.stack};process.exitCode=1;}
finally{await Promise.allSettled(pending);if(context)await context.close();if(browser)await browser.close();receipt.endedAt=new Date().toISOString();await writeFile(join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');}
console.log(JSON.stringify({status:receipt.status,observed:receipt.observedQuestions.length,requests:receipt.requests.length,downloads:receipt.downloads,failure:receipt.failure??null}));
