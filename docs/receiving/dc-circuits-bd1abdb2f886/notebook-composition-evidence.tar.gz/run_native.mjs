import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {spawn,spawnSync} from 'node:child_process';
const qa="/Users/me/recallweave-dc-learner-composition-169b-bd1abdb2f886-20261008";
const sha=b=>createHash('sha256').update(b).digest('hex');
const blob=b=>createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const expected=[
  {
    "path": "source/demo.html",
    "bytes": 81178,
    "sha256": "172a0415c717e938fce0fa9e7b94cc1acd502e07f7a193f6b76ff97fbb7e2200",
    "git_blob": "fc782277cf057899d26036bdd2ecb5ce9328422a"
  },
  {
    "path": "provenance/app.mjs",
    "bytes": 20093,
    "sha256": "efd8f069c9ad085bcf42012366bf2f341cff4bf875f7394485caaf4b02db325e",
    "git_blob": "47c43bbb4b2698abf8601a00755ceed630c610df"
  },
  {
    "path": "provenance/session-export.mjs",
    "bytes": 5325,
    "sha256": "6d2063dcaf3b17846f2468035464a2871a6b2ef3d0c59b90500b3bb41e5f05ac",
    "git_blob": "394b9148d210f885869102d6ea2475efa034bda4"
  },
  {
    "path": "provenance/styles.css",
    "bytes": 13478,
    "sha256": "7e7b9b72cf2955a4422fb1d2b269e06c0486f13a91d1c496eb6738cf8bbd0dd1",
    "git_blob": "4d3295b19c9137509dc741f4c93a270a96f8359a"
  },
  {
    "path": "provenance/make_demo.py",
    "bytes": 3183,
    "sha256": "a82c728813641fbbe4de3031f7d29abff2a10f3a0161ac617055e7e4b5f208c5",
    "git_blob": "b88d08088ed5732928d86f20011c9dfe12227437"
  },
  {
    "path": "provenance/reflections.mjs",
    "bytes": 2523,
    "sha256": "92354bccb48deb7c3455d4f9d0e922f7b8b5d45d3d7bbf1968d23ad2818fe330",
    "git_blob": "1506c7b920ed827a94080bde73351daed6554590"
  },
  {
    "path": "source/courses/dc-circuits.json",
    "bytes": 11662,
    "sha256": "cfe7a4586a4a97aa96356e9afe7fea5bc1e216a0aff70454476397c909058ccb",
    "git_blob": "fb5a66a86c127cfe81f691ad4c3a81081ad5fe0c"
  },
  {
    "path": "browser-helpers.mjs",
    "bytes": 7018,
    "sha256": "03ceb9845d9ff65eb8f76609473831a506e5850634399d298ab8ae575fcce051"
  },
  {
    "path": "learner-consumer-contract.json",
    "bytes": 4807,
    "sha256": "9bbd951d4e7e7a3ac1ddb2732ea8a9a68c3252daa27a8d5b3c881f6fc84cea30"
  }
];
const checkInputs=async()=>{
 const rows=[];
 for(const expectedFile of expected){
  const bytes=await readFile(join(qa,expectedFile.path));
  assert.equal(bytes.length,expectedFile.bytes,'Transferred size '+expectedFile.path);
  assert.equal(sha(bytes),expectedFile.sha256,'Transferred SHA '+expectedFile.path);
  if(expectedFile.git_blob)assert.equal(blob(bytes),expectedFile.git_blob,'Transferred Git identity '+expectedFile.path);
  rows.push({path:expectedFile.path,bytes:bytes.length,sha256:sha(bytes),git_blob:blob(bytes)});
 }
 return rows;
};
const rows=await checkInputs();
const adaptation=JSON.parse(await readFile(join(qa,'composition-adaptation.json')));
const originalBytes=await readFile(adaptation.originalSuccessfulDriver.path);
assert.equal(originalBytes.length,adaptation.originalSuccessfulDriver.bytes);
assert.equal(sha(originalBytes),adaptation.originalSuccessfulDriver.sha256);
let rebuilt=originalBytes.toString('utf8');
for(const {before,after,count}of adaptation.changes){
 assert.equal(rebuilt.split(before).length-1,count,'Unexpected provenance adaptation count');
 rebuilt=rebuilt.split(before).join(after);
}
const driver=join(qa,'receive_learner.mjs');
const driverBytes=await readFile(driver);
assert.equal(rebuilt,driverBytes.toString('utf8'),'Unexpected behavioral assertion change');
assert.equal(sha(driverBytes),adaptation.driverSha256);
const syntax=spawnSync(process.execPath,['--check',driver],{encoding:'utf8'});
const transfer={at:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,sourceHead:adaptation.sourceHead,files:rows,originalDriverSha256:sha(originalBytes),driverSha256:sha(driverBytes),onlyRecordedProvenanceAndPathChanges:true,behavioralGroupsUnchanged:6,syntaxExit:syntax.status,syntaxStdout:syntax.stdout,syntaxStderr:syntax.stderr};
await writeFile(join(qa,'transfer-receipt.json'),JSON.stringify(transfer,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(transfer));
if(syntax.status!==0)process.exit(syntax.status??1);
const started=new Date().toISOString(),start=performance.now();
const command=[process.execPath,driver],chunks=[];
const child=spawn(command[0],command.slice(1),{stdio:['ignore','pipe','pipe']});
for(const stream of [child.stdout,child.stderr])stream.on('data',bytes=>{chunks.push(bytes);process.stdout.write(bytes);});
const outcome=await new Promise((resolve,reject)=>{child.once('close',(exitCode,signal)=>resolve({exitCode,signal}));child.once('error',reject);});
const log=Buffer.concat(chunks);
await writeFile(join(qa,'composition-process.log'),log,{flag:'wx'});
const after=await checkInputs();
assert.deepEqual(after,rows,'Native input/source snapshots changed');
const receipt={command,started,finished:new Date().toISOString(),elapsedSeconds:(performance.now()-start)/1000,...outcome,sourceHead:adaptation.sourceHead,logSha256:sha(log),driverSha256:sha(driverBytes),inputsUnchanged:true};
await writeFile(join(qa,'composition-process.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
process.exitCode=outcome.exitCode??1;
