# Independent genetic-linkage receiving before candidate access

This packet freezes scientific assumptions, hand expectations, the exact-rational oracle and actual executable model receiver before any candidate implementation or course answer key was disclosed to this receiver. The author supplied only the public input/output and admission contract.

The only execution retained here is receiver calibration: two native Node syntax checks, 102 constructive reference-invariant cases, eight independent hand fractions and eight deliberate corrupt-result controls. No candidate/model/course/learner test is represented by that result. The 200 analytic weights are arithmetic, not 200 meioses or a guaranteed observed sample.

Receiving will run receive-model.mjs once on the explicitly frozen candidate module and preserve its first stdout/stderr/exit. Course prompts/options are solved separately before keys, then all feedback and transfer wording are reviewed. Existing parseDeck compatibility is a separate schema gate. Browser and learner/download behavior belong to another receiver.

Files and their byte/Git/SHA-256 identities are listed in members.json, excluding that manifest itself. The original source and raw calibration are retained unchanged. Static peer comments and any later candidate outcomes will be additive records rather than replacements.

No Actions, Git ref or PR writes, installs, providers, hamon-ie or LA7 access occurred for this work.
