# Public API and editor grammar — RecallWeave #253
Addendum dated 2026-10-09, before independent candidate admission. Original issue contract remains unchanged.

Configuration has exactly {wires, values, comparators}; wire and comparator bounds are unchanged. Wire pairs are one-based and ordered as written. The editor takes one integer wire-count token, whitespace-separated values, and one two-token comparator row per line. Decimal grammar is [+-]? followed by one or more ASCII digits, with surrounding whitespace permitted. Decimal points, exponent/hex notation and commas are refused. Leading zeros and + are allowed. Empty/whitespace-only comparator text means zero comparators; an interior blank row is refused. Negative zero normalizes to numeric zero. Draft text limits: wires20, values200, comparators2000 UTF-16 code units, with semantic limits still applied.

Public pure API in courses/sorting-networks-core.mjs:
- validateConfiguration(value): validates/copies/freezes exactly the three-field configuration.
- parseDraft(wireText, valueText, comparatorText): reads editor grammar and returns that validated configuration.
- traceInput(configuration, values): validates configuration and the supplied same-length integer vector, then returns {input, steps, output, sorted, firstInversion}.
- analyzeNetwork(configuration): returns {format:"recallweave-sorting-network-observation/1", configuration, authored, binary}.
- configurationJSON(configuration) / observationJSON(configuration): JSON with two-space indentation and final LF, from complete validated values.
- PRESETS: the exact public three presets already frozen in PUBLIC-PRESETS.json, plus their display names.
- MAX_WIRES=6, MAX_COMPARATORS=30.

A trace step is {index,pair,before,after,swapped}, index1-based. An unchanged comparison is included, with swapped:false. firstInversion is the first adjacent out-of-order one-based wire pair, or null. The initial vector is input; every after-vector is retained. sorted refers only to that output.

binary is {total,passed,failed,sortsAll,failingOrdinals,cases}. Cases are lexicographic binary inputs, ordinal0-based, wire1 most significant. Each case is {ordinal,...the complete trace fields}. failingOrdinals identifies every failed case in this fixed enumeration. sortsAll is true iff failed is zero. The observation retains the authored trace even when the page displays a binary-case trace.

Downloads are semantic configuration JSON and complete observation JSON plus the fixed exact lesson JSON. They do not retain editor whitespace/token spelling. The page does not import configuration files. Selecting a binary row changes the viewed trace only, not the accepted configuration or observation. Fixed lesson download is independent of draft validity.
