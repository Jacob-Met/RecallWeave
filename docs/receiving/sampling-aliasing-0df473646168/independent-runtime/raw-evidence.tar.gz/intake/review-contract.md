# Sampling lab: independent receiving contract

Owner: universal-0df473646168 / estate_product. Repository: Jacob-Met/RecallWeave.
Coordination: issue 7, root claim comment 6059561253. Root owns Git publication.

## Immutable native base and boundaries

Base commit 5ce520a778da04605f5fa610fb1ad110ffe52b99, tree 3da3cc7da0005c9e703548057a2e60642f144f37.
The adjacent source-manifest.json identifies five exact native files. Their unchanged copies live in ../baseline and ../candidate; src/deck.mjs blob f0f8a4b234489c2388f427633f548d56c6ed4c03 provides recallweave-deck/1 validation. The native model, review and study-notes code stay unchanged. No importer acceptance is claimed: issue 7's current app composition remains its owner's receiving work.

This increment adds only a sampling-prefixed course, guide, lab model/UI, template, builder and two focused test files, plus uniquely owned evidence. No existing path, default deck, shared learner, import/authoring UI, trace format or build process changes.

## Product and mathematical contract

The directly opened offline HTML teaches ambiguity in ideal uniform observations. Its authored reference is x(t) = cos(2*pi*f*t), unit amplitude and zero phase. The window includes t=0 through t=1 second, so an integer rate fs contributes fs+1 displayed sample points at n/fs. Frequency controls accept finite f from 0 to 40 Hz in half-Hz increments. The rate accepts integers 2 through 32 samples/second.

The lab always draws a different compatible zero-phase cosine. Its readouts separately identify authored reference, matching alternative, lowest nonnegative representative in [0, fs/2], and half-rate. When the reference already is the lowest representative, the comparison uses a higher alias rather than implying uniqueness. All exact integer sample times match up to normal floating-point evaluation error. Plotted between-sample curves are analytical reference/comparison signals, not an estimated reconstruction.

An input boundary explanation uses the strict ideal condition fs > 2B with a known input band limit and complete ideal sample sequence. At equality, the sine phase counterexample can vanish at every sample. A finite displayed sequence does not establish an unknown physical original, validate a band limit, or guarantee practical recovery. Filter discussion is an ideal acquisition-order example, not a filter design.

## Planned stable consumer interfaces

- Model module src/sampling-aliasing.mjs exports analyzeSampling({frequencyHz, sampleRateHz}), principalAlias(frequencyHz, sampleRateHz), cosineAt(frequencyHz, timeSeconds), and samplingCsv(snapshot).
- analyzeSampling returns a frozen snapshot with frequencyHz, sampleRateHz, aliasHz, comparisonHz, durationSeconds, intervalSeconds, halfSampleRateHz, relation ('below', 'at', 'above'), and samples[{index,timeSeconds,reference,comparison}].
- The actual UI's two number inputs have IDs sa-frequency and sa-rate. The numeric table body is sa-sample-rows; each row has index, time, reference, comparison cells. Display values may be rounded; CSV preserves numeric precision.
- CSV columns in order: sample_index,time_seconds,reference_hz,sample_rate_hz,comparison_hz,lowest_alias_hz,reference_value,comparison_value. The last line ends in a newline. Values are numeric only.
- The live CSV download button is sa-download-csv. Invalid or empty input retires the current result/table, reports an accessible error, disables download, and a forced handler must still refuse stale export. Presets must update both inputs and the same live snapshot.
- sa-download-course downloads the exact authored courses/sampling-aliasing.json bytes. The builder validates those bytes with the untouched native deck parser before embedding them. The standalone needs no network, module fetch, storage or server.
- tools/build-sampling-aliasing.mjs builds the standalone from source/template and supports --check without writing. Production paths remain additive.

## Blind content review

questions-blind.json intentionally omits answer indices and explanations. Please derive the correct options and transfer answers independently, inspect distractor ambiguity, and then compare the final authored explanations/guide once delivered. The four-concept native course has twelve original questions. AI-assisted original wording/examples alone are released CC0-1.0; referenced teaching materials retain their licenses and other repository files are not relicensed.

## Primary references read by author

MIT 6.300, Sampling and Aliasing, Fall 2025: https://sigproc.mit.edu/_static/fall25/lectures/Sampling_and_Aliasing-handout.pdf

Dennis Freeman, MIT 6.003 Lecture 21, Sampling, Fall 2011: https://ocw.mit.edu/courses/6-003-signals-and-systems-fall-2011/12e6e5d7567fca2e993ef8563fef5a60_MIT6_003F11_lec21.pdf

No MIT exercises, figures or passages are copied. Independent review may use other primary references. Author execution and browser qualification are pending; no outcome is claimed by this planning contract.
