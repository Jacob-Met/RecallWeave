import pathlib,json,datetime,subprocess,hashlib,os
R=pathlib.Path(__file__).resolve().parent
known=[28504,25560,15416,23324,20176,28156,29448,22928]
cmd="$ids=@("+",".join(map(str,known))+"); @(Get-CimInstance Win32_Process|Where-Object {$ids -contains [int]$_.ProcessId}|Select-Object ProcessId,Name,CreationDate,CommandLine)|ConvertTo-Json -Depth 4 -Compress"
raw=subprocess.check_output(['powershell','-NoProfile','-Command',cmd],text=True,encoding='utf-8')
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
r=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),observer=os.getpid(),known=known,observed=json.loads(raw) if raw.strip() else [],tmp_entries=[str(p) for p in (R/'browser-r2/tmp').rglob('*')],wrapper=pin(R/'browser-r2/wrapper-receipt.json'),receipt=pin(R/'browser-r2/artifacts/receipt.json'),images=[dict(path=p.name,**pin(p)) for p in sorted((R/'browser-r2/artifacts').glob('*.png'))],transport_note='Polling historical outer28504 returned an unrelated earlier fair-division delivery log, timestamp10:43:37. Own native started/receipt files bind Python25560, Node15416 and Edge23324 to10:45:47–10:46:24, Nodeexit0. That unrelated output is excluded. Two wrong process-output mappings have occurred; PID reuse versus connector cache/mapping cause is unestablished. Earlier R1 closure used PID-reuse language as a caution, not a proved cause. No launch was repeated.')
with (R/'AUTHOR-R2-DELAYED-CLOSURE.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r))
