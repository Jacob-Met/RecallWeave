# Independent cache-policy oracle, before candidate inspection

This packet freezes the receiver's policy oracle before reading any candidate implementation or course answer keys. It accepts the bounded FIFO/LRU symbolic-page contract and records current source/neighbor ownership. It is **not product, parser, JavaScript immutability, course-content, browser, or integration acceptance**.

## Frozen policy

The policy_oracle.py.source file has SHA-256 fecc2055bd45767c31f256c2f61f3bd7da71d7645d2a52d3f50ea340d25f186e. It models empty, fully associative, equal-size caches using resident arrival and most-recent-reference timestamps. FIFO ranks arrival; LRU ranks the most recent reference. It does not import or copy a producer implementation. Both returned orders are oldest first according to policy, not physical cache slots.

The native Python 3.13.7 run at 2026-10-08 15:38:26 UTC exited 0 with unchanged source and empty stderr. Eleven complete golden outputs include empty input, one-slot capacity, repeated requests, distinct A/1 identity, eight pages, maximum length, the FIFO anomaly, and a case where LRU has more misses. The bounded exhaustive self-check covers every A-D sequence of length 0-6: 5,461 sequences, 54,610 policy runs, 309,480 step checks, 364,090 prefix checks, and 123,792 LRU stack-inclusion checks. A separate backward-distinct scan cross-checks LRU residency. These are oracle self-checks, not tests of an absent feature.

At capacity 2, A B A C B yields FIFO 3 misses and LRU 4. For 1 2 3 4 1 2 5 1 2 3 4 5, capacities 1-5 give FIFO misses [12, 12, 9, 10, 5] and LRU misses [12, 12, 10, 8, 5]. The latter includes FIFO's 3-to-4 capacity anomaly. The algorithms make no blanket policy-superiority or hardware-performance claim.

Before the first run, review corrected Python's capacity admission to accept an integer-valued JSON number such as 2.0, matching JavaScript number semantics. The prior source and exact correction are preserved under preparation/. No failed product test or runtime failure is attributed to that preparation correction.

## Source and ownership boundary

The original independent read binds Jacob-Met/RecallWeave main 343d20e38fb619c5eea2ec588b61c5f26fea714b to complete tree a4dce90aebe38adecc6ee066e0f764dba53e02a4 (1,347 leaves). The exact original README and complete blob/mode inventory are retained. Existing catalog #39, recursion/memoization #66, and native question-selection lab #72 keep their paths and APIs.

After the oracle executed, production reserved #79 at current main 7c169acc38baaa04a36bad3eba2ada1f9a371203, tree fbea2e9af15fe97865fe4858707f17fe058df3c9 (1,387 leaves). The receiver independently checked that advance: 40 new DC/focused-lesson files plus README; all 1,346 other prior leaves and their modes are exact. No planned cache path collides. The claim body is retained separately from the earlier baseline read.

The bounded topic check includes repository LRU/FIFO/cache searches, exact neighbor claims and all 451 returned central #140 comments through comment 6063429455 at 15:34:59 UTC. Comment identity/time/body hashes retain provenance without copying every unrelated body. There is no cache-replacement claimant in that read. No native advisory surface was independently acquired; the producer's reported unavailable ThinkPad advisory remains a visibility limitation. No lease, exclusivity over the estate, GitHub mutation, installed dependency or producer-source edit is asserted.

## Replay and later receiving

Run the exact oracle with the available Python runtime:

    python3 -B policy_oracle.py.source --self-check /an/owned/new/output-directory

Without --self-check, stdin is JSONL core inputs and stdout is JSONL result/error envelopes. The packet's self-check output directory must remain unchanged; use a new owned directory if replay is necessary.

A frozen candidate will be compared against the unchanged full traces and totals. Text spelling, sparse arrays, exact fields, input copying, deep freezing, browser cursor/input invalidation, downloads, actual learner preview/explicit Start, course answers, and final current-main composition remain separate future gates. No implementation-specific candidate harness or hidden answer key was read to author this oracle.
