'use strict';
const fs=require('node:fs'), path=require('node:path'), os=require('node:os'), crypto=require('node:crypto'), zlib=require('node:zlib'), assert=require('node:assert/strict');
const SOURCE='C:\\Users\\minec\\AppData\\Local\\Hamon\\estate-6e5752b49b6f\\course-comparison-source-receiving-root-r2';
const OWN=__dirname;
const expected=['admission-context.json','chrome.stderr','chrome.stdout','driver-result.json','intake-r1.json','intake-r2.json','node.stderr','node.stdout','r1-ids-1280.png','r1-ids-390.png','r1-renderer-probe.html','r2-ids-1280.png','r2-ids-390.png','r2-renderer-probe.html','receive-renderer-r2.mjs','renderer-receiving.json','run-renderer-r2.cjs','stage-r2.cjs','staging.json'];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=b=>crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const rec=b=>({bytes:b.length,sha256:sha(b),gitBlob:git(b)});
function streamed(p){const s=fs.statSync(p);assert.ok(s.isFile());const h=crypto.createHash('sha256'),g=crypto.createHash('sha1');g.update(Buffer.from('blob '+s.size+'\0'));const fd=fs.openSync(p,'r'),buf=Buffer.alloc(1024*1024);try{let n;while((n=fs.readSync(fd,buf,0,buf.length,null))>0){h.update(buf.subarray(0,n));g.update(buf.subarray(0,n));}}finally{fs.closeSync(fd);}return {path:p,bytes:s.size,sha256:h.digest('hex'),gitBlob:g.digest('hex'),mtimeMs:s.mtimeMs};}
const began=new Date().toISOString();
const capacity={freeMemoryBytes:os.freemem(),freeDiskBytes:fs.statfsSync(OWN).bavail*fs.statfsSync(OWN).bsize,scope:'Read/hash/archive only; no browser admission or launch.'};
assert.ok(capacity.freeMemoryBytes>256*1024**2);assert.ok(capacity.freeDiskBytes>32*1024**2);
assert.deepEqual(fs.readdirSync(SOURCE).sort(),expected);
const originals=new Map(expected.map(n=>{const p=path.join(SOURCE,n);assert.ok(fs.lstatSync(p).isFile());return [n,fs.readFileSync(p)];}));
const originalPins=expected.map(n=>({path:n,...rec(originals.get(n)),mtimeMs:fs.statSync(path.join(SOURCE,n)).mtimeMs}));
const json=n=>JSON.parse(originals.get(n).toString('utf8'));
const report=json('renderer-receiving.json'),driver=json('driver-result.json'),context=json('admission-context.json');
assert.equal(report.accepted,true);assert.equal(report.inputsUnchanged,true);assert.deepEqual(report.errors,[]);
assert.equal(driver.pid,94488);assert.equal(driver.exitCode,0);assert.equal(driver.signal,null);assert.equal(driver.elapsedMs,2550.3259);assert.equal(report.elapsedMs,2387.7041);
assert.equal(report.browserPid,76288);assert.equal(report.browserClosed,true);assert.equal(report.browserExitCode,0);assert.equal(report.browserSignal,null);assert.equal(report.ownProfileRemoved,true);
assert.equal(fs.existsSync(path.join(SOURCE,'chrome-profile')),false);
assert.equal(report.before.length,13);assert.deepEqual(report.before,report.after);
assert.deepEqual(report.before.map(p=>streamed(p.path)),report.before);
assert.equal(report.requests.length,2);
assert.deepEqual(report.requests.map(r=>[new URL(r.url).pathname.split('/').pop(),r.method]).sort(),[['r1-renderer-probe.html','GET'],['r2-renderer-probe.html','GET']]);
assert.equal(report.observations.length,4);
assert.deepEqual(report.observations.map(o=>[o.version,o.width]),[['r1',1280],['r1',390],['r2',1280],['r2',390]]);
const geometry=[];
for(const o of report.observations){
 assert.equal(o.unexpectedImages,0);assert.ok(o.scrollWidth<=o.innerWidth);assert.equal(o.innerWidth,o.width);
 assert.equal(o.paragraphs.length,4);assert.equal(o.summaries.length,2);
 assert.deepEqual(o.paragraphs.map(x=>x.quoted),['"a b"','"a b"','"a  b"','"a  b"']);
 assert.deepEqual(o.summaries.map(x=>x.quoted),['"a b"','"a  b"']);
 const single=o.paragraphs[0].width,double=o.paragraphs[2].width,ss=o.summaries[0].width,ds=o.summaries[1].width;
 if(o.version==='r1'){assert.equal(single,double);assert.equal(ss,ds);assert.ok(o.paragraphs.concat(o.summaries).every(x=>x.whiteSpace==='normal'));assert.ok(o.warning.includes('both complete courses'));}
 else{assert.ok(double>single);assert.ok(ds>ss);assert.ok(o.paragraphs.concat(o.summaries).every(x=>x.whiteSpace==='pre-wrap'));assert.ok(o.warning.includes('full question records and answer keys'));assert.ok(!o.warning.includes('both complete courses'));}
 geometry.push({version:o.version,width:o.width,paragraphSingle:single,paragraphDouble:double,summarySingle:ss,summaryDouble:ds});
}
assert.equal(report.browserVersion.product,'Chrome/154.0.8037.98');
assert.equal(report.browserVersion.revision,'@b859317bf11f6be47f9b7799ec690a0a42a1fb33');
assert.ok(report.preSpawnAdmission.freeMemoryBytes>2*1024**3);assert.ok(report.preSpawnAdmission.freeDiskBytes>1024**3);
assert.ok(!report.command.includes('--no-sandbox'));
const renderer=originals.get('receive-renderer-r2.mjs');
assert.equal(renderer.length,15455);assert.equal(sha(renderer),'74381dc66562de16743d02fd2e399a353b6f29e8dd25c43f17a736794e0c7bd1');
assert.equal(git(renderer),'4fa1a8688ecc5fc8ce7c94e8274a81b0135c66e2');
assert.equal(context.edits.length,5);
let reversed=renderer.toString('utf8');
for(const e of [...context.edits].reverse()){assert.equal(reversed.split(e.after).length,2,'Unique exact substitution');reversed=reversed.replace(e.after,e.before);}
const old=Buffer.from(reversed);
assert.equal(old.length,14355);assert.equal(sha(old),'f01c7fd8bf4829efdceeb7c533c59c414c00c1752d77771dc885b4995c93e1d2');assert.equal(git(old),'6ecf865dd29b1e73d94c41cbd07b8127b16f93b0');
const payloads=new Map(expected.map(n=>['original/'+n,originals.get(n)]));
const embedded=[];
for(const v of ['r1','r2']){
 const intake=json('intake-'+v+'.json');assert.equal(intake.files.length,7);
 for(const f of intake.files){assert.ok(!f.path.includes('..')&&!path.isAbsolute(f.path));const b=Buffer.from(f.text);assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256);assert.equal(git(b),f.gitBlob);payloads.set('received-source/'+v+'/'+f.path,b);embedded.push({version:v,path:f.path,...rec(b)});}
 const by=n=>intake.files.find(f=>f.path===n).text;
 const slice=by('src/course-comparison-ui.mjs').slice(...report[v+'Source'].sliceStringOffsets);
 assert.equal(sha(Buffer.from(slice)),report[v+'Source'].rendererSliceSha256);
 const html=originals.get(v+'-renderer-probe.html').toString('utf8');assert.ok(html.includes(slice));assert.ok(html.includes(by('course-compare/styles.css')));
}
const png=[];
assert.equal(report.artifacts.length,6);
for(const a of report.artifacts){assert.equal(path.dirname(a.path),SOURCE);const b=originals.get(path.basename(a.path));assert.ok(b);assert.equal(b.length,a.bytes);assert.equal(sha(b),a.sha256);assert.equal(git(b),a.gitBlob);}
for(const n of expected.filter(n=>n.endsWith('.png'))){const b=originals.get(n);assert.equal(b.subarray(0,8).toString('hex'),'89504e470d0a1a0a');const width=b.readUInt32BE(16),height=b.readUInt32BE(20);assert.equal(width,n.includes('1280')?1280:390);png.push({path:n,width,height,...rec(b)});}
const stableOriginals=expected.map(n=>{const p=path.join(SOURCE,n);return {path:n,...rec(fs.readFileSync(p)),mtimeMs:fs.statSync(p).mtimeMs};});assert.deepEqual(stableOriginals,originalPins);
assert.deepEqual(report.before.map(p=>streamed(p.path)),report.before);
const receipt={
 schema:'recall180-independent-renderer-custody/1',worker:'estate-6e5752b49b6f/native_runtime',began,ended:new Date().toISOString(),
 scope:'Custody and independent byte/record validation of completed fixed-report renderer/CSS slice only. No source execution, comparator177, full product/file-lifecycle, standalone, or new browser receiving.',
 accepted:true,identity:{host:os.hostname(),user:os.userInfo().username,node:process.version,execPath:process.execPath},capacity,
 sourceRoot:SOURCE,originalFiles:originalPins,originalFileCount:19,inputCount:13,inputRecordsBeforeAfterEqual:true,inputsRehashedUnchanged:true,
 process:{nodePid:driver.pid,nodeExit:driver.exitCode,nodeSignal:driver.signal,nodeElapsedMs:driver.elapsedMs,receiverElapsedMs:report.elapsedMs,browserPid:report.browserPid,browserObservedClosed:report.browserClosed,browserExit:report.browserExitCode,browserSignal:report.browserSignal,ownProfileRemovedInOriginal:true,ownProfileAbsentAtCustody:true},
 exactFiveEditReversal:{recoveredBytes:old.length,recoveredSha256:sha(old),recoveredGitBlob:git(old),rendererOraclesUnchangedByExactReversal:true},
 embeddedSourceRecords:embedded,geometry,pngs:png,errors:report.errors,requests:report.requests,
 historicalFailures:{unchangedImmutableCommit:'83cd3cfe935b67f494f72190c23ec21c1f6ef92a',archiveSha256:'60698819609899a325cdd1f66eefda495459e028ff7f12c4f5025cecf7cdd99f',repackaged:false},
 limits:['Original browser execution and visual inspection were by root; this custody did not replay them.','PNG headers/hashes checked natively; transported PNG chunks/pixels will be decoded independently.','Runtime executables are pinned by original receipts and independently rehashed, not copied into archive.','Historical R0/R1 refusal archive remains separate and unchanged.']
};
const readme='# Recall180 completed renderer/CSS slice — independent custody\n\nThis packet preserves the original completed root R2 run, not a new execution. It contains all 19 original source/context/output files byte-for-byte, the 14 embedded R1/R2 source records extracted without execution, this custodian and its bounded receiving record, and an exhaustive member manifest.\n\nThe native record reports four 1280/390 observations. R1 collapses the distinct one-space/two-space exact IDs; R2 preserves their different measured widths in both paragraphs and summaries. R2 also uses truthful full-question-record/answer-key wording. Node94488 exited0, Chrome76288 had observed close0/null signal, and its own profile was removed. All13 admitted records and all19 completed-folder files were rehashed unchanged here. The five declared admission/close/cleanup edits reverse exactly to the pinned earlier R1 receiver, without changing renderer oracles.\n\nScope is only the fixed contract-shaped report renderer/CSS. Owner177 comparator, actual course comparison, full file lifecycle, generated standalone and whole-product acceptance remain pending. No browser, product source, generator or comparator was run during custody. The original four PNGs and two probe HTMLs are preserved, not regenerated. Runtime binaries are not bundled; exact pins remain in the original receipt.\n\nHistorical R0/R1 refusals stay separately preserved in immutable83cd3cfe935b67f494f72190c23ec21c1f6ef92a, archive SHA25660698819609899a325cdd1f66eefda495459e028ff7f12c4f5025cecf7cdd99f. This archive does not recreate or repackage that packet. Native own archives/base64 are custody copies only, with no ref/PR/Actions operation. A separate transport verification receipt must bind the whole archive and each member before external acceptance.\n';
payloads.set('custody/README.md',Buffer.from(readme));payloads.set('custody/receiving.json',Buffer.from(JSON.stringify(receipt,null,2)+'\n'));payloads.set('custody/seal-renderer.cjs',fs.readFileSync(__filename));
const manifest={schema:'hamon-exact-payload-manifest/1',files:[...payloads].sort(([a],[b])=>a.localeCompare(b)).map(([p,b])=>({path:p,...rec(b)}))};
payloads.set('manifest.json',Buffer.from(JSON.stringify(manifest,null,2)+'\n'));
function oct(n,width){return n.toString(8).padStart(width-1,'0')+'\0';}
const blocks=[];for(const [name,b]of [...payloads].sort(([a],[b])=>a.localeCompare(b))){assert.ok(Buffer.byteLength(name)<100);const h=Buffer.alloc(512);h.write(name,0,100,'utf8');h.write(oct(420,8),100);h.write(oct(0,8),108);h.write(oct(0,8),116);h.write(oct(b.length,12),124);h.write(oct(0,12),136);h.fill(32,148,156);h[156]=48;h.write('ustar\0',257);h.write('00',263);const sum=h.reduce((a,x)=>a+x,0);h.write(sum.toString(8).padStart(6,'0')+'\0 ',148);blocks.push(h,b,Buffer.alloc((512-b.length%512)%512));}blocks.push(Buffer.alloc(1024));
const tar=Buffer.concat(blocks),archive=zlib.gzipSync(tar,{level:9});
const decoded=zlib.gunzipSync(archive);let offset=0,count=0;while(decoded.subarray(offset,offset+512).some(x=>x)){const header=decoded.subarray(offset,offset+512),name=header.subarray(0,100).toString().split('\0')[0],size=parseInt(header.subarray(124,136).toString().replace(/\0/g,'').trim(),8);assert.ok(payloads.has(name));assert.deepEqual(decoded.subarray(offset+512,offset+512+size),payloads.get(name));count++;offset+=512+Math.ceil(size/512)*512;}assert.equal(count,payloads.size);
for(const n of expected){assert.deepEqual(fs.readFileSync(path.join(SOURCE,n)),originals.get(n));}
const archiveName='recall180-root-renderer-r2-independent-custody.tar.gz';
fs.writeFileSync(path.join(OWN,'receiving.json'),payloads.get('custody/receiving.json'),{flag:'wx'});fs.writeFileSync(path.join(OWN,'README.md'),readme,{flag:'wx'});fs.writeFileSync(path.join(OWN,'manifest.json'),payloads.get('manifest.json'),{flag:'wx'});
fs.writeFileSync(path.join(OWN,archiveName),archive,{flag:'wx'});
const base64=archive.toString('base64');fs.writeFileSync(path.join(OWN,'packet.b64'),base64.match(/.{1,16000}/g).join('\n')+'\n',{flag:'wx'});
const metadata={archive:path.join(OWN,archiveName),...rec(archive),members:count,manifestSha256:sha(payloads.get('manifest.json')),receipt:rec(payloads.get('custody/receiving.json')),base64Path:path.join(OWN,'packet.b64'),base64Characters:base64.length,base64Lines:Math.ceil(base64.length/16000),originalFiles:19,embeddedSourceFiles:14,nativeMemberReadback:true,sourceStillExact:true};
fs.writeFileSync(path.join(OWN,'archive-metadata.json'),JSON.stringify(metadata,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(metadata));
