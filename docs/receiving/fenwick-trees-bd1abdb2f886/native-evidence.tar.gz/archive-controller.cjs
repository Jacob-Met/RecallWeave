const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process'),zlib=require('node:zlib');
const root="/home/ubuntu/hamon-receiving-bd1abdb2f886-20261009/fenwick",out=path.join(root,'publication-v1'),stage=path.join(out,'members');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),git=b=>crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const pin=(b,mode)=>({bytes:b.length,sha256:hash(b),git_blob:git(b),mode});
const from=p=>{const s=fs.lstatSync(p);if(!s.isFile()||s.isSymbolicLink())throw Error('Not regular '+p);return {bytes:fs.readFileSync(p),mode:(s.mode&511).toString(8)};};
const safe=n=>{if(!n||n.startsWith('/')||n.includes('\\')||n.split('/').some(x=>!x||x==='.'||x==='..')||n.length>250)throw Error('Unsafe path '+n);};
const guard=fs.statfsSync(root);if(guard.bavail*guard.bsize<268435456)throw Error('Capacity guard');
if(fs.existsSync(out))throw Error('No replay: publication exists');fs.mkdirSync(stage,{recursive:true});
const members=new Map(),sources=new Map();
function add(n,b,mode='644',expected){safe(n);if(members.has(n))throw Error('Duplicate '+n);const p=pin(b,mode);if(expected){for(const k of ['bytes','sha256','git_blob','mode'])if(expected[k]!==undefined&&String(expected[k])!==String(p[k]))throw Error(n+' '+k+' differs');}const dest=path.join(stage,n);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,b,{flag:'wx',mode:parseInt(mode,8)});fs.chmodSync(dest,parseInt(mode,8));members.set(n,p);}
function copy(n,p,expected){const f=from(p);add(n,f.bytes,f.mode,expected);sources.set(p,pin(f.bytes,f.mode));}
const inv=JSON.parse(fs.readFileSync(path.join(root,'actual-receiving-inventory-v1.json')));
for(const [n,expected]of Object.entries(inv.files))copy('pod/'+n,path.join(root,n),expected);
copy('pod/actual-receiving-inventory-v1.json',path.join(root,'actual-receiving-inventory-v1.json'),{git_blob:'826d7596b5038c5c199f4075adda1cd81cf8e1f5'});
copy('pod/cohort-admission.json',path.join(root,'../admission.json'),{git_blob:'5c8e40f91ea1107109ee265a658f2eb2f06e7084'});
const input=JSON.parse(fs.readFileSync(path.join(root,'input-v1.json')));
for(const f of input.files)copy('pod/'+f.path,path.join(root,f.path),{git_blob:f.git_blob});
const packet=JSON.parse(fs.readFileSync(path.join(root,'archive-history-v1.json')));
for(const f of packet.files)add(f.path,Buffer.from(f.content),f.mode||'644',f);
copy('archive-controller.cjs',__filename);
const scope={schema:'fenwick-evidence-scope/v1',product:'RecallWeave issue189',execution:{thinkpad:'Node22.22.1 authored ten tests/build/check and independent28groups/29923assertions, no browser run',admitted_pod:'Node22.22.2/Chrome148 first explorer13checks and first learner9checks; shared helper19groups, no repeated product mathematics'},browser_output:'Seven actual explorer downloads plus actual notes; all five real PNGs',history:'Original source absence is source evidence, not a fabricated failing runtime. Old browser preparation/helper is explicitly historical; final qualified helper/drivers are in pod/receivers.',custody:'Exact bytes and modes, raw stdout/stderr, actual runtime hashes and source pre/post. No profiles, caches, browser/runtime binaries or fabricated log outputs.',acceptance:{model:'e306539a632519ec02714dc79681e8ff34393ea7',actual_browser:'750868dbf8aef110c8558f61eaa5cf0e84ef8d6f',root_visual:'020df69d3880269f3649b5fa7b1861100b404f2e'},limits:'No GitHub Actions run or PR/main publication. Preview source composition and event/ref approval are separate.'};
add('SCOPE.json',Buffer.from(JSON.stringify(scope,null,2)+'\n'));
const manifest={schema:'fenwick-native-evidence-manifest/v1',created_at:new Date().toISOString(),members:Object.fromEntries([...members].sort(([a],[b])=>a.localeCompare(b))),member_count:members.size,payload_bytes:[...members.values()].reduce((a,p)=>a+p.bytes,0)};
const manifestBytes=Buffer.from(JSON.stringify(manifest,null,2)+'\n');fs.writeFileSync(path.join(stage,'MANIFEST.json'),manifestBytes,{flag:'wx',mode:0o644});fs.copyFileSync(path.join(stage,'MANIFEST.json'),path.join(out,'MANIFEST.json'));
const names=[...members.keys()].sort().concat('MANIFEST.json');fs.writeFileSync(path.join(out,'members.list'),names.join('\n')+'\n',{flag:'wx'});
const rawPath=path.join(out,'native-evidence.tar'),tar=cp.spawnSync('tar',['--format=ustar','--owner=0','--group=0','--numeric-owner','--mtime=@0','--no-recursion','-cf',rawPath,'-C',stage,'-T',path.join(out,'members.list')],{encoding:'utf8',timeout:60000,maxBuffer:1048576});
fs.writeFileSync(path.join(out,'tar.stdout.txt'),tar.stdout||'');fs.writeFileSync(path.join(out,'tar.stderr.txt'),tar.stderr||'');if(tar.status!==0)throw Error('tar '+JSON.stringify(tar));
const raw=fs.readFileSync(rawPath),archive=zlib.gzipSync(raw,{level:9}),decoded=zlib.gunzipSync(archive);if(!raw.equals(decoded))throw Error('Compression roundtrip differs');
const seen=new Map();for(let off=0;off+512<=decoded.length;){const header=decoded.subarray(off,off+512);if(header.every(x=>x===0))break;
 const c=(a,b)=>header.subarray(a,b).toString('utf8').replace(/\0.*$/s,'');const n=(c(345,500)?c(345,500)+'/':'')+c(0,100);safe(n);
 const sum=header.reduce((a,v,i)=>a+((i>=148&&i<156)?32:v),0);if(sum!==parseInt(c(148,156).trim(),8))throw Error('Tar checksum '+n);
 const mode=parseInt(c(100,108).trim(),8).toString(8),size=parseInt(c(124,136).trim(),8),type=c(156,157);if(type!==''&&type!=='0')throw Error('Nonregular tar member '+n);if(seen.has(n))throw Error('Duplicate tar '+n);if(!Number.isSafeInteger(size)||size<0||off+512+size>decoded.length)throw Error('Tar size');
 const bytes=decoded.subarray(off+512,off+512+size);seen.set(n,pin(bytes,mode));off+=512+Math.ceil(size/512)*512;
}
if(seen.size!==members.size+1)throw Error('Tar count');for(const[n,p]of members)if(JSON.stringify(seen.get(n))!==JSON.stringify(p))throw Error('Tar member differs '+n);
if(JSON.stringify(seen.get('MANIFEST.json'))!==JSON.stringify(pin(manifestBytes,'644')))throw Error('Tar manifest differs');
for(const[p,want]of sources){const f=from(p);if(JSON.stringify(pin(f.bytes,f.mode))!==JSON.stringify(want))throw Error('Original source changed '+p);}
const archivePath=path.join(out,'native-evidence.tar.gz');fs.writeFileSync(archivePath,archive,{flag:'wx'});
const seal={schema:'fenwick-native-evidence-seal/v1',created_at:new Date().toISOString(),archive:{path:archivePath,...pin(archive,'644')},manifest:{path:path.join(out,'MANIFEST.json'),...pin(manifestBytes,'644')},raw_tar:pin(raw,'644'),member_count:members.size+1,declared_payload_members:members.size,payload_bytes:manifest.payload_bytes,total_member_bytes:manifest.payload_bytes+manifestBytes.length,original_files_verified:sources.size,tar_command:{exit:tar.status,stdout:tar.stdout,stderr:tar.stderr},decoded_audit:{safe_unique_regular_paths:true,exact_pathset:true,exact_bytes_sha_git_modes:true,manifest_exact:true,lossless_compression:true,source_postflight:true},browser_profiles_after:fs.readdirSync(path.join(root,'profiles')),scope};
fs.writeFileSync(path.join(out,'seal.json'),JSON.stringify(seal,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(seal));