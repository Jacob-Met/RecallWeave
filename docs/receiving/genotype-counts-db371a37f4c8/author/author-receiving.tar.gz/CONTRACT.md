## Original genotype-count lesson and count-table worksheet — estate-db371a37f4c8

A learner using the integrated Mendelian course can calculate a specified parental cross. This distinct contribution teaches the change of question when the input is a whole group's observed genotype counts: count allele copies, distinguish allele from genotype frequency, derive a stated random-union expectation, and keep that expectation separate from observed finite counts.

### Finished learner contribution

- An original fourteen-question `recallweave-deck/1` course with authored distractors, explanations and transfer prompts.
- A static, unanswered count-table worksheet, readable offline and printable through a browser.
- A separate worked guide containing exact fraction derivations, worksheet solutions, all fourteen answers and transfer responses, assumptions, source references and normal learner instructions.
- The unchanged learner receives the actual course file through local preview and explicit Start this deck, then first-answer review, separate missed-item practice and an actual study-notes download.

There is no new calculator, parser, lab runtime, database, catalog framework or adaptive model. This is an authored learning contribution, not a software diagnosis or a new assessment-validity claim.

### Mathematical and biological scope fixed before authoring

All examples are hypothetical diploid plants, one autosomal locus, and exactly two labels A and a. No dominance or phenotype rule is needed to count alleles. Recorded nonnegative whole counts are `nAA, nAa, naa`; `N = nAA + nAa + naa`. If N is positive, the observed allele fractions are `p = (2*nAA + nAa)/(2*N)` and `q = (2*naa + nAa)/(2*N)`. Observed genotype fractions are the three original counts divided by N. This accounting does **not** require Hardy–Weinberg equilibrium.

Separately stipulate independent union of two gametes from pools with the same A fraction p and a fraction q, equal contribution/ordinary segregation, and no change in the specified allele pool. The expected zygote probabilities are `p*p, 2*p*q, q*q`. Multiplying those probabilities by a stated positive cohort size gives expected counts, which can be fractional. They are not guaranteed realized counts or integer quotas; do not round them to create fictitious observed plants.

A persistent Hardy–Weinberg model additionally needs its ideal generational assumptions, including random mating, no mutation/migration/selection and no finite-population drift. The lesson distinguishes this idealization from one stipulated gamete-union calculation. A finite count table alone neither establishes all those assumptions nor identifies a cause for a difference. No significance test, p-value, genotyping-quality verdict, mechanism diagnosis, disease risk, ancestry, real genetic dataset or clinical inference is included.

Public worksheet inputs, in AA/Aa/aa order, are fixed now:
`G1=(7,6,3)`, `G2=(0,9,0)`, `G3=(5,0,5)`, `G4=(0,10,0)`, `G5=(8,0,0)`, `G6=(0,0,0)`.
Learners derive totals, copy counts, observed fractions and model expectations themselves. G3/G4 compare groups with the same allele fractions but different genotype composition. G2 preserves odd size and nonintegral expected counts; G5 covers a boundary; G6 has zero copies and therefore undefined observed allele/genotype fractions, not p=q=0 or a fabricated model result. Expected probabilities sum to one; expected allele-copy accounting preserves p and q. Scaling an observed count table changes counts, not its fractions.

All numerical examples, question wording, distractors, explanations and layout will be original. Foundations are checked against OpenStax Biology 2e §19.1, the University of California Berkeley Biology 1B Hardy–Weinberg lecture, and primary literature on the distinction between observed discrepancies and statistical tests. Their exercises/figures/passages are not copied. This contribution teaches accounting and declared model assumptions, not subject mastery, medical advice or empirical educational efficacy.

### Exact source fence and owner preservation

New paths only:
```
courses/genotype-counts.json
courses/genotype-counts.md
courses/genotype-counts-worksheet.html
tests/genotype-counts-course.test.mjs
docs/receiving/genotype-counts-db371a37f4c8/
```
A small README discovery paragraph, if later warranted, is separately root-composed over current bytes. Preserve every existing runtime, importer, session/archive/review/practice/notes module, learner HTML, catalog registration, offline-pack builder, dependency, workflow and other course.

Current main is `ec07bf3989132130759e5c00c6cb02eef19709d3`, tree `a839b6877bf2824f134443829d1ce62e1bd79e50`, complete 2,933 leaves. No applicable AGENTS file or proposed path exists in that tree. Current all-state issue/PR inventory contains records1–260; targeted Hardy, random-mating and population-genetics searches found no matching scope. This is a bounded public check, not knowledge of private queues.

Original Mendelian #60 remains a specific-parent/independent-assortment lesson. #198 retains its distinct two-locus linkage and test-cross contribution; its complete current contract and delivery comment were read. #245 retains strand/codon content; probability/counting/conditional/sampling owners and current #253 sorting networks retain their contributions. No sibling unpublished source is a dependency.

### Original-first and native receiving

No new question, key, candidate artifact or authored test exists at this reservation. Root will freeze independent mathematical expectations, then solve a separate prompt/options-only projection before receiving answer/explanation fields. Author tests will not become the expected oracle.

The original native source closure will include the exact current unchanged parser and learner, original Mendelian course/guide and relevant provenance. An original Node parse/serialize control precedes candidate authoring. The final gate uses actual course import, complete answers, first-answer review, separate missed-item practice and a retained physical notes file; it also directly inspects the static worksheet at ordinary/phone widths and a browser print artifact. Any first failures remain preserved. No repeated broad shared-learner campaign is intended.

Use only the already admitted MSI\\Veria route and installed Node24.19.0/Edge154/Python3.11; no installation. Fresh C:>=1GiB, D:>=256MiB and available memory>=2GiB guards remain unchanged. Own inputs, TEMP/profile and outputs live in `D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8`; the independent receiver uses its own namespace. Root currently holds the browser window; no new UI launch occurs before release.

The complete current five-workflow bodies were fetched and Git-verified. They subscribe to selected main pushes and PRs, not issues/comments. This issue creates no ref, PR, merge, Actions, workflow/protection change, provider/account action or public contest submission. Initial source/evidence custody will be immutable objects only.
