#!/usr/bin/env node
/** Loader receiving with actual Chromium, real files, and controlled read races. */
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { mkdir, mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { dirname, extname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const args = process.argv.slice(2);
const option = (name, fallback) => args.includes(name) ? args[args.indexOf(name) + 1] : fallback;
const root = resolve(option('--root', join(dirname(fileURLToPath(import.meta.url)), '..')));
const executable = option('--browser', 'chromium');
const output = resolve(option('--output', join(root, 'verification/loader-browser')));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const { parseDeck, MAX_DECK_BYTES } = await import(pathToFileURL(join(root, 'src/deck.mjs')));
await mkdir(output, { recursive: true });
const profile = await mkdtemp(join(output, 'profile-'));
const downloads = join(output, 'downloads');
const fixtures = join(output, 'fixtures');
await mkdir(downloads, { recursive: true });
await mkdir(fixtures, { recursive: true });
const report = { status: 'running', root, executable, checks: [], sources: {}, inputs: {}, pageErrors: [], externalRequests: [], downloads: [] };
for (const path of ['src/deck.mjs', 'src/deck-author.mjs', 'src/deck-author-ui.mjs', 'src/deck-author-loader.mjs',
  'author/index.html', 'author/author.css', 'author.html']) report.sources[path] = hash(await readFile(join(root, path)));
const actual = {};
for (const name of ['authored-final.json', 'authored-standalone-phone.json']) {
  const bytes = await readFile(join(root, 'verification/inputs', name));
  report.inputs[name] = { sha256: hash(bytes), bytes: bytes.length, provenance: 'Actual owner browser download, not a reconstructed fixture' };
  actual[name] = parseDeck(bytes.toString('utf8'));
  await writeFile(join(fixtures, name), bytes);
}
const original = actual['authored-final.json'];
const phone = actual['authored-standalone-phone.json'];
const makeFile = async (name, value) => { const path = join(fixtures, name); await writeFile(path, typeof value === 'string' ? value : JSON.stringify(value)); return path; };
const firstFile = join(fixtures, 'authored-final.json');
const secondFile = join(fixtures, 'authored-standalone-phone.json');
const invalid = await makeFile('invalid.json', '{');
const oversized = await makeFile('oversized.json', 'x'.repeat(MAX_DECK_BYTES + 1));
const unreadable = await makeFile('unreadable.json', original);
const slowSuccess = await makeFile('slow-success.json', original);
const slowFailure = await makeFile('slow-failure.json', original);
const slowCancel = await makeFile('slow-cancel.json', original);
const longDeck = structuredClone(phone); longDeck.title = '界'.repeat(160);
const longFile = await makeFile(`${'f'.repeat(240)}.json`, longDeck);

const server = createServer(async (request, response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    const path = resolve(root, `.${pathname}`);
    if (!path.startsWith(`${root}/`)) { response.writeHead(403).end(); return; }
    const bytes = await readFile(path);
    response.writeHead(200, { 'Content-Type': `${({ '.mjs': 'text/javascript', '.html': 'text/html', '.css': 'text/css', '.json': 'application/json' })[extname(path)] ?? 'application/octet-stream'}; charset=utf-8` });
    response.end(bytes);
  } catch { response.writeHead(404).end(); }
});
await new Promise(done => server.listen(0, '127.0.0.1', done));
const base = `http://127.0.0.1:${server.address().port}`;
let browser, socket, sessionId, sequence = 0, chooserCount = 0, browserLog = '';
const pending = new Map();
const downloadEvents = new Map();
const delay = ms => new Promise(done => setTimeout(done, ms));
async function waitFor(check, label) {
  let last;
  for (let i = 0; i < 120; i++) {
    try { if (await check()) return; } catch (error) { last = error; }
    await delay(50);
  }
  throw new Error(`Timed out: ${label}${last ? `: ${last.message}` : ''}`);
}
function command(method, params = {}, scoped = true) {
  return new Promise((yes, no) => {
    const id = ++sequence;
    const timer = setTimeout(() => { pending.delete(id); no(new Error(`CDP timeout: ${method}`)); }, 10000);
    pending.set(id, { yes, no, timer });
    socket.send(JSON.stringify({ id, method, params, ...(scoped && sessionId ? { sessionId } : {}) }));
  });
}
async function evaluate(expression) {
  const result = await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
  return result.result.value;
}
async function key(name) {
  const code = { Enter: 13, Tab: 9 }[name];
  for (const type of ['keyDown', 'keyUp']) await command('Input.dispatchKeyEvent', { type, key: name, code: name, windowsVirtualKeyCode: code, nativeVirtualKeyCode: code,
    ...(name === 'Enter' && type === 'keyDown' ? { text: '\r', unmodifiedText: '\r' } : {}) });
}
async function activate(selector) { await evaluate(`document.querySelector(${JSON.stringify(selector)}).focus()`); await key('Enter'); }
async function fill(selector, value) { await evaluate(`{const control=document.querySelector(${JSON.stringify(selector)});control.value=${JSON.stringify(value)};control.dispatchEvent(new Event('input',{bubbles:true}));}`); }
async function choose(path, click = true) {
  if (click) { const before = chooserCount; await activate('#open-deck-button'); await waitFor(() => chooserCount > before, 'native file chooser requested'); }
  const { root: document } = await command('DOM.getDocument');
  const { nodeId } = await command('DOM.querySelector', { nodeId: document.nodeId, selector: '#open-deck' });
  await command('DOM.setFileInputFiles', { nodeId, files: path ? [path] : [] });
}
const visiblePreview = () => evaluate(`!document.querySelector('#open-preview').hidden`);
const focus = () => evaluate('document.activeElement.id');
const formState = () => evaluate(`({fields:[...document.querySelectorAll('#author-form input,#author-form textarea,#author-form select')].map(e=>({id:e.id,value:e.value,checked:e.checked,disabled:e.disabled})),previewHidden:document.querySelector('#author-preview').hidden,preview:document.querySelector('#preview-content').textContent,downloadDisabled:document.querySelector('#download-deck').disabled,downloadHelp:document.querySelector('#download-help').textContent,undoHidden:document.querySelector('#undo-removal').hidden})`);
async function navigate(url, width = 1200) {
  await command('Emulation.setDeviceMetricsOverride', { width, height: 900, deviceScaleFactor: 1, mobile: false });
  await command('Page.navigate', { url });
  await waitFor(() => evaluate(`document.URL===${JSON.stringify(url)}&&document.readyState==='complete'&&!!document.querySelector('#question-prompt')`), 'author ready');
}
async function download(expected, label) {
  await activate('#check-draft');
  assert.equal(await evaluate(`document.querySelector('#download-deck').disabled`), false);
  const previous = downloadEvents.size;
  await activate('#download-deck');
  await waitFor(() => downloadEvents.size > previous && [...downloadEvents.values()].at(-1)?.state === 'completed', 'actual JSON download');
  const event = [...downloadEvents.values()].at(-1);
  const bytes = await readFile(join(downloads, event.suggestedFilename));
  const value = parseDeck(bytes.toString('utf8'));
  assert.deepEqual(value, expected, `${label}: every metadata, item identity, answer, option and prerequisite survives`);
  report.downloads.push({ label, filename: event.suggestedFilename, sha256: hash(bytes), bytes: bytes.length });
  return bytes;
}
async function screenshot(name) {
  const { data } = await command('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  await writeFile(join(output, name), Buffer.from(data, 'base64'));
}
const pass = name => { report.checks.push(name); console.log(`PASS ${name}`); };

try {
  browser = spawn(executable, ['--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-background-networking', '--disable-component-update', '--disable-sync', '--no-first-run', '--no-default-browser-check', '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', `--user-data-dir=${profile}`, 'about:blank'], { stdio: ['ignore', 'ignore', 'pipe'] });
  browser.stderr.on('data', chunk => { browserLog = (browserLog + chunk).slice(-4000); });
  let startupError;
  browser.on('error', error => { startupError = error; });
  let port, endpoint;
  await waitFor(async () => { if (startupError) throw startupError; [port, endpoint] = (await readFile(join(profile, 'DevToolsActivePort'), 'utf8')).trim().split('\n'); return port && endpoint; }, 'Chromium startup');
  socket = new WebSocket(`ws://127.0.0.1:${port}${endpoint}`);
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id) { const item = pending.get(message.id); if (!item) return; pending.delete(message.id); clearTimeout(item.timer); message.error ? item.no(new Error(message.error.message)) : item.yes(message.result); }
    else if (message.method === 'Runtime.exceptionThrown') report.pageErrors.push(message.params.exceptionDetails.exception?.description ?? message.params.exceptionDetails.text);
    else if (message.method === 'Page.fileChooserOpened') chooserCount++;
    else if (message.method === 'Network.requestWillBeSent') { const url = message.params.request.url; if (!url.startsWith(base) && !/^(file:|data:|blob:)/.test(url)) report.externalRequests.push(url); }
    else if (message.method === 'Browser.downloadWillBegin') downloadEvents.set(message.params.guid, { ...message.params, state: 'started' });
    else if (message.method === 'Browser.downloadProgress') { const item = downloadEvents.get(message.params.guid); if (item) Object.assign(item, message.params); }
  });
  await new Promise((yes, no) => { socket.addEventListener('open', yes, { once: true }); socket.addEventListener('error', no, { once: true }); });
  report.browser = await command('Browser.getVersion', {}, false);
  await command('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: downloads, eventsEnabled: true }, false);
  const { targetId } = await command('Target.createTarget', { url: 'about:blank' }, false);
  ({ sessionId } = await command('Target.attachToTarget', { targetId, flatten: true }, false));
  for (const method of ['Page.enable', 'Runtime.enable', 'Network.enable', 'DOM.enable']) await command(method);
  await command('Page.setInterceptFileChooserDialog', { enabled: true });
  await command('Page.addScriptToEvaluateOnNewDocument', { source: `(() => {const text=File.prototype.text;window.loaderReadCalls=[];window.loaderHeld=new Map();File.prototype.text=function(){window.loaderReadCalls.push(this.name);if(this.name==='unreadable.json')return Promise.reject(new Error('Controlled read error'));if(this.name.startsWith('slow-'))return new Promise((resolve,reject)=>window.loaderHeld.set(this.name,{file:this,resolve,reject}));return text.call(this);};window.releaseLoaderRead=async(name,fail=false)=>{const request=window.loaderHeld.get(name);if(!request)throw new Error('Missing held read');if(fail)request.reject(new Error('Controlled late failure'));else request.resolve(await text.call(request.file));window.loaderHeld.delete(name);};})();` });

  await navigate(`${base}/author/index.html`);
  await fill('#deck-title', 'Unsaved draft: keep my work');
  await fill('#question-prompt', 'This unfinished wording must survive.');
  let before = await formState();
  await choose(firstFile); await waitFor(visiblePreview, 'first incoming preview');
  assert.deepEqual(await formState(), before);
  assert.equal(await focus(), 'open-preview-title');
  assert.ok((await evaluate(`document.querySelector('#open-preview-title').textContent`)).includes(original.title));
  await activate('#cancel-open');
  assert.equal(await focus(), 'open-deck-button');
  assert.deepEqual(await formState(), before);
  assert.equal(await visiblePreview(), false);
  pass('actual file selection and keyboard cancellation preserve the unfinished editor');

  await choose(firstFile); await waitFor(visiblePreview, 'reopened same file');
  await activate('#replace-draft');
  assert.equal(await focus(), 'deck-title');
  assert.equal(await evaluate(`document.querySelector('#deck-title').value`), original.title);
  await download(original, 'reopen actual modular editor download');
  assert.equal(await evaluate(`document.querySelectorAll('[data-receiving="literal"]').length`), 0);
  pass('explicit replacement reexports the actual authored file with exact full-deck fidelity');

  await fill('#deck-title', 'A changed current draft');
  await activate('#check-draft');
  before = await formState();
  for (const [path, text] of [[invalid, 'not valid JSON'], [oversized, '256 KiB'], [unreadable, 'could not be read']]) {
    await choose(path);
    await waitFor(() => evaluate(`document.querySelector('#author-status').textContent.includes(${JSON.stringify(text)})`), text);
    assert.deepEqual(await formState(), before);
    assert.equal(await visiblePreview(), false);
    assert.equal(await focus(), 'open-deck-button');
  }
  assert.equal(await evaluate(`loaderReadCalls.includes('oversized.json')`), false);
  await choose(secondFile); await waitFor(visiblePreview, 'valid retry'); await activate('#cancel-open');
  assert.deepEqual(await formState(), before);
  pass('invalid, oversized and unreadable real files preserve checked content and allow retry');

  await choose(slowSuccess);
  await waitFor(() => evaluate(`loaderHeld.has('slow-success.json')`), 'held first read');
  await fill('#deck-title', 'Writing continues while a file is read');
  before = await formState();
  await choose(secondFile); await waitFor(visiblePreview, 'newer valid preview');
  await evaluate(`releaseLoaderRead('slow-success.json')`);
  assert.deepEqual(await formState(), before);
  assert.equal(await evaluate(`document.querySelector('#open-preview-title').textContent`), `Open “${phone.title}”?`);
  await activate('#replace-draft');
  await download(phone, 'newer file wins slow success');
  await choose(slowFailure); await waitFor(() => evaluate(`loaderHeld.has('slow-failure.json')`), 'held later failure');
  await choose(firstFile); await waitFor(visiblePreview, 'replacement before old failure');
  await activate('#replace-draft');
  before = await formState();
  const status = await evaluate(`document.querySelector('#author-status').textContent`);
  await evaluate(`releaseLoaderRead('slow-failure.json',true)`);
  assert.deepEqual(await formState(), before);
  assert.equal(await evaluate(`document.querySelector('#author-status').textContent`), status);
  pass('out-of-order browser File reads cannot replace a newer deck or overwrite later editor status');

  await choose(slowCancel); await waitFor(() => evaluate(`loaderHeld.has('slow-cancel.json')`), 'cancelled read');
  before = await formState();
  await evaluate(`document.querySelector('#open-deck').dispatchEvent(new Event('cancel'))`);
  await evaluate(`releaseLoaderRead('slow-cancel.json')`);
  assert.equal(await visiblePreview(), false);
  assert.deepEqual(await formState(), before);
  assert.equal(await focus(), 'open-deck-button');
  await choose(secondFile); await waitFor(visiblePreview, 'valid staged before invalid choice');
  await choose(invalid); await waitFor(() => evaluate(`document.querySelector('#author-status').textContent.includes('not valid JSON')`), 'invalid supersedes staged');
  assert.equal(await evaluate(`document.querySelector('#replace-draft').disabled`), true);
  assert.deepEqual(await formState(), before);
  pass('real-DOM cancel event and invalid newer selection retire pending replacements');

  await navigate(pathToFileURL(join(root, 'author.html')).href, 390);
  await command('Network.emulateNetworkConditions', { offline: true, latency: 0, downloadThroughput: 0, uploadThroughput: 0 });
  await choose(longFile); await waitFor(visiblePreview, 'long phone preview');
  const layout = await evaluate(`({width:innerWidth,pageWidth:document.documentElement.scrollWidth,title:[document.querySelector('#open-preview-title').clientWidth,document.querySelector('#open-preview-title').scrollWidth],summary:[document.querySelector('#open-preview-summary').clientWidth,document.querySelector('#open-preview-summary').scrollWidth],markup:document.querySelectorAll('[data-receiving="literal"]').length})`);
  assert.equal(layout.width, 390);
  assert.ok(layout.pageWidth <= layout.width, 'The document fits within the viewport, allowing a native scrollbar.');
  assert.ok(layout.title[1] <= layout.title[0] + 1);
  assert.ok(layout.summary[1] <= layout.summary[0] + 1);
  assert.equal(layout.markup, 0);
  report.phoneLayout = layout;
  await evaluate(`document.querySelector('#open-preview').scrollIntoView({block:'start'})`);
  await screenshot('incoming-phone.png');
  await key('Tab'); assert.equal(await focus(), 'replace-draft');
  await key('Tab'); assert.equal(await focus(), 'cancel-open');
  await key('Enter'); assert.equal(await focus(), 'open-deck-button');
  await choose(secondFile); await waitFor(visiblePreview, 'actual standalone file on phone');
  await activate('#replace-draft');
  await download(phone, 'offline standalone reopen actual phone-authored file');
  await evaluate(`document.querySelector('#author-preview').scrollIntoView({block:'start'})`);
  await screenshot('reopened-phone.png');
  pass('offline standalone at 390 px keeps long incoming content readable and keyboard actions usable');

  assert.deepEqual(report.pageErrors, []);
  assert.deepEqual(report.externalRequests, []);
  for (const [path, sha] of Object.entries(report.sources)) assert.equal(hash(await readFile(join(root, path))), sha, `${path} changed during receiving`);
  report.status = 'passed';
  report.fileChooserRequests = chooserCount;
} catch (error) {
  report.status = 'failed'; report.error = error.stack;
  try { await screenshot('failure.png'); } catch {}
  process.exitCode = 1;
} finally {
  if (socket?.readyState === WebSocket.OPEN) { try { await command('Browser.close', {}, false); } catch {} socket.close(); }
  if (browser && browser.exitCode === null) { browser.kill('SIGTERM'); await Promise.race([new Promise(done => browser.once('exit', done)), delay(2000)]); if (browser.exitCode === null) browser.kill('SIGKILL'); }
  await new Promise(done => server.close(done));
  await rm(profile, { recursive: true, force: true });
  for (const request of pending.values()) clearTimeout(request.timer);
  await writeFile(join(output, 'receiving.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, checks: report.checks.length, report: join(output, 'receiving.json'), error: report.error }));
}
