import assert from 'node:assert/strict';

export const GAMETES = Object.freeze(['AB', 'Ab', 'aB', 'ab']);
const offspring = Object.freeze(['AaBb', 'Aabb', 'aaBb', 'aabb']);
export function fraction(n, d = 200) {
  assert.ok(Number.isSafeInteger(n) && Number.isSafeInteger(d) && n >= 0 && d > 0);
  let a = n, b = d;
  while (b) [a, b] = [b, a % b];
  return {numerator: n / a, denominator: d / a};
}
export function reference(phase, percent) {
  assert.ok(['coupling', 'repulsion'].includes(phase));
  assert.ok(Number.isInteger(percent) && percent >= 0 && percent <= 50);
  const homologs = phase === 'coupling' ? ['AB', 'ab'] : ['Ab', 'aB'];
  const counts = new Map(GAMETES.map(g => [g, 0]));
  // 200 equally weighted analytic slots, NOT 200 meioses or a finite-sample quota.
  // Each homolog contributes 100 slots. In p of them, combine its first
  // allele with the other homolog's second allele.
  for (let h = 0; h < 2; h++) {
    for (let slot = 0; slot < 100; slot++) {
      const g = homologs[h][0] + homologs[slot < percent ? 1 - h : h][1];
      counts.set(g, counts.get(g) + 1);
    }
  }
  const rows = GAMETES.map((gamete, i) => ({
    gamete, kind: homologs.includes(gamete) ? 'parental' : 'recombinant',
    probability: fraction(counts.get(gamete)), offspringGenotype: offspring[i],
  }));
  const sum = predicate => [...counts].filter(([g]) => predicate(g)).reduce((s, [, n]) => s + n, 0);
  return {
    format: 'recallweave-genetic-linkage/1',
    input: {phase, recombinationPercent: percent === 0 ? 0 : percent},
    parent: {genotype: 'AaBb', homologs},
    tester: {genotype: 'aabb', gamete: 'ab'},
    rows,
    totals: {
      parental: fraction(sum(g => homologs.includes(g))),
      recombinant: fraction(sum(g => !homologs.includes(g))),
      all: fraction(sum(() => true)),
    },
    marginals: Object.fromEntries(['A', 'a', 'B', 'b'].map(a => [a, fraction(sum(g => g.includes(a)))])),
    independentComparison: {probability: {numerator: 1, denominator: 4}, matches: percent === 50},
  };
}
export function assertResult(actual, phase, percent) {
  assert.deepEqual(Object.keys(actual).sort(),
    ['format','input','assumptions','parent','tester','rows','totals','marginals','independentComparison'].sort());
  const {assumptions, ...projection} = actual;
  assert.deepEqual(projection, reference(phase, percent));
  assert.ok(Array.isArray(assumptions) && assumptions.length > 0, 'assumptions must be nonempty text array');
  for (const s of assumptions) assert.ok(typeof s === 'string' && s.trim().length > 0);
  assert.equal(new Set(assumptions).size, assumptions.length);
  // All model numbers are finite and this structure must survive JSON exactly.
  assert.deepEqual(JSON.parse(JSON.stringify(actual)), actual);
}
export function assertFrozen(value, path = '$', seen = new Set()) {
  if (!value || typeof value !== 'object' || seen.has(value)) return;
  seen.add(value);
  assert.ok(Object.isFrozen(value), path + ' must be frozen');
  for (const key of Reflect.ownKeys(value)) {
    const d = Object.getOwnPropertyDescriptor(value, key);
    assert.ok('value' in d, path + ' must not contain accessor');
    assertFrozen(d.value, path + '.' + String(key), seen);
  }
}
export function descriptorSnapshot(obj) {
  return {prototype: Object.getPrototypeOf(obj), keys: Reflect.ownKeys(obj),
    descriptors: Object.getOwnPropertyDescriptors(obj), extensible: Object.isExtensible(obj)};
}
export function plainMock(phase, percent) {
  return {...reference(phase, percent), assumptions: ['Independent calibration placeholder; no candidate assumption wording.']};
}
