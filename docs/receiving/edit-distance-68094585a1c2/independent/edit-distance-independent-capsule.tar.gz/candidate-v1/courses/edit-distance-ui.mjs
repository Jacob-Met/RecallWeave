import {POLICY, EXAMPLES, analyzeEditDistance} from './edit-distance-core.mjs';

const $ = id => document.getElementById(id);
const sourceInput = $('source'), targetInput = $('target');
const courseText = JSON.stringify(JSON.parse($('course-data').textContent), null, 2) + '\n';
let comparison = null, comparisonText = '', selected = [0, 0], revealed = 0;
const pointCode = point => 'U+' + point.codePointAt(0).toString(16).toUpperCase().padStart(4, '0');
const names = new Map([[0, 'NUL'], [9, 'tab'], [10, 'line feed'], [13, 'carriage return'], [32, 'space'], [160, 'no-break space'], [0x200d, 'zero width joiner']]);
function visible(point) {
  if (point === null) return 'gap';
  const code = point.codePointAt(0);
  if (names.has(code)) return names.get(code);
  if (code < 32 || (code >= 0x7f && code <= 0x9f) || (code >= 0x202a && code <= 0x202e) || (code >= 0x2066 && code <= 0x2069)) return pointCode(point);
  return JSON.stringify(point);
}
function node(tag, text, className) {
  const element = document.createElement(tag);
  if (text !== undefined) element.textContent = text;
  if (className) element.className = className;
  return element;
}
function countLabel(value) {
  let count = 0;
  for (const ignored of value) {
    count++;
    if (count > POLICY.maxCodePoints) return 'More than 24 code points — shorten to compare';
  }
  return count + ' / 24 code points' + (count === 0 ? ' · empty is valid' : '');
}
function draftState() {
  $('source-count').textContent = countLabel(sourceInput.value);
  $('target-count').textContent = countLabel(targetInput.value);
  const matches = comparison && sourceInput.value === comparison.source && targetInput.value === comparison.target;
  $('download-comparison').disabled = !matches;
  $('comparison').classList.toggle('stale', Boolean(comparison && !matches));
  $('draft-state').textContent = matches ? 'The table and download match these inputs.' : comparison ? 'Draft changed. The table still shows the previous comparison. Compare again to update and download.' : 'Choose Compare to build the table.';
}
function updateMatrixSelection() {
  if (!comparison) return;
  const path = new Set(['0,0', ...comparison.alignment.map(step => step.to.join(','))]);
  const shown = new Set(['0,0', ...comparison.alignment.slice(0, revealed).map(step => step.to.join(','))]);
  for (const button of $('prefix-matrix').querySelectorAll('button')) {
    const id = button.dataset.i + ',' + button.dataset.j;
    const active = id === selected.join(',');
    button.setAttribute('aria-pressed', String(active));
    button.tabIndex = active ? 0 : -1;
    button.classList.toggle('on-path', path.has(id));
    button.classList.toggle('revealed', shown.has(id));
  }
}
function inspectCell(i, j, focus = false) {
  selected = [i, j];
  const cell = comparison.cells[i][j];
  $('cell-title').textContent = 'D[' + i + '][' + j + '] = ' + cell.cost;
  $('cell-prefixes').textContent = 'Source prefix ' + JSON.stringify(comparison.sourcePoints.slice(0, i).join('')) +
    ' → target prefix ' + JSON.stringify(comparison.targetPoints.slice(0, j).join(''));
  const list = $('candidate-list');
  list.replaceChildren();
  for (const candidate of cell.candidates) {
    const [pi, pj] = candidate.from;
    const parentCost = comparison.matrix[pi][pj];
    const action = candidate.operation === 'match' ? 'Match' : candidate.operation === 'substitute' ? 'Substitute' : candidate.operation === 'delete' ? 'Delete source' : 'Insert target';
    const item = node('li', action + ': D[' + pi + '][' + pj + '] + ' + candidate.stepCost + ' = ' +
      parentCost + ' + ' + candidate.stepCost + ' = ' + candidate.totalCost + (candidate.optimal ? ' · optimal' : ''), candidate.optimal ? 'optimal' : '');
    item.append(node('small', comparison.cells[pi][pj].optimalPathCount + ' optimal path(s) to this predecessor' +
      (candidate.optimal ? ' contribute to the count.' : '; this more expensive move contributes none.')));
    list.append(item);
  }
  const optimal = cell.candidates.filter(candidate => candidate.optimal);
  $('tie-note').textContent = optimal.length
    ? cell.optimalPathCount + ' optimal path(s) reach this prefix. ' + (optimal.length > 1 ? 'There is a tie. ' : '') +
      'Canonical backtrace here chooses ' + optimal[0].operation + '.'
    : 'Empty → empty costs 0. There is one empty path and no predecessor.';
  updateMatrixSelection();
  if (focus) {
    const button = $('prefix-matrix').querySelector('button[data-i="' + i + '"][data-j="' + j + '"]');
    button.focus({preventScroll: true});
    button.scrollIntoView({block: 'nearest', inline: 'nearest'});
  }
}
function renderMatrix() {
  const table = $('prefix-matrix');
  table.replaceChildren(node('caption', 'D[i][j] · rows: source prefix i · columns: target prefix j'));
  const head = document.createElement('thead'), heading = document.createElement('tr');
  heading.append(node('th', 'i ↓ / j →'));
  for (let j = 0; j <= comparison.targetPoints.length; j++) {
    const th = node('th', j + '\n' + (j ? visible(comparison.targetPoints[j - 1]) : 'empty'));
    th.scope = 'col';
    th.title = j ? 'Target prefix length ' + j + '; last point ' + pointCode(comparison.targetPoints[j - 1]) : 'Empty target prefix';
    heading.append(th);
  }
  head.append(heading); table.append(head);
  const body = document.createElement('tbody');
  for (let i = 0; i <= comparison.sourcePoints.length; i++) {
    const row = document.createElement('tr');
    const th = node('th', i + '\n' + (i ? visible(comparison.sourcePoints[i - 1]) : 'empty'));
    th.scope = 'row';
    th.title = i ? 'Source prefix length ' + i + '; last point ' + pointCode(comparison.sourcePoints[i - 1]) : 'Empty source prefix';
    row.append(th);
    for (let j = 0; j <= comparison.targetPoints.length; j++) {
      const cell = comparison.cells[i][j], td = document.createElement('td');
      const button = node('button', String(cell.cost));
      button.type = 'button'; button.dataset.i = String(i); button.dataset.j = String(j);
      button.setAttribute('aria-label', 'Source prefix ' + i + ', target prefix ' + j + ', cost ' + cell.cost + ', ' + cell.optimalPathCount + ' optimal paths');
      td.append(button); row.append(td);
    }
    body.append(row);
  }
  table.append(body);
}
function token(point, index, side) {
  const box = document.createElement('div');
  const value = node('strong', visible(point), 'token');
  value.dir = 'auto';
  box.append(value, node('span', point === null ? 'No ' + side + ' code point' : side + '[' + index + '] · ' + pointCode(point), 'token-meta'));
  return box;
}
function renderAlignment() {
  const all = comparison.alignment;
  const list = $('alignment-columns'); list.replaceChildren();
  let cost = 0;
  for (const step of all.slice(0, revealed)) {
    cost += step.cost;
    const item = node('li');
    item.append(node('span', 'Column ' + step.step, 'step-number'));
    const pair = node('div', undefined, 'token-pair');
    pair.append(token(step.source, step.sourceIndex, 'Source'), token(step.target, step.targetIndex, 'Target'));
    item.append(pair, node('div', step.operation + ' · +' + step.cost + ' · total ' + cost, 'operation'));
    list.append(item);
  }
  list.hidden = revealed === 0;
  $('alignment-empty').hidden = revealed !== 0;
  $('alignment-empty').textContent = all.length ? 'No columns revealed yet. Choose Next to follow the alignment.' : 'Both inputs are empty: zero columns, zero edits, one empty path.';
  $('step-status').textContent = revealed + ' of ' + all.length + ' alignment columns revealed';
  const [i, j] = revealed ? all[revealed - 1].to : [0, 0];
  $('alignment-summary').textContent = 'Consumed ' + i + ' source and ' + j + ' target code points; running cost ' + cost +
    '. Target prefix: ' + JSON.stringify(comparison.targetPoints.slice(0, j).join('')) + '. Complete minimum cost: ' + comparison.distance + '.';
  $('previous-step').disabled = revealed === 0;
  $('next-step').disabled = revealed === all.length;
  $('show-all').disabled = revealed === all.length;
  updateMatrixSelection();
}
function compare(focus = true) {
  $('input-error').hidden = true;
  sourceInput.removeAttribute('aria-invalid'); targetInput.removeAttribute('aria-invalid');
  let next;
  try { next = analyzeEditDistance(sourceInput.value, targetInput.value); }
  catch (error) {
    $('input-error').textContent = error.message;
    $('input-error').hidden = false;
    (error.message.startsWith('Source') ? sourceInput : targetInput).setAttribute('aria-invalid', 'true');
    draftState();
    if (focus) $('input-error').focus();
    return;
  }
  comparison = next;
  comparisonText = JSON.stringify(next, null, 2) + '\n';
  revealed = 0;
  $('distance').textContent = String(next.distance);
  $('path-count').textContent = next.optimalPathCount;
  $('lengths').textContent = next.sourcePoints.length + ' → ' + next.targetPoints.length;
  $('applied-source').textContent = JSON.stringify(next.source);
  $('applied-target').textContent = JSON.stringify(next.target);
  renderMatrix(); inspectCell(next.sourcePoints.length, next.targetPoints.length); renderAlignment(); draftState();
  if (focus) $('matrix-title').focus();
}
function download(text, filename) {
  const url = URL.createObjectURL(new Blob([text], {type: 'application/json;charset=utf-8'}));
  const link = document.createElement('a');
  link.href = url; link.download = filename; link.hidden = true;
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
$('compare-form').addEventListener('submit', event => { event.preventDefault(); compare(); });
for (const input of [sourceInput, targetInput]) {
  input.addEventListener('input', () => {
    input.removeAttribute('aria-invalid'); $('input-error').hidden = true; draftState();
  });
}
$('prefix-matrix').addEventListener('click', event => {
  const button = event.target.closest('button[data-i]');
  if (button) inspectCell(Number(button.dataset.i), Number(button.dataset.j));
});
$('prefix-matrix').addEventListener('keydown', event => {
  const button = event.target.closest('button[data-i]');
  if (!button) return;
  const moves = {ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1]};
  if (!Object.hasOwn(moves, event.key)) return;
  event.preventDefault();
  const [di, dj] = moves[event.key];
  inspectCell(Math.max(0, Math.min(comparison.sourcePoints.length, Number(button.dataset.i) + di)),
    Math.max(0, Math.min(comparison.targetPoints.length, Number(button.dataset.j) + dj)), true);
});
for (const [id, change] of [['previous-step', -1], ['next-step', 1], ['show-all', Infinity]]) {
  $(id).addEventListener('click', () => {
    revealed = Math.max(0, Math.min(comparison.alignment.length, revealed + change));
    renderAlignment();
    const [i, j] = revealed ? comparison.alignment[revealed - 1].to : [0, 0];
    inspectCell(i, j);
    $('alignment-columns').lastElementChild?.scrollIntoView({block: 'nearest', inline: 'nearest'});
  });
}
for (const example of EXAMPLES) {
  const option = node('option', example.label); option.value = example.id; $('example').append(option);
}
function loadExample(focus = true) {
  const example = EXAMPLES.find(item => item.id === $('example').value);
  sourceInput.value = example.source; targetInput.value = example.target; compare(focus);
}
$('load-example').addEventListener('click', () => loadExample());
$('download-comparison').addEventListener('click', () => {
  draftState();
  if (!$('download-comparison').disabled) download(comparisonText, 'recallweave-edit-distance-comparison.json');
});
$('download-course').addEventListener('click', () => download(courseText, 'recallweave-edit-distance-course.json'));
loadExample(false);
