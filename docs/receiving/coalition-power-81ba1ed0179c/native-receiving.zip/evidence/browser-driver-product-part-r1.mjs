
import {execFileSync} from 'node:child_process';
import {copyFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {analyzeGame} from '../courses/coalition-power-core.mjs';
async function receive(){
 const [outputArg,executable]=process.argv.slice(2);
 if(!outputArg||!executable)throw new Error('Usage: node tools/check-coalition-power.mjs <new-output-dir> <Chrome>');
 const output=resolve(outputArg);await mkdir(output);
 const root=fileURLToPath(new URL('../',import.meta.url)),page=join(root,'courses/coalition-power-explorer.html');
 const receipt={at:new Date().toISOString(),source:{},groups:[],downloads:[],screenshots:[],artifacts:[],cleanup:null};
 for(const p of ['courses/coalition-power.json','courses/coalition-power.md','courses/coalition-power-core.mjs','courses/coalition-power-explorer-ui.mjs','courses/coalition-power-explorer.template.html','courses/coalition-power-explorer.html','tools/build-coalition-power.mjs','tools/check-coalition-power.mjs','tests/coalition-power.test.mjs'])receipt.source[p]=sha256(await readFile(join(root,p)));
 const course=await readFile(join(root,'courses/coalition-power.json')),guide=await readFile(join(root,'courses/coalition-power.md')),deck=JSON.parse(course);
 let b,courseDownload;
 const group=async(name,fn)=>{await fn();receipt.groups.push({name,passed:true});console.log('PASS '+name);};
 const fill=async(id,text)=>{
  await b.evaluate('(()=>{const e=document.getElementById('+JSON.stringify(id)+');e.focus();e.select();})()');
  await b.command('Input.insertText',{text});
 };
 const set=async(weights,quota)=>{await fill('weights',weights);await fill('quota',quota);};
 const download=async selector=>{const d=await b.download(selector);receipt.downloads.push({path:d.path,bytes:d.bytes.length,sha256:d.sha256,name:d.suggestedFilename,completed:d.completed.state});return d;};
 const observation=(weights,quota,index=1,critical=false)=>JSON.stringify({format:'recallweave-coalition-power-observation/1',analysis:analyzeGame(weights,quota),view:{player_index:index,critical_only:critical}},null,2)+'\n';
 const click=async selector=>{
  const r=await b.evaluate('(()=>{const r=document.querySelector('+JSON.stringify(selector)+').getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()');
  await b.command('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...r});
  await b.command('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...r});
 };
 try{
  b=await openBrowser(output,executable);receipt.browser=b.version;receipt.pid=b.childPid;receipt.profile=b.profile;
  await b.navigate(page,1280,1000);
  await until(()=>b.evaluate('!document.querySelector("#result").hidden'),'applied authored game');
  await group('Default visible table and cards retain exact critical membership and two denominators',async()=>{
   assert.deepEqual(await b.evaluate('[...document.querySelectorAll("#metrics strong")].map(e=>e.textContent)'),['8','3','5','7']);
   assert.equal(await b.evaluate('document.querySelectorAll("#coalitions tr").length'),8);
   assert.deepEqual(await b.evaluate('[...document.querySelectorAll("#coalitions tr")].map(r=>r.lastElementChild.textContent)'),['none','none','none','A, B','none','A, C','none','A']);
   assert.match(await b.evaluate('document.querySelector(".player").textContent'),/3\/4.*3\/5/);
  });
  await group('Actual default observation is the exact applied analysis and view wrapper',async()=>{
   const d=await download('#observation-save');assert.equal(d.bytes.toString(),observation([6,4,2],7));
   assert.equal(d.suggestedFilename,'coalition-power-observation.json');
  });
  await group('Course and worked-guide downloads preserve exact source bytes and distinct formats',async()=>{
   courseDownload=await download('#course-save');assert.deepEqual(courseDownload.bytes,course);
   assert.equal(courseDownload.suggestedFilename,'coalition-power-course.json');
   const d=await download('#guide-save');assert.deepEqual(d.bytes,guide);
   assert.equal(d.suggestedFilename,'coalition-power-guide.md');
  });
  await group('Actual keyboard edits immediately retire results and malformed values cannot export',async()=>{
   await set('6, 4, -0','7');
   assert.equal(await b.evaluate('document.querySelector("#result").hidden && document.querySelector("#observation-save").disabled'),true);
   await b.activate('#apply');assert.match(await b.evaluate('document.querySelector("#status").textContent'),/without signs/);
   assert.equal(await b.evaluate('document.querySelector("#result").hidden'),true);
   await set('6,4,2','13');await b.activate('#apply');
   assert.match(await b.evaluate('document.querySelector("#status").textContent'),/1 through 12/);
   assert.equal(await b.evaluate('document.querySelector("#observation-save").disabled'),true);
  });
  await group('A preset remains unapplied until explicit Apply and a dummy has no invented witness',async()=>{
   await b.activate('[data-preset="5,3,1|7"]');
   assert.equal(await b.evaluate('document.querySelector("#result").hidden'),true);
   await b.activate('#apply');
   await b.evaluate('document.querySelector("#player").focus()');await b.key('End');
   assert.equal(await b.evaluate('document.querySelector("#player").value'),'3');
   await click('#critical-only');
   assert.equal(await b.evaluate('document.querySelectorAll("#coalitions tr").length'),0);
   assert.equal(await b.evaluate('document.querySelector("#no-rows").hidden'),false);
   assert.match(await b.evaluate('document.querySelector("#witnesses").textContent'),/No swing exists/);
   assert.deepEqual(await b.evaluate('[...document.querySelectorAll(".count")].map(e=>e.textContent)'),['2 swings','2 swings','0 swings']);
   const d=await download('#observation-save');assert.equal(d.bytes.toString(),observation([5,3,1],7,3,true));
  });
  await group('Zero-weight addition doubles raw counts and retains reduced measures and ordinals',async()=>{
   await set('6,4,2,0','7');await b.activate('#apply');
   assert.deepEqual(await b.evaluate('[...document.querySelectorAll(".count")].map(e=>e.textContent)'),['6 swings','2 swings','2 swings','0 swings']);
   assert.equal(await b.evaluate('document.querySelectorAll("#coalitions tr").length'),16);
   assert.match(await b.evaluate('document.querySelector(".player").textContent'),/3\/4.*3\/5/);
   assert.equal(await b.evaluate('document.querySelector("#player option:last-child").textContent'),'D · weight 0');
  });
  await group('Largest six-player game keeps all 64 rows and exact observation',async()=>{
   await set('20,20,20,20,20,20','120');await b.activate('#apply');
   assert.equal(await b.evaluate('document.querySelectorAll("#coalitions tr").length'),64);
   assert.equal(await b.evaluate('document.querySelector("#coalitions tr:last-child").lastElementChild.textContent'),'A, B, C, D, E, F');
   assert.match(await b.evaluate('document.querySelector(".player").textContent'),/1\/32.*1\/6/);
   const d=await download('#observation-save');assert.equal(d.bytes.toString(),observation([20,20,20,20,20,20],120));
  });
  await group('Actual Letter PDF preserves complete maximum table, exact measures and model limits',async()=>{
   await b.viewport(739,1000);await b.command('Emulation.setEmulatedMedia',{media:'print'});
   const pdf=await b.command('Page.printToPDF',{printBackground:true,paperWidth:8.5,paperHeight:11,marginTop:.4,marginBottom:.4,marginLeft:.4,marginRight:.4});
   const bytes=Buffer.from(pdf.data,'base64'),path=join(output,'coalition-power.pdf');await writeFile(path,bytes);
   const text=execFileSync('pdftotext',['-layout',path,'-'],{encoding:'utf8'});await writeFile(join(output,'print.txt'),text);
   for(const s of ['quota 120','64 coalitions','1/32','1/6','A, B, C, D, E, F','coordination','fairness'])assert.ok(text.includes(s),'PDF missing '+s);
   receipt.artifacts.push({path,bytes:bytes.length,sha256:sha256(bytes)});await b.command('Emulation.setEmulatedMedia',{media:''});
  });
  await group('One-player edge includes the empty other-player coalition without fictitious peers',async()=>{
   await set('1','1');await b.activate('#apply');
   assert.equal(await b.evaluate('document.querySelectorAll("#coalitions tr").length'),2);
   assert.equal(await b.evaluate('document.querySelectorAll("#player option").length'),1);
   assert.match(await b.evaluate('document.querySelector("#witnesses").textContent'),/none \(empty\).*0 loses.*1 passes/);
   assert.match(await b.evaluate('document.querySelector(".player").textContent'),/1\/1.*1\/1/);
  });
  await group('Desktop and 390-pixel phone retain readable controls without page overflow',async()=>{
   await set('6,4,2','7');await b.activate('#apply');
   await b.viewport(1280,1000);
   assert.ok(await b.evaluate('document.documentElement.scrollWidth<=innerWidth'));
   receipt.screenshots.push(await b.screenshot('desktop.png'));
   await b.viewport(390,844);
   assert.ok(await b.evaluate('document.documentElement.scrollWidth<=innerWidth'));
   assert.equal(await b.evaluate('document.querySelectorAll("#coalitions tr").length'),8);
   receipt.screenshots.push(await b.screenshot('phone.png'));
  });
  await group('Fresh relocated standalone page works with network offline and exact embedded downloads',async()=>{
   const dir=join(output,'relocated');await mkdir(dir);const path=join(dir,'explorer.html');await copyFile(page,path);
   await b.navigate(path,390,844);await until(()=>b.evaluate('!document.querySelector("#result").hidden'),'relocated applied game');
   assert.equal(await b.evaluate('document.querySelectorAll("#coalitions tr").length'),8);
   const d=await download('#course-save');assert.deepEqual(d.bytes,course);
   assert.ok(b.requests.every(x=>x.startsWith('file:')));assert.equal(b.errors.length,0);
  });
  await group('Downloaded course enters unchanged learner preview before explicit Start',async()=>{
   await b.navigate(join(root,'demo.html'),1280,1000);
   const {root:dom}=await b.command('DOM.getDocument');
   const {nodeId}=await b.command('DOM.querySelector',{nodeId:dom.nodeId,selector:'#deck-file'});
   await b.command('DOM.setFileInputFiles',{nodeId,files:[courseDownload.path]});
   await until(()=>b.evaluate('document.querySelector("#deck-preview-title")?.textContent === '+JSON.stringify(deck.title)),'course preview');
   assert.equal(await b.evaluate('document.querySelectorAll("#deck-preview ol li").length'),12);
   assert.equal(await b.evaluate('document.querySelector("#step-count").textContent'),'0 / 6');
   await b.activate('#start-deck');
   await until(()=>b.evaluate('document.querySelector("#step-count").textContent.includes("/ 12")'),'explicit course start');
   assert.match(await b.evaluate('document.querySelector("#deck-status").textContent'),/Started/);
   receipt.screenshots.push(await b.screenshot('learner-start.png'));
  });
  await group('No runtime exception or external request is observed',async()=>{
   assert.equal(b.errors.length,0);assert.ok(b.requests.every(x=>x.startsWith('file:')));
   receipt.requests=[...b.requests];receipt.errors=[...b.errors];
  });
  receipt.accepted=true;
 }catch(error){receipt.accepted=false;receipt.error=String(error.stack??error);if(b){try{receipt.failureState=await b.evaluate('({url:location.href,status:document.querySelector("#status")?.textContent,weights:document.querySelector("#weights")?.value,quota:document.querySelector("#quota")?.value,resultHidden:document.querySelector("#result")?.hidden})');}catch{}}throw error;}
 finally{if(b){await b.close();receipt.cleanup={closed:true,profileRemoved:true};}await writeFile(join(output,'browser-receiving.json'),JSON.stringify(receipt,null,2)+'\n');}
}
receive().catch(error=>{console.error(error);process.exitCode=1;});
