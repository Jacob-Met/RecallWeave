import base64,gzip,hashlib,io,json,os,re,subprocess,tarfile,time
from pathlib import Path
old=Path("/tmp/hamon-7a9310dad255-recall19-integration")
middle=Path("/dev/shm/hamon-7a9310dad255-recall19-integration-current")
root=middle/"current-8b82"
candidate=root/"candidate"
proof=Path("docs/receiving/probability-course-7a9310dad255/current-importer-adoption")
expected=json.loads((middle/"expected-final-8b82.json").read_text())
freeze=json.loads((root/"pre-ci-source-manifest.json").read_text())
def pin(data):
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
def tree_id(rows):
    tree={}
    for row in rows:
        node=tree;parts=row["path"].split("/")
        for part in parts[:-1]:node=node.setdefault(part,{})
        assert parts[-1] not in node
        node[parts[-1]]=(row["mode"],row.get("git_blob",row.get("sha")))
    def emit(node):
        data=b""
        for name,item in sorted(node.items(),key=lambda x:(x[0]+("/" if isinstance(x[1],dict) else "")).encode()):
            mode,sha=("40000",emit(item)) if isinstance(item,dict) else item
            data+=mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(sha)
        return hashlib.sha1(b"tree "+str(len(data)).encode()+b"\0"+data).hexdigest()
    return emit(tree)
def snapshot():
    rows=[]
    for p in sorted(candidate.rglob("*")):
        assert not p.is_symlink()
        if p.is_file():rows.append({"path":str(p.relative_to(candidate)),"mode":"100755" if p.stat().st_mode&0o111 else "100644",**pin(p.read_bytes())})
    return rows
def write_json(path,value):
    with path.open("x") as f:json.dump(value,f,indent=2);f.write("\n")
assert snapshot()==freeze["files"]
members={}
def add(name,path):
    assert name not in members
    members[name]=Path(path).read_bytes()
for label,where in [("d202",old),("c00",middle),("8b82",root)]:
    for filename in ["capture-composition-receipt.json","pre-ci-source-manifest.json","run_required_native_ci.py"]:
        add("capture/"+label+"/"+filename,where/filename)
    for p in sorted((where/"required-native-ci").iterdir()):
        if p.is_file():add("native-ci/"+label+"/"+p.name,p)
    result=json.loads((where/"required-native-ci/receipt.json").read_text())
    assert result["completed"] and result["all_source_files_unchanged"]
    assert all(x["exit"]==0 and x["stderr"]["bytes"]==0 for x in result["commands"])
add("source-context/expected-original-d202.json",old/"expected-public-inputs.json")
add("source-context/expected-current-c00.json",old/"expected-current-c00.json")
add("source-context/expected-final-8b82.json",middle/"expected-final-8b82.json")
for name,path in [
("scripts/capture-original.py",old/"capture_compose.py"),
("scripts/add-original-supplement.py",old/"add_adoption_supplement.py"),
("scripts/failed-c00-full-capture.py",old/"compose_current_c00.py"),
("scripts/cleanup-original.py",old/"cleanup-script-original.py"),
("scripts/capture-c00-workflow-source.py",middle/"capture_current_source.py"),
("scripts/capture-8b82-workflow-source.py",middle/"capture_final_8b82.py"),
("scripts/package-preparation.py",root/"package_prepared_integration.py"),
("setup/raw-recovery.json",old/"native-recovery-raw.json"),
("setup/recovery-summary.json",root/"recovery-summary.json"),
("setup/retired-d202-process-read.json",old/"d202-late-process-read.json"),
("execution/d202-observation.json",old/"d202-execution-observation.json"),
("execution/c00-rdc.json",middle/"c00-native-execution-rdc.json"),
("execution/8b82-rdc.json",root/"native-execution-rdc.json"),
("source-variants/d202-adoption-README.md",old/"candidate"/proof/"README.md"),
("source-variants/c00-adoption-README.md",middle/"candidate"/proof/"README.md"),
("authority.json",root/"authority.json")]:add(name,path)
manifest={"format":"recallweave-probability-integration-evidence/1","members":[{"path":name,**pin(data)} for name,data in sorted(members.items())],"notes":"Raw inputs, source manifests, exact native output and setup failures. No executable/dependency binaries or duplicate public source archives."}
members["manifest.json"]=(json.dumps(manifest,indent=2)+"\n").encode()
archive_path=candidate/proof/"native-evidence.tar.gz"
with archive_path.open("xb") as out:
    with gzip.GzipFile(filename="",fileobj=out,mode="wb",mtime=0,compresslevel=9) as gz:
        with tarfile.open(fileobj=gz,mode="w") as tar:
            for name,data in sorted(members.items()):
                item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
                tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive_path,"r:gz") as tar:
    assert len(tar.getmembers())==len(members)
    for item in tar:
        assert item.isfile() and tar.extractfile(item).read()==members[item.name]
archive_pin=pin(archive_path.read_bytes())
ci=[]
for label,where,count in [("d202",old,128),("c00",middle,137),("8b82",root,191)]:
    raw=(where/"required-native-ci/receipt.json").read_bytes();report=json.loads(raw)
    assert "# pass "+str(count)+"\n" in report["test_summary"]
    ci.append({"source_label":label,"parent":report["current_parent"],"physical_source_tree":report["source_tree"],"proposed_full_tree":report.get("proposed_full_tree",report["source_tree"]),"physical_files":report["source_files"],"passed":count,"failed":0,"commands_all_exit_zero":True,"all_stderr_empty":True,"all_captured_files_unchanged":True,"demo_parity":report["demo"],"node":report["node"],"python":report["python"],"native_receipt":{"archive_path":"native-ci/"+label+"/receipt.json",**pin(raw)},"started_at_utc":report["started_at_utc"],"finished_at_utc":report["finished_at_utc"],"seconds":report["seconds"]})
qualification={"format":"recallweave-probability-current-adoption/1","prepared":True,"repository":expected["repository"],"pr":19,"expected_original_head":expected["course_head"],"prepared_parent":expected["current_head"],"prepared_parent_tree":expected["current_tree"],"tested_proposed_full_tree_before_two_evidence_files":freeze["proposed_full_tree"],"native_physical_tree_before_two_evidence_files":freeze["source_tree"],"source_preservation":{"incoming_public_files":583,"captured_current_source_files":102,"omitted_current_proof_documentation_files":481,"original_contribution_files_unchanged":28,"original_course_json":pin((candidate/"courses/probability-foundations.json").read_bytes()),"all_incoming_blobs_and_git_modes_preserved":True,"all_14_received_learner_inputs_exact":True,"new_files":"Five proof-only adoption files; no learner, default deck, schema, styles, builders, dependencies or existing course/proof file changes."},"importer_adoption":{"owner":"490fcd7c4056","merged_head":"d8a9ff81e8e5290e8daad5b4af957d4eddc0ee74","proof_commit":"4487260efca6819f152435af9cf0a1b64a978d61","handoff":"https://github.com/Jacob-Met/RecallWeave/pull/19#issuecomment-6060533777","owner_archive_sha256":"4e57c0269a4debbf5080f9169949360156ee30b33fc444afd2749e45cb9c93d8","owner_archive_files":92,"accepted_owner_browser_groups":6,"actual_downloads":18,"new_browser_execution_in_this_preparation":False,"independent_assessment":pin((candidate/proof/"independent-assessment.json").read_bytes()),"accepted_d202_compatibility":pin((candidate/proof/"current-d202-compatibility.json").read_bytes())},"native_ci":ci,"workflow":{"path":".github/workflows/test.yml","git_blob":"a64c95e06e656a1875706bc013c13b82ccf8ca83","required_commands":["node --test tests/*.test.mjs","python3 tools/make_demo.py","cmp own-saved-demo-before.html demo.html"],"native_invocation_adjustments":"Unique owned temporary demo path; Python -B and PYTHONDONTWRITEBYTECODE=1 keep source clean. Test semantics and workflow file are unchanged.","hosted_node_major":20,"native_node":"22.22.1","remaining_gate":"Root must publish, inspect actual-head hosted Node20 CI and refresh actual-parent/ownership before readiness or merge."},"original_patch":pin((old/"original-course-28.patch").read_bytes()),"evidence_archive":{"path":"native-evidence.tar.gz",**archive_pin,"member_count":len(members),"all_members_read_back_exact":True,"manifest":pin(members["manifest.json"])},"setup_failures":"Exact quota failure, original failed helper, cleanup assertion, raw readback and retired-process read are retained in the archive. No failed setup is counted as a passing source run.","boundary":"This is local/native integration preparation, not a branch update, PR readiness change, merge, deployed application result or new learning-effectiveness claim."}
write_json(candidate/proof/"qualification.json",qualification)
final=snapshot();prior_map={x["path"]:x for x in freeze["files"]};fm={x["path"]:x for x in final}
assert len(final)==135 and all(fm[p]==x for p,x in prior_map.items())
public=expected["current_entries"];public_paths={x["path"] for x in public}
contribution=[x for x in final if x["path"] not in public_paths];assert len(contribution)==33
orig={x["path"]:x for x in expected["course_entries"]}
assert all(fm[p]["git_blob"]==x["sha"] and fm[p]["mode"]==x["mode"] for p,x in orig.items())
full=[{"path":x["path"],"mode":x["mode"],"sha":x["sha"],"type":"blob"} for x in public]+[{"path":x["path"],"mode":x["mode"],"sha":x["git_blob"],"type":"blob"} for x in contribution]
full=sorted(full,key=lambda x:x["path"]);assert len(full)==616
full_tree=tree_id(full)
source_manifest={"repository":expected["repository"],"base_head":expected["current_head"],"base_tree":expected["current_tree"],"expected_existing_branch_head":expected["course_head"],"proposed_tree":full_tree,"full_leaf_count":616,"physical_leaf_count":135,"physical_tree":tree_id(final),"all_583_parent_leaves_preserved":True,"all_28_original_contribution_blobs_preserved":True,"full_tree_entries":full,"physical_files":final,"contribution_files":contribution}
write_json(root/"publication-source-manifest.json",source_manifest)
body=(root/"updated-pr-body-template.md").read_text().replace("{{FINAL_TREE}}",full_tree)
with (root/"updated-pr-body.md").open("x") as f:f.write(body)
entries=[]
for x in contribution:
    item={"path":x["path"],"mode":x["mode"],"type":"blob","sha":x["git_blob"],"bytes":x["bytes"],"sha256":x["sha256"],"local_path":str(candidate/x["path"]),"reuse_existing_blob":x["path"] in orig}
    if item["reuse_existing_blob"]:item["source_ref"]=expected["course_head"]
    else:item.update({"encoding":"base64","content":base64.b64encode((candidate/x["path"]).read_bytes()).decode()})
    entries.append(item)
patch=root/"prepared-33-path-contribution.patch"
with patch.open("xb") as out:
    for x in contribution:
        p=subprocess.run(["git","--no-replace-objects","--no-pager","-c","core.autocrlf=false","diff","--no-ext-diff","--no-textconv","--binary","--full-index","--no-index","--","/dev/null",x["path"]],cwd=candidate,env={"PATH":"/usr/bin:/bin","GIT_OPTIONAL_LOCKS":"0"},capture_output=True)
        assert p.returncode==1 and not p.stderr
        out.write(p.stdout)
payload={"format":"recallweave-existing-pr-content-payload/1","repository":expected["repository"],"pr":19,"branch":"courses/probability-foundations-7a9310dad255","expected_branch_head":expected["course_head"],"base_head":expected["current_head"],"base_tree":expected["current_tree"],"proposed_tree":full_tree,"full_leaf_count":616,"entry_count":33,"reuse_existing_blob_count":28,"new_blob_count":5,"entries":entries,"source_manifest":{"path":str(root/"publication-source-manifest.json"),**pin((root/"publication-source-manifest.json").read_bytes())},"pr_body":{"path":str(root/"updated-pr-body.md"),**pin((root/"updated-pr-body.md").read_bytes())},"full_patch":{"path":str(patch),**pin(patch.read_bytes())},"authorization":"Prepared bytes only. Root retains all GitHub mutations and merge gates."}
write_json(root/"ready-publication-payload.json",payload)
for x in payload["entries"]:
    data=(candidate/x["path"]).read_bytes();assert pin(data)["git_blob"]==x["sha"]
    if not x["reuse_existing_blob"]:assert base64.b64decode(x["content"])==data
assert tree_id(payload["entries"]+[{"path":x["path"],"mode":x["mode"],"sha":x["sha"]} for x in public])==full_tree
backup=old/"prepared-publication";backup.mkdir()
for name in ["ready-publication-payload.json","publication-source-manifest.json","updated-pr-body.md"]:
    data=(root/name).read_bytes()
    with (backup/name).open("xb") as f:f.write(data)
    assert (backup/name).read_bytes()==data
receipt={"completed":True,"prepared_parent":expected["current_head"],"proposed_tree":full_tree,"full_leaf_count":616,"entry_count":33,"all_583_parent_leaves_preserved":True,"all_28_original_contributions_preserved":True,"new_five_paths":[{k:v for k,v in x.items() if k not in ["content"]} for x in entries if not x["reuse_existing_blob"]],"archive":qualification["evidence_archive"],"payload":{"path":str(root/"ready-publication-payload.json"),**pin((root/"ready-publication-payload.json").read_bytes())},"backup_payload":str(backup/"ready-publication-payload.json"),"source_manifest":payload["source_manifest"],"pr_body":payload["pr_body"],"full_patch":payload["full_patch"],"finished_at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
write_json(root/"preparation-receipt.json",receipt)
with (backup/"preparation-receipt.json").open("xb") as f:f.write((root/"preparation-receipt.json").read_bytes())
print(json.dumps(receipt,indent=2))
