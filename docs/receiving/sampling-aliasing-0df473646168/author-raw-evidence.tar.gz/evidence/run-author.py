import hashlib
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
candidate = root / 'candidate'
evidence = root / 'evidence'
source_paths = [
    'courses/sampling-aliasing.json', 'courses/sampling-aliasing.md',
    'src/sampling-aliasing.mjs', 'src/sampling-aliasing-ui.mjs',
    'templates/sampling-aliasing-lab.html', 'tools/build-sampling-aliasing.mjs',
    'tests/sampling-aliasing.test.mjs', 'tests/sampling-aliasing-course.test.mjs',
]
run_name = sys.argv[1]
run_dir = evidence / run_name
run_dir.mkdir()
manifest = []
for name in source_paths:
    target = run_dir / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(candidate / name, target)
    data = target.read_bytes()
    manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(run_dir / 'source-before.json').write_text(json.dumps(manifest, indent=2) + '\n')
commands = [
    ['node', 'tools/build-sampling-aliasing.mjs'],
    ['node', '--test', 'tests/sampling-aliasing.test.mjs', 'tests/sampling-aliasing-course.test.mjs'],
    ['node', 'tools/build-sampling-aliasing.mjs', '--check'],
]
results = []
for index, command in enumerate(commands):
    completed = subprocess.run(command, cwd=candidate, text=True, capture_output=True)
    (run_dir / f'{index + 1}.stdout.txt').write_text(completed.stdout)
    (run_dir / f'{index + 1}.stderr.txt').write_text(completed.stderr)
    results.append({'command': command, 'returncode': completed.returncode})
    if completed.returncode:
        print(completed.stdout + completed.stderr)
        break
unchanged = all(hashlib.sha256((candidate / item['path']).read_bytes()).hexdigest() == item['sha256'] for item in manifest)
receipt = {'at': datetime.now(timezone.utc).isoformat(), 'cwd': str(candidate), 'commands': results, 'authored_sources_unchanged': unchanged}
(run_dir / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
sys.exit(0 if unchanged and len(results) == 3 and all(not r['returncode'] for r in results) else 1)
