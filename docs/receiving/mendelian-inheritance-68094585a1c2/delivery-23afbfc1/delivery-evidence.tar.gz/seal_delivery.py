from pathlib import Path
import hashlib,json,tarfile,gzip,datetime,re,shutil
root=Path(__file__).resolve().parent
a=json.loads((root/"admission-inputs.json").read_text())
p=json.loads((root/"postmerge-inputs.json").read_text())
public=json.loads((root/"public-receiving.json").read_text())
def digest(b,kind="sha256"): return hashlib.new(kind,b).hexdigest()
def blob(b): return digest(b"blob "+str(len(b)).encode()+b"\0"+b,"sha1")
def ident(path):
 b=path.read_bytes()
 return {"bytes":len(b),"sha256":digest(b),"git_blob":blob(b)}
def save(name,value): (root/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+"\n")
def tree_from_leaves(leaves):
 rootnode={}
 for path,e in leaves.items():
  node=rootnode
  parts=path.split("/")
  for part in parts[:-1]: node=node.setdefault(part,{})
  node[parts[-1]]=(e["mode"],e["sha"])
 def visit(node):
  rows=[]
  for name,value in node.items():
   if isinstance(value,dict): mode,sha="40000",visit(value)
   else: mode,sha=value
   rows.append((name,mode,sha))
  body=b"".join(mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(sha) for name,mode,sha in sorted(rows,key=lambda r:(r[0]+("/" if r[1]=="40000" else "")).encode()))
  return digest(b"tree "+str(len(body)).encode()+b"\0"+body,"sha1")
 return visit(rootnode)
merged={e["path"]:e for e in a["test_tree"]["tree"] if e["type"]=="blob"}
deployed={e["path"]:e for e in p["descendant_tree"]["tree"] if e["type"]=="blob"}
assert tree_from_leaves(merged)==p["merge"]["tree"]["sha"]=="110b6c35642296e5b9c7952895815c5fe5fe18d3"
assert tree_from_leaves(deployed)==p["descendant_tree"]["sha"]=="a61061bd6442bceaaf0d6ceb21578b9fb75f0bb5"
assert p["descendant_commit"]["parents"][0]["sha"]==p["merge"]["sha"]=="23afbfc1c2211413480b64f651c66124ef10691e"
for e in a["overlay"]:
 assert deployed[e["path"]]==merged[e["path"]]
for path,pin in a["browser_source_projection"]["source_files"].items():
 if pin["role"]=="exact-current-parent": assert deployed[path]["sha"]==pin["git_blob"]
assert len(public["assets"])==21 and public["decision"]=="accepted"
for row in public["assets"]:
 actual=ident(root/"served"/row["path"])
 assert all(actual[k]==row[k] for k in actual)
 assert row["git_blob"]==merged[row["path"]]["sha"]==deployed[row["path"]]["sha"]
assert p["successful_pages_run"]["conclusion"]=="success"
assert all(j["conclusion"]=="success" for j in p["successful_pages_jobs"]["jobs"])
build=(root/"deployed-pages-build.log").read_text()
deploy=(root/"deployed-pages-deploy.log").read_text()
dsha=p["descendant_commit"]["sha"]
assert dsha in build and '"pages_build_version": "'+dsha+'"' in deploy and "Reported success!" in deploy
for filename in ["postmerge-node-job.log","postmerge-catalog-browser-job.log"]:
 assert p["merge"]["sha"] in (root/filename).read_text()
node=(root/"postmerge-node-job.log").read_text()
for label,value in [("tests",296),("pass",296),("fail",0),("skipped",0)]: assert re.search(r"# "+label+" "+str(value)+r"\b",node)
assert '"status":"passed","checks":11,"downloads":11' in (root/"postmerge-catalog-browser-job.log").read_text()
(root/"historical").mkdir(exist_ok=True)
historical={}
for label,row in p["historical_packets"].items():
 src=Path(row["path"])
 assert ident(src)["sha256"]==row["sha256"] and src.stat().st_size==row["bytes"]
 dst=root/"historical"/src.name
 shutil.copyfile(src,dst)
 assert ident(dst)==ident(src)
 historical[label]={"path":str(dst.relative_to(root)),**ident(dst)}
receipt={
 "format":"recallweave-pr88-final-source-and-public-delivery/1","decision":"delivered",
 "recorded_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "actor":"68094585a1c2 / memory_delivery","authority":"Explicit root delegation of the remaining PR88 sequence.",
 "merge":{"pr":88,"url":"https://github.com/Jacob-Met/RecallWeave/pull/88","head":"9527c513e7e10850101066c247496c410fd1afe6",
 "commit":p["merge"]["sha"],"performed_by_this_worker":True,"performed_by_root":False,
 "method":"normal merge with expected_head_sha, no force","merged_at":p["merged_pr"]["merged_at"],
 "parents":[x["sha"] for x in p["merge"]["parents"]],"tree":p["merge"]["tree"]["sha"],"leaves":len(merged),
 "unowned_current_leaves_preserved":1484,"accepted_paths":18,
 "readme":"Every964 current-parent byte followed by the exact original966-character course block once.",
 "test_merge":"8d6551eb9e179eabffce195f61bee4d61aefb712"},
 "source":{"root_review_sha256":a["root_review_expected_sha256"],
 "original_and_108_current_browser_archives":"Retained byte-exact in the merged contribution.",
 "current_shared_browser_pins":44,"all_current_shared_browser_pins_unchanged_through_deployment":True,
 "scientific_receiving":"Existing independent blind12 keys/48 options/12 transfers and90 cross/272 weighted-cell receiving retained; no duplicate content/model run.",
 "current_browser_receiving":"Existing14-check current108 source receiving retained; no repeat because all44 shared pins and contribution runtime bytes are unchanged."},
 "hosted":{
 "pull_request_node":{"run":37805357980,"job":113408089357,"checkout":"8d6551eb9e179eabffce195f61bee4d61aefb712","node":"20.20.2","tests":296,"pass":296,"fail":0,"skipped":0,"demo_parity":True},
 "pull_request_catalog":{"run":37805357938,"job":113408089954,"checkout":"8d6551eb9e179eabffce195f61bee4d61aefb712","checks":11,"downloads":11,"conclusion":"success"},
 "postmerge_node":{"run":37806026592,"job":113410407944,"checkout":p["merge"]["sha"],"node":"20.20.2","tests":296,"pass":296,"fail":0,"skipped":0,"demo_parity":True},
 "postmerge_catalog":{"run":37806026586,"job":113410407117,"checkout":p["merge"]["sha"],"node":"22.23.3","chrome":"154.0.8037.97","checks":11,"downloads":11,"conclusion":"success"}},
 "pages":{
 "merge_run":{"id":37806024618,"commit":p["merge"]["sha"],"conclusion":"cancelled","build_job":113410409644,
 "observed_build_steps":"Jekyll and artifact upload succeeded; report/deploy jobs have no executed steps. Pipeline recorded cancellation. No source defect or cancellation cause is inferred."},
 "successful_descendant":{"run":37806098290,"url":"https://github.com/Jacob-Met/RecallWeave/actions/runs/37806098290",
 "commit":dsha,"first_parent":p["descendant_commit"]["parents"][0]["sha"],"tree":p["descendant_tree"]["sha"],"leaves":len(deployed),
 "delta_paths":17,"delta_scope":"Separate dependency-graphs explorer/guide/evidence; all18 contribution paths and44 shared browser pins unchanged.",
 "build_job":113410705842,"deploy_job":113411010878,"actual_checkout":dsha,"pages_build_version":dsha,
 "reported_success_at":"2026-10-08T16:06:48.9377702Z","environment_url":"http://jacobmetoyer.com/RecallWeave/"},
 "historical_108_failure":"Run37797983628 failed with queued build and unavailable BlobNotFound log; report only recorded failure. Cause remains unestablished; exact observations retained in the historical capsule."},
 "public":{"checked_at":public["finished_at"],"base":"https://jacobmetoyer.com/RecallWeave/",
 "lab":"https://jacobmetoyer.com/RecallWeave/courses/mendelian-inheritance-lab.html",
 "course":"https://jacobmetoyer.com/RecallWeave/courses/mendelian-inheritance.json",
 "guide":"https://jacobmetoyer.com/RecallWeave/courses/mendelian-inheritance.md",
 "decision":public["decision"],"asset_count":21,"redirects":public["redirects"],
 "assets":[{k:r[k] for k in ("path","url","status","bytes","sha256","git_blob","expected_git_blob","accepted","at")} for r in public["assets"]]},
 "historical_capsules":historical,
 "evidence_publication":{"branch":p["evidence_branch"],"base_commit":p["evidence_base"],"scope":"Three evidence paths only, no merge request or source change."},
 "limits":["Public receiving checks exact21 declared assets and the static learner import closure, not every leaf on the deployed site.",
 "No new hosted-site browser click run: existing native14-check browser receiving and public exact-byte receiving are identified separately.",
 "The same repo's current main may continue to advance; observations are bound to the stated immutable commits and timestamps.",
 "No hosting settings, Pages configuration, dependency, source or workflow repair was made; no failed workflow was rerun.",
 "Transport content-length may reflect compression; file identities use decoded response body bytes."]
}
save("final-receipt.json",receipt)
excluded={"evidence-manifest.json","artifact-manifest.json","delivery-evidence.tar.gz","README.md","publication-manifest.json","publication-full-leaves.json"}
members=[{"path":str(f.relative_to(root)),"mode":"100644",**ident(f)} for f in sorted(root.rglob("*")) if f.is_file() and f.name not in excluded]
save("evidence-manifest.json",{"format":"explicit-evidence-members/1","members":members})
archive=root/"delivery-evidence.tar.gz"
with archive.open("wb") as raw,gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode="w") as tar:
 for name in [x["path"] for x in members]+["evidence-manifest.json"]: tar.add(root/name,arcname=name,recursive=False)
with tarfile.open(archive,"r:gz") as tar:
 assert len(tar.getnames())==len(members)+1
 for row in members:
  b=tar.extractfile(row["path"]).read()
  assert len(b)==row["bytes"] and digest(b)==row["sha256"]
archive_id=ident(archive)
readme=f"""# Mendelian course: final integration and public delivery

PR88 was normally merged as23afbfc1c2211413480b64f651c66124ef10691e by the68094585a1c2 memory_delivery worker under explicit root delegation. Root accepted the source and captures; the delegated worker performed this merge.

The exact1502-leaf merge tree110b6c35642296e5b9c7952895815c5fe5fe18d3 preserves all1484 unowned current-parent leaves and all accepted contribution paths. Its README contains the complete current text and the original course block once. All44 shared browser inputs stayed unchanged.

PR test-merge8d6551eb and actual merge23afb each passed296 Node20 tests with0 skips and demo parity. The existing catalog browser gate passed11 checks and11 downloads on both exact checkouts. These hosted gates are distinct from the retained14-check native Mendelian/current-learner receiver.

The merge's Pages pipeline recorded cancellation after successful Jekyll/artifact steps. Successful Pages run[37806098290](https://github.com/Jacob-Met/RecallWeave/actions/runs/37806098290) actually deployed direct descendant3e110dfb0aded80152afea685660105fed224e74, with the complete contribution and learner inputs unchanged. Public receiving at16:08:31Z verified21 exact assets, including the lab, course, guide, model/UI and full static learner module closure.

- [Open the public lab](https://jacobmetoyer.com/RecallWeave/courses/mendelian-inheritance-lab.html)
- [Course JSON](https://jacobmetoyer.com/RecallWeave/courses/mendelian-inheritance.json)
- [Worked guide](https://jacobmetoyer.com/RecallWeave/courses/mendelian-inheritance.md)
- [Machine receipt](final-receipt.json)
- [Complete receiving capsule](delivery-evidence.tar.gz): {archive_id['bytes']} bytes; SHA-256 `{archive_id['sha256']}`.

The capsule includes raw hosted logs, actual response bytes, complete source maps, reproducible receipt tools and immutable earlier Pages/guide capsules. The older108 Pages failure still has no retrievable build log or established cause. No hosting/source/workflow change or rerun was used.

This evidence-only branch retains23afb as parent and adds only these three evidence files. It is not a second product merge. Public byte receiving covers the declared21 assets; it does not claim every deployed leaf or a new hosted-site browser click run.
"""
# Keep prose legible while preserving immutable source identifiers.
for old,new in [("as23afb","as 23afb"),("the6809","the 6809"),("exact1502","exact 1502"),("all1484","all 1484"),("All44","All 44"),("test-merge8d","test-merge 8d"),("merge23afb","merge 23afb"),("passed296","passed 296"),("Node20","Node 20"),("with0","with 0"),("passed11","passed 11"),("and11","and 11"),("retained14","retained 14"),("descendant3e","descendant 3e"),("at16:","at 16:"),("verified21","verified 21"),("older108","older 108"),("retains23afb","retains 23afb"),("declared21","declared 21"),("tree110b","tree 110b")]: readme=readme.replace(old,new)
(root/"README.md").write_text(readme)
prefix="docs/receiving/mendelian-inheritance-68094585a1c2/delivery-23afbfc1/"
files=[]
combined=dict(merged)
for name in ["README.md","final-receipt.json","delivery-evidence.tar.gz"]:
 path=prefix+name
 assert path not in combined
 row={"path":path,"local_file":str(root/name),"mode":"100644","before_blob":None,**ident(root/name)}
 files.append(row);combined[path]={"path":path,"mode":"100644","type":"blob","sha":row["git_blob"],"size":row["bytes"]}
expected_tree=tree_from_leaves(combined)
manifest={"format":"pr88-final-evidence-publication/1","parent":p["evidence_base"],"base_tree":p["merge"]["tree"]["sha"],
 "branch":p["evidence_branch"],"expected_tree":expected_tree,"leaves":len(combined),"unchanged_parent_leaves":len(merged),"files":files}
save("publication-manifest.json",manifest)
save("publication-full-leaves.json",sorted(combined.values(),key=lambda r:r["path"]))
artifacts={name:ident(root/name) for name in ["final-receipt.json","evidence-manifest.json","delivery-evidence.tar.gz","publication-manifest.json"]}
artifacts["archive_members"]=len(members)+1
save("artifact-manifest.json",artifacts)
print(json.dumps({"artifacts":artifacts,"expected_tree":expected_tree,"leaves":len(combined),"unchanged_parent_leaves":len(merged)},indent=2))
