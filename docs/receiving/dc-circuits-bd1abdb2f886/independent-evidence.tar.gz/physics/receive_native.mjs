/** Independent law/value checks against the literal native candidate, never a model replacement. */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const source = resolve(process.argv[2]);
const receiptPath = join(here, 'native-receipt.json');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const blob = bytes => createHash('sha1').update('blob ' + bytes.length + '\0').update(bytes).digest('hex');
const receipt = {
  kind: 'independent-native-dc-course-and-model-receiving',
  created_utc: new Date().toISOString(), node: process.version, platform: process.platform,
  arch: process.arch, source, source_base: 'd22b5ef7c641fc1726ae5b774383f8e6527d73e7',
  receiver_sha256: sha(readFileSync(fileURLToPath(import.meta.url))),
  groups: [], source_before: {}, source_after: {},
};
function group(name, run) {
  try { receipt.groups.push({ name, status: 'passed', details: run() ?? null }); }
  catch (error) { receipt.groups.push({ name, status: 'failed', error: String(error), stack: error.stack }); }
}
function close(actual, expected, description) {
  assert.equal(typeof actual, 'number', description + ': numeric type');
  assert.ok(Number.isFinite(actual), description + ': finite');
  assert.ok(Math.abs(actual - expected) <= 1e-12 * Math.max(1, Math.abs(actual), Math.abs(expected)),
    `${description}: got ${actual}, expected ${expected}`);
}
const rational = value => {
  const [n, d = '1'] = value.split('/');
  return Number(n) / Number(d);
};
const pins = {
  'src/dc-circuits.mjs': { sha256: 'b8a94b617e2285f8e07229f256d8c2f1c1fcbe53a6e8045f1d816e74d7fb9ba8' },
  'courses/dc-circuits.json': { sha256: 'cfe7a4586a4a97aa96356e9afe7fea5bc1e216a0aff70454476397c909058ccb' },
  'src/deck.mjs': { blob: 'f0f8a4b234489c2388f427633f548d56c6ed4c03' },
};

try {
  for (const [path, pin] of Object.entries(pins)) {
    const bytes = readFileSync(join(source, path));
    const actual = { bytes: bytes.length, sha256: sha(bytes), blob: blob(bytes) };
    for (const [kind, expected] of Object.entries(pin)) assert.equal(actual[kind], expected, path);
    receipt.source_before[path] = actual;
  }
  const vectorsBytes = readFileSync(join(here, 'conservation-vectors.json'));
  assert.equal(sha(vectorsBytes), 'bab2238cb58d0043e5aa8cf17cddca186bff3b9a6ddf940d1f731b917d038c7f');
  const answersBytes = readFileSync(join(here, 'blind-answers.json'));
  assert.equal(sha(answersBytes), '44363ad6d91b1ae9483a3858d2668d22203192778c0a2dc88835242a73ce5cd4');
  receipt.blind_vectors_sha256 = sha(vectorsBytes);
  receipt.blind_answers_sha256 = sha(answersBytes);
  const vectors = JSON.parse(vectorsBytes).cases;
  const blind = JSON.parse(answersBytes);
  const { compareCircuits, parseCircuitNumber, comparisonCSV, CIRCUIT_LIMITS } =
    await import(pathToFileURL(join(source, 'src/dc-circuits.mjs')));
  const { parseDeck, validateDeck, serializeDeck } =
    await import(pathToFileURL(join(source, 'src/deck.mjs')));

  function physics(input) {
    const before = JSON.stringify(input);
    const got = compareCircuits(input);
    assert.equal(JSON.stringify(input), before, 'caller input preserved');
    assert.deepEqual(got.input, input);
    for (const mode of ['series', 'parallel']) {
      const row = got[mode];
      assert.equal(row.connection, mode);
      assert.equal(row.resistors.length, 2);
      assert.ok(row.equivalentResistance > 0);
      close(row.sourceCurrent * row.equivalentResistance, input.voltage, mode + ' source Ohm law');
      close(row.sourcePower, input.voltage * row.sourceCurrent, mode + ' source power');
      close(row.sourcePower, row.resistors.reduce((sum, part) => sum + part.power, 0), mode + ' power balance');
      for (const [i, part] of row.resistors.entries()) {
        assert.equal(part.id, 'R' + (i + 1));
        assert.equal(part.resistance, input['resistance' + (i + 1)]);
        close(part.voltage, part.current * part.resistance, mode + ' resistor Ohm law');
        close(part.power, part.current * part.voltage, mode + ' VI power');
        close(part.power, part.current ** 2 * part.resistance, mode + ' I squared R power');
        close(part.power, part.voltage ** 2 / part.resistance, mode + ' V squared over R power');
        assert.ok(part.current >= 0 && part.voltage >= 0 && part.power >= 0);
      }
      if (mode === 'series') {
        close(row.resistors[0].current, row.sourceCurrent, 'series R1 current');
        close(row.resistors[1].current, row.sourceCurrent, 'series R2 current');
        close(row.resistors[0].voltage + row.resistors[1].voltage, input.voltage, 'series loop balance');
        close(row.equivalentResistance, input.resistance1 + input.resistance2, 'series resistance');
        assert.ok(row.equivalentResistance > Math.max(input.resistance1, input.resistance2));
      } else {
        close(row.resistors[0].voltage, input.voltage, 'parallel R1 voltage');
        close(row.resistors[1].voltage, input.voltage, 'parallel R2 voltage');
        close(row.resistors[0].current + row.resistors[1].current, row.sourceCurrent, 'parallel junction balance');
        close(1 / row.equivalentResistance, 1 / input.resistance1 + 1 / input.resistance2, 'parallel conductance');
        assert.ok(row.equivalentResistance < Math.min(input.resistance1, input.resistance2));
      }
    }
    return got;
  }

  group('frozen exact-rational values inside the declared domain', () => {
    const passed = [], outOfDomain = [], notRepresentable = [], cache = new Map(), rejected = new Set();
    for (const vector of vectors) {
      if (vector.resistors.length !== 2) {
        notRepresentable.push({ name: vector.name, reason: 'fixed two-resistor interface; no numeric pass claimed' });
        continue;
      }
      const input = { voltage: rational(vector.voltage), resistance1: rational(vector.resistors[0]),
        resistance2: rational(vector.resistors[1]) };
      const key = JSON.stringify(input);
      if (input.voltage < 0 || input.voltage > 24 || input.resistance1 < 1 || input.resistance1 > 1000 ||
          input.resistance2 < 1 || input.resistance2 > 1000) {
        if (!rejected.has(key)) { assert.throws(() => compareCircuits(input)); rejected.add(key); }
        outOfDomain.push({ name: vector.name, input, disposition: 'explicit refusal, not a numeric pass' });
        continue;
      }
      if (!cache.has(key)) cache.set(key, physics(input));
      const result = cache.get(key)[vector.mode];
      close(result.equivalentResistance, rational(vector.equivalent), vector.name + ' equivalent');
      close(result.sourceCurrent, rational(vector.source_current), vector.name + ' source current');
      close(result.sourcePower, rational(vector.source_power), vector.name + ' source power');
      result.resistors.forEach((part, i) => {
        close(part.voltage, rational(vector.branch_voltages[i]), vector.name + ' voltage ' + i);
        close(part.current, rational(vector.branch_currents[i]), vector.name + ' current ' + i);
        close(part.power, rational(vector.branch_powers[i]), vector.name + ' power ' + i);
      });
      passed.push(vector.name);
    }
    assert.equal(passed.length, 6);
    assert.equal(outOfDomain.length, 4);
    assert.equal(notRepresentable.length, 4);
    return { numeric_vectors_passed: passed, distinct_admitted_inputs: cache.size,
      distinct_out_of_domain_refusals: rejected.size, out_of_domain: outOfDomain,
      inapplicable_interface_vectors: notRepresentable };
  });

  group('conservation at domain boundaries and unequal fractional values', () => {
    let count = 0;
    for (const voltage of [0, 0.25, 1, 7.5, 24]) {
      for (const resistance1 of [1, 2.5, 10, 1000]) {
        for (const resistance2 of [1, 2.5, 10, 1000]) {
          physics({ voltage, resistance1, resistance2 }); count++;
        }
      }
    }
    return { input_comparisons: count, connection_results: count * 2 };
  });

  group('changed-input scaling, permutation and ideal-source independence', () => {
    const base = physics({ voltage: 6, resistance1: 4, resistance2: 8 });
    const doubledV = physics({ voltage: 12, resistance1: 4, resistance2: 8 });
    const doubledR = physics({ voltage: 6, resistance1: 8, resistance2: 16 });
    const swapped = physics({ voltage: 6, resistance1: 8, resistance2: 4 });
    const changedR2 = physics({ voltage: 6, resistance1: 4, resistance2: 16 });
    for (const mode of ['series', 'parallel']) {
      close(doubledV[mode].sourceCurrent, 2 * base[mode].sourceCurrent, mode + ' doubled V current');
      close(doubledV[mode].sourcePower, 4 * base[mode].sourcePower, mode + ' doubled V power');
      close(doubledV[mode].equivalentResistance, base[mode].equivalentResistance, mode + ' doubled V resistance');
      close(doubledR[mode].sourceCurrent, base[mode].sourceCurrent / 2, mode + ' doubled R current');
      close(doubledR[mode].sourcePower, base[mode].sourcePower / 2, mode + ' doubled R power');
      close(doubledR[mode].equivalentResistance, 2 * base[mode].equivalentResistance, mode + ' doubled R equivalent');
      close(swapped[mode].equivalentResistance, base[mode].equivalentResistance, mode + ' permutation equivalent');
      close(swapped[mode].sourceCurrent, base[mode].sourceCurrent, mode + ' permutation current');
      for (let i = 0; i < 2; i++) {
        close(doubledV[mode].resistors[i].voltage, 2 * base[mode].resistors[i].voltage, mode + ' scaled branch V');
        close(doubledR[mode].resistors[i].voltage, base[mode].resistors[i].voltage, mode + ' fixed branch V');
        for (const field of ['voltage', 'current', 'power']) {
          close(swapped[mode].resistors[1 - i][field], base[mode].resistors[i][field], mode + ' permutation ' + field);
        }
      }
    }
    close(changedR2.parallel.resistors[0].current, base.parallel.resistors[0].current, 'unchanged parallel branch');
    assert.ok(changedR2.parallel.sourceCurrent < base.parallel.sourceCurrent);
    assert.ok(changedR2.series.sourceCurrent < base.series.sourceCurrent);
    const equal = physics({ voltage: 8, resistance1: 4, resistance2: 4 });
    close(equal.parallel.sourceCurrent / equal.series.sourceCurrent, 4, 'equal resistor topology current ratio');
    close(equal.parallel.sourcePower / equal.series.sourcePower, 4, 'equal resistor topology power ratio');
    return { comparisons: 6, properties: ['voltage scaling', 'resistance scaling', 'permutation',
      'parallel branch independence', 'series resistance increase', 'equal-resistor topology power ratio'] };
  });

  group('strict actual-number admission and decimal text admission', () => {
    assert.equal(CIRCUIT_LIMITS.voltage.min, 0); assert.equal(CIRCUIT_LIMITS.voltage.max, 24);
    assert.equal(CIRCUIT_LIMITS.resistance1.min, 1); assert.equal(CIRCUIT_LIMITS.resistance1.max, 1000);
    assert.equal(CIRCUIT_LIMITS.resistance2.min, 1); assert.equal(CIRCUIT_LIMITS.resistance2.max, 1000);
    let modelRefusals = 0, textRefusals = 0;
    for (const bad of [undefined, null, [], '12', {}, { voltage: 12, resistance1: 4 }]) {
      assert.throws(() => compareCircuits(bad)); modelRefusals++;
    }
    for (const [key, values] of [['voltage', [true, '12', NaN, Infinity, -Infinity, -0.1, 24.1]],
      ['resistance1', [false, '4', NaN, Infinity, 0, -1, 1001]],
      ['resistance2', [null, [], NaN, Infinity, 0, -1, 1001]]]) {
      for (const value of values) {
        assert.throws(() => compareCircuits({ voltage: 12, resistance1: 4, resistance2: 8, [key]: value }));
        modelRefusals++;
      }
    }
    for (const [text, value] of [['0', 0], ['-0', 0], ['24', 24], [' 1.25 ', 1.25], ['.5', 0.5], ['+1e1', 10]]) {
      close(parseCircuitNumber(text, 'Source voltage', 0, 24), value, 'admitted decimal ' + text);
    }
    for (const text of ['', ' ', '0x10', '0b10', 'Infinity', 'NaN', '1abc', '1,5', '--2', '1e', '1/2',
      undefined, null, 12, true, '24.1', '-1', '1e1000']) {
      assert.throws(() => parseCircuitNumber(text, 'Source voltage', 0, 24)); textRefusals++;
    }
    for (const text of ['0', '-1', '1001']) {
      assert.throws(() => parseCircuitNumber(text, 'R1 resistance', 1, 1000)); textRefusals++;
    }
    close(parseCircuitNumber('1', 'R1 resistance', 1, 1000), 1, 'minimum R');
    close(parseCircuitNumber('1000', 'R1 resistance', 1, 1000), 1000, 'maximum R');
    return { model_refusals: modelRefusals, text_refusals: textRefusals, accepted_text_values: 8 };
  });

  group('CSV preserves physical values and recomputes untrusted result cells', () => {
    const input = { voltage: 6, resistance1: 2, resistance2: 3 };
    const comparison = physics(input), csv = comparisonCSV(comparison);
    assert.ok(csv.endsWith('\r\n'));
    assert.equal(csv.replaceAll('\r\n', '').includes('\n'), false);
    const [header, series, parallel, tail] = csv.split('\r\n');
    assert.equal(tail, '');
    const columns = header.split(',');
    assert.equal(columns.length, 13); assert.equal(new Set(columns).size, 13);
    const expected = [
      ['series', 6, 2, 3, 5, 6 / 5, 36 / 5, 12 / 5, 6 / 5, 72 / 25, 18 / 5, 6 / 5, 108 / 25],
      ['parallel', 6, 2, 3, 6 / 5, 5, 30, 6, 3, 18, 6, 2, 12],
    ];
    for (const [row, index] of [[series, 0], [parallel, 1]]) {
      const cells = row.split(','); assert.equal(cells.length, 13); assert.equal(cells[0], expected[index][0]);
      for (let i = 1; i < cells.length; i++) close(Number(cells[i]), expected[index][i], 'CSV physical cell ' + i);
    }
    const tampered = { input, series: { sourceCurrent: '=1+1' }, parallel: { sourcePower: Infinity } };
    assert.equal(comparisonCSV(tampered), csv, 'serialized output recalculated from admitted inputs');
    assert.throws(() => comparisonCSV({ input: { ...input, voltage: '6' } }));
    return { csv_sha256: sha(Buffer.from(csv)), rows: 2, columns: 13, tampered_cells_ignored: true };
  });

  group('real deck parser, exact blind answers and content round trip', () => {
    const bytes = readFileSync(join(source, 'courses/dc-circuits.json'));
    const deck = parseDeck(bytes.toString('utf8'));
    assert.deepEqual(validateDeck(deck), deck);
    assert.equal(deck.items.length, 12); assert.equal(deck.concepts.length, 4);
    for (const expected of blind.answers) {
      const item = deck.items.find(item => item.id === expected.id);
      assert.ok(item, expected.id);
      assert.equal(item.answer, expected.selected_index, expected.id + ' blind index');
      assert.equal(item.options[item.answer], expected.answer, expected.id + ' blind value');
    }
    const serialized = serializeDeck(deck);
    assert.deepEqual(parseDeck(serialized), deck);
    assert.equal(serialized, bytes.toString('utf8'), 'course already has exact canonical exported bytes');
    const counts = Object.fromEntries(deck.concepts.map(concept =>
      [concept, deck.items.filter(item => item.concept === concept).length]));
    assert.deepEqual(Object.values(counts), [3, 3, 3, 3]);
    return { questions: 12, blind_answers_matched: 12, concepts: counts,
      serialized_sha256: sha(Buffer.from(serialized)), active_learner_picker_or_importer_tested: false };
  });
} catch (error) {
  receipt.fatal_error = String(error); receipt.fatal_stack = error.stack;
} finally {
  for (const path of Object.keys(pins)) {
    const bytes = readFileSync(join(source, path));
    receipt.source_after[path] = { bytes: bytes.length, sha256: sha(bytes), blob: blob(bytes) };
  }
  receipt.source_preserved = JSON.stringify(receipt.source_before) === JSON.stringify(receipt.source_after);
  receipt.passed_groups = receipt.groups.filter(group => group.status === 'passed').length;
  receipt.failed_groups = receipt.groups.filter(group => group.status === 'failed').length;
  receipt.accepted = !receipt.fatal_error && receipt.failed_groups === 0 && receipt.passed_groups === 6 && receipt.source_preserved;
  const output = JSON.stringify(receipt, null, 2) + '\n';
  writeFileSync(receiptPath, output, { flag: 'wx' });
  console.log(JSON.stringify({ receipt: receiptPath, sha256: sha(Buffer.from(output)), accepted: receipt.accepted,
    passed_groups: receipt.passed_groups, failed_groups: receipt.failed_groups,
    groups: receipt.groups.map(({name, status, error}) => ({name, status, error})), fatal_error: receipt.fatal_error }, null, 2));
  process.exitCode = receipt.accepted ? 0 : 1;
}
