# Probability browser receiving

The frozen standalone HTML SHA256 6bf851f7c01176e2667fd9f0ee1af595c26ddbc96a08227977ca3a01666e93c7 passed 16 of 16 independent browser/learner groups on corrected v5. Node exited 0, stderr was empty, and fresh default-sandbox Snap Chromium closed. Four captures were visually inspected. Fourteen real downloads include current table results, the exact existing course, and learner notes before and after practice.

Attempt1 remains a failed receiver execution: exit1, ten groups passed and six stopped before edits because Puppeteer rejected Control+A. Only the v4-to-v5 key-delivery sequence changed; all behavior expectations remain exact. Both runs, raw logs, downloaded bytes, screenshots, receiver versions and corrections are retained.

The native learner is the97565-byte demo blob cf7eea3792deacc3eb98a22aef539b920fb66746, observed unchanged at48611be99baa20f51d1e3846ed8cd38879748961. Later learner changes require separate source composition review. Headless390px rendering is not physical mobile-device evidence.

browser-native-receipt.json states scope/exclusions. packet-index.json binds every payload member. Identical artifact bytes may use tar hard links; every archive member was independently read back and checked. Browser profiles/caches are excluded; exact input HTML/contracts/adapters/raw outputs/actual downloads are included.
