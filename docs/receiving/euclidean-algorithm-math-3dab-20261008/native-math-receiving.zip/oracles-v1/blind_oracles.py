"""Blind exact-integer oracle, frozen before the Euclidean implementation/key is read.
This receives arithmetic, not the application's parser or browser.
"""
from __future__ import annotations
from pathlib import Path
import datetime, hashlib, json, math, random, sys

LIMIT = 999_999
PAIRS = [
    (0, 0), (0, 1), (1, 0), (0, LIMIT), (LIMIT, 0),
    (1, 1), (LIMIT, 1), (1, LIMIT), (LIMIT, LIMIT),
    (524288, 524288), (524288, 262144), (524288, 393216),
    (999999, 333333), (100, 25), (999999, 999998),
    (999983, 999979), (48, 18), (18, 48), (252, 198),
    (240, 46), (391, 299), (1071, 462),
    (832040, 514229), (514229, 832040),
    (999900, 100), (100000, 1), (999999, 999), (999999, 37),
    (4096, 6144),
]

def binary_gcd(a: int, b: int) -> int:
    if a == 0:
        return b
    if b == 0:
        return a
    powers_of_two = 0
    while (a & 1) == 0 and (b & 1) == 0:
        a >>= 1
        b >>= 1
        powers_of_two += 1
    while (a & 1) == 0:
        a >>= 1
    while b:
        while (b & 1) == 0:
            b >>= 1
        if a > b:
            a, b = b, a
        b -= a
    return a << powers_of_two

def exact_oracle(a: int, b: int) -> dict:
    if type(a) is not int or type(b) is not int:
        raise TypeError("Oracle values must be integers.")
    if not (0 <= a <= LIMIT and 0 <= b <= LIMIT):
        raise ValueError("Oracle range is 0 through 999999.")
    expected_gcd = math.gcd(a, b)
    if expected_gcd != binary_gcd(a, b):
        raise AssertionError("Independent gcd implementations disagree.")
    older, current = a, b
    old_x, x, old_y, y = 1, 0, 0, 1
    steps = []
    while current != 0:
        quotient, remainder = divmod(older, current)
        next_x, next_y = old_x - quotient * x, old_y - quotient * y
        if not (
            older == quotient * current + remainder
            and 0 <= remainder < current
            and a * old_x + b * old_y == older
            and a * x + b * y == current
            and a * next_x + b * next_y == remainder
            and math.gcd(older, current) == expected_gcd
            and math.gcd(current, remainder) == expected_gcd
        ):
            raise AssertionError("Division, coefficient or gcd invariant failed.")
        steps.append({
            "dividend": str(older), "divisor": str(current),
            "quotient": str(quotient), "remainder": str(remainder),
            "dividend_coefficients": [str(old_x), str(old_y)],
            "divisor_coefficients": [str(x), str(y)],
            "remainder_coefficients": [str(next_x), str(next_y)],
        })
        older, current = current, remainder
        old_x, x, old_y, y = x, next_x, y, next_y
    if older != expected_gcd or a * old_x + b * old_y != expected_gcd:
        raise AssertionError("Final reconstruction failed.")
    if expected_gcd and (a % expected_gcd or b % expected_gcd):
        raise AssertionError("Reported gcd does not divide both inputs.")
    return {
        "a": str(a), "b": str(b), "gcd": str(expected_gcd),
        "steps": steps, "division_count": len(steps),
        "one_valid_bezout_pair": [str(old_x), str(old_y)],
        "reconstruction_terms": [str(a * old_x), str(b * old_y)],
        "reconstruction_sum": str(a * old_x + b * old_y),
    }

def accepts_result(a: int, b: int, d: int, x: int, y: int) -> bool:
    """A certificate needs the correct gcd and reconstruction, not one fixed pair."""
    return (
        all(type(value) is int for value in [a, b, d, x, y])
        and 0 <= a <= LIMIT and 0 <= b <= LIMIT
        and d == math.gcd(a, b) == binary_gcd(a, b)
        and a * x + b * y == d
    )

def main() -> None:
    out = Path(__file__).parent
    evaluations = 0
    max_observed_divisions = 0
    for a in range(65):
        for b in range(65):
            result = exact_oracle(a, b)
            evaluations += 1
            max_observed_divisions = max(max_observed_divisions, result["division_count"])
    rng = random.Random(20261008)
    for unused in range(2048):
        result = exact_oracle(rng.randrange(LIMIT + 1), rng.randrange(LIMIT + 1))
        evaluations += 1
        max_observed_divisions = max(max_observed_divisions, result["division_count"])
    vectors = [exact_oracle(a, b) for a, b in PAIRS]
    for item in vectors:
        a, b, d = int(item["a"]), int(item["b"]), int(item["gcd"])
        x, y = map(int, item["one_valid_bezout_pair"])
        if not accepts_result(a, b, d, x, y):
            raise AssertionError("Valid selected certificate rejected.")
        if d:
            if not accepts_result(a, b, d, x + b // d, y - a // d):
                raise AssertionError("Alternative valid Bezout pair rejected.")
            if accepts_result(a, b, d + 1, x, y):
                raise AssertionError("Incorrect gcd accepted.")
        evaluations += 1
        max_observed_divisions = max(max_observed_divisions, item["division_count"])
    payload = {
        "schema": 1,
        "frozen_before": "Root implementation, answer key, explanations and question-only packet were not read.",
        "domain": {"minimum": "0", "maximum": "999999", "both_zero_convention": "0"},
        "step_convention": "Preserve the supplied order. Each row divides the current first value by the nonzero second value, including the terminal zero remainder.",
        "coefficient_policy": "The supplied pair is one valid extended-Euclid result. Accept every integer pair with a*x+b*y=gcd(a,b); do not require pair identity.",
        "both_zero_note": "gcd(0,0)=0 is the explicit computational convention. Every positive integer divides both zeros, so 0 is not a greatest positive common divisor.",
        "zero_note": "If the initial second input is zero, there are no division rows and the answer is the first input. Never divide by zero.",
        "references": [
            "https://docs.python.org/3.13/library/math.html#math.gcd",
            "https://math.mit.edu/~dav/euclidC.pdf",
        ],
        "vectors": vectors,
    }
    data = (json.dumps(payload, indent=2) + "\n").encode()
    (out / "blind-oracles.json").write_bytes(data)
    receipt = {
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "python": sys.version,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "oracle_sha256": hashlib.sha256(data).hexdigest(),
        "oracle_bytes": len(data),
        "selected_vectors": len(vectors),
        "validation_evaluations": evaluations,
        "validation_components": {"small_domain_pairs": 65 * 65, "seeded_pairs": 2048, "selected_pairs": len(vectors)},
        "max_divisions_in_examined_cases": max_observed_divisions,
        "seed": 20261008,
        "all_oracle_invariants_passed": True,
        "candidate_code_executed": False,
    }
    (out / "oracle-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    manifest = {"schema": 1, "files": {}}
    for name in ["blind_oracles.py", "blind-oracles.json", "oracle-receipt.json"]:
        b = (out / name).read_bytes()
        manifest["files"][name] = {"bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}
    raw = (json.dumps(manifest, indent=2) + "\n").encode()
    (out / "ORACLE_MANIFEST.json").write_bytes(raw)
    print(json.dumps({"root": str(out), "manifest_sha256": hashlib.sha256(raw).hexdigest(), **receipt}, indent=2))
    print(json.dumps([{"a": item["a"], "b": item["b"], "gcd": item["gcd"], "divisions": item["division_count"], "one_pair": item["one_valid_bezout_pair"]} for item in vectors], indent=2))

if __name__ == "__main__":
    main()
