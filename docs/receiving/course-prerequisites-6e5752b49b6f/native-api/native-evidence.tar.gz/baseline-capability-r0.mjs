import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import * as deck from './baseline-deck.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=b=>crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const paths=['baseline-deck.mjs','manual-course-r0.json','runtime-dependencies.json',path.basename(fileURLToPath(import.meta.url))];
const before=paths.map(p=>({path:p,sha256:hash(fs.readFileSync(path.join(root,p)))}));
assert.equal(git(fs.readFileSync(path.join(root,'baseline-deck.mjs'))),'f0f8a4b234489c2388f427633f548d56c6ed4c03');
const runtime=JSON.parse(fs.readFileSync(path.join(root,'runtime-dependencies.json'),'utf8'));
for(const f of runtime.files)assert.equal(hash(fs.readFileSync(f.path)),f.sha256,f.path);
const memory=Number(fs.readFileSync('/proc/meminfo','utf8').match(/MemAvailable:\s+(\d+)/)[1])*1024;
const disk=fs.statfsSync(root);assert.ok(memory>=256*1024**2);assert.ok(disk.bavail*disk.bsize>=64*1024**2);
const raw=fs.readFileSync(path.join(root,'manual-course-r0.json'),'utf8');
const original=JSON.parse(raw),snapshot=JSON.stringify(original),checked=deck.parseDeck(raw);
assert.deepEqual(checked.concepts,['Finish','Side','Base','Branch','Island']);
assert.deepEqual(checked.items.map(x=>x.id),['finish-A','base','branch','finish-B','side','island','finish-C']);
assert.equal(JSON.stringify(original),snapshot);assert.ok(Object.isFrozen(checked)&&Object.isFrozen(checked.items)&&checked.items.every(Object.isFrozen));
const refusals=[];
for(const [name,change] of [
['aggregate-cycle',x=>x.items[1].prerequisites.push('Finish')],
['unknown-prerequisite',x=>x.items[2].prerequisites.push('Missing')],
['self-prerequisite',x=>x.items[2].prerequisites.push('Branch')],
['duplicate-question-id',x=>x.items[6].id='finish-A']
]){
 const x=structuredClone(original);change(x);const snap=JSON.stringify(x);assert.throws(()=>deck.validateDeck(x));assert.equal(JSON.stringify(x),snap);refusals.push(name);
}
const names=structuredClone(original),replacement=new Map(original.concepts.map((x,i)=>[x,['__proto__','constructor',' a b','a  b','é'][i]]));
names.concepts=names.concepts.map(x=>replacement.get(x));
for(const q of names.items){q.concept=replacement.get(q.concept);q.prerequisites=q.prerequisites.map(x=>replacement.get(x));}
const special=deck.validateDeck(names);assert.deepEqual(special.concepts,['__proto__','constructor',' a b','a  b','é']);
const after=paths.map(p=>({path:p,sha256:hash(fs.readFileSync(path.join(root,p)))}));assert.deepEqual(after,before);
for(const f of runtime.files)assert.equal(hash(fs.readFileSync(f.path)),f.sha256);
const out={scope:'Original current validator capability only; no prerequisite-viewer candidate or output expectations exposed',base:'698902f9c9c1d5c5023092b85b3632a7cb7a01ed',tree:'d6d3707b691850af7928299242631534cff89aa8',validatorGit:'f0f8a4b234489c2388f427633f548d56c6ed4c03',passed:true,groups:6,sourceOrderedQuestionIds:checked.items.map(x=>x.id),concepts:checked.concepts,specialLiteralConcepts:special.concepts,refusals,validatorExports:Object.keys(deck).sort(),runtimeFileCount:runtime.files.length,before,after,sourceUnchanged:true,capacity:{memory,filesystemBytes:disk.bavail*disk.bsize},limit:'This proves existing validator behavior and lack of a viewer API in this module only; full source-tree path absence is separate read-only evidence.'};
const output=path.join(root,'baseline-capability-r0.json');assert.equal(fs.existsSync(output),false);fs.writeFileSync(output,JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify(out));
