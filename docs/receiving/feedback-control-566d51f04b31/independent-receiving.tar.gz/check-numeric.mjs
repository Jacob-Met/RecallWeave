import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { simulateFeedback, analyzeSettings, validateSettings, feedbackCsv, DEFAULT_SETTINGS } from './source/feedback-control.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(root, 'numeric-receiving');
fs.mkdirSync(out);
const read = name => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const nativeRoot = '/tmp/recall-feedback-control-566d51f04b31/source';
const pins = read('source-receiving.json');
const sourcesBefore = pins.source_files.map(p => ({
  ...p, nativeSha256: hash(path.join(nativeRoot, p.path)),
  copiedSha256: hash(path.join(root, p.copied_as))
}));
for (const p of sourcesBefore) {
  assert.equal(p.nativeSha256, p.sha256);
  assert.equal(p.copiedSha256, p.sha256);
}
const exact = (got, expected, label) => assert.ok(got === expected, label + ': ' + got + ' != ' + expected);
const close = (got, expected, label) => {
  const error = Math.abs(got - expected);
  const scale = Math.max(1, Math.abs(expected));
  assert.ok(error <= 5e-14 * scale, label + ' relative error=' + error / scale);
  return error / scale;
};
const frozen = read('blind-course-numeric-oracles.json');
const results = [];
const runs = new Map();
for (const test of frozen.cases) {
  const i = test.inputs;
  const settings = {
    a: i.a, gain: i.k, reference: i.r, disturbance: i.d,
    initial: i.x0, offset: 0, steps: i.steps
  };
  const before = JSON.stringify(settings);
  if (test.name.startsWith('just-')) {
    // Frozen near-boundary rational cases fall outside the documented quarter grid.
    assert.throws(() => simulateFeedback(settings), RangeError);
    assert.equal(JSON.stringify(settings), before);
    results.push({name: test.name, result: 'correctly rejected outside quarter-grid admission',
      mathematical_q: test.q, expected_mathematical_decay: test.decays_for_all_initial_states});
    continue;
  }
  const run = simulateFeedback(settings);
  assert.equal(JSON.stringify(settings), before);
  exact(run.q, test.q, test.name + ' q');
  exact(run.c, test.c, test.name + ' constant');
  const kind = test.decays_for_all_initial_states ? 'decay' : Math.abs(test.q) === 1 ? 'boundary' : 'growth';
  assert.equal(run.kind, kind);
  if (test.q_one_kind) {
    assert.equal(run.fixedPoint.kind, test.q_one_kind === 'all fixed' ? 'every-state' : 'none');
    assert.equal(run.fixedPoint.value, null);
  } else {
    assert.equal(run.fixedPoint.kind, 'unique');
    exact(run.fixedPoint.value, test.fixed_point, test.name + ' fixed point');
  }
  assert.equal(run.rows.length, test.trace.length);
  run.rows.forEach((row, n) => {
    const expected = test.trace[n];
    assert.equal(row.n, n);
    exact(row.x, expected.x, test.name + ' state ' + n);
    exact(row.error, expected.reference_error, test.name + ' reference error ' + n);
    exact(row.compared, row.x, test.name + ' zero-offset compared state ' + n);
    exact(row.difference, 0, test.name + ' zero-offset separation ' + n);
    exact(row.predictedDifference, 0, test.name + ' zero-offset analytical separation ' + n);
    if (n < settings.steps) {
      exact(row.control, expected.u, test.name + ' applied control ' + n);
      exact(row.next, test.trace[n + 1].x, test.name + ' next state ' + n);
      assert.equal(row.applied, true);
    } else {
      assert.equal(row.control, null);
      assert.equal(row.next, null);
      assert.equal(row.applied, false);
    }
  });
  runs.set(test.name, run);
  fs.writeFileSync(path.join(out, test.name + '.json'), JSON.stringify(run, null, 2) + '\n');
  results.push({name: test.name, result: 'exact rational states, controls, classification and fixed-point agreement',
    q: run.q, kind: run.kind, states: run.rows.length});
}
assert.equal(runs.size, 11);
const A = frozen.cases.find(c => c.name === 'two-starts-A');
const B = frozen.cases.find(c => c.name === 'two-starts-B');
const paired = simulateFeedback({...runs.get('two-starts-A').settings, offset: 1});
paired.rows.forEach((row, n) => {
  exact(row.x, A.trace[n].x, 'paired A ' + n);
  exact(row.compared, B.trace[n].x, 'paired B ' + n);
  exact(row.difference, (-0.5) ** n, 'paired actual separation ' + n);
  exact(row.predictedDifference, (-0.5) ** n, 'paired analytical separation ' + n);
  if (n < 6) exact(row.comparedControl, B.trace[n].u, 'paired compared control ' + n);
});
exact(paired.rows[3].difference, frozen.cross_case_expectation.two_starts_delta_after_three, 'frozen three-update separation');
const csv = feedbackCsv(paired);
fs.writeFileSync(path.join(out, 'paired-trace.csv'), csv);
const csvLines = csv.trimEnd().split('\r\n').map(line => {
  assert.ok(line.startsWith('"') && line.endsWith('"'));
  return line.slice(1, -1).split('","').map(cell => cell.replaceAll('""', '"'));
});
const header = csvLines[0];
assert.equal(header.length, 22);
assert.equal(csvLines.length, 8);
const col = name => {const i = header.indexOf(name); assert.ok(i >= 0, name); return i;};
csvLines.slice(1).forEach((line, n) => {
  assert.equal(line.length, header.length);
  exact(Number(line[col('n')]), n, 'CSV n');
  exact(Number(line[col('state')]), A.trace[n].x, 'CSV state');
  exact(Number(line[col('compared_state')]), B.trace[n].x, 'CSV compared state');
  exact(Number(line[col('computed_separation')]), (-0.5) ** n, 'CSV computed separation');
  exact(Number(line[col('analytical_separation')]), (-0.5) ** n, 'CSV analytical separation');
});
const last = csvLines.at(-1);
assert.equal(last[col('row_kind')], 'final-state');
assert.equal(last[col('applied_control')], '');
assert.equal(last[col('compared_applied_control')], '');
assert.equal(last[col('next_state')], '');
assert.equal(last[col('compared_next_state')], '');
assert.equal(feedbackCsv({settings: paired.settings, rows: [{x: 999}], q: 999}), csv);
const edgeResults = [];
for (const e of read('domain-edge-oracles.json').cases) {
  const run = simulateFeedback(e.settings);
  for (const row of run.rows) for (const v of Object.values(row)) {
    if (typeof v === 'number') assert.ok(Number.isFinite(v));
  }
  const last = run.rows.at(-1);
  edgeResults.push({name:e.name, states:run.rows.length,
    final:last.x, compared:last.compared,
    final_relative_error:close(last.x,e.expected_final,e.name+' final'),
    compared_relative_error:close(last.compared,e.expected_compared,e.name+' compared'),
    analytical_relative_error:close(last.predictedDifference,e.expected_analytical_difference,e.name+' analytical')});
}
const invalids = [
  ['nan-a', {...DEFAULT_SETTINGS,a:NaN}, RangeError],
  ['infinite-gain', {...DEFAULT_SETTINGS,gain:Infinity}, RangeError],
  ['string-reference', {...DEFAULT_SETTINGS,reference:'1'}, RangeError],
  ['negative-gain', {...DEFAULT_SETTINGS,gain:-0.25}, RangeError],
  ['zero-horizon', {...DEFAULT_SETTINGS,steps:0}, RangeError],
  ['over-limit-horizon', {...DEFAULT_SETTINGS,steps:61}, RangeError],
  ['fractional-horizon', {...DEFAULT_SETTINGS,steps:1.5}, RangeError],
  ['unknown-setting', {...DEFAULT_SETTINGS,unexpected:1}, TypeError],
  ['array-settings', [], TypeError]
];
for (const [name, value, type] of invalids) {
  const before = JSON.stringify(value);
  assert.throws(() => simulateFeedback(value), type, name);
  assert.equal(JSON.stringify(value), before);
}
const rounded = simulateFeedback({...DEFAULT_SETTINGS,steps:60});
const collapsed = rounded.rows.find(row => row.difference === 0 && row.predictedDifference !== 0);
assert.ok(collapsed);
const floatingBoundary = {
  boundary:'Separate computed subtraction from the exact-form analytical separation; finite iteration can round both states to the same value.',
  first_rounded_equal_row: collapsed,
  analytical_classification: rounded.kind,
  interpretation:'This is expected ordinary floating-point cancellation, not an assertion that analytical separation reached zero.'
};
fs.writeFileSync(path.join(out,'finite-precision-boundary.json'),JSON.stringify(floatingBoundary,null,2)+'\n');
for (const p of sourcesBefore) {
  assert.equal(hash(path.join(nativeRoot,p.path)),p.sha256);
  assert.equal(hash(path.join(root,p.copied_as)),p.sha256);
}
const receipt = {
  status:'pass',
  actor:'chatgpt-566d51f04b31-coordination',
  native_node:process.version,
  native_bounded_capture:pins.native_bounded_capture,
  source_files:sourcesBefore,
  blind_answers_sha256:hash(path.join(root,'blind-solved-answers.json')),
  blind_numeric_oracles_sha256:hash(path.join(root,'blind-course-numeric-oracles.json')),
  original_and_copied_source_unchanged:true,
  admitted_frozen_cases:11,
  frozen_non_grid_cases_correctly_rejected:3,
  cases:results,
  paired_separation_and_csv:true,
  final_row_has_no_applied_control:true,
  csv_recomputed_from_validated_settings:true,
  domain_edge_cases:edgeResults,
  invalid_inputs_rejected_without_mutation:invalids.map(x=>x[0]),
  finite_precision_example:{n:collapsed.n,computed:collapsed.difference,analytical:collapsed.predictedDifference},
  receiver_binding_notes:[
    'Frozen k/r/d/x0 names map to gain/reference/disturbance/initial; zero offset isolates each frozen trajectory.',
    'The last state is n=N with no applied next transition. Frozen mathematical u[N] is not misrepresented as an applied terminal control.',
    'Three pre-source-read near-unit multipliers are rejected by the documented quarter grid; their mathematical expectations remain frozen and are not silently replaced.',
    'Two 60-step corner cases were selected after reading the admitted domain and evaluated using independent rational closed-form oracles.',
    'No authored unit or browser tests were read or reused.'
  ]
};
fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({status:receipt.status,admitted_frozen_cases:11,rejected_frozen_cases:3,
  edge_cases:edgeResults,invalid_inputs:invalids.length,paired_csv:true,
  finite_precision_example:receipt.finite_precision_example,
  receipt_sha256:hash(path.join(out,'receipt.json'))}));
