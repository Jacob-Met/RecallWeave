from pathlib import Path
from fractions import Fraction as F
import json,hashlib,datetime
root=Path('/home/jacob/hamon-research-build/recall-feedback-control-review-566d51f04b31-coordination')
root.mkdir(mode=0o700,exist_ok=True)
cases=[
('stable-monotone','4/5','1/5','10','0','0'),
('stable-alternating','4/5','6/5','10','0','0'),
('growing-alternating','4/5','2','10','0','0'),
('neutral-two-cycle','1','2','10','0','0'),
('neutral-fixed-start','1','2','10','0','10'),
('unit-factor-drift','1','0','10','1','0'),
('unit-factor-all-fixed','1','0','10','0','3'),
('one-update-fixed','4/5','4/5','10','1','0'),
]
rows=[]
for name,aa,kk,rr,dd,xx in cases:
 a,k,r,d,x0=map(F,(aa,kk,rr,dd,xx));q=a-k;b=k*r+d
 x=x0;seq=[x]
 for n in range(6):x=q*x+b;seq.append(x)
 fixed=None if q==1 else b/(1-q)
 if q!=1:
  closed=[fixed+q**n*(x0-fixed) for n in range(7)]
  assert seq==closed
 else:assert seq==[x0+n*b for n in range(7)]
 rows.append({'name':name,'inputs':dict(zip(('a','k','r','d','x0'),(aa,kk,rr,dd,xx))),'q':str(q),'constant_term':str(b),'fixed_point':None if fixed is None else str(fixed),'unit_q_case':('all states fixed' if b==0 else 'no fixed point') if q==1 else None,'attracting_for_all_initial_states':abs(q)<1,'trace_exact':[str(x) for x in seq],'trace_float':[float(x) for x in seq]})
v={'status':'independent equation-only oracle; no product or authored-solution read yet','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actor':'chatgpt-566d51f04b31-coordination','equation':'u[n]=k(r-x[n]); x[n+1]=a*x[n]+u[n]+d','derivation':{'q':'a-k','b':'k*r+d','q_not_one':'x[n]=x_star+q^n*(x[0]-x_star), x_star=b/(1-q)','q_one':'x[n]=x[0]+n*b; all points fixed if b=0, otherwise no fixed point','difference':'xA[n]-xB[n]=q^n*(xA[0]-xB[0])','attraction':'For the affine model, every initial condition converges to the unique fixed point iff abs(q)<1. Starting exactly at an unstable or neutral fixed point does not prove attraction.','q_minus_one':'The fixed point exists but deviations alternate without decay, unless initially zero.','steady_error':'r-x_star=((1-a)*r-d)/(1-a+k), when the denominator is nonzero.'},'cases':rows}
p=root/'blind-numeric-oracle.json';assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cases':len(rows)}))
