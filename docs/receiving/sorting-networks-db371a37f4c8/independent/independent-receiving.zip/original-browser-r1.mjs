import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
import {chromium} from 'file:///D:/Hamon/receiving/pneumatic-goals-root-db371a37f4c8/dependencies/node_modules/playwright/index.mjs';
const root=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const read=p=>fs.readFileSync(p),parse=p=>JSON.parse(read(p).toString('utf8').replace(/^\uFEFF/,''));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const pin=p=>{const b=read(p),s=fs.statSync(p,{bigint:true});return {bytes:b.length,sha256:hash(b),mtime_ns:s.mtimeNs.toString()};};
const admission=parse(path.join(root,'ORIGINAL-ADMISSION.json')),inputs=parse(path.join(root,'ADMISSION-INPUT.json'));
for(const s of admission.source){const p=path.join(root,'original',s.path),x=pin(p);assert.equal(x.sha256,s.receiver.sha256);assert.equal(x.mtime_ns,s.receiver.mtime_ns);}
for(const d of admission.donor.files)assert.deepEqual(pin(path.join(admission.donor.root,d.path)),{bytes:d.bytes,sha256:d.sha256,mtime_ns:d.mtime_ns});
assert.deepEqual(pin(inputs.edge),{bytes:admission.edge.bytes,sha256:admission.edge.sha256,mtime_ns:admission.edge.mtime_ns});
const receipt={schema:'recall253-root-original-browser-v1',started:new Date().toISOString(),pid:process.pid,parent:process.ppid,source_commit:admission.source_commit,status:'running',groups:[],requests:[],externalRequests:[],pageErrors:[],consoleErrors:[],browserProcesses:[],captures:[],candidate_exposure:false};
let browser,context;
async function group(name,fn){const g={name,start:new Date().toISOString()};receipt.groups.push(g);try{g.result=await fn();g.status='passed';}catch(e){g.status='failed';g.error=String(e.stack||e);throw e;}finally{g.end=new Date().toISOString();}}
try{
  browser=await chromium.launch({executablePath:inputs.edge,headless:true,chromiumSandbox:true,timeout:45000});
  receipt.browserVersion=browser.version();
  context=await browser.newContext({viewport:{width:1360,height:900},acceptDownloads:true,serviceWorkers:'block'});
  await context.setOffline(true);const page=await context.newPage();page.setDefaultTimeout(12000);
  page.on('request',r=>{receipt.requests.push(r.url());if(!/^(file|data|blob):/.test(r.url()))receipt.externalRequests.push(r.url());});
  page.on('pageerror',e=>receipt.pageErrors.push(String(e)));page.on('console',m=>{if(m.type()==='error')receipt.consoleErrors.push(m.text());});
  const fixture=parse(path.join(root,'ORIGINAL-DECK.json'));
  await group('original direct-open, valid preview cancellation and malformed later-item preservation',async()=>{
    await page.goto(pathToFileURL(path.join(root,'original/demo.html')).href,{waitUntil:'load'});
    await page.locator('#start-button').click();await page.locator('[data-choice]').first().click();await page.locator('#next-button').waitFor();
    const before=await page.locator('#session-content').innerHTML(),beforeCount=await page.locator('#step-count').innerText();
    await page.locator('#deck-file').setInputFiles(path.join(root,'ORIGINAL-DECK.json'));await page.locator('#start-deck').waitFor();
    assert.equal(await page.locator('#deck-preview-title').innerText(),fixture.title);assert.equal(await page.locator('#session-content').innerHTML(),before);
    await page.locator('#cancel-deck').click();assert.equal(await page.locator('#session-content').innerHTML(),before);
    await page.locator('#deck-file').setInputFiles(path.join(root,'ORIGINAL-INVALID-DECK.json'));
    await page.waitForFunction(()=>document.querySelector('#deck-status').textContent.includes('items[1].answer'));
    assert.equal(await page.locator('#session-content').innerHTML(),before);assert.equal(await page.locator('#step-count').innerText(),beforeCount);
    return {originalCount:beforeCount,previewDidNotReplace:true,cancelDidNotReplace:true,malformedLaterItemDidNotReplace:true,error:await page.locator('#deck-status').innerText()};
  });
  await group('explicit original learner import and responsive controls',async()=>{
    await page.locator('#deck-file').setInputFiles(path.join(root,'ORIGINAL-DECK.json'));await page.locator('#start-deck').click();await page.locator('[data-choice]').first().waitFor();
    assert.equal(await page.locator('#step-count').innerText(),'0 / 2');assert.equal(await page.locator('#lesson-description').innerText(),fixture.title);
    const layouts=[];
    for(const viewport of [{width:1360,height:900},{width:390,height:844}]){
      await page.setViewportSize(viewport);await page.locator('[data-choice]').first().scrollIntoViewIfNeeded();
      const bounds=await page.evaluate(()=>({innerWidth,innerHeight,documentWidth:document.documentElement.scrollWidth,controls:[...document.querySelectorAll('#deck-file,[data-choice]')].map(e=>{const r=e.getBoundingClientRect();return {id:e.id||e.getAttribute('data-choice'),x:r.x,y:r.y,width:r.width,height:r.height};})}));
      for(const b of bounds.controls){assert.ok(b.width>0&&b.height>0);assert.ok(b.x>=-1&&b.x+b.width<=viewport.width+1,JSON.stringify(b));}
      const name='original-'+viewport.width+'x'+viewport.height+'.png';await page.screenshot({path:path.join(root,name),fullPage:true});
      receipt.captures.push({path:name,...pin(path.join(root,name)),viewport,bounds});layouts.push(bounds);
    }
    await page.setViewportSize({width:1360,height:900});return {title:await page.title(),layouts};
  });
  let firstSummary,firstAnswers,firstMastery,wrongId;
  const note='Independent ordering note: comparisons preserve the other positions.',application='I can count positions even when values repeat.';
  await group('two actual answers, review, reflection and missed-question practice',async()=>{
    const answered=[];
    for(let i=0;i<2;i++){
      const prompt=await page.locator('#session-content h2').innerText(),item=fixture.items.find(x=>x.prompt===prompt);assert.ok(item);
      const choice=i===0?(item.answer+1)%item.options.length:item.answer;if(i===0)wrongId=item.id;
      await page.locator('[data-choice="'+choice+'"]').click();await page.locator('#next-button').waitFor();answered.push({id:item.id,prompt,choice,correct:choice===item.answer});await page.locator('#next-button').click();
    }
    await page.locator('#first-try-summary').waitFor();firstSummary=await page.locator('#first-try-summary').innerText();assert.ok(firstSummary.includes('1 of 2'));
    firstAnswers=await page.locator('.review-answers').allInnerTexts();firstMastery=await page.locator('.mastery-box output').allInnerTexts();
    await page.locator('.review-item').first().locator('summary').click();await page.locator('[data-reflection-item]').first().fill(note);await page.locator('#application-reflection').fill(application);
    await page.locator('#practice-button').click();const missed=fixture.items.find(x=>x.id===wrongId);assert.equal(await page.locator('#session-content h2').innerText(),missed.prompt);
    await page.locator('[data-practice-choice="'+missed.answer+'"]').click();await page.locator('#practice-next').click();await page.locator('#first-try-summary').waitFor();
    assert.equal(await page.locator('#first-try-summary').innerText(),firstSummary);assert.deepEqual(await page.locator('.review-answers').allInnerTexts(),firstAnswers);assert.deepEqual(await page.locator('.mastery-box output').allInnerTexts(),firstMastery);
    assert.equal(await page.locator('[data-reflection-item]').first().inputValue(),note);assert.equal(await page.locator('#application-reflection').inputValue(),application);
    return {answered,firstSummary,firstAnswers,firstMastery,practiceCorrect:true,firstAnswersAndMasteryPreserved:true,reflectionsPreserved:true};
  });
  await group('actual original learner notes download and offline state',async()=>{
    const pending=page.waitForEvent('download');await page.locator('#save-notes-button').click();const download=await pending;
    const destination=path.join(root,'downloads/original-study-notes.txt');await download.saveAs(destination);const text=read(destination).toString('utf8');
    for(const wanted of [fixture.title,...fixture.items.map(x=>x.prompt),note,application])assert.ok(text.includes(wanted),wanted);
    const storage=await page.evaluate(()=>({local:localStorage.length,session:sessionStorage.length}));
    assert.deepEqual(storage,{local:0,session:0});assert.deepEqual(receipt.externalRequests,[]);assert.deepEqual(receipt.pageErrors,[]);
    return {filename:download.suggestedFilename(),path:destination,...pin(destination),text,storage,externalRequests:0,pageErrors:0};
  });
  try{const cdp=await browser.newBrowserCDPSession();receipt.browserProcesses=(await cdp.send('SystemInfo.getProcessInfo')).processInfo;await cdp.detach();}catch(e){receipt.processInfoObserver=String(e);}
  receipt.status='passed';
}catch(e){receipt.status='failed';receipt.error=String(e.stack||e);process.exitCode=1;}
finally{
  if(context)await context.close().catch(e=>{receipt.contextCloseError=String(e);process.exitCode=1;});
  if(browser)await browser.close().then(()=>receipt.browserClosed=true).catch(e=>{receipt.browserCloseError=String(e);process.exitCode=1;});
  receipt.finished=new Date().toISOString();
  receipt.sourceUnchanged=admission.source.every(s=>{const x=pin(path.join(root,'original',s.path));return x.sha256===s.receiver.sha256&&x.mtime_ns===s.receiver.mtime_ns;});
  receipt.donorUnchanged=admission.donor.files.every(d=>{const x=pin(path.join(admission.donor.root,d.path));return x.sha256===d.sha256&&x.mtime_ns===d.mtime_ns;});
  if(!receipt.sourceUnchanged||!receipt.donorUnchanged){receipt.status='failed';process.exitCode=1;}
  fs.writeFileSync(path.join(root,'ORIGINAL-BROWSER-r1.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({status:receipt.status,pid:process.pid,groups:receipt.groups.map(g=>({name:g.name,status:g.status})),browserClosed:receipt.browserClosed,sourceUnchanged:receipt.sourceUnchanged,donorUnchanged:receipt.donorUnchanged}));
}
