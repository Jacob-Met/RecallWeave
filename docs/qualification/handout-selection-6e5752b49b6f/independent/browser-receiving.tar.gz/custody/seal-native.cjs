const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { gzipSync, gunzipSync } = require('node:zlib');
const STAGE = __dirname, BASE = path.dirname(STAGE);
const hash = b => createHash('sha256').update(b).digest('hex');
const blob = b => createHash('sha1').update(Buffer.from('blob ' + b.length + '\0')).update(b).digest('hex');
const specs = [
  { name: 'la7-readiness', roots: ['browser-readiness-r0', 'browser-readiness-r1'], metadata: 'la7-readiness-metadata.json' },
  { name: 'recall170-root-browser', roots: ['handout-selection-root-r0'], metadata: 'recall170-root-metadata.json' }
];
function file(p, member) {
  const before = fs.lstatSync(p); assert.ok(before.isFile() && !before.isSymbolicLink(), 'regular owned file');
  const bytes = fs.readFileSync(p), after = fs.lstatSync(p);
  assert.equal(before.size, after.size); assert.equal(before.mtimeMs, after.mtimeMs); assert.equal(bytes.length, before.size);
  return { path: member, nativePath: p, bytes: bytes.length, sha256: hash(bytes), gitBlob: blob(bytes), mtimeMs: before.mtimeMs, payload: bytes };
}
function walk(root, relative, entries, excluded) {
  const actual = path.join(BASE, root, relative);
  for (const de of fs.readdirSync(actual, { withFileTypes: true }).sort((a,b)=>a.name.localeCompare(b.name))) {
    const child = relative ? relative + '/' + de.name : de.name;
    const p = path.join(BASE, root, child);
    const st = fs.lstatSync(p);
    if (de.name === 'chrome-profile' && st.isDirectory() && !st.isSymbolicLink()) { excluded.push({ path: root + '/' + child, reason: 'Owned temporary browser cache retained locally; not an acceptance artifact' }); continue; }
    if (st.isDirectory() && !st.isSymbolicLink()) walk(root, child, entries, excluded);
    else entries.push(file(p, root + '/' + child));
  }
}
function octal(header, offset, length, n) {
  const value = Math.trunc(n).toString(8); assert.ok(value.length < length);
  header.write(value.padStart(length - 1, '0') + '\0', offset, length, 'ascii');
}
function tar(entries) {
  const chunks = [];
  for (const e of entries) {
    assert.match(e.path, /^[A-Za-z0-9._/-]+$/); assert.ok(!e.path.includes('..') && !e.path.startsWith('/') && e.path.length <= 100);
    const h = Buffer.alloc(512);
    h.write(e.path, 0, 100, 'ascii'); octal(h, 100, 8, 0o644); octal(h, 108, 8, 0); octal(h, 116, 8, 0);
    octal(h, 124, 12, e.payload.length); octal(h, 136, 12, 0);
    h.fill(32, 148, 156); h[156] = 48; h.write('ustar\0', 257, 6, 'ascii'); h.write('00', 263, 2, 'ascii');
    const checksum = [...h].reduce((a,b)=>a+b,0);
    h.write(checksum.toString(8).padStart(6,'0') + '\0 ', 148, 8, 'ascii');
    chunks.push(h, e.payload);
    if (e.payload.length % 512) chunks.push(Buffer.alloc(512 - e.payload.length % 512));
  }
  chunks.push(Buffer.alloc(1024)); return Buffer.concat(chunks);
}
const index = { schema: 'hamon-owned-receiving-archives/1', createdUtc: new Date().toISOString(), nativeNode: process.version, root: STAGE, format: 'POSIX ustar, normalized0644/uid0/gid0/mtime0; original native byte hashes and mtimes in manifest', archives: [] };
for (const spec of specs) {
  const entries = [], excluded = [];
  for (const root of spec.roots) walk(root, '', entries, excluded);
  entries.push(file(path.join(STAGE, spec.metadata), 'custody/' + spec.metadata));
  entries.push(file(__filename, 'custody/seal-native.cjs'));
  entries.sort((a,b)=>a.path.localeCompare(b.path));
  assert.ok(entries.length < 500 && entries.reduce((n,e)=>n+e.bytes,0) < 32*1024*1024, 'bounded owned evidence');
  const manifest = { schema: 'hamon-native-file-manifest/1', name: spec.name, excludedRetainedLocally: excluded, files: entries.map(({payload,...e})=>e) };
  const manifestBytes = Buffer.from(JSON.stringify(manifest,null,2)+'\n');
  const all = [...entries, { path: 'manifest.json', payload: manifestBytes }];
  const bytes = gzipSync(tar(all), { level: 9 });
  const archivePath = path.join(STAGE, spec.name + '.tar.gz');
  fs.writeFileSync(archivePath, bytes, { flag: 'wx' });
  const reRead = fs.readFileSync(archivePath); assert.deepEqual(reRead, bytes); assert.deepEqual(gunzipSync(reRead), tar(all));
  for (const e of entries) {
    const after = file(e.nativePath, e.path); assert.equal(after.sha256,e.sha256); assert.equal(after.bytes,e.bytes); assert.equal(after.mtimeMs,e.mtimeMs);
  }
  const base64 = bytes.toString('base64');
  fs.writeFileSync(archivePath + '.base64', base64.match(/.{1,76}/g).join('\n')+'\n', { flag: 'wx' });
  const record = { name: spec.name, path: archivePath, bytes: bytes.length, sha256: hash(bytes), gitBlob: blob(bytes), memberCount: all.length, payloadFiles: entries.length, payloadBytes: entries.reduce((n,e)=>n+e.bytes,0), manifestSha256: hash(manifestBytes), base64Characters: base64.length, excludedRetainedLocally: excluded, files: entries.map(({payload,...e})=>e) };
  index.archives.push(record);
}
fs.writeFileSync(path.join(STAGE,'native-archive-index.json'), JSON.stringify(index,null,2)+'\n', { flag: 'wx' });
console.log(JSON.stringify({ schema:index.schema, archives:index.archives.map(({files,...a})=>a), index:path.join(STAGE,'native-archive-index.json') }));
