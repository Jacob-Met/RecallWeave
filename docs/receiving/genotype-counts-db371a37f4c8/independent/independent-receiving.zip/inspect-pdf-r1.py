import sys,json,pathlib,hashlib,datetime
import fitz
r=pathlib.Path(r'D:\Hamon\receiving\recall-genotype-counts-root-db371a37f4c8')
p=r/'candidate-worksheet-print-r1.pdf'
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest(),'mtime_ns':str(p.stat().st_mtime_ns)}
source=pin(p)
assert source['bytes']==189854 and source['sha256']=='12ed871b295e06b976ff37f2a77251367b8b84e866979b9be2188d6cedafdf83'
python=pin(pathlib.Path(sys.executable))
assert python['sha256']=='5f7b89a612c9b8af1d6456cdfcd1dbe5ca630849e79aebced9bee9a6694952ec'
dest=r/'pdf-review-r1';dest.mkdir()
doc=fitz.open(p)
assert 1<=len(doc)<=8
pages=[]
for i,page in enumerate(doc):
 image=dest/('page-'+str(i+1)+'.png')
 pix=page.get_pixmap(matrix=fitz.Matrix(110/72,110/72),alpha=False);pix.save(image)
 words=page.get_text('words')
 outside=[list(x) for x in words if x[0]<-0.5 or x[1]<-0.5 or x[2]>page.rect.width+0.5 or x[3]>page.rect.height+0.5]
 pages.append({'page':i+1,'size_points':[page.rect.width,page.rect.height],'text':page.get_text(),'word_count':len(words),'outside_page':outside,'image':{'path':str(image),**pin(image)}})
assert pin(p)==source
receipt={'schema':'recall261-root-native-pdf-inspection-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':__import__('os').getpid(),'python':python,'fitz_version':fitz.VersionBind,'source':{'path':str(p),**source},'page_count':len(doc),'expected_pages':3,'page_count_matches':len(doc)==3,'pages':pages,'source_unchanged':True,'screen_review':'Pending root direct reading of every rendered page','container_transfer_failure':'Read-only attempt to copy native PDF to scratch for Poppler stopped: overlay full and /dev/shm only140KiB free. No files deleted or product rerun. Existing native PyMuPDF used on exact retained PDF instead.'}
out=dest/'PDF-INSPECTION.json';out.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'status':'rendered','pages':len(doc),'page_count_matches':len(doc)==3,'outside_words':sum(len(p['outside_page']) for p in pages),'receipt':str(out)},ensure_ascii=True))
