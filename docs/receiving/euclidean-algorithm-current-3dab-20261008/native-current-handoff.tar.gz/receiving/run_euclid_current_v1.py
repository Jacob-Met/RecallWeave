import pathlib,hashlib,json,subprocess,datetime,sys
root=pathlib.Path('/home/jacob/snap/chromium/common/optimizer-euclid-current-handoff-3dab-20261008')
script=root/'receiving/receive_euclid_current_v1.mjs'
out=root/'receiving/command-v1';out.mkdir()
b=script.read_bytes();assert hashlib.sha256(b).hexdigest()=='f43e5e7098d7fbb0fb467e12e01b1ca374df81a9e7a4f536310d23844a289dae'
r={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receiver_sha256':hashlib.sha256(b).hexdigest(),'argv':['/usr/bin/node',str(script)],'source_manifest':'7ce2bcfcecff22ef8d5493d815e1675ac887c8d3ad860a8c04d88a804d7a519f','stages':[]}
for label,argv in [('syntax',['/usr/bin/node','--check',str(script)]),('browser',r['argv'])]:
 p=subprocess.run(argv,capture_output=True,timeout=240)
 (out/(label+'-stdout.txt')).write_bytes(p.stdout);(out/(label+'-stderr.txt')).write_bytes(p.stderr)
 stage={'label':label,'argv':argv,'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 r['stages'].append(stage)
 print(label,p.returncode,p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'),flush=True)
 if p.returncode:break
r['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
r['receiver_unchanged']=script.read_bytes()==b
r['accepted']=len(r['stages'])==2 and all(x['exit_code']==0 for x in r['stages']) and r['receiver_unchanged'] and p.stdout.decode().splitlines().count('EUCLID_HANDOFF_OK checks=4 failures=0')==1
if (root/'receiving/browser-v1/browser-report.json').exists():
 report=(root/'receiving/browser-v1/browser-report.json').read_bytes();r['report_sha256']=hashlib.sha256(report).hexdigest();r['report_status']=json.loads(report)['status'];r['accepted']=r['accepted'] and r['report_status']=='passed'
(out/'controller.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print('EUCLID_CONTROLLER_'+('OK' if r['accepted'] else 'FAILED'),flush=True)
sys.exit(0 if r['accepted'] else 1)
