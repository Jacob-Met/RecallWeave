/**
 * Transparent Bayesian Knowledge Tracing and adaptive item selection.
 * Parameters are pedagogical defaults, not fitted or validated estimates.
 * @typedef {{id:string, concept:string, prerequisites:string[], options:string[], answer:number, prompt:string, explanation:string, transfer:string}} Item
 * @typedef {{initial:number, learn:number, guess:number, slip:number}} BktParameters
 */
const DEFAULT_BKT = Object.freeze({ initial: 0.22, learn: 0.18, guess: 0.2, slip: 0.1 });
const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));

/** Bernoulli entropy in bits. @param {number} p */
function entropy(p) {
  const q = clamp(p);
  if (q === 0 || q === 1) return 0;
  return -q * Math.log2(q) - (1 - q) * Math.log2(1 - q);
}

/**
 * One BKT update. Correctness is evidence, not certainty; a guess and a slip remain possible.
 * @param {number} prior
 * @param {boolean} correct
 * @param {BktParameters} parameters
 */
function updateMastery(prior, correct, parameters = DEFAULT_BKT) {
  const p = clamp(prior);
  const { guess, slip, learn } = parameters;
  for (const [key, value] of Object.entries(parameters)) {
    if (!Number.isFinite(value) || value < 0 || value > 1) throw new RangeError(`${key} must be in [0,1]`);
  }
  const pCorrect = p * (1 - slip) + (1 - p) * guess;
  const posterior = correct ? p * (1 - slip) / pCorrect : p * slip / (p * slip + (1 - p) * (1 - guess));
  return clamp(posterior + (1 - posterior) * learn);
}

/** Expected reduction in uncertainty from an item response under its concept mastery.
 * @param {number} mastery
 * @param {BktParameters} parameters
 */
function expectedInformationGain(mastery, parameters = DEFAULT_BKT) {
  const p = clamp(mastery);
  const { guess, slip } = parameters;
  const pCorrect = p * (1 - slip) + (1 - p) * guess;
  const correctPosterior = p * (1 - slip) / pCorrect;
  const wrongPosterior = p * slip / (p * slip + (1 - p) * (1 - guess));
  return Math.max(0, entropy(p) - pCorrect * entropy(correctPosterior) - (1 - pCorrect) * entropy(wrongPosterior));
}

/**
 * Select an unseen item maximizing uncertainty reduction plus prerequisite repair.
 * Tie-break is stable by item id, making the choice reproducible.
 * @param {Item[]} items
 * @param {Set<string>} asked
 * @param {Record<string,number>} mastery
 * @param {BktParameters} parameters
 * @returns {Item|null}
 */
function selectNextItem(items, asked, mastery, parameters = DEFAULT_BKT) {
  const candidates = items.filter(item => !asked.has(item.id));
  if (!candidates.length) return null;
  const score = item => {
    const m = mastery[item.concept] ?? parameters.initial;
    // Prefer a weak concept that unlocks several still-unanswered downstream ideas.
    const downstream = candidates.filter(next => next.id !== item.id && next.prerequisites.includes(item.concept)).length;
    const prerequisiteRepair = (1 - m) * Math.min(3, downstream) * 0.12;
    return expectedInformationGain(m, parameters) + prerequisiteRepair;
  };
  return candidates.sort((a, b) => score(b) - score(a) || a.id.localeCompare(b.id))[0];
}

/** Clone session probabilities so learners' local run has no shared state. */
function initialMastery(concepts, parameters = DEFAULT_BKT) {
  return Object.fromEntries(concepts.map(concept => [concept, parameters.initial]));
}

/**
 * Reproducible toy learner run; simulated evidence is never real learner data.
 * @param {Item[]} items
 * @param {string[]} concepts
 * @param {Record<string,number>} latentKnowledge simulated probability of knowing each concept
 * @param {boolean} adaptive use the information-gain selector, or fixed deck order
 * @param {number} seed deterministic pseudo-random seed
 */
function runLearnerSimulation(items, concepts, latentKnowledge, adaptive = true, seed = 20261005) {
  let state = seed >>> 0 || 1;
  const random = () => {
    state ^= state << 13; state ^= state >>> 17; state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
  const stateByConcept = initialMastery(concepts);
  const asked = new Set();
  const trace = [];
  while (asked.size < items.length) {
    const item = adaptive ? selectNextItem(items, asked, stateByConcept) : items.find(candidate => !asked.has(candidate.id));
    const knowledge = clamp(latentKnowledge[item.concept] ?? 0.5);
    const correct = random() < 0.18 + knowledge * 0.72;
    asked.add(item.id);
    stateByConcept[item.concept] = updateMastery(stateByConcept[item.concept], correct);
    trace.push({ item: item.id, concept: item.concept, correct });
  }
  const meanEstimatedMastery = concepts.reduce((sum, concept) => sum + stateByConcept[concept], 0) / concepts.length;
  return { trace, mastery: stateByConcept, meanEstimatedMastery };
}

/**
 * A local review snapshot and one bounded practice round.
 * Practice never updates the original answers or the knowledge model.
 */

function validChoice(item, choice) {
  if (!Number.isInteger(choice) || choice < 0 || choice >= item.options.length) {
    throw new RangeError('Choose one of this question’s answer options.');
  }
}

/** Keep the first-attempt order, chosen answer and explanation available for review. */
function createReview(items, answers) {
  const byId = new Map(items.map(item => [item.id, item]));
  const seen = new Set();
  return Object.freeze(answers.map(answer => {
    const item = byId.get(answer.item);
    if (!item || seen.has(item.id)) throw new RangeError('Review needs one first answer per known question.');
    seen.add(item.id);
    validChoice(item, answer.choice);
    return Object.freeze({
      id: item.id,
      concept: item.concept,
      prompt: item.prompt,
      options: Object.freeze([...item.options]),
      answer: item.answer,
      choice: answer.choice,
      correct: answer.choice === item.answer,
      explanation: item.explanation,
      transfer: item.transfer
    });
  }));
}

/** Each initially missed question gets one retry, in its original session order. */
function beginPractice(review) {
  return Object.freeze({
    items: Object.freeze(review.filter(item => !item.correct)),
    answers: Object.freeze([])
  });
}

function currentPracticeItem(round) {
  return round.items[round.answers.length] ?? null;
}

/** Return new practice state; both the review and earlier round states stay intact. */
function answerPractice(round, itemId, choice) {
  const item = currentPracticeItem(round);
  if (!item || item.id !== itemId) throw new RangeError('Only the current unanswered practice question can be answered.');
  validChoice(item, choice);
  return Object.freeze({
    items: round.items,
    answers: Object.freeze([...round.answers, Object.freeze({item: item.id, choice, correct: choice === item.answer})])
  });
}

/** Build local, readable study notes from a completed first session and separate practice. */
function createStudyNotes({ deck, review, mastery, practice = null, exportedAt = new Date(), conceptLabel = id => id }) {
  if (!Array.isArray(review) || review.length !== deck.items.length || review.length === 0) {
    throw new RangeError('Finish the learning session before saving study notes.');
  }
  const known = new Set(deck.items.map(item => item.id));
  const seen = new Set();
  for (const item of review) {
    if (!known.has(item.id) || seen.has(item.id)) throw new RangeError('Study notes need every first answer exactly once.');
    seen.add(item.id);
    for (const choice of [item.choice, item.answer]) {
      if (!Number.isInteger(choice) || choice < 0 || choice >= item.options.length) {
        throw new RangeError('Study notes need the recorded answer choice.');
      }
    }
  }
  const missed = review.filter(item => item.choice !== item.answer);
  const retries = practice?.answers ?? [];
  if (retries.length > missed.length) throw new RangeError('Practice must remain separate from the first session.');
  retries.forEach((retry, index) => {
    const item = missed[index];
    if (retry.item !== item.id || !Number.isInteger(retry.choice) || retry.choice < 0 || retry.choice >= item.options.length) {
      throw new RangeError('Study notes need the recorded practice order and choices.');
    }
  });
  const savedAt = new Date(exportedAt);
  if (!Number.isFinite(savedAt.getTime())) throw new RangeError('Study notes need a valid save time.');
  const lines = [
    'RecallWeave — study notes',
    deck.title,
    `Saved: ${savedAt.toISOString()}`,
    '',
    'FIRST SESSION',
    `${review.length - missed.length} of ${review.length} connections correct on the first try.`,
    'This count describes this session; it is not a measure of your ability.',
    '',
    'ESTIMATED MASTERY — MODEL STATE, NOT A GRADE',
    'These estimates come from the demo’s learning model. They are not a validated assessment.',
    'Practice does not change the first-session estimates.'
  ];
  for (const concept of deck.concepts) {
    const value = mastery[concept];
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1) {
      throw new RangeError('Study notes need the original model estimates.');
    }
    lines.push(`${conceptLabel(concept)}: ${Math.round(value * 100)}%`);
  }
  lines.push('', 'PRACTICE');
  if (!missed.length) lines.push('No missed connections in the first session.');
  else if (!practice) lines.push(`Not started. ${missed.length} missed ${missed.length === 1 ? 'connection is' : 'connections are'} available for practice.`);
  else {
    const correct = retries.filter((retry, index) => retry.choice === missed[index].answer).length;
    lines.push(`${retries.length === missed.length ? 'Complete' : 'Paused'}: ${retries.length} of ${missed.length} practice answers recorded; ${correct} correct on retry.`);
  }
  lines.push('Practice follows the explanations and is recorded separately from the first answers.', '', 'REVIEW THE CONNECTIONS');
  const retryById = new Map(retries.map(retry => [retry.item, retry]));
  review.forEach((item, index) => {
    const retry = retryById.get(item.id);
    lines.push(
      '',
      `${index + 1}. ${item.prompt}`,
      `Concept: ${conceptLabel(item.concept)}`,
      `Your first answer: ${item.options[item.choice]}`,
      `First try: ${item.choice === item.answer ? 'correct' : 'needs review'}`,
      `Correct answer: ${item.options[item.answer]}`,
      `Explanation: ${item.explanation}`,
      `Apply the idea: ${item.transfer}`
    );
    if (retry) {
      lines.push(`Practice answer: ${item.options[retry.choice]}`, `Practice result: ${retry.choice === item.answer ? 'correct on retry' : 'keep reviewing'}`);
    } else if (item.choice !== item.answer) lines.push('Practice answer: not recorded.');
  });
  lines.push('', 'DECK ATTRIBUTION', deck.attribution, deck.license, '', 'Saved from this browser session. The download does not upload the session or restore it after a refresh.');
  return Object.freeze({
    filename: `recallweave-study-notes-${savedAt.toISOString().slice(0, 10)}.txt`,
    mediaType: 'text/plain;charset=utf-8',
    text: `${lines.join('\n')}\n`
  });
}

/** A session-local display order; each value remains the original answer-option index. */
function orderOptions(count, random = Math.random) {
  if (!Number.isInteger(count) || count < 0) throw new RangeError('Option count must be a nonnegative integer.');
  const order = Array.from({length: count}, (_, index) => index);
  for (let index = order.length - 1; index > 0; index--) {
    const value = random();
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value >= 1) {
      throw new RangeError('The option-order source must return a number from zero up to one.');
    }
    const target = Math.floor(value * (index + 1));
    [order[index], order[target]] = [order[target], order[index]];
  }
  return Object.freeze(order);
}

/** Local lesson content. Imported data cannot replace the model or run code. */
const DECK_FORMAT = 'recallweave-deck/1';
const MAX_DECK_BYTES = 262144;

function deckRecord(value, path) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`${path} must be an object.`);
  }
  return value;
}

function deckText(value, path, limit) {
  if (typeof value !== 'string' || !value.trim() || value.length > limit) {
    throw new Error(`${path} must be nonempty text of at most ${limit} characters.`);
  }
  return value;
}

function deckList(value, path, minimum, maximum) {
  if (!Array.isArray(value) || value.length < minimum || value.length > maximum) {
    throw new Error(`${path} must contain ${minimum}–${maximum} entries.`);
  }
  return value;
}

/** Validate and copy only the content fields used by the existing lesson runtime. */
function validateDeck(value) {
  const input = deckRecord(value, 'Deck');
  if (input.format !== undefined && input.format !== DECK_FORMAT) {
    throw new Error(`Unsupported deck format. Use ${DECK_FORMAT}.`);
  }
  const title = deckText(input.title, 'title', 160);
  const attribution = deckText(input.attribution, 'attribution', 2000);
  const license = deckText(input.license, 'license', 2000);
  const concepts = deckList(input.concepts, 'concepts', 1, 32).map((concept, index) =>
    deckText(concept, `concepts[${index}]`, 80));
  if (new Set(concepts).size !== concepts.length) throw new Error('Concept names must be unique.');
  const knownConcepts = new Set(concepts);
  const ids = new Set();
  const coveredConcepts = new Set();
  const links = new Map(concepts.map(concept => [concept, new Set()]));
  const items = deckList(input.items, 'items', 1, 100).map((value, index) => {
    const path = `items[${index}]`;
    const item = deckRecord(value, path);
    const id = deckText(item.id, `${path}.id`, 80);
    if (ids.has(id)) throw new Error(`${path}.id duplicates another question ID.`);
    ids.add(id);
    const concept = deckText(item.concept, `${path}.concept`, 80);
    if (!knownConcepts.has(concept)) throw new Error(`${path}.concept is not in concepts.`);
    coveredConcepts.add(concept);
    const prerequisites = deckList(item.prerequisites, `${path}.prerequisites`, 0, 31).map((name, p) => {
      deckText(name, `${path}.prerequisites[${p}]`, 80);
      if (!knownConcepts.has(name)) throw new Error(`${path}.prerequisites contains an unknown concept.`);
      if (name === concept) throw new Error(`${path} cannot require its own concept.`);
      links.get(concept).add(name);
      return name;
    });
    if (new Set(prerequisites).size !== prerequisites.length) throw new Error(`${path}.prerequisites contains a duplicate.`);
    const options = deckList(item.options, `${path}.options`, 2, 6).map((option, o) =>
      deckText(option, `${path}.options[${o}]`, 1000));
    if (new Set(options).size !== options.length) throw new Error(`${path}.options must be distinct.`);
    if (!Number.isInteger(item.answer) || item.answer < 0 || item.answer >= options.length) {
      throw new Error(`${path}.answer must be a zero-based index of an option.`);
    }
    return Object.freeze({
      id, concept, prerequisites: Object.freeze(prerequisites),
      prompt: deckText(item.prompt, `${path}.prompt`, 2000),
      options: Object.freeze(options), answer: item.answer,
      explanation: deckText(item.explanation, `${path}.explanation`, 4000),
      transfer: deckText(item.transfer, `${path}.transfer`, 2000)
    });
  });
  if (coveredConcepts.size !== concepts.length) throw new Error('Every concept must have at least one question.');
  const visiting = new Set();
  const visited = new Set();
  const visit = concept => {
    if (visiting.has(concept)) throw new Error('Prerequisite links must not form a cycle.');
    if (visited.has(concept)) return;
    visiting.add(concept);
    for (const prerequisite of links.get(concept)) visit(prerequisite);
    visiting.delete(concept);
    visited.add(concept);
  };
  concepts.forEach(visit);
  return Object.freeze({
    format: DECK_FORMAT, title, attribution, license,
    concepts: Object.freeze(concepts), items: Object.freeze(items)
  });
}

/** The same size limit applies to a File and to programmatically supplied UTF-8 JSON. */
function parseDeck(text) {
  if (typeof text !== 'string' || new TextEncoder().encode(text).length > MAX_DECK_BYTES) {
    throw new Error('Choose a JSON deck no larger than 256 KiB.');
  }
  let value;
  try { value = JSON.parse(text); }
  catch { throw new Error('The file is not valid JSON. Check its commas, quotes and brackets.'); }
  return validateDeck(value);
}

/** Export the existing bundled lesson as an editable example of the same contract. */
function serializeDeck(deck) {
  return JSON.stringify(validateDeck(deck), null, 2) + '\n';
}


/** Stage a local file without touching the current learning session until Start. */
function mountDeckPicker(element, bundledDeck, onStart) {
  const input = element.querySelector('#deck-file');
  const status = element.querySelector('#deck-status');
  const preview = element.querySelector('#deck-preview');
  let revision = 0;
  let pending = null;

  function message(text, error = false) {
    status.textContent = text;
    status.classList.toggle('deck-error', error);
  }
  function clearPreview() {
    pending = null;
    preview.replaceChildren();
    preview.hidden = true;
  }
  function showPreview(deck, source) {
    pending = deck;
    preview.hidden = false;
    preview.innerHTML = '<h3 id="deck-preview-title" tabindex="-1"></h3><p class="deck-preview-count"></p><p class="deck-preview-attribution"></p><p class="deck-preview-license"></p><details class="deck-questions"><summary>Preview question prompts</summary><ol></ol></details><p class="deck-replace-note">Starting this deck replaces the current session and its practice answers. Your file stays on this device.</p><div class="deck-actions"><button class="primary-button" id="start-deck">Start this deck</button><button class="reset-button" id="cancel-deck">Cancel preview</button></div>';
    preview.querySelector('h3').textContent = deck.title;
    preview.querySelector('.deck-preview-count').textContent = `${source} · ${deck.items.length} questions · ${deck.concepts.length} concepts`;
    preview.querySelector('.deck-preview-attribution').textContent = `Attribution supplied in the deck: ${deck.attribution}`;
    preview.querySelector('.deck-preview-license').textContent = `License supplied in the deck: ${deck.license}`;
    const list = preview.querySelector('ol');
    for (const item of deck.items) {
      const row = document.createElement('li');
      const prompt = document.createElement('strong');
      prompt.textContent = item.prompt;
      const concept = document.createElement('p');
      concept.textContent = `${item.concept} · ${item.prerequisites.length ? `Prerequisites: ${item.prerequisites.join(', ')}` : 'No prerequisites'}`;
      row.append(prompt, concept);
      list.append(row);
    }
    preview.querySelector('#cancel-deck').addEventListener('click', () => {
      revision++;
      clearPreview();
      input.value = '';
      message('Preview cancelled. Your current session is unchanged.');
      input.focus();
    });
    preview.querySelector('#start-deck').addEventListener('click', () => {
      if (pending !== deck) return;
      const selected = deck;
      revision++;
      clearPreview();
      input.value = '';
      onStart(selected);
      message(`Started “${selected.title}”. This lesson stays in this tab until you reload or choose another deck.`);
    });
    message('Deck ready to preview. Your current session continues until you choose Start this deck.');
    preview.querySelector('h3').focus();
  }

  input.addEventListener('change', async () => {
    const file = input.files?.[0];
    if (!file) return;
    const request = ++revision;
    clearPreview();
    message('Reading the local deck…');
    try {
      if (file.size > MAX_DECK_BYTES) throw new Error('Choose a JSON deck no larger than 256 KiB.');
      let text;
      try { text = await file.text(); }
      catch { throw new Error('The file could not be read. Choose it again.'); }
      if (request !== revision) return;
      showPreview(parseDeck(text), file.name);
    } catch (error) {
      if (request !== revision) return;
      clearPreview();
      message(`${error.message} Your current session is unchanged.`, true);
      input.value = '';
      status.focus();
    }
  });
  element.querySelector('#use-bundled-deck').addEventListener('click', () => {
    revision++;
    showPreview(bundledDeck, 'Bundled example');
  });
  element.querySelector('#download-deck').addEventListener('click', () => {
    const url = URL.createObjectURL(new Blob([serializeDeck(bundledDeck)], {type: 'application/json'}));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'recallweave-example-deck.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 0);
    message('Example deck downloaded. Edit a copy, then choose it here to preview it.');
  });
}


const root = document.querySelector('#session-content');
const bundledDeck = validateDeck(JSON.parse(document.querySelector('#deck-json').textContent));
let deck = bundledDeck;
let concepts = deck.concepts;
let optionOrders = new Map(deck.items.map(item => [item.id, orderOptions(item.options.length)]));
let mastery = initialMastery(concepts);
const asked = new Set();
const answers = [];
let review = null;
let practice = null;
let inPractice = false;
const progressFill = document.querySelector('#progress-fill');
const progressTrack = document.querySelector('[role="progressbar"]');
const stepLabel = document.querySelector('#step-label');
const stepCount = document.querySelector('#step-count');
const welcomeMarkup = root.innerHTML;
const defaultTitle = document.title;
const contextIds = ['lesson-subject', 'lesson-description', 'lesson-size', 'lesson-time', 'lesson-map', 'lesson-caption', 'deck-footer'];
const defaultContext = new Map(contextIds.map(id => [id, document.getElementById(id).innerHTML]));

function renderDeckContext() {
  const map = document.querySelector('#lesson-map');
  map.classList.toggle('imported-concepts', deck !== bundledDeck);
  document.title = deck === bundledDeck ? defaultTitle : `${deck.title} — RecallWeave`;
  if (deck === bundledDeck) {
    for (const [id, markup] of defaultContext) document.getElementById(id).innerHTML = markup;
    map.setAttribute('aria-label', 'Concept pathway: light energy to glucose to ATP');
    return;
  }
  document.querySelector('#lesson-subject').textContent = 'FIELD NOTES / LOCAL DECK';
  document.querySelector('#lesson-description').textContent = deck.title;
  document.querySelector('#lesson-size').textContent = `${deck.items.length} ${deck.items.length === 1 ? 'challenge' : 'challenges'}`;
  document.querySelector('#lesson-time').textContent = 'at your pace';
  map.setAttribute('aria-label', 'Concepts in this deck');
  map.replaceChildren(...concepts.map(concept => {
    const label = document.createElement('span');
    label.className = 'deck-concept';
    label.textContent = concept;
    return label;
  }));
  document.querySelector('#lesson-caption').textContent = 'Prerequisite links in your deck guide selection. The same illustrative model estimates each concept; it does not validate the content or assess ability.';
  document.querySelector('#deck-footer').textContent = 'Local deck · supplied attribution and license appear in the learning trace';
}

function resetSession(nextDeck = deck) {
  deck = nextDeck;
  concepts = deck.concepts;
  optionOrders = new Map(deck.items.map(item => [item.id, orderOptions(item.options.length)]));
  mastery = initialMastery(concepts);
  asked.clear();
  answers.length = 0;
  review = null;
  practice = null;
  inPractice = false;
  root.innerHTML = welcomeMarkup;
  root.querySelector('.simulation-launch').hidden = deck !== bundledDeck;
  bindWelcome();
  renderDeckContext();
  setProgress();
  const heading = root.querySelector('h2');
  heading.tabIndex = -1;
  heading.focus();
}

function setProgress() {
  const count = inPractice ? practice.answers.length : answers.length;
  const total = inPractice ? practice.items.length : deck.items.length;
  stepCount.textContent = `${count} / ${total}`;
  progressFill.style.width = `${total ? count / total * 100 : 0}%`;
  progressTrack.setAttribute('aria-label', inPractice ? 'Practice progress' : 'Lesson progress');
  progressTrack.setAttribute('aria-valuemax', String(total));
  progressTrack.setAttribute('aria-valuenow', String(count));
  stepLabel.textContent = inPractice
    ? (count === total ? 'PRACTICE COMPLETE' : 'PRACTICE ROUND')
    : count === total ? 'THREAD COMPLETE' : count ? 'FOLLOW THE CONNECTION' : 'READY TO BEGIN';
}
function renderMastery() {
  const rows = concepts.map(concept => `<div class="mastery-row"><span>${escapeHtml(conceptLabel(concept))}</span><div class="mastery-meter" aria-hidden="true"><span style="width:${Math.round(mastery[concept] * 100)}%"></span></div><output aria-label="${escapeHtml(conceptLabel(concept))} estimated mastery ${Math.round(mastery[concept] * 100)} percent">${Math.round(mastery[concept] * 100)}%</output></div>`).join('');
  return `<div class="mastery-box"><h3>Estimated mastery · model state, not a grade</h3>${rows}</div>`;
}
function conceptLabel(concept) {
  const labels = {'photosynthesis':'Light capture','glucose':'Stored sugar','cellular-respiration':'Respiration','atp':'ATP transfer'};
  return deck === bundledDeck && Object.hasOwn(labels, concept) ? labels[concept] : concept;
}
function renderQuestion() {
  const item = selectNextItem(deck.items, asked, mastery);
  if (!item) return renderResults();
  asked.add(item.id);
  root.innerHTML = `<article class="question-card"><div class="question-type">CONNECTION ${String(answers.length + 1).padStart(2, '0')} · ${escapeHtml(conceptLabel(item.concept).toUpperCase())}</div><h2>${escapeHtml(item.prompt)}</h2><p class="prompt">Choose the best explanation, then connect it to the larger idea.</p><div class="choices" role="group" aria-label="Answer options">${optionOrders.get(item.id).map((choice, position) => `<button class="choice" data-choice="${choice}"><span class="choice-key">${String.fromCharCode(65+position)}</span>${escapeHtml(item.options[choice])}</button>`).join('')}</div><div id="feedback-slot"></div>${renderMastery()}</article>`;
  root.querySelectorAll('[data-choice]').forEach(button => button.addEventListener('click', () => submitAnswer(item, Number(button.dataset.choice))));
  const first = root.querySelector('[data-choice]');
  first?.focus({preventScroll:true});
  setProgress();
}
function submitAnswer(item, choice) {
  if (answers.some(answer => answer.item === item.id)) return;
  const correct = choice === item.answer;
  answers.push(Object.freeze({item: item.id, concept:item.concept, choice, correct}));
  mastery[item.concept] = updateMastery(mastery[item.concept] ?? DEFAULT_BKT.initial, correct);
  root.querySelectorAll('[data-choice]').forEach(button => {
    button.disabled = true;
    const selected = Number(button.dataset.choice);
    if (selected === item.answer) button.classList.add('correct');
    else if (selected === choice) button.classList.add('incorrect');
  });
  const feedback = document.querySelector('#feedback-slot');
  feedback.innerHTML = `<div class="feedback"><strong>${correct ? 'That connection holds.' : 'Here’s the correction.'}</strong> ${escapeHtml(item.explanation)}<span class="why">Try this transfer: ${escapeHtml(item.transfer)}</span></div><button class="primary-button next-button" id="next-button">${answers.length === deck.items.length ? 'See your learning trace' : 'Follow the next thread'} <span aria-hidden="true">→</span></button>`;
  feedback.querySelector('button').addEventListener('click', renderQuestion);
  const state = root.querySelector('.mastery-box');
  state.outerHTML = renderMastery();
  setProgress();
  feedback.querySelector('button').focus();
}
function renderResults() {
  inPractice = false;
  review ??= createReview(deck.items, answers);
  const correct = answers.filter(answer => answer.correct).length;
  const reflection = deck === bundledDeck
    ? 'Trace energy from sunlight to a cell doing work. Where does the form of energy change, and what molecule transfers it to cellular processes?'
    : 'Choose one connection from this deck and explain how it relates to another idea in your own words.';
  root.innerHTML = `<article class="result-card"><div class="result-mark" aria-hidden="true">⌁</div><div class="card-kicker">YOUR LEARNING TRACE</div><h2 tabindex="-1">Notice the links you built.</h2><p id="first-try-summary">You made ${correct} of ${answers.length} connections on the first try. That count is a snapshot—not a measure of your ability. Review the concept estimates and choose one connection to explain in your own words.</p>${renderMastery()}${renderPracticeSummary()}<section class="review-list" aria-labelledby="review-title"><h3 id="review-title">Review the connections</h3><p>Open a question to see your first answer, the explanation, and an idea to apply.</p>${review.map(renderReviewItem).join('')}</section><div class="reflection"><strong>Apply it:</strong> ${reflection}</div><p class="source-note"><strong>${deck === bundledDeck ? 'Demo deck attribution' : 'Attribution supplied in the deck'}:</strong> ${escapeHtml(deck.attribution)}<br><strong>License supplied in the deck:</strong> ${escapeHtml(deck.license)}</p><button class="reset-button" id="reset-button">Start a fresh local session</button></article>`;
  const resetButton = root.querySelector('#reset-button');
  resetButton.insertAdjacentHTML('beforebegin', '<section class="practice-summary" aria-labelledby="save-notes-title"><h3 id="save-notes-title">Keep these connections</h3><p>Save your questions, first answers, explanations, and any practice answers as a text file.</p><button class="reset-button" id="save-notes-button" aria-describedby="save-notes-status">Download study notes (.txt)</button><p id="save-notes-status" role="status">Your session stays in this tab until you refresh. Download notes to keep a copy.</p></section>');
  root.querySelector('#save-notes-button').addEventListener('click', downloadStudyNotes);
  resetButton.addEventListener('click', () => resetSession());
  root.querySelector('#practice-button')?.addEventListener('click', () => {
    practice ??= beginPractice(review);
    inPractice = true;
    renderPracticeQuestion();
  });
  setProgress();
  root.querySelector('h2').focus();
}

function downloadStudyNotes() {
  const status = root.querySelector('#save-notes-status');
  let url;
  try {
    const notes = createStudyNotes({deck, review, mastery, practice, conceptLabel});
    url = URL.createObjectURL(new Blob([notes.text], {type: notes.mediaType}));
    const link = document.createElement('a');
    link.href = url;
    link.download = notes.filename;
    document.body.append(link);
    try { link.click(); } finally { link.remove(); }
    status.textContent = 'Download requested. Check your browser’s downloads for the study notes. Your session is still here.';
  } catch {
    status.textContent = 'The notes could not be prepared. Your answers are still available in this learning trace; try the download again.';
  } finally {
    if (url) setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[char]);
}

function renderReviewItem(item, index) {
  const retry = practice?.answers.find(answer => answer.item === item.id);
  const practiceAnswer = retry
    ? `<div class="review-practice-answer"><strong>Practice answer · ${retry.correct ? 'correct on retry' : 'keep reviewing'}</strong><p>${escapeHtml(item.options[retry.choice])}</p></div>`
    : '';
  return `<details class="review-item"><summary><span class="review-label">${String(index + 1).padStart(2, '0')} · ${escapeHtml(conceptLabel(item.concept))}</span><span class="review-status ${item.correct ? 'is-correct' : 'needs-review'}">${item.correct ? 'Correct' : 'Needs review'} · first try</span><span class="review-prompt">${escapeHtml(item.prompt)}</span></summary><div class="review-body"><dl class="review-answers"><div><dt>Your first answer</dt><dd>${escapeHtml(item.options[item.choice])}</dd></div><div><dt>Correct answer</dt><dd>${escapeHtml(item.options[item.answer])}</dd></div></dl><p>${escapeHtml(item.explanation)}</p><p class="review-transfer"><strong>Apply the idea:</strong> ${escapeHtml(item.transfer)}</p>${practiceAnswer}</div></details>`;
}

function renderPracticeSummary() {
  const missed = review.filter(item => !item.correct).length;
  if (!missed) return '<section class="practice-summary"><h3>Every connection held on the first try.</h3><p>Revisit any explanation below, then try applying a connection in your own words.</p></section>';
  const total = practice?.items.length ?? missed;
  const count = practice?.answers.length ?? 0;
  const complete = practice && count === total;
  const status = complete
    ? `You answered ${practice.answers.filter(answer => answer.correct).length} of ${total} correctly on retry.`
    : practice ? `Practice paused: ${count} of ${total} answered. Resume with the next unanswered prompt.`
    : `Try ${missed === 1 ? 'the missed connection' : `each of the ${missed} missed connections`} once more.`;
  const button = complete ? '' : `<button class="primary-button" id="practice-button">${practice ? 'Resume practice' : `Practice ${missed} missed ${missed === 1 ? 'connection' : 'connections'}`} <span aria-hidden="true">→</span></button>`;
  return `<section class="practice-summary" aria-labelledby="practice-title"><h3 id="practice-title">${complete ? 'Practice complete' : 'A second pass'}</h3><p id="practice-status">${status}</p><p class="practice-note">You have seen these explanations. Practice is for recall; your first answers and model estimates stay as they were.</p>${button}</section>`;
}

function renderPracticeQuestion() {
  const item = currentPracticeItem(practice);
  if (!item) return renderResults();
  const number = practice.answers.length + 1;
  root.innerHTML = `<article class="question-card practice-card"><div class="question-type">PRACTICE ${number} OF ${practice.items.length} · ${escapeHtml(conceptLabel(item.concept).toUpperCase())}</div><h2>${escapeHtml(item.prompt)}</h2><p class="prompt">Recall the explanation. Choose the best answer once more.</p><p class="practice-note">This retry is recorded separately from your first try and model estimates.</p><div class="choices" role="group" aria-label="Practice answer options">${optionOrders.get(item.id).map((choice, position) => `<button class="choice" data-practice-choice="${choice}"><span class="choice-key">${String.fromCharCode(65+position)}</span>${escapeHtml(item.options[choice])}</button>`).join('')}</div><div id="practice-feedback"></div><button class="text-button practice-back" id="back-to-review">Back to learning trace</button></article>`;
  let submitted = false;
  root.querySelectorAll('[data-practice-choice]').forEach(button => button.addEventListener('click', () => {
    if (submitted) return;
    const choice = Number(button.dataset.practiceChoice);
    practice = answerPractice(practice, item.id, choice);
    submitted = true;
    const correct = choice === item.answer;
    root.querySelectorAll('[data-practice-choice]').forEach(option => {
      option.disabled = true;
      const selected = Number(option.dataset.practiceChoice);
      if (selected === item.answer) option.classList.add('correct');
      else if (selected === choice) option.classList.add('incorrect');
    });
    const feedback = root.querySelector('#practice-feedback');
    feedback.innerHTML = `<div class="feedback"><strong>${correct ? 'That connection holds on retry.' : 'Keep this connection in view.'}</strong><p><strong>Correct answer:</strong> ${escapeHtml(item.options[item.answer])}</p>${escapeHtml(item.explanation)}<span class="why">Apply the idea: ${escapeHtml(item.transfer)}</span></div><button class="primary-button next-button" id="practice-next">${currentPracticeItem(practice) ? 'Next practice connection' : 'See practice results'} <span aria-hidden="true">→</span></button>`;
    feedback.querySelector('button').addEventListener('click', renderPracticeQuestion);
    setProgress();
    feedback.querySelector('button').focus();
  }));
  root.querySelector('#back-to-review').addEventListener('click', renderResults);
  setProgress();
  root.querySelector('[data-practice-choice]').focus({preventScroll:true});
}

function renderSimulation() {
  const truth = { photosynthesis:0.82, glucose:0.66, 'cellular-respiration':0.53, atp:0.74 };
  const adaptive = runLearnerSimulation(deck.items, concepts, truth, true, 41);
  const fixed = runLearnerSimulation(deck.items, concepts, truth, false, 41);
  const correctCount = run => run.trace.filter(answer => answer.correct).length;
  document.querySelector('#simulation-output').innerHTML = `<div class="simulation-result"><strong>Scripted run · not learner evidence</strong><p>One deterministic toy profile (latent concept strengths: 0.53–0.82), same seed and response model; only item order changes.</p><div class="simulation-compare"><span>Adaptive: ${correctCount(adaptive)}/${adaptive.trace.length} correct · mean estimated mastery ${Math.round(adaptive.meanEstimatedMastery * 100)}%</span><span>Fixed order: ${correctCount(fixed)}/${fixed.trace.length} correct · mean estimated mastery ${Math.round(fixed.meanEstimatedMastery * 100)}%</span></div><p>One tiny synthetic run is not a performance claim. Use the test suite for invariants; efficacy needs a larger, preregistered study.</p></div>`;
}
function bindWelcome() {
  root.querySelector('#simulation-button').addEventListener('click', renderSimulation);
  root.querySelector('#start-button').addEventListener('click', renderQuestion);
}
mountDeckPicker(document.querySelector('#deck-picker'), bundledDeck, nextDeck => {
  resetSession(nextDeck);
  renderQuestion();
});
bindWelcome();
setProgress();
