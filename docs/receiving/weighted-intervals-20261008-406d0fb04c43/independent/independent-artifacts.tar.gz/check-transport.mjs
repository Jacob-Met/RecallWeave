import {spawn} from 'node:child_process';import {readFile,writeFile,mkdir,rm} from 'node:fs/promises';
const root='/Users/me/hamon-native-406d0fb04c43/recallweave-weighted-intervals-independent',profile=root+'/transport-profile';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));const child=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',['--headless=new','--no-sandbox','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:'ignore'});
let socket,sessionId,seq=0;const pending=new Map(),out={kind:'receiver-transport-control-only',candidateInspected:false};
function command(method,params={},browser=false){return new Promise((resolve,reject)=>{const id=++seq;const timer=setTimeout(()=>{pending.delete(id);reject(Error(method));},10000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...(!browser&&sessionId?{sessionId}:{})}));});}
async function evaluate(expression){const r=await command('Runtime.evaluate',{expression,returnByValue:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;}
try{let parts;for(let n=0;n<100;n++){try{parts=(await readFile(profile+'/DevToolsActivePort','utf8')).trim().split('\n');break;}catch{}await sleep(50);}
if(!parts)throw Error('Chrome startup');socket=new WebSocket('ws://127.0.0.1:'+parts[0]+parts[1]);socket.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}});
await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
const {targetId}=await command('Target.createTarget',{url:'about:blank'},true);({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},true));await command('Runtime.enable');
await evaluate('document.body.innerHTML="<button id=b>Increment</button><input type=number id=n value=10>";globalThis.clickCount=0;document.querySelector("#b").onclick=()=>clickCount++;document.querySelector("#b").focus();');
for(const type of ['keyDown','keyUp'])await command('Input.dispatchKeyEvent',{type,key:'Enter',code:'Enter'});
out.originalEnterClicks=await evaluate('clickCount');
await evaluate('document.querySelector("#n").focus()');
await command('Input.dispatchKeyEvent',{type:'keyDown',key:'a',code:'KeyA',modifiers:4,commands:['selectAll']});await command('Input.dispatchKeyEvent',{type:'keyUp',key:'a',code:'KeyA',modifiers:4});await command('Input.insertText',{text:'0'});
out.originalInputValue=await evaluate('document.querySelector("#n").value');
out.status=out.originalEnterClicks===1&&out.originalInputValue==='0'?'accepted':'adapter-correction-needed';
}catch(error){out.status='setup-error';out.error=error.stack;}finally{if(socket?.readyState===WebSocket.OPEN){try{await command('Browser.close',{},true);}catch{}}socket?.close();for(const p of pending.values())clearTimeout(p.timer);if(child.exitCode===null)child.kill();await sleep(200);await rm(profile,{recursive:true,force:true});await writeFile(root+'/transport-control.json',JSON.stringify(out,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(out));}
