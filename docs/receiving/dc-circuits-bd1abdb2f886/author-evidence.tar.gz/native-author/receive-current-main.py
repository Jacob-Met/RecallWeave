import os,pathlib,subprocess,hashlib,json,datetime
root=pathlib.Path('/home/jacob/recallweave-dc-circuits-bd1abdb2f886')
qa=pathlib.Path('/home/jacob/recallweave-dc-circuits-bd1abdb2f886-qa')
old='d22b5ef7c641fc1726ae5b774383f8e6527d73e7'
target='d202fdc8b3608c5321f83e1bf6f9a2ceb253f14b'
owned=['courses/dc-circuits.json','courses/dc-circuits.md','courses/dc-circuits-lab.html','src/dc-circuits.mjs','src/dc-circuits-ui.mjs','templates/dc-circuits-lab.html','tools/build-dc-circuits.mjs','tests/dc-circuits.test.mjs','tests/dc-circuits-course.test.mjs']
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(p):return hashlib.sha256((root/p).read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==old
assert git('branch','--show-current')=='work/dc-circuits-bd1abdb2f886-20261008'
assert git('diff','--name-only','HEAD')==''
s=os.statvfs(root);assert s.f_bavail*s.f_frsize>64*1024*1024,'require 64 MiB receiving headroom'
before={p:sha(p) for p in owned}
result=subprocess.run(['git','fetch','--no-tags','origin','main'],cwd=root,capture_output=True,timeout=90)
with open(qa/'current-main-fetch.stdout','xb') as f:f.write(result.stdout)
with open(qa/'current-main-fetch.stderr','xb') as f:f.write(result.stderr)
assert result.returncode==0,'read-only source fetch failed'
subprocess.run(['git','merge-base','--is-ancestor',old,target],cwd=root,check=True)
leaves=subprocess.check_output(['git','ls-tree','-rz',target],cwd=root)
expected={}
for record in leaves.split(b'\0'):
    if not record:continue
    meta,path=record.split(b'\t',1);mode,kind,blob=meta.decode().split()
    path=os.fsdecode(path);assert path not in owned,'new payload path already exists on main'
    assert kind=='blob';expected[path]=(mode,blob)
merge=subprocess.run(['git','merge','--ff-only','--no-edit',target],cwd=root,capture_output=True,timeout=90)
with open(qa/'current-main-ff.stdout','xb') as f:f.write(merge.stdout)
with open(qa/'current-main-ff.stderr','xb') as f:f.write(merge.stderr)
assert merge.returncode==0,'native fast-forward failed'
assert git('rev-parse','HEAD')==target
for p,(mode,blob) in expected.items():
    b=(root/p).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==blob,p+' raw source mismatch'
    assert bool((root/p).stat().st_mode&0o111)==(mode=='100755'),p+' mode mismatch'
assert before=={p:sha(p) for p in owned},'own product changed during receiving'
assert git('diff','--name-only','HEAD')==''
dependencies=['src/deck.mjs','src/knowledge.mjs','src/review.mjs','src/session-export.mjs']
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_base':old,'receiving_base':target,'receiving_tree':git('rev-parse','HEAD^{tree}'),'receiving_leaves_verified':len(expected),'owned_payload_sha256':before,'owned_payload_unchanged':True,'dependencies':[{'path':p,'original_blob':git('rev-parse',old+':'+p),'current_blob':git('rev-parse',target+':'+p),'sha256':sha(p)} for p in dependencies]}
encoded=(json.dumps(receipt,indent=2)+'\n').encode();out=qa/'current-main-receiving.json'
with open(out,'xb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
print(json.dumps({'receipt':str(out),'sha256':hashlib.sha256(encoded).hexdigest(),**receipt}),flush=True)
