import difflib,hashlib,json,pathlib
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
old=json.loads((R/'RUNTIME-MANIFEST-r1.json').read_text(encoding='utf-8'))
runtime=[e for e in json.loads((R/'CANDIDATE-MANIFEST-r3.json').read_text(encoding='utf-8')) if not e['path'].startswith('tests/')]
changes=[a['path'] for a,b in zip(old,runtime) if a!=b];assert changes==['courses/genotype-counts-worksheet.html']
for e in runtime:assert pin(R/'candidate-r3'/e['path'])=={k:e[k] for k in ['bytes','sha256','git']}
manifest=R/'RUNTIME-MANIFEST-r2.json';manifest.write_bytes((json.dumps(runtime,indent=2)+'\n').encode('utf-8'))
rel=changes[0];a=(R/'candidate-r2'/rel).read_text(encoding='utf-8');b=(R/'candidate-r3'/rel).read_text(encoding='utf-8')
diff=R/'WORKSHEET-DEFINITION-r2.patch';diff.write_bytes(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='R1/'+rel,tofile='R2/'+rel)).encode('utf-8'))
offer=json.loads((R/'RUNTIME-ONLY-OFFER-r1.json').read_text(encoding='utf-8'));offer.update({'format':'genotype-counts-runtime-only/2','sourceRoot':str(R/'candidate-r3'),'manifest':{'path':str(manifest),**pin(manifest)},'portablePackage':{'path':str(R/'portable-r2/genotype-counts-portable.zip'),**pin(R/'portable-r2/genotype-counts-portable.zip'),'members':6},'deltaFromR1':{'changedPaths':changes,'unchangedRuntimePaths':28,'diff':{'path':str(diff),**pin(diff)}},'independence':'Only unchanged original runtime and new authored content; no authored test bodies or author outcomes. This successor adds p and q definitions to the static worksheet only. Course questions/keys/guide and all public mathematical inputs remain exact.'})
target=R/'RUNTIME-ONLY-OFFER-r2.json';target.write_bytes((json.dumps(offer,indent=2)+'\n').encode('utf-8'));print(json.dumps({'offer':pin(target),'manifest':pin(manifest),'diff':pin(diff)}))
