import fs from 'node:fs';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';

const config=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const x of config.bound_inputs) assert.equal(sha(fs.readFileSync(x.path)),x.sha256,x.role+' input identity');
const oracle=JSON.parse(fs.readFileSync(config.oracle_path,'utf8'));
const model=await import(pathToFileURL(config.core_path).href);
assert.equal(typeof model.simulate,'function');
const report={schema:'independent-time-stepping-receiving/v1',node:process.version,platform:process.platform,arch:process.arch,
  product_node_processes:1,api_calls:0,valid_calls:0,refusal_calls:0,row_count:0,numeric_comparisons:0,
  absolute_tolerance:1e-12,relative_tolerance:2e-12,cases:[],cross_checks:[],failures:[]};
const results=new Map();
const snap=x=>JSON.stringify(x,(k,v)=>typeof v==='number'&&!Number.isFinite(v)?{nonfinite:String(v)}:v);
const near=(a,e,label)=>{
 report.numeric_comparisons++;
 assert.equal(typeof a,'number',label+' numeric type'); assert(Number.isFinite(a),label+' finite');
 if(e===0){assert(a===0,label+' exact zero');return;}
 assert(Math.sign(a)===Math.sign(e),label+' sign');
 assert(Math.abs(a-e)<=1e-12+2e-12*Math.max(Math.abs(a),Math.abs(e)),label+' tolerance');
};
const rowKeys=['index','time','exact','forward','backward','forwardError','backwardError','forwardAbsError','backwardAbsError'];
const resultKeys=['settings','z','forwardMultiplier','backwardMultiplier','forwardBehavior','rows'];
for(const expected of [...oracle.time,...oracle.time_refinement]){
 const input=structuredClone(expected.settings); const before=snap(input);
 const entry={id:expected.id,kind:'valid',input:structuredClone(input)};
 report.api_calls++;report.valid_calls++;
 try{
  const actual=model.simulate(input);entry.actual=actual;
  assert.equal(snap(input),before,'settings unchanged');
  assert.deepEqual(Object.keys(actual).sort(),resultKeys.slice().sort(),'result schema');
  assert.deepEqual(actual.settings,expected.settings,'returned settings');
  assert.equal(actual.forwardBehavior,expected.forwardBehavior,'behavior');
  for(const key of ['z','forwardMultiplier','backwardMultiplier'])near(actual[key],expected[key],key);
  assert(Array.isArray(actual.rows),'rows array');
  assert.equal(actual.rows.length,expected.settings.steps+1,'N+1 rows');
  assert.equal(actual.rows.length,expected.expected_rows.length,'oracle complete rows');
  report.row_count+=actual.rows.length;
  for(let n=0;n<actual.rows.length;n++){
   const a=actual.rows[n],e=expected.expected_rows[n];
   assert.deepEqual(Object.keys(a).sort(),rowKeys.slice().sort(),'row schema');
   assert.equal(a.index,n,'row index');assert.equal(a.index,e.index,'oracle row index');
   assert.equal(a.time,n*input.step,'shared physical time');assert.equal(a.time,e.time,'oracle time');
   for(const key of rowKeys.slice(2))near(a[key],e[key],expected.id+' row'+n+' '+key);
   near(a.forwardError,a.forward-a.exact,'signed forward error identity');
   near(a.backwardError,a.backward-a.exact,'signed backward error identity');
   near(a.forwardAbsError,Math.abs(a.forwardError),'forward absolute identity');
   near(a.backwardAbsError,Math.abs(a.backwardError),'backward absolute identity');
  }
  assert(actual.backwardMultiplier>0&&actual.backwardMultiplier<1,'backward multiplier range');
  entry.passed=true;results.set(expected.id,actual);
 }catch(error){entry.passed=false;entry.error={name:error.name,message:error.message};report.failures.push({id:entry.id,...entry.error});}
 entry.input_unchanged=snap(input)===before;
 if(!entry.input_unchanged)report.failures.push({id:entry.id,message:'input mutation'});
 report.cases.push(entry);
}
function decode(x){
 if(x===null||typeof x!=='object')return x;
 if(!Array.isArray(x)&&Object.keys(x).length===1&&Object.hasOwn(x,'$number')){
  return x.$number==='NaN'?NaN:x.$number==='Infinity'?Infinity:-Infinity;
 }
 if(Array.isArray(x))return x.map(decode);
 return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,decode(v)]));
}
for(const fixture of config.refusals){
 const input=decode(fixture.input);const before=snap(input);const entry={id:fixture.id,kind:'refusal',input:fixture.input};
 report.api_calls++;report.refusal_calls++;
 try{model.simulate(input);entry.passed=false;entry.error={message:'invalid settings accepted'};}
 catch(error){entry.passed=error instanceof Error;entry.exception={name:error.name,message:error.message};}
 entry.input_unchanged=snap(input)===before;
 if(!entry.input_unchanged){entry.passed=false;entry.error={message:'invalid input mutated'};}
 if(!entry.passed)report.failures.push({id:entry.id,...entry.error});
 report.cases.push(entry);
}
function cross(id,fn){try{fn();report.cross_checks.push({id,passed:true});}catch(error){report.cross_checks.push({id,passed:false,message:error.message});report.failures.push({id,message:error.message});}}
cross('positive-half-step-brackets-exact',()=>{
 const a=results.get('half_step');assert(a);
 for(const r of a.rows.slice(1))assert(r.forward<r.exact&&r.exact<r.backward,'forward < exact < backward');
});
cross('zero-initial-does-not-hide-growth-classification',()=>{
 const a=results.get('zero_does_not_hide_unstable_multiplier');assert(a);
 assert.equal(a.forwardBehavior,'alternating_growth');
 for(const r of a.rows)for(const k of rowKeys.slice(2))assert(r[k]===0);
});
cross('all-five-classifications-observed',()=>{
 assert.deepEqual([...new Set([...results.values()].map(x=>x.forwardBehavior))].sort(),
 ['monotone_decay','one_step_zero','alternating_decay','alternating_boundary','alternating_growth'].sort());
});
cross('fixed-endpoint-refinement',()=>{
 let previous=null;
 for(const e of oracle.time_refinement){
  const a=results.get(e.id);assert(a);const last=a.rows.at(-1);assert.equal(last.time,1);
  if(previous){assert(last.forwardAbsError<previous.forwardAbsError);assert(last.backwardAbsError<previous.backwardAbsError);near(last.exact,previous.exact,'same endpoint exact');}
  previous=last;
 }
});
report.passed=report.failures.length===0;
report.observed_valid_rows_expected=244;
assert.equal(report.api_calls,13+config.refusals.length);
const output=JSON.stringify(report,null,2)+'\n';
assert(Buffer.byteLength(output)<=config.max_stdout_bytes,'bounded output');
process.stdout.write(output);
process.exitCode=report.passed?0:1;
