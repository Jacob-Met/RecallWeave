import ast,datetime,hashlib,json,pathlib,subprocess,sys
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
files=['receive-browser-r1.mjs','run-browser-r1.py','launch-browser-r1.py'];pins={}
for name in files:
 b=(R/name).read_bytes();pins[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 if name.endswith('.py'):ast.parse(b.decode('utf-8'))
p=subprocess.run([r'C:/Program Files/nodejs/node.exe','--check',str(R/'receive-browser-r1.mjs')],capture_output=True,timeout=10)
rec={'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'nodeSyntaxExit':p.returncode,'stdout':p.stdout.decode('utf-8'),'stderr':p.stderr.decode('utf-8'),'pins':pins,'noBrowserLaunched':True}
(R/'BROWSER-SYNTAX-r1.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
print(json.dumps(rec));sys.exit(p.returncode)
