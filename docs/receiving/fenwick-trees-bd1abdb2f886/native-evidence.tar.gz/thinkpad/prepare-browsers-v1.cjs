const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),cp=require("node:child_process");
const root="/home/jacob/recallweave-fenwick-bd1abdb2f886-20261008",out=path.join(root,"browser-preparation-v1");
const git=b=>crypto.createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
const pin=p=>{const b=fs.readFileSync(p);return{bytes:b.length,sha256:crypto.createHash("sha256").update(b).digest("hex"),git_blob:git(b),mode:(fs.statSync(p).mode&511).toString(8)};};
if(fs.existsSync(out))throw Error("Fresh preparation path required");
const space=fs.statfsSync(root);if(space.bavail*space.bsize<134217728)throw Error("128MiB reserve");
const packet=JSON.parse(fs.readFileSync(path.join(root,"browser-preparation-v1.json")));
fs.mkdirSync(out);
const paths=[];
function materialize(name,content,want){
 const bytes=Buffer.from(content);if(git(bytes)!==want)throw Error("Exact Git bytes mismatch "+name);
 const dst=path.join(out,name);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,bytes,{flag:"wx",mode:420});paths.push(name);
}
for(const f of packet.consumer){
 if(!["demo.html","src/app.mjs","src/deck-picker.mjs","src/session-export.mjs","src/answer-order.mjs"].includes(f.path))throw Error("Unadmitted consumer file");
 materialize("consumer/"+f.path,f.content,f.git_blob);
}
for(const key of["explorer_receiver","consumer_receiver","helper"]){const f=packet[key];if(!/^fenwick-trees-(browser|consumer|browser-helpers)\.mjs$/.test(f.path))throw Error("Unadmitted receiver");materialize(f.path,f.content,f.git_blob);}
materialize("independent-expectations.json",packet.independent_expectations_text,"71a2d88781ba683b0afcdbb4f0a53db7d37e22e0");
const snapshots=()=>Object.fromEntries(paths.map(n=>[n,pin(path.join(out,n))]));
const result={schema:"recallweave-fenwick-browser-preparation-native/v1",stage:"Syntax/source preparation only; no Chromium launch",at:new Date().toISOString(),canonical_main:packet.canonical_main,packet:pin(path.join(root,"browser-preparation-v1.json")),before:snapshots(),commands:[],controller:pin(__filename)};
for(const name of["fenwick-trees-browser.mjs","fenwick-trees-consumer.mjs","fenwick-trees-browser-helpers.mjs"]){
 const run=cp.spawnSync(process.execPath,["--check",path.join(out,name)],{encoding:"utf8",timeout:10000,maxBuffer:1024*1024});
 result.commands.push({argv:[process.execPath,"--check",path.join(out,name)],exit:run.status,error:run.error?String(run.error):null,stdout:run.stdout,stderr:run.stderr});
}
result.after=snapshots();result.pass=result.commands.every(x=>x.exit===0&&!x.error)&&JSON.stringify(result.before)===JSON.stringify(result.after);
const receipt=path.join(out,"preparation.json");fs.writeFileSync(receipt,JSON.stringify(result,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify({pass:result.pass,receipt:pin(receipt),commands:result.commands.map(x=>({argv:x.argv,exit:x.exit})),free:fs.statfsSync(root).bavail*fs.statfsSync(root).bsize}));process.exitCode=result.pass?0:1;
