import json,hashlib,urllib.request,urllib.parse,shutil,time,traceback,concurrent.futures
from pathlib import Path
prior=Path("/dev/shm/hamon-7a9310dad255-recall19-integration-current")
root=prior/"current-8b82";root.mkdir()
expected=json.loads((prior/"expected-final-8b82.json").read_text())
def pin(data):
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
def tree_id(rows):
    tree={}
    for row in rows:
        node=tree;parts=row["path"].split("/")
        for part in parts[:-1]:node=node.setdefault(part,{})
        assert parts[-1] not in node
        node[parts[-1]]=(row["mode"],row["git_blob"])
    def emit(node):
        data=b""
        for name,item in sorted(node.items(),key=lambda x:(x[0]+("/" if isinstance(x[1],dict) else "")).encode()):
            mode,sha=("40000",emit(item)) if isinstance(item,dict) else item
            data+=mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(sha)
        return hashlib.sha1(b"tree "+str(len(data)).encode()+b"\0"+data).hexdigest()
    return emit(tree)
def snapshot(where):
    rows=[]
    for p in sorted(where.rglob("*")):
        assert not p.is_symlink(),str(p)
        if p.is_file():rows.append({"path":str(p.relative_to(where)),"mode":"100755" if p.stat().st_mode&0o111 else "100644",**pin(p.read_bytes())})
    return rows
receipt={"repository":expected["repository"],"current_head":expected["current_head"],"current_tree":expected["current_tree"],"previous_head":expected["previous_head"],"course_head":expected["course_head"],"started_at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"capture_scope":"All 102 current repository files outside docs/ and verification/, plus the exact original 28 course contribution files and three adoption documents. All 481 omitted current proof/documentation leaves are preserved in the full Git tree metadata.","downloads":[],"completed":False}
started=time.monotonic()
try:
    old=json.loads((prior/"pre-ci-source-manifest.json").read_text())
    assert snapshot(prior/"candidate")==old["files"]
    candidate=root/"candidate";shutil.copytree(prior/"candidate",candidate)
    def get(row):
        path=row["path"];assert not(candidate/path).exists()
        url="https://raw.githubusercontent.com/Jacob-Met/RecallWeave/"+expected["current_head"]+"/"+urllib.parse.quote(path,safe="/")
        with urllib.request.urlopen(url,timeout=30) as response:
            assert response.status==200
            data=response.read(row["size"]+1)
        assert len(data)==row["size"] and pin(data)["git_blob"]==row["sha"],path
        return row,data,url
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for row,data,url in pool.map(get,expected["added_source"]):
            out=candidate/row["path"];out.parent.mkdir(parents=True,exist_ok=True)
            with out.open("xb") as f:f.write(data)
            out.chmod(0o755 if row["mode"]=="100755" else 0o644)
            receipt["downloads"].append({"path":row["path"],"url":url,**pin(data)})
    proof=Path("docs/receiving/probability-course-7a9310dad255/current-importer-adoption")
    (candidate/proof/"README.md").write_bytes((prior/"final-adoption-README.md").read_bytes())
    final=snapshot(candidate);fm={x["path"]:x for x in final}
    assert len(final)==133 and len(expected["scope"])==102
    assert all(fm[x["path"]]["git_blob"]==x["sha"] and fm[x["path"]]["mode"]==x["mode"] for x in expected["scope"])
    assert all(fm[x["path"]]["git_blob"]==x["sha"] and fm[x["path"]]["mode"]==x["mode"] for x in expected["course_entries"])
    public=[{"path":x["path"],"mode":x["mode"],"git_blob":x["sha"]} for x in expected["current_entries"]]
    assert len(public)==583 and tree_id(public)==expected["current_tree"]
    public_paths={x["path"] for x in public}
    contributions=[x for x in final if x["path"] not in public_paths];assert len(contributions)==31
    complete=public+contributions;assert len(complete)==614
    acceptance=json.loads((candidate/proof/"independent-assessment.json").read_text())
    assert all(fm[x["path"]]["git_blob"]==x["git_blob"] for x in acceptance["learner_source_pins"])
    manifest={"repository":expected["repository"],"current_head":expected["current_head"],"current_tree":expected["current_tree"],"course_head":expected["course_head"],"source_tree":tree_id(final),"proposed_full_tree":tree_id(complete),"files":final,"complete_proposed_files":complete,"current_public_leaves":583,"native_current_source_leaves":102,"omitted_current_documentation_leaves":481,"all_current_public_leaves_preserved":True,"all_28_original_contribution_paths_preserved":True,"all_14_received_learner_inputs_preserved":True,"source_label":receipt["capture_scope"]}
    with (root/"pre-ci-source-manifest.json").open("x") as f:json.dump(manifest,f,indent=2);f.write("\n")
    receipt.update({"completed":True,"physical_source_tree":manifest["source_tree"],"proposed_full_tree":manifest["proposed_full_tree"],"physical_files":133,"complete_proposed_files":614,"source_manifest":pin((root/"pre-ci-source-manifest.json").read_bytes())})
except Exception as error:
    receipt["error"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
finally:
    receipt["finished_at_utc"]=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime());receipt["seconds"]=time.monotonic()-started
    with (root/"capture-composition-receipt.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
    print(json.dumps({k:v for k,v in receipt.items() if k!="downloads"},indent=2))
if not receipt["completed"]:raise SystemExit(1)
