import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';

const args = process.argv.slice(2);
assert.equal(args.length % 2, 0);
const options = Object.fromEntries(args.reduce((all, value, index) => index % 2 ? all : [...all, [value.replace(/^--/, ''), args[index + 1]]], []));
const root = resolve(options.root), output = resolve(options.output);
await mkdir(output, { recursive: true });
const temporary = resolve(output, 'owned-browser-temporary');
await mkdir(temporary, { recursive: true });
process.env.TMPDIR = temporary;
const { chromium } = createRequire(import.meta.url)(options.playwright);
const { validateDeck, parseDeck } = await import(pathToFileURL(resolve(root, 'src/deck.mjs')));
const hash = value => createHash('sha256').update(value).digest('hex');
const paths = ['focus/index.html', 'focus/focus.css', 'focus.html', 'src/course-focus.mjs', 'src/course-focus-ui.mjs', 'src/deck.mjs', 'tools/make_focus.py'];
const sources = Object.fromEntries(await Promise.all(paths.map(async path => [path, hash(await readFile(resolve(root, path)))])));
assert.equal(sources['src/course-focus.mjs'], '82e362e82a185c18f771f675622bcef8c382b7832e9d95a6c5341fa96e051370');
assert.equal(sources['src/deck.mjs'], '621438c166ec4bfafd9d87c698a1d46cb1722f4fb92dcbb8d9f52fce682c338b');
const report = { source_commit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  source_sha256: sources, receiver_sha256: hash(await readFile(new URL(import.meta.url))), node: process.version,
  cases: [], downloads: [], screenshots: [], external_requests: [], page_errors: [] };
const concepts = ['Shared topic', 'Shared\ttopic', 'Shared\ntopic', 'Outcome <literal>'];
function item(id, concept, prerequisites, answer) {
  return { id, concept, prerequisites, prompt: `${id}: which literal choice belongs here?`,
    options: ['First "choice"', 'Second <choice>'], answer,
    explanation: `${id}: original explanation\nwith a second line.`, transfer: `${id}: connect café to the example.` };
}
const source = validateDeck({ title: 'Distinct literal concepts', attribution: 'Original author\nLiteral <source>', license: 'Fixture permission stays unchanged', concepts,
  items: [item('first', concepts[0], [], 1), item('second', concepts[1], [], 0), item('third', concepts[2], [], 1), item('branch', concepts[3], [concepts[1]], 0)] });
await writeFile(resolve(output, 'source.json'), JSON.stringify(source, null, 2) + '\n');
const server = createServer(async (request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
  if (pathname === '/favicon.ico') { response.writeHead(204); response.end(); return; }
  const file = resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
  if (!file.startsWith(root + sep)) { response.writeHead(403); response.end(); return; }
  try {
    const bytes = await readFile(file);
    response.writeHead(200, { 'Content-Type': (({ '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css' })[extname(file)] || 'application/octet-stream') + '; charset=utf-8' });
    response.end(bytes);
  } catch { response.writeHead(404); response.end(); }
});
await new Promise(done => server.listen(0, '127.0.0.1', done));
const origin = 'http://127.0.0.1:' + server.address().port;
let browser;
async function activate(locator, key = 'Enter') { await locator.focus(); await locator.press(key); }
async function actualDownload(page, mode, name, expectedConcepts, expectedIds) {
  const event = page.waitForEvent('download');
  await activate(page.getByRole('button', { name: 'Download focused lesson', exact: true }));
  const download = await event;
  assert.equal(await download.failure(), null);
  const chunks = [];
  for await (const chunk of await download.createReadStream()) chunks.push(chunk);
  const bytes = Buffer.concat(chunks);
  const deck = parseDeck(bytes.toString('utf8'));
  assert.deepEqual(deck, { format: source.format, title: 'Distinct targets', attribution: source.attribution, license: source.license,
    concepts: expectedConcepts, items: source.items.filter(question => expectedIds.includes(question.id)) });
  const filename = `${mode}-${name}.focus.json`;
  await writeFile(resolve(output, filename), bytes);
  const record = { filename, bytes: bytes.length, sha256: hash(bytes), question_ids: deck.items.map(question => question.id), suggested_filename: download.suggestedFilename() };
  report.downloads.push(record);
  return record;
}
try {
  browser = await chromium.launch({ executablePath: options.browser, headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-background-networking'] });
  report.browser_version = browser.version();
  for (const standalone of [false, true]) {
    const mode = standalone ? 'standalone-phone' : 'modular';
    const context = await browser.newContext({ acceptDownloads: true, viewport: { width: standalone ? 390 : 1280, height: standalone ? 844 : 960 } });
    await context.route('**/*', route => {
      const url = route.request().url();
      if (url.startsWith(origin + '/') || url.startsWith(pathToFileURL(root + '/').href) || url.startsWith('blob:') || url.startsWith('data:')) return route.continue();
      report.external_requests.push(url); return route.abort();
    });
    if (standalone) await context.setOffline(true);
    const page = await context.newPage();
    page.on('pageerror', error => report.page_errors.push(String(error)));
    try {
      await page.goto(standalone ? pathToFileURL(resolve(root, 'focus.html')).href : origin + '/focus/');
      const chooser = page.waitForEvent('filechooser');
      await activate(page.locator('#open-source'));
      await (await chooser).setFiles({ name: 'literal-source.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(source)) });
      await page.locator('#source-preview').waitFor({ state: 'visible' });
      await activate(page.locator('#use-source'));
      assert.equal(await page.evaluate(() => document.activeElement.id), 'targets-heading');
      await page.getByLabel('Focused lesson title', { exact: true }).fill('Distinct targets');
      const names = [1, 2, 3].map(number => `Shared topic Source concept ${number} · 1 question`);
      names.push('Outcome <literal> Source concept 4 · 1 question');
      for (const name of names) assert.equal(await page.getByRole('checkbox', { name, exact: true }).count(), 1, name);
      const initialAccessibility = await page.locator('#target-concepts').ariaSnapshot();
      const outputs = [];
      for (let index = 0; index < 3; index++) {
        if (index) await activate(page.locator('#clear-targets'));
        await activate(page.getByRole('checkbox', { name: names[index], exact: true }), 'Space');
        assert.equal(await page.evaluate(() => document.activeElement.id), 'focus-target-' + index);
        outputs.push(await actualDownload(page, mode, ['first', 'second', 'third'][index], [concepts[index]], [['first'], ['second'], ['third']][index]));
      }
      assert.equal(new Set(outputs.map(record => record.sha256)).size, 3, 'Different literal target concepts must not download the same question');
      await activate(page.locator('#clear-targets'));
      await activate(page.getByRole('checkbox', { name: names[3], exact: true }), 'Space');
      assert.deepEqual(await page.locator('.inclusion-head strong').allTextContents(), ['Source concept 2: Shared\ttopic', 'Source concept 4: Outcome <literal>']);
      assert.deepEqual(await page.locator('.inclusion .badge').allTextContents(), ['Required by links', 'Selected target']);
      assert.ok((await page.locator('.inclusion').first().textContent()).includes('Linked as a prerequisite by: Source concept 4: Outcome <literal>'));
      const branchQuestion = page.locator('[data-item-id="branch"]');
      await branchQuestion.locator('summary').click();
      assert.deepEqual(await branchQuestion.locator('.hint').allTextContents(), ['Source concept 4: Outcome <literal>', 'Prerequisites: Source concept 2: Shared\ttopic']);
      assert.equal(await page.locator('#included-concepts literal, #target-concepts literal').count(), 0);
      const branch = await actualDownload(page, mode, 'branch', [concepts[1], concepts[3]], ['second', 'branch']);
      await page.locator('#included-concepts').scrollIntoViewIfNeeded();
      const dimensions = await page.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }));
      assert.ok(dimensions.scroll <= dimensions.width, JSON.stringify(dimensions));
      const screenshot = mode + '.png';
      await page.screenshot({ path: resolve(output, screenshot), fullPage: true });
      report.screenshots.push(screenshot);
      report.cases.push({ name: mode + ': distinct accessible keyboard targets, exact real files and numbered prerequisite preview', passed: true,
        accessible_names: names, initial_accessibility: initialAccessibility, dimensions, outputs, branch });
      console.log('PASS ' + mode);
    } catch (error) { report.cases.push({ name: mode, passed: false, error: error.stack }); throw error; }
    finally { await context.close(); }
  }
  assert.deepEqual(report.external_requests, []);
  assert.deepEqual(report.page_errors, []);
  for (const path of paths) assert.equal(hash(await readFile(resolve(root, path))), sources[path], path + ' unchanged');
  for (const name of ['first', 'second', 'third', 'branch']) {
    assert.equal(report.downloads.find(row => row.filename === `modular-${name}.focus.json`).sha256,
      report.downloads.find(row => row.filename === `standalone-phone-${name}.focus.json`).sha256);
  }
  report.passed = true;
} catch (error) { report.passed = false; report.error = error.stack; process.exitCode = 1; }
finally {
  await browser?.close();
  await new Promise(done => server.close(done));
  await rm(temporary, { recursive: true, force: true });
  await writeFile(resolve(output, 'receiving.json'), JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ passed: report.passed, cases: report.cases.length, downloads: report.downloads.length, output }));
