import assert from 'node:assert/strict';
import {reference, assertResult, plainMock} from './rational-oracle.mjs';
const checks=[];
let cases=0;
for(const phase of ['coupling','repulsion'])for(let p=0;p<=50;p++){
 const out=plainMock(phase,p);assertResult(out,phase,p);
 const weight=f=>f.numerator*(200/f.denominator);
 assert.equal(out.rows.reduce((s,r)=>s+weight(r.probability),0),200);
 assert.equal(weight(out.totals.recombinant),2*p);
 assert.equal(weight(out.totals.parental),200-2*p);
 for(const f of Object.values(out.marginals))assert.equal(weight(f),100);
 cases++;
}
checks.push({name:'constructive reference invariants',cases,passed:true});
const hands=[
 ['coupling',0,[[1,2],[0,1],[0,1],[1,2]]],
 ['repulsion',0,[[0,1],[1,2],[1,2],[0,1]]],
 ['coupling',20,[[2,5],[1,10],[1,10],[2,5]]],
 ['repulsion',14,[[7,100],[43,100],[43,100],[7,100]]],
 ['coupling',37,[[63,200],[37,200],[37,200],[63,200]]],
 ['repulsion',49,[[49,200],[51,200],[51,200],[49,200]]],
 ['coupling',50,[[1,4],[1,4],[1,4],[1,4]]],
 ['repulsion',50,[[1,4],[1,4],[1,4],[1,4]]],
];
for(const[phase,p,rows]of hands)assert.deepEqual(reference(phase,p).rows.map(r=>Object.values(r.probability)),rows);
checks.push({name:'hand-computed fractions',cases:hands.length,passed:true});
const mutations=[
 ['wrong phase-class probability',x=>{x.rows[0].probability={numerator:1,denominator:10};}],
 ['phase-relative kind lost',x=>{x.rows[0].kind='recombinant';}],
 ['wrong tester genotype',x=>{x.rows[1].offspringGenotype='AaBB';}],
 ['unreduced fraction',x=>{x.rows[0].probability={numerator:4,denominator:10};}],
 ['false independent equality',x=>{x.independentComparison.matches=true;}],
 ['wrong marginal',x=>{x.marginals.A={numerator:2,denominator:5};}],
 ['missing zero-capable row',x=>{x.rows.pop();}],
 ['undeclared output field',x=>{x.physicalDistance=20;}],
];
for(const[name,mutate]of mutations){const x=plainMock('coupling',20);mutate(x);assert.throws(()=>assertResult(x,'coupling',20));}
checks.push({name:'deliberate result mutation controls',cases:mutations.length,mutations:mutations.map(x=>x[0]),passed:true});
console.log(JSON.stringify({schema:'recallweave-linkage-independent-oracle-calibration/1',
 candidateRead:false,productExecution:false,node:process.version,passed:true,checks},null,2));
