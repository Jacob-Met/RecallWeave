import sys,os,json,pathlib,tempfile,hashlib,base64,subprocess,shutil,tarfile,io,termios,traceback
attributes=termios.tcgetattr(sys.stdin.fileno());attributes[3]&=~(termios.ECHO|termios.ICANON);termios.tcsetattr(sys.stdin.fileno(),termios.TCSANOW,attributes)
runtime=pathlib.Path(tempfile.mkdtemp(prefix="estate-60b2c08feb01-timing-browser-",dir="/dev"))
(runtime/"source").mkdir();(runtime/"harness").mkdir();(runtime/"results").mkdir();(runtime/"tmp").mkdir()
state={"runtime":str(runtime),"sharedPins":[]}
node="/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node"
def digest(raw): return hashlib.sha256(raw).hexdigest()
def blob(raw): return hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
def emit(kind,data): print(json.dumps({"kind":kind,**data}),flush=True)
emit("ready",{"runtime":str(runtime)})
for line in sys.stdin:
 try:
  command=json.loads(line)
  if command["action"]=="prepare":
   ui=pathlib.Path("/dev/shm/estate-60b2c08feb01-recall-timing-ui/source")
   model=pathlib.Path("/dev/shm/estate-60b2c08feb01-recall-timing/source")
   rows=[
    (ui,"src/dependency-timing-ui.mjs","09ff092ec1293a76f2f8f8d0c4155a10bfdd8f1f"),
    (ui,"src/dependency-plan.mjs","ad667b4a93b93a755b5f36460c1a5653884a6f7b"),
    (ui,"tools/build-dependency-timing.mjs","4d168d5812c694348f11469efc29928818df035b"),
    (ui,"courses/dependency-timing.template.html","ade32e9bf2cf6a09bb03ef7be76bfc196ff0e1ee"),
    (ui,"courses/dependency-graphs.md","fedb1704e6c14b01cbf03864ac53a65ea5465d31"),
    (model,"src/dependency-timing.mjs","f45e8d7a")]
   pins=[]
   for root,name,expected in rows:
    source=root/name;raw=source.read_bytes();actual=blob(raw);assert actual.startswith(expected),(name,actual,expected)
    target=runtime/"source"/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    pin={"path":name,"bytes":len(raw),"gitBlob":actual,"sha256":digest(raw)}
    pins.append(pin);state["sharedPins"].append({**pin,"source":str(source)})
   for name,content in command["harness"].items():
    raw=content.encode();target=runtime/"harness"/name;target.write_bytes(raw)
   for name,packet in command.get("preservedFiles",{}).items():
    raw=base64.b64decode(packet["base64"],validate=True);assert digest(raw)==packet["sha256"] and len(raw)==packet["bytes"];target=runtime/"harness"/name;target.write_bytes(raw)
   htmlSource=ui/"courses/dependency-timing.html"
   html=htmlSource.read_bytes()
   (runtime/"source"/"courses/dependency-timing.html").write_bytes(html)
   state["sharedPins"].append({"path":"courses/dependency-timing.html","bytes":len(html),"gitBlob":blob(html),"sha256":digest(html),"source":str(htmlSource)})
   preparation={"kind":"copy-exact-frozen-native-standalone","source":str(htmlSource),"bytes":len(html),"gitBlob":blob(html),"sha256":digest(html),"productBuildExecuted":False,"priorNativeBuilds":"Both earlier isolated receiver exports executed the native builder and produced these same bytes; their raw freeze receipts are retained."}
   assert len(html)==51991 and digest(html)=="84929ded09872b14a69da310c50bcfe899ca2fae6d601d98e1063b317b9a0393" and blob(html)=="a955954c7d7d900612ee8111cfd29c39febc1723"
   pins.append({"path":"courses/dependency-timing.html","bytes":len(html),"gitBlob":blob(html),"sha256":digest(html)})
   for pin in pins:
    raw=(runtime/"source"/pin["path"]).read_bytes();assert digest(raw)==pin["sha256"]
   config={"status":"frozen","sourceRoot":str(runtime/"source"),"entry":"courses/dependency-timing.html","outputRoot":str(runtime/"results"),
    "sourcePin":{"kind":"frozen-native-source-blobs","model":pins[-2]["gitBlob"],"ui":pins[0]["gitBlob"],"graph":pins[1]["gitBlob"],"standalone":pins[-1]["gitBlob"],"authorMetadataSha256":"e3f3ce5a3b605d7d2b095a4a4d51b64015c1b6e4b862bc77b04f371a3f013a4c"},
    "sourceFiles":pins,"playwrightModule":"/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs","chromium":"/workspace/scratch/3e50c5ad22c5/production/browser/chromium",
    "contractHashes":{"behavior":"25dbf19401e3220119cc21798fa1dc497f984adcf088b2048fd7ffc9f60afba6","publicAddendum":"4c81bd198d2578d48c4fa8dffca07f6d7d856183bbef9087a7a226510ed86cc6","helper":"6c878c93ba58bf464231e51d209c46d33c37c6f90dacfc4608e0fd6e34b7b6a4","driver":"dce5850bddc202b979f8098fd276c446e794235e6a986db2e1e135f177dc2afd"}}
   configRaw=(json.dumps(config,indent=2,ensure_ascii=False)+"\n").encode();(runtime/"harness"/"execution-config.json").write_bytes(configRaw)
   freeze={"sourcePins":pins,"sharedPins":state["sharedPins"],"configSha256":digest(configRaw),"preparation":preparation,"harness":[{"path":name,"bytes":len(text.encode()),"sha256":digest(text.encode())} for name,text in command["harness"].items()]}
   (runtime/"results"/"source-build-freeze.json").write_text(json.dumps(freeze,indent=2)+"\n")
   state["freeze"]=freeze;emit("prepared",freeze)
  elif command["action"]=="run":
   assert "freeze" in state
   environment=dict(os.environ);environment["TMPDIR"]=str(runtime/"tmp")
   process=subprocess.Popen([node,str(runtime/"harness"/"receive-browser.mjs"),str(runtime/"harness"/"execution-config.json")],cwd=runtime/"harness",env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   lines=[]
   for output in process.stdout: lines.append(output);print(output,end="",flush=True)
   exitcode=process.wait();rawlog="".join(lines).encode();(runtime/"results"/"browser-execution.log").write_bytes(rawlog)
   shared=[]
   for pin in state["sharedPins"]:
    raw=pathlib.Path(pin["source"]).read_bytes();shared.append({"path":pin["source"],"unchanged":digest(raw)==pin["sha256"],"sha256":digest(raw)})
   state["exitCode"]=exitcode;state["sharedReadback"]=shared
   emit("completed",{"exitCode":exitcode,"sharedReadback":shared,"receiptExists":(runtime/"results"/"receipt.json").exists()})
  elif command["action"]=="json":
   name=command["name"];p=(runtime/name).resolve();assert p.is_relative_to(runtime);emit("json",{"name":name,"data":json.loads(p.read_text())})
  elif command["action"]=="file":
   p=(runtime/command["name"]).resolve();assert p.is_relative_to(runtime);raw=p.read_bytes()
   offset=command.get("offset",0);size=command.get("size",8190);part=raw[offset:offset+size]
   emit("file",{"name":command["name"],"totalBytes":len(raw),"sha256":digest(raw),"offset":offset,"partBytes":len(part),"base64":base64.b64encode(part).decode()})
  elif command["action"]=="list":
   emit("files",{"files":[{"path":str(p.relative_to(runtime)),"bytes":p.stat().st_size} for p in runtime.rglob("*") if p.is_file() and "tmp" not in p.relative_to(runtime).parts]})
  elif command["action"]=="record":
   name=command["name"];assert pathlib.Path(name).name==name
   raw=base64.b64decode(command["base64"],validate=True);assert digest(raw)==command["sha256"]
   p=runtime/"results"/name
   with p.open("xb") as out: out.write(raw)
   assert p.read_bytes()==raw
   emit("recorded",{"name":"results/"+name,"bytes":len(raw),"sha256":digest(raw)})
  elif command["action"]=="pack":
   selected=[p for folder in ["source","harness","results"] for p in (runtime/folder).rglob("*") if p.is_file()]
   manifest={"schema":"recallweave-timing-independent-archive/1","members":[{"path":str(p.relative_to(runtime)),"bytes":p.stat().st_size,"sha256":digest(p.read_bytes())} for p in sorted(selected)]}
   (runtime/"archive-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
   archive=runtime/"independent-native-evidence.tar.gz"
   with tarfile.open(archive,"w:gz") as out:
    for p in sorted(selected): out.add(p,arcname=str(p.relative_to(runtime)),recursive=False)
    out.add(runtime/"archive-manifest.json",arcname="archive-manifest.json",recursive=False)
   with tarfile.open(archive,"r:gz") as inp:
    for entry in manifest["members"]:
     raw=inp.extractfile(entry["path"]).read();assert len(raw)==entry["bytes"] and digest(raw)==entry["sha256"]
   raw=archive.read_bytes();emit("packed",{"name":"independent-native-evidence.tar.gz","bytes":len(raw),"sha256":digest(raw),"members":len(manifest["members"])+1})
  elif command["action"]=="close":
   shutil.rmtree(runtime);emit("closed",{"runtime":str(runtime)});break
  else: raise ValueError("Unknown action")
 except BaseException as error: emit("error",{"error":str(error),"traceback":traceback.format_exc()})
