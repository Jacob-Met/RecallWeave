#!/usr/bin/env node
/**
 * Independent Euclid browser and native learner receiving.
 * CDP lifecycle/download transport follows RecallWeave tools/check_sql_query_browser.mjs
 * at Git blob 2933c00f1174dc5e243e16eee3dcb27cc8107e00; new scenarios are confined here.
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, mkdtemp, rm, rename, stat, readdir } from 'node:fs/promises';
import { dirname, extname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { receiveLearner } from './receive_learner.mjs';

const args=process.argv.slice(2);
const option=(name,fallback)=>args.includes(name)?args[args.indexOf(name)+1]:fallback;
const carrier=dirname(fileURLToPath(import.meta.url));
const root=resolve(option('--root',join(carrier,'source')));
const executable=option('--browser','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
const output=resolve(option('--output',join(carrier,'evidence','browser-v1')));
const manifestPath=resolve(option('--manifest',join(carrier,'reference','subject-v1.json')));
const sha=b=>createHash('sha256').update(b).digest('hex');
const gitBlob=b=>createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const manifestBytes=await readFile(manifestPath), manifest=JSON.parse(manifestBytes);
await mkdir(output);
const downloadPath=join(output,'downloads');await mkdir(downloadPath);
const profile=await mkdtemp(join(output,'profile-'));
const report={status:'running',root,output,executable,node:process.version,platform:process.platform,architecture:process.arch,
  subjectManifest:sha(manifestBytes),checks:[],screenshots:[],downloads:[],explorer:[],pageErrors:[],pageRequests:[],blockedRequests:[]};
async function sourcePins(){
  const pins={};
  for(const expected of manifest.files){
    const file=join(root,expected.path),b=await readFile(file),s=await stat(file);
    const row={sha256:sha(b),git_blob:gitBlob(b),bytes:b.length,mode:s.mode&0o111?'100755':'100644'};
    assert.equal(row.sha256,expected.sha256,expected.path+' SHA256');
    assert.equal(row.git_blob,expected.git_blob,expected.path+' Git blob');
    assert.equal(row.bytes,expected.bytes,expected.path+' byte length');
    assert.equal(row.mode,expected.mode,expected.path+' mode');
    pins[expected.path]=row;
  }
  async function walk(folder,prefix=''){
    const paths=[];
    for(const e of await readdir(folder,{withFileTypes:true})){
      const path=prefix+e.name;
      if(e.isDirectory())paths.push(...await walk(join(folder,e.name),path+'/'));
      else {assert.ok(e.isFile(),'Source entries are regular files');paths.push(path);}
    }
    return paths;
  }
  assert.deepEqual((await walk(root)).sort(),Object.keys(pins).sort());
  return pins;
}
report.before=await sourcePins();
const {computeEuclid}=await import(pathToFileURL(join(root,'src/euclidean-algorithm.mjs')));
const courseBytes=await readFile(join(root,'courses/euclidean-algorithm.json'));
const oracleBytes=await readFile(join(carrier,'reference','blind-oracles.json'));
assert.equal(sha(oracleBytes),'7d2c6566151dc6ecd654073254c3d707ade4d6649abce2a98cd4b4559f269252');
const blindOracles=JSON.parse(oracleBytes).vectors;
report.blindOracle={sha256:sha(oracleBytes),used:[]};
const downloads=new Map(),pending=new Map();
let browser,socket,sessionId,sequence=0,browserLog='',serverClosed=false;
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const allowed=new Set(manifest.files.map(x=>x.path));
const server=createServer(async(request,response)=>{
  try{
    const path=decodeURIComponent(new URL(request.url,'http://localhost').pathname).replace(/^\/+/,'')||'index.html';
    if(!allowed.has(path)){response.writeHead(404).end();return;}
    const b=await readFile(join(root,path));
    const mime={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.json':'application/json'};
    response.writeHead(200,{'Content-Type':(mime[extname(path)]||'application/octet-stream')+'; charset=utf-8','Cache-Control':'no-store'}).end(b);
  }catch{response.writeHead(404).end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base='http://127.0.0.1:'+server.address().port;
async function waitFor(check,label){
  let last;
  for(let i=0;i<120;i++){try{if(await check())return;}catch(error){last=error;}await sleep(75);}
  throw new Error('Timed out: '+label+(last?' ('+last.message+')':''));
}
function command(method,params={},scoped=true){
  const id=++sequence;
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{pending.delete(id);reject(new Error('CDP timeout: '+method));},15000);
    pending.set(id,{resolve,reject,timer});
    socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));
  });
}
async function evaluate(expression){
  const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);
  return r.result.value;
}
async function key(name,shift=false){
  const codes={Enter:13,Tab:9,ArrowDown:40,ArrowUp:38,ArrowRight:39,ArrowLeft:37,Home:36,End:35,Backspace:8,Escape:27};
  for(const type of ['keyDown','keyUp'])await command('Input.dispatchKeyEvent',{
    type,key:name,code:name,windowsVirtualKeyCode:codes[name],nativeVirtualKeyCode:codes[name],modifiers:shift?8:0,
    ...(name==='Enter'&&type==='keyDown'?{text:'\r',unmodifiedText:'\r'}:{})});
}
async function activate(selector){
  assert.ok(await evaluate('!!document.querySelector('+JSON.stringify(selector)+')'),'Missing control '+selector);
  await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');await key('Enter');
}
async function tabTo(selector){
  for(let i=0;i<100;i++){
    if(await evaluate('document.activeElement.matches('+JSON.stringify(selector)+')'))return;
    await key('Tab');
  }
  throw new Error('Keyboard Tab did not reach '+selector);
}
async function fill(selector,text){
  await evaluate('(()=>{const e=document.querySelector('+JSON.stringify(selector)+');e.focus();e.select();})()');
  await key('Backspace');
  if(text)await command('Input.insertText',{text});
  assert.equal(await evaluate('document.querySelector('+JSON.stringify(selector)+').value'),text);
}
async function chooseFile(selector,file){
  const {root:doc}=await command('DOM.getDocument');
  const {nodeId}=await command('DOM.querySelector',{nodeId:doc.nodeId,selector});
  assert.ok(nodeId,'Native file input '+selector);
  await command('DOM.setFileInputFiles',{nodeId,files:[file]});
}
async function navigate(url,width=1280,height=1000,ready='#euclid-form'){
  await command('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
  await command('Page.navigate',{url});
  await waitFor(()=>evaluate('document.URL === '+JSON.stringify(url)+' && document.readyState === "complete" && !!document.querySelector('+JSON.stringify(ready)+')'),'native page '+url);
}
async function capture(name,selector){
  if(selector)await evaluate('document.querySelector('+JSON.stringify(selector)+').scrollIntoView({block:"start"})');
  const {data}=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
  const b=Buffer.from(data,'base64');await writeFile(join(output,name),b);
  report.screenshots.push({name,bytes:b.length,sha256:sha(b)});
}
async function download(selector,name){
  const previous=new Set(downloads.keys());
  await activate(selector);
  let value;
  await waitFor(()=>{value=[...downloads.values()].find(x=>!previous.has(x.guid)&&x.state==='completed');return Boolean(value);},'actual download '+name);
  const original=join(downloadPath,value.guid),path=join(downloadPath,name);
  const bytes=await readFile(original);
  await rename(original,path);
  const record={name,suggestedFilename:value.suggestedFilename,guid:value.guid,bytes:bytes.length,sha256:sha(bytes)};
  report.downloads.push(record);
  return {...record,path,bytes};
}
const passed=name=>{report.checks.push(name);console.log('PASS '+name);};
async function explorerState(){
  return evaluate("({a:document.querySelector('#euclid-a').value,b:document.querySelector('#euclid-b').value,"
    +"hidden:document.querySelector('#results').hidden,empty:document.querySelector('#empty').hidden,"
    +"gcd:document.querySelector('#gcd-value').textContent,result:document.querySelector('#result-inputs').textContent,"
    +"coefficient:document.querySelector('#bezout-result').textContent,inspector:document.querySelector('#inspector').hidden,"
    +"count:document.querySelector('#result-count').textContent,"
    +"step:document.querySelector('#step-count').textContent,equation:document.querySelector('#division-equation').textContent,"
    +"rows:[...document.querySelectorAll('#division-rows tr')].map(r=>[...r.cells].map(c=>c.textContent)),"
    +"traceDisabled:document.querySelector('#download-trace').disabled,zero:document.querySelector('#zero-convention').hidden})");
}
async function compute(a,b){
  await fill('#euclid-a',a);await fill('#euclid-b',b);
  assert.equal(await evaluate("document.querySelector('#results').hidden"),true);
  assert.equal(await evaluate("document.querySelector('#download-trace').disabled"),true);
  await tabTo('#compute');await key('Enter');
  await waitFor(()=>evaluate("!document.querySelector('#results').hidden"),'computed '+a+','+b);
  const expected=computeEuclid(a,b),state=await explorerState();
  assert.equal(state.gcd,expected.gcd);assert.equal(state.result,'gcd('+expected.inputs.a+', '+expected.inputs.b+') = '+expected.gcd);
  assert.equal(state.coefficient,expected.gcd+' = ('+expected.coefficients.x+') × '+expected.inputs.a+' + ('+expected.coefficients.y+') × '+expected.inputs.b);
  assert.deepEqual(state.rows,expected.steps.map(x=>[String(x.index),x.dividend,x.divisor,x.quotient,x.remainder]));
  assert.equal(state.inspector,expected.steps.length===0);assert.equal(state.traceDisabled,false);
  assert.equal(state.zero,expected.inputs.a!=='0'||expected.inputs.b!=='0');
  const oracle=blindOracles.find(v=>v.a===expected.inputs.a&&v.b===expected.inputs.b);
  if(oracle){
    assert.equal(state.gcd,oracle.gcd);
    assert.deepEqual(state.rows,oracle.steps.map((x,i)=>[String(i+1),x.dividend,x.divisor,x.quotient,x.remainder]));
    report.blindOracle.used.push([oracle.a,oracle.b]);
  }
  report.explorer.push({input:[a,b],expected,state});
  return expected;
}
async function assertStep(expected,index){
  const s=expected.steps[index];
  const actual=await evaluate("({step:document.querySelector('#step-count').textContent,equation:document.querySelector('#division-equation').textContent,"
    +"current:[...document.querySelectorAll('#division-rows tr[aria-current]')].map(r=>r.dataset.index),"
    +"previous:document.querySelector('#previous-step').disabled,next:document.querySelector('#next-step').disabled,last:document.querySelector('#last-step').disabled,"
    +"coefficients:['dividend-combination','divisor-combination','remainder-combination'].map(id=>document.getElementById(id).textContent),"
    +"diagramTitle:document.querySelector('#diagram-title').textContent,diagramDescription:document.querySelector('#diagram-desc').textContent})");
  assert.equal(actual.step,'Inspecting division '+(index+1)+' of '+expected.steps.length);
  assert.equal(actual.equation,s.dividend+' = '+s.quotient+' × '+s.divisor+' + '+s.remainder);
  assert.deepEqual(actual.current,[String(index)]);assert.equal(actual.previous,index===0);
  assert.equal(actual.next,index===expected.steps.length-1);assert.equal(actual.last,index===expected.steps.length-1);
  for(const [i,field] of ['dividend','divisor','remainder'].entries()){
    const c=s[field+'Coefficients'];
    assert.equal(actual.coefficients[i],s[field]+' = ('+c.x+') × '+expected.inputs.a+' + ('+c.y+') × '+expected.inputs.b);
  }
  assert.equal(actual.diagramTitle,'Division '+s.index+': '+s.dividend+' by '+s.divisor);
  report.explorer.at(-1).inspected??=[];report.explorer.at(-1).inspected.push(actual);
}
async function receiveExplorer(){
  const url=pathToFileURL(join(root,'courses/euclidean-algorithm-explorer.html')).href;
  await navigate(url,1280,1050);
  assert.equal(await evaluate("document.querySelector('#results').hidden"),true);
  assert.equal(await evaluate("document.querySelector('#download-trace').disabled"),true);
  await tabTo('#euclid-a');
  const expected=await compute('252','198');assert.equal(expected.gcd,'18');
  await assertStep(expected,0);
  await activate('#next-step');await assertStep(expected,1);
  await activate('#previous-step');await assertStep(expected,0);
  await activate('#last-step');await assertStep(expected,expected.steps.length-1);
  await activate('#division-rows tr:nth-child(2) button');await assertStep(expected,1);
  const before=await explorerState();
  const trace=await download('#download-trace','explorer-252-198-trace.json');
  assert.equal(trace.suggestedFilename,'euclid-252-198.json');
  assert.deepEqual(trace.bytes,Buffer.from(JSON.stringify(expected,null,2)+'\n'));
  assert.deepEqual(await explorerState(),before);
  await capture('explorer-desktop.png','#results');
  passed('direct-file explorer requires Compute; exact rows, equation, coefficients and accessible current step follow native Next/Previous/Last and row controls');

  await fill('#euclid-a','1.5');
  assert.equal(await evaluate("document.querySelector('#results').hidden"),true);
  assert.equal(await evaluate("document.querySelector('#download-trace').disabled"),true);
  await activate('#compute');
  assert.equal(await evaluate("document.querySelector('#euclid-error').hidden"),false);
  const invalidBefore=await explorerState();
  const course=await download('#download-course','downloaded-euclidean-algorithm.json');
  assert.equal(course.suggestedFilename,'euclidean-algorithm.json');assert.deepEqual(course.bytes,courseBytes);
  assert.deepEqual(await explorerState(),invalidBefore);
  for(const text of ['', '-1', '1e3', 'NaN', '1000000', '12 3']){
    await fill('#euclid-a',text);await activate('#compute');
    assert.equal(await evaluate("document.querySelector('#results').hidden"),true);
    assert.equal(await evaluate("document.querySelector('#download-trace').disabled"),true);
    assert.equal(await evaluate("document.querySelector('#euclid-error').hidden"),false);
  }
  passed('edited and invalid inputs retire the visible result and exact trace; the actual lesson download remains independent and byte exact');
  const smaller=await compute('18','48');assert.equal(smaller.steps[0].quotient,'0');await assertStep(smaller,0);
  const normalized=await compute(' 000045 ','000000');assert.equal(normalized.gcd,'45');assert.equal(normalized.steps.length,0);
  await evaluate("document.querySelector('#example').focus()");await key('Home');
  for(let i=0;i<5;i++)await key('ArrowDown');
  await key('Tab');assert.equal(await evaluate('document.activeElement.id'),'load-example');await key('Enter');
  assert.equal(await evaluate("document.querySelector('#results').hidden"),true);
  assert.equal(await evaluate("document.querySelector('#download-trace').disabled"),true);
  assert.equal(await evaluate("document.querySelector('#euclid-a').value"),'0');assert.equal(await evaluate("document.querySelector('#euclid-b').value"),'0');
  await key('Enter');
  assert.equal(await evaluate("document.querySelector('#gcd-value').textContent"),'0');
  assert.equal(await evaluate("document.querySelector('#zero-convention').hidden"),false);
  assert.equal(await evaluate("document.querySelector('#inspector').hidden"),true);
  const zeros=await download('#download-trace','explorer-zero-zero-trace.json');
  assert.deepEqual(JSON.parse(zeros.bytes.toString('utf8')),computeEuclid('0','0'));
  const upper=await compute('999999','999998');assert.equal(upper.gcd,'1');await assertStep(upper,0);
  const zeroFirst=await compute('0','999999');assert.equal(zeroFirst.steps.length,1);await assertStep(zeroFirst,0);
  passed('smaller-first quotient zero, normalized decimal input, zero-divisor no-division state and explicit gcd(0,0)=0 convention work through native controls');

  await navigate(url,390,844);
  const large=await compute('832040','514229');await activate('#last-step');await assertStep(large,large.steps.length-1);
  await activate('#inspector details summary');
  assert.equal(await evaluate("document.documentElement.scrollWidth > innerWidth"),false);
  const geometry=await evaluate("({viewport:innerWidth,width:document.documentElement.scrollWidth,table:(()=>{const e=document.querySelector('.table-scroll'),r=e.getBoundingClientRect();return {left:r.left,right:r.right,width:e.clientWidth,scroll:e.scrollWidth};})(),"
    +"coefficients:[...document.querySelectorAll('.detail-grid dd')].map(e=>{const r=e.getBoundingClientRect();return {text:e.textContent,left:r.left,right:r.right,height:r.height};})})");
  assert.ok(geometry.table.left>=0&&geometry.table.right<=390);
  assert.ok(geometry.table.scroll>geometry.table.width);
  for(const r of geometry.coefficients)assert.ok(r.left>=0&&r.right<=390);
  await evaluate("document.querySelector('.table-scroll').focus()");
  await key('ArrowRight');
  await waitFor(()=>evaluate("document.querySelector('.table-scroll').scrollLeft>0"),'keyboard horizontal table scroll');
  report.phoneGeometry=geometry;
  await capture('explorer-phone-result.png','#results');
  await capture('explorer-phone-coefficients.png','#inspector details');
  const largeTrace=await download('#download-trace','explorer-large-trace.json');
  assert.deepEqual(JSON.parse(largeTrace.bytes.toString('utf8')),large);
  passed('390px explorer wraps long coefficients and keeps every large integer row in a keyboard-scrollable table without page overflow');

  const stable=await explorerState(),oldDownloads=downloads.size;
  await evaluate("window.receivingURL=URL.createObjectURL;URL.createObjectURL=()=>{throw new Error('authored download refusal');}");
  await activate('#download-trace');
  assert.equal(downloads.size,oldDownloads);
  assert.deepEqual(await explorerState(),stable);
  assert.ok((await evaluate("document.querySelector('#euclid-status').textContent")).includes('could not start'));
  await evaluate("URL.createObjectURL=window.receivingURL;delete window.receivingURL;");
  const retried=await download('#download-trace','explorer-large-retry-trace.json');
  assert.deepEqual(retried.bytes,largeTrace.bytes);
  assert.deepEqual(await explorerState(),stable);
  passed('a refused trace download preserves the exact calculation and permits an ordinary byte-identical retry');
  return course.path;
}
async function closeServer(){
  if(serverClosed)return;server.closeAllConnections();await new Promise(resolve=>server.close(resolve));serverClosed=true;
}
function waitForBrowserExit(ms){
  if(!browser||browser.exitCode!==null||browser.signalCode!==null)return Promise.resolve(true);
  return new Promise(resolve=>{
    const finish=()=>{clearTimeout(timer);browser.off('exit',finish);resolve(true);};
    const timer=setTimeout(()=>{browser.off('exit',finish);resolve(false);},ms);browser.once('exit',finish);
  });
}
try{
  browser=spawn(executable,['--headless=new','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions',
    '--password-store=basic','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0',
    '--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1, EXCLUDE localhost','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
  browser.stderr.on('data',b=>{browserLog=(browserLog+b.toString()).slice(-6000);});
  const endpoint=await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error('Chromium startup timed out: '+browserLog)),45000);
    browser.on('error',e=>{clearTimeout(timer);reject(e);});browser.on('exit',c=>{clearTimeout(timer);reject(new Error('Chromium exited '+c+': '+browserLog));});
    browser.stderr.on('data',()=>{const m=browserLog.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});
  });
  socket=new WebSocket(endpoint);
  socket.addEventListener('message',event=>{
    const message=JSON.parse(event.data);
    if(message.id){
      const p=pending.get(message.id);if(!p)return;pending.delete(message.id);clearTimeout(p.timer);
      if(message.error)p.reject(new Error(message.error.message));else p.resolve(message.result);
    }else if(message.method==='Browser.downloadWillBegin'||message.method==='Browser.downloadProgress'){
      const v=message.params;downloads.set(v.guid,{...downloads.get(v.guid),...v});
    }else if(message.method==='Runtime.exceptionThrown')report.pageErrors.push(message.params.exceptionDetails.exception?.description??message.params.exceptionDetails.text);
    else if(message.method==='Network.requestWillBeSent')report.pageRequests.push(message.params.request.url);
    else if(message.method==='Fetch.requestPaused'){
      const p=message.params,url=p.request.url;
      if(url.startsWith(base+'/'))command('Fetch.continueRequest',{requestId:p.requestId}).catch(e=>report.pageErrors.push(e.message));
      else{report.blockedRequests.push(url);command('Fetch.failRequest',{requestId:p.requestId,errorReason:'BlockedByClient'}).catch(e=>report.pageErrors.push(e.message));}
    }
  });
  await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
  report.browser=await command('Browser.getVersion',{},false);
  await command('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath,eventsEnabled:true},false);
  const {targetId}=await command('Target.createTarget',{url:'about:blank'},false);
  ({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));
  for(const method of ['Page.enable','Runtime.enable','Network.enable','DOM.enable'])await command(method);
  await command('Network.setCacheDisabled',{cacheDisabled:true});
  await command('Network.setBypassServiceWorker',{bypass:true});
  await command('Fetch.enable',{patterns:[{urlPattern:'http://*'},{urlPattern:'https://*'}]});
  const api={root,output,report,evaluate,activate,key,waitFor,chooseFile,download,capture,passed,navigate,fill,tabTo};
  const courseFile=await receiveExplorer();
  await receiveLearner(api,courseFile,[
    {label:'modular-desktop',url:base+'/index.html',width:1280,height:1000},
    {label:'standalone-phone',url:pathToFileURL(join(root,'demo.html')).href,width:390,height:844}
  ]);
  assert.deepEqual(report.blockedRequests,[]);
  assert.deepEqual(report.pageErrors,[]);
  assert.ok(report.pageRequests.every(url=>url.startsWith(base+'/')||url.startsWith('file:')||url.startsWith('blob:')));
  report.after=await sourcePins();assert.deepEqual(report.after,report.before);
  passed('all 21 frozen source inputs remain exact; observed page requests are local only and no JavaScript exception occurred');
  report.status='passed';
}catch(error){
  report.status='failed';report.error=error.stack??String(error);report.browserLog=browserLog;process.exitCode=1;console.error(report.error);
  if(sessionId)try{report.lastPage=await evaluate("({url:location.href,text:document.body.innerText.slice(0,12000),focus:document.activeElement.outerHTML})");await capture('failed-state.png');}catch{}
}finally{
  try{report.after=await sourcePins();assert.deepEqual(report.after,report.before);}catch(e){report.sourceGuardError=e.stack??String(e);report.status='failed';process.exitCode=1;}
  if(socket?.readyState===WebSocket.OPEN)try{await command('Browser.close',{},false);}catch{}
  socket?.close();for(const p of pending.values())clearTimeout(p.timer);
  if(!await waitForBrowserExit(5000)){browser.kill('SIGTERM');await waitForBrowserExit(5000);}
  await closeServer();
  try{
    if(browser&&browser.exitCode===null&&browser.signalCode===null)throw new Error('Owned browser exit was not observed');
    await rm(profile,{recursive:true,force:true,maxRetries:5,retryDelay:150});
    report.profileCleanup='Owned browser exited; only its generated temporary profile was removed.';
  }catch(e){report.profileCleanup={retained:profile,pid:browser?.pid,error:e.message};report.status='failed';process.exitCode=1;}
  await writeFile(join(output,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
  console.log('EUCLID_BROWSER_'+(report.status==='passed'?'OK':'FAILED')+' checks='+report.checks.length+' failures='+(report.status==='passed'?0:1));
}
