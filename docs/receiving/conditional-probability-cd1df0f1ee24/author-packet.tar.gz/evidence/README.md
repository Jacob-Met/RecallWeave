# Probability model author packet

This archive preserves the three exact authored files, the original combined RDC test transcript/tool response, source pins and a receipt explaining the execution and failed evidence-write boundaries. The maintained Node run reports 13 tests passed, zero failed; streams were not captured separately. The shell reported exit 0 after the later hash command. Independent numerical, build and browser qualification are separate packets.

`qualified/` contains exact candidate bytes. `evidence/` contains this index and receipts. `member-manifest.json` records every other archive member. The archive's own hash and byte count are recorded outside it to avoid a self-reference.
