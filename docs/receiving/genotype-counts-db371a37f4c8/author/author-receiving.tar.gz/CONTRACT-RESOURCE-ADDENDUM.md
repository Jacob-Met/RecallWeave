# Resource-floor correction — 2026-10-09

Root clarified after reading the original #261 offer that the admitted native floors for this lane are C: >= 1 GiB, D: >= 1 GiB, and available memory >= 2 GiB. The original contract's D: >= 256 MiB sentence was too weak and is superseded prospectively by D: >= 1 GiB. Every future admission/launch will enforce the stronger D: floor.

The original contract, staging code and native receipt remain unchanged. The recorded original admission had hundreds of gigabytes free on D: and therefore also exceeded the clarified floor; this is a read-only interpretation of the retained capacity observation, not a rerun or a claim that the old guard code enforced the new threshold. No existing baseline is repeated.

All source, scientific scope, public G1..G6 inputs and independent expectations remain unchanged.
