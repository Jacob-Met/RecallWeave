import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { chromium } from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { expected, allCompletions } from './oracle.mjs';

const sourceRoot=process.argv[2], outputDir=process.argv[3];
if(!sourceRoot||!outputDir) throw Error('Pass frozen source root and private receiving output directory.');
fs.mkdirSync(outputDir,{recursive:true});
const freezePath=path.join(sourceRoot,'../source-freeze.json');
const freeze=JSON.parse(fs.readFileSync(freezePath,'utf8'));
assert.equal(freeze.head,'b48f33b507418ef4eaa16407567e7dfa5567218c');
assert.equal(freeze.tree,'2bd8932fbfdfb2be5449940820dc30c096052a70');
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const blob=b=>crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const sourcePaths=[...Object.keys(freeze.sourcePins),'courses/dependency-graphs.json','src/deck.mjs','demo.html'];
function sourcePins() {
  return Object.fromEntries(sourcePaths.map(p=>{
    const b=fs.readFileSync(path.join(sourceRoot,p));
    return [p,{bytes:b.length,sha256:digest(b),blob:blob(b)}];
  }));
}
const before=sourcePins();
for(const [p,pin] of Object.entries(freeze.sourcePins)) {
  assert.equal(before[p].sha256,pin.sha256,p);assert.equal(before[p].blob,pin.sha,p);
}
assert.equal(before['src/dependency-plan.mjs'].sha256,'fea26b701e2e394c86309d4e2d1927c7743205b17210d1b50c8676faaeb27b10');
assert.equal(before['courses/dependency-graphs-explorer.html'].sha256,'2a88659ac288a89dc1b1443b3a9deb5a2e28e61d78d71aac491e6f2f70e8e170');
assert.equal(before['courses/dependency-graphs.json'].blob,'6e36d7113308540eb923fe5f5c83f1ba0b0ac537');
assert.equal(before['src/deck.mjs'].blob,'f0f8a4b234489c2388f427633f548d56c6ed4c03');
assert.equal(before['demo.html'].blob,'223ee1a4452e01c0fea2194c6921f82f4a062f6e');
const originalCourse=fs.readFileSync(path.join(sourceRoot,'courses/dependency-graphs.json'));
assert.equal(digest(originalCourse),'e6538a1a28c6a1ce31be2b20095abf8c0d4461c4ba3aa07388181f9efd57810d');
const {parseDeck}=await import(pathToFileURL(path.join(sourceRoot,'src/deck.mjs')));
const course=JSON.parse(originalCourse.toString('utf8'));
const runtime=fs.mkdtempSync('/dev/estate-60b2c08feb01-recall-graph-receiver-');
const browserExecutable='/workspace/scratch/3e50c5ad22c5/production/browser/chromium';
const oldTmp=process.env.TMPDIR;
process.env.TMPDIR=runtime;
const report={schema:'recallweave.graph-independent-browser-receiving.v1',started_at:new Date().toISOString(),
 source:{head:freeze.head,tree:freeze.tree,pins:before},groups:[],snapshots:[],
 runtime:{node:process.version,platform:os.platform(),browserExecutable,privateProfile:true},
 network:{offline:true,requests:[],offOrigin:[]},pageErrors:[],consoleErrors:[],dialogs:[],
 substitutions:{product_source:0,API:0,HTML:0,responses:0},course:null,cleanup:{},passed:false};
let context,page,downloadedPath,currentPhase='launch';
function attachPage(p) {
  p.on('pageerror',error=>report.pageErrors.push({phase:currentPhase,error:String(error)}));
  p.on('console',message=>{if(message.type()==='error')report.consoleErrors.push({phase:currentPhase,text:message.text()});});
  p.on('dialog',async dialog=>{report.dialogs.push({phase:currentPhase,type:dialog.type(),message:dialog.message()});await dialog.dismiss();});
}
async function group(name,fn) {
  currentPhase=name;const started=performance.now();
  try { const details=await fn();report.groups.push({name,passed:true,milliseconds:Math.round(performance.now()-started),details}); }
  catch(error) {report.groups.push({name,passed:false,error:{name:error.name,message:error.message,stack:error.stack}});throw error;}
}
async function snapshot(label,graph,history) {
  const view=await page.evaluate(()=>({
    rows:[...document.querySelectorAll('#job-rows tr')].map(tr=>({
      job:tr.dataset.job,status:tr.dataset.status,
      exactLabel:tr.querySelector('th').textContent,
      prerequisites:tr.children[2].textContent,unmet:tr.children[3].textContent})),
    ready:[...document.querySelectorAll('#ready-jobs button')].map(b=>b.dataset.completeJob),
    history:[...document.querySelectorAll('#completion-history li')].map(li=>li.textContent),
    cycleGroups:[...document.querySelectorAll('#cycle-groups li')].map(li=>li.textContent),
    blocked:document.querySelector('#blocked-jobs').textContent,
    orders:[...document.querySelectorAll('#orders-list li')].map(li=>li.textContent),
    ordersNote:document.querySelector('#orders-note').textContent,
    progress:document.querySelector('#plan-progress').textContent,
    status:document.querySelector('#graph-status').textContent
  }));
  const want=expected(graph,history);
  assert.deepEqual(view.history,history);
  assert.deepEqual(view.ready,want.ready);
  assert.equal(view.rows.length,graph.jobs.length);
  for(const row of want.rows) {
    const got=view.rows.find(r=>r.job===row.name);assert.ok(got);
    assert.equal(got.exactLabel,row.name);
    const state=history.includes(row.name)?'complete':want.ready.includes(row.name)?'ready':
      want.cycleMembers.includes(row.name)?'cycle':want.blockedByCycle.includes(row.name)?'blocked':'waiting';
    assert.equal(got.status,state);
    assert.equal(got.prerequisites,row.prerequisites.join(', ')||'None');
    assert.equal(got.unmet,state==='complete'?'—':row.unmet.join(', ')||'None');
  }
  assert.equal(view.blocked,want.blockedByCycle.join(', ')||'None');
  const orders=allCompletions(graph,history);
  assert.deepEqual(view.orders,orders.slice(0,12).map(x=>x.join(' → ')));
  report.snapshots.push({label,graph,history,view});
  return view;
}
async function preview(graph) {
  await page.locator('#jobs-input').fill(graph.jobs.join('\n'));
  await page.locator('#edges-input').fill(graph.edges.map(([a,b])=>a+' -> '+b).join('\n'));
  await page.locator('#preview-graph').click();
  await page.locator('#plan-results').waitFor({state:'visible'});
}
async function keyboardComplete(name) {
  const button=page.getByRole('button',{name:'Complete '+name,exact:true});
  await button.focus();await page.keyboard.press('Enter');
}
try {
  context=await chromium.launchPersistentContext(path.join(runtime,'profile'),{
    executablePath:browserExecutable,headless:true,viewport:{width:1180,height:900},acceptDownloads:true,
    args:['--no-sandbox','--disable-dev-shm-usage'],env:{...process.env,TMPDIR:runtime}
  });
  context.setDefaultTimeout(10000);
  report.runtime.chromium=context.browser().version();
  const req=createRequire(import.meta.url);
  report.runtime.playwright=req('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/package.json').version;
  context.on('page',attachPage);for(const p of context.pages())attachPage(p);
  context.on('request',request=>{
    const url=request.url();report.network.requests.push({phase:currentPhase,url,method:request.method()});
    if(!/^(file:|data:|blob:|about:)/.test(url))report.network.offOrigin.push(url);
  });
  await context.route('**/*',async route=>{
    if(/^(file:|data:|blob:|about:)/.test(route.request().url()))await route.continue();
    else await route.abort('internetdisconnected');
  });
  await context.setOffline(true);
  page=context.pages()[0]||await context.newPage();
  await page.goto(pathToFileURL(path.join(sourceRoot,'courses/dependency-graphs-explorer.html')).href);
  await page.locator('#plan-results').waitFor({state:'visible'});

  const cycle={jobs:['Tail','A','B','Free'],edges:[['A','B'],['B','A'],['B','Tail']]};
  await group('Cycle members, a nonmember tail and positive-length inspection in the built page',async()=>{
    await preview(cycle);
    const first=await snapshot('cycle initial',cycle,[]);
    assert.equal(first.cycleGroups.length,1);
    assert.match(first.cycleGroups[0],/A, B/);assert.equal(first.blocked,'Tail');
    await page.locator('#inspect-job').selectOption('A');
    assert.equal(await page.locator('#reachable-jobs').textContent(),'Tail, A, B');
    assert.match(await page.locator('#reach-origin-note').textContent(),/cycle returns/);
    await page.locator('#inspect-job').selectOption('Free');
    assert.equal(await page.locator('#reachable-jobs').textContent(),'None');
    assert.match(await page.locator('#reach-origin-note').textContent(),/starting job is excluded/);
    await keyboardComplete('Free');
    const completed=await snapshot('independent job completed despite cycle',cycle,['Free']);
    assert.equal(completed.orders.length,0);assert.match(completed.ordersNote,/No complete order/);
    await page.locator('#undo-step').focus();await page.keyboard.press('Enter');
    await snapshot('undo restores the independent job',cycle,[]);
    await keyboardComplete('Free');
    await page.locator('#reset-plan').focus();await page.keyboard.press('Enter');
    await snapshot('reset preserves cycle graph',cycle,[]);
    return {cycleMembers:['A','B'],nonmemberBlocked:['Tail'],positiveReachabilityFromA:['Tail','A','B'],independentCompletionAndUndoReset:true};
  });

  await group('Editing clears old actions; invalid and C1 drafts cannot revive the prior graph',async()=>{
    await keyboardComplete('Free');
    await page.locator('#jobs-input').fill('A\u0085B\nFree');
    assert.equal(await page.locator('#jobs-input').inputValue(),'A\u0085B\nFree');
    assert.equal(await page.locator('#plan-results').isVisible(),false);
    assert.equal(await page.locator('#ready-jobs button').count(),0);
    assert.equal(await page.locator('#completion-history li').count(),0);
    assert.equal(await page.locator('#undo-step').isDisabled(),true);
    assert.equal(await page.locator('#reset-plan').isDisabled(),true);
    await page.locator('#edges-input').fill('');
    await page.locator('#preview-graph').click();
    await page.locator('#graph-error').waitFor({state:'visible'});
    assert.match(await page.locator('#graph-error').textContent(),/control characters/);
    assert.equal(await page.evaluate(()=>document.activeElement.id),'graph-error');
    assert.equal(await page.locator('#plan-results').isVisible(),false);
    await page.locator('#jobs-input').fill('Safe\nEnd');
    assert.equal(await page.locator('#plan-results').isVisible(),false);
    await page.locator('#edges-input').fill('Safe -> Missing');
    await page.locator('#preview-graph').click();
    await page.locator('#graph-error').waitFor({state:'visible'});
    assert.equal(await page.locator('#ready-jobs button').count(),0);
    assert.equal(await page.locator('#plan-results').isVisible(),false);
    return {earlierActionsAndHistoryRemoved:true,C1RefusalInActualCorrectedBundle:true,unknownEndpointRefused:true,errorReceivesFocus:true};
  });

  const literal={jobs:['<b>"Plan"</b>','__proto__','Ship'],edges:[['<b>"Plan"</b>','__proto__'],['__proto__','Ship']]};
  await group('Literal names, keyboard completion and reversible progress at 375 pixels',async()=>{
    await page.setViewportSize({width:375,height:900});
    await preview(literal);await snapshot('literal DAG initial',literal,[]);
    assert.equal(await page.locator('#job-rows th b').count(),0);
    assert.equal(await page.locator('#ready-jobs button b').count(),0);
    const titles=await page.locator('#graph-map g title').allTextContents();
    assert.ok(titles.some(t=>t.startsWith(literal.jobs[0]+':')));
    await keyboardComplete(literal.jobs[0]);await snapshot('literal job keyboard completion',literal,[literal.jobs[0]]);
    const focus=await page.evaluate(()=>({
      job:document.activeElement.dataset.completeJob,
      outline:getComputedStyle(document.activeElement).outlineWidth,
      control:{width:document.activeElement.getBoundingClientRect().width,height:document.activeElement.getBoundingClientRect().height},
      viewport:innerWidth,document:document.documentElement.scrollWidth
    }));
    assert.equal(focus.job,'__proto__');assert.notEqual(focus.outline,'0px');
    assert.ok(focus.control.height>=44);assert.ok(focus.document<=focus.viewport+1);
    await page.locator('#plan-results').screenshot({path:path.join(outputDir,'narrow-plan.png')});
    await page.keyboard.press('Enter');await snapshot('next ready keyboard completion',literal,[literal.jobs[0],'__proto__']);
    await page.locator('#undo-step').focus();await page.keyboard.press('Enter');
    await snapshot('literal DAG undo retains prefix',literal,[literal.jobs[0]]);
    await page.locator('#reset-plan').focus();await page.keyboard.press('Enter');
    await snapshot('literal DAG reset retains exact graph',literal,[]);
    assert.equal(await page.locator('#jobs-input').inputValue(),literal.jobs.join('\n'));
    return {literalLabelsPreserved:true,noLabelHTMLCreated:true,focus,narrowScreenshot:'narrow-plan.png'};
  });

  const many={jobs:['z','Y','x','W','v','U','t','S'],edges:[]};
  await group('Visible deterministic order cap and exact original course after custom graph changes',async()=>{
    await preview(many);
    const initial=await snapshot('eight independent jobs',many,[]);
    assert.equal(initial.orders.length,12);
    assert.match(initial.ordersNote,/First 12 complete orders shown; more exist/);
    assert.match(initial.ordersNote,/not the total count/);
    await keyboardComplete('W');
    await snapshot('orders extend chosen nonfirst prefix',many,['W']);
    const downloadEvent=page.waitForEvent('download');
    await page.locator('#download-course').click();
    const download=await downloadEvent;
    assert.equal(download.suggestedFilename(),'dependency-graphs.json');
    downloadedPath=path.join(runtime,'downloaded-dependency-graphs.json');
    await download.saveAs(downloadedPath);
    const received=fs.readFileSync(downloadedPath);
    assert.deepEqual(received,originalCourse);
    const native=parseDeck(received.toString('utf8'));
    assert.equal(native.items.length,12);assert.equal(native.concepts.length,4);
    assert.deepEqual(native,course);
    fs.writeFileSync(path.join(outputDir,'downloaded-course.json'),received);
    report.course={suggestedFilename:download.suggestedFilename(),bytes:received.length,sha256:digest(received),gitBlob:blob(received),nativeValidatorBlob:before['src/deck.mjs'].blob,nativeImport:{format:native.format,title:native.title,concepts:native.concepts,ids:native.items.map(x=>x.id)}};
    assert.deepEqual(await page.locator('#completion-history li').allTextContents(),['W']);
    return {shownOrders:12,totalIndependentOrders:40320,exactPrefix:['W'],downloadBytes:received.length,downloadSha256:digest(received),nativeImportItems:12,graphProgressUnaffected:true};
  });

  await group('Actual relative learner link, staged local preview and explicit first-question transition',async()=>{
    const nextPage=context.waitForEvent('page');
    await page.getByRole('link',{name:'Open the learner in another tab',exact:true}).click();
    const learner=await nextPage;await learner.waitForLoadState('domcontentloaded');
    assert.equal(learner.url(),pathToFileURL(path.join(sourceRoot,'demo.html')).href);
    await learner.locator('#deck-file').waitFor({state:'visible'});
    assert.equal(await learner.locator('#step-count').textContent(),'0 / 6');
    await learner.locator('#deck-file').setInputFiles(downloadedPath);
    await learner.locator('#deck-preview').waitFor({state:'visible'});
    assert.equal(await learner.locator('#deck-preview-title').textContent(),course.title);
    assert.deepEqual(await learner.locator('#deck-preview .deck-questions strong').allTextContents(),course.items.map(x=>x.prompt));
    assert.equal(await learner.locator('#deck-preview .deck-preview-attribution').textContent(),'Attribution supplied in the deck: '+course.attribution);
    assert.equal(await learner.locator('#deck-preview .deck-preview-license').textContent(),'License supplied in the deck: '+course.license);
    assert.equal(await learner.locator('#step-count').textContent(),'0 / 6');
    await learner.locator('#start-deck').click();
    assert.equal(await learner.locator('#step-count').textContent(),'0 / 12');
    assert.match(await learner.locator('#lesson-size').textContent(),/12/);
    await learner.locator('#start-button').click();
    const prompt=await learner.locator('#session-content .question-card h2').textContent();
    const item=course.items.find(x=>x.prompt===prompt);assert.ok(item);
    const choices=await learner.locator('#session-content [data-choice]').evaluateAll(nodes=>nodes.map(n=>({choice:Number(n.dataset.choice),text:n.textContent})));
    assert.equal(choices.length,item.options.length);
    assert.deepEqual(choices.map(c=>c.choice).sort(),[0,1,2,3]);
    for(const choice of choices)assert.ok(choice.text.includes(item.options[choice.choice]));
    assert.equal(await learner.locator('#step-count').textContent(),'0 / 12');
    assert.deepEqual(await page.locator('#completion-history li').allTextContents(),['W']);
    return {learnerBlob:before['demo.html'].blob,previewedPrompts:12,previewKeptOriginalSession:true,explicitStartChangedToTwelveItems:true,firstQuestion:item.id,firstAnswerStillPending:true,graphProgressUnaffected:true};
  });
  assert.deepEqual(report.network.offOrigin,[]);
  assert.deepEqual(report.pageErrors,[]);
  assert.deepEqual(report.consoleErrors,[]);
  assert.deepEqual(report.dialogs,[]);
  report.passed=true;
} catch(error) {
  report.error={phase:currentPhase,name:error.name,message:error.message,stack:error.stack};
  if(page)try{await page.screenshot({path:path.join(outputDir,'failure.png'),fullPage:true});}catch{}
} finally {
  if(context)try{await context.close();report.cleanup.browserClosed=true;}catch(error){report.cleanup.closeError=String(error);report.passed=false;}
  const after=sourcePins();report.source.after=after;report.source.unchanged=JSON.stringify(before)===JSON.stringify(after);
  if(!report.source.unchanged)report.passed=false;
  fs.rmSync(runtime,{recursive:true,force:true});report.cleanup.privateProfileRemoved=!fs.existsSync(runtime);
  if(oldTmp===undefined)delete process.env.TMPDIR;else process.env.TMPDIR=oldTmp;
  report.finished_at=new Date().toISOString();
  report.harness={sha256:digest(fs.readFileSync(process.argv[1])),oracleSha256:digest(fs.readFileSync(new URL('./oracle.mjs',import.meta.url)))};
  for(const name of ['narrow-plan.png','failure.png'])if(fs.existsSync(path.join(outputDir,name))){
    const b=fs.readFileSync(path.join(outputDir,name));(report.images??={})[name]={bytes:b.length,sha256:digest(b)};
  }
  fs.writeFileSync(path.join(outputDir,'receipt.json'),JSON.stringify(report,null,2)+'\n');
  process.stdout.write(JSON.stringify({passed:report.passed,groups:report.groups,sourceUnchanged:report.source.unchanged,
    pageErrors:report.pageErrors,consoleErrors:report.consoleErrors,offOrigin:report.network.offOrigin,
    error:report.error,receipt:path.join(outputDir,'receipt.json'),receiptSha256:digest(fs.readFileSync(path.join(outputDir,'receipt.json'))),images:report.images,cleanup:report.cleanup})+'\n');
  process.exitCode=report.passed?0:1;
}
