#!/usr/bin/env node
// Actual standalone browser receiver, authored from declared UI and numerical
// contracts before candidate inspection. No candidate helper is imported.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const [htmlPath,coursePath,fixturePath,outDir,playwrightEntry]=process.argv.slice(2);
if(!htmlPath||!coursePath||!fixturePath||!outDir||!playwrightEntry)throw new Error('Usage: receive_explorer.mjs HTML COURSE_JSON FIXTURE_JSON OUT PLAYWRIGHT');
const root=path.resolve(outDir);await fs.mkdir(root,{recursive:false});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const html=await fs.readFile(htmlPath),course=await fs.readFile(coursePath),fixtureBytes=await fs.readFile(fixturePath),fixture=JSON.parse(fixtureBytes);
const writeJson=(p,x)=>fs.writeFile(p,JSON.stringify(x,null,2)+'\n');
const report={schema:'recall-prefix-independent-explorer-browser-v1',argv:process.argv,node:process.version,
  sourceHtmlSha256:sha(html),courseSha256:sha(course),fixtureSha256:sha(fixtureBytes),cases:[],checks:[],downloads:[],
  pageErrors:[],requests:[],blockedRequests:[],negativeControls:[]};
const check=(name,fn)=>{try{fn();report.checks.push({name,ok:true});return true;}catch(e){report.checks.push({name,ok:false,error:e.stack||String(e)});return false;}};
function expectedModel(e){let cost=0;return {rows:e.symbols,nodes:e.nodes.map(n=>({id:n.id,weight:n.count,symbol:n.symbol,left:n.left,right:n.right})),root:e.root,
 steps:e.merges.map((s,i)=>{const addedCost=e.nodes[s.parent].count;cost+=addedCost;return {index:i+1,...s,addedCost,accumulatedCost:cost};}),
 codebook:e.codebook.map(c=>({symbol:c.symbol,count:c.count,code:c.bits,length:c.length,cost:c.count*c.length})),
 totals:{totalCount:e.totalCount,payloadBits:e.weightedBits,fixedWidth:e.fixedWidth,fixedPayloadBits:e.fixedBits,
 averageBits:e.averageBits,savedPayloadBits:e.fixedBits-e.weightedBits,mergeWeightSum:e.weightedBits}};}
function message(model){let bits='';const symbols=model.rows.map(r=>r.symbol),segments=[];for(const symbol of symbols){const code=model.codebook.find(c=>c.symbol===symbol).code,start=bits.length;bits+=code;segments.push({symbol,code,start,end:bits.length});}return {bits,symbols,segments};}
const integer=text=>{const m=String(text).match(/-?\d[\d,]*/);return m?Number(m[0].replaceAll(',','')):null;};
async function observe(page){return page.evaluate(()=>{
 const rows=id=>{const target=document.querySelector(id);return [...(target?.querySelectorAll('tr')||[])].filter(r=>!r.closest('thead')&&r.querySelector('td')).map(r=>[...r.children].filter(c=>/^(TD|TH)$/.test(c.tagName)).map(c=>c.textContent));};
 const headers=id=>[...(document.querySelector(id)?.querySelectorAll('thead th')||[])].map(c=>c.textContent);
 const queue=document.querySelector('#queue'),book=document.querySelector('#codebook'),svg=document.querySelector('#tree-svg');
 const error=document.querySelector('#input-error');
 const visibleError=error&&!error.hidden&&error.getClientRects().length&&getComputedStyle(error).visibility!=='hidden';
 const storage=name=>{try{return {keys:Object.keys(window[name]),available:true};}catch(e){return {keys:[],available:false,error:e.message};}};
 const local=storage('localStorage'),session=storage('sessionStorage');
 const trace=document.querySelector('#decode-trace');let segments=[...(trace?.querySelectorAll('li,tr')||[])].filter(x=>!x.closest('thead'));
 if(!segments.length&&trace)segments=[...trace.children];
 return {title:document.title,text:document.body.innerText,labels:[...document.querySelectorAll('.symbol-row input[id^="symbol-"]')].map(x=>x.value),
 counts:[...document.querySelectorAll('.symbol-row input[id^="count-"]')].map(x=>x.value),book:rows('#codebook'),queue:rows('#queue'),
 queueHeaders:headers('#queue'),codebookHeaders:headers('#codebook'),payload:document.querySelector('#payload-bits')?.textContent,
 fixedPayload:document.querySelector('#fixed-payload-bits')?.textContent,average:document.querySelector('#average-bits')?.textContent,
 step:document.querySelector('#step-status')?.textContent,inputError:visibleError?error.textContent:'',rawInputError:error?.textContent,
 bits:document.querySelector('#bits')?.value,decoded:document.querySelector('#decoder-result')?.textContent,
 trace:segments.map(x=>x.textContent),downloadDisabled:document.querySelector('#download-example')?.disabled,
 courseDownloadDisabled:document.querySelector('#download-course')?.disabled,fixtureTags:document.querySelectorAll('#prefix-x').length,
 width:innerWidth,documentWidth:document.documentElement.scrollWidth,svg:svg?.outerHTML,
 svgBox:svg?{width:svg.getBoundingClientRect().width,height:svg.getBoundingClientRect().height}:null,
 treeScroll:document.querySelector('#tree-scroll')?{clientWidth:document.querySelector('#tree-scroll').clientWidth,scrollWidth:document.querySelector('#tree-scroll').scrollWidth}:null,
 localStorageKeys:local.keys,sessionStorageKeys:session.keys,storageAvailability:{local,session}};
 });}
function inspect(snapshot,model,step){
 assert.deepEqual(snapshot.labels,model.rows.map(r=>r.symbol));assert.deepEqual(snapshot.counts.map(Number),model.rows.map(r=>r.count));
 assert.equal(snapshot.book.length,model.codebook.length);
 for(let i=0;i<model.codebook.length;i++){
  const row=snapshot.book[i],c=model.codebook[i];assert.equal(row.length,5);
  assert(row[0]===c.symbol||row[0]===JSON.stringify(c.symbol),'literal symbol cell');
  assert.equal(integer(row[1]),c.count);assert.equal(row[2].trim(),c.code);assert.equal(integer(row[3]),c.length);assert.equal(integer(row[4]),c.cost);
 }
 assert.equal(integer(snapshot.payload),model.totals.payloadBits);assert.equal(integer(snapshot.fixedPayload),model.totals.fixedPayloadBits);
 const queue=step?model.steps[step-1].after:model.steps[0].before;
 assert.equal(snapshot.queue.length,queue.length);
 const weightColumn=snapshot.queueHeaders.findIndex(x=>/weight|count/i.test(x));assert(weightColumn>=0,'queue has an explicit weight/count heading');
 assert.deepEqual(snapshot.queue.map(row=>integer(row[weightColumn])),queue.map(id=>model.nodes[id].weight));
 assert(snapshot.svgBox&&snapshot.svgBox.width>0&&snapshot.svgBox.height>0,'actual SVG tree is visible');
 assert(snapshot.documentWidth<=snapshot.width+1,'document remains within viewport');
 assert.equal(snapshot.fixtureTags,0,'markup-like labels stay literal');
 assert.equal(snapshot.downloadDisabled,false);assert(!snapshot.inputError?.trim());
}
async function setRows(page,rows){
 let count=await page.locator('.symbol-row').count();
 while(count<rows.length){await page.locator('#add-symbol').click();count++;}
 while(count>rows.length){await page.getByRole('button',{name:'Remove symbol '+count,exact:true}).click();count--;}
 for(let i=0;i<rows.length;i++){await page.locator('#symbol-'+i).fill(rows[i].symbol);await page.locator('#count-'+i).fill(String(rows[i].count));}
}
async function download(page,id,dir,label){
 const waiting=page.waitForEvent('download');await page.locator(id).click();const result=await waiting;
 const target=path.join(dir,label+'.json');await result.saveAs(target);const data=await fs.readFile(target);
 report.downloads.push({label,path:target,bytes:data.length,sha256:sha(data),suggestedFilename:result.suggestedFilename()});return data;
}
let browser;
try{
 const {chromium}=await import(pathToFileURL(playwrightEntry));
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--no-first-run','--disable-background-networking','--disable-component-update','--disable-sync']});report.browser=await browser.version();
 for(const item of fixture.cases){
  const label=item.name,dir=path.join(root,label);await fs.mkdir(dir);const detached=path.join(dir,'detached');await fs.mkdir(detached);
  const file=path.join(detached,'explorer.html');await fs.writeFile(file,html);
  const context=await browser.newContext({viewport:{width:item.width,height:900},acceptDownloads:true});
  await context.route('**/*',r=>{if(/^https?:/.test(r.request().url())){report.blockedRequests.push({case:label,url:r.request().url()});return r.abort();}return r.continue();});
  const page=await context.newPage();page.on('pageerror',e=>report.pageErrors.push({case:label,message:e.message}));page.on('request',r=>report.requests.push({case:label,url:r.url(),method:r.method()}));
  const record={name:label,width:item.width,rows:item.rows,states:[]};report.cases.push(record);
  try{
   await page.goto(pathToFileURL(file).href,{waitUntil:'load'});await page.locator('#symbol-0').waitFor({state:'visible'});
   await setRows(page,item.expected.symbols);const model=expectedModel(item.expected),decoded=message(model);
   let snapshot=await observe(page);record.states.push({phase:'rebuilt',step:0,observation:snapshot});
   check(label+':initial-complete-model',()=>inspect(snapshot,model,0));
   check(label+':row-edits-reset-decoder',()=>assert.equal(snapshot.bits,''));
   for(let step=1;step<=model.steps.length;step++){
    await page.locator('#step-next').focus();await page.keyboard.press('Enter');snapshot=await observe(page);record.states.push({phase:'merge',step,observation:snapshot});
    check(label+':merge-'+step,()=>inspect(snapshot,model,step));
   }
   check(label+':last-step-boundary',()=>assert.equal(record.states.at(-1).observation.queue.length,1));
   const nextDisabled=await page.locator('#step-next').isDisabled();check(label+':next-disabled-at-end',()=>assert(nextDisabled));
   await page.locator('#step-back').focus();await page.keyboard.press('Enter');snapshot=await observe(page);
   record.states.push({phase:'previous',step:model.steps.length-1,observation:snapshot});check(label+':previous-merge',()=>inspect(snapshot,model,model.steps.length-1));
   await page.locator('#step-reset').click();const backDisabled=await page.locator('#step-back').isDisabled();check(label+':first-step-boundary',()=>assert(backDisabled));
   const chosen=Math.floor(model.steps.length/2);for(let i=0;i<chosen;i++)await page.locator('#step-next').click();
   await page.locator('#sample-bits').click();
   const bits=await page.locator('#bits').inputValue();check(label+':sample-bits-match-canonical-symbols',()=>assert.equal(bits,decoded.bits));
   await page.locator('#decode-button').focus();await page.keyboard.press('Enter');snapshot=await observe(page);record.states.push({phase:'decoded',step:chosen,observation:snapshot});
   check(label+':decoded-literal-sequence',()=>{const match=snapshot.decoded.match(/\[[\s\S]*\]/);assert(match);assert.deepEqual(JSON.parse(match[0]),decoded.symbols);assert.equal(snapshot.trace.length,decoded.segments.length);});
   const data=await download(page,'#download-example',dir,'worked-example');const parsed=JSON.parse(data);
   check(label+':exact-current-export',()=>assert.deepEqual(parsed,{format:'recallweave.prefix-coding/1',model,inspection:{step:chosen},decoding:decoded}));
   check(label+':export-newline',()=>assert(data.at(-1)===10));record.exportSha256=sha(data);
   await page.locator('#bits').fill('2');const retired=await page.locator('#download-example').isDisabled();check(label+':bits-edit-retires-download',()=>assert(retired));
   await page.locator('#decode-button').click();const bad=await observe(page);record.states.push({phase:'invalid-decoder',observation:bad});
   check(label+':invalid-decoder-has-no-valid-export',()=>{assert.equal(bad.downloadDisabled,true);assert.equal(bad.book.length,model.codebook.length);});
   await page.locator('#count-0').fill('1.5');const invalid=await observe(page);record.states.push({phase:'invalid-count',observation:invalid});
   check(label+':invalid-count-clears-derived-state',()=>{assert.equal(invalid.book.length,0);assert.equal(invalid.downloadDisabled,true);assert(invalid.inputError.trim());assert.equal(invalid.courseDownloadDisabled,false);});
   if(label==='declared-default'){
    const deck=await download(page,'#download-course',dir,'lesson-during-invalid-example');check('course-export-independent-and-exact',()=>assert(deck.equals(course)));
    const changed=structuredClone(parsed);changed.model.totals.payloadBits++;
    let rejected=false;try{assert.deepEqual(changed,{format:'recallweave.prefix-coding/1',model,inspection:{step:chosen},decoding:decoded});}catch{rejected=true;}
    report.negativeControls.push({name:'altered-captured-example-payload',application_runs:0,rejected});check('negative:altered-captured-example-detected',()=>assert(rejected));
   }
   await page.locator('#count-0').fill(String(model.rows[0].count));snapshot=await observe(page);record.states.push({phase:'repaired',step:0,observation:snapshot});
   check(label+':repaired-count-resets-valid-state',()=>{inspect(snapshot,model,0);assert.equal(snapshot.bits,'');});
   await page.locator('#step-all').click();snapshot=await observe(page);record.states.push({phase:'finished',step:model.steps.length,observation:snapshot});check(label+':show-finished-tree',()=>inspect(snapshot,model,model.steps.length));
   check(label+':no-browser-persistence',()=>{assert.deepEqual(snapshot.localStorageKeys,[]);assert.deepEqual(snapshot.sessionStorageKeys,[]);});
   await fs.writeFile(path.join(dir,'saved-dom.html'),await page.content());await page.screenshot({path:path.join(dir,'viewport.png'),fullPage:false});await page.screenshot({path:path.join(dir,'full-page.png'),fullPage:true});
   const detachedNames=await fs.readdir(detached),detachedBytes=await fs.readFile(file);
   check(label+':standalone-single-file',()=>{assert.deepEqual(detachedNames,['explorer.html']);assert(detachedBytes.equals(html));});
  }catch(e){record.observerError=e.stack||String(e);check(label+':browser-complete',()=>{throw e;});}
  finally{await writeJson(path.join(dir,'case.json'),record);await context.close();}
 }
 check('no-application-errors',()=>assert.deepEqual(report.pageErrors,[]));check('no-external-request-attempts',()=>assert.deepEqual(report.blockedRequests,[]));
 check('all-declared-cases-complete',()=>assert.equal(report.cases.filter(c=>!c.observerError).length,fixture.cases.length));
}catch(e){report.harnessError=e.stack||String(e);check('browser-harness-complete',()=>{throw e;});}
finally{
 if(browser)await browser.close();
 report.sourceAfterSha256=sha(await fs.readFile(htmlPath));report.courseAfterSha256=sha(await fs.readFile(coursePath));
 check('original-delivered-html-unchanged',()=>assert.equal(report.sourceAfterSha256,report.sourceHtmlSha256));check('original-course-unchanged',()=>assert.equal(report.courseAfterSha256,report.courseSha256));
 report.passedChecks=report.checks.filter(x=>x.ok).length;report.failedChecks=report.checks.filter(x=>!x.ok).length;
 await writeJson(path.join(root,'report.json'),report);console.log(JSON.stringify({cases:report.cases.length,downloads:report.downloads.length,passedChecks:report.passedChecks,failedChecks:report.failedChecks,harnessError:report.harnessError,report:path.join(root,'report.json')}));
 process.exitCode=report.failedChecks?1:0;
}
