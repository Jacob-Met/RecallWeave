import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const out=path.join(root,'model-v1');
assert(!fs.existsSync(out),'existing receiver must be inspected, not replayed');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const source=path.join(root,'linear-programming-v1.mjs');
const sourceHash='63e3a3661c0c3e1ab7da3eedd2aa3ed72c2de479ee7e29973d75de9dfdc1e18d';
assert.equal(hash(source),sourceHash);
const stat=fs.statfsSync(root);
const mem=Number(fs.readFileSync('/proc/meminfo','utf8').match(/^MemAvailable:\s+(\d+)/m)[1])*1024;
assert(stat.bavail*stat.bsize>16*1024*1024,'capacity refusal');
assert(mem>128*1024*1024,'memory refusal');
const oracle=JSON.parse(fs.readFileSync(path.join(root,'FRACTION-ORACLE.json'),'utf8'));
const hands=JSON.parse(fs.readFileSync(path.join(root,'HAND-CASES.json'),'utf8'));
assert.equal(hash(path.join(root,'FRACTION-ORACLE.json')),'0d2966f372fe7871056db5a504b6e1ef2be42588f9851383bea0d556788a1d55');
const model=await import('./linear-programming-v1.mjs');
fs.mkdirSync(out);
const results=[];
const write=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const clone=x=>structuredClone(x);
const sorted=x=>[...x].sort();
const pairKey=p=>sorted(p).join('|');
function deepFrozen(x){
 if(x&&typeof x==='object'){assert(Object.isFrozen(x));Object.values(x).forEach(deepFrozen);}
 assert.notEqual(typeof x,'bigint');
}
function test(name,fn){
 try {const facts=fn();results.push({name,status:'pass',facts});}
 catch(error){results.push({name,status:'failed',error:String(error),stack:error.stack});}
}
function coordinateSet(values){return values.map(v=>v.join(',')).sort();}
function summary(result){
 const byId=new Map(result.vertices.map(v=>[v.id,[v.x,v.y]]));
 return {vertices:coordinateSet(result.vertices.map(v=>[v.x,v.y])),region:result.region.kind,
 optimum:result.optimum?{value:result.optimum.value,coordinates:coordinateSet(result.optimum.vertices.map(id=>byId.get(id))),kind:result.optimum.kind,wholeRegion:result.optimum.wholeRegion}:null};
}
for(const hand of hands){
 test(hand.id,()=>{
  const expected=oracle.cases.find(c=>c.id===hand.id).result;
  const input=clone(hand.problem),before=clone(input);
  const actual=model.solveProblem(input);
  write(hand.id+'.json',actual);
  assert.deepEqual(input,before,'solver may not mutate caller input');
  deepFrozen(actual);
  assert.deepEqual(actual.problem,hand.problem);
  assert.deepEqual(actual.vertices.map(v=>[v.x,v.y]),hand.expected.vertices,'complete exact lexicographic vertex set');
  assert.equal(actual.region.kind,hand.expected.region);
  assert.deepEqual(actual.boundaries.map(({id,a,b,c})=>({id,a,b,c})),expected.boundaries);
  const ids=new Map(actual.vertices.map(v=>[v.id,[v.x,v.y]]));
  assert.equal(actual.pairs.length,expected.pairs.length);
  assert.equal(new Set(actual.pairs.map(p=>pairKey([p.first,p.second]))).size,expected.pairs.length);
  const expectedPairs=new Map(expected.pairs.map(p=>[pairKey(p.boundaries),p]));
  for(const pair of actual.pairs){
   const want=expectedPairs.get(pairKey([pair.first,pair.second]));assert(want);
   assert.equal(pair.kind,want.kind);
   if(pair.kind==='intersection'){
    assert.deepEqual([pair.point.x,pair.point.y],want.coordinates);
    assert.equal(pair.feasible,want.feasible);
    assert.deepEqual(sorted(pair.violated),sorted(want.violated));
    if(pair.feasible)assert.deepEqual(ids.get(pair.vertex),want.coordinates);
    else assert(!Object.hasOwn(pair,'vertex'));
   }
  }
  for(let i=0;i<actual.vertices.length;i++){
   const got=actual.vertices[i],want=expected.vertices[i];
   assert.equal(got.id,want.id);assert.equal(got.objective,want.objective);
   assert.deepEqual(sorted(got.active),sorted(want.active));
   assert.deepEqual(Object.fromEntries(got.slacks.map(s=>[s.id,s.value])),want.slacks);
   assert.deepEqual(sorted(got.pairs.map(pairKey)),sorted(want.pairs.map(pairKey)));
   assert.equal(got.optimal,Boolean(actual.optimum?.vertices.includes(got.id)));
  }
  const boundary=actual.region.boundary.map(id=>ids.get(id));
  assert(boundary.every(Boolean));assert.equal(new Set(actual.region.boundary).size,actual.region.boundary.length);
  if(actual.region.kind==='polygon'){
   assert(expected.boundary.some((_,offset)=>JSON.stringify(boundary)===JSON.stringify([...expected.boundary.slice(offset),...expected.boundary.slice(0,offset)])),'exact CCW boundary, arbitrary starting rotation');
  } else assert.deepEqual(coordinateSet(boundary),coordinateSet(expected.boundary));
  if(hand.expected.optimum===null)assert.equal(actual.optimum,null);
  else {
   const want=hand.expected.optimum;
   assert.equal(actual.optimum.value,want.value);
   assert.equal(actual.optimum.sense,hand.problem.objective.sense);
   assert.equal(actual.optimum.wholeRegion,want.wholeRegion);
   assert.deepEqual(coordinateSet(actual.optimum.vertices.map(id=>ids.get(id))),coordinateSet(want.vertices));
   // The additive API clarification preserves the hand-derived full optimal
   // set, while kind describes geometry and wholeRegion describes coverage.
   const geometry=want.vertices.length===1?'point':want.vertices.length===2?'segment':'region';
   assert.equal(actual.optimum.kind,geometry);
  }
  const snapshot=JSON.stringify(actual);
  input.bounds.xmin=999;input.constraints.push({a:0,b:0,c:-1});
  assert.equal(JSON.stringify(actual),snapshot,'returned admitted problem is detached');
  assert.throws(()=>{actual.problem.bounds.xmin=999;},TypeError);
  const selected=actual.vertices[0]?.id??null;
  const observation=JSON.parse(model.observationJSON(actual,selected));
  assert.deepEqual(observation,{...actual,inspection:{selectedVertex:selected}});
  assert.throws(()=>model.observationJSON(actual,'V999'));
  return {vertices:actual.vertices.length,pairs:actual.pairs.length,region:actual.region.kind,optimum:actual.optimum};
 });
}
test('positive_scaling_and_row_permutation',()=>{
 const base=hands[0].problem;
 const reversed={...clone(base),constraints:[...base.constraints].reverse().map(c=>({...c}))};
 const scaled={...clone(base),constraints:base.constraints.map(c=>({a:2*c.a,b:2*c.b,c:2*c.c}))};
 const expected=summary(model.solveProblem(base));
 assert.deepEqual(summary(model.solveProblem(reversed)),expected);
 assert.deepEqual(summary(model.solveProblem(scaled)),expected);
 return {transforms:2,geometryAndOptimumUnchanged:true,sourceRowsRetained:true};
});
test('api_limits_types_and_exact_known_fields',()=>{
 const base=hands[0].problem;
 const bad=[];
 const change=fn=>{const p=clone(base);fn(p);bad.push(p);};
 change(p=>{delete p.bounds;});
 change(p=>{p.extra=1;});
 change(p=>{p.bounds.extra=1;});
 change(p=>{p.objective.extra=1;});
 change(p=>{p.constraints[0].extra=1;});
 change(p=>{p.bounds.xmin=5;});
 change(p=>{p.bounds.xmin=-21;});
 change(p=>{p.bounds.xmax=21;});
 change(p=>{p.constraints=Array.from({length:9},()=>({a:0,b:0,c:0}));});
 change(p=>{p.constraints=new Array(1);});
 change(p=>{p.objective.sense='both';});
 for(const value of ['1',true,null,0.5,NaN,Infinity,-Infinity]){
  change(p=>{p.constraints[0].a=value;});
  change(p=>{p.objective.p=value;});
 }
 for(const value of [-101,101]){
  change(p=>{p.constraints[0].c=value;});
  change(p=>{p.objective.q=value;});
 }
 for(const p of [null,[],...bad])assert.throws(()=>model.validateProblem(p));
 const admitted=model.validateProblem(hands.at(-1).problem);
 deepFrozen(admitted);assert.equal(admitted.constraints.length,8);
 return {invalidProblemsRefused:bad.length+2,maximumRowsAndRangesAccepted:true};
});
test('literal_integer_text_and_inclusive_limits',()=>{
 const base={xmin:'-0',xmax:'02',ymin:'+0',ymax:'2',constraints:' +01, -0, 02\r\n\r0,01,2\r ',p:'+01',q:'00',sense:'max'};
 const p=model.parseProblem(base);
 assert.deepEqual(p,{bounds:{xmin:0,xmax:2,ymin:0,ymax:2},constraints:[{a:1,b:0,c:2},{a:0,b:1,c:2}],objective:{p:1,q:0,sense:'max'}});
 assert(!Object.is(p.bounds.xmin,-0));assert(!Object.is(p.constraints[0].b,-0));
 assert.equal(model.parseProblem({...base,constraints:' '.repeat(4096)}).constraints.length,0);
 assert.throws(()=>model.parseProblem({...base,constraints:' '.repeat(4097)}));
 assert.equal(model.parseProblem({...base,p:'0'.repeat(32)}).objective.p,0);
 assert.throws(()=>model.parseProblem({...base,p:'0'.repeat(33)}));
 assert.equal(model.parseProblem({...base,constraints:Array(8).fill('0,0,0').join('\n')}).constraints.length,8);
 assert.throws(()=>model.parseProblem({...base,constraints:Array(9).fill('0,0,0').join('\n')}));
 for(const text of ['1.0','1e0','0x1','1+1','+','', '101','-101'])assert.throws(()=>model.parseProblem({...base,p:text}));
 for(const text of ['1,2','1,2,3,4','1,,2','1.5,0,2'])assert.throws(()=>model.parseProblem({...base,constraints:text}));
 const fields=model.problemFields(p);deepFrozen(fields);assert.deepEqual(model.parseProblem(fields),p);
 return {exactText4096:true,exactToken32:true,exactRows8:true,canonicalSignedZero:true,literalGrammar:true,roundTrip:true};
});
test('presets_are_immutable_valid_problems',()=>{
 deepFrozen(model.PRESETS);
 assert.equal(new Set(model.PRESETS.map(p=>p.id)).size,model.PRESETS.length);
 for(const preset of model.PRESETS){
  assert.equal(typeof preset.title,'string');assert.equal(typeof preset.note,'string');
  assert.deepEqual(model.validateProblem(preset.problem),preset.problem);
 }
 return {presets:model.PRESETS.length};
});
assert.equal(hash(source),sourceHash);
const result={schema:'e3.recall-lp.independent-model-receiving/1',utc:new Date().toISOString(),node:process.version,
 sourceSha256:sourceHash,oracleSha256:hash(path.join(root,'FRACTION-ORACLE.json')),
 labelClarificationSha256:hash(path.join(root,'API-LABEL-CLARIFICATION.json')),driverSha256:hash(fileURLToPath(import.meta.url)),
 resources:{availableBytes:stat.bavail*stat.bsize,memoryAvailableBytes:mem},
 authorTestsRead:false,sourceUnchanged:true,groups:results,passed:results.filter(r=>r.status==='pass').length,
 failed:results.filter(r=>r.status!=='pass').length};
result.status=result.failed?'failed':'pass';
write('RESULTS.json',result);
console.log(JSON.stringify({status:result.status,passed:result.passed,failed:result.failed,
 resultsPath:path.join(out,'RESULTS.json'),resultsSha256:hash(path.join(out,'RESULTS.json')),
 failures:results.filter(r=>r.status!=='pass')}));
process.exitCode=result.failed?1:0;
