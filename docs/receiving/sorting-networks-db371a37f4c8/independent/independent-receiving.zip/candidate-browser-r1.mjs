import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {fileURLToPath,pathToFileURL} from 'node:url';
import {chromium} from 'file:///D:/Hamon/receiving/pneumatic-goals-root-db371a37f4c8/dependencies/node_modules/playwright/index.mjs';
import {analyze,trace,insertionConfiguration} from './reference-oracle.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),read=p=>fs.readFileSync(p),parse=p=>JSON.parse(read(p).toString('utf8').replace(/^\uFEFF/,''));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),pin=p=>{const b=read(p),s=fs.statSync(p,{bigint:true});return {bytes:b.length,sha256:hash(b),mtime_ns:s.mtimeNs.toString()};};
const admission=parse(path.join(root,'CANDIDATE-ADMISSION.json')),freeze=parse(path.join(root,'ORIGINAL-FREEZE.json')),inputs=parse(path.join(root,'ADMISSION-INPUT.json'));
const literals=parse(path.join(root,'LITERAL-GOLD.json')),answers=parse(path.join(root,'COURSE-ANSWERS.json')),portable=admission.package.portableRoot;
const expectPin=(p,s)=>assert.deepEqual(pin(p),{bytes:s.bytes,sha256:s.sha256,mtime_ns:s.mtime_ns},p);
function provenance(){
 for(const s of admission.files)expectPin(path.join(root,'candidate',s.path),s.receiver);
 for(const s of freeze.source)expectPin(path.join(root,'original',s.path),s.receiver);
 for(const s of admission.package.members)expectPin(path.join(portable,s.path),s);
 for(const s of freeze.artifacts)expectPin(path.join(root,s.path),s);
 for(const s of freeze.donor.files)expectPin(path.join(freeze.donor.root,s.path),s);
 expectPin(freeze.node.path,freeze.node);expectPin(freeze.edge.path,freeze.edge);expectPin(admission.package.path,admission.package.received);
 return {candidateFiles:admission.files.length,originalFiles:freeze.source.length,portableFiles:admission.package.members.length,preCandidateArtifacts:freeze.artifacts.length,donorFiles:freeze.donor.files.length,node:true,edge:true,zip:true};
}
const receipt={schema:'recall253-root-candidate-browser-v1',started:new Date().toISOString(),pid:process.pid,parent:process.ppid,source_commit:admission.source_commit,package:admission.package.received,status:'running',groups:[],requests:[],externalRequests:[],pageErrors:[],consoleErrors:[],storageCalls:[],downloadEvents:[],downloads:[],browserProcesses:[],captures:[],authoredTestsOrResultsRead:false};
let browser,context,page,downloadedLesson;
function checkpoint(){fs.writeFileSync(path.join(root,'CANDIDATE-BROWSER-r1-PROGRESS.json'),JSON.stringify(receipt,null,2)+'\n');}
async function group(name,fn){const g={name,start:new Date().toISOString()};receipt.groups.push(g);try{g.result=await fn();g.status='passed';}catch(e){g.status='failed';g.error=String(e.stack||e);throw e;}finally{g.end=new Date().toISOString();checkpoint();}}
const text=id=>page.locator(id).textContent();
const fields=async()=>({wires:await page.locator('#wires').inputValue(),values:await page.locator('#values').inputValue(),comparators:await page.locator('#comparators').inputValue()});
async function retired(){assert.equal(await page.locator('#results').isHidden(),true);assert.equal(await page.locator('#download-config').isDisabled(),true);assert.equal(await page.locator('#download-observation').isDisabled(),true);assert.equal(await page.locator('#download-course').isEnabled(),true);}
async function fill(c){await page.locator('#wires').fill(String(c.wires));await page.locator('#values').fill(c.values.join(' '));await page.locator('#comparators').fill(c.comparators.map(x=>x.join(' ')).join('\n'));}
async function binary(c){
 const expected=analyze(c),rows=await page.locator('#binary-table tbody tr').evaluateAll(rows=>rows.map(r=>[...r.cells].map(x=>x.textContent)));
 assert.deepEqual(rows,expected.binary.cases.map(x=>[String(x.ordinal),x.input.join(' '),x.output.join(' '),(x.sorted?'Sorted':'Unsorted · wires '+x.firstInversion.join('–')),'Trace']));
 assert.equal(await text('#binary-summary'),expected.binary.passed+' sorted · '+expected.binary.failed+' unsorted · '+expected.binary.total+' complete cases, in lexicographic order.');
 assert.equal(await text('#verdict'),expected.binary.sortsAll?'All '+expected.binary.total+' binary inputs sort.':expected.binary.failed+' of '+expected.binary.total+' binary inputs fail.');
 return {rows,summary:await text('#binary-summary'),verdict:await text('#verdict'),failingOrdinals:expected.binary.failingOrdinals};
}
async function checkTrace(c,source=c.values,ordinal=null){
 const expected=trace(c,source),rows=await page.locator('#trace-table tbody tr').evaluateAll(rows=>rows.map(r=>[...r.cells].map(x=>x.textContent)));
 assert.deepEqual(rows,[[0,'—',...source,'Initial'],...expected.steps.map(s=>[s.index,s.pair.join('–'),...s.after,s.swapped?'Swap':'Unchanged'])].map(r=>r.map(String)));
 const sourceLabel=ordinal===null?'Authored input: '+source.join(' '):'Binary case '+ordinal+': '+source.join(' ')+(expected.sorted?' — sorted output.':' — counterexample.');
 assert.equal(await text('#trace-source'),sourceLabel);
 const steps=[];
 for(let i=0;i<=c.comparators.length;i++){
  if(i)await page.locator('#next').click();
  const vector=i===0?source:expected.steps[i-1].after,summary=i===0?'Step 0 · before any comparison':'Step '+i+' · compare wires '+expected.steps[i-1].pair.join(' and ')+' · '+(expected.steps[i-1].swapped?'swap':'unchanged');
  assert.equal(await text('#current-values'),vector.map((v,k)=>'W'+(k+1)+': '+v).join('   '));assert.equal(await text('#step-summary'),summary);
  assert.equal(await page.locator('#previous').isDisabled(),i===0);assert.equal(await page.locator('#next').isDisabled(),i===c.comparators.length);
  assert.equal(await page.locator('#trace-table tbody tr.active td').first().textContent(),String(i));
  steps.push({index:i,vector,summary});
 }
 return {sourceLabel,rows,steps};
}
async function download(selector,name,expected){
 const pending=page.waitForEvent('download');await page.locator(selector).click();const d=await pending,destination=path.join(root,'downloads',name);
 assert.equal(fs.existsSync(destination),false);await d.saveAs(destination);assert.equal(await d.failure(),null);
 const b=read(destination);if(expected!==undefined)assert.deepEqual(b,Buffer.isBuffer(expected)?expected:Buffer.from(expected,'utf8'));
 const r={selector,suggestedFilename:d.suggestedFilename(),path:destination,...pin(destination)};receipt.downloads.push(r);return {...r,bytesContent:b};
}
try{
 receipt.provenanceBefore=provenance();
 browser=await chromium.launch({executablePath:inputs.edge,headless:true,chromiumSandbox:true,timeout:45000});receipt.browserVersion=browser.version();
 context=await browser.newContext({viewport:{width:1360,height:900},acceptDownloads:true,serviceWorkers:'block'});
 await context.setOffline(true);
 await context.exposeBinding('__rootStorageObservation',(_,entry)=>receipt.storageCalls.push(entry));
 await context.addInitScript(()=>{
  for(const method of ['setItem','removeItem','clear']){const original=Storage.prototype[method];Storage.prototype[method]=function(...args){window.__rootStorageObservation({method,origin:location.href,args:args.map(String)});return original.apply(this,args);};}
  const originalOpen=IDBFactory.prototype.open;IDBFactory.prototype.open=function(...args){window.__rootStorageObservation({method:'indexedDB.open',origin:location.href,args:args.map(String)});return originalOpen.apply(this,args);};
 });
 context.on('request',r=>{receipt.requests.push(r.url());if(!/^(file|data|blob):/.test(r.url()))receipt.externalRequests.push(r.url());});
 context.on('page',p=>{p.on('pageerror',e=>receipt.pageErrors.push(String(e)));p.on('console',m=>{if(m.type()==='error')receipt.consoleErrors.push(m.text());});p.on('download',d=>receipt.downloadEvents.push({at:new Date().toISOString(),url:d.url(),filename:d.suggestedFilename()}));});
 page=await context.newPage();page.setDefaultTimeout(12000);
 const cdp=await browser.newBrowserCDPSession();receipt.browserProcesses=(await cdp.send('SystemInfo.getProcessInfo')).processInfo;await cdp.detach();
 await group('packaged direct file, explicit Run, complete default table and keyboard step navigation',async()=>{
  await page.goto(pathToFileURL(path.join(portable,'courses/sorting-networks-explorer.html')).href,{waitUntil:'load'});await retired();
  const c=literals.find(x=>x.name==='public-four').configuration;assert.deepEqual(await fields(),{wires:'4',values:'4 1 3 2',comparators:'1 2\n3 4\n1 3\n2 4\n2 3'});
  await page.locator('#run').click();assert.equal(await page.locator('#results').isVisible(),true);
  const table=await binary(c),authored=await checkTrace(c);await page.locator('#previous').focus();await page.keyboard.press('Enter');
  assert.ok((await text('#step-summary')).startsWith('Step 4 ·'));await page.locator('#next').click();assert.equal(await page.locator('#next').isDisabled(),true);
  return {title:await page.title(),url:page.url(),initialRetired:true,table,authored,keyboardPreviousStep:4};
 });
 await group('pending preset selection, broken network witnesses, trace isolation and exact actual downloads',async()=>{
  const before=await fields(),beforeResult=await page.locator('#results').innerHTML();await page.locator('#preset').selectOption('2');
  assert.deepEqual(await fields(),before);assert.equal(await page.locator('#results').innerHTML(),beforeResult);assert.equal(await page.locator('#download-config').isEnabled(),true);
  await page.locator('#load-preset').click();await retired();const c=literals.find(x=>x.name==='public-broken').configuration;
  await page.locator('#run').click();const table=await binary(c),authored=await checkTrace(c),draft=await fields(),expected=analyze(c);
  await page.getByRole('button',{name:'Trace binary case 5',exact:true}).click();const witness=await checkTrace(c,[0,1,0,1],5);assert.deepEqual(await fields(),draft);
  const config=await download('#download-config','candidate-broken-configuration.json',JSON.stringify(c,null,2)+'\n');
  const observation=await download('#download-observation','candidate-broken-observation.json',JSON.stringify(expected,null,2)+'\n');
  assert.deepEqual(JSON.parse(observation.bytesContent),expected);assert.deepEqual(JSON.parse(config.bytesContent),c);
  await page.locator('#authored').click();assert.equal(await text('#trace-source'),'Authored input: 2 4 1 3');assert.equal(await text('#step-summary'),'Step 0 · before any comparison');
  return {pendingSelectionPreservesAccepted:true,applyRetires:true,table,authored,witness,draftUnaffected:true,downloadJSONFullExact:true};
 });
 await group('each field retires, invalid drafts refuse, fixed course stays exact, complete three-wire preset',async()=>{
  const refusals=[];
  for(const [selector,value] of [['#wires','3'],['#values','2 4 1 1000'],['#comparators','2 1']]){
   await page.locator('#load-preset').click();await page.locator('#run').click();assert.equal(await page.locator('#results').isVisible(),true);
   await page.locator(selector).fill(value);await retired();await page.locator('#run').click();await retired();
   assert.equal(await page.locator('#status.error').count(),1);const error=await text('#status');assert.ok(error.length>0);refusals.push({selector,value,error});
  }
  const lesson=await download('#download-course','candidate-sorting-networks.json',read(path.join(portable,'courses/sorting-networks.json')));downloadedLesson=lesson.path;
  assert.equal(lesson.sha256,'d214e628bd4ad1f6a4e155498c0f8d46e01af83d63ae180db8f49b7cf1dd4e1e');
  await page.locator('#preset').selectOption('0');await page.locator('#load-preset').click();await retired();await page.locator('#run').click();
  const c=literals.find(x=>x.name==='public-three').configuration;return {refusals,courseAvailableWhileInvalid:true,courseDownloadSHA:lesson.sha256,threeWireTable:await binary(c),threeWireTrace:await checkTrace(c)};
 });
 await group('six-wire exhaustive tables, thirty-step trace and responsive physical browser viewports',async()=>{
  const insertion=insertionConfiguration(6);await fill(insertion);await retired();await page.locator('#run').click();
  const insertionTable=await binary(insertion),insertionTrace=await checkTrace(insertion);
  await download('#download-observation','candidate-six-insertion-observation.json',JSON.stringify(analyze(insertion),null,2)+'\n');
  const long={wires:6,values:[999,5,0,0,-5,-999],comparators:Array.from({length:30},()=>[1,6])};
  await fill(long);await retired();await page.locator('#run').click();const longTable=await binary(long),longTrace=await checkTrace(long);
  await download('#download-observation','candidate-six-thirty-observation.json',JSON.stringify(analyze(long),null,2)+'\n');
  const layouts=[];
  for(const viewport of [{width:1360,height:900},{width:390,height:844}]){
   await page.setViewportSize(viewport);await page.evaluate(()=>scrollTo(0,0));
   const bounds=await page.evaluate(()=>({innerWidth,innerHeight,documentWidth:document.documentElement.scrollWidth,controls:[...document.querySelectorAll('#preset,#load-preset,#wires,#values,#comparators,#run,#download-config,#download-observation,#authored,#previous,#next,#download-course,#learner-link')].map(e=>{const r=e.getBoundingClientRect();return {id:e.id,x:r.x,y:r.y,width:r.width,height:r.height};}),scrollers:[...document.querySelectorAll('.scroller')].map(e=>{const r=e.getBoundingClientRect();return {label:e.getAttribute('aria-label'),width:r.width,x:r.x,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth};})}));
   assert.ok(bounds.documentWidth<=viewport.width);
   for(const b of bounds.controls){assert.ok(b.width>0&&b.height>0);assert.ok(b.x>=-1&&b.x+b.width<=viewport.width+1,JSON.stringify(b));}
   for(const b of bounds.scrollers)assert.ok(b.x>=-1&&b.x+b.width<=viewport.width+1,JSON.stringify(b));
   const editorName='candidate-editor-'+viewport.width+'x'+viewport.height+'.png';await page.screenshot({path:path.join(root,editorName)});receipt.captures.push({path:editorName,...pin(path.join(root,editorName)),viewport,bounds});
   await page.locator('#trace-title').scrollIntoViewIfNeeded();await page.locator('#diagram').focus();const scrollBefore=await page.locator('#diagram').evaluate(e=>e.scrollLeft);
   await page.keyboard.press('ArrowRight');await page.waitForFunction(before=>document.querySelector('#diagram').scrollLeft>before,scrollBefore);
   const diagramScroll=await page.locator('#diagram').evaluate(e=>({left:e.scrollLeft,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth}));assert.ok(diagramScroll.scrollWidth>diagramScroll.clientWidth);
   const traceName='candidate-trace-'+viewport.width+'x'+viewport.height+'.png';await page.screenshot({path:path.join(root,traceName)});receipt.captures.push({path:traceName,...pin(path.join(root,traceName)),viewport,diagramScroll});
   layouts.push({viewport,bounds,keyboardDiagramScroll:{before:scrollBefore,...diagramScroll}});
  }
  await page.setViewportSize({width:1360,height:900});
  return {insertionTable,insertionTrace,longTable,longTrace,layouts,allFullObservationsDownloaded:true};
 });
 let firstSummary,firstAnswers,firstMastery,answered,wrongId,reviewBefore;
 const note='Independent threshold note: min and max commute with a nondecreasing zero-one map.',application='A failed output pair yields a binary witness for the same fixed comparator sequence.';
 function reviewSnapshot(){return page.locator('.review-item').evaluateAll(rows=>rows.map(e=>({prompt:e.querySelector('.review-prompt').textContent,status:e.querySelector('.review-status').textContent,answers:[...e.querySelectorAll('.review-answers dd')].map(x=>x.textContent),fullAnswerText:e.querySelector('.review-answers').textContent,explanation:e.querySelector('.review-body > p').textContent})));}
 await group('actual packaged learner link and twelve-course first answers, review, reflection and retry',async()=>{
  await page.locator('#learner-link').click();await page.locator('#start-button').waitFor();assert.equal(page.url(),pathToFileURL(path.join(portable,'demo.html')).href);
  const course=parse(downloadedLesson);assert.equal(course.items.length,12);assert.deepEqual(course.items.map(x=>({id:x.id,answer:x.answer})),answers.map(x=>({id:x.id,answer:x.answer})));
  const before=await page.locator('#session-content').innerHTML();await page.locator('#deck-file').setInputFiles(downloadedLesson);await page.locator('#start-deck').waitFor();
  assert.equal(await text('#deck-preview-title'),course.title);assert.equal(await page.locator('#session-content').innerHTML(),before);
  await page.locator('#start-deck').click();assert.equal(await text('#step-count'),'0 / 12');assert.equal(await text('#lesson-description'),course.title);
  answered=[];
  for(let i=0;i<12;i++){
   const prompt=await text('#session-content h2'),item=course.items.find(x=>x.prompt===prompt);assert.ok(item);assert.equal(answered.some(x=>x.id===item.id),false);
   const frozen=answers.find(x=>x.id===item.id).answer,choice=i===0?(frozen+1)%item.options.length:frozen;if(i===0)wrongId=item.id;
   await page.locator('[data-choice="'+choice+'"]').click();await page.locator('#next-button').waitFor();const feedback=await text('#feedback-slot');
   for(const wanted of [item.options[choice],item.options[frozen],item.explanation,item.transfer])assert.ok(feedback.includes(wanted),item.id+' feedback '+wanted);
   answered.push({id:item.id,prompt,choice,correct:choice===frozen,correctIndex:frozen,feedback});await page.locator('#next-button').click();
  }
  await page.locator('#first-try-summary').waitFor();firstSummary=await text('#first-try-summary');assert.ok(firstSummary.includes('11 of 12'));
  reviewBefore=await reviewSnapshot();assert.equal(reviewBefore.length,12);
  for(let i=0;i<12;i++){const a=answered[i],item=course.items.find(x=>x.id===a.id),r=reviewBefore[i];assert.equal(r.prompt,item.prompt);assert.deepEqual(r.answers,[item.options[a.choice],item.options[a.correctIndex]]);assert.equal(r.status,(a.correct?'Correct':'Needs review')+' · first try');assert.equal(r.explanation,item.explanation);assert.ok(r.fullAnswerText.length>0);}
  firstAnswers=await page.locator('.review-answers').allTextContents();assert.ok(firstAnswers.every(x=>x.length>0));firstMastery=await page.locator('.mastery-box output').allInnerTexts();assert.ok(firstMastery.length>0&&firstMastery.every(x=>x.length>0));
  await page.locator('.review-item').first().locator('summary').click();await page.locator('[data-reflection-item]').first().fill(note);await page.locator('#application-reflection').fill(application);
  await page.locator('#practice-button').click();const missed=course.items.find(x=>x.id===wrongId);assert.equal(await text('#session-content h2'),missed.prompt);
  await page.locator('[data-practice-choice="'+answers.find(x=>x.id===wrongId).answer+'"]').click();await page.locator('#practice-next').click();await page.locator('#first-try-summary').waitFor();
  assert.equal(await text('#first-try-summary'),firstSummary);assert.deepEqual(await page.locator('.review-answers').allTextContents(),firstAnswers);assert.deepEqual(await reviewSnapshot(),reviewBefore);assert.deepEqual(await page.locator('.mastery-box output').allInnerTexts(),firstMastery);
  assert.equal(await page.locator('[data-reflection-item]').first().inputValue(),note);assert.equal(await page.locator('#application-reflection').inputValue(),application);assert.equal(await text('#practice-status'),'You answered 1 of 1 correctly on retry.');
  return {courseSHA:pin(downloadedLesson).sha256,previewPreservedSession:true,answered,firstSummary,reviewBefore,firstAnswers,firstMastery,wrongId,practiceCorrect:true,firstAnswersAndMasteryPreserved:true,reflectionsPreserved:true};
 });
 await group('actual complete lesson notes preserve choices and observations remain offline',async()=>{
  const d=await download('#save-notes-button','candidate-study-notes.txt'),notes=d.bytesContent.toString('utf8'),course=parse(downloadedLesson);
  for(const wanted of [course.title,'11 of 12 connections correct on the first try.','Complete: 1 of 1 practice answers recorded; 1 correct on retry.',note,application,course.attribution,course.license])assert.ok(notes.includes(wanted),wanted);
  const noteRows=[];
  for(let i=0;i<answered.length;i++){
   const a=answered[i],item=course.items.find(x=>x.id===a.id),start=notes.indexOf('\n'+(i+1)+'. '+item.prompt+'\n'),end=i+1<answered.length?notes.indexOf('\n'+(i+2)+'. '+answered[i+1].prompt+'\n'):notes.indexOf('\nYOUR APPLICATION REFLECTION');
   assert.ok(start>=0&&end>start);const segment=notes.slice(start,end);
   for(const wanted of ['Your first answer: '+item.options[a.choice],'First try: '+(a.correct?'correct':'needs review'),'Correct answer: '+item.options[a.correctIndex],'Explanation: '+item.explanation,'Apply the idea: '+item.transfer])assert.ok(segment.includes(wanted),item.id+' '+wanted);
   if(item.id===wrongId){assert.ok(segment.includes('Practice answer: '+item.options[a.correctIndex]));assert.ok(segment.includes('Practice result: correct on retry'));}
   noteRows.push({id:item.id,firstChoice:a.choice,firstCorrect:a.correct,practice:item.id===wrongId,segment});
  }
  for(const estimate of firstMastery)assert.ok(notes.includes(estimate),estimate);
  const storage=await page.evaluate(()=>({local:localStorage.length,session:sessionStorage.length}));assert.deepEqual(storage,{local:0,session:0});
  assert.deepEqual(receipt.storageCalls,[]);assert.deepEqual(receipt.externalRequests,[]);assert.deepEqual(receipt.pageErrors,[]);assert.equal(receipt.downloadEvents.length,6);assert.equal(receipt.downloads.length,6);
  return {path:d.path,sha256:d.sha256,bytes:d.bytes,noteRows,notes,storage,storageCalls:[],externalRequests:[],pageErrors:[],explicitDownloads:receipt.downloads.length};
 });
 const finalCdp=await browser.newBrowserCDPSession();receipt.browserProcessesFinal=(await finalCdp.send('SystemInfo.getProcessInfo')).processInfo;await finalCdp.detach();receipt.status='passed';
}catch(e){receipt.status='failed';receipt.error=String(e.stack||e);process.exitCode=1;if(page)try{const name='candidate-browser-r1-failure.png';await page.screenshot({path:path.join(root,name)});receipt.captures.push({path:name,...pin(path.join(root,name)),failure:true});}catch(captureError){receipt.failureCaptureError=String(captureError);}}
finally{
 if(context)await context.close().catch(e=>{receipt.contextCloseError=String(e);receipt.status='failed';process.exitCode=1;});
 if(browser)await browser.close().then(()=>receipt.browserClosed=true).catch(e=>{receipt.browserCloseError=String(e);receipt.status='failed';process.exitCode=1;});
 try{receipt.provenanceAfter=provenance();receipt.sourceAndRuntimeUnchanged=true;}catch(e){receipt.provenanceError=String(e.stack||e);receipt.status='failed';process.exitCode=1;}
 receipt.finished=new Date().toISOString();fs.writeFileSync(path.join(root,'CANDIDATE-BROWSER-r1.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({status:receipt.status,pid:process.pid,groups:receipt.groups.map(g=>({name:g.name,status:g.status})),browserClosed:receipt.browserClosed,sourceAndRuntimeUnchanged:receipt.sourceAndRuntimeUnchanged,error:receipt.error}));
}
