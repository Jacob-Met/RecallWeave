Independent course receiving supplemental evidence.

The blind/ files were frozen before candidate answers/feedback and are copied verbatim from the readback-verified shared blind archive. content/ includes the exact executed runner, raw process output and source-pinned input. The runner imports the inherited validator and timing/graph modules copied from that input; run `node content/receive.mjs` from the unpacked packet to reproduce its bounded checks. That would be a new execution; this archive claims only the recorded one. The native parsed schema is separate from the independent blind-key checker and pre-key path oracle.

receiver-syntax-negative/ contains the exact first driver and raw process exit1. Node failed module parsing before Chromium launch. The successor adds one missing parenthesis and its node --check passed before the first actual browser. The successful browser and all three actual/expected study-note downloads are in the separate browser archive. No product source was changed by receiving; no hosted Actions or remote records were invoked.

The old fc4 deck explanation is retained in content/input.json as sources.initial. Only the arithmetic explanation clause changed in 49a; all prompts/options/keys/transfers remain exact.
