#!/usr/bin/env node
// Counting author browser receiver. CDP lifecycle follows the previously received
// Euclid/SQL private-profile route; this file runs only authored counting and
// actual-file learner handoff controls, with no HTTP server.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import {readFile,writeFile,mkdir,mkdtemp,rm,rename,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
const carrier='/home/jacob/snap/chromium/common/optimizer-counting-principles-3dab-20261008';
const root=join(carrier,'source-v1'),output=join(carrier,'receiving/browser-learner-v2');
const executable='/snap/bin/chromium';
const sha=b=>createHash('sha256').update(b).digest('hex');
const git=b=>createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const manifestBytes=await readFile(join(carrier,'receiving/browser-source-v1-pins.json'));
assert.equal(sha(manifestBytes),'259201272faad03d8ad316848ad7c95cb092f5963b3263f6f40d994c08474a15');
const manifest=JSON.parse(manifestBytes);
await mkdir(output);
const downloadPath=join(output,'downloads');await mkdir(downloadPath);
const profile=await mkdtemp(join(output,'profile-'));
const report={started:new Date().toISOString(),status:'running',node:process.version,platform:process.platform,root,output,executable,manifest:sha(manifestBytes),checks:[],pages:[],screenshots:[],downloads:[],pageErrors:[],requests:[],blocked:[]};
async function guards(){
 const result={};
 for(const [name,pin]of Object.entries(manifest.files)){
  const b=await readFile(join(root,name)),actual={bytes:b.length,sha256:sha(b),git_blob:git(b)};
  assert.deepEqual(actual,pin,name);result[name]=actual;
 }
 async function walk(dir,prefix=''){const paths=[];for(const e of await readdir(dir,{withFileTypes:true})){const n=prefix+e.name;if(e.isDirectory())paths.push(...await walk(join(dir,e.name),n+'/'));else{assert.ok(e.isFile());paths.push(n);}}return paths;}
 assert.deepEqual((await walk(root)).sort(),Object.keys(result).sort());return result;
}
report.before=await guards();
const {countingPage}=await import(pathToFileURL(join(root,'src/counting-principles.mjs')));
const courseBytes=await readFile(join(root,'courses/counting-principles.json')),course=JSON.parse(courseBytes);
const pending=new Map(),downloads=new Map();let browser,socket,sessionId,sequence=0,stderr='';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitFor(fn,label){let last;for(let i=0;i<160;i++){try{if(await fn())return;}catch(e){last=e;}await sleep(75);}throw Error('Timed out '+label+(last?': '+last.message:''));}
function cmd(method,params={},scoped=true){const id=++sequence;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));});}
async function evaluate(expression){const r=await cmd('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value;}
async function key(name){const codes={Enter:13,Tab:9,Backspace:8,Space:32,Escape:27};for(const type of ['keyDown','keyUp'])await cmd('Input.dispatchKeyEvent',{type,key:name==='Space'?' ':name,code:name,windowsVirtualKeyCode:codes[name],nativeVirtualKeyCode:codes[name],...(name==='Enter'&&type==='keyDown'?{text:'\r',unmodifiedText:'\r'}:{})});}
async function focus(selector){assert.ok(await evaluate('!!document.querySelector('+JSON.stringify(selector)+')'),'Missing '+selector);await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');assert.ok(await evaluate('document.activeElement.matches('+JSON.stringify(selector)+')'));}
async function activate(selector){await focus(selector);await key('Enter');}
async function fill(selector,text){await evaluate('(()=>{const e=document.querySelector('+JSON.stringify(selector)+');e.focus();e.select();})()');await key('Backspace');if(text)await cmd('Input.insertText',{text});assert.equal(await evaluate('document.querySelector('+JSON.stringify(selector)+').value'),text);}
async function radio(name,value){const selector='input[name='+name+'][value='+value+']';if(!await evaluate('document.querySelector('+JSON.stringify(selector)+').checked')){await focus(selector);await key('Space');}assert.equal(await evaluate('document.querySelector('+JSON.stringify(selector)+').checked'),true);}
async function navigate(file,width=1280,height=1000,ready='#count-form'){const url=pathToFileURL(join(root,file)).href;await cmd('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});await cmd('Page.navigate',{url});await waitFor(()=>evaluate('document.URL === '+JSON.stringify(url)+' && document.readyState==="complete" && !!document.querySelector('+JSON.stringify(ready)+')'),'navigate '+file);}
async function screenshot(name,selector){if(selector)await evaluate('document.querySelector('+JSON.stringify(selector)+').scrollIntoView({block:"start"})');const {data}=await cmd('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const b=Buffer.from(data,'base64');await writeFile(join(output,name),b);report.screenshots.push({name,bytes:b.length,sha256:sha(b)});}
async function download(selector,name){const old=new Set(downloads.keys());await activate(selector);let d;await waitFor(()=>{d=[...downloads.values()].find(x=>!old.has(x.guid)&&x.state==='completed');return !!d;},'download '+name);const from=join(downloadPath,d.guid),to=join(downloadPath,name),bytes=await readFile(from);await rename(from,to);report.downloads.push({name,suggestedFilename:d.suggestedFilename,bytes:bytes.length,sha256:sha(bytes),guid:d.guid});return {path:to,bytes,suggestedFilename:d.suggestedFilename};}
function passed(label){report.checks.push(label);console.log('PASS '+label);}
async function assertPage(input,index=0n){
 const expected=countingPage(input,index);
 const actual=await evaluate("({hidden:document.querySelector('#results').hidden,data:{...document.querySelector('#results').dataset},title:document.querySelector('#result-title').textContent,model:document.querySelector('#model-tag').textContent,formula:['formula-rule','formula-calculation','formula-reason'].map(id=>document.getElementById(id).textContent),counts:[...document.querySelectorAll('[data-count]')].map(e=>({id:e.dataset.count,total:e.dataset.total,selected:e.classList.contains('selected')})),rows:[...document.querySelectorAll('.outcome')].map(e=>({ordinal:e.dataset.ordinal,labels:[...e.querySelectorAll('.token')].map(x=>x.textContent),orderedRepresentations:e.dataset.orderedRepresentations,visible:e.querySelector('.representations').textContent,empty:e.querySelector('.outcome-tokens').textContent})),impossible:!document.querySelector('#impossible-message').hidden,page:document.querySelector('#page-number').value,pageTotal:document.querySelector('#page-total').textContent,buttons:['first-page','previous-page','next-page','last-page'].map(id=>document.getElementById(id).disabled),downloadDisabled:document.querySelector('#download-page').disabled})");
 assert.equal(actual.hidden,false);assert.deepEqual(actual.data,{model:input.model,n:String(input.n),k:String(input.k),total:expected.total,page:expected.page});
 assert.equal(actual.title,BigInt(expected.total).toLocaleString('en-US')+(expected.total==='1'?' outcome':' outcomes'));
 assert.equal(actual.model,expected.model);assert.deepEqual(actual.formula,[expected.formula.rule,expected.formula.calculation,expected.formula.reason]);
 assert.deepEqual(actual.counts.map(({id,total})=>({id,total})).sort((a,b)=>a.id.localeCompare(b.id)),expected.comparison.map(({id,total})=>({id,total})).sort((a,b)=>a.id.localeCompare(b.id)));
 assert.deepEqual(actual.counts.filter(x=>x.selected).map(x=>x.id),[input.model]);
 assert.deepEqual(actual.rows.map(({ordinal,labels,orderedRepresentations})=>({ordinal,labels,orderedRepresentations})),expected.rows.map(({ordinal,labels,orderedRepresentations})=>({ordinal,labels,orderedRepresentations})));
 actual.rows.forEach((r,i)=>{assert.equal(r.visible,expected.ordered?'One distinct ordered outcome':BigInt(r.orderedRepresentations).toLocaleString('en-US')+(r.orderedRepresentations==='1'?' ordered representation':' ordered representations'));if(!expected.rows[i].labels.length)assert.equal(r.empty,'Empty selection');});
 assert.equal(actual.impossible,expected.impossible);assert.equal(actual.page,expected.page);assert.equal(actual.pageTotal,'of '+BigInt(expected.pageCount).toLocaleString('en-US'));assert.deepEqual(actual.buttons,[index===0n,index===0n,expected.page===expected.pageCount,expected.page===expected.pageCount]);assert.equal(actual.downloadDisabled,false);
 report.pages.push({input,index:String(index),expected,actual});return expected;
}
async function retired(){assert.deepEqual(await evaluate("({hidden:document.querySelector('#results').hidden,data:{...document.querySelector('#results').dataset},disabled:document.querySelector('#download-page').disabled})"),{hidden:true,data:{},disabled:true});}
async function apply(n,k,model){await fill('#n',String(n));await fill('#k',String(k));const [order,reuse]=model.split('-');await radio('order',order);await radio('reuse',reuse);await retired();await activate('.count-button');return assertPage({n,k,model});}
async function geometry(){return evaluate("(()=>{const ids=['n','k','count-form'];const r={viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,bodyWidth:document.body.scrollWidth,items:{}};for(const id of ids){const e=document.getElementById(id),b=e.getBoundingClientRect();r.items[id]={left:b.left,right:b.right,width:b.width,scroll:e.scrollWidth,client:e.clientWidth};}return r;})()");}
function layoutFits(g){assert.ok(g.documentWidth<=g.viewport+1,'Document exceeds viewport '+JSON.stringify(g));const f=g.items['count-form'];for(const id of ['n','k']){const r=g.items[id];assert.ok(r.left>=f.left-1&&r.right<=f.right+1,id+' exceeds its form '+JSON.stringify(g));}}
function exited(ms){if(!browser||browser.exitCode!==null||browser.signalCode!==null)return Promise.resolve(true);return new Promise(resolve=>{const done=()=>{clearTimeout(timer);browser.off('exit',done);resolve(true);};const timer=setTimeout(()=>{browser.off('exit',done);resolve(false);},ms);browser.once('exit',done);});}
try{
 browser=spawn(executable,['--headless=new','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--password-store=basic','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1, EXCLUDE localhost','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
 browser.stderr.on('data',b=>{stderr+=b.toString();});
 const endpoint=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Browser startup timeout')),45000);browser.once('error',e=>{clearTimeout(timer);reject(e);});browser.once('exit',c=>{clearTimeout(timer);reject(Error('Browser exited '+c));});browser.stderr.on('data',()=>{const m=stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});});
 socket=new WebSocket(endpoint);socket.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}else if(m.method.startsWith('Browser.download')){const d=m.params;downloads.set(d.guid,{...downloads.get(d.guid),...d});}else if(m.method==='Runtime.exceptionThrown')report.pageErrors.push(m.params);else if(m.method==='Network.requestWillBeSent')report.requests.push(m.params.request.url);else if(m.method==='Fetch.requestPaused'){report.blocked.push(m.params.request.url);cmd('Fetch.failRequest',{requestId:m.params.requestId,errorReason:'BlockedByClient'}).catch(e=>report.pageErrors.push(e.message));}});
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 report.browser=await cmd('Browser.getVersion',{},false);await cmd('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath,eventsEnabled:true},false);
 const {targetId}=await cmd('Target.createTarget',{url:'about:blank'},false);({sessionId}=await cmd('Target.attachToTarget',{targetId,flatten:true},false));
 for(const method of ['Page.enable','Runtime.enable','Network.enable','DOM.enable'])await cmd(method);
 await cmd('Network.setCacheDisabled',{cacheDisabled:true});await cmd('Network.setBypassServiceWorker',{bypass:true});await cmd('Fetch.enable',{patterns:[{urlPattern:'http://*'},{urlPattern:'https://*'}]});
 const priorBytes=await readFile(join(carrier,'receiving/browser-v1/browser-report.json'));
 assert.equal(sha(priorBytes),'848c50f365fff09632d98ba7b364bc9c15f38fd308841558e9f10bc43673bccc');
 const prior=JSON.parse(priorBytes);assert.equal(prior.status,'failed');assert.equal(prior.checks.length,7);assert.ok(prior.error.includes('12 short challenges'));assert.deepEqual(prior.before,report.before);assert.deepEqual(prior.after,report.before);
 report.continuation={priorReport:sha(priorBytes),retainedPassedGroups:prior.checks,fixtureCorrection:'Current imported-deck label is 12 challenges; original 12 short challenges assertion and failed receipt remain immutable.',boundary:'Only actual downloaded-file learner tail and source/cleanup controls run here.'};
 const courseDownload={path:join(carrier,'receiving/browser-v1/downloads/downloaded-counting-principles.json')};
 assert.deepEqual(await readFile(courseDownload.path),courseBytes);
 await navigate('demo.html',390,844,'#deck-file');
 const before=await evaluate("({progress:document.querySelector('#step-count').textContent,size:document.querySelector('#lesson-size').textContent,html:document.querySelector('#session-content').innerHTML})");assert.equal(before.progress,'0 / 6');
 const {root:doc}=await cmd('DOM.getDocument');const {nodeId}=await cmd('DOM.querySelector',{nodeId:doc.nodeId,selector:'#deck-file'});await cmd('DOM.setFileInputFiles',{nodeId,files:[courseDownload.path]});
 await waitFor(()=>evaluate("!document.querySelector('#deck-preview').hidden && !!document.querySelector('#start-deck')"),'downloaded course preview');
 report.learnerPreview=await evaluate("({title:document.querySelector('#deck-preview-title').textContent,count:document.querySelector('.deck-preview-count').textContent,prompts:[...document.querySelectorAll('.deck-questions li strong')].map(x=>x.textContent),progress:document.querySelector('#step-count').textContent,size:document.querySelector('#lesson-size').textContent,html:document.querySelector('#session-content').innerHTML})");
 assert.equal(report.learnerPreview.title,course.title);assert.deepEqual(report.learnerPreview.prompts,course.items.map(x=>x.prompt));assert.match(report.learnerPreview.count,/12 questions · 4 concepts/);assert.equal(report.learnerPreview.progress,before.progress);assert.equal(report.learnerPreview.size,before.size);assert.equal(report.learnerPreview.html,before.html);
 await activate('#start-deck');await waitFor(()=>evaluate("!!document.querySelector('.question-card h2')"),'explicit lesson start');
 const prompt=await evaluate("document.querySelector('.question-card h2').textContent"),item=course.items.find(x=>x.prompt===prompt);assert.ok(item);assert.equal(await evaluate("document.querySelector('#lesson-size').textContent"),'12 challenges');
 await activate('.choice[data-choice="'+item.answer+'"]');await waitFor(()=>evaluate("!!document.querySelector('#feedback-slot .feedback')"),'ordinary lesson feedback');
 const feedback=await evaluate("document.querySelector('#feedback-slot .feedback').textContent");assert.ok(feedback.includes(item.explanation));report.learnerStart={item:item.id,prompt,feedback};
 await screenshot('counting-learner-phone.png','.question-card');passed('actual downloaded course previews all twelve prompts without replacing default session, then explicit Start and answer produce canonical feedback');
 assert.deepEqual(report.pageErrors,[]);assert.deepEqual(report.blocked,[]);assert.ok(report.requests.every(x=>x.startsWith('file:')||x.startsWith('blob:')));
 report.after=await guards();assert.deepEqual(report.after,report.before);passed('all ten input files remain exact and observed page requests remain offline without JavaScript exceptions');report.status='passed';
}catch(error){report.status='failed';report.error=error.stack??String(error);process.exitCode=1;console.error(report.error);if(sessionId)try{report.lastPage=await evaluate("({url:location.href,text:document.body.innerText.slice(0,15000),focus:document.activeElement.outerHTML})");await screenshot('failed-state.png');}catch{}}
finally{
 try{report.after=await guards();assert.deepEqual(report.after,report.before);}catch(e){report.guardError=e.stack;report.status='failed';process.exitCode=1;}
 if(socket?.readyState===WebSocket.OPEN)try{await cmd('Browser.close',{},false);}catch{}socket?.close();for(const p of pending.values())clearTimeout(p.timer);
 if(!await exited(5000)){browser.kill('SIGTERM');if(!await exited(5000)){browser.kill('SIGKILL');await exited(5000);}}
 try{assert.ok(!browser||browser.exitCode!==null||browser.signalCode!==null,'Owned browser exit not observed');await rm(profile,{recursive:true,force:true,maxRetries:5,retryDelay:150});report.cleanup={profile,pid:browser?.pid,exitCode:browser?.exitCode,signal:browser?.signalCode,removed:true};}catch(e){report.cleanup={profile,error:e.stack};report.status='failed';process.exitCode=1;}
 report.finished=new Date().toISOString();await writeFile(join(output,'browser-stderr.txt'),stderr);await writeFile(join(output,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
 console.log('COUNTING_BROWSER_'+(report.status==='passed'?'OK':'FAILED')+' checks='+report.checks.length+' failures='+(report.status==='passed'?0:1));
}
