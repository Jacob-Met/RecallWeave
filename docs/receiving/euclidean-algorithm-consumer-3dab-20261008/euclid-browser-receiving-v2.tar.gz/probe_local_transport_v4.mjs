import {spawn,spawnSync} from 'node:child_process';
import {createServer} from 'node:http';
import {mkdir,mkdtemp,writeFile,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const root='/Users/me/recallweave-euclid-receiving-3dab-20261008/evidence/local-transport-headed-v4';
await mkdir(root);const profile=await mkdtemp(join(root,'profile-'));
const report={node:process.version,requestLog:[],events:[],steps:[],flags:[],status:'running'};
const body='<title>Owned offline transport probe</title><h1 id="ready">Exact local transport</h1>';
const server=createServer((req,res)=>{report.requestLog.push(req.url);res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'}).end(body);});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
let child,socket,sid,n=0,log='';const pending=new Map();
const command=(method,params={},scope=sid)=>new Promise((resolve,reject)=>{const id=++n,timer=setTimeout(()=>{pending.delete(id);reject(new Error('CDP timeout '+method));},7000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...(scope?{sessionId:scope}:{})}));});
async function stop(){if(socket?.readyState===WebSocket.OPEN)try{await command('Browser.close',{},null);}catch{}socket?.close();for(const p of pending.values())clearTimeout(p.timer);if(child&&child.exitCode===null&&child.signalCode===null){child.kill('SIGKILL');await new Promise(r=>{const t=setTimeout(r,3000);child.once('exit',()=>{clearTimeout(t);r();});});}server.closeAllConnections();await new Promise(r=>server.close(r));if(!child||child.exitCode!==null||child.signalCode!==null){await rm(profile,{recursive:true,force:true,maxRetries:3,retryDelay:100});report.profileCleanup=true;}else report.profileCleanup={retained:profile,pid:child.pid};}
try{
 report.flags=['--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--password-store=basic','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'];
 child=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',report.flags,{stdio:['ignore','ignore','pipe']});
 const endpoint=await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('startup')),15000);child.stderr.on('data',b=>{log=(log+b).slice(-4000);const m=log.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);if(m){clearTimeout(t);resolve(m[1]);}});child.on('error',reject);});
 socket=new WebSocket(endpoint);
 socket.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}else{if(/Fetch|crash|detach|requestWillBeSent|loadingFailed/i.test(m.method))report.events.push(m);if(m.method==='Fetch.requestPaused')command('Fetch.continueRequest',{requestId:m.params.requestId},m.sessionId).catch(e=>report.events.push({continueError:e.message}));}});
 await new Promise((r,j)=>{socket.addEventListener('open',r,{once:true});socket.addEventListener('error',j,{once:true});});
 const {targetId}=await command('Target.createTarget',{url:'about:blank'},null);({sessionId:sid}=await command('Target.attachToTarget',{targetId,flatten:true},null));
 for(const x of ['Page.enable','Runtime.enable','Network.enable'])await command(x);
 report.version=await command('Browser.getVersion',{},null);
 await command('Page.bringToFront');
 for(const intercept of [false,true]){
  if(intercept)await command('Fetch.enable',{patterns:[{urlPattern:'http://*'},{urlPattern:'https://*'}]});
  const start=Date.now();let result;
  try{const nav=await command('Page.navigate',{url:base+'/?intercept='+intercept});const dom=await command('Runtime.evaluate',{expression:'document.body.innerText',returnByValue:true});result={intercept,nav,text:dom.result?.value,ms:Date.now()-start};if(dom.result?.value!=='Exact local transport')throw Error('Unexpected local DOM');}catch(e){result={intercept,error:e.stack,ms:Date.now()-start};}
  report.steps.push(result);console.log(JSON.stringify(result));if(result.error){const c=spawnSync('/usr/sbin/screencapture',['-x',join(root,'native-window.png')],{encoding:'utf8',timeout:3000});report.nativeCapture={status:c.status,error:c.error?.message??null,stdout:c.stdout,stderr:c.stderr};break;}
 }
 report.status=report.steps.length===2&&report.steps.every(x=>!x.error)?'passed':'failed';
}catch(e){report.status='failed';report.error=e.stack;}
finally{await stop();report.browserLog=log;await writeFile(join(root,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,path:root,sha256:createHash('sha256').update(JSON.stringify(report,null,2)+'\n').digest('hex')}));if(report.status!=='passed')process.exitCode=1;}
