# Independent answers to the unkeyed cache course

These twelve answers and worked derivations were completed from the exact prompt/options-only input before any candidate key, explanation, transfer prompt or implementation was read. The zero-based answer sequence is [1,2,3,0,2,2,1,1,2,0,3,0].

All questions have one correct option under the stated fully associative, equal-size, empty-cache model. The derivations distinguish residence from past references, FIFO insertion from LRU recency, prefix counts from whole-run totals, and modeled misses from runtime or workload-wide claims. The full FIFO 3/4-capacity hand traces are included. The previously frozen timestamp oracle remains a separate pre-candidate packet.

This packet is an independent content expectation, not final course or application acceptance. Actual keys, explanations, transfer wording, native deck admission, learner flow, engine/UI and publication remain to be received against their exact source pins. Preserve these bytes unchanged when comparing the candidate.
