$ErrorActionPreference = 'Stop'
$root = 'D:/Hamon/receiving/recall-genotype-counts-root-db371a37f4c8'
$os = Get-CimInstance Win32_OperatingSystem
$c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='D:'"
$guard = [ordered]@{schema='recall261-root-native-guard-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;machine=[Environment]::MachineName;user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;boot=$os.LastBootUpTime.ToUniversalTime().ToString('o');freeC=[long]$c.FreeSpace;freeD=[long]$d.FreeSpace;freeMemory=[long]$os.FreePhysicalMemory*1024;floorC=1073741824;floorD=1073741824;floorMemory=2147483648}
$guard | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 "$root/PDF-INSPECTION-r1-GUARD.json"
if ($guard.machine -ne 'MSI' -or $guard.user -ne 'MSI\Veria' -or $guard.boot -ne '2026-10-04T04:03:32.5000000Z' -or $guard.freeC -lt $guard.floorC -or $guard.freeD -lt $guard.floorD -or $guard.freeMemory -lt $guard.floorMemory) { throw 'Identity, boot or resource guard refused' }

$b = Get-Content -Raw "$root/CANDIDATE-BROWSER-r2.json" | ConvertFrom-Json
$x = Get-Content -Raw "$root/CANDIDATE-BROWSER-r2-EXIT.json" | ConvertFrom-Json
if ($x.exitCode -ne 1 -or -not $b.browserClosed -or -not $b.sourceAndRuntimeUnchanged) { throw 'Unexpected retained browser outcome' }
$ids = @($b.pid,$b.parent,$x.controller,$x.parent,$x.child,27740) + @($b.browserProcesses | ForEach-Object { $_.id }) + @($b.browserProcessesAtClose | ForEach-Object { $_.id })
$all = @(Get-CimInstance Win32_Process)
$self = $all | Where-Object { $_.ProcessId -eq $PID }
$known = @($ids | Sort-Object -Unique | ForEach-Object {
 $id = [int]$_; $p = $all | Where-Object { $_.ProcessId -eq $id }
 if ($p) { [ordered]@{pid=$id;present=$true;name=$p.Name;created=$p.CreationDate.ToUniversalTime().ToString('o');createdAfterRetainedExit=($p.CreationDate.ToUniversalTime() -gt [DateTime]::Parse($x.end).ToUniversalTime());commandLine=$p.CommandLine} } else { [ordered]@{pid=$id;present=$false} }
})
$owned = @($all | Where-Object { $_.ProcessId -ne $PID -and $_.ProcessId -ne $self.ParentProcessId -and $_.CommandLine -like '*recall-genotype-counts-root-db371a37f4c8*' } | Select-Object ProcessId,ParentProcessId,Name,CommandLine)
$oldPresent = @($known | Where-Object { $_.present -and -not $_.createdAfterRetainedExit })
$temp = @(); if (Test-Path "$root/browser-tmp-r2") { $temp = @(Get-ChildItem -Force -Recurse "$root/browser-tmp-r2" | Select-Object FullName,Length,LastWriteTimeUtc) }
$receipt = [ordered]@{schema='recall261-root-delayed-browser-closure-v2';at=[DateTime]::UtcNow.ToString('o');auditorPID=$PID;auditorParent=$self.ParentProcessId;retainedNativeExit=$x.exitCode;browserClosed=$b.browserClosed;known=$known;ownedNamespace=$owned;oldOwnedPresent=$oldPresent;tempEntries=$temp;signalsSent=0;status= $(if ($owned.Count -eq 0 -and $oldPresent.Count -eq 0) {'closed'} else {'unresolved'})}
$receipt | ConvertTo-Json -Depth 12 | Set-Content -Encoding UTF8 "$root/BROWSER-CLOSURE-r2.json"
if ($receipt.status -ne 'closed') { throw 'Owned browser closure unresolved' }
& 'C:/Program Files/nodejs/node.exe' "$root/control-native.mjs" "$root/PDF-INSPECTION-r1-SPEC.json"
$code = $LASTEXITCODE
[ordered]@{at=[DateTime]::UtcNow.ToString('o');pid=$PID;exitCode=$code} | ConvertTo-Json | Set-Content -Encoding UTF8 "$root/PDF-INSPECTION-r1-OUTER.json"
exit $code
