import assert from 'node:assert/strict';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';

const choices = async (page, attribute) => page.$$eval('[' + attribute + ']', (nodes, name) => nodes.map(node => {
  const clone = node.cloneNode(true);
  clone.querySelector('.choice-key')?.remove();
  return {canonical: Number(node.getAttribute(name)), text: clone.textContent};
}), attribute);
const snapshot = page => page.evaluate(() => ({
  firstSummary: document.querySelector('#first-try-summary')?.textContent,
  mastery: [...document.querySelectorAll('.mastery-row')].map(node => node.textContent),
  review: [...document.querySelectorAll('.review-item')].map(node => ({
    prompt: node.querySelector('.review-prompt').textContent,
    status: node.querySelector('.review-status').textContent,
    firstAnswer: node.querySelectorAll('.review-answers dd')[0].textContent,
    correctAnswer: node.querySelectorAll('.review-answers dd')[1].textContent
  }))
}));
async function selectCourse(page, file) {
  const pending = page.waitForFileChooser({timeout: 5000});
  await page.click('#deck-file');
  const chooser = await pending;
  await chooser.accept([file]);
  await page.waitForSelector('#start-deck', {visible: true, timeout: 5000});
}
export async function receiveLearner(page, {source, courseFile, course, blindSolutions, output, download}) {
  const correctById = new Map(blindSolutions.answers.map(item => [item.id, item.choice]));
  const byPrompt = new Map(course.items.map(item => [item.prompt, item]));
  assert.equal(byPrompt.size, 12);
  for (const item of course.items) assert.equal(item.answer, correctById.get(item.id), 'course key remains bound to blind solution');
  const missIds = new Set(['units-square-factor', 'units-speed-denominator']);
  const trace = {courseTitle: course.title, intentionalMisses: [...missIds], firstAnswers: [], practiceAnswers: []};
  await page.goto(pathToFileURL(join(source, 'demo.html')).href, {waitUntil: 'load'});
  await page.waitForSelector('#start-button', {visible: true});
  await page.click('#start-button');
  await page.waitForSelector('[data-choice]', {visible: true});
  await page.click('[data-choice]');
  await page.waitForSelector('#next-button', {visible: true});
  const existing = await page.evaluate(() => ({content: document.querySelector('#session-content').textContent, progress: document.querySelector('#step-count').textContent}));
  await selectCourse(page, courseFile);
  const preview = await page.evaluate(() => ({
    title: document.querySelector('#deck-preview-title').textContent,
    counts: document.querySelector('.deck-preview-count').textContent,
    attribution: document.querySelector('.deck-preview-attribution').textContent,
    license: document.querySelector('.deck-preview-license').textContent,
    prompts: [...document.querySelectorAll('.deck-questions li strong')].map(node => node.textContent)
  }));
  assert.equal(preview.title, course.title);
  assert.match(preview.counts, /12 questions.*4 concepts/);
  assert.ok(preview.attribution.includes(course.attribution));
  assert.ok(preview.license.includes(course.license));
  assert.deepEqual(preview.prompts, course.items.map(item => item.prompt));
  await page.click('#cancel-deck');
  assert.deepEqual(await page.evaluate(() => ({content: document.querySelector('#session-content').textContent, progress: document.querySelector('#step-count').textContent})), existing, 'cancel preserves actual prior lesson');
  trace.preview = preview;
  trace.cancelPreservedExisting = true;
  await selectCourse(page, courseFile);
  await page.click('#start-deck');
  assert.equal(await page.$eval('#lesson-description', node => node.textContent), course.title);
  assert.equal(await page.$eval('#step-count', node => node.textContent), '0 / 12');
  const seen = new Set();
  const firstOrders = new Map();
  for (let n = 0; n < 12; n++) {
    await page.waitForSelector('.question-card [data-choice]', {visible: true});
    const prompt = await page.$eval('.question-card h2', node => node.textContent);
    const item = byPrompt.get(prompt);
    assert.ok(item && !seen.has(item.id), 'each authored prompt appears once');
    seen.add(item.id);
    const rendered = await choices(page, 'data-choice');
    assert.equal(rendered.length, 4);
    assert.deepEqual(rendered.map(item => item.canonical).sort((a,b) => a-b), [0,1,2,3]);
    for (const option of rendered) assert.equal(option.text, item.options[option.canonical]);
    firstOrders.set(item.id, rendered.map(item => item.canonical));
    const correct = correctById.get(item.id);
    const selected = missIds.has(item.id) ? (correct + 1) % 4 : correct;
    await page.click('[data-choice="' + selected + '"]');
    await page.waitForSelector('#next-button', {visible: true});
    const feedback = await page.$eval('#feedback-slot', node => node.textContent);
    assert.ok(feedback.includes(item.explanation));
    assert.ok(feedback.includes(item.transfer));
    trace.firstAnswers.push({id: item.id, prompt, selected, correct, renderedOrder: firstOrders.get(item.id)});
    await page.click('#next-button');
  }
  await page.waitForSelector('#first-try-summary', {visible: true});
  const before = await snapshot(page);
  assert.match(before.firstSummary, /10 of 12 connections/);
  assert.equal(before.review.length, 12);
  for (const row of before.review) {
    const item = byPrompt.get(row.prompt), answer = trace.firstAnswers.find(record => record.id === item.id);
    assert.equal(row.firstAnswer, item.options[answer.selected]);
    assert.equal(row.correctAnswer, item.options[correctById.get(item.id)]);
    assert.equal(row.status.startsWith('Needs review'), missIds.has(item.id));
  }
  const firstNotes = await download(page, '#save-notes-button', 'learner-first-notes');
  for (const text of [course.title, course.attribution, course.license, '10 of 12 connections correct on the first try.', 'Not started. 2 missed connections are available for practice.']) assert.ok(firstNotes.text.includes(text));
  for (const item of course.items) {
    assert.ok(firstNotes.text.includes('Correct answer: ' + item.options[correctById.get(item.id)]));
    assert.ok(firstNotes.text.includes('Explanation: ' + item.explanation));
    assert.ok(firstNotes.text.includes('Apply the idea: ' + item.transfer));
  }
  await page.screenshot({path: join(output, 'learner-first-trace-desktop.png'), fullPage: false});
  await page.click('#practice-button');
  for (let n = 0; n < 2; n++) {
    await page.waitForSelector('[data-practice-choice]', {visible: true});
    const prompt = await page.$eval('.practice-card h2', node => node.textContent);
    const item = byPrompt.get(prompt);
    assert.ok(item && missIds.has(item.id));
    assert.ok(!trace.practiceAnswers.some(record => record.id === item.id));
    const rendered = await choices(page, 'data-practice-choice');
    assert.deepEqual(rendered.map(item => item.canonical), firstOrders.get(item.id), 'practice retains displayed option order');
    for (const option of rendered) assert.equal(option.text, item.options[option.canonical]);
    const selected = correctById.get(item.id);
    await page.click('[data-practice-choice="' + selected + '"]');
    await page.waitForSelector('#practice-next', {visible: true});
    const feedback = await page.$eval('#practice-feedback', node => node.textContent);
    assert.ok(feedback.includes(item.explanation));
    assert.ok(feedback.includes(item.transfer));
    trace.practiceAnswers.push({id: item.id, selected, renderedOrder: rendered.map(item => item.canonical)});
    await page.click('#practice-next');
  }
  await page.waitForSelector('#first-try-summary', {visible: true});
  const after = await snapshot(page);
  assert.deepEqual(after, before, 'practice preserves first answers and model estimates');
  const secondNotes = await download(page, '#save-notes-button', 'learner-practice-notes');
  assert.ok(secondNotes.text.includes('Complete: 2 of 2 practice answers recorded; 2 correct on retry.'));
  for (const text of [course.title, course.attribution, course.license, '10 of 12 connections correct on the first try.']) assert.ok(secondNotes.text.includes(text));
  for (const item of course.items) {
    const answer = trace.firstAnswers.find(record => record.id === item.id);
    assert.ok(secondNotes.text.includes('Your first answer: ' + item.options[answer.selected]));
    if (missIds.has(item.id)) assert.ok(secondNotes.text.includes('Practice answer: ' + item.options[correctById.get(item.id)]));
  }
  const firstEstimate = firstNotes.text.split('ESTIMATED MASTERY — MODEL STATE, NOT A GRADE')[1].split('\nPRACTICE\n')[0];
  const finalEstimate = secondNotes.text.split('ESTIMATED MASTERY — MODEL STATE, NOT A GRADE')[1].split('\nPRACTICE\n')[0];
  assert.equal(finalEstimate, firstEstimate);
  trace.firstSnapshot = before;
  trace.finalSnapshot = after;
  trace.notes = [firstNotes, secondNotes].map(({text, ...metadata}) => metadata);
  trace.completed = true;
  return trace;
}
