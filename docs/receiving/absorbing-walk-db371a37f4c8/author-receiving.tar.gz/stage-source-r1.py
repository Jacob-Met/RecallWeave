import pathlib,json,hashlib,subprocess,datetime,traceback,shutil
root=pathlib.Path('/run/user/1000/snap.chromium/hamon-absorbing-walk-author-db371a37f4c8')
packet=json.loads((root/'source-packet.json').read_text())
run=root/'stage-r1';run.mkdir(exist_ok=False)
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 for folder in ['original','source']:(root/folder).mkdir(exist_ok=False)
 for item in packet['original']['files']:
  data=item['content'].encode();assert hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest()==item['git']
  for folder in ['original','source']:
   p=root/folder/item['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 for item in packet['candidate']:
  p=root/'source'/item['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(item['content'].encode())
 (root/'source/tools/check-absorbing-walk-browser.mjs').write_bytes(packet['driver'].encode())
 args=['/usr/bin/node','tools/build-absorbing-walk.mjs']
 build=subprocess.run(args,cwd=root/'source',capture_output=True,timeout=20)
 (run/'build.stdout').write_bytes(build.stdout);(run/'build.stderr').write_bytes(build.stderr)
 report['buildExit']=build.returncode;assert build.returncode==0
 report['runtimeExact']=[{'path':x['path'],'exact':hashlib.sha256((root/'source'/x['path']).read_bytes()).hexdigest()==x['sha256']} for x in packet['runtimeManifest']]
 assert all(x['exact'] for x in report['runtimeExact'])
 (root/'runtime-manifest-r1.json').write_text(json.dumps(packet['runtimeManifest'],indent=2)+'\n')
 baseline="""import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {computeTrace} from './original/courses/markov-chains-core.mjs';import {parseDeck} from './original/src/deck.mjs';const r=computeTrace({matrix:[[100,0,0],[25,0,75],[0,0,100]],initial:[0,100,0]},3);assert.deepEqual(r.trace[3].probabilities,[.25,0,.75]);const d=parseDeck(await readFile('./original/courses/markov-chains.json','utf8'));assert.equal(d.items.length,14);console.log(JSON.stringify({status:'passed',node:process.version,originalMarkov:true,originalDeckItems:d.items.length}));"""
 (root/'platform-original.mjs').write_text(baseline)
 result=subprocess.run(['/usr/bin/node','platform-original.mjs'],cwd=root,capture_output=True,timeout=20)
 (run/'original.stdout').write_bytes(result.stdout);(run/'original.stderr').write_bytes(result.stderr)
 report['originalExit']=result.returncode;assert result.returncode==0
 report['node']=subprocess.check_output(['/usr/bin/node','--version'],timeout=10).decode().strip()
 report['browser']=subprocess.check_output(['/snap/bin/chromium','--version'],timeout=20).decode().strip()
 report['status']='passed'
except Exception:report['status']='failed';report['error']=traceback.format_exc()
finally:
 report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();(run/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
