
## Refraction and the critical boundary

[Refraction foundations](courses/refraction-foundations.json) is an original 16-question course for the existing local deck picker. Its [worked guide](courses/refraction-foundations.md) connects normal-angle geometry, ordered refractive indices, Snell's law, equal-index and normal-incidence controls, reversibility, and the strict total-internal-reflection threshold. Import the JSON into `demo.html`, preview it, then choose **Start this deck**. Review, separate practice, reflections and study-note downloads use the unchanged learner. The ideal ray model predicts directions; it does not calculate optical power or claim measured learning gains. No catalog registration or new runtime is required.
