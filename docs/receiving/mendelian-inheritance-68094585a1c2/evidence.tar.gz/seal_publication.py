from pathlib import Path, PurePosixPath
import subprocess, hashlib, json, tarfile, gzip, io, shutil, datetime, re, difflib
ROOT=Path('/Users/me/hamon-recallweave-inheritance-68094585a1c2')
SRC=ROOT/'source'; EV=ROOT/'evidence'
RECEIVER=Path('/Users/me/hamon-recallweave-blind-receiving-68094585a1c2')
BASE='6f920f177ae90a09958146d41612a0e83f52702f'
BASE_TREE='c2be5240d1ffa17c7e66b3fb8fe74aa334ec10b2'
DOC='docs/receiving/mendelian-inheritance-68094585a1c2'
SOURCE_PATHS=['README.md','courses/mendelian-inheritance.json','courses/mendelian-inheritance.md','courses/mendelian-inheritance-lab.html','templates/mendelian-inheritance-lab.html','src/mendelian-inheritance.mjs','src/mendelian-inheritance-ui.mjs','tools/build-mendelian-inheritance.mjs','tools/check-mendelian-inheritance-browser.mjs','tests/mendelian-inheritance.test.mjs','tests/mendelian-inheritance-course.test.mjs']
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=SRC).decode().strip()
def write_json(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def pin(path,rel=None):
 data=path.read_bytes()
 return {'path':rel or str(path),'mode':'100644','bytes':len(data),'sha256':sha(data),'git_blob':blob(data)}
def tree_map(ref):
 result={}
 for raw in subprocess.check_output(['git','ls-tree','-rz',ref],cwd=SRC).split(b'\0'):
  if not raw: continue
  meta,p=raw.split(b'\t',1); mode,kind,oid=meta.decode().split()
  result[p.decode()]={'mode':mode,'type':kind,'sha':oid}
 return result
def calculated_tree(entries):
 root={}
 for path,v in entries.items():
  cursor=root; segments=path.split('/')
  for segment in segments[:-1]: cursor=cursor.setdefault(segment,{})
  cursor[segments[-1]]=(v['mode'],v['sha'])
 def recurse(node):
  parts=[]
  for name,value in node.items():
   if isinstance(value,dict): mode,oid,isdir='40000',recurse(value),True
   else: mode,oid=value; isdir=False
   parts.append(((name+('/' if isdir else '')).encode(),mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)))
  data=b''.join(value for key,value in sorted(parts))
  return hashlib.sha1(b'tree '+str(len(data)).encode()+b'\0'+data).hexdigest()
 return recurse(root)

assert git('rev-parse','HEAD')==BASE and git('rev-parse','HEAD^{tree}')==BASE_TREE
before=tree_map(BASE)
assert len(before)==1179 and calculated_tree(before)==BASE_TREE
assert before==json.loads((EV/'current-main-6f920f-full-tree.json').read_text())
assert not git('diff','--cached','--name-only')
assert git('diff','--name-only').splitlines()==['README.md']
assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(SOURCE_PATHS)-{'README.md'}
assert not [p for p in before if PurePosixPath(p).name in ['AGENTS.md','CONTINUE.md','CODEOWNERS','CONTRIBUTING.md']]
readme_before=subprocess.check_output(['git','show',BASE+':README.md'],cwd=SRC)
readme_after=(SRC/'README.md').read_bytes()
assert readme_before==(EV/'README-before-6f920f.md').read_bytes()
assert readme_after.startswith(readme_before) and len(readme_after)-len(readme_before)==966
source_pins=[dict(pin(SRC/p,p),local_path=str(SRC/p),before_blob=before.get(p,{}).get('sha'),before_mode=before.get(p,{}).get('mode')) for p in SOURCE_PATHS]
source_map={x['path']:x for x in source_pins}

independent_dir=EV/'independent'; independent_dir.mkdir(exist_ok=True)
independent_names={
 'recallweave-independent-receiving-v1.tar.gz':'1160d9a2ee745910db4f29d730c3959034abd69003a76961be128e3062c515fd',
 'receiving-manifest.json':'23bfb4a3e8f357e270636e53e3d153a8ce4a551ffebe9de4a6c3c4961724aefe'
}
for name,expected in independent_names.items():
 assert sha((RECEIVER/name).read_bytes())==expected
 shutil.copyfile(RECEIVER/name,independent_dir/name)
 assert sha((independent_dir/name).read_bytes())==expected
review_manifest=json.loads((independent_dir/'receiving-manifest.json').read_text())
with tarfile.open(independent_dir/'recallweave-independent-receiving-v1.tar.gz','r:gz') as archive:
 inner_members={m.name:m for m in archive.getmembers() if m.isfile()}
 assert all(not PurePosixPath(p).is_absolute() and '..' not in PurePosixPath(p).parts for p in inner_members)
 for entry in review_manifest['files']:
  assert entry['path'] in inner_members
  data=archive.extractfile(inner_members[entry['path']]).read()
  assert sha(data)==entry['sha256'] and len(data)==entry['bytes']
 independent_member_count=len(inner_members)

browser=json.loads((EV/'browser-v6/browser-report.json').read_text())
assert browser['status']=='passed' and len(browser['checks'])==14 and browser['sourcePinsStable'] is True
assert browser['pageErrors']==browser['consoleErrors']==browser['dialogs']==[]
assert len(browser['screenshots'])==7 and len(browser['downloads'])==5
browser_differences=[]
for p,expected in browser['sourceSha256'].items():
 actual=sha((SRC/p).read_bytes())
 if actual!=expected: browser_differences.append({'path':p,'executed_receipt_sha256':expected,'final_sha256':actual})
assert [x['path'] for x in browser_differences]==['tools/build-mendelian-inheritance.mjs']
for entry in browser['screenshots']:
 data=(EV/'browser-v6'/entry['name']).read_bytes()
 assert sha(data)==entry['sha256'] and len(data)==entry['bytes']
for entry in browser['downloads']:
 data=(EV/'browser-v6/downloads'/entry['filename']).read_bytes()
 assert sha(data)==entry['sha256'] and len(data)==entry['bytes']
assert (EV/'browser-v6/downloads/03/mendelian-inheritance.json').read_bytes()==(SRC/'courses/mendelian-inheritance.json').read_bytes()
assert sum(len(x['firstAnswers']) for x in browser['learnerRuns'])==24
assert sum(x['practiceCount'] for x in browser['learnerRuns'])==6
guide_prior=(EV/'content-review/accepted-guide-v2.md').read_text()
guide_final=(SRC/'courses/mendelian-inheritance.md').read_text()
assert guide_prior.split('## Native maintenance')[0]==guide_final.split('## Native maintenance')[0]
(EV/'content-review/final-maintenance-only.diff').write_text(''.join(difflib.unified_diff(guide_prior.splitlines(True),guide_final.splitlines(True),fromfile='accepted-guide-v2.md',tofile='courses/mendelian-inheritance.md')))
old_builder=(EV/'symlink-entry-baseline/actual/tools/build-mendelian-inheritance.mjs').read_text()
new_builder=(SRC/'tools/build-mendelian-inheritance.mjs').read_text()
marker='export function buildInheritanceLab() {'
assert old_builder.split(marker,1)[1].split('\n}\n\n',1)[0]==new_builder.split(marker,1)[1].split('\n}\n\n',1)[0]
assert old_builder[old_builder.index('\nif ('):].split('{\n',1)[1]==new_builder[new_builder.index('\nif (invokedDirectly()'):].split('{\n',1)[1]
(EV/'cli-entry-guard.diff').write_text(''.join(difflib.unified_diff(old_builder.splitlines(True),new_builder.splitlines(True),fromfile='original-builder.mjs',tofile='tools/build-mendelian-inheritance.mjs')))
for name,count,expected in [('final-new-tests.log',14,'5c737aa68b995876d91e8e3fb2ff12cfcbf4d0ecbbb18d4828a8ebccd2455b90'),('final-full-node-suite.log',241,'c5113a45166f4d8f6bea9b92c630f2db010e9e1e1e78ac680adf4d6281ddc096')]:
 data=(EV/name).read_bytes(); text=data.decode()
 assert sha(data)==expected and re.search(r'tests '+str(count)+r'\b',text) and re.search(r'pass '+str(count)+r'\b',text) and re.search(r'fail 0\b',text)
assert sha((EV/'final-lab-parity.log').read_bytes())=='e38bfe77fd63c5ec859d17fb22f6eb11319d8b9b25ca1318c35335e20d388d0e'
assert sha((SRC/'courses/mendelian-inheritance-lab.html').read_bytes())=='3a35277a4347f4985a90fa4cfe5d777c1a55b8485cab3142a0a520a157893da4'
native_prior=json.loads((EV/'current-native-gates.json').read_text())
assert native_prior['maintained_demo_gate']['byte_exact']
assert sha((SRC/'demo.html').read_bytes())==native_prior['maintained_demo_gate']['before_sha256']
baseline=json.loads((EV/'symlink-entry-baseline/receipt.json').read_text())
assert baseline['returncode']==0 and baseline['stdout']==baseline['stderr']=='' and 'stale' in baseline['retained_output']
subprocess.run(['git','add','--',*SOURCE_PATHS],cwd=SRC,check=True)
source_tree=git('write-tree'); runtime_map=tree_map(source_tree)
expected_runtime=dict(before)
for entry in source_pins: expected_runtime[entry['path']]={'mode':entry['mode'],'type':'blob','sha':entry['git_blob']}
assert runtime_map==expected_runtime and calculated_tree(runtime_map)==source_tree and len(runtime_map)==1189
write_json(EV/'runtime-source-pins.json',{'base':BASE,'base_tree':BASE_TREE,'source_tree':source_tree,'files':source_pins})
write_json(EV/'runtime-full-leaves.json',runtime_map)
frozen=datetime.datetime.now(datetime.timezone.utc).isoformat()
qualification={
 'format':'recallweave-mendelian-receiving/1','frozen_at_utc':frozen,'repository':'Jacob-Met/RecallWeave',
 'claim':'https://github.com/Jacob-Met/RecallWeave/issues/60','author_scope':'68094585a1c2 / memory_delivery',
 'base':{'commit':BASE,'tree':BASE_TREE,'leaves':1179},'source_tree':source_tree,'source_leaves':1189,'source':source_pins,
 'instructions':{'checked_full_tree':True,'AGENTS_CONTINUE_CODEOWNERS_CONTRIBUTING_found':False},
 'beneficiary':'A learner connecting individual gamete routes to genotype and phenotype probabilities, then explaining and revisiting those ideas in the existing learner.',
 'delivery':{'course_items':12,'concepts':4,'native_format':'recallweave-deck/1','guide':'Worked answers, all 36 distractor rationales and 12 transfer solutions.','explorer':'One or two autosomal loci, exact route fractions, explicit complete-dominance and independent-assortment assumptions; no deterministic finite-offspring claim.','local_explicit_downloads':['exact course JSON','computed cross JSON'],'shared_learner_changes':False,'dependency_or_workflow_changes':False},
 'primary_references':['https://openstax.org/books/biology-2e/pages/12-3-laws-of-inheritance','https://openstax.org/books/biology-2e/pages/12-2-characteristics-and-traits','https://www.genome.gov/genetics-glossary/Meiosis','https://www.genome.gov/genetics-glossary/genotype','https://www.genome.gov/genetics-glossary/Phenotype'],
 'independent_receiving':{
  'blind_before_author_key':True,'blind_manifest_sha256':'5c70f41540eda2a020ae9c5682f2e06bc7ee6eb0ee25f566ddacf0c445495174',
  'scope':review_manifest['native_summary'],'options_reviewed':48,'transfer_answers_reviewed':12,
  'capsule':pin(independent_dir/'recallweave-independent-receiving-v1.tar.gz','evidence/independent/recallweave-independent-receiving-v1.tar.gz'),
  'manifest':pin(independent_dir/'receiving-manifest.json','evidence/independent/receiving-manifest.json'),
  'capsule_regular_file_members':independent_member_count,
  'finding_resolved':'Item 11 explanation now explicitly distinguishes AaBb x AaBb P(A_ and B_)=9/16 from P(A_ and bb)=3/16. The given AABb x Aabb question remains P(A_ and bb)=1/2; no key change.',
  'accepted_scientific_guide_prefix_unchanged':True,'later_guide_change':'Only Native maintenance instructions now describe the existing Playwright receiver route.','browser_claim':False
 },
 'native':{
  'platform':'macOS native','node':'v26.3.0','python':'3.13.7','canonical_TMPDIR':str(ROOT/'native-tmp'),
  'new_tests':{'passed':14,'failed':0,'log':pin(EV/'final-new-tests.log','evidence/final-new-tests.log')},
  'full_current_suite':{'passed':241,'failed':0,'skipped':0,'command':'node --test tests/*.test.mjs','log':pin(EV/'final-full-node-suite.log','evidence/final-full-node-suite.log')},
  'maintained_demo_gate':native_prior['maintained_demo_gate'],
  'lab_check':{'command':'node tools/build-mendelian-inheritance.mjs --check','generated_bytes':40531,'generated_sha256':source_map['courses/mendelian-inheritance-lab.html']['sha256'],'log':pin(EV/'final-lab-parity.log','evidence/final-lab-parity.log')},
  'initial_preconditions':native_prior['execution_preconditions'],
  'owned_cli_boundary':{'original_probe':'evidence/symlink-entry-baseline/receipt.json','original_exit':0,'original_stale_file_preserved':True,'original_empty_stdout_stderr':True,'fix':'Canonicalize only this new builder entry detector. Build function and CLI body are byte-identical.','regression':'An owned directory-symlink CLI refuses stale --check without replacing it, then accepts the exact current artifact.'}
 },
 'browser':{
  'report':pin(EV/'browser-v6/browser-report.json','evidence/browser-v6/browser-report.json'),'log':pin(EV/'browser-v6.log','evidence/browser-v6.log'),
  'checks_passed':14,'checks':browser['checks'],'browser':browser['browser'],'node':browser['node'],'playwright_version':'1.63.0',
  'playwright_entry':browser['playwrightEntry'],'playwright_entry_sha256':browser['playwrightEntrySha256'],
  'first_answers':24,'separate_correct_retries':6,'actual_downloads':5,'screenshots':7,'no_page_console_or_dialog_errors':True,'source_pins_stable_at_run':True,
  'final_source_differences_from_run':browser_differences,
  'difference_qualification':'Only the later CLI entry guard changed; the HTML construction function and CLI body remain exact, and final deterministic artifact parity proves the identical browser-executed HTML. No browser rerun solely for this non-browser entry guard.',
  'visual_inspection':'Actual desktop lab, 390px route/probability tables, phone standalone learner and desktop modular learner captures were opened and reviewed. Bounds and content are readable.'
 },
 'preserved_history':[
  'native-v1/v2 were 13-case historical runs; final suite adds the CLI case.',
  'Initial full-suite failures exposed missing sparse author HTML/CSS inputs and an existing grouped-data CLI lexical path guard under Mac /var symlinks. Exact current author inputs were hydrated; an owned canonical TMPDIR is an execution precondition. Existing source/tests were not changed.',
  'Browser v1/v2 stopped on receiver Mac select-key assumptions. Actual Tab/Enter remains exercised; final normal Playwright selectOption delivers parent/preset changes.',
  'Browser v3/v4 and minimal custom-CDP HTTP probes timed out inside Page.navigate before readiness checks. The exact cause is not established. Existing installed Playwright transport executed unchanged HTTP inputs successfully; product HTML needed no repair.',
  'Browser v5 stopped on a receiver expectation of a second Start button. The real existing Start this deck flow immediately renders a question; v6 follows that behavior and passes.',
  'The original owned-builder symlink probe preserved its false-success exit and stale bytes; the final maintained CLI regression covers the repair.',
  'All raw small logs, receipts, helper versions and probes are in the capsule; all final captures/downloads and the original v1/v5 failed-state captures are included. Other repeated historical images remain untouched in the native evidence directories.'
 ],
 'preservation':{'README_before_blob':before['README.md']['sha'],'README_prefix_byte_exact':True,'README_append_bytes':966,'all_current_unowned_leaves_preserved':1178,'current_author_grouped_membrane_learner_inputs_unchanged':True},
 'limits':['This receipt records native macOS/Node 26/Chrome receiving, not a hosted Node 20 gate or a deployed release.','The cross explorer deliberately supports only the stated one/two-locus equal-gamete model; unequal weights are a course counterexample, not a hidden model option.','The browser receiver is an optional tool using an already installed Playwright/browser, with no new workflow/dependency declaration.','Publication and any new current-main composition remain with the root receiving owner.']
}
write_json(EV/'qualification.json',qualification)

members={}
for p in sorted(EV.rglob('*')):
 if not p.is_file() or p.is_symlink(): continue
 rel=p.relative_to(EV).as_posix()
 if p.suffix.lower()=='.png' and not (rel.startswith('browser-v6/') or rel in ['browser-v1/failed-state.png','browser-v5/failed-state.png']): continue
 members['evidence/'+rel]=p
for rel in SOURCE_PATHS: members['source/'+rel]=SRC/rel
members['seal_publication.py']=Path(__file__)
entries=[pin(p,rel) for rel,p in sorted(members.items())]
archive_manifest={'format':'recallweave-mendelian-capsule/1','frozen_at_utc':frozen,'base':BASE,'source_tree':source_tree,'files':entries,'excluded':'Repeated historical PNGs only; all small prior probes/logs and final images/downloads are retained.'}
manifest_bytes=(json.dumps(archive_manifest,indent=2,ensure_ascii=False)+'\n').encode()
archive_path=ROOT/'mendelian-receiving-evidence.tar.gz'
with archive_path.open('wb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.USTAR_FORMAT) as tar:
   for rel,p in sorted(members.items()):
    data=p.read_bytes(); info=tarfile.TarInfo(rel); info.size=len(data); info.mode=0o644; info.mtime=0
    tar.addfile(info,io.BytesIO(data))
   info=tarfile.TarInfo('archive-manifest.json');info.size=len(manifest_bytes);info.mode=0o644;info.mtime=0
   tar.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(archive_path,'r:gz') as tar:
 actual=tar.getmembers()
 assert len(actual)==len(entries)+1
 assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in actual)
 for entry in entries:
  data=tar.extractfile(entry['path']).read()
  assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
 assert tar.extractfile('archive-manifest.json').read()==manifest_bytes
write_json(ROOT/'evidence-archive-manifest.json',archive_manifest)
doc_dir=SRC/DOC; doc_dir.mkdir(parents=True,exist_ok=True)
shutil.copyfile(archive_path,doc_dir/'evidence.tar.gz')
archive_pin=pin(doc_dir/'evidence.tar.gz',DOC+'/evidence.tar.gz')
doc_receipt=dict(qualification)
doc_receipt['capsule']=dict(archive_pin,regular_file_members=len(entries)+1,archive_manifest_sha256=sha(manifest_bytes))
write_json(doc_dir/'receipt.json',doc_receipt)
shutil.copyfile(ROOT/'qualification-readme.md',doc_dir/'README.md')
DOC_PATHS=[DOC+'/README.md',DOC+'/receipt.json',DOC+'/evidence.tar.gz']
subprocess.run(['git','add','--sparse','--',*DOC_PATHS],cwd=SRC,check=True)
final_tree=git('write-tree'); full=tree_map(final_tree); all_paths=SOURCE_PATHS+DOC_PATHS
assert set(git('diff','--cached','--name-only').splitlines())==set(all_paths) and not git('diff','--name-only')
final_pins=[dict(pin(SRC/p,p),local_path=str(SRC/p),before_blob=before.get(p,{}).get('sha'),before_mode=before.get(p,{}).get('mode')) for p in all_paths]
expected=dict(before)
for entry in final_pins: expected[entry['path']]={'mode':entry['mode'],'type':'blob','sha':entry['git_blob']}
assert full==expected and calculated_tree(full)==final_tree and len(full)==1192
assert all(full[p]==v for p,v in before.items() if p not in all_paths)
assert sha((doc_dir/'evidence.tar.gz').read_bytes())==sha(archive_path.read_bytes())
write_json(ROOT/'publication-full-leaves.json',full)
publication={
 'format':'recallweave-mendelian-publication/1','frozen_at_utc':frozen,'repository':'Jacob-Met/RecallWeave','issue':60,
 'parent':BASE,'parents':[BASE],'base_tree':BASE_TREE,'base_leaves':1179,'runtime_source_tree':source_tree,'runtime_source_leaves':1189,
 'expected_tree':final_tree,'expected_leaves':1192,'path_count':len(all_paths),'source_path_count':len(SOURCE_PATHS),'evidence_path_count':len(DOC_PATHS),
 'current_unowned_leaves_preserved':1178,'files':final_pins,
 'evidence_archive':dict(archive_pin,local_path=str(doc_dir/'evidence.tar.gz'),regular_file_members=len(entries)+1),
 'full_leaf_map':str(ROOT/'publication-full-leaves.json'),
 'instructions':'No applicable repository AGENTS/CONTINUE/CODEOWNERS/CONTRIBUTING file in the complete pinned tree.',
 'publication':'Local isolated index/tree only. No commit, GitHub mutation, hosted gate or deployment claimed.'
}
write_json(ROOT/'publication-manifest.json',publication)
packet_files=[ROOT/'publication-manifest.json',ROOT/'publication-full-leaves.json',ROOT/'evidence-archive-manifest.json',archive_path]
packet={'format':'recallweave-mendelian-packet/1','parent':BASE,'expected_tree':final_tree,'files':[pin(p,str(p)) for p in packet_files]}
write_json(ROOT/'packet-manifest.json',packet)
print(json.dumps({'status':'sealed','parent':BASE,'runtime_tree':source_tree,'tree':final_tree,'leaves':len(full),'paths':len(all_paths),'unowned_preserved':1178,'publication_manifest':pin(ROOT/'publication-manifest.json'),'packet_manifest':pin(ROOT/'packet-manifest.json'),'archive':pin(archive_path),'archive_members':len(entries)+1,'independent_capsule_members':independent_member_count,'source':source_pins},indent=2))
