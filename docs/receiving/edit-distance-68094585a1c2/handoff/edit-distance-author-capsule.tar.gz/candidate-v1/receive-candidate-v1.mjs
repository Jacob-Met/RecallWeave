import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root='/tmp/hamon-levenshtein-68094585a1c2';
if(JSON.parse(fs.readFileSync(root+'/baseline-evidence/receipt.json','utf8')).status!=='passed')throw new Error('Original receiving must pass before candidate admission.');
const overlay=JSON.parse(fs.readFileSync(root+'/candidate-v1-overlay.json','utf8'));
const project=root+'/candidate-source', evidence=root+'/candidate-v1-evidence';
fs.mkdirSync(evidence);fs.cpSync(root+'/baseline-source',project,{recursive:true,errorOnExist:true,force:false});
for(const [name,content] of Object.entries(overlay.files)){
  const target=path.join(project,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,content,{flag:'wx'});
}
const report={format:'recallweave-edit-distance-author-native/1',status:'running',started:new Date().toISOString(),node:process.version,pid:process.pid,project,parent:overlay.parent,commands:[]};
for(const [name,executable,args] of [
  ['build',process.execPath,['tools/build_edit_distance_explorer.mjs']],
  ['focused',process.execPath,['--test','tests/edit-distance.test.mjs']],
  ['ui-syntax',process.execPath,['--check','courses/edit-distance-ui.mjs']]
]){
  const started=new Date().toISOString();const r=spawnSync(executable,args,{cwd:project,encoding:'utf8',timeout:90000,maxBuffer:8*1024*1024});
  fs.writeFileSync(evidence+'/'+name+'.stdout.log',r.stdout??'',{flag:'wx'});fs.writeFileSync(evidence+'/'+name+'.stderr.log',r.stderr??'',{flag:'wx'});
  report.commands.push({name,executable,args,started,finished:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?String(r.error):null});
  if(r.status!==0)process.exitCode=1;
}
const names=[...Object.keys(overlay.files),'courses/edit-distance-explorer.html'];
report.pins=names.map(name=>{const b=fs.readFileSync(path.join(project,name));return {path:name,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex'),blob:createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex')};});
const base=JSON.parse(fs.readFileSync(root+'/baseline-evidence/source-pins.json','utf8'));
report.originalSourceUnchanged=base.every(p=>createHash('sha256').update(fs.readFileSync(path.join(project,p.path))).digest('hex')===p.sha256);
if(!report.originalSourceUnchanged)process.exitCode=1;
report.status=process.exitCode?'failed':'passed';report.finished=new Date().toISOString();
fs.writeFileSync(evidence+'/receipt.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:report.status,commands:report.commands,originalSourceUnchanged:report.originalSourceUnchanged,files:report.pins.length}));
