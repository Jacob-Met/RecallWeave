const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process'),assert=require('node:assert/strict');
const root=__dirname,project=path.join(root,'source-r0'),out=path.join(root,'native-r0');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),git=b=>crypto.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex');
const rec=file=>{const b=fs.readFileSync(file),s=fs.statSync(file);return {path:file,bytes:b.length,sha256:sha(b),gitBlob:git(b),mtimeMs:s.mtimeMs};};
const report={format:'recall180-authentic-page-native/1',at:new Date().toISOString(),pid:process.pid,accepted:false,commands:[]};
try {
 assert.equal(os.userInfo().username,'jacob');assert.equal(process.version,'v24.14.0');
 report.runtimeBefore=rec(process.execPath);assert.equal(report.runtimeBefore.sha256,'63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088');
 const disk=fs.statfsSync(root);report.resources={freeMemory:os.freemem(),freeDisk:Number(disk.bavail)*Number(disk.bsize),minMemory:2*1024**3,minDisk:1024**3};
 assert.ok(report.resources.freeMemory>=report.resources.minMemory);assert.ok(report.resources.freeDisk>=report.resources.minDisk);
 assert.ok(!fs.existsSync(project));assert.ok(!fs.existsSync(out));
 const payload=JSON.parse(fs.readFileSync(path.join(root,'source-payload-r0.json'),'utf8'));
 assert.equal(payload.expected.length,12);assert.equal(Object.keys(payload.source).length,12);
 for(const row of payload.expected){
  assert.ok(row.path&&!path.isAbsolute(row.path)&&row.path.split('/').every(x=>x&&x!=='.'&&x!=='..'));assert.equal(typeof payload.source[row.path],'string');
  const b=Buffer.from(payload.source[row.path]);assert.equal(b.length,row.bytes,row.path);assert.equal(sha(b),row.sha256,row.path);assert.equal(git(b),row.gitBlob,row.path);
 }
 fs.mkdirSync(project);fs.mkdirSync(out);for(const row of payload.expected){const dest=path.join(project,row.path);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,payload.source[row.path],{flag:'wx'});}
 report.originalSourceBefore=payload.expected.map(r=>rec(path.join(project,r.path)));
 report.inputBefore=[rec(__filename),rec(path.join(root,'source-payload-r0.json'))];
 const commands=[['build',['tools/build-course-compare.mjs']],['parity',['tools/build-course-compare.mjs','--check']],['page-tests',['--test','tests/course-comparison-page.test.mjs']]];
 for(const [name,args]of commands){const at=Date.now(),r=spawnSync(process.execPath,args,{cwd:project,encoding:'utf8',timeout:30000,maxBuffer:2*1024**2,windowsHide:true});fs.writeFileSync(path.join(out,name+'.stdout'),r.stdout??'',{flag:'wx'});fs.writeFileSync(path.join(out,name+'.stderr'),r.stderr??'',{flag:'wx'});report.commands.push({name,args,status:r.status,signal:r.signal,error:r.error?String(r.error):null,elapsedMs:Date.now()-at,stdout:rec(path.join(out,name+'.stdout')),stderr:rec(path.join(out,name+'.stderr'))});assert.equal(r.status,0,name+': '+r.stderr);assert.equal(r.signal,null,name);}
 report.originalSourceAfter=payload.expected.map(r=>rec(path.join(project,r.path)));assert.deepEqual(report.originalSourceAfter,report.originalSourceBefore);
 report.generatedStandalone=rec(path.join(project,'course-compare.html'));
 report.sourceClosure=[...payload.expected.map(r=>({...rec(path.join(project,r.path)),path:r.path})),{...report.generatedStandalone,path:'course-compare.html'}];
 assert.equal(report.sourceClosure.length,13);
 report.runtimeAfter=rec(process.execPath);assert.deepEqual(report.runtimeAfter,report.runtimeBefore);report.inputAfter=report.inputBefore.map(r=>rec(r.path));assert.deepEqual(report.inputAfter,report.inputBefore);
 report.accepted=true;report.boundary='Actual authentic owner177 + unchanged180 page state tests/build/parity only. No comparator-suite replay and no browser launch.';
}catch(e){report.error=e.stack??String(e);process.exitCode=1;}
fs.writeFileSync(path.join(root,'native-receiving-r0.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report));