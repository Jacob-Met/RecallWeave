# RecallWeave #79 — independent publication and integration acceptance

This increment accepts PR #104 through actual merge ea7d4b6a8e504f004f41be33d6dbe9c6db788831, tree a4712cf51e6bd073547ed731a1acda4ec0ad2f27. It has 1,798 leaves. The actual ordered parents are dac952715bead1ab0199aa4c149243e2206f6b2b and public contribution 1acdbdb0bc709d9d77dd8de7c9b62cef8af41387.

## Publication and composition

The public contribution's 1,745-leaf tree 2ad5e354e131659a5f4d2bed18ada2529c77f41b matches every frozen expected path, blob, mode and size. The actual public standalone HTML also matches the qualified artifact bytes. Its native publication payload was independently received against the actual 3575993d parent, including all 139 archived evidence members and unchanged adoption of all three peer packets.

The PR first tested synthetic merge 9344bb6fd7a376fbee1b16484a5f8b8767e35e14 / fe856e1c7e4b4dfd4c87a501abbe0d71ff87d4eb on base 81363271. Its 1,756 leaves preserve all 1,737 unrelated base leaves. No authored composition was necessary.

Main advanced between the last PR read and the actual merge. The actual first parent dac95271 adds 42 Markov paths and changes only README from the tested base. The receiver used actual Git commit parents, not the older PR base snapshot. All 1,779 unrelated incoming leaves retain their blobs, modes and sizes in the final merge. All 18 non-README contribution leaves remain exact; final README is the exact incoming text plus the same 1,072-byte append. All 36 original consumer dependencies are unchanged. Native source/runtime gates were retained without reruns.

## Actual hosted gates

| Exact checkout | Run / job | Result |
| --- | --- | --- |
| PR synthetic 9344bb6f | 37809452929 / 113422196480 | Node 20.20.2: 395/395 tests; all 19 cache methods; zero failures/skips; original demo regeneration succeeds |
| PR synthetic 9344bb6f | 37809452926 / 113422197037 | Node 22.23.3: existing catalog 11 checks and 25 downloads |
| Actual merge ea7d4b6a | 37809967017 / 113423966404 | Node 20.20.2: 405/405 tests; all 19 cache methods; zero failures/skips; original demo regeneration succeeds |
| Actual merge ea7d4b6a | 37809967030 / 113424044875 | Node 22.23.3: existing catalog 11 checks and 25 downloads |

All four jobs completed successfully. Both final workflow run records explicitly have event push, head ea7d4b6a and conclusion success. Raw checkout lines bind the jobs to the stated commits. The existing catalog browser result is separate from the new explorer's previously qualified independent native/browser gate.

## Evidence and replay

Read disposition.json, actual-merge-receiving.json and hosted-receiving.json. The .json.gz API records retain complete actual first-parent, actual merged and earlier synthetic leaf manifests plus the received commit/run/job metadata. The public expected manifest is separately preserved. The receiver reconstructs all corresponding Git roots from these manifests and checks every retained leaf.

The four .log.gz members contain the complete, unedited tool-decoded job logs; gzip decompression yields the original bytes. logs.json binds both compressed and original sizes/hashes. No catalog bundle chunks or raw output were omitted. API record compression is also lossless.

dependencies.json references the unchanged candidate/oracle/answer packets already present in the published 139-member evidence archive. They and the original application capsule are not duplicated here. payload-receiving.json records the exact archive/member custody. The immutable native candidate gates still belong to cae47af5 and its documented successors; this increment adds actual public and hosted receiving.

This is source/main and GitHub Actions acceptance. No new product test execution, dependency installation, owner-source edit or separate live-site deployment claim is introduced by this receiver.
