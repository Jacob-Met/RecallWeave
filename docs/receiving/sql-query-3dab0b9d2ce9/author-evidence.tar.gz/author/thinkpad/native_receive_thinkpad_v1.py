import hashlib
import json
import os
from pathlib import Path
import platform
import re
import sqlite3
import subprocess
import sys

ROOT = Path('/home/jacob/snap/chromium/common/recallweave-sql-3dab-20261008')
FROZEN = ROOT / 'frozen-v1'
REPO = FROZEN / 'repo'
OUT = ROOT / 'receiving' / 'author-thinkpad-v1'
OUT.mkdir(exist_ok=False)
pins = json.loads((FROZEN / 'source-pins.json').read_text())


def guard():
    actual = {path: hashlib.sha256((REPO / path).read_bytes()).hexdigest() for path in pins['files']}
    expected = {path: value['sha256'] for path, value in pins['files'].items()}
    if actual != expected:
        raise RuntimeError('Native source does not match the frozen manifest')
    return actual


receipt = {'status': 'running', 'python': sys.version, 'sqlite': sqlite3.sqlite_version,
           'platform': platform.platform(), 'steps': []}
environment = os.environ.copy()
environment['PYTHON'] = '/usr/bin/python3'
steps = [
    ('browser', ['/usr/bin/node', 'tools/check_sql_query_browser.mjs', '--browser',
     '/snap/bin/chromium', '--output', str(OUT / 'browser')],
     r'^SQL_BROWSER_OK checks=8 failures=0
    receipt['before'] = guard()
    for name, command, marker in steps:
        print('START ' + name, flush=True)
        result = subprocess.run(command, cwd=REPO, env=environment, capture_output=True, text=True, timeout=120)
        (OUT / (name + '.stdout')).write_text(result.stdout)
        (OUT / (name + '.stderr')).write_text(result.stderr)
        step = {'name': name, 'command': command, 'exit': result.returncode,
                'marker_found': re.search(marker, result.stdout, re.M) is not None}
        if name == 'native-contracts':
            step['zero_failures_skips'] = bool(re.search(r'^# fail 0$', result.stdout, re.M)
                                               and re.search(r'^# skipped 0$', result.stdout, re.M))
        if name == 'browser' and (OUT / 'browser/browser-report.json').is_file():
            report = json.loads((OUT / 'browser/browser-report.json').read_text())
            step['browser_status'] = report['status']
            step['browser_checks'] = len(report['checks'])
        receipt['steps'].append(step)
        print(json.dumps(step), flush=True)
        if result.returncode or not step['marker_found'] or step.get('zero_failures_skips') is False:
            raise RuntimeError('Native receiving failed: ' + name)
    receipt['status'] = 'passed'
except Exception as error:
    receipt['status'] = 'failed'
    receipt['error'] = str(error)
finally:
    try:
        receipt['after'] = guard()
    except Exception as error:
        receipt['status'] = 'failed'
        receipt['guard_error'] = str(error)
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('SQL_NATIVE_' + receipt['status'].upper() + ' source_inputs=' + str(len(pins['files'])), flush=True)
sys.exit(0 if receipt['status'] == 'passed' else 1)
),
]
receipt['scope'] = 'Browser receiving only; Mac already received exact SQLite and native model contracts.'
try:
    receipt['before'] = guard()
    for name, command, marker in steps:
        print('START ' + name, flush=True)
        result = subprocess.run(command, cwd=REPO, env=environment, capture_output=True, text=True, timeout=120)
        (OUT / (name + '.stdout')).write_text(result.stdout)
        (OUT / (name + '.stderr')).write_text(result.stderr)
        step = {'name': name, 'command': command, 'exit': result.returncode,
                'marker_found': re.search(marker, result.stdout, re.M) is not None}
        if name == 'native-contracts':
            step['zero_failures_skips'] = bool(re.search(r'^# fail 0$', result.stdout, re.M)
                                               and re.search(r'^# skipped 0$', result.stdout, re.M))
        if name == 'browser' and (OUT / 'browser/browser-report.json').is_file():
            report = json.loads((OUT / 'browser/browser-report.json').read_text())
            step['browser_status'] = report['status']
            step['browser_checks'] = len(report['checks'])
        receipt['steps'].append(step)
        print(json.dumps(step), flush=True)
        if result.returncode or not step['marker_found'] or step.get('zero_failures_skips') is False:
            raise RuntimeError('Native receiving failed: ' + name)
    receipt['status'] = 'passed'
except Exception as error:
    receipt['status'] = 'failed'
    receipt['error'] = str(error)
finally:
    try:
        receipt['after'] = guard()
    except Exception as error:
        receipt['status'] = 'failed'
        receipt['guard_error'] = str(error)
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('SQL_NATIVE_' + receipt['status'].upper() + ' source_inputs=' + str(len(pins['files'])), flush=True)
sys.exit(0 if receipt['status'] == 'passed' else 1)
