# Linear-programming native browser receiving

This packet receives the exact original RecallWeave bounded continuous LP page and its unchanged learner consumer. Open candidate/courses/linear-programming-explorer.html directly to use the lab; candidate/learner/demo.html is the pinned original learner used for receiving.

All ten planned browser groups are qualified by composition on identical source: six completed groups in browser-v1, then four in browser-v2-remaining. The first run is honestly retained as failed at its following raw-CDP Enter assertion. The separate ordinary-form diagnostic proves the missing Enter character event and receives the unchanged app with the corrected native event. No source edit or repeated first-six suite occurred. Source pins, actual downloads, screenshots, logs and cleanup receipts remain available.

Chrome used a new owned profile for each bounded run, with its sandbox intact. All three child processes exited0; profiles were removed. Source and learner bytes remain exact. Model/lesson and independent UI/package receipts live in the linked ThinkPad source checkpoint; this packet does not repeat those tests. Source integration and hosted gates are pending under the Actions hold.
