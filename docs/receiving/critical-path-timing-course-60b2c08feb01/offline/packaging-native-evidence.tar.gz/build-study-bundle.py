#!/usr/bin/env python3
"""Assemble the accepted lesson into an ordinary offline ZIP; stdlib only."""
import hashlib
import json
from pathlib import Path
import stat
import sys
import zipfile

PINS = json.loads("{\"demo.html\":{\"git\":\"ef7bc3e27e7f161d917ced6a457fad8822802f3f\",\"bytes\":98468},\"courses/critical-path-timing.json\":{\"git\":\"49a84feea08ec76de711557e172ccbc6c5c744e9\",\"bytes\":23233},\"courses/critical-path-timing.md\":{\"git\":\"501be7ae56a040b3e5bfcb251737728576aa278c\",\"bytes\":13731},\"courses/dependency-timing.html\":{\"git\":\"a955954c7d7d900612ee8111cfd29c39febc1723\",\"bytes\":51991},\"courses/dependency-graphs-explorer.html\":{\"git\":\"eda0dfa00efec0127818a66a9009da692c40a379\",\"bytes\":54137},\"courses/dependency-graphs.md\":{\"git\":\"fedb1704e6c14b01cbf03864ac53a65ea5465d31\",\"bytes\":8267},\"courses/dependency-graphs.json\":{\"git\":\"6e36d7113308540eb923fe5f5c83f1ba0b0ac537\",\"bytes\":12121}}")
SOURCE = json.loads("{\"format\":\"recallweave-course-delivery-source/1\",\"repository\":\"Jacob-Met/RecallWeave\",\"issue\":171,\"accepted_commit\":\"be8e9fd6a279a72fc3843da44c52ac109dcd8cd2\",\"accepted_tree\":\"1328c908fbefd52b62ea05ae3c1bcb7e80e9c7b2\",\"delivery\":\"Detached offline study folder; seven unchanged product files plus opening instructions and integrity/provenance manifests.\",\"packaging_precedent\":\"docs/receiving/markov-chains-81ba1ed0179c/offline/README.md\",\"general_pack_boundary\":\"The accepted branch's general pack contains eleven registered courses but omits this timing course, guide and companion. No catalog, registry, builder or product source was changed.\",\"product_files\":{\"demo.html\":{\"git\":\"ef7bc3e27e7f161d917ced6a457fad8822802f3f\",\"bytes\":98468},\"courses/critical-path-timing.json\":{\"git\":\"49a84feea08ec76de711557e172ccbc6c5c744e9\",\"bytes\":23233},\"courses/critical-path-timing.md\":{\"git\":\"501be7ae56a040b3e5bfcb251737728576aa278c\",\"bytes\":13731},\"courses/dependency-timing.html\":{\"git\":\"a955954c7d7d900612ee8111cfd29c39febc1723\",\"bytes\":51991},\"courses/dependency-graphs-explorer.html\":{\"git\":\"eda0dfa00efec0127818a66a9009da692c40a379\",\"bytes\":54137},\"courses/dependency-graphs.md\":{\"git\":\"fedb1704e6c14b01cbf03864ac53a65ea5465d31\",\"bytes\":8267},\"courses/dependency-graphs.json\":{\"git\":\"6e36d7113308540eb923fe5f5c83f1ba0b0ac537\",\"bytes\":12121}},\"packaging_additions\":[\"START-HERE.html\",\"START-HERE.txt\",\"SOURCE.json\",\"SHA256SUMS.json\"],\"limits\":[\"The source course and browser qualification remain those of issue 171; packaging does not repeat or expand them.\",\"No browser/Windows learner execution, installed adoption, main integration or Actions run is claimed by this artifact.\",\"External reference/repository links are optional and outside this offline bundle.\",\"Checksum manifest is an integrity aid, not an authenticated signature.\"]}")
START_TEXT = "RecallWeave: Parallel plans — critical paths and slack\n\n1. Extract the entire ZIP before opening any page. Keep the RecallWeave folder\n   and its courses subfolder together.\n2. Open START-HERE.html, then choose Open the learner. It opens demo.html.\n3. Under Bring your own lesson, choose courses/critical-path-timing.json.\n4. Inspect the preview: \"Parallel plans: critical paths, slack and what a delay\n   changes\" — 16 questions, 4 concepts — with its source and permission statement.\n5. Choose Start this deck explicitly. Previewing alone leaves the current lesson\n   in place; starting replaces the current lesson and practice progress.\n6. Answer the questions, inspect the learning trace, and practice missed questions.\n   Use Download study notes (.txt) when you want to retain a study record.\n\nThe learner initially shows its original bundled lesson. This folder does not\nautomatically import the timing course. The included JSON is the learner input.\nA timing trace downloaded from the companion is a calculation record, not a\ncourse deck and not an input for Bring your own lesson.\n\nOpen courses/dependency-timing.html for the timing companion. Use the worked\nexamples in courses/critical-path-timing.md (a plain-text Markdown guide; open it\nin a text editor if your browser downloads it). The companion's graph explorer\nand graph-guide links are included. Their dependency-graphs.json is a different\nintroductory course; choose critical-path-timing.json for this timing lesson.\n\nThe local learner and explorers require JavaScript, but no server, account,\ninstallation or internet connection. External reference and repository links\nare optional and require internet access. Do not run the pages inside a ZIP preview.\n\nThe examples assume fixed integer durations and unlimited parallelism. They do\nnot estimate calendars, staffing, uncertainty or measured learning efficacy.\nOriginal lesson wording/examples are CC BY 4.0; preserve the course attribution.\nThis does not relicense the learner, companion or referenced works.\n\nSOURCE.json binds the exact accepted source and separates packaging additions.\nSHA256SUMS.json lists every other member's byte length and SHA-256. These hashes\ncheck integrity; they are not an authenticated signature.\n"
START_HTML = "<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>Parallel plans · RecallWeave offline lesson</title>\n<style>\n:root{color-scheme:light;font-family:system-ui,sans-serif;line-height:1.6;color:#183c32;background:#f7f5ee}body{max-width:52rem;margin:auto;padding:1.5rem}h1{line-height:1.15;font-family:Georgia,serif;font-weight:500}a{color:#245940;text-underline-offset:.2em}a:focus-visible{outline:3px solid #925219;outline-offset:4px}nav{display:flex;flex-wrap:wrap;gap:1rem;margin:1.5rem 0}nav a{padding:.7rem 1rem;border:1px solid #245940;border-radius:.4rem}li{margin-bottom:.6rem}code{overflow-wrap:anywhere}aside{padding:1rem;border-left:4px solid #8ca58b;background:#edf1e7}footer{margin-top:2rem;border-top:1px solid #c8d5c7;padding-top:1rem;font-size:.9rem}\n</style>\n</head>\n<body>\n<main>\n<p>RecallWeave · Offline study folder</p>\n<h1>Parallel plans: critical paths, slack and what a delay changes</h1>\n<p>A sixteen-question lesson about parallel prerequisites, latest times, shared slack and tied critical branches.</p>\n<aside><strong>First extract the entire ZIP.</strong> Keep this page, <code>demo.html</code> and the <code>courses</code> folder together.</aside>\n<nav aria-label=\"Study tools\">\n<a href=\"demo.html\">Open the learner</a>\n<a href=\"courses/dependency-timing.html\">Open the timing companion</a>\n<a href=\"courses/critical-path-timing.md\">Read the worked guide (.md)</a>\n</nav>\n<h2>Start the timing lesson</h2>\n<ol>\n<li>Open the learner. Its original bundled lesson appears first.</li>\n<li>Under <strong>Bring your own lesson</strong>, choose the included <code>courses/critical-path-timing.json</code>.</li>\n<li>Inspect the preview for this title, <strong>16 questions</strong>, <strong>4 concepts</strong>, attribution and permission.</li>\n<li>Select <strong>Start this deck</strong>. Previewing preserves the current lesson; explicitly starting replaces it and its practice progress.</li>\n<li>Answer, review the learning trace and practice missed questions. Use <strong>Download study notes (.txt)</strong> to retain a study record.</li>\n</ol>\n<p>The <a href=\"courses/critical-path-timing.json\" download=\"critical-path-timing.json\">exact timing course JSON</a> is already included; there is no need to reconstruct repository files. If the guide opens as a download, read the included Markdown file in a text editor.</p>\n<h2>Explore a worked plan</h2>\n<p>Use the guide's examples with the unchanged timing companion. A companion <em>timing trace</em> is a calculation record, not a learner course file. The companion's original graph explorer and guide links are included; their introductory graph course is separate from this timing lesson.</p>\n<p>The examples use fixed integer durations and unlimited parallelism. They do not estimate calendars, staffing, uncertainty or measured learning efficacy.</p>\n<footer>\n<p>JavaScript is required. These local tools need no server, account or installation. External reference and repository links are optional and need internet access. Open the extracted files, not a ZIP preview.</p>\n<p>The original timing lesson wording/examples are CC BY 4.0 with the attribution retained in the course and guide. That statement does not relicense the learner, companion or referenced works.</p>\n<p><a href=\"START-HERE.txt\">Plain-text instructions</a> · <a href=\"SOURCE.json\">Exact source and packaging provenance</a> · <a href=\"SHA256SUMS.json\">File integrity manifest</a></p>\n</footer>\n</main>\n</body>\n</html>\n"

def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "git": hashlib.sha1(("blob " + str(len(raw)) + "\0").encode() + raw).hexdigest()}

def assemble(source, destination):
    members = {}
    for relative, pin in PINS.items():
        path = source / relative
        if not stat.S_ISREG(path.lstat().st_mode) or path.is_symlink():
            raise ValueError("Expected regular pinned source: " + relative)
        raw = path.read_bytes()
        actual = identity(raw)
        if actual["git"] != pin["git"] or actual["bytes"] != pin["bytes"]:
            raise ValueError("Source identity mismatch: " + relative)
        members[relative] = raw
    members["START-HERE.txt"] = START_TEXT.encode("utf-8")
    members["START-HERE.html"] = START_HTML.encode("utf-8")
    members["SOURCE.json"] = (json.dumps(SOURCE, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    manifest = {"format": "recallweave-offline-pack-v1", "files": [
        {"path": relative, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        for relative, raw in sorted(members.items())
    ]}
    members["SHA256SUMS.json"] = (json.dumps(manifest, ensure_ascii=True, indent=2) + "\n").encode("utf-8")
    # Standard deterministic ZIP metadata follows the existing native packer;
    # deflate keeps this detached course delivery compact, as in prior course ZIPs.
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9, allowZip64=False) as archive:
        for relative, raw in sorted(members.items()):
            entry = zipfile.ZipInfo("RecallWeave/" + relative, (1980, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.create_version = 20
            entry.extract_version = 20
            entry.external_attr = (stat.S_IFREG | 0o644) << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.flag_bits = 0
            entry.extra = b""
            entry.comment = b""
            archive.writestr(entry, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    for relative in PINS:
        if (source / relative).read_bytes() != members[relative]:
            raise ValueError("Source changed during packaging: " + relative)
    return {"archive": identity(destination.read_bytes()), "members": [
        {"path": relative, **identity(raw), "origin": "unchanged accepted product" if relative in PINS else "packaging addition"}
        for relative, raw in sorted(members.items())
    ]}

if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python build-study-bundle.py PINNED_SOURCE NEW.zip")
    print(json.dumps(assemble(Path(sys.argv[1]), Path(sys.argv[2])), ensure_ascii=False, indent=2))
