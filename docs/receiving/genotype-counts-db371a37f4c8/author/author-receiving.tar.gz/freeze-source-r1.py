import datetime,hashlib,json,pathlib
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
manifest=json.loads((R/'CANDIDATE-MANIFEST-r3.json').read_text(encoding='utf-8'))
for entry in manifest:assert pin(R/'candidate-r3'/entry['path'])=={k:entry[k] for k in ['bytes','sha256','git']}
selected=[e for e in manifest if e['path'].startswith('courses/genotype-counts') or e['path']=='tests/genotype-counts-course.test.mjs'];assert len(selected)==4
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'canonicalCommit':'ec07bf3989132130759e5c00c6cb02eef19709d3','canonicalTree':'a839b6877bf2824f134443829d1ce62e1bd79e50','sourceRoot':str(R/'candidate-r3'),'all30FilesExact':True,'additions':selected,'manifest':pin(R/'CANDIDATE-MANIFEST-r3.json'),'runtimeManifest':pin(R/'RUNTIME-MANIFEST-r2.json'),'portablePackage':pin(R/'portable-r2/genotype-counts-portable.zip')}
(R/'SOURCE-FREEZE-r1.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode('utf-8'));print(json.dumps(receipt))
