const fs=require('node:fs'),{spawn}=require('node:child_process');
const root="/home/jacob/snap/chromium/common/recallweave-vector-import-db371a37f4c8-root";
const [label,project]=process.argv.slice(2);
if(!/^evidence-[a-z0-9-]+$/.test(label||''))throw Error('Explicit evidence label required');
if(!project||!project.startsWith(root+'/receiving-')||!fs.statSync(project).isDirectory())throw Error('Explicit owned receiver project required');
const floor=256*1024*1024,free=()=>{const s=fs.statfsSync(root);return s.bavail*s.bsize};
const initialAvailable=free();if(initialAvailable<floor)throw Error('Native capacity preflight refused: '+initialAvailable);
const evidence=root+'/'+label;
fs.mkdirSync(evidence,{recursive:true});
if(fs.existsSync(evidence+'/runner-receipt.json'))throw Error('Existing evidence must be retained');
const log=fs.openSync(evidence+'/process.log','w'),started=new Date().toISOString();
const child=spawn('/usr/bin/node',[root+'/course/verification/vector-geometry-db371a37f4c8/course-browser.mjs',project],{detached:true,env:{...process.env,RECALLWEAVE_CHROMIUM:'/snap/bin/chromium',RECALLWEAVE_PROFILE_ROOT:root+'/profiles',RECALLWEAVE_EVIDENCE_DIR:evidence},stdio:['ignore',log,log]});
let timedOut=false,capacityRefusal=false,force,finished=false,minAvailable=initialAvailable;
function stop(){try{process.kill(-child.pid,'SIGTERM')}catch{};force=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL')}catch{}},3000)}
const timer=setTimeout(()=>{timedOut=true;stop()},180000);
const capacityTimer=setInterval(()=>{const n=free();minAvailable=Math.min(n,minAvailable);if(n<floor&&!capacityRefusal){capacityRefusal=true;stop()}},1000);
console.log(JSON.stringify({started,ownedChild:child.pid,evidence,project,initialAvailable,capacityFloor:floor}));
function complete(code,signal,error){if(finished)return;finished=true;clearTimeout(timer);clearInterval(capacityTimer);if(force)clearTimeout(force);fs.closeSync(log);const receipt={started,finished:new Date().toISOString(),pid:child.pid,project,code,signal,error:error?String(error):undefined,timedOut,capacityRefusal,initialAvailable,minAvailable,finalAvailable:free(),capacityFloor:floor};fs.writeFileSync(evidence+'/runner-receipt.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));process.exitCode=code??1}
child.on('error',error=>complete(null,null,error));child.on('exit',(code,signal)=>complete(code,signal));
