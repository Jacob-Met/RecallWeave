import base64
import contextlib
import datetime as dt
import gzip
import hashlib
import io
import json
import os
import platform
import sys
import tarfile
import time
import traceback

def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def encoded(document, pretty=False):
    return (json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2 if pretty else None, separators=None if pretty else (",", ":")) + "\n").encode("utf-8")

def pin(name, data):
    return {"path": name, "mode": "100644", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "gitBlob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}

bundle = json.loads(sys.argv[1])
controller_source = sys.orig_argv[sys.orig_argv.index("-c") + 1]
payloads = {
    "CONTRACT.json": bundle["contract"].encode("utf-8"),
    "generate_oracle.py": bundle["generator"].encode("utf-8"),
    "run_oracle.py": controller_source.encode("utf-8"),
    "capacity-receipt.json": encoded(bundle["capacity"], pretty=True),
}
before = [pin(name, payloads[name]) for name in ("CONTRACT.json", "generate_oracle.py", "run_oracle.py")]
payloads["oracle-source-freeze.json"] = encoded({
    "frozenUTC": stamp(),
    "sourceCustody": "Independent expectations authored before access to optimizer counting implementation, course answer key or author tests.",
    "inputs": before,
    "allowedMechanism": "Python standard library itertools and exact integer math only.",
    "memoryOnlyExecution": True,
}, pretty=True)
stdout = io.StringIO()
stderr = io.StringIO()
started = stamp()
clock = time.monotonic()
status = "passed"
exit_code = 0
summary = None
with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
    try:
        namespace = {"__name__": "independent_counting_oracle", "__file__": "<frozen-generate_oracle.py>"}
        exec(compile(bundle["generator"], "<frozen-generate_oracle.py>", "exec"), namespace)
        document, summary = namespace["build"](payloads["CONTRACT.json"])
        payloads["blind-oracles.json"] = encoded(document)
        payloads["enumeration-receipt.json"] = encoded(summary, pretty=True)
    except BaseException:
        status = "failed"
        exit_code = 1
        traceback.print_exc()
payloads["oracle.stdout"] = stdout.getvalue().encode("utf-8")
payloads["oracle.stderr"] = stderr.getvalue().encode("utf-8")
after = [pin(name, payloads[name]) for name in ("CONTRACT.json", "generate_oracle.py", "run_oracle.py")]
if before != after:
    status = "failed"
    exit_code = 1
receipt = {
    "format": "independent-counting-controller-v1",
    "startedUTC": started,
    "finishedUTC": stamp(),
    "elapsedSeconds": time.monotonic() - clock,
    "invocation": "python3 -I -B -c <exact run_oracle.py> <JSON bundle containing exact generator and contract>",
    "cwd": os.getcwd(),
    "exitCode": exit_code,
    "sourceInputsUnchanged": before == after,
    "inputsBefore": before,
    "inputsAfter": after,
    "stdout": pin("oracle.stdout", payloads["oracle.stdout"]),
    "stderr": pin("oracle.stderr", payloads["oracle.stderr"]),
    "python": sys.version,
    "executable": sys.executable,
    "platform": platform.platform(),
    "implementationAccessBeforeFreeze": False,
    "keyAccessBeforeFreeze": False,
    "memoryOnlyExecution": True,
    "status": status,
    "enumeration": summary,
}
payloads["controller-receipt.json"] = encoded(receipt, pretty=True)
manifest = {
    "format": "independent-counting-oracle-manifest-v1",
    "frozenUTC": stamp(),
    "status": status,
    "sourceAndExpectationsFrozenBeforeImplementationRead": True,
    "files": [pin(name, payloads[name]) for name in sorted(payloads)],
}
payloads["MANIFEST.json"] = encoded(manifest, pretty=True)
archive_buffer = io.BytesIO()
with tarfile.open(fileobj=archive_buffer, mode="w", format=tarfile.PAX_FORMAT) as archive:
    for name in sorted(payloads):
        data = payloads[name]
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        entry.uid = entry.gid = 0
        entry.mtime = 0
        entry.uname = entry.gname = ""
        archive.addfile(entry, io.BytesIO(data))
compressed = gzip.compress(archive_buffer.getvalue(), mtime=0)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(compressed)), mode="r:") as archive:
    members = archive.getmembers()
    if sorted(member.name for member in members) != sorted(payloads):
        raise RuntimeError("Archive member mismatch")
    for member in members:
        if archive.extractfile(member).read() != payloads[member.name]:
            raise RuntimeError("Archive payload mismatch: " + member.name)
result = {
    "status": status,
    "manifest": pin("MANIFEST.json", payloads["MANIFEST.json"]),
    "oracle": pin("blind-oracles.json", payloads["blind-oracles.json"]) if "blind-oracles.json" in payloads else None,
    "archive": pin("blind-counting-oracle-v1.tar.gz", compressed),
    "archiveBase64": base64.b64encode(compressed).decode("ascii"),
    "payloadFiles": len(payloads),
    "summary": summary,
    "sourcePins": before,
}
print(json.dumps(result, sort_keys=True))
raise SystemExit(exit_code)
