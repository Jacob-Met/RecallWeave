import fs from "node:fs/promises";
import { createHash } from "node:crypto";
import { join } from "node:path";
const root = process.argv[2];
const packet = JSON.parse(await fs.readFile(join(root, "TRANSFER.json"), "utf8"));
const manifest = [];
for (const file of packet.files) {
  if (!/^[A-Za-z0-9_./-]+$/.test(file.path) || file.path.split("/").some(p => p === "..")) throw new Error("Unsafe source path");
  const bytes = Buffer.from(file.content, "utf8");
  const sha256 = createHash("sha256").update(bytes).digest("hex");
  const gitBlob = createHash("sha1").update("blob " + bytes.length + "\0").update(bytes).digest("hex");
  if (sha256 !== file.sha256 || gitBlob !== file.gitBlob) throw new Error("Transfer pin mismatch: " + file.path);
  const target = join(root, "candidate", file.path);
  await fs.mkdir(join(target, ".."), { recursive: true });
  await fs.writeFile(target, bytes, { flag: "wx" });
  const actual = await fs.readFile(target);
  if (!actual.equals(bytes)) throw new Error("Readback mismatch: " + file.path);
  manifest.push({ path: file.path, bytes: bytes.length, sha256, gitBlob });
}
const receipt = { schema: "recallweave.lp-la7-source-receiving/1", repository: packet.repository, base: packet.base,
 tree: packet.tree, sourceOrigin: packet.sourceOrigin, node: process.version, executable: process.execPath,
 files: manifest, status: "passed", browserExecuted: false };
await fs.writeFile(join(root, "SOURCE-RECEIPT.json"), JSON.stringify(receipt, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(receipt));
