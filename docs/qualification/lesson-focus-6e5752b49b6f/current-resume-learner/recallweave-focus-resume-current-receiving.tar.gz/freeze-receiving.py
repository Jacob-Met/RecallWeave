from pathlib import Path
import hashlib,json,re,tarfile
ROOT=Path("/tmp/recallweave-focus-resume-6e5752b49b6f-github")
sha=lambda data:hashlib.sha256(data).hexdigest()
source=json.loads((ROOT/"runtime-source.json").read_text())
receipt=json.loads((ROOT/"r3/receiving.json").read_text())
assert receipt["passed"] is True and len(receipt["cases"])==2 and len(receipt["downloads"])==8
assert receipt["receiver_sha256"]=="4dd632f2f1dc02507bc3cc8b802c8fdd234bf07b977a904c0431e6430a645b72"
assert sha((ROOT/"receive-focused-resume.mjs").read_bytes())==receipt["receiver_sha256"]
for row in source["files"]:
    data=(ROOT/"source"/row["path"]).read_bytes()
    assert sha(data)==row["sha256"]
    assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==row["sha"]
source_input=(ROOT/"actual-focused-lesson.json").read_bytes()
assert len(source_input)==3285 and sha(source_input)=="544dced1fc8c909dd2a8353fe28bb7235effb5e871a38eebcdf377b3cd505475"
deck=json.loads(source_input)
download_rows=[]
for row in receipt["downloads"]:
    data=(ROOT/"r3"/row["filename"]).read_bytes()
    assert sha(data)==row["sha256"] and len(data)==row["bytes"]
    download_rows.append({"path":"r3/"+row["filename"],"bytes":len(data),"sha256":sha(data)})
for mode in ["modular","standalone-phone"]:
    saved=json.loads((ROOT/"r3"/(mode+"-two-answer-feedback.json")).read_text())
    again=json.loads((ROOT/"r3"/(mode+"-resaved-feedback.json")).read_text())
    assert saved["deck"]==deck==again["deck"]
    saved.pop("savedAt");again.pop("savedAt");assert saved==again
for suffix in ["resumed-notebook.txt","fresh-course-resumed.txt"]:
    left=(ROOT/"r3"/("modular-"+suffix)).read_text()
    right=(ROOT/"r3"/("standalone-phone-"+suffix)).read_text()
    scrub=lambda text:re.sub(r"^Saved: .*$","Saved: <actual timestamp>",text,flags=re.M)
    assert scrub(left)==scrub(right)
assert receipt["cases"][0]["firstAnswers"]==receipt["cases"][1]["firstAnswers"]
assert receipt["page_errors"]==[] and receipt["external_requests"]==[]
audit={"source_commit":source["commit"],"source_tree":source["tree"],"source_files_unchanged":len(source["files"]),"actual_downloads":download_rows,"saved_resaved_equal_except_savedAt":True,"mode_note_pairs_equal_except_actual_Saved_timestamp":True,"both_modes_have_same_canonical_first_answers":True,"passed":True,"receipt_sha256":sha((ROOT/"r3/receiving.json").read_bytes()),"phone_visual_inspection":"Accepted actual 390px r3 screenshot in receiving agent: readable preview, explicit replace/retention copy, visible focus and both actions fit."}
(ROOT/"native-file-audit.json").write_text(json.dumps(audit,indent=2)+"\n")
paths=[p for p in ROOT.rglob("*") if p.is_file() and p.name not in {"source-transfer.base64","evidence-manifest.json","packet.json"}]
paths=sorted(paths,key=lambda p:p.relative_to(ROOT).as_posix())
manifest={"source_commit":source["commit"],"source_tree":source["tree"],"members":[{"path":p.relative_to(ROOT).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())} for p in paths]}
(ROOT/"evidence-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
paths.append(ROOT/"evidence-manifest.json")
archive=ROOT.parent/"recallweave-focus-resume-current-receiving-6e5752b49b6f.tar.gz"
with tarfile.open(archive,"w:gz") as output:
    for p in paths:output.add(p,arcname=p.relative_to(ROOT).as_posix(),recursive=False)
with tarfile.open(archive,"r:gz") as received:
    names=received.getnames()
    assert len(names)==len(manifest["members"])+1
    for row in manifest["members"]:
        data=received.extractfile(row["path"]).read()
        assert len(data)==row["bytes"] and sha(data)==row["sha256"]
packet={"archive":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),"manifest_sha256":sha((ROOT/"evidence-manifest.json").read_bytes()),"members":len(paths),"source_commit":source["commit"],"source_tree":source["tree"],"r3_receipt_sha256":audit["receipt_sha256"],"r1_receipt_sha256":sha((ROOT/"r1/receiving.json").read_bytes()),"r2_receipt_sha256":sha((ROOT/"r2/receiving.json").read_bytes()),"receiver_sha256":receipt["receiver_sha256"],"native_file_audit_sha256":sha((ROOT/"native-file-audit.json").read_bytes()),"result":"accepted: 2 native browser groups, 8 actual downloads; 2 receiver-only corrections preserved"}
(ROOT/"packet.json").write_text(json.dumps(packet,indent=2)+"\n")
print(json.dumps(packet))
