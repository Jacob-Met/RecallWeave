from pathlib import Path
import json,hashlib,subprocess,os,time,platform
root=Path('/dev/shm/rw490f-final/source')
out=Path('/dev/shm/rw490f-final/evidence')
tmp=Path('/dev/shm/rw490f-tmp');tmp.mkdir(exist_ok=True)
manifest=json.loads((out/'source-manifest.json').read_text())
before={x['path']:x['sha256'] for x in manifest['files']}
for name,expected in before.items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
env=os.environ.copy()
env.update({'TMPDIR':str(tmp),'NODE_PATH':'/home/jacob/.cache/returnby-backup-8b336fefde84/node_modules','BROWSER_BIN':'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome','RECALLWEAVE_EVIDENCE_DIR':str(out),'PYTHONDONTWRITEBYTECODE':'1'})
report={'base':manifest['receiving_base'],'manifest_sha256':hashlib.sha256((out/'source-manifest.json').read_bytes()).hexdigest(),'source_before':before,'node':subprocess.check_output(['node','--version'],text=True).strip(),'browser':subprocess.check_output([env['BROWSER_BIN'],'--version'],text=True).strip(),'python':platform.python_version(),'checks':[]}
stages=[('unit',['node','--test']+[str(p.relative_to(root)) for p in sorted((root/'tests').glob('*.test.mjs'))]),('import',['node','tests/deck_browser_smoke.cjs']),('trace',['node','tools/check_trace_browser.mjs','--browser',env['BROWSER_BIN'],'--output','/dev/shm/rw490f-final/trace'])]
for name,cmd in stages:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:
  process=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=140)
 record={'name':name,'command':cmd,'exit_code':process.returncode,'seconds':round(time.monotonic()-start,3),'log':name+'.log'}
 report['checks'].append(record)
 (out/'native-receiving.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if process.returncode: break
after={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in before}
report['source_after']=after;report['source_unchanged']=before==after
report['status']='passed' if all(x['exit_code']==0 for x in report['checks']) and len(report['checks'])==len(stages) and before==after else 'failed'
(out/'native-receiving.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'source_unchanged':report['source_unchanged'],'receipt_sha256':hashlib.sha256((out/'native-receiving.json').read_bytes()).hexdigest()}),flush=True)
