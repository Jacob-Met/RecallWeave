import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import zlib from 'node:zlib';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
const root=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const parse=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'')),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const pin=p=>{const b=fs.readFileSync(p),s=fs.statSync(p,{bigint:true});return {bytes:b.length,sha256:hash(b),git:crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex'),mtime_ns:s.mtimeNs.toString()};};
const started=new Date().toISOString(),input=parse(path.join(root,'CANDIDATE-ADMISSION-INPUT.json')),offer=input.offer,runtime=input.runtime,freeze=parse(path.join(root,'ORIGINAL-FREEZE.json')),blindFreeze=parse(path.join(root,'BLIND-ANSWER-FREEZE.json'));
const verifyFreeze=()=>{assert.deepEqual(pin(path.join(root,'ORIGINAL-FREEZE.json')),input.originalFreeze);assert.deepEqual(pin(path.join(root,'BLIND-ANSWER-FREEZE.json')),input.blindFreeze);assert.deepEqual(pin(path.join(root,'COURSE-BLIND.json')),blindFreeze.projectionCopy);assert.deepEqual(pin(path.join(root,'COURSE-ANSWERS.json')),blindFreeze.answers);for(const f of freeze.artifacts)assert.deepEqual(pin(path.join(root,f.path)),{bytes:f.bytes,sha256:f.sha256,git:f.git,mtime_ns:f.mtime_ns});for(const f of freeze.original){assert.deepEqual(pin(path.join(root,'original',f.path)),f.receiver);assert.deepEqual(pin(path.join(input.originalOffer.originalRoot,f.path)),f.source);}};
verifyFreeze();assert.equal(parse(path.join(root,'ORIGINAL-FREEZE-r1-EXIT.json')).exitCode,0);assert.equal(parse(path.join(root,'BLIND-FREEZE-r1-EXIT.json')).exitCode,0);
assert.equal(freeze.candidateQuestionsRead,false);assert.equal(blindFreeze.candidateCourseRead,false);assert.equal(blindFreeze.authoredTestsOrResultsRead,false);
assert.equal(freeze.sourceCommit,offer.canonical.commit);assert.equal(freeze.sourceTree,offer.canonical.tree);
const manifestPin=pin(offer.manifest.path);for(const k of ['bytes','sha256','git'])assert.equal(manifestPin[k],offer.manifest[k]);assert.deepEqual(parse(offer.manifest.path),runtime);
const candidate=path.join(root,'candidate');fs.mkdirSync(candidate,{recursive:false});const received=[];
for(const f of runtime){assert.ok(!f.path.startsWith('/')&&!/[\\:]/.test(f.path)&&f.path.split('/').every(s=>s&&s!=='.'&&s!=='..'));const source=path.join(offer.sourceRoot,f.path),actual=pin(source);for(const k of ['bytes','sha256','git'])assert.equal(actual[k],f[k]);const original=freeze.original.find(x=>x.path===f.path);if(original){assert.equal(actual.sha256,original.source.sha256);assert.equal(actual.git,original.source.git);}const destination=path.join(candidate,f.path);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.copyFileSync(source,destination,fs.constants.COPYFILE_EXCL);const copied=pin(destination);for(const k of ['bytes','sha256','git'])assert.equal(copied[k],f[k]);received.push({path:f.path,source:actual,receiver:copied});}
assert.equal(received.length,29);assert.equal(received.filter(x=>freeze.original.some(o=>o.path===x.path)).length,26);
const zipSource=offer.portablePackage.path,sourceZip=pin(zipSource);for(const k of ['bytes','sha256','git'])assert.equal(sourceZip[k],offer.portablePackage[k]);const zipPath=path.join(root,'genotype-counts-portable.zip');fs.copyFileSync(zipSource,zipPath,fs.constants.COPYFILE_EXCL);const zip=fs.readFileSync(zipPath);
let end=-1;for(let p=zip.length-22;p>=Math.max(0,zip.length-65557);p--)if(zip.readUInt32LE(p)===0x06054b50&&p+22+zip.readUInt16LE(p+20)===zip.length){end=p;break;}
assert.ok(end>=0);assert.equal(zip.readUInt16LE(end+4),0);assert.equal(zip.readUInt16LE(end+6),0);
const count=zip.readUInt16LE(end+10),centralSize=zip.readUInt32LE(end+12),centralStart=zip.readUInt32LE(end+16);
assert.equal(count,6);assert.equal(zip.readUInt16LE(end+8),count);assert.equal(centralStart+centralSize,end);
const portable=path.join(root,'portable');fs.mkdirSync(portable,{recursive:false});const members=[],seen=new Set();let cursor=centralStart,total=0;
function crc32(data){let crc=0xffffffff;for(const byte of data){crc^=byte;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
for(let i=0;i<count;i++){
  assert.equal(zip.readUInt32LE(cursor),0x02014b50);
  const flags=zip.readUInt16LE(cursor+8),method=zip.readUInt16LE(cursor+10),crc=zip.readUInt32LE(cursor+16),compressed=zip.readUInt32LE(cursor+20),size=zip.readUInt32LE(cursor+24),nl=zip.readUInt16LE(cursor+28),xl=zip.readUInt16LE(cursor+30),cl=zip.readUInt16LE(cursor+32),external=zip.readUInt32LE(cursor+38),local=zip.readUInt32LE(cursor+42);
  assert.equal(flags&1,0);assert.ok(method===0||method===8);assert.equal(zip.readUInt16LE(cursor+34),0);assert.ok(size<=1024*1024);total+=size;assert.ok(total<=2*1024*1024);
  const rawName=zip.subarray(cursor+46,cursor+46+nl),name=rawName.toString('utf8');assert.ok(Buffer.from(name).equals(rawName));assert.ok(!/[\\:]/.test(name)&&!name.startsWith('/')&&!name.endsWith('/'));assert.ok(name.split('/').every(s=>s&&s!=='.'&&s!=='..'&&!/[. ]$/.test(s)));assert.ok(!seen.has(name.toLowerCase()));seen.add(name.toLowerCase());assert.notEqual((external>>>16)&0xf000,0xa000);
  assert.equal(zip.readUInt32LE(local),0x04034b50);assert.equal(zip.readUInt16LE(local+8),method);const lnl=zip.readUInt16LE(local+26),lxl=zip.readUInt16LE(local+28);
  assert.ok(zip.subarray(local+30,local+30+lnl).equals(rawName));const start=local+30+lnl+lxl;assert.ok(start+compressed<=centralStart);
  const data=method===0?Buffer.from(zip.subarray(start,start+compressed)):zlib.inflateRawSync(zip.subarray(start,start+compressed),{maxOutputLength:1024*1024});
  assert.equal(data.length,size);assert.equal(crc32(data),crc);
  const dst=path.join(portable,name);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,data,{flag:'wx'});
  const identity=pin(dst),bound=runtime.filter(f=>f.sha256===identity.sha256&&f.bytes===identity.bytes).map(f=>f.path);
  members.push({path:name,method,crc32:crc,compressed_bytes:compressed,...identity,bound_runtime_paths:bound});cursor+=46+nl+xl+cl;
}
assert.equal(cursor,end);
for(const expected of ['courses/genotype-counts-worksheet.html','demo.html','courses/genotype-counts.json','courses/genotype-counts.md'])assert.equal(members.filter(m=>m.bound_runtime_paths.includes(expected)).length,1,expected+' package identity');
const auxiliary=members.filter(m=>m.bound_runtime_paths.length===0);assert.equal(auxiliary.length,2);assert.ok(auxiliary.every(m=>/\.(json|txt|md)$/i.test(m.path)));

const course=parse(path.join(candidate,'courses/genotype-counts.json')),blind=parse(path.join(root,'COURSE-BLIND.json')),answers=parse(path.join(root,'COURSE-ANSWERS.json'));
const projection=course.items.map(({id,prompt,options})=>({id,prompt,options}));assert.deepEqual(projection,blind);
const deckModule=await import(pathToFileURL(path.join(root,'original/src/deck.mjs')).href);const validated=deckModule.validateDeck(course);assert.equal(validated.items.length,14);
assert.deepEqual(validated,course);for(const expected of answers){const item=course.items.find(q=>q.id===expected.id);assert.equal(item.answer,expected.answer,expected.id+' author key differs from independently frozen answer');}
for(const f of received){assert.deepEqual(pin(path.join(offer.sourceRoot,f.path)),f.source);assert.deepEqual(pin(path.join(candidate,f.path)),f.receiver);}
verifyFreeze();assert.deepEqual(pin(zipSource),sourceZip);
const result={schema:'recall261-independent-candidate-admission-v1',at:new Date().toISOString(),started,pid:process.pid,parent:process.ppid,status:'passed',canonical:offer.canonical,sourceCustody:input.sourceCustody,originalFreeze:pin(path.join(root,'ORIGINAL-FREEZE.json')),blindFreeze:pin(path.join(root,'BLIND-ANSWER-FREEZE.json')),originalSourcesUnchanged:freeze.original.length,preCandidateArtifactsUnchanged:freeze.artifacts.length,candidateRoot:candidate,files:received,sourceAndReceiverUnchanged:true,package:{source:sourceZip,received:pin(zipPath),path:zipPath,portableRoot:portable,members,safeUniqueRegularMembers:members.length,totalExpandedBytes:total},course:{blindProjectionExact:true,independentlyFrozenKeysMatch:14,untouchedOriginalParserAccepted:true,allValidatedFieldsMatchSource:true,explanationsAwaitRootReading:true},authoredTestsOrResultsRead:false};
fs.writeFileSync(path.join(root,'CANDIDATE-ADMISSION.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:result.status,pid:process.pid,runtimeFiles:received.length,preCandidateArtifactsExact:freeze.artifacts.length,packageMembers:members.map(m=>({path:m.path,bytes:m.bytes,bound:m.bound_runtime_paths})),courseKeysMatch:14}));
