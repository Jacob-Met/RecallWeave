import pathlib,json,hashlib,subprocess,os,signal,time
R=pathlib.Path('/dev/shm/hamon-probability-cd1df0f1ee24/receiving-browser');H=pathlib.Path('/home/jacob/hamon-probability-cd1df0f1ee24/receiving-browser');name='feedback-76921-attempt1';out=R/'runs'/name;logs=R/'runs'/(name+'-process')
assert not out.exists() and not logs.exists() and not (H/'runs'/name).exists()
freeze=json.loads((R/'feedback-freeze-v1.json').read_text());assert freeze['syntax']['exit']==0
for f in freeze['files']:assert hashlib.sha256((R/f['path']).read_bytes()).hexdigest()==f['sha256']
capacity={}
for p in [H,R]:
 s=os.statvfs(p);capacity[str(p)]=s.f_bavail*s.f_frsize
assert capacity[str(H)]>=268435456 and capacity[str(R)]>=134217728
mem=next(int(x.split()[1])*1024 for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'));assert mem>=536870912
logs.mkdir()
command=['/usr/bin/node',str(R/'feedback-receiver-v1.mjs')]
pre={'command':command,'frozen_inputs':freeze['files'],'capacity_before':capacity,'mem_available_before':mem,'timeout_seconds':90,'automatic_retries':0};(logs/'preflight.json').write_text(json.dumps(pre,indent=2)+'\n')
start=time.time();p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
try:stdout,stderr=p.communicate(timeout=90)
except subprocess.TimeoutExpired:
 timed=True;os.killpg(p.pid,signal.SIGTERM)
 try:stdout,stderr=p.communicate(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
(logs/'stdout.log').write_bytes(stdout);(logs/'stderr.log').write_bytes(stderr)
v={**pre,'node_exit':p.returncode,'timed_out':timed,'elapsed_seconds':time.time()-start,'stdout_bytes':len(stdout),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_bytes':len(stderr),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'inputs_unchanged':all(hashlib.sha256((R/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in freeze['files'])}
if (out/'receipt.json').exists():
 x=json.loads((out/'receipt.json').read_text());v['browser_summary']={k:x.get(k) for k in ['passed','failed','fatal','pass','browserClosed','sourceUnchanged']}
(logs/'process.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
raise SystemExit(1 if timed or not v['inputs_unchanged'] else p.returncode)
