import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
import {selfCheck} from './reference-oracle.mjs';
const root=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const read=p=>fs.readFileSync(p);
const parse=p=>JSON.parse(read(p).toString('utf8').replace(/^\uFEFF/,''));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const pin=p=>{const b=read(p),s=fs.statSync(p,{bigint:true});return {bytes:b.length,sha256:hash(b),mtime_ns:s.mtimeNs.toString(),git:crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex')};};
const write=(name,value)=>fs.writeFileSync(path.join(root,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const start=new Date().toISOString(),inputs=parse(path.join(root,'ADMISSION-INPUT.json')),before=[];
assert.equal(process.version,inputs.node.version);assert.equal(pin(process.execPath).sha256,inputs.node.sha256);
assert.equal(process.execPath.toLowerCase(),inputs.node.path.replaceAll('/','\\').toLowerCase());
const sourceRoot=inputs.original.original_root,destination=path.join(root,'original');
fs.mkdirSync(destination,{recursive:false});fs.mkdirSync(path.join(root,'tmp'),{recursive:true});fs.mkdirSync(path.join(root,'downloads'),{recursive:true});
for(const f of inputs.original.files){
  assert.ok(!f.path.startsWith('/')&&!f.path.split('/').includes('..'));
  const src=path.join(sourceRoot,f.path),s=fs.lstatSync(src);assert.ok(s.isFile()&&!s.isSymbolicLink());
  const actual=pin(src);assert.equal(actual.bytes,f.bytes);assert.equal(actual.sha256,f.sha256);assert.equal(actual.git,f.git);
  const dst=path.join(destination,f.path);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(src,dst,fs.constants.COPYFILE_EXCL);assert.deepEqual({...pin(dst),mtime_ns:actual.mtime_ns},actual);
  before.push({path:f.path,source:actual,receiver:pin(dst)});
}
function listFiles(dir,prefix=''){let result=[];for(const e of fs.readdirSync(dir,{withFileTypes:true})){const rel=prefix?prefix+'/'+e.name:e.name;if(e.isDirectory())result=result.concat(listFiles(path.join(dir,e.name),rel));else{assert.ok(e.isFile(),rel+' unexpected nonregular donor');result.push(rel);}}return result.sort();}
assert.deepEqual(listFiles(inputs.donor_root),Object.keys(inputs.donor).sort());
const donor=[];
for(const [rel,expected]of Object.entries(inputs.donor)){const actual=pin(path.join(inputs.donor_root,rel));assert.equal(actual.bytes,expected.bytes);assert.equal(actual.sha256,expected.sha256);donor.push({path:rel,...actual});}
const model=await import(pathToFileURL(path.join(destination,'src/deck.mjs')).href);
const originalFixture=parse(path.join(root,'ORIGINAL-DECK.json')),sourceSnapshot=JSON.stringify(originalFixture);
const accepted=model.validateDeck(originalFixture);assert.equal(accepted.items.length,2);assert.ok(Object.isFrozen(accepted)&&Object.isFrozen(accepted.items)&&Object.isFrozen(accepted.items[0].options));assert.notEqual(accepted.items,originalFixture.items);
assert.deepEqual(model.parseDeck(model.serializeDeck(originalFixture)),accepted);assert.equal(JSON.stringify(originalFixture),sourceSnapshot);
const malformed=structuredClone(originalFixture);malformed.items[1].answer="1";assert.throws(()=>model.validateDeck(malformed));assert.throws(()=>model.parseDeck(JSON.stringify(malformed)));assert.deepEqual(accepted,model.parseDeck(sourceSnapshot));
fs.writeFileSync(path.join(root,'ORIGINAL-INVALID-DECK.json'),JSON.stringify(malformed,null,2)+'\n',{flag:'wx'});
const literals=parse(path.join(root,'LITERAL-GOLD.json')),math=selfCheck(literals);write('ORIGINAL-ORACLE-OBSERVATIONS.json',math);
const blind=parse(path.join(root,'COURSE-BLIND.json')),answers=parse(path.join(root,'COURSE-ANSWERS.json'));
assert.equal(blind.items.length,12);assert.equal(answers.length,12);assert.deepEqual(blind.items.map(x=>x.id),answers.map(x=>x.id));
for(const question of blind.items){assert.ok(!Object.hasOwn(question,'answer')&&!Object.hasOwn(question,'explanation'));const answer=answers.find(a=>a.id===question.id);assert.ok(Number.isInteger(answer.answer)&&answer.answer>=0&&answer.answer<question.options.length);}
const authorBlind=path.join(path.dirname(sourceRoot),'COURSE-BLIND.json');assert.deepEqual(parse(authorBlind),blind);
for(const f of before)assert.deepEqual(pin(path.join(sourceRoot,f.path)),f.source);
const controls=['ADMISSION-INPUT.json','RECEIVING-PLAN.md','CONTRACT.md','PUBLIC-API-ADDENDUM.md','COURSE-BLIND.json','COURSE-ANSWERS.json','LITERAL-GOLD.json','reference-oracle.mjs','ORIGINAL-DECK.json','ORIGINAL-INVALID-DECK.json','ORIGINAL-ORACLE-OBSERVATIONS.json','admit-original.mjs'].map(name=>({path:name,...pin(path.join(root,name))}));
const result={schema:'recall253-root-original-admission-v1',start,end:new Date().toISOString(),pid:process.pid,parent:process.ppid,status:'passed',source_commit:inputs.original.commit,source_tree:inputs.original.tree,source:before,source_unchanged:true,node:{version:process.version,path:process.execPath,...pin(process.execPath)},edge:{path:inputs.edge,...pin(inputs.edge)},donor:{root:inputs.donor_root,files:donor,bytes:donor.reduce((s,f)=>s+f.bytes,0),all_exact:true},original_parser:{groups:3,valid_immutable_copy:true,roundtrip:true,malformed_later_item_refused:true},independent_math:{literal_cases:literals.length,permutation_groups:math.permutationGroups,permutations:math.permutationGroups.reduce((s,g)=>s+g.permutations,0),all_reference_checks_pass:true},course:{questions:blind.items.length,answers_frozen:true,answer_keys_unread:true,author_blind:pin(authorBlind),receiver_blind:pin(path.join(root,'COURSE-BLIND.json')),semantic_projection_exact:true},controls,candidate_exposure:false,browser_executed:false};
write('ORIGINAL-ADMISSION.json',result);console.log(JSON.stringify({status:result.status,pid:process.pid,sourceFiles:before.length,donorFiles:donor.length,math:result.independent_math,course:12}));
