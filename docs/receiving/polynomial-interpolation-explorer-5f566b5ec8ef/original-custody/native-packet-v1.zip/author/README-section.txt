
## Learn polynomial interpolation with exact arithmetic

The original [polynomial interpolation course](courses/polynomial-interpolation.json)
and [worked guide](courses/polynomial-interpolation.md) connect sample constraints,
divided differences, equivalent polynomial forms and extrapolation limits. Bring
the JSON lesson into the existing learner for its ordinary review and practice.

With Node 20 or later, run `node tools/interpolate-polynomial.mjs points.json`
to inspect an authored set of rational samples, or add `--format text` for the
complete terminal table. The command computes exact Newton and monomial
coefficients, verifies every original node and labels requested evaluations by
their position relative to the sampled range. It changes no input files and
requires no external dependencies. The guide defines the bounded JSON contract
and refusal behavior. This contribution adds no browser interface and makes no
claim about learning effectiveness or an unknown function between its samples.
