#!/usr/bin/env python3
"""Single frozen browser receiving attempt; no automatic retry."""
import pathlib, sys, re, json, hashlib, subprocess, os, signal, time
if len(sys.argv) != 6:
    raise SystemExit("Usage: run-browser-receiver.py LAB_HTML LAB_SHA256 RECEIVER_MJS RECEIVER_SHA256 RUN_NAME")
lab, lab_hash, receiver, receiver_hash, name = sys.argv[1:]
assert re.fullmatch(r"[a-z0-9][a-z0-9-]{0,40}", name)
assert all(re.fullmatch(r"[0-9a-f]{64}", h) for h in [lab_hash, receiver_hash])
root = pathlib.Path("/dev/shm/hamon-probability-cd1df0f1ee24/receiving-browser")
home = pathlib.Path("/home/jacob/hamon-probability-cd1df0f1ee24/receiving-browser")
out = root / "runs" / name
logs = root / "runs" / (name + "-process")
assert not out.exists() and not logs.exists() and not (home / "runs" / name).exists()
for path, expected in [(lab, lab_hash), (receiver, receiver_hash)]:
    assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() == expected, ("Frozen input mismatch", path)
capacity = {}
for path in [str(home), str(root)]:
    s = os.statvfs(path); capacity[path] = s.f_bavail * s.f_frsize
assert capacity[str(home)] >= 268435456, ("Home 256MiB admission floor", capacity)
assert capacity[str(root)] >= 134217728, ("Evidence tmpfs128MiB admission floor", capacity)
available = next(int(line.split()[1]) * 1024 for line in pathlib.Path("/proc/meminfo").read_text().splitlines() if line.startswith("MemAvailable:"))
assert available >= 536870912, ("512MiB available memory floor", available)
logs.mkdir(parents=True)
command = ["/usr/bin/node", receiver, lab, str(out)]
preflight = {"command":command,"lab_sha256":lab_hash,"receiver_sha256":receiver_hash,"capacity_before":capacity,"mem_available_before":available,"timeout_seconds":180,"automatic_retries":0}
(logs / "preflight.json").write_text(json.dumps(preflight, indent=2)+"\n")
started = time.time()
p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
timed_out = False
try:
    stdout, stderr = p.communicate(timeout=180)
except subprocess.TimeoutExpired:
    timed_out = True
    os.killpg(p.pid, signal.SIGTERM)
    try:
        stdout, stderr = p.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        stdout, stderr = p.communicate()
(logs / "stdout.log").write_bytes(stdout)
(logs / "stderr.log").write_bytes(stderr)
receipt = {
    **preflight,"exit":p.returncode,"timed_out":timed_out,"elapsed_seconds":time.time()-started,
    "stdout_bytes":len(stdout),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),
    "stderr_bytes":len(stderr),"stderr_sha256":hashlib.sha256(stderr).hexdigest(),
    "lab_source_unchanged":hashlib.sha256(pathlib.Path(lab).read_bytes()).hexdigest()==lab_hash,
    "receiver_source_unchanged":hashlib.sha256(pathlib.Path(receiver).read_bytes()).hexdigest()==receiver_hash,
}
if (out / "browser-receipt.json").exists():
    observed = json.loads((out / "browser-receipt.json").read_text())
    receipt["completed_browser_receipt"] = {k:observed.get(k) for k in ["passed","failed","fatal","pass","browserClosed","sourceUnchanged"]}
(logs / "process.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
sys.exit(1 if timed_out else p.returncode)
