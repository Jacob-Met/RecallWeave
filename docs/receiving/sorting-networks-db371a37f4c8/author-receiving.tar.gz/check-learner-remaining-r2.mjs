import fs from "node:fs/promises";
import path from "node:path";
import {pathToFileURL} from "node:url";
import crypto from "node:crypto";
import assert from "node:assert/strict";
const options = {};
for(let i=2;i<process.argv.length;i+=2) {
  const key=process.argv[i], value=process.argv[i+1];
  if(!["--root","--browser","--playwright","--output"].includes(key)||!value||options[key]) throw new Error("Use --root --browser --playwright --output once each.");
  options[key]=value;
}
for(const key of ["--root","--browser","--playwright","--output"]) if(!options[key])throw new Error("Missing "+key);
const root=path.resolve(options["--root"]), output=path.resolve(options["--output"]);
await fs.mkdir(output); // New-run admission precedes the runtime/finally boundary.
const receipt={started:new Date().toISOString(),pid:process.pid,argv:process.argv,groups:[],downloads:[],pageErrors:[],external:[],screenshots:[],error:null};
const pin=b=>({bytes:b.length,sha256:crypto.createHash("sha256").update(b).digest("hex")});
let browser;
const saveReceipt=()=>fs.writeFile(path.join(output,"receipt.json"),JSON.stringify(receipt,null,2)+"\n");
const group=(name,details)=>{receipt.groups.push({name,at:new Date().toISOString(),...details});};
async function getDownload(page,selector,name) {
 const waiting=page.waitForEvent("download");
 await page.locator(selector).click();
 const d=await waiting, target=path.join(output,name);
 assert.equal(await d.failure(),null);
 await d.saveAs(target);
 const bytes=await fs.readFile(target);
 receipt.downloads.push({name,suggested:d.suggestedFilename(),...pin(bytes)});
 return bytes;
}
try {
 const {chromium}=await import(pathToFileURL(options["--playwright"]).href);
 browser=await chromium.launch({executablePath:options["--browser"],headless:true,chromiumSandbox:true,timeout:45000});
 const context=await browser.newContext({viewport:{width:1200,height:860},acceptDownloads:true});
 context.setDefaultTimeout(12000);
 context.on("page",page=>{
  page.on("pageerror",e=>receipt.pageErrors.push(e.message));
  page.on("request",r=>{if(/^https?:/.test(r.url()))receipt.external.push(r.url());});
 });
 await context.route(/^https?:/,r=>r.abort());

 const actualCourseSource="D:/Hamon/worktrees/recall-sorting-networks-db371a37f4c8/browser-r1/artifacts/lesson.json";
 const rawCourse=await fs.readFile(actualCourseSource);
 assert.equal(pin(rawCourse).sha256,"d214e628bd4ad1f6a4e155498c0f8d46e01af83d63ae180db8f49b7cf1dd4e1e");
 await fs.writeFile(path.join(output,"lesson.json"),rawCourse,{flag:"wx"});
 receipt.actualR1Download={path:actualCourseSource,...pin(rawCourse)};
 const learner=await context.newPage();
 await learner.goto(pathToFileURL(path.join(root,"demo.html")).href);
 const before=await learner.locator("#step-count").textContent();
 await learner.locator("#deck-file").setInputFiles(path.join(output,"lesson.json"));
 assert.equal(await learner.locator("#deck-preview-title").textContent(),JSON.parse(rawCourse).title);
 assert.equal(await learner.locator("#step-count").textContent(),before);
 await learner.locator("#start-deck").click();
 const course=JSON.parse(rawCourse),answered=[];
 for(let i=0;i<12;i++){
  const prompt=await learner.locator("#session-content h2").textContent();
  const item=course.items.find(x=>x.prompt===prompt);assert.ok(item);
  assert.ok(!answered.includes(item.id));
  const choice=i===0?(item.answer+1)%item.options.length:item.answer;
  await learner.locator('[data-choice="'+choice+'"]').click();
  assert.ok((await learner.locator("#feedback-slot").textContent()).includes(item.explanation));
  answered.push(item.id);await learner.locator("#next-button").click();
 }
 const first=await learner.locator("#first-try-summary").textContent();
 assert.match(first,/11 of 12/);
 await learner.locator("#practice-button").click();
 const prompt=await learner.locator("#session-content h2").textContent(),item=course.items.find(x=>x.prompt===prompt);
 await learner.locator('[data-practice-choice="'+item.answer+'"]').click();
 await learner.locator("#practice-next").click();
 assert.equal(await learner.locator("#first-try-summary").textContent(),first);
 const notes=await getDownload(learner,"#save-notes-button","study-notes.txt");
 assert.ok(notes.toString("utf8").includes(course.title));
 for(const item of course.items)assert.ok(notes.toString("utf8").includes(item.prompt));
 group("B5-real-original-learner-preview-answer-review-practice-notes",{answered,firstTry:first,notes:pin(notes)});

 const page=await context.newPage();
 await page.setViewportSize({width:390,height:844});
 await page.goto(pathToFileURL(path.join(root,"courses/sorting-networks-explorer.html")).href);
 await page.locator("#preset").selectOption("0");await page.locator("#load-preset").click();
 await page.locator("#run").click();
 await page.evaluate(()=>scrollTo(0,0));
 await page.screenshot({path:path.join(output,"phone-controls.png"),fullPage:false});
 receipt.screenshots.push("phone-controls.png");
 await page.locator("#verdict-title").scrollIntoViewIfNeeded();
 await page.screenshot({path:path.join(output,"phone-result.png"),fullPage:false});
 receipt.screenshots.push("phone-result.png");
 await learner.screenshot({path:path.join(output,"learner-review.png"),fullPage:false});
 receipt.screenshots.push("learner-review.png");
 await page.setViewportSize({width:1200,height:860});
 await page.evaluate(()=>scrollTo(0,0));
 await page.screenshot({path:path.join(output,"desktop-lab.png"),fullPage:true});
 receipt.screenshots.push("desktop-lab.png");
 assert.deepEqual(receipt.external,[]);assert.deepEqual(receipt.pageErrors,[]);
 group("B6-photography-and-no-external-requests",{screenshots:receipt.screenshots});
 await context.close();
} catch(error) {
 receipt.error=error.stack??String(error);process.exitCode=1;
} finally {
 if(browser){try{await browser.close();receipt.browserClosed=true;}catch(e){receipt.closeError=String(e);process.exitCode=1;}}
 receipt.finished=new Date().toISOString();
 await saveReceipt();
 console.log(JSON.stringify({groups:receipt.groups.map(x=>x.name),downloads:receipt.downloads.length,error:receipt.error,browserClosed:receipt.browserClosed}));
}
