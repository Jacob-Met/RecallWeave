import json,hashlib,urllib.request,tarfile,io,shutil,subprocess,time,traceback
from pathlib import Path
prior=Path("/tmp/hamon-7a9310dad255-recall19-integration")
root=Path("/dev/shm/hamon-7a9310dad255-recall19-integration-current")
expected=json.loads((prior/"expected-current-c00.json").read_text())
def pin(data):
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
def tree_id(rows):
    tree={}
    for row in rows:
        node=tree;parts=row["path"].split("/")
        for part in parts[:-1]:node=node.setdefault(part,{})
        assert parts[-1] not in node
        node[parts[-1]]=(row["mode"],row["git_blob"])
    def emit(node):
        data=b""
        for name,item in sorted(node.items(),key=lambda x:(x[0]+("/" if isinstance(x[1],dict) else "")).encode()):
            mode,sha=("40000",emit(item)) if isinstance(item,dict) else item
            data+=mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(sha)
        return hashlib.sha1(b"tree "+str(len(data)).encode()+b"\0"+data).hexdigest()
    return emit(tree)
def snapshot(where):
    rows=[]
    for p in sorted(where.rglob("*")):
        assert not p.is_symlink(),str(p)
        if p.is_file():rows.append({"path":str(p.relative_to(where)),"mode":"100755" if p.stat().st_mode&0o111 else "100644",**pin(p.read_bytes())})
    return rows
receipt={"started_at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"repository":expected["repository"],"current_head":expected["current_head"],"current_tree":expected["current_tree"],"course_head":expected["course_head"],"prior_source_label":"d202 full composition and qualification retained unchanged","capture_scope":"Every current path outside docs/, plus all original 28 course contributions and three new adoption documents. Complete current docs are preserved through exact public Git tree metadata.","commands":[],"completed":False}
started=time.monotonic()
try:
    public=[{"path":x["path"],"mode":x["mode"],"git_blob":x["sha"]} for x in expected["current_entries"]]
    assert len(public)==496 and tree_id(public)==expected["current_tree"]
    wanted={x["path"]:x for x in expected["current_entries"] if not x["path"].startswith("docs/")}
    assert len(wanted)==86
    url="https://codeload.github.com/Jacob-Met/RecallWeave/tar.gz/"+expected["current_head"]
    with urllib.request.urlopen(url,timeout=45) as response:
        assert response.status==200
        archive=response.read(64*1024*1024+1)
    assert len(archive)<=64*1024*1024
    receipt["download"]={"url":url,"stored_as_full_archive":False,**pin(archive)}
    candidate=root/"candidate";candidate.mkdir()
    seen=set()
    with tarfile.open(fileobj=io.BytesIO(archive),mode="r:gz") as tar:
        for item in tar:
            if not item.isfile():continue
            path=item.name.split("/",1)[1]
            if path not in wanted:continue
            assert path not in seen and not Path(path).is_absolute() and ".." not in Path(path).parts
            data=tar.extractfile(item).read();x=wanted[path]
            assert len(data)==x["size"] and pin(data)["git_blob"]==x["sha"],path
            out=candidate/path;out.parent.mkdir(parents=True,exist_ok=True)
            with out.open("xb") as f:f.write(data)
            assert x["mode"] in ["100644","100755"]
            out.chmod(0o755 if x["mode"]=="100755" else 0o644);seen.add(path)
    assert set(wanted)==seen
    patch=prior/"original-course-28.patch"
    for command in [["git","apply","--check",str(patch)],["git","apply",str(patch)]]:
        p=subprocess.run(command,cwd=candidate,env={"PATH":"/usr/bin:/bin","GIT_OPTIONAL_LOCKS":"0"},capture_output=True)
        receipt["commands"].append({"argv":command,"exit":p.returncode,"stdout":p.stdout.decode(),"stderr":p.stderr.decode()})
        assert p.returncode==0
    proof=Path("docs/receiving/probability-course-7a9310dad255/current-importer-adoption")
    shutil.copytree(prior/"candidate"/proof,candidate/proof)
    (candidate/proof/"README.md").write_bytes((root/"current-adoption-README.md").read_bytes())
    final=snapshot(candidate);fm={x["path"]:x for x in final}
    assert len(final)==117
    assert all(fm[p]["git_blob"]==x["sha"] and fm[p]["mode"]==x["mode"] for p,x in wanted.items())
    assert all(fm[x["path"]]["git_blob"]==x["sha"] and fm[x["path"]]["mode"]==x["mode"] for x in expected["course_entries"])
    acceptance=json.loads((candidate/proof/"independent-assessment.json").read_text())
    assert all(fm[x["path"]]["git_blob"]==x["git_blob"] for x in acceptance["learner_source_pins"])
    public_paths={x["path"] for x in public}
    contributions=[x for x in final if x["path"] not in public_paths];assert len(contributions)==31
    complete=public+contributions;assert len(complete)==527
    manifest={"repository":expected["repository"],"current_head":expected["current_head"],"current_tree":expected["current_tree"],"course_head":expected["course_head"],"source_tree":tree_id(final),"proposed_full_tree":tree_id(complete),"files":final,"complete_proposed_files":complete,"current_public_leaves":496,"native_current_source_leaves":86,"omitted_current_documentation_leaves":410,"all_current_public_leaves_preserved":True,"all_28_original_contribution_paths_preserved":True,"all_14_received_learner_inputs_preserved":True,"source_label":receipt["capture_scope"]}
    with (root/"pre-ci-source-manifest.json").open("x") as f:json.dump(manifest,f,indent=2);f.write("\n")
    receipt.update({"completed":True,"parent_leaves":496,"physical_candidate_leaves":117,"proposed_full_leaves":527,"physical_source_tree":manifest["source_tree"],"proposed_full_tree":manifest["proposed_full_tree"],"all_current_public_leaves_preserved":True,"all_28_original_contribution_paths_preserved":True,"all_14_received_learner_inputs_preserved":True,"source_manifest":pin((root/"pre-ci-source-manifest.json").read_bytes())})
except Exception as error:
    receipt["error"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
finally:
    receipt["finished_at_utc"]=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime());receipt["seconds"]=time.monotonic()-started
    with (root/"capture-composition-receipt.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
    print(json.dumps(receipt,indent=2))
if not receipt["completed"]:raise SystemExit(1)
