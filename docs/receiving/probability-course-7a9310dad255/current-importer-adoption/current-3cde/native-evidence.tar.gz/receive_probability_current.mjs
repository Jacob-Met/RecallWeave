import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const directory = path.resolve(process.argv[2]);
const source = path.join(directory, 'source');
const output = path.join(directory, 'probability-current-control');
await mkdir(output, { recursive: false });
const sha = value => createHash('sha256').update(value).digest('hex');
const manifest = JSON.parse(await readFile(path.join(directory, 'source-manifest.json'), 'utf8'));
const sourceBefore = {};
for (const item of manifest.physical_learner_and_course_files) {
  const data = await readFile(path.join(source, item.path));
  assert.equal(sha(data), item.sha256, item.path);
  sourceBefore[item.path] = sha(data);
}
const originalTraceBytes = await readFile(path.join(directory, 'inputs/probability-prior-paused-trace.json'));
assert.equal(sha(originalTraceBytes), 'dabf33fce202e808dc3513e72a967063291cae0f044e4832a5b9c6fe96d448c8');
const courseBytes = await readFile(path.join(source, 'courses/probability-foundations.json'));
assert.equal(sha(courseBytes), '17a35b359ab5c1f097931bba29dcf7deddc75c98accbf1cced8ae5eca9e9ad01');
const imported = await Promise.all(['deck', 'trace-archive', 'reflections', 'session-export', 'review']
  .map(name => import(pathToFileURL(path.join(source, 'src', name + '.mjs')).href)));
const [{ validateDeck }, { readTraceArchive, createTraceArchive },
  { createReflections, updateReflection, updateApplicationReflection },
  { createStudyNotes }, { currentPracticeItem }] = imported;
const deck = validateDeck(JSON.parse(courseBytes));
assert.equal(deck.items.length, 12);
const originalTrace = JSON.parse(originalTraceBytes);
const restored = readTraceArchive(originalTraceBytes.toString('utf8'), deck);
assert.equal(restored.answers.length, 12);
assert.deepEqual(restored.answers.map(({ item, choice }) => ({ item, choice })), originalTrace.firstAnswers);
assert.deepEqual(restored.mastery, originalTrace.mastery);
assert.equal(restored.summary.correctFirst, 10);
assert.equal(restored.practice.items.length, 2);
assert.deepEqual(restored.practice.answers.map(({ item, choice }) => ({ item, choice })), [{ item: 'pf-c1', choice: 2 }]);
assert.equal(currentPracticeItem(restored.practice).id, 'pf-i2');
const restoredBefore = JSON.stringify(restored);
let notebook = createReflections(deck.items);
const notesById = new Map(deck.items.map((item, index) => [item.id,
  'Current receiving note ' + (index + 1) + ' for ' + item.id + '\nLiteral <tag> & Ω retained.']));
for (const item of [...deck.items].reverse()) notebook = updateReflection(notebook, item.id, notesById.get(item.id));
const application = 'Current probability application reflection.\nThis is receiving input, not a scored answer.';
notebook = updateApplicationReflection(notebook, application);
const expectedPrompt = 'Choose one connection from this deck and explain how it relates to another idea in your own words.';
const appText = await readFile(path.join(source, 'src/app.mjs'), 'utf8');
assert.ok(appText.includes(": '" + expectedPrompt + "';"));
assert.ok(appText.includes('applicationPrompt: applicationPrompt()'));
const notes = createStudyNotes({
  deck, review: restored.review, mastery: restored.mastery, practice: restored.practice,
  reflections: notebook, exportedAt: originalTrace.savedAt, applicationPrompt: expectedPrompt
});
assert.ok(notes.text.includes('10 of 12 connections correct on the first try.'));
assert.ok(notes.text.includes('Paused: 1 of 2 practice answers recorded; 1 correct on retry.'));
assert.ok(notes.text.includes('Prompt: ' + expectedPrompt));
assert.ok(!notes.text.includes('Trace energy from sunlight to a cell doing work.'));
assert.ok(notes.text.includes('  > ' + application.replaceAll('\n', '\n  > ')));
const paragraphChecks = [];
for (let index = 0; index < restored.review.length; index++) {
  const item = restored.review[index];
  const start = notes.text.indexOf('\n' + (index + 1) + '. ' + item.prompt + '\n');
  const end = index + 1 < restored.review.length
    ? notes.text.indexOf('\n' + (index + 2) + '. ' + restored.review[index + 1].prompt + '\n')
    : notes.text.indexOf('\nYOUR APPLICATION REFLECTION');
  assert.ok(start >= 0 && end > start, item.id);
  const paragraph = notes.text.slice(start, end);
  for (const line of [
    'Your first answer: ' + item.options[item.choice],
    'Correct answer: ' + item.options[item.answer],
    'Explanation: ' + item.explanation,
    'Apply the idea: ' + item.transfer,
    '  > ' + notesById.get(item.id).replaceAll('\n', '\n  > ')
  ]) assert.ok(paragraph.includes(line), item.id + ': ' + line);
  for (const [otherId, note] of notesById) {
    if (otherId !== item.id) assert.ok(!paragraph.includes(note.split('\n')[0]), item.id + '/' + otherId);
  }
  paragraphChecks.push({ item: item.id, firstChoice: item.choice, correctChoice: item.answer,
    reflection: notesById.get(item.id), canonicalParagraph: true });
}
assert.equal(JSON.stringify(restored), restoredBefore);
const roundTrip = createTraceArchive({ deck, answers: restored.answers, mastery: restored.mastery,
  practice: restored.practice, savedAt: originalTrace.savedAt });
assert.equal(roundTrip.text, originalTraceBytes.toString('utf8'));
assert.ok(!roundTrip.text.includes('Current receiving note'));
assert.ok(!roundTrip.text.includes(application));
const changed = JSON.parse(courseBytes);
changed.items[0].explanation += ' Receiving-only changed course text.';
assert.throws(() => readTraceArchive(originalTraceBytes.toString('utf8'), validateDeck(changed)), /different course/);
const sourceAfter = {};
for (const item of manifest.physical_learner_and_course_files) {
  sourceAfter[item.path] = sha(await readFile(path.join(source, item.path)));
}
assert.deepEqual(sourceAfter, sourceBefore);
assert.equal(sha(await readFile(path.join(directory, 'inputs/probability-prior-paused-trace.json'))), sha(originalTraceBytes));
await writeFile(path.join(output, 'study-notes.txt'), notes.text, { flag: 'wx' });
await writeFile(path.join(output, 'unchanged-answer-trace.json'), roundTrip.text, { flag: 'wx' });
await writeFile(path.join(output, 'authored-reflections.json'), JSON.stringify(notebook, null, 2) + '\n', { flag: 'wx' });
const receipt = {
  format: 'recallweave-current-probability-reflection-control/1',
  status: 'passed', publicSource: manifest.public_head, sourceTree: manifest.physical_source_tree,
  sourceManifestSha256: sha(await readFile(path.join(directory, 'source-manifest.json'))),
  originalCourse: { sha256: sha(courseBytes), bytes: courseBytes.length, originalPublicCommit: '226068c6e04677995b08a683c8997f66be1748b3' },
  priorActualBrowserTrace: { sha256: sha(originalTraceBytes), bytes: originalTraceBytes.length,
    ownerProofCommit: '4487260efca6819f152435af9cf0a1b64a978d61', archivedMember: 'evidence/modular/paused-trace.json' },
  actualModuleEntries: ['validateDeck', 'readTraceArchive', 'createReflections', 'updateReflection',
    'updateApplicationReflection', 'createStudyNotes', 'createTraceArchive', 'currentPracticeItem'],
  firstAnswers: 12, correctFirst: 10, practiceRecorded: 1, practiceTotal: 2, nextPracticeItem: 'pf-i2',
  paragraphChecks, importedPrompt: expectedPrompt,
  fullPrecisionMasteryPreserved: true, answerTraceBytesUnchanged: true, changedCourseRefused: true,
  studyNotes: { bytes: Buffer.byteLength(notes.text), sha256: sha(notes.text), filename: notes.filename },
  sourceBefore, sourceAfter, node: process.version,
  qualificationBoundary: 'One actual current-module compatibility control using an earlier actual browser download. No new browser, user interaction, content/math or full-suite execution is claimed.'
};
await writeFile(path.join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ status: receipt.status, firstAnswers: 12, canonicalParagraphs: 12,
  answerTraceBytesUnchanged: true, changedCourseRefused: true, studyNotes: receipt.studyNotes,
  receiptSha256: sha(await readFile(path.join(output, 'receipt.json'))) }) + '\n');
