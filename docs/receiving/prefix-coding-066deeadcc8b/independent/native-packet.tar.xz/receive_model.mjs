#!/usr/bin/env node
// Frozen independent receiver. The minimum-cost fixture comes from exhaustive
// labeled binary-tree partitions in oracle.py, not the candidate's greedy code.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {gunzipSync} from 'node:zlib';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';

const [sourcePath, fixturePath, outPath] = process.argv.slice(2);
if(!sourcePath || !fixturePath || !outPath) throw new Error('Usage: receive_model.mjs MODULE FIXTURE_JSON_GZ OUT');
const root=path.resolve(outPath); await fs.mkdir(root,{recursive:false});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const fixtureBytes=await fs.readFile(fixturePath);
const raw=fixturePath.endsWith('.gz') ? gunzipSync(fixtureBytes) : fixtureBytes;
const fixture=JSON.parse(raw);
const report={schema:'recall-prefix-independent-model-receiving-v1',argv:process.argv,node:process.version,
  executable:process.execPath,source:path.resolve(sourcePath),fixtureSha256:sha(raw),
  checks:[],cases:[],invalidModels:[],protocolCases:[],negativeControls:[]};
const check=(name,fn)=>{try{fn();report.checks.push({name,ok:true});return true;}catch(e){report.checks.push({name,ok:false,error:e.stack||String(e)});return false;}};
const clean=x=>JSON.parse(JSON.stringify(x));
const frozen=rows=>Object.freeze(rows.map(r=>Object.freeze({...r})));
const expectThrow=fn=>{let error;try{fn();}catch(e){error=e;}assert(error instanceof Error,'expected an explicit refusal');assert(String(error.message).trim(),'refusal needs a message');return {name:error.name,message:error.message};};

function expectedModel(e){
 let accumulated=0;
 return {rows:e.symbols,nodes:e.nodes.map(n=>({id:n.id,weight:n.count,symbol:n.symbol,left:n.left,right:n.right})),root:e.root,
  steps:e.merges.map((s,i)=>{const addedCost=e.nodes[s.parent].count;accumulated+=addedCost;return {index:i+1,...s,addedCost,accumulatedCost:accumulated};}),
  codebook:e.codebook.map(c=>({symbol:c.symbol,count:c.count,code:c.bits,length:c.length,cost:c.count*c.length})),
  totals:{totalCount:e.totalCount,payloadBits:e.weightedBits,fixedWidth:e.fixedWidth,fixedPayloadBits:e.fixedBits,
    averageBits:e.averageBits,savedPayloadBits:e.fixedBits-e.weightedBits,mergeWeightSum:e.weightedBits}};
}
function expectedMessage(expected,symbols){
 const code=new Map(expected.codebook.map(c=>[c.symbol,c.code]));
 let bits='';const segments=symbols.map(symbol=>{const value=code.get(symbol),start=bits.length;bits+=value;return {symbol,code:value,start,end:bits.length};});
 return {bits,symbols,segments};
}
function inspectPrefixCost(codebook,claimed,optimal){
 const codes=codebook.map(x=>x.code);
 for(let i=0;i<codes.length;i++){
  assert(/^[01]+$/.test(codes[i]));
  for(let j=0;j<codes.length;j++) if(i!==j) assert(!codes[j].startsWith(codes[i]),'code is not prefix-free');
 }
 assert.equal(claimed,codebook.reduce((s,c)=>s+c.count*c.code.length,0),'weighted codeword accounting');
 assert.equal(claimed,optimal,'cost differs from exhaustive full-tree minimum');
}
function inspectModel(model,expected){
 inspectPrefixCost(model.codebook,model.totals.payloadBits,expected.totals.payloadBits);
 assert.deepEqual(clean(model),expected);
 assert.equal(model.totals.payloadBits,model.steps.reduce((s,x)=>s+x.addedCost,0));
 assert(model.totals.payloadBits<=model.totals.fixedPayloadBits);
}

try {
 const source=await fs.readFile(sourcePath);report.sourceBeforeSha256=sha(source);
 const api=await import(pathToFileURL(path.resolve(sourcePath)));
 report.exports=Object.keys(api).sort();
 for(const name of ['validateRows','buildCode','encodeSymbols','decodeBits','serializeExample']) assert.equal(typeof api[name],'function',name+' export');
 for(const item of fixture.cases){
  const expected=expectedModel(item.expected),rows=frozen(item.rows),before=JSON.stringify(rows);
  const record={name:item.name,kind:item.kind,input:clean(rows)};report.cases.push(record);
  check(item.name+':complete-model-and-exhaustive-cost',()=>{record.actual=clean(api.buildCode(rows));inspectModel(record.actual,expected);});
  check(item.name+':canonical-validation-and-frozen-copy',()=>{
   const validated=api.validateRows(rows);assert.deepEqual(clean(validated),expected.rows);
   assert(Object.isFrozen(validated));validated.forEach(r=>assert(Object.isFrozen(r)));
   assert.equal(JSON.stringify(rows),before);
  });
  check(item.name+':permutation-independent-ids-ties-and-codes',()=>inspectModel(api.buildCode(frozen([...rows].reverse())),expected));
  const symbols=[...expected.rows.map(r=>r.symbol),...expected.rows.map(r=>r.symbol).reverse(),expected.rows.at(-1).symbol];
  const message=expectedMessage(expected,symbols);
  check(item.name+':actual-encoder-exact-segments',()=>{record.encoded=clean(api.encodeSymbols(rows,symbols));assert.deepEqual(record.encoded,message);});
  check(item.name+':actual-decoder-exact-roundtrip',()=>{record.decoded=clean(api.decodeBits(rows,message.bits));assert.deepEqual(record.decoded,message);});
  check(item.name+':complete-current-example-serialization',()=>{
   const value=api.serializeExample(rows,expected.steps.length,message.bits);assert.equal(typeof value,'string');assert(value.endsWith('\n'));
   const parsed=JSON.parse(value);assert.deepEqual(parsed,{format:'recallweave.prefix-coding/1',model:expected,inspection:{step:expected.steps.length},decoding:message});
   assert.equal(value,api.serializeExample(frozen([...rows].reverse()),expected.steps.length,message.bits));
   record.serializedSha256=sha(Buffer.from(value));record.serializedBytes=Buffer.byteLength(value);
  });
  if(item.kind!=='exhaustive-positive-count-vector'){
   check(item.name+':all-inspection-steps',()=>{for(let step=0;step<=expected.steps.length;step++) assert.equal(JSON.parse(api.serializeExample(rows,step,'')).inspection.step,step);});
  }
 }
 for(const item of fixture.invalid_models){
  let rows=item.rows;
  if(item.javascriptValue){
   const value={NaN:NaN,Infinity:Infinity,'-Infinity':-Infinity}[item.javascriptValue];
   rows=item.javascriptValue==='undefined-row' ? [undefined,{symbol:'B',count:2}] : [{symbol:'A',count:value},{symbol:'B',count:2}];
  }
  const record={name:item.name,sourceFixture:item,refusals:{}};report.invalidModels.push(record);
  for(const [name,invoke] of [['validateRows',()=>api.validateRows(rows)],['buildCode',()=>api.buildCode(rows)],
    ['encodeSymbols',()=>api.encodeSymbols(rows,[])],['decodeBits',()=>api.decodeBits(rows,'')],['serializeExample',()=>api.serializeExample(rows,0,'')]]){
   check(item.name+':'+name+':refuse',()=>{record.refusals[name]=expectThrow(invoke);});
  }
 }
 const item=fixture.cases.find(x=>x.name==='original-worked'),rows=frozen(item.rows),expected=expectedModel(item.expected);
 const pairRows=frozen([{symbol:'A',count:1},{symbol:'B',count:2}]);
 const protocol=(name,fn)=>{const row={name};report.protocolCases.push(row);check('protocol:'+name,()=>{row.result=fn();});};
 protocol('empty-encoder',()=>{const value=api.encodeSymbols(rows,[]);assert.deepEqual(clean(value),{bits:'',symbols:[],segments:[]});return value;});
 protocol('empty-decoder',()=>{const value=api.decodeBits(rows,'');assert.deepEqual(clean(value),{bits:'',symbols:[],segments:[]});return value;});
 protocol('512-symbol-encoder-boundary',()=>{const message=Array.from({length:512},(_,i)=>expected.rows[i%expected.rows.length].symbol);const value=api.encodeSymbols(rows,message);assert.deepEqual(clean(value),expectedMessage(expected,message));return {symbols:value.symbols.length,bits:value.bits.length};});
 protocol('4096-bit-decoder-boundary',()=>{const value=api.decodeBits(pairRows,'0'.repeat(4096));assert.equal(value.bits.length,4096);assert.equal(value.symbols.length,4096);assert.equal(value.segments.at(-1).end,4096);return {bits:value.bits.length,symbols:value.symbols.length};});
 const refusals=[
  ['encoder-over-limit',()=>api.encodeSymbols(rows,Array(513).fill('A'))],['encoder-unknown',()=>api.encodeSymbols(rows,['A','unknown','B'])],
  ['encoder-string',()=>api.encodeSymbols(rows,'A')],['encoder-null',()=>api.encodeSymbols(rows,null)],['encoder-nonstring-symbol',()=>api.encodeSymbols(rows,[7])],
  ['decoder-over-limit',()=>api.decodeBits(pairRows,'0'.repeat(4097))],['decoder-space',()=>api.decodeBits(rows,'0 1')],
  ['decoder-newline',()=>api.decodeBits(rows,'0\n')],['decoder-other-digit',()=>api.decodeBits(rows,'012')],
  ['decoder-fullwidth-digit',()=>api.decodeBits(rows,'０')],['decoder-null',()=>api.decodeBits(rows,null)],['decoder-array',()=>api.decodeBits(rows,[])],
  ['decoder-unfinished',()=>api.decodeBits(rows,expected.codebook.find(c=>c.length>1).code.slice(0,-1))],
  ['serialize-negative-step',()=>api.serializeExample(rows,-1,'')],['serialize-fraction-step',()=>api.serializeExample(rows,0.5,'')],
  ['serialize-too-large-step',()=>api.serializeExample(rows,rows.length,'')],['serialize-string-step',()=>api.serializeExample(rows,'0','')],
  ['serialize-bad-decoder',()=>api.serializeExample(rows,0,'2')],['serialize-too-long-decoder',()=>api.serializeExample(rows,0,'0'.repeat(4097))]
 ];
 for(const [name,fn]of refusals) protocol(name,()=>expectThrow(fn));
 check('negative:nonoptimal-weighted-cost-detected',()=>{
  const nonoptimal=[{symbol:'A',count:1,code:'0'},{symbol:'B',count:2,code:'10'},{symbol:'C',count:3,code:'11'}];
  const error=expectThrow(()=>inspectPrefixCost(nonoptimal,11,fixture.negative_control.exhaustive_minimum));
  assert(error.message.includes('exhaustive full-tree minimum'));
  report.negativeControls.push({name:'internally-consistent-prefix-code-with-nonoptimal-cost',rejected:true,claimedCost:11,optimalCost:9,error});
 });
 check('negative:prefix-collision-detected',()=>{
  const counterexample=clean(expected);counterexample.codebook[1].code=counterexample.codebook[0].code+'0';
  const error=expectThrow(()=>inspectPrefixCost(counterexample.codebook,counterexample.totals.payloadBits,expected.totals.payloadBits));
  assert(error.message.includes('not prefix-free'));report.negativeControls.push({name:'prefix-collision',rejected:true,error});
 });
 report.sourceAfterSha256=sha(await fs.readFile(sourcePath));check('source-stable',()=>assert.equal(report.sourceAfterSha256,report.sourceBeforeSha256));
} catch(e){report.harnessError=e.stack||String(e);check('model-capability',()=>{throw e;});}
report.passedChecks=report.checks.filter(c=>c.ok).length;report.failedChecks=report.checks.filter(c=>!c.ok).length;
await fs.writeFile(path.join(root,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({cases:report.cases.length,invalidModels:report.invalidModels.length,protocolCases:report.protocolCases.length,
 passedChecks:report.passedChecks,failedChecks:report.failedChecks,sourceBeforeSha256:report.sourceBeforeSha256,sourceAfterSha256:report.sourceAfterSha256,
 report:path.join(root,'report.json'),harnessError:report.harnessError}));
process.exitCode=report.failedChecks?1:0;
