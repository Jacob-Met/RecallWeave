# Critical-path timing course — author receiving

This packet records the author work for RecallWeave issue171. It is evidence, not a claim that the Actions hold has lifted or hosted gates passed.

Current product source is the three files listed in author-review.json: corrected deck49a84, guide501be7 and testf602. All existing learner/model files are byte-exact canonical inputs from main698902f9. The root worker owns README integration and any future ref/PR/merge.

The original six-group browser journey used deckfc4 and is intentionally retained as historical functional evidence. It included all16 questions, four misses and correct retries, exact notes, reflections,375px keyboard use and the A-duration companion sequence. Independent prose review then found one explanation error in ct-early-3. The corrected source changed only that sentence. A separate actual current-deck browser run stopped at that corrected question after10 native prompts. The final focused Node module passed8/8. Do not relabel old notes as corrected-source exports.

The first browser attempt failed because the receiver read each whole preview list item as only its prompt. The native preview also includes concept/prerequisite metadata. V2 narrows the prompt selector and separately checks the metadata; raw failure and both drivers are preserved. No consumer UI was changed.

Files at the archive root mirror the minimal source closure so current native qualification can be reproduced with an existing Node:
    node --test tests/critical-path-timing-course.test.mjs

Browser drivers use the explicitly recorded installed Playwright/Chromium paths and a private temporary directory. These environment paths may need equivalent substitutions elsewhere; do not claim an unexecuted substitute run. The current correction driver is:
    node evidence/author-browser-correction.mjs

The full V2 driver is historical and pins the initial deckfc4. It must only be reproduced in a separate copy with evidence/course-initial-fc4efe98.json placed at courses/critical-path-timing.json. Its output names are separate from the current correction. No replay is necessary merely to inspect this packet.

archive-manifest.json binds every payload member by bytes, SHA256 and Git blob identity. The embedded manifest is additional to its payload member count. verify-archive.py checks the complete archived payload without extracting or running product code.

The independent blind packet belongs to estate_records and is retained verbatim. Its follow-up full-content and corrected-source browser review are separate worker evidence, not authored here.

No provider calls, installed-runtime changes, original consumer changes, catalog additions, automatic persistence, live deployment or Actions/ref/PR/merge writes were performed.
