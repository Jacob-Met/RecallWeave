import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {ASSUMPTIONS,FIXED_TIME,sha256,pinFile,expectedObservation,assertCross,storageSnapshot,assertNoStorage} from './browser-oracle.mjs';
import {parseDeck} from './baseline/src/deck.mjs';
import {initialMastery,updateMastery} from './baseline/src/knowledge.mjs';
import {createReview,beginPractice,answerPractice} from './baseline/src/review.mjs';
import {createReflections,updateReflection,updateApplicationReflection} from './baseline/src/reflections.mjs';
import {createStudyNotes} from './baseline/src/session-export.mjs';

if(process.env.LINKAGE_RECEIVING_ADMITTED!=='1') throw Error('Root candidate admission is required before execution.');
if(process.argv.length!==3) throw Error('Usage: node receive-browser.mjs admitted-manifest.json');
const manifest=JSON.parse(readFileSync(resolve(process.argv[2]),'utf8'));
assert.equal(manifest.admitted,true);assert.equal(manifest.publicContract,'dc43bbd25c189252f70d6d4d3eab48f244d0a5b0');
const out=resolve(manifest.outputDir);mkdirSync(out,{recursive:true});
const pagePath=resolve(manifest.pagePath),coursePath=resolve(manifest.coursePath),learnerPath=resolve(manifest.learnerPath);
const sourceBefore=manifest.sources.map(p=>{const actual=pinFile(resolve(p.path));for(const k of ['git','sha256','bytes'])assert.equal(actual[k],p[k],p.path+' '+k);return actual;});
assert.equal(new Set(sourceBefore.map(p=>p.path)).size,sourceBefore.length);
for(const p of [pagePath,coursePath,learnerPath]) assert(sourceBefore.some(x=>x.path===p),'Missing admitted pin '+p);
assert.equal(sourceBefore.find(x=>x.path===learnerPath).git,'ef7bc3e27e7f161d917ced6a457fad8822802f3f');
const receiverRoot=dirname(fileURLToPath(import.meta.url));
const baselineFreeze=JSON.parse(readFileSync(join(receiverRoot,'pre-candidate-freeze.json'),'utf8'));
const baselineBefore=baselineFreeze.files.map(p=>{const actual=pinFile(join(receiverRoot,p.path));for(const key of ['git','sha256','bytes'])assert.equal(actual[key],p[key],p.path+' baseline '+key);return actual;});
const publicContract=JSON.parse(readFileSync(join(receiverRoot,'public-contract.json'),'utf8'));
const sourceRoot=resolve(manifest.sourceRoot);
for(const relative of publicContract.sourceFence)assert(sourceBefore.some(p=>p.path===join(sourceRoot,relative)),'Missing candidate closure '+relative);
const courseBytes=readFileSync(coursePath),deck=parseDeck(courseBytes.toString('utf8'));
assert.equal(deck.title,'Linked genes: same genotype, different gametes');assert.equal(deck.items.length,12);
assert.equal(manifest.blindAnswersFreeze,'69ac06f41f3f2fc6d000857cc0eb5d817c6d1ae0');
const blind=manifest.blindAnswers;assert.equal(Object.keys(blind).length,12);
assert.deepEqual(deck.items.map(item=>blind[item.id]),[2,1,0,3,0,2,1,0,3,2,1,0]);
for(const item of deck.items) assert.equal(blind[item.id],item.answer,'Independent sealed blind answer '+item.id);
const missIds=new Set([1,5,9].map(i=>deck.items[i].id));
const selfFiles=[fileURLToPath(import.meta.url),fileURLToPath(new URL('./browser-oracle.mjs',import.meta.url))];
const selfBefore=selfFiles.map(pinFile);
const receipt={schema:'recallweave-linkage-independent-browser-result/1',startedAt:new Date().toISOString(),publicContract:manifest.publicContract,behaviorContract:manifest.behaviorContract,admission:manifest.admission,sourceBefore,baselineBefore,selfBefore,groups:[],requests:[],offOrigin:[],errors:[],consoleErrors:[],downloads:[],storage:[],injections:[],learner:{missIds:[...missIds]},result:'running'};
const save=()=>writeFileSync(join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
save();
let browser,context,page,downloadEvents=0;
const allowed=new Set([pathToFileURL(pagePath).href,pathToFileURL(learnerPath).href]);
async function runGroup(id,fn){const detail=await fn();receipt.groups.push({id,status:'pass',detail});save();}
async function download(selector,filename,label,expected) {
 const promised=page.waitForEvent('download',{timeout:7000});
 await page.locator(selector).click();
 const d=await promised;
 assert.equal(d.suggestedFilename(),filename);
 const path=join(out,String(receipt.downloads.length+1).padStart(2,'0')+'-'+label+'-'+filename);
 await d.saveAs(path);assert.equal(await d.failure(),null);
 const b=readFileSync(path);if(expected!==undefined)assert.deepEqual(b,Buffer.isBuffer(expected)?expected:Buffer.from(expected,'utf8'),label+' exact physical bytes');
 const record={label,filename,path,bytes:b.length,sha256:sha256(b)};receipt.downloads.push(record);save();return record;
}
async function apply(phase,raw,keyboard=false) {
 await page.locator('#linkage-phase').selectOption(phase);await page.locator('#linkage-recombination').fill(raw);
 if(keyboard){await page.locator('#linkage-apply').focus();await page.keyboard.press('Enter');}else await page.locator('#linkage-apply').click();
}
async function retired() {
 assert.equal(await page.locator('#linkage-result').isVisible(),false);assert.equal(await page.locator('#linkage-download').isDisabled(),true);
}
async function noDownloadActivation(action) {
 const before=downloadEvents;const urlsBefore=await page.evaluate(()=>window.__linkageAudit.urls.filter(x=>x.kind==='create').length);
 const result=await action();
 await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>resolve())));
 assert.equal(downloadEvents,before);assert.equal(await page.evaluate(()=>window.__linkageAudit.urls.filter(x=>x.kind==='create').length),urlsBefore);
 return result;
}
async function auditDocument(label) {const snapshot=await storageSnapshot(page,label);receipt.storage.push(snapshot);assertNoStorage(snapshot);save();}
async function assertNoPageOverflow() {const v=await page.evaluate(()=>({inner:innerWidth,client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth}));assert(v.scroll<=v.client+1,JSON.stringify(v));return v;}
try {
 browser=await chromium.launch({executablePath:'/workspace/scratch/3e50c5ad22c5/production/browser/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 receipt.runtime={node:process.version,chromium:browser.version(),platform:process.platform};
 context=await browser.newContext({acceptDownloads:true,viewport:{width:375,height:812},locale:'en-US',reducedMotion:'reduce'});
 await context.addInitScript(({fixed})=>{
  const NativeDate=Date;
  class FixedDate extends NativeDate{constructor(...args){super(...(args.length?args:[fixed]));}static now(){return new NativeDate(fixed).getTime();}}
  window.Date=FixedDate;
  window.__linkageAudit={storage:[],urls:[],failNextObjectURL:false};
  for(const method of ['setItem','removeItem','clear']){const native=Storage.prototype[method];Storage.prototype[method]=function(...args){window.__linkageAudit.storage.push({api:'Storage.'+method,args:args.map(String)});return native.apply(this,args);};}
  for(const [target,name,methods] of [[globalThis.IDBFactory?.prototype,'indexedDB',['open','deleteDatabase']],[globalThis.CacheStorage?.prototype,'caches',['open','delete']]])for(const method of methods){if(!target)continue;const native=target[method];target[method]=function(...args){window.__linkageAudit.storage.push({api:name+'.'+method,args:args.map(String)});return native.apply(this,args);};}
  const cookie=Object.getOwnPropertyDescriptor(Document.prototype,'cookie');
  if(cookie?.set)Object.defineProperty(Document.prototype,'cookie',{...cookie,set(value){window.__linkageAudit.storage.push({api:'cookie',value:String(value)});return cookie.set.call(this,value);}});
  const create=URL.createObjectURL.bind(URL),revoke=URL.revokeObjectURL.bind(URL);
  URL.createObjectURL=function(blob){if(window.__linkageAudit.failNextObjectURL){window.__linkageAudit.failNextObjectURL=false;window.__linkageAudit.urls.push({kind:'injected-failure'});throw Error('Receiver-only one-shot preparation refusal');}const url=create(blob);window.__linkageAudit.urls.push({kind:'create',url,size:blob.size,type:blob.type});return url;};
  URL.revokeObjectURL=function(url){window.__linkageAudit.urls.push({kind:'revoke',url});return revoke(url);};
 },{fixed:FIXED_TIME});
 await context.route('**/*',route=>{const url=route.request().url();if(allowed.has(url)||url.startsWith('blob:')||url.startsWith('data:'))return route.continue();receipt.offOrigin.push({url,method:route.request().method()});return route.abort('blockedbyclient');});
 context.on('request',r=>receipt.requests.push({url:r.url(),method:r.method(),resourceType:r.resourceType()}));
 context.on('page',p=>{p.on('pageerror',e=>receipt.errors.push(String(e)));p.on('console',m=>{if(m.type()==='error')receipt.consoleErrors.push(m.text());});p.on('download',()=>downloadEvents++);});
 page=await context.newPage();page.setDefaultTimeout(6000);
 await page.goto(pathToFileURL(pagePath).href);await page.waitForLoadState('load');
 let originalCourse,firstObservation;
 await runGroup('G1',async()=>{
  assert.equal(await page.title(),'Linked genes: same genotype, different gametes');
  assert.equal(await page.locator('#linkage-phase').inputValue(),'coupling');assert.equal(await page.locator('#linkage-recombination').inputValue(),'20');await retired();assert.equal(downloadEvents,0);
  assert.equal((await page.locator('#linkage-apply').textContent()).trim(),'Apply cross');assert.equal(await page.getByLabel('Recombinant gametes (%)',{exact:true}).getAttribute('id'),'linkage-recombination');
  assert.equal(await page.locator('#linkage-status').getAttribute('role'),'status');assert.equal(await page.locator('#linkage-error').getAttribute('role'),'alert');
  assert.equal(await page.locator('#linkage-recombination').getAttribute('type'),'text');assert.equal(await page.locator('#linkage-recombination').getAttribute('inputmode'),'numeric');
  assert.equal(await page.locator('#linkage-learner').getAttribute('href'),'../demo.html');assert.equal(await page.locator('#linkage-guide').getAttribute('href'),'./genetic-linkage.md');
  const body=await page.locator('body').innerText();for(const assumption of ASSUMPTIONS)assert(body.includes(assumption),assumption);assert(body.includes('AaBb'));assert(body.includes('aabb'));
  originalCourse=await download('#linkage-course','genetic-linkage.json','initial-course',courseBytes);
  return {unapplied:true,course:originalCourse,concepts:deck.concepts,attribution:deck.attribution,license:deck.license};
 });
 await runGroup('G2',async()=>{
  await apply('repulsion',' 014 ');await assertCross(page,'repulsion',14);
  firstObservation=await download('#linkage-download','genetic-linkage-observation.json','repulsion14',expectedObservation('repulsion',' 014 '));
  const repeat=await download('#linkage-download','genetic-linkage-observation.json','repulsion14-repeat',readFileSync(firstObservation.path));
  return {raw:' 014 ',modelPercent:14,first:firstObservation,repeat};
 });
 await runGroup('G3',async()=>{
  const same=await noDownloadActivation(()=>page.evaluate(()=>{
   const input=document.querySelector('#linkage-recombination');input.dispatchEvent(new Event('input',{bubbles:true}));
   const state={hidden:document.querySelector('#linkage-result').hidden,disabled:document.querySelector('#linkage-download').disabled};
   document.querySelector('#linkage-download').dispatchEvent(new MouseEvent('click',{bubbles:true}));return state;
  }));assert.deepEqual(same,{hidden:true,disabled:true});await retired();
  await apply('repulsion',' 014 ');await assertCross(page,'repulsion',14);
  await noDownloadActivation(()=>page.evaluate(()=>{document.querySelector('#linkage-recombination').value='15';document.querySelector('#linkage-download').click();}));await retired();
  const refusals=[];
  for(const raw of ['', '+14','14.0','1e1','51','0'.repeat(33)]) {
   await apply('repulsion','14');await assertCross(page,'repulsion',14);
   await page.locator('#linkage-recombination').fill(raw);await retired();await page.locator('#linkage-apply').click();await retired();
   assert.equal(await page.locator('#linkage-error').isVisible(),true);const error=(await page.locator('#linkage-error').textContent()).trim();assert(error.length);refusals.push({raw,error});
  }
  const invalidCourse=await download('#linkage-course','genetic-linkage.json','invalid-draft-course',courseBytes);
  await apply('coupling','0'.repeat(32));await assertCross(page,'coupling',0);
  await apply('repulsion',' 014 ');await assertCross(page,'repulsion',14);
  for(const which of ['observation','course']) {
   await page.evaluate(()=>{window.__linkageAudit.failNextObjectURL=true;});
   const before=downloadEvents;await page.locator(which==='observation'?'#linkage-download':'#linkage-course').click();
   assert.equal(downloadEvents,before);assert.equal(await page.locator('#linkage-error').isVisible(),true);assert((await page.locator('#linkage-error').textContent()).trim());
   await assertCross(page,'repulsion',14);assert.equal(await page.locator('#linkage-download').isEnabled(),true);
   receipt.injections.push({which,kind:'URL.createObjectURL one-shot throw',appliedStatePreserved:true});
   await download(which==='observation'?'#linkage-download':'#linkage-course',which==='observation'?'genetic-linkage-observation.json':'genetic-linkage.json',which+'-retry',which==='observation'?expectedObservation('repulsion',' 014 '):courseBytes);
  }
  assert.equal(sha256(readFileSync(firstObservation.path)),firstObservation.sha256);
  return {sameValueRetired:same,unannouncedEditRefused:true,refusals,accepted32Zeroes:true,invalidCourse};
 });
 await runGroup('G4',async()=>{
  const cases=[];
  for(const phase of ['coupling','repulsion'])for(const r of [0,50]){await apply(phase,String(r),true);await assertCross(page,phase,r);cases.push({phase,r});}
  await page.locator('#linkage-download').focus();
  const promised=page.waitForEvent('download',{timeout:7000});await page.keyboard.press('Enter');const d=await promised;
  assert.equal(d.suggestedFilename(),'genetic-linkage-observation.json');const path=join(out,'keyboard-endpoint-observation.json');await d.saveAs(path);assert.equal(await d.failure(),null);const b=readFileSync(path);assert.deepEqual(b,Buffer.from(expectedObservation('repulsion','50')));
  receipt.downloads.push({label:'keyboard-endpoint',filename:d.suggestedFilename(),path,bytes:b.length,sha256:sha256(b)});
  const viewport=await assertNoPageOverflow();await page.screenshot({path:join(out,'companion-375px.png'),fullPage:true});await auditDocument('lab-before-learner-navigation');
  return {cases,keyboardApplyAndDownload:true,viewport};
 });
 let answers=[],review,mastery=initialMastery(deck.concepts),reflections=createReflections(deck.items),practice=null,firstMastery;
 const reflectionText='<b>AB / ab</b> & Ω\nMy r = 14% interpretation.';
 const applicationText='Same AaBb; different phase.\nProbabilities are not a finite quota.';
 const applicationPrompt='Choose one connection from this deck and explain how it relates to another idea in your own words.';
 async function notes(label) {
  const expected=createStudyNotes({deck,review,mastery,practice,reflections,exportedAt:FIXED_TIME,conceptLabel:id=>id,applicationPrompt});
  return await download('#save-notes-button',expected.filename,label,expected.text);
 }
 await runGroup('G5',async()=>{
  const titleBefore=await page.title();await page.locator('#linkage-learner').focus();
  await Promise.all([page.waitForURL(pathToFileURL(learnerPath).href),page.keyboard.press('Enter')]);
  assert.notEqual(await page.title(),titleBefore);
  const initialDescription=await page.locator('#lesson-description').textContent();
  await page.locator('#deck-file').setInputFiles(originalCourse.path);await page.locator('#start-deck').waitFor({state:'visible'});
  assert.equal(await page.locator('#deck-preview-title').textContent(),deck.title);
  assert((await page.locator('.deck-preview-count').textContent()).includes('12 questions'));
  assert.equal(await page.locator('.deck-preview-attribution').textContent(),'Attribution supplied in the deck: '+deck.attribution);
  assert.equal(await page.locator('.deck-preview-license').textContent(),'License supplied in the deck: '+deck.license);
  assert.equal(await page.locator('#lesson-description').textContent(),initialDescription);
  await page.locator('#cancel-deck').click();assert.equal(await page.locator('#deck-preview').isVisible(),false);assert.equal(await page.locator('#lesson-description').textContent(),initialDescription);
  await page.locator('#deck-file').setInputFiles(originalCourse.path);await page.locator('#start-deck').waitFor({state:'visible'});await page.locator('#start-deck').click();
  const seen=new Set();
  for(let i=0;i<12;i++){
   const prompt=await page.locator('#session-content .question-card h2').textContent();const matches=deck.items.filter(item=>item.prompt===prompt);assert.equal(matches.length,1);
   const item=matches[0];assert(!seen.has(item.id));seen.add(item.id);
   const choice=missIds.has(item.id)?(blind[item.id]+1)%item.options.length:blind[item.id];const correct=choice===blind[item.id];
   await page.locator('[data-choice="'+choice+'"]').click();assert.equal(await page.locator('[data-choice]:enabled').count(),0);
   assert((await page.locator('#feedback-slot').textContent()).includes(item.explanation));
   answers.push({item:item.id,concept:item.concept,choice,correct});mastery[item.concept]=updateMastery(mastery[item.concept],correct);
   await page.locator('#next-button').click();
  }
  review=createReview(deck.items,answers);firstMastery=await page.locator('.mastery-row').allTextContents();
  assert((await page.locator('#first-try-summary').textContent()).includes('9 of 12'));
  const rendered=await page.locator('.review-item').evaluateAll(items=>items.map(item=>({prompt:item.querySelector('.review-prompt').textContent,choices:[...item.querySelectorAll('.review-answers dd')].map(x=>x.textContent)})));
  assert.deepEqual(rendered,review.map(item=>({prompt:item.prompt,choices:[item.options[item.choice],item.options[item.answer]]})));
  const reflectionId=review[0].id;
  const details=page.locator('.review-item').filter({has:page.locator('[data-reflection-item="'+reflectionId+'"]')});
  await details.locator('summary').click();await page.locator('[data-reflection-item="'+reflectionId+'"]').fill(reflectionText);reflections=updateReflection(reflections,reflectionId,reflectionText);
  await page.locator('#application-reflection').fill(applicationText);reflections=updateApplicationReflection(reflections,applicationText);
  assert.equal(await page.locator('[data-reflection-item="'+reflectionId+'"]').inputValue(),reflectionText);
  assert.equal(await page.locator('.review-item b').count(),0);
  const initialNotes=await notes('first-session-notes');
  receipt.learner={...receipt.learner,answers,reviewOrder:review.map(x=>x.id),mastery,reflectionId,reflectionText,applicationText};
  return {seen:[...seen],firstCorrect:9,firstTotal:12,initialNotes};
 });
 await runGroup('G6',async()=>{
  practice=beginPractice(review);assert.equal(practice.items.length,3);
  await page.locator('#practice-button').click();
  for(let i=0;i<3;i++){
   const item=practice.items[i];assert.equal(await page.locator('.practice-card h2').textContent(),item.prompt);
   const choice=i===0?(blind[item.id]+1)%item.options.length:blind[item.id];
   await page.locator('[data-practice-choice="'+choice+'"]').click();practice=answerPractice(practice,item.id,choice);
   assert.equal(await page.locator('[data-practice-choice]:enabled').count(),0);
   if(i===0){
    await page.locator('#back-to-review').click();assert((await page.locator('#practice-status').textContent()).includes('1 of 3'));
    assert.deepEqual(await page.locator('.mastery-row').allTextContents(),firstMastery);assert((await page.locator('#first-try-summary').textContent()).includes('9 of 12'));
    assert.equal(await page.locator('#application-reflection').inputValue(),applicationText);
    await notes('paused-practice-notes');await page.locator('#practice-button').click();
   }else await page.locator('#practice-next').click();
  }
  assert((await page.locator('#practice-status').textContent()).includes('2 of 3'));assert.equal(await page.locator('#practice-button').count(),0);
  assert((await page.locator('#first-try-summary').textContent()).includes('9 of 12'));assert.deepEqual(await page.locator('.mastery-row').allTextContents(),firstMastery);
  await notes('completed-practice-notes');
  const firstChoices=await page.locator('.review-item .review-answers').evaluateAll(rows=>rows.map(x=>[...x.querySelectorAll('dd')].map(x=>x.textContent)));
  assert.deepEqual(firstChoices,review.map(item=>[item.options[item.choice],item.options[item.answer]]));
  assert.equal(await page.locator('[data-reflection-item="'+review[0].id+'"]').inputValue(),reflectionText);
  const viewport=await assertNoPageOverflow();await page.screenshot({path:join(out,'learner-375px.png'),fullPage:true});await auditDocument('learner-final-before-close');
  receipt.learner.practice=practice;return {firstCorrect:9,practiceCorrect:2,practiceTotal:3,preservedFirstAnswers:true,viewport};
 });
 receipt.sourceAfter=sourceBefore.map(x=>pinFile(x.path));assert.deepEqual(receipt.sourceAfter,sourceBefore);
 receipt.selfAfter=selfFiles.map(pinFile);assert.deepEqual(receipt.selfAfter,selfBefore);
 receipt.baselineAfter=baselineBefore.map(p=>pinFile(p.path));assert.deepEqual(receipt.baselineAfter,baselineBefore);
 for(const d of receipt.downloads)assert.equal(sha256(readFileSync(d.path)),d.sha256);
 assert.deepEqual(receipt.offOrigin,[]);assert.deepEqual(receipt.errors,[]);assert.deepEqual(receipt.consoleErrors,[]);assert.equal(downloadEvents,receipt.downloads.length);
 assert.equal(receipt.groups.length,6);receipt.result='pass';receipt.finishedAt=new Date().toISOString();save();
 console.log(JSON.stringify({result:receipt.result,groups:receipt.groups.map(x=>x.id),downloads:receipt.downloads.length,requests:receipt.requests.length,sourceFiles:sourceBefore.length,receipt:join(out,'receipt.json')}));
}catch(error){
 receipt.result='fail';receipt.failure={name:error.name,message:error.message,stack:error.stack};receipt.finishedAt=new Date().toISOString();
 try{if(page&&!page.isClosed())await page.screenshot({path:join(out,'failure.png'),fullPage:false});}catch(e){receipt.screenshotFailure=String(e);}
 save();console.error(error.stack);process.exitCode=1;
}finally{
 if(context)await context.close();if(browser)await browser.close();
}
