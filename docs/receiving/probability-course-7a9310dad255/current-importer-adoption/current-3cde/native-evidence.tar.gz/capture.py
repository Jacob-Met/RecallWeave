from pathlib import Path, PurePosixPath
import base64, datetime, hashlib, io, json, os, stat, tarfile, zipfile

ROOT = Path(__file__).resolve().parent
data = json.loads((ROOT / "input.json").read_text())
OLD = ROOT.parent / "current-8b82" / "candidate"
SOURCE = ROOT / "source"
def digest(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}
def save(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as file: file.write(raw)
def dump(path, value):
    save(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())
def tree_id(rows):
    tree = {}
    for row in rows:
        parts = row["path"].split("/")
        node = tree
        for part in parts[:-1]: node = node.setdefault(part, {})
        assert parts[-1] not in node
        node[parts[-1]] = (row["mode"], row.get("git_blob", row.get("sha")))
    def emit(node):
        raw = b""
        for name, item in sorted(node.items(), key=lambda pair: (pair[0] + ("/" if isinstance(pair[1], dict) else "")).encode()):
            mode, sha = ("40000", emit(item)) if isinstance(item, dict) else item
            raw += mode.encode() + b" " + name.encode() + b"\0" + bytes.fromhex(sha)
        return hashlib.sha1(b"tree " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    return emit(tree)

assert len(data["public_files"]) == 871
assert tree_id(data["public_files"]) == data["tree"]
public = {item["path"]: item for item in data["public_files"]}
records = []
for rel, expected in data["source_pins"]["files"].items():
    if rel in data["source_overrides"]:
        raw = data["source_overrides"][rel].encode()
        route = "GitHub exact 3cde file read"
    else:
        original = OLD / rel
        assert original.is_file() and not original.is_symlink()
        raw = original.read_bytes()
        route = "read-only prior owned source with identical current Git blob"
    found = digest(raw)
    assert found["git_blob"] == public[rel]["sha"], (rel, found, public[rel])
    assert found["bytes"] == public[rel]["size"]
    assert found["sha256"] == expected["sha256"] and found["bytes"] == expected["size"], (rel, expected, found)
    save(SOURCE / rel, raw)
    os.chmod(SOURCE / rel, 0o755 if public[rel]["mode"] == "100755" else 0o644)
    records.append({"path": rel, "mode": public[rel]["mode"], **found,
                    "public_head": data["head"], "owner_browser_pin_identical": True, "capture": route})
proofs = {}
for item in data["proof_files"]:
    raw = item["content"].encode()
    found = digest(raw)
    assert found["git_blob"] == item["sha"] and found["bytes"] == item["size"]
    rel = item["path"].removeprefix("docs/reflections-20261008-9ec02b70e5f0/")
    save(ROOT / "owner-proof" / rel, raw)
    proofs[rel] = {"path": item["path"], **found}
pre = "independent-current-picker-d8a9/"
owner_dir = ROOT / "owner-proof" / pre
index_raw = (owner_dir / "browser-evidence-index.json").read_bytes()
index = json.loads(index_raw)
encoded = (owner_dir / "browser-evidence.tar.gz.base64").read_bytes()
assert len(encoded) == index["encoded_bytes"] == 46709
assert hashlib.sha256(encoded).hexdigest() == index["encoded_sha256"]
compressed = base64.b64decode(b"".join(encoded.split()), validate=True)
assert len(compressed) == index["compressed_bytes"] == 35030
assert hashlib.sha256(compressed).hexdigest() == index["compressed_sha256"]
archive_members = {}
with tarfile.open(fileobj=io.BytesIO(compressed), mode="r:gz") as archive:
    for member in archive.getmembers():
        assert member.isfile() and not member.issym() and not member.islnk()
        rel = PurePosixPath(member.name)
        assert not rel.is_absolute() and ".." not in rel.parts and str(rel) == member.name
        assert member.name not in archive_members
        raw = archive.extractfile(member).read()
        expected = index["files"][member.name]
        assert len(raw) == expected["size"] and hashlib.sha256(raw).hexdigest() == expected["sha256"]
        archive_members[member.name] = raw
assert set(archive_members) == set(index["files"])
assert len(archive_members) == index["file_count"] == 46
assert sum(map(len, archive_members.values())) == index["raw_bytes"] == 490458
owner_review = json.loads((owner_dir / "review.json").read_bytes())
assert owner_review["status"] == "passed"
assert len(owner_review["native_browser_checks"]) == 11
for group, count in [("actual_notes", 15), ("actual_traces", 4)]:
    assert len(owner_review[group]) == count
    for item in owner_review[group]:
        raw = archive_members["receiving/" + item["name"]]
        assert len(raw) == item["bytes"] and hashlib.sha256(raw).hexdigest() == item["sha256"]
        assert raw in [body for name, body in archive_members.items() if name.startswith("receiving/downloads/")]
assert archive_members["browser-execution.json"] == (owner_dir / "browser-execution.json").read_bytes()
owner_browser_report = json.loads(archive_members["receiving/receiving-report.json"])
owner_course = json.loads(archive_members["receiving/reused-id-local-course.json"])
assert len(owner_course["items"]) == 3
# Keep original source-bound owner results attributed; do not re-execute its browser driver.
archive_receipt = {"owner_review": digest((owner_dir / "review.json").read_bytes()),
    "source_pins": digest((ROOT / "owner-proof/picker-receiving-d8a9/browser-source-pins.json").read_bytes()),
    "encoded_archive": digest(encoded), "compressed_sha256": index["compressed_sha256"],
    "verified_members": len(archive_members), "raw_bytes": sum(map(len, archive_members.values())),
    "verified_notes": 15, "verified_traces": 4, "owner_browser_checks": 11,
    "fixture_item_count": len(owner_course["items"]), "fixture_ids": [x["id"] for x in owner_course["items"]],
    "owner_execution": json.loads(archive_members["browser-execution.json"]),
    "all_15_runtime_files_identical_to_current_3cde": True,
    "execution_repeated": False}
dump(ROOT / "owner-evidence-verification.json", archive_receipt)

prior_zip = Path("/tmp/hamon-7a9310dad255-recall19-review/probability-current-importer-review.zip")
zip_raw = prior_zip.read_bytes()
assert len(zip_raw) == 338198
assert hashlib.sha256(zip_raw).hexdigest() == "4e57c0269a4debbf5080f9169949360156ee30b33fc444afd2749e45cb9c93d8"
with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
    course = archive.read("published/courses/probability-foundations.json")
    trace_name = "evidence/modular/paused-trace.json"
    trace = archive.read(trace_name)
assert hashlib.sha256(course).hexdigest() == "17a35b359ab5c1f097931bba29dcf7deddc75c98accbf1cced8ae5eca9e9ad01"
assert digest(course)["git_blob"] == "82cc4bdd8bf22afc5ca84098a0b19c3d485d2f45"
assert course == (OLD / "courses/probability-foundations.json").read_bytes()
assert len(json.loads(course)["items"]) == 12
trace_doc = json.loads(trace)
assert len(trace_doc["firstAnswers"]) == 12
assert trace_doc["practice"]["answers"] == [{"item": "pf-c1", "choice": 2}]
save(SOURCE / "courses/probability-foundations.json", course)
records.append({"path": "courses/probability-foundations.json", "mode": "100644", **digest(course),
    "public_head": "226068c6e04677995b08a683c8997f66be1748b3",
    "capture": "exact course from original accepted owner 4487260 browser packet, independently matched prepared PR19"})
save(ROOT / "inputs/probability-prior-paused-trace.json", trace)
dump(ROOT / "prior-trace-provenance.json", {"owner_commit": "4487260efca6819f152435af9cf0a1b64a978d61",
    "archive": {"path": str(prior_zip), **digest(zip_raw)}, "member": trace_name, "trace": digest(trace),
    "course": digest(course), "calibration_output_used": False, "old_browser_result_relabelled": False})
payload = json.loads((ROOT.parent / "current-8b82/ready-publication-payload.json").read_bytes())
overlay = dict(public)
assert len(payload["entries"]) == 33
for item in payload["entries"]:
    assert item["path"] not in overlay, item["path"]
    overlay[item["path"]] = {"path": item["path"], "mode": item["mode"], "sha": item["sha"]}
context = {"format": "recallweave-current-source-compatibility/1", "assessed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "public_head": data["head"], "public_tree": data["tree"], "public_leaves": len(public),
    "current_plus_frozen_33_tree": tree_id(list(overlay.values())), "current_plus_frozen_33_leaves": len(overlay),
    "all_current_parent_leaves_preserved": True, "frozen_contribution_paths_unchanged": 33,
    "physical_learner_and_course_files": records, "physical_source_tree": tree_id(records),
    "owner_proof_files": proofs, "changed_files_since_8b82": data["changed_files"], "intervening_commits": data["commits"],
    "scope": "15 exact current learner/build inputs plus original 12-item course; metadata covers the entire current public tree",
    "owner_browser_qualification_bound_to_current_source": archive_receipt,
    "remaining_control": "One actual-module restored probability trace with canonical 12-item reflection notes; no repeated browser/math/full-suite run."}
dump(ROOT / "source-manifest.json", context)
dump(ROOT / "capture-receipt.json", {"status": "passed", "public_tree_verified": data["tree"],
    "source_manifest": digest((ROOT / "source-manifest.json").read_bytes()),
    "native_source_tree": context["physical_source_tree"], "current_plus_frozen_33_tree": context["current_plus_frozen_33_tree"],
    "physical_files": len(records), "owner_runtime_pins_matched": 15, "owner_raw_members_verified": 46,
    "old_probability_trace": digest(trace), "original_source_paths_untouched": True})
print(json.dumps(json.loads((ROOT / "capture-receipt.json").read_bytes()), indent=2))
