import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const [sourceRoot, downloadedPath, outputDir]=process.argv.slice(2);
assert.ok(sourceRoot&&downloadedPath&&outputDir);
fs.mkdirSync(outputDir,{recursive:true});
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const blob=b=>crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const pinned={
  'courses/dependency-graphs-explorer.html':'eda0dfa00efec0127818a66a9009da692c40a379',
  'courses/dependency-graphs.json':'6e36d7113308540eb923fe5f5c83f1ba0b0ac537',
  'src/deck.mjs':'f0f8a4b234489c2388f427633f548d56c6ed4c03',
  'demo.html':'cf7eea3792deacc3eb98a22aef539b920fb66746'
};
function pins(){return Object.fromEntries(Object.keys(pinned).map(p=>{const b=fs.readFileSync(path.join(sourceRoot,p));return [p,{bytes:b.length,git_blob:blob(b),sha256:digest(b)}];}));}
const before=pins();
for(const [p,expected] of Object.entries(pinned))assert.equal(before[p].git_blob,expected,p);
assert.equal(before['demo.html'].bytes,97565);
const actualDownload=fs.readFileSync(downloadedPath);
assert.equal(actualDownload.length,12121);
assert.equal(digest(actualDownload),'e6538a1a28c6a1ce31be2b20095abf8c0d4461c4ba3aa07388181f9efd57810d');
assert.deepEqual(actualDownload,fs.readFileSync(path.join(sourceRoot,'courses/dependency-graphs.json')));
const {parseDeck}=await import(pathToFileURL(path.join(sourceRoot,'src/deck.mjs')));
const course=parseDeck(actualDownload.toString('utf8'));
assert.equal(course.items.length,12);
const runtime=fs.mkdtempSync('/dev/estate-60b2c08feb01-recall-current-import-');
const executable='/workspace/scratch/3e50c5ad22c5/production/browser/chromium';
const oldTmp=process.env.TMPDIR;process.env.TMPDIR=runtime;
const report={
 schema:'recallweave.independent-current-learner-import.v1',
 started_at:new Date().toISOString(),passed:false,
 graph_source:{head:'b48f33b507418ef4eaa16407567e7dfa5567218c',tree:'2bd8932fbfdfb2be5449940820dc30c096052a70'},
 learner_source:{reported_current_main:'1082482afe31e557e36b1a694b2eb9917729c2dd',reported_tree:'6f53870452adc29420627f5e269870fb5fe9982d',exact_fetched_blob:pinned['demo.html'],connector_url:'https://api.github.com/repos/Jacob-Met/RecallWeave/git/blobs/'+pinned['demo.html']},
 purpose:'Only the current learner import boundary; previous four graph groups are carried from their separate raw failed process without relabeling it as a clean run.',
 previous_raw_browser:{exit_code:1,receipt_sha256:'846eddb89ab9b0429ffb78b97ca1bd2a02db1d34a856ecd1a95412d93e354467',harness_error:'An extra #start-button click after Start this deck had already called renderQuestion.'},
 actual_download:{path:downloadedPath,bytes:actualDownload.length,sha256:digest(actualDownload),git_blob:blob(actualDownload),source:'Actual original-course download from previous browser run'},
 source:{before},runtime:{node:process.version,platform:os.platform(),browserExecutable:executable,private_profile:true},
 network:{offline:true,requests:[],off_origin:[]},page_errors:[],console_errors:[],dialogs:[],
 substitutions:{source_edits:0,API:0,HTML:0,responses:0},steps:[],cleanup:{}
};
let context,graph,learner,phase='launch';
const attach=p=>{
 p.on('pageerror',e=>report.page_errors.push({phase,error:String(e)}));
 p.on('console',m=>{if(m.type()==='error')report.console_errors.push({phase,text:m.text()});});
 p.on('dialog',async d=>{report.dialogs.push({phase,type:d.type(),message:d.message()});await d.dismiss();});
};
try{
 context=await chromium.launchPersistentContext(path.join(runtime,'profile'),{executablePath:executable,headless:true,viewport:{width:1120,height:900},acceptDownloads:true,args:['--no-sandbox','--disable-dev-shm-usage'],env:{...process.env,TMPDIR:runtime}});
 context.setDefaultTimeout(10000);report.runtime.chromium=context.browser().version();
 context.on('page',attach);for(const p of context.pages())attach(p);
 context.on('request',r=>{report.network.requests.push({phase,url:r.url(),method:r.method()});if(!/^(file|data|blob|about):/.test(r.url()))report.network.off_origin.push(r.url());});
 await context.route('**/*',route=>/^(file|data|blob|about):/.test(route.request().url())?route.continue():route.abort());
 await context.setOffline(true);
 graph=await context.newPage();
 phase='actual frozen companion and current relative learner link';
 await graph.goto(pathToFileURL(path.join(sourceRoot,'courses/dependency-graphs-explorer.html')).href,{waitUntil:'domcontentloaded'});
 const historyBefore=await graph.locator('#completion-history').textContent();
 const next=context.waitForEvent('page');
 await graph.getByRole('link',{name:'Open the learner in another tab',exact:true}).click();
 learner=await next;await learner.waitForLoadState('domcontentloaded');
 assert.equal(learner.url(),pathToFileURL(path.join(sourceRoot,'demo.html')).href);
 await learner.locator('#deck-file').waitFor({state:'visible'});
 assert.equal(await learner.locator('#step-count').textContent(),'0 / 6');
 report.steps.push({name:phase,passed:true,learner_url:learner.url(),graph_url:graph.url(),initial_progress:'0 / 6'});
 phase='actual downloaded course picker and explicit preview';
 await learner.locator('#deck-file').setInputFiles(downloadedPath);
 await learner.locator('#deck-preview').waitFor({state:'visible'});
 assert.equal(await learner.locator('#deck-preview-title').textContent(),course.title);
 assert.deepEqual(await learner.locator('#deck-preview .deck-questions strong').allTextContents(),course.items.map(x=>x.prompt));
 assert.equal(await learner.locator('#deck-preview .deck-preview-attribution').textContent(),'Attribution supplied in the deck: '+course.attribution);
 assert.equal(await learner.locator('#deck-preview .deck-preview-license').textContent(),'License supplied in the deck: '+course.license);
 assert.equal(await learner.locator('#step-count').textContent(),'0 / 6');
 report.steps.push({name:phase,passed:true,title:course.title,prompts:course.items.map(x=>x.prompt),attribution:course.attribution,license:course.license,active_progress_still:'0 / 6'});
 phase='Start this deck directly enters the first original question';
 await learner.locator('#start-deck').focus();
 await learner.keyboard.press('Enter');
 await learner.locator('#session-content .question-card h2').waitFor({state:'visible'});
 assert.equal(await learner.locator('#step-count').textContent(),'0 / 12');
 const prompt=await learner.locator('#session-content .question-card h2').textContent();
 const item=course.items.find(x=>x.prompt===prompt);assert.ok(item,'first prompt must be exact original course content');
 const choices=await learner.locator('#session-content [data-choice]').evaluateAll(nodes=>nodes.map(n=>({choice:Number(n.dataset.choice),text:n.textContent,disabled:n.disabled})));
 assert.equal(choices.length,item.options.length);
 assert.deepEqual(choices.map(x=>x.choice).sort((a,b)=>a-b),item.options.map((_,i)=>i));
 for(const choice of choices){assert.ok(choice.text.includes(item.options[choice.choice]));assert.equal(choice.disabled,false);}
 assert.equal(await learner.locator('#session-content #start-button').count(),0);
 assert.equal(await learner.locator('#step-count').textContent(),'0 / 12');
 assert.equal(await graph.locator('#completion-history').textContent(),historyBefore);
 report.steps.push({name:phase,passed:true,item_id:item.id,prompt,choices,active_progress:'0 / 12',answer_submitted:false,extra_welcome_click_required:false,graph_progress_unchanged:true});
 assert.deepEqual(report.network.off_origin,[]);assert.deepEqual(report.page_errors,[]);assert.deepEqual(report.console_errors,[]);assert.deepEqual(report.dialogs,[]);
 report.passed=true;
}catch(error){report.error={phase,name:error.name,message:error.message,stack:error.stack};}
finally{
 if(context)try{await context.close();report.cleanup.browser_closed=true;}catch(e){report.cleanup.browser_close_error=String(e);report.passed=false;}
 report.source.after=pins();report.source.unchanged=JSON.stringify(before)===JSON.stringify(report.source.after);
 if(!report.source.unchanged)report.passed=false;
 report.actual_download.after_sha256=digest(fs.readFileSync(downloadedPath));
 if(report.actual_download.after_sha256!==report.actual_download.sha256)report.passed=false;
 fs.rmSync(runtime,{recursive:true,force:true});report.cleanup.private_profile_removed=!fs.existsSync(runtime);
 if(oldTmp===undefined)delete process.env.TMPDIR;else process.env.TMPDIR=oldTmp;
 report.finished_at=new Date().toISOString();report.harness_sha256=digest(fs.readFileSync(process.argv[1]));
 fs.writeFileSync(path.join(outputDir,'receipt.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({passed:report.passed,steps:report.steps.map(s=>({name:s.name,passed:s.passed})),source_unchanged:report.source.unchanged,page_errors:report.page_errors,console_errors:report.console_errors,off_origin:report.network.off_origin,error:report.error,cleanup:report.cleanup,receipt_sha256:digest(fs.readFileSync(path.join(outputDir,'receipt.json')))}));
 process.exitCode=report.passed?0:1;
}
