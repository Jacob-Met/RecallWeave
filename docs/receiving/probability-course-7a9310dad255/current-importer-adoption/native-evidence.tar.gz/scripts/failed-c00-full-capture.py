import json,hashlib,urllib.request,tarfile,shutil,subprocess,time
from pathlib import Path
root=Path("/tmp/hamon-7a9310dad255-recall19-integration")
work=root/"current-c00";work.mkdir()
expected=json.loads((root/"expected-current-c00.json").read_text())
def pin(data):
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
def tree_id(rows):
    tree={}
    for row in rows:
        node=tree;parts=row["path"].split("/")
        for part in parts[:-1]:node=node.setdefault(part,{})
        assert parts[-1] not in node
        node[parts[-1]]=(row["mode"],row["git_blob"])
    def emit(node):
        data=b""
        for name,item in sorted(node.items(),key=lambda x:(x[0]+("/" if isinstance(x[1],dict) else "")).encode()):
            mode,sha=("40000",emit(item)) if isinstance(item,dict) else item
            data+=mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(sha)
        return hashlib.sha1(b"tree "+str(len(data)).encode()+b"\0"+data).hexdigest()
    return emit(tree)
def snapshot(where):
    rows=[]
    for p in sorted(where.rglob("*")):
        assert not p.is_symlink(),str(p)
        if p.is_file():rows.append({"path":str(p.relative_to(where)),"mode":"100755" if p.stat().st_mode&0o111 else "100644",**pin(p.read_bytes())})
    return rows
receipt={"started_at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"repository":expected["repository"],"current_head":expected["current_head"],"current_tree":expected["current_tree"],"course_head":expected["course_head"],"prior_source_label":"d202 composition retained unchanged","commands":[],"completed":False}
started=time.monotonic()
try:
    url="https://codeload.github.com/Jacob-Met/RecallWeave/tar.gz/"+expected["current_head"]
    with urllib.request.urlopen(url,timeout=45) as response:
        assert response.status==200
        archive=response.read(64*1024*1024+1)
    assert len(archive)<=64*1024*1024
    archive_path=work/"public-current-c00.tar.gz"
    with archive_path.open("xb") as f:f.write(archive)
    receipt["download"]={"url":url,**pin(archive)}
    baseline=work/"baseline";baseline.mkdir()
    wanted={x["path"]:x for x in expected["current_entries"]};seen=set()
    with tarfile.open(archive_path,"r:gz") as tar:
        for item in tar:
            if not item.isfile():continue
            path=item.name.split("/",1)[1]
            if path not in wanted:continue
            assert path not in seen and not Path(path).is_absolute() and ".." not in Path(path).parts
            data=tar.extractfile(item).read();x=wanted[path]
            assert len(data)==x["size"] and pin(data)["git_blob"]==x["sha"],path
            out=baseline/path;out.parent.mkdir(parents=True,exist_ok=True)
            with out.open("xb") as f:f.write(data)
            assert x["mode"] in ["100644","100755"]
            out.chmod(0o755 if x["mode"]=="100755" else 0o644);seen.add(path)
    assert set(wanted)==seen
    base=snapshot(baseline);assert len(base)==496 and tree_id(base)==expected["current_tree"]
    candidate=work/"candidate";shutil.copytree(baseline,candidate)
    patch=root/"original-course-28.patch"
    for command in [["git","apply","--check",str(patch)],["git","apply",str(patch)]]:
        p=subprocess.run(command,cwd=candidate,env={"PATH":"/usr/bin:/bin","GIT_OPTIONAL_LOCKS":"0"},capture_output=True)
        receipt["commands"].append({"argv":command,"exit":p.returncode,"stdout":p.stdout.decode(),"stderr":p.stderr.decode()})
        assert p.returncode==0
    proof=Path("docs/receiving/probability-course-7a9310dad255/current-importer-adoption")
    shutil.copytree(root/"candidate"/proof,candidate/proof)
    readme=candidate/proof/"README.md"
    text=readme.read_text()
    old="The integration preparation ordinarily applies the original 28-file binary patch over all 444 current leaves. No current file overlaps those additions. All incoming bytes and modes are preserved."
    new="The initial integration preparation ordinarily applied the original 28-file binary patch over all 444 leaves at d202. A later public main, \`c00bd1f31c353698957d2ebad311334536cdef98\` (tree \`22edf70cdecedd0788170d7956159a2e8f8cac30\`), added the shortest-path and enzyme contributions and SQL receiving documentation. Its 496-file source includes one updated SQL guide and 52 added files. The current composition applies the same course patch over that exact parent and preserves all 496 incoming blobs and modes; none overlaps the course additions. All fourteen received learner inputs remain exact. The required test command runs again because the newly merged shortest-path test changes its input set."
    new=new.replace("\\\`","\`")
    assert text.count(old)==1
    readme.write_text(text.replace(old,new))
    final=snapshot(candidate);fm={x["path"]:x for x in final};bm={x["path"]:x for x in base}
    assert len(final)==527
    assert all(fm[p]==x for p,x in bm.items())
    assert all(fm[x["path"]]["git_blob"]==x["sha"] and fm[x["path"]]["mode"]==x["mode"] for x in expected["course_entries"])
    acceptance=json.loads((candidate/proof/"independent-assessment.json").read_text())
    assert all(fm[x["path"]]["git_blob"]==x["git_blob"] for x in acceptance["learner_source_pins"])
    manifest={"repository":expected["repository"],"current_head":expected["current_head"],"current_tree":expected["current_tree"],"course_head":expected["course_head"],"source_tree":tree_id(final),"files":final,"all_496_current_leaves_preserved":True,"all_28_original_contribution_paths_preserved":True,"all_14_received_learner_inputs_preserved":True,"source_label":"c00 current source + original 28 course files + three additive adoption documents; before required native checks"}
    with (work/"pre-ci-source-manifest.json").open("x") as f:json.dump(manifest,f,indent=2);f.write("\n")
    receipt.update({"completed":True,"parent_leaves":496,"candidate_leaves":527,"source_tree":manifest["source_tree"],"all_current_leaves_preserved":True,"all_28_original_contribution_paths_preserved":True,"all_14_received_learner_inputs_preserved":True,"source_manifest":pin((work/"pre-ci-source-manifest.json").read_bytes())})
except Exception as error:
    receipt["error"]={"type":type(error).__name__,"message":str(error)}
finally:
    receipt["finished_at_utc"]=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime());receipt["seconds"]=time.monotonic()-started
    with (work/"capture-composition-receipt.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
    print(json.dumps(receipt,indent=2))
if not receipt["completed"]:raise SystemExit(1)
