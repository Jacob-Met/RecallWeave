import base64,datetime,gzip,hashlib,io,json,pathlib,sys,tarfile
root=pathlib.Path(__file__).resolve().parent
packet=root/"final-native-v2";packet.mkdir(exist_ok=False)
def pin(name,data):
 return {"path":name,"mode":"100644","bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"gitBlob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
def enc(doc):
 return (json.dumps(doc,ensure_ascii=False,indent=2,sort_keys=True)+"\n").encode()
def save(path,data):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open("xb") as h:h.write(data)
 if path.read_bytes()!=data:raise RuntimeError("Readback differs")
raw=(root/"native-v2/stdout.json").read_bytes();report=json.loads(raw)
if hashlib.sha256(raw).hexdigest()!="8d11b2c928ef037080250663e656b9c6b4e1fe99f483a64283e78ab8c7d6022b" or report["checks"]!={"passed":5890,"failed":0} or not report["sourcePinsUnchanged"]:raise RuntimeError("Raw receipt drift")
if len(report["observations"])!=252 or any(not x["passed"] for x in report["observations"]):raise RuntimeError("Incomplete cases")
for case in report["observations"]:
 for page in case["pages"]:
  if page["actualProjectionSha256"]!=page["expectedProjectionSha256"]:raise RuntimeError("Page digest mismatch")
owner=pathlib.Path("/home/jacob/snap/chromium/common/optimizer-counting-principles-3dab-20261008/source-v1/src/counting-principles.mjs")
for path in [owner,root/"source/counting-principles.mjs"]:
 if hashlib.sha256(path.read_bytes()).hexdigest()!="7997430fe73448c67f7ee1bb58c76534606d2499c1cec2e44234039eb9e4f55b":raise RuntimeError("Core drift")
oracle=(root/"blind-counting-oracle-v1.tar.gz").read_bytes()
if hashlib.sha256(oracle).hexdigest()!="df0e6e43fb73d6ac723d99196cc5e0615ef89a16f2a51ea96dda290914b4e2b7":raise RuntimeError("Oracle drift")
oracle_manifest=(root/"blind-oracle-v1/MANIFEST.json").read_bytes()
for expected in json.loads(oracle_manifest)["files"]:
 if pin(expected["path"],(root/"blind-oracle-v1"/expected["path"]).read_bytes())!=expected:raise RuntimeError("Oracle member drift")
partial=(root/"build-review-packet-v2.py").read_bytes()
if partial!=b"":raise RuntimeError("Original negative partial changed")
dependency={"archive":pin("blind-counting-oracle-v1.tar.gz",oracle),"manifest":pin("MANIFEST.json",oracle_manifest),"fixture":pin("blind-oracles.json",(root/"blind-oracle-v1/blind-oracles.json").read_bytes()),"recoveryCommit":"c185a8f591f3e0e3f7401037b9e2b047bc62c9d8","regenerated":False}
names=["REVIEW.md","REPLAY.md","SOURCE_CUSTODY.json","PAGE-FIELD-CLARIFICATION.json","receiver-preflight.json","receive_counting_native_v2.mjs","run-native-v2.py","source/counting-principles.mjs","source/browser-source-v1-pins.json","native-v2/source-freeze.json","native-v2/stdout.json","native-v2/stderr.txt","native-v2/controller-receipt.json","native-v2/MANIFEST.json","build-review-packet-v2b.py"]
payloads={name:(root/name).read_bytes() for name in names}
payloads["capacity-failure/build-review-packet-v2.py"]=partial
payloads["capacity-failure/receipt.json"]=enc({"format":"native-seal-capacity-failure-v1","originalWriteResult":"ENOSPC; zero-byte new script left in the owned root","observedNativeFreeBytes":0,"partialExecuted":False,"rawNativeOutputPreserved":pin("native-v2/stdout.json",raw),"successor":"New uniquely named packaging script after independently reported capacity recovery; no core or oracle regeneration."})
payloads["blind-oracle-dependency.json"]=enc(dependency)
payloads["post-guard.json"]=enc({"checkedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"ownerCore":pin(str(owner),owner.read_bytes()),"ownedCore":pin("source/counting-principles.mjs",(root/"source/counting-principles.mjs").read_bytes()),"all252CasesPassed":True,"all391PageDigestsMatch":True,"originalOracleMembersExact":True,"productExecution":False,"rootIndependentAudit":{"path":"/home/jacob/snap/chromium/common/root-evidence-verification-3dab-20261008/counting-native-v2-report-audit.json","sha256":"d74b875aafb5789567f04a793f611f980863d418996369f29ab1a9c99318900d","bytes":1423}})
for name,data in payloads.items():save(packet/name,data)
manifest={"format":"independent-counting-native-review-v2-manifest","frozenUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"disposition":"APPROVE exact core7997430f on the distinct durable Node22 run","originalNode24RawByteCustody":"Lost; observed success and recorded hashes only","externalImmutableDependency":dependency,"files":[pin(name,payloads[name]) for name in sorted(payloads)]}
manifest_bytes=enc(manifest);payloads["MANIFEST.json"]=manifest_bytes;save(packet/"MANIFEST.json",manifest_bytes)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode="w",format=tarfile.PAX_FORMAT) as tar:
 for name in sorted(payloads):
  data=payloads[name];entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.uid=entry.gid=0;entry.mtime=0;entry.uname=entry.gname="";tar.addfile(entry,io.BytesIO(data))
zipped=gzip.compress(buffer.getvalue(),mtime=0)
archive_path=root/"independent-counting-native-review-v2.tar.gz";save(archive_path,zipped)
with tarfile.open(fileobj=io.BytesIO(zipped),mode="r:gz") as tar:
 members=tar.getmembers()
 if sorted(x.name for x in members)!=sorted(payloads):raise RuntimeError("Archive member set")
 for member in members:
  if not member.isfile() or member.mode!=0o644 or member.uid!=0 or member.gid!=0 or member.mtime!=0 or tar.extractfile(member).read()!=payloads[member.name]:raise RuntimeError("Archive member drift")
prefix="docs/receiving/counting-principles-independent-3dab-20261008/"
items=[("blind-counting-oracle-v1.tar.gz",oracle,"base64"),("blind-oracle-MANIFEST.json",oracle_manifest,"utf-8"),("independent-counting-native-review-v2.tar.gz",zipped,"base64"),("native-review-v2-MANIFEST.json",manifest_bytes,"utf-8"),("REVIEW.md",payloads["REVIEW.md"],"utf-8")]
allowlist=[]
with (root/"publication-transfer-v2.jsonl").open("x",encoding="utf-8",newline="\n") as h:
 for name,data,encoding in items:
  item=pin(prefix+name,data);item["encoding"]=encoding;allowlist.append(dict(item));item["content"]=base64.b64encode(data).decode() if encoding=="base64" else data.decode();h.write("TRANSFER_JSON:"+json.dumps(item,ensure_ascii=False,separators=(",",":"))+"\n")
ready={"format":"counting-native-v2-publication-ready","root":str(root),"packet":str(packet),"payloadFiles":len(payloads),"archive":pin(archive_path.name,zipped),"manifest":pin("final-native-v2/MANIFEST.json",manifest_bytes),"review":pin("REVIEW.md",payloads["REVIEW.md"]),"nativeRaw":pin("native-v2/stdout.json",raw),"allowlist":allowlist,"transfer":pin("publication-transfer-v2.jsonl",(root/"publication-transfer-v2.jsonl").read_bytes()),"noCoreOrOracleRerun":True}
save(root/"publication-ready-v2.json",enc(ready));print(json.dumps(ready,sort_keys=True))
