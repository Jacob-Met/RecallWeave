$ErrorActionPreference = 'Stop'
$root = 'D:/Hamon/receiving/recall-sorting-networks-root-db371a37f4c8'
$os = Get-CimInstance Win32_OperatingSystem
$c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='D:'"
$guard = [ordered]@{schema='recall253-root-native-guard-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;machine=[Environment]::MachineName;user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;boot=$os.LastBootUpTime.ToUniversalTime().ToString('o');freeC=[long]$c.FreeSpace;freeD=[long]$d.FreeSpace;freeMemory=[long]$os.FreePhysicalMemory*1024;floorC=1073741824;floorD=1073741824;floorMemory=2147483648}
$guard | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 "$root/CANDIDATE-CLOSE-r1-GUARD.json"
if ($guard.machine -ne 'MSI' -or $guard.user -ne 'MSI\Veria' -or $guard.boot -ne '2026-10-04T04:03:32.5000000Z' -or $guard.freeC -lt $guard.floorC -or $guard.freeD -lt $guard.floorD -or $guard.freeMemory -lt $guard.floorMemory) { throw 'Identity, boot or resource guard refused' }

$all = @(Get-CimInstance Win32_Process)
$selfProcess = $all | Where-Object ProcessId -eq $PID
$ignored = @($PID, $selfProcess.ParentProcessId)
$known = @(10296,23636,5992,24888,16724,12880,3312,3660,22688,10364,21336)
$closeAt = [DateTime]::Parse('2026-10-09T11:16:40.065Z').ToUniversalTime()
$found = @($all | Where-Object { $_.ProcessId -in $known } | ForEach-Object { [ordered]@{pid=[int]$_.ProcessId;ppid=[int]$_.ParentProcessId;name=$_.Name;creation=$_.CreationDate.ToUniversalTime().ToString('o');command=$_.CommandLine;predatesClose=($_.CreationDate.ToUniversalTime() -le $closeAt)} })
$owned = @($all | Where-Object { $_.ProcessId -notin $ignored -and $_.CommandLine -and ($_.CommandLine.Replace('\','/').Contains($root)) } | ForEach-Object {[ordered]@{pid=[int]$_.ProcessId;ppid=[int]$_.ParentProcessId;name=$_.Name;creation=$_.CreationDate.ToUniversalTime().ToString('o');command=$_.CommandLine}})
$receipt = [ordered]@{schema='recall253-candidate-delayed-closure-v1';at=[DateTime]::UtcNow.ToString('o');observer=$PID;observerParent=$selfProcess.ParentProcessId;knownNumbers=$known;currentlyPresentHistoricalNumbers=$found;presentOriginalBrowserIdentities=@($found | Where-Object predatesClose);ownedNamespace=$owned;signalsSent=@()}
$receipt | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 "$root/CANDIDATE-CLOSURE-r1.json"
if ($receipt.presentOriginalBrowserIdentities.Count -ne 0 -or $owned.Count -ne 0) { throw 'Candidate browser closure incomplete; no signal sent' }
& 'C:/Program Files/nodejs/node.exe' "$root/control-native.mjs" "$root/candidate-close-r1-control.json"
$code = $LASTEXITCODE
[ordered]@{schema='recall253-native-outer-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;exitCode=$code} | ConvertTo-Json | Set-Content -Encoding UTF8 "$root/CANDIDATE-CLOSE-r1-OUTER.json"
exit $code
