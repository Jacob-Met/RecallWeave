from pathlib import Path
import json,hashlib,datetime,difflib,re
root=Path(__file__).resolve().parent
x=json.loads((root/"admission-inputs.json").read_text())
def h(b,kind="sha256"): return hashlib.new(kind,b).hexdigest()
def blob(b): return h(b"blob "+str(len(b)).encode()+b"\0"+b,"sha1")
def treecheck(tree):
 assert not tree["truncated"]
 groups={}
 for e in tree["tree"]:
  parent,_,name=e["path"].rpartition("/")
  groups.setdefault(parent,[]).append((name,e))
 def walk(path):
  out=bytearray()
  for name,e in sorted(groups.get(path,[]),key=lambda v:(v[0]+("/" if v[1]["type"]=="tree" else "")).encode()):
   assert e["type"] in ("tree","blob")
   digest=walk(e["path"]) if e["type"]=="tree" else e["sha"]
   assert digest==e["sha"]
   mode="40000" if e["type"]=="tree" else e["mode"]
   out.extend(mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(digest))
  return h(b"tree "+str(len(out)).encode()+b"\0"+out,"sha1")
 actual=walk("")
 assert actual==tree["sha"]
 return {"tree":actual,"leaves":sum(e["type"]=="blob" for e in tree["tree"])}
proof={key:treecheck(x[key]) for key in ("base_tree","published_tree","current_tree","test_tree")}
maps={key:{e["path"]:e for e in x[key]["tree"] if e["type"]=="blob"} for key in proof}
assert x["test_merge"]["tree"]["sha"]==proof["test_tree"]["tree"]
assert [p["sha"] for p in x["test_merge"]["parents"]]==[x["main"]["commit"]["sha"],x["pr"]["head"]["sha"]]
overlay={e["path"]:e for e in x["overlay"]}
assert len(overlay)==18
for path,e in maps["current_tree"].items():
 if path not in overlay: assert maps["test_tree"][path]==e
for path,e in overlay.items():
 if path!="README.md": assert maps["test_tree"][path]==e
assert set(maps["test_tree"])==set(maps["current_tree"])|set(overlay)
texts={k:v["content"] for k,v in x["readmes"].items()}
for k,v in x["readmes"].items(): assert blob(v["content"].encode())==v["sha"]
assert texts["published"].startswith(texts["base"])
append=texts["published"][len(texts["base"]):]
assert texts["test_merge"]==texts["current"]+append
assert texts["test_merge"].count(append)==1
assert len(append)==966
unchanged=[]
for path,pin in x["browser_source_projection"]["source_files"].items():
 if pin["role"]=="exact-current-parent":
  assert maps["current_tree"][path]["sha"]==maps["test_tree"][path]["sha"]==pin["git_blob"]
  unchanged.append(path)
assert len(unchanged)==44
assert not [p for p in maps["current_tree"] if p.split("/")[-1] in ("AGENTS.md","CONTINUE.md")]
raw=x["root_review_source"]["content"].encode()
assert h(raw)==x["root_review_expected_sha256"] and blob(raw)==x["root_review_source"]["sha"]
for name,pair in [("README-current.patch",{"before":x["readmes"]["base"],"current":x["readmes"]["current"]}),("sampling-guide-current.patch",x["sampling_guides"])]:
 (root/name).write_text("".join(difflib.unified_diff(pair["before"]["content"].splitlines(True),pair["current"]["content"].splitlines(True),fromfile="7c/before",tofile="964/current")))
node=(root/"pr-node-job.log").read_text()
browser=(root/"pr-catalog-browser-job.log").read_text()
testmerge=x["test_merge"]["sha"]
assert testmerge in node and testmerge in browser
assert "node: v20.20.2" in node
for label,value in [("tests",296),("pass",296),("fail",0),("skipped",0)]:
 assert re.search(r"# "+label+r" "+str(value)+r"\b",node)
assert '"status":"passed","checks":11,"downloads":11' in browser
assert all(j["conclusion"]=="success" for key in ("node_jobs","catalog_jobs") for j in x[key]["jobs"])
receipt={"format":"recallweave-pr88-current-admission/1","decision":"accepted",
 "at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"delegate":"68094585a1c2 / memory_delivery",
 "authority":"Root delegated the unchanged-scope remaining PR88 composition, exact-head merge and delivery sequence.",
 "pr":88,"head":x["pr"]["head"]["sha"],"current_parent":x["main"]["commit"]["sha"],"test_merge":testmerge,
 "trees":proof,"original_overlay_paths":18,"unowned_current_leaves_preserved":1484,"non_readme_contribution_leaves_exact":17,
 "readme":"The actual test-merge README equals every current-parent byte plus the exact original966-character course block, once.",
 "browser_shared_pins_unchanged":unchanged,
 "current_source_delta":"Independent course catalog and browser gate; sampling guide/receiving documentation. No previously executed learner source changed.",
 "source_conflict":"Initial mergeability was pending/false at creation; fresh GitHub result is clean. The actual ordinary test merge already composes the exact desired tree; no author branch update or repeated suite is needed.",
 "ancestry":"Normal expected-head merge will retain current main and original published contribution as parents.",
 "hosted_gates":{"node":{"run":37805357980,"job":113408089357,"checkout":testmerge,"node":"20.20.2","tests":296,"pass":296,"fail":0,"skipped":0,"demo_parity":True},
 "catalog":{"run":37805357938,"job":113408089954,"checkout":testmerge,"node":"22.23.3","chrome":"154.0.8037.97","checks":11,"downloads":11,"conclusion":"success"}},
 "root_review_sha256":x["root_review_expected_sha256"],
 "limits":["No repeated native/current-browser suite; prior source and browser receipts retain their original checkout identities.",
 "No new source/configuration or workflow edits. Existing Pages failure observation is preserved separately and its cause remains unknown.",
 "This premerge receipt is not a merge or public deployment claim."]}
(root/"current-admission.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"decision":"accepted","trees":proof,"receipt_sha256":h((root/"current-admission.json").read_bytes())},indent=2))
