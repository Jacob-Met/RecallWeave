// Receiver oracle derived before reading author implementation.
// Enumerate permutations; compute positive path closure independently.
export function* permutations(xs) {
  if (!xs.length) { yield []; return; }
  for (let i=0;i<xs.length;i++)
    for (const tail of permutations(xs.slice(0,i).concat(xs.slice(i+1))))
      yield [xs[i],...tail];
}
export function closure(g) {
  const ix=new Map(g.jobs.map((x,i)=>[x,i]));
  const p=g.jobs.map(()=>g.jobs.map(()=>false));
  for (const [a,b] of g.edges) p[ix.get(a)][ix.get(b)]=true;
  for(let k=0;k<p.length;k++) for(let i=0;i<p.length;i++) for(let j=0;j<p.length;j++)
    p[i][j] ||= p[i][k] && p[k][j];
  return p; // No reflexive seed; self means an actual positive-length cycle.
}
export function validHistory(g,h) {
  if(!Array.isArray(h)) return false;
  const done=new Set();
  for(const x of h) {
    if(!g.jobs.includes(x)||done.has(x)||g.edges.some(([a,b])=>b===x&&!done.has(a))) return false;
    done.add(x);
  }
  return true;
}
export function expected(g,h=[]) {
  if(!validHistory(g,h)) throw Error('invalid oracle history');
  const p=closure(g),done=new Set(h),ci=g.jobs.map((_,i)=>i).filter(i=>p[i][i]);
  const cycleMembers=ci.map(i=>g.jobs[i]),seen=new Set(),cycleComponents=[];
  for(const i of ci) if(!seen.has(i)) {
    const group=ci.filter(j=>p[i][j]&&p[j][i]);
    group.forEach(j=>seen.add(j));cycleComponents.push(group.map(j=>g.jobs[j]));
  }
  const blockedByCycle=g.jobs.filter((x,i)=>!cycleMembers.includes(x)&&ci.some(j=>p[j][i]));
  const rows=g.jobs.map(name=>{
    const prerequisites=g.jobs.filter(a=>g.edges.some(([x,y])=>x===a&&y===name));
    return {name,prerequisites,unmet:prerequisites.filter(x=>!done.has(x))};
  });
  const remaining=g.jobs.filter(x=>!done.has(x));
  return {ready:remaining.filter(x=>!rows.find(r=>r.name===x).unmet.length),
    cycleComponents,cycleMembers,blockedByCycle,rows,remaining,finished:!remaining.length,
    reachability:Object.fromEntries(g.jobs.map((x,i)=>[x,g.jobs.filter((_,j)=>p[i][j])]))};
}
export function allCompletions(g,h=[]) {
  if(!validHistory(g,h)) throw Error('invalid oracle history');
  const out=[];
  for(const suffix of permutations(g.jobs.filter(x=>!h.includes(x)))) {
    const order=h.concat(suffix),pos=new Map(order.map((x,i)=>[x,i]));
    if(g.edges.every(([a,b])=>pos.get(a)<pos.get(b))) out.push(order);
  }
  return out;
}
export function* histories(jobs) {
  yield [];
  function* walk(prefix,rest) {
    for(let i=0;i<rest.length;i++) {
      const next=prefix.concat(rest[i]);yield next;
      yield* walk(next,rest.slice(0,i).concat(rest.slice(i+1)));
    }
  }
  yield* walk([],jobs);
}
export function* allThreeJobGraphs() {
  const jobs=['Third','First','Second'],possible=jobs.flatMap(a=>jobs.map(b=>[a,b]));
  for(let mask=0;mask<2**possible.length;mask++)
    yield {jobs:jobs.slice(),edges:possible.filter((_,i)=>mask&(1<<i))};
}
export const boundaryGraphs=[
 {name:'two disjoint cycles with ancestors and descendants',graph:{
   jobs:['Lead','A','B','Tail','Side','C','D','Out'],
   edges:[['Lead','A'],['A','B'],['B','A'],['B','Tail'],['C','D'],['D','C'],['D','Out']]}},
 {name:'diamond plus independent job',graph:{
   jobs:['Final','Left','Right','Start','Spare'],
   edges:[['Start','Left'],['Start','Right'],['Left','Final'],['Right','Final']]}},
 {name:'eight independent jobs, deliberately unsorted',graph:{
   jobs:['z','Y','x','W','v','U','t','S'],edges:[]}},
 {name:'eight-job chain against input order',graph:{
   jobs:['H','G','F','E','D','C','B','A'],
   edges:[['A','B'],['B','C'],['C','D'],['D','E'],['E','F'],['F','G'],['G','H']]}},
 {name:'prototype-like, literal and Unicode names',graph:{
   jobs:['__proto__','constructor','toString','<b>Plan</b>','章甲','章乙'],
   edges:[['__proto__','constructor'],['constructor','<b>Plan</b>'],['章甲','章乙']]}}
];
