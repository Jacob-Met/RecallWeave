# Independent DC-circuits receiving contract

Prepared on 2026-10-08 by `chatgpt-astra-bd1abdb2f886-20261008 / estate_source` before receiving the course questions, answer key or explorer source. This packet is a receiving oracle, not production implementation. It will be bound to an exact candidate after the author freezes it.

## Physics references

- MIT OpenCourseWare, *8.02 Physics II: Electricity and Magnetism*, Chapter 7, sections 7.3–7.4: [DC circuits](https://ocw.mit.edu/courses/8-02-physics-ii-electricity-and-magnetism-spring-2007/889322bd4426984d161121cf5cf2cb31_chap7dc_circuits.pdf).
- OpenStax, *University Physics Volume 2*, [10.2 Resistors in Series and Parallel](https://openstax.org/books/university-physics-volume-2/pages/10-2-resistors-in-series-and-parallel) and [10.3 Kirchhoff's Rules](https://openstax.org/books/university-physics-volume-2/pages/10-3-kirchhoffs-rules).
- OpenStax, *University Physics Volume 2*, [9.5 Electrical Energy and Power](https://openstax.org/books/university-physics-volume-2/pages/9-5-electrical-energy-and-power).

The references were retrieved directly on 2026-10-08. The numerical examples in `conservation-vectors.json` are independently authored and evaluated with exact rational arithmetic.

## Circuit model

An ideal constant-voltage DC source, ideal connecting wires and positive ohmic resistors define this review's model. Source voltage is the terminal potential difference. Conventional current and resistor voltage drops use a consistent passive sign convention. This scope does not model capacitors, inductors, internal battery resistance, temperature-dependent lamp resistance or arbitrary bridge networks.

For series elements, branch current is common and resistor voltage drops sum to the source voltage. For parallel branches, branch voltage is common and branch currents sum to source current. Each resistor obeys `V = I R`. Its dissipated power is simultaneously `I V`, `I² R` and `V² / R`. Source power equals total resistor power. Equivalent resistance depends on the resistor network even when source voltage is zero.

## Blind numerical receiving

The fourteen exact vectors cover unequal and equal resistors, two and three components, fractional values, kiloohm unit scale, zero source voltage, and the single-component equivalence. Only cases inside the implementation's advertised domain will count as execution gates; these values do not impose an expanded UI or API.

After seeing the public function/interface, bind an adapter to the literal candidate module. Compare each reported equivalent resistance, source current, branch voltage/current and displayed power to the frozen values. Do not replace the model with the oracle or infer a pass from the author's tests. Use unrounded internal numbers for conservation checks and the documented precision for displayed strings.

Additional changed-input checks will verify these relationships within the admitted domain:

1. Doubling source voltage doubles all currents and voltage drops, quadruples power and leaves equivalent resistance unchanged.
2. Doubling all resistances doubles equivalent resistance, halves currents and power, and leaves each voltage drop unchanged at fixed source voltage.
3. Permuting components preserves aggregate results and permutes the component results consistently.
4. Adding a positive series resistor increases equivalent resistance and lowers source current at fixed positive voltage. Adding a parallel branch lowers equivalent resistance and raises source current; existing branch currents remain unchanged for an ideal source.
5. Switching two equal resistors from series to parallel at the same fixed voltage multiplies total current and total power by four.
6. At zero source voltage, current and power are zero while equivalent resistance stays positive; no `NaN` is produced by reconstructing resistance as zero divided by zero.

## Question and explanation review

Solve each prompt from the blind question packet before viewing its answer key. Preserve the independent answers and short derivations. Then check every keyed answer and explanation, including why its distractors fail. Check that stated fixed quantities and topology support the conclusion; for example, resistance–power comparisons differ when voltage is fixed versus current being fixed.

Check units explicitly: ampere is charge per time, volt is energy per charge, ohm is volt per ampere, watt is joule per second, and constant-power energy is `P × time`. Confirm that kΩ/mA and time-unit conversions do not lose factors of 1,000 or 3,600.

Do not teach that charge/current is consumed by a resistor, that unequal parallel branches divide current equally, or that an ideal source delivers a fixed current regardless of load. If brightness is used as an analogy, attach it to dissipated power within the stated constant-resistance idealization. This educational model does not establish the behavior of actual lamps, batteries or household wiring.

## Source and interaction boundary

Review the source admission and reset/changed-input handling against its documented finite numeric domain. The comparison must not pass on stale outputs after a topology/input change or reuse a correct display with a different circuit diagram. Invalid or incomplete controls should have explicit behavior rather than silently appearing as a newly calculated physical result. Native/browser receiving remains distinct from source review and oracle arithmetic, with exact pins and environment recorded for any execution.
