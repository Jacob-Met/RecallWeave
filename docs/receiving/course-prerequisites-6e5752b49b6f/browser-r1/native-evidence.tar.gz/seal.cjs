'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const root=String.raw`C:\Users\jacob\AppData\Local\Hamon\estate-6e5752b49b6f\recall-prerequisite-browser-root-r1`;
const own=__dirname;
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=b=>crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const stamp=(name,b,s)=>({path:name,bytes:b.length,sha256:sha(b),gitBlob:git(b),mtimeMs:s.mtimeMs,mode:s.mode});
const cap=fs.statfsSync(own);assert(os.freemem()>=512*1024**2);assert(cap.bavail*cap.bsize>=256*1024**2);
assert.equal(sha(fs.readFileSync(process.execPath)),'63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088');
let entries=[],dirs=[];
function walk(dir,rel=''){for(const n of fs.readdirSync(dir).sort()){const file=path.join(dir,n),r=(rel?rel+'/':'')+n,s=fs.lstatSync(file);assert(!s.isSymbolicLink());if(s.isDirectory()){dirs.push(r);walk(file,r);}else{assert(s.isFile());const b=fs.readFileSync(file);entries.push({name:'original/'+r,data:b,record:stamp(r,b,s)});}}}
walk(root);assert(!dirs.some(n=>n.includes('owned-profile')));assert(entries.reduce((s,x)=>s+x.data.length,0)<64*1024**2);
const get=n=>entries.find(x=>x.record.path===n).data;
assert.equal(sha(get('browser-receiving-r1.json')),'f37a55a7db6229662f0db49985c510b7e1ddb3ba70dccdb0fe3c94fa4a028bc0');
const run=JSON.parse(get('browser-receiving-r1.json')),exe=JSON.parse(get('browser-execution-r1.json'));
assert.equal(run.accepted,true);assert.equal(run.groups.length,17);assert.equal(run.downloads.length,20);assert.equal(exe.exitCode,0);
assert.equal(run.inputsUnchanged,true);assert.equal(run.browserClose.code,0);assert.equal(run.launcherClose.code,0);assert.equal(run.ownProfileRemoved,true);
for(const item of [...run.before,...run.fixturePins,...run.artifacts]){
 if(!item.path.toLowerCase().startsWith(root.toLowerCase()+'\\'))continue;
 const rel=path.relative(root,item.path).replaceAll('\\','/'),actual=entries.find(x=>x.record.path===rel)?.record;
 assert(actual,rel);assert.equal(actual.bytes,item.bytes);assert.equal(actual.sha256,item.sha256);assert.equal(actual.gitBlob,item.gitBlob);
}
assert.deepEqual(run.before,run.after);
const readme="RecallWeave196 original browser receiving R1 custody\n\nThis packet preserves every regular file in the frozen successful R1 root, including exact source/controller/observer, manually frozen references, native fixtures, logs, 67 DOM observations, all 20 original physical downloads and all original screenshots. No source or browser was executed and no screenshot/download was regenerated during custody. The root receipt records 17 groups, 20 physical downloads, 100 artifacts, unchanged inputs, actual retained-handle Chrome exit zero, observer/launcher zero and own-profile removal. Native API qualification and the earlier failed R0 browser attempt remain separate evidence. R0 failed before its first download; it is not superseded or relabeled. R1's own keyboard control records the earlier trusted keydown/up without keypress and the corrected Enter text sequence with keypress and visible disclosure toggle.\n\nThis custody operation checks original files against the complete actual receipt, preserves all original bytes, and checks them again after archive creation. Runtime executables remain external pinned dependencies; they are not copied or rerun. Empty original directories are listed in manifest.json. Archive metadata are neutral packaging values; original byte hashes and file metadata are recorded in manifest.json. This bounded acceptance does not establish teaching efficacy, deployment, modular-browser behavior or universal platform support.\n";
const custody={format:'recall196-original-browser-r1-custody/1',at:new Date().toISOString(),root,scope:'Frozen original successful R1 receiving; no execution or regeneration',runtime:{execPath:process.execPath,node:process.version,sha256:sha(fs.readFileSync(process.execPath)),user:os.userInfo().username},capacity:{freeMemoryBytes:os.freemem(),freeDiskBytes:cap.bavail*cap.bsize},sourceReceipt:{bytes:get('browser-receiving-r1.json').length,sha256:sha(get('browser-receiving-r1.json')),gitBlob:git(get('browser-receiving-r1.json'))},accepted:true,originalFiles:entries.length,originalDirectories:dirs,sourceAndArtifactAdmission:true,failedAt:run.failure,recordedBrowserClose:run.browserClose,recordedOwnProfileRemoved:run.ownProfileRemoved};
entries.push({name:'README.md',data:Buffer.from(readme)});
entries.push({name:'custody.json',data:Buffer.from(JSON.stringify(custody,null,2)+'\n')});
entries.push({name:'seal.cjs',data:fs.readFileSync(__filename)});
const manifest={format:'recall196-custody-manifest/1',originalRoot:root,originalRecords:entries.filter(x=>x.record).map(x=>x.record),originalDirectories:dirs,members:entries.map(x=>({path:x.name,bytes:x.data.length,sha256:sha(x.data),gitBlob:git(x.data)}))};
entries.push({name:'manifest.json',data:Buffer.from(JSON.stringify(manifest,null,2)+'\n')});
function tarEntry(e){const h=Buffer.alloc(512);assert(Buffer.byteLength(e.name)<100);h.write(e.name,0,100,'utf8');const oct=(off,len,n)=>h.write(n.toString(8).padStart(len-1,'0')+'\0',off,len,'ascii');oct(100,8,0o644);oct(108,8,0);oct(116,8,0);oct(124,12,e.data.length);oct(136,12,0);h.fill(32,148,156);h[156]=48;h.write('ustar\0',257,6);h.write('00',263,2);const sum=h.reduce((a,b)=>a+b,0);h.write(sum.toString(8).padStart(6,'0')+'\0 ',148,8);return [h,e.data,Buffer.alloc((512-e.data.length%512)%512)];}
const raw=Buffer.concat([...entries.flatMap(tarEntry),Buffer.alloc(1024)]),archive=zlib.gzipSync(raw,{level:9});
const archivePath=path.join(own,'recall196-original-browser-r1.tar.gz');fs.writeFileSync(archivePath,archive,{flag:'wx'});
const back=zlib.gunzipSync(fs.readFileSync(archivePath));let off=0,count=0;
while(back[off]){const h=back.subarray(off,off+512);const name=h.subarray(0,100).toString('utf8').split('\0')[0],size=parseInt(h.subarray(124,136).toString().replace(/\0.*$/,''),8),e=entries[count++];assert.equal(name,e.name);assert.deepEqual(back.subarray(off+512,off+512+size),e.data);off+=512+Math.ceil(size/512)*512;}assert.equal(count,entries.length);
for(const e of entries.filter(x=>x.record)){const f=path.join(root,e.record.path),b=fs.readFileSync(f),s=fs.statSync(f);assert.deepEqual(stamp(e.record.path,b,s),e.record);}
const b64=archive.toString('base64').match(/.{1,16384}/g).join('\n')+'\n';
fs.writeFileSync(path.join(own,'recall196-original-browser-r1.tar.gz.b64'),b64,{flag:'wx'});
fs.writeFileSync(path.join(own,'README.md'),readme,{flag:'wx'});
fs.writeFileSync(path.join(own,'custody.json'),entries.find(x=>x.name==='custody.json').data,{flag:'wx'});
fs.writeFileSync(path.join(own,'manifest.json'),entries.find(x=>x.name==='manifest.json').data,{flag:'wx'});
const result={format:'recall196-r1-archive/1',archive:archivePath,bytes:archive.length,sha256:sha(archive),gitBlob:git(archive),mirror:{bytes:Buffer.byteLength(b64),sha256:sha(Buffer.from(b64)),gitBlob:git(Buffer.from(b64)),lines:b64.trimEnd().split('\n').length},members:entries.length,originalFiles:manifest.originalRecords.length,allMembersReadbackVerified:true,allOriginalBytesAndMetadataUnchanged:true};
fs.writeFileSync(path.join(own,'archive-receipt.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
