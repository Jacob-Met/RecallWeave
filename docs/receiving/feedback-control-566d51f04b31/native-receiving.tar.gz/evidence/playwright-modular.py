from pathlib import Path
import hashlib,json,threading,datetime,traceback,functools
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright,expect

root=Path("/Users/me/recall-feedback-control-566d51f04b31/current-main")
out=Path("/Users/me/recall-feedback-control-566d51f04b31/evidence/current-main-108/playwright-modular")
out.mkdir(parents=True,exist_ok=True)
course=root/"courses/feedback-control.json"
trace=Path("/Users/me/recall-feedback-control-566d51f04b31/evidence/current-main-108/browser/learning-trace-recallweave-learning-trace-2026-10-08.json")
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=["index.html","demo.html","courses/feedback-control.json","courses/feedback-control-lab.html"]+[str(p.relative_to(root)) for p in sorted((root/"src").glob("*.mjs"))]
before={p:hashfile(root/p) for p in paths}
report={"format":"recallweave-feedback-modular-receiving/1","status":"running","source":str(root),"source_sha256":before,"requests":[],"server_requests":[],"request_failures":[],"errors":[],"console_errors":[],"checks":[],"trace":{"path":str(trace),"sha256":hashfile(trace)}}
class Handler(SimpleHTTPRequestHandler):
    def log_message(self,fmt,*args):
        report["server_requests"].append({"path":self.path,"message":fmt%args})
    def end_headers(self):
        self.send_header("Cache-Control","no-store")
        super().end_headers()
server=ThreadingHTTPServer(("127.0.0.1",0),functools.partial(Handler,directory=str(root)))
thread=threading.Thread(target=server.serve_forever,daemon=True)
thread.start()
base="http://127.0.0.1:"+str(server.server_address[1])
def check(name):
    report["checks"].append(name)
    print("PASS "+name,flush=True)
try:
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless=True)
        report["browser"]=browser.version
        context=browser.new_context(viewport={"width":1280,"height":1000},accept_downloads=True)
        page=context.new_page()
        page.on("request",lambda request:report["requests"].append(request.url))
        page.on("requestfailed",lambda request:report["request_failures"].append({"url":request.url,"failure":request.failure}))
        page.on("pageerror",lambda error:report["errors"].append(str(error)))
        page.on("console",lambda msg:report["console_errors"].append(msg.text) if msg.type=="error" else None)
        page.on("dialog",lambda dialog:report.setdefault("dialogs",[]).append({"type":dialog.type,"message":dialog.message}))
        response=page.goto(base+"/index.html",wait_until="networkidle",timeout=20000)
        assert response and response.status==200
        expect(page.locator("#deck-file")).to_be_attached()
        assert response.body()==(root/"index.html").read_bytes()
        check("current modular entry loaded from exact native index bytes")
        deck=json.loads(course.read_bytes())
        page.locator("#deck-file").set_input_files(str(course))
        expect(page.locator("#deck-preview-title")).to_have_text(deck["title"])
        expect(page.locator(".deck-preview-count")).to_contain_text("18 questions")
        page.locator("#start-deck").focus()
        page.keyboard.press("Enter")
        prompt=page.locator(".question-card h2")
        expect(prompt).to_be_visible()
        question=next(item for item in deck["items"] if item["prompt"]==prompt.inner_text())
        choice=page.locator('[data-choice="'+str(question["answer"])+'"]')
        choice.focus()
        page.keyboard.press("Enter")
        feedback=page.locator("#feedback-slot")
        expect(feedback).to_contain_text(question["explanation"])
        expect(feedback).to_contain_text(question["transfer"])
        page.locator("#next-button").focus()
        page.keyboard.press("Enter")
        check("exact course imports and keyboard answer renders original explanation and transfer")
        page.locator("#trace-archive-panel").evaluate("(element)=>element.open=true")
        page.locator("#trace-file").set_input_files(str(trace))
        expect(page.locator("#trace-preview")).to_be_visible()
        page.locator("#restore-trace-confirm").focus()
        page.keyboard.press("Enter")
        expect(page.locator("#first-try-summary")).to_contain_text("15 of 18")
        expect(page.locator("#practice-status")).to_contain_text("3 of 3 correctly")
        page.locator(".result-card").scroll_into_view_if_needed()
        page.screenshot(path=str(out/"modular-receiving.png"))
        check("actual completed file learner trace restores 15 of 18 first tries and 3 of 3 separate retries")
        assert not report["errors"],report["errors"]
        assert not report["request_failures"],report["request_failures"]
        assert not [u for u in report["requests"] if u.startswith(("http:","https:")) and not u.startswith(base+"/")]
        report["after_source_sha256"]={p:hashfile(root/p) for p in paths}
        assert report["after_source_sha256"]==before
        assert hashfile(trace)==report["trace"]["sha256"]
        check("zero page exceptions, failed or external requests; all source and received trace bytes unchanged")
        report["status"]="passed"
        context.close()
        browser.close()
except Exception:
    report["status"]="failed"
    report["failure"]=traceback.format_exc()
    print(report["failure"],flush=True)
finally:
    server.shutdown()
    server.server_close()
    report["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (out/"receipt.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"status":report["status"],"checks":report["checks"],"requests":len(report["requests"]),"server_requests":len(report["server_requests"]),"receipt_sha256":hashfile(out/"receipt.json")}),flush=True)
if report["status"]!="passed":
    raise SystemExit(1)
