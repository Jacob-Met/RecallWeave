import ctypes,datetime,hashlib,json,pathlib,platform,shutil,sys,zipfile
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8');E=R/'portable-r1';E.mkdir(exist_ok=False)
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
class MEM(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['totalPhys','availPhys','totalPage','availPage','totalVirtual','availVirtual','availExtended']]
m=MEM();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
assert shutil.disk_usage('C:/').free>=1073741824 and shutil.disk_usage('D:/').free>=1073741824 and m.availPhys>=2147483648
S=R/'candidate-r2';dest=E/'unpacked';dest.mkdir()
payload=json.loads((R/'PACKAGE-INPUT-r1.json').read_text(encoding='utf-8'))
members=['demo.html','courses/genotype-counts.json','courses/genotype-counts.md','courses/genotype-counts-worksheet.html']
for rel in members:
 target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((S/rel).read_bytes())
(dest/'PLAY.md').write_bytes(payload['play'].encode('utf-8'));members.append('PLAY.md')
manifest={rel:pin(dest/rel) for rel in members}
(dest/'MANIFEST.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf-8'));members.append('MANIFEST.json')
z=E/'genotype-counts-portable.zip'
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as f:
 for rel in members:f.write(dest/rel,arcname=rel)
with zipfile.ZipFile(z) as f:
 assert f.namelist()==members
 for rel in members:assert f.read(rel)==(dest/rel).read_bytes()
before=json.loads((R/'CANDIDATE-MANIFEST-r1.json').read_text(encoding='utf-8'))
after=json.loads((R/'CANDIDATE-MANIFEST-r2.json').read_text(encoding='utf-8'))
assert [a['path'] for a in before]==[a['path'] for a in after]
changes=[a['path'] for a,b in zip(before,after) if a!=b];assert changes==['tests/genotype-counts-course.test.mjs']
for entry in after:assert pin(S/entry['path'])=={k:entry[k] for k in ['bytes','sha256','git']}
receipt={'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','package':pin(z),'members':{rel:pin(dest/rel) for rel in members},'nativeSource':str(S),'testOnlyDelta':changes,'all29OtherSourceFilesExact':True,'originalLearnerExact':(dest/'demo.html').read_bytes()==(R/'original/demo.html').read_bytes(),'noProductInvocation':True}
(E/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode('utf-8'));print(json.dumps(receipt))
