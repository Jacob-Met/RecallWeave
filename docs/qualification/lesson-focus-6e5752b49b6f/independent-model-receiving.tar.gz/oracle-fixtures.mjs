// Independent receiving fixtures. Expected membership uses a Boolean reachability
// matrix, independent of the production focus implementation and its output.
export const conceptNames = Object.freeze([
  'Start', 'Left, branch', 'Right → branch', 'Join', 'Middle',
  'Final', '__proto__', '<b>Literal optional concept</b>'
]);

const patterns = Object.freeze({
  separate: [],
  chain: [[1, 0], [2, 1], [3, 2], [4, 3], [5, 4], [6, 5], [7, 6]],
  diamond: [[1, 0], [2, 0], [3, 1], [3, 2], [4, 3], [5, 3]],
  split_questions: [[3, 0], [3, 1], [3, 2], [5, 3], [5, 4], [6, 1], [7, 5], [7, 6]],
  disconnected: [[1, 0], [3, 2], [5, 4], [7, 6]],
  shared_roots: [[2, 0], [2, 1], [3, 0], [3, 1], [4, 2], [5, 3], [6, 4], [6, 5]],
  dense: Array.from({ length: 8 }, (_, i) =>
    Array.from({ length: i }, (_, j) => [i, j])).flat()
});

export function makeFixtures() {
  return Object.entries(patterns).map(([name, edges]) => {
    // Deliberately neither prerequisite order nor item grouping.
    const concepts = [3, 1, 7, 0, 6, 2, 5, 4].map(i => conceptNames[i]);
    const itemOrder = [6, 1, 4, 7, 0, 3, 2, 5];
    const items = [0, 1].flatMap(part => itemOrder.map(i => {
      const prerequisites = edges.filter(([dependent]) => dependent === i)
        .filter((_, edgeIndex) => edgeIndex % 2 === part)
        .map(([, prerequisite]) => conceptNames[prerequisite]);
      return {
        id: `${name}:question:${i}:${part}`,
        concept: conceptNames[i], prerequisites,
        prompt: `Fixture ${name}; topic ${i}; question ${part}. <tag> is literal.`,
        options: ['Preserve option A', 'Preserve option B', 'Preserve option C'],
        answer: (i + part) % 3,
        explanation: `Exact explanation for ${name}/${i}/${part}: é / 漢字 / 🧭.`,
        transfer: `Exact transfer prompt for ${name}/${i}/${part}.`
      };
    }));
    return {
      name, deck: {
        format: 'recallweave-deck/1',
        title: `Independent receiving — ${name}`,
        attribution: 'Original fictional verification content by estate-6e5752b49b6f. <source> is text.',
        license: 'CC0-1.0; fixture content only. Preserve this complete text.',
        concepts, items
      }
    };
  });
}

export function closureOracle(deck, selected) {
  const n = deck.concepts.length;
  const index = new Map(deck.concepts.map((name, i) => [name, i]));
  const reachable = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (_, j) => i === j));
  for (const item of deck.items) {
    for (const prerequisite of item.prerequisites) {
      reachable[index.get(item.concept)][index.get(prerequisite)] = true;
    }
  }
  // Floyd–Warshall transitive closure, with no call to the candidate's helpers.
  for (let k = 0; k < n; ++k) {
    for (let i = 0; i < n; ++i) {
      for (let j = 0; j < n; ++j) {
        reachable[i][j] ||= reachable[i][k] && reachable[k][j];
      }
    }
  }
  const requested = new Set(selected);
  const retained = new Set(deck.concepts.filter((_, j) =>
    selected.some(name => reachable[index.get(name)][j])));
  return {
    selected: deck.concepts.filter(name => requested.has(name)),
    required: deck.concepts.filter(name => retained.has(name) && !requested.has(name)),
    concepts: deck.concepts.filter(name => retained.has(name)),
    items: deck.items.filter(item => retained.has(item.concept))
  };
}

export function nonemptySelections(concepts) {
  return Array.from({ length: (2 ** concepts.length) - 1 }, (_, i) =>
    concepts.filter((_, bit) => ((i + 1) & (2 ** bit)) !== 0));
}
