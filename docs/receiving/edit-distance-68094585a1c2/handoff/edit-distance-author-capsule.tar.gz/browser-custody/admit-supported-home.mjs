import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root='/tmp/hamon-levenshtein-68094585a1c2';
const home='/home/jacob/hamon-levenshtein-68094585a1c2-browser';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const manifest=JSON.parse(fs.readFileSync(root+'/candidate-for-independent-v1/MANIFEST.json','utf8'));
for(const entry of manifest.paths){
 const bytes=fs.readFileSync(root+'/candidate-source/'+entry.path);
 if(bytes.length!==entry.bytes||hash(bytes)!==entry.sha256)throw new Error('Product drift since independent admission: '+entry.path);
}
const docs=JSON.parse(fs.readFileSync(root+'/documentation-overlay.json','utf8'));
for(const [name,content] of Object.entries(docs.files))if(fs.readFileSync(root+'/candidate-source/'+name,'utf8')!==content)throw new Error('Documentation custody mismatch: '+name);
const oldProfile='/dev/shm/hamon-edit-distance-profile-TyJDOo';
const children=[];
for(const pid of fs.readdirSync('/proc').filter(name=>/^[0-9]+$/.test(name))){
 try{const args=fs.readFileSync('/proc/'+pid+'/cmdline','utf8').split('\0');
 if(args.includes('--user-data-dir='+oldProfile))children.push({pid:Number(pid),executable:args[0],profile:oldProfile});
 }catch{}
}
if(children.length)throw new Error('Prior private browser remains; reconcile before a new attempt: '+JSON.stringify(children));
const s=fs.statfsSync('/home/jacob');
if(s.bavail*s.bsize<300000000)throw new Error('Home capacity is below private browser admission.');
fs.accessSync('/snap/bin/chromium',fs.constants.X_OK);
fs.mkdirSync(home);
fs.cpSync(root+'/candidate-source',home+'/source',{recursive:true,errorOnExist:true,force:false});
const entries=[];
function visit(relative=''){
 for(const entry of fs.readdirSync(path.join(home,'source',relative),{withFileTypes:true})){
  const name=path.join(relative,entry.name);
  if(entry.isDirectory())visit(name);
  else if(entry.isFile()){
   const original=fs.readFileSync(path.join(root,'candidate-source',name)), bytes=fs.readFileSync(path.join(home,'source',name));
   if(!original.equals(bytes))throw new Error('Home transfer mismatch: '+name);
   entries.push({path:name,bytes:bytes.length,sha256:hash(bytes)});
  }else throw new Error('Unexpected source entry: '+name);
 }
}
visit();
const receipt={recorded_at:new Date().toISOString(),source:root+'/candidate-source',destination:home+'/source',homeAvailableBytes:s.bavail*s.bsize,previousAttempt:{exit:JSON.parse(fs.readFileSync(root+'/browser-v1-exit.json','utf8')),profile:oldProfile,profileStillExists:fs.existsSync(oldProfile),remainingExactProfileProcesses:children,cause:'Not established; no DevToolsActivePort, empty browser stderr, zero page checks.'},wrapperObservation:'Installed /usr/bin/chromium-browser performs desktop-settings queries before exec /snap/bin/chromium. New attempt uses that installed Snap launcher directly with ordinary owned home paths, without changing confinement or shared settings.',executable:'/snap/bin/chromium',productManifestSha256:hash(fs.readFileSync(root+'/candidate-for-independent-v1/MANIFEST.json')),entries};
const bytes=Buffer.from(JSON.stringify(receipt,null,2)+'\n');fs.writeFileSync(home+'/admission.json',bytes,{flag:'wx'});
console.log(JSON.stringify({path:home+'/admission.json',sha256:hash(bytes),files:entries.length,bytes:entries.reduce((n,e)=>n+e.bytes,0),homeAvailableBytes:receipt.homeAvailableBytes,oldProfileExists:receipt.previousAttempt.profileStillExists,remainingChildren:children.length}));
