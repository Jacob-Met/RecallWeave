from pathlib import Path
import base64, hashlib, io, json, os, signal, subprocess, tarfile, datetime
root = Path('/Users/me/hamon-recall-units-receiving-cd1df0f1ee24')
raw = base64.b64decode((root / 'input-v2.tar.gz.b64').read_bytes(), validate=False)
assert len(raw) == 96509
assert hashlib.sha256(raw).hexdigest() == '36b300e1a08a21d6a9c52abf4365f32bb14d427a87f46336c2331c61ebbb523a'
(root / 'input-v2.tar.gz').write_bytes(raw)
source = root / 'input-v2'
source.mkdir()
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
    for member in archive.getmembers():
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
    archive.extractall(source, filter='data')
manifest_raw = (source / 'input-manifest.json').read_bytes()
manifest_sha = hashlib.sha256(manifest_raw).hexdigest()
assert manifest_sha == 'cf04a014074b97fe8780a2ccc0c091e245a6abe56ea295251c9b35bcfe72401a'
for item in json.loads(manifest_raw)['files']:
    body = (source / item['path']).read_bytes()
    assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
output = root / 'run-v2-01'
assert not output.exists()
command = ['/opt/homebrew/bin/node', str(source / 'receiver/receive-unit-explorer.mjs')]
env = os.environ.copy()
env.update(UNITS_BROWSER_INPUT=str(source), UNITS_BROWSER_OUTPUT=str(output), UNITS_INPUT_MANIFEST_SHA256=manifest_sha)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
timed_out = False
with (root / 'run-v2-01.stdout').open('wb') as stdout, (root / 'run-v2-01.stderr').open('wb') as stderr:
    process = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        code = process.wait(timeout=150)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            code = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
receipt = {
    'schema': 'hamon.recallweave.units.native-command.v1',
    'startedAt': started,
    'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'deviceId': '0e3d582f-e25b-44b2-8418-9639fc4e4e33',
    'command': command,
    'environmentOverrides': {key:env[key] for key in ['UNITS_BROWSER_INPUT','UNITS_BROWSER_OUTPUT','UNITS_INPUT_MANIFEST_SHA256']},
    'archiveSHA256': hashlib.sha256(raw).hexdigest(),
    'inputManifestSHA256': manifest_sha,
    'exitCode': code,
    'timedOut': timed_out,
    'stdoutSHA256': hashlib.sha256((root/'run-v2-01.stdout').read_bytes()).hexdigest(),
    'stderrSHA256': hashlib.sha256((root/'run-v2-01.stderr').read_bytes()).hexdigest(),
}
(root / 'run-v2-01-command.json').write_text(json.dumps(receipt, indent=2)+'\n')
archive_path = root / 'run-v2-01-evidence.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for path in [output, root/'run-v2-01.stdout', root/'run-v2-01.stderr', root/'run-v2-01-command.json', root/'run-native-v2.py']:
        if path.exists(): archive.add(path, arcname=path.name)
    archive.add(source/'input-manifest.json', arcname='input-manifest.json')
    archive.add(source/'receiver', arcname='receiver')
body = archive_path.read_bytes()
encoded = base64.b64encode(body).decode()
(root/'run-v2-01-evidence.tar.gz.b64').write_text('\n'.join(encoded[i:i+12000] for i in range(0,len(encoded),12000))+'\n')
report = {'command':receipt, 'browserSummary':(root/'run-v2-01.stdout').read_text(), 'stderr':(root/'run-v2-01.stderr').read_text(), 'evidenceArchive':str(archive_path),'evidenceBytes':len(body),'evidenceSHA256':hashlib.sha256(body).hexdigest(),'base64Lines':(len(encoded)+11999)//12000}
(root/'run-v2-01-export.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
