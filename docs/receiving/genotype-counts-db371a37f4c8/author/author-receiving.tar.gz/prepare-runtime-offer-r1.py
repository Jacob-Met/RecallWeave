import hashlib,json,pathlib
R=pathlib.Path(r'D:/Hamon/worktrees/recall-genotype-counts-db371a37f4c8')
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
full=json.loads((R/'CANDIDATE-MANIFEST-r2.json').read_text(encoding='utf-8'))
runtime=[e for e in full if not e['path'].startswith('tests/')]
assert len(runtime)==29
for e in runtime:assert pin(R/'candidate-r2'/e['path'])=={k:e[k] for k in ['bytes','sha256','git']}
manifest=R/'RUNTIME-MANIFEST-r1.json';manifest.write_bytes((json.dumps(runtime,indent=2)+'\n').encode('utf-8'))
offer={'format':'genotype-counts-runtime-only/1','canonical':{'commit':'ec07bf3989132130759e5c00c6cb02eef19709d3','tree':'a839b6877bf2824f134443829d1ce62e1bd79e50'},'sourceRoot':str(R/'candidate-r2'),'manifest':{'path':str(manifest),**pin(manifest)},'sourceFiles':29,'unchangedOriginalFiles':26,'newContentPaths':['courses/genotype-counts.json','courses/genotype-counts.md','courses/genotype-counts-worksheet.html'],'promptsOnly':{'path':str(R/'PROMPTS-ONLY-r1.json'),**pin(R/'PROMPTS-ONLY-r1.json')},'portablePackage':{'path':str(R/'portable-r1/genotype-counts-portable.zip'),**pin(R/'portable-r1/genotype-counts-portable.zip'),'members':6},'independence':'Contains only unchanged original runtime and new authored content. No authored test bodies or author outcomes are included. Candidate-r1 and candidate-r2 have identical29 runtime files; r2 names a maintained-test-only successor.'}
path=R/'RUNTIME-ONLY-OFFER-r1.json';path.write_bytes((json.dumps(offer,indent=2)+'\n').encode('utf-8'));print(json.dumps({'offer':pin(path),'manifest':pin(manifest)}))
