import pathlib,json,hashlib,datetime,os,subprocess
R=pathlib.Path(__file__).resolve().parent
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def tree_hash(rows):
 root={}
 for row in rows:
  bits=row['path'].split('/');n=root
  for bit in bits[:-1]:n=n.setdefault(bit,{})
  assert bits[-1] not in n
  n[bits[-1]]=row
 def walk(node):
  entries=[]
  for name,value in node.items():
   leaf=isinstance(value,dict) and 'sha' in value and 'mode' in value
   mode=value['mode'].lstrip('0') if leaf else '40000'
   sha=value['sha'] if leaf else walk(value)
   entries.append(((name+('' if leaf else '/')).encode(),mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(sha)))
  raw=b''.join(v for _,v in sorted(entries));return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 return walk(root)
p=json.loads((R/'SOURCE-COMPOSITION-r1.json').read_text(encoding='utf-8'))
assert tree_hash(p['baseLeaves'])==p['baseTree']
assert tree_hash(p['finalLeaves'])==p['commit']['tree']['sha']
base={x['path']:x for x in p['baseLeaves']};final={x['path']:x for x in p['finalLeaves']}
assert all(final[k]==v for k,v in base.items()) and len(final)==len(base)+10
for row in p['additions']:assert final[row['path']]==row
source=json.loads((R/'candidate-source-final-r1.json').read_text())
for row in source:
 b=(R/'candidate-r2'/row['path']).read_bytes();assert pin(b)=={k:row[k] for k in ('bytes','sha256','git')}
 assert final[row['path']]['sha']==row['git']
for row in p['workflows']:assert pin(row['body'].encode())['git']==row['sha']
donor=pathlib.Path('D:/Hamon/receiving/pneumatic-goals-root-db371a37f4c8')
donor_manifest=json.loads((donor/'LINUX-DONOR-MANIFEST.json').read_text())
for path,row in donor_manifest.items():
 b=(donor/'dependencies/node_modules'/path).read_bytes()
 assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],path
proc=subprocess.run(['powershell','-NoProfile','-Command','Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress'],capture_output=True,check=True,encoding='utf-8').stdout
processes=json.loads(proc);ancestors={os.getpid()}
while True:
 before=len(ancestors)
 for x in processes:
  if x['ProcessId'] in ancestors:ancestors.add(x['ParentProcessId'])
 if before==len(ancestors):break
owned=[x for x in processes if str(R).lower().replace('\\','/') in (x.get('CommandLine') or '').lower().replace('\\','/') and x['ProcessId'] not in ancestors]
assert not owned,owned
assert not list((R/'browser-r1/tmp').rglob('*')) and not list((R/'browser-r2/tmp').rglob('*'))
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),base_tree=p['baseTree'],source_tree=p['commit']['tree']['sha'],source_commit=p['commit']['sha'],base_leaves=len(base),source_leaves=len(final),additions=10,all_parent_leaves_and_modes_exact=True,both_git_trees_reconstructed_from_raw_entries=True,native_source_files=len(source),donor_files=len(donor_manifest),all_native_source_bytes_exact=True,all_workflow_bytes_exact=True,owned_nonancestor_processes=owned,observer_ancestors=sorted(ancestors),tmp_empty=True,source_manifest=pin((R/'candidate-source-final-r1.json').read_bytes()),runtime_offer=pin((R/'RUNTIME-ONLY-OFFER-r1.json').read_bytes()),package=pin((R/'portable-r1/sorting-networks-offline.zip').read_bytes()),source_stats=[dict(path=x['path'],mtime_ns=str((R/'candidate-r2'/x['path']).stat().st_mtime_ns)) for x in source],transport_note='Unrelated read_process_output responses not used; exact owned files and native census are authoritative for this audit. Cause unestablished.',hosted_checks='unexecuted',ref_mutation=False)
for name in ['NATIVE-SOURCE-PROOF-r1.json','FINAL-AUDIT.json']:(R/name).write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in result.items() if k!='source_stats'}))
