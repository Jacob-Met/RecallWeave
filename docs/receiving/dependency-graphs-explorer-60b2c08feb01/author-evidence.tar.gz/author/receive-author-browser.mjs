import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const source = path.resolve(process.argv[2] || '/dev/shm/estate-60b2c08feb01-recall-graph/source');
const output = path.resolve(process.argv[3] || '/dev/shm/estate-60b2c08feb01-recall-graph/evidence/browser-r2');
const executablePath = process.env.GRAPH_CHROMIUM || '/workspace/scratch/3e50c5ad22c5/production/browser/chromium';
const playwrightPath = process.env.GRAPH_PLAYWRIGHT || '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const temporary = fs.mkdtempSync('/dev/estate-60b2c08feb01-graph-browser-');
process.env.TMPDIR = temporary;
fs.mkdirSync(output, { recursive: true });
const sha256 = data => crypto.createHash('sha256').update(data).digest('hex');
const gitBlob = data => crypto.createHash('sha1').update(`blob ${data.length}\0`).update(data).digest('hex');
const sourceNames = ['courses/dependency-graphs-explorer.html', 'courses/dependency-graphs-explorer.template.html', 'courses/dependency-graphs.json', 'courses/dependency-graphs.md', 'src/dependency-plan.mjs', 'src/dependency-plan-ui.mjs', 'src/deck.mjs', 'tools/build-dependency-graphs.mjs', 'tests/dependency-plan.test.mjs', 'demo.html'];
const pins = Object.fromEntries(sourceNames.map(name => {
  const bytes = fs.readFileSync(path.join(source, name));
  return [name, { bytes: bytes.length, sha256: sha256(bytes), gitBlob: gitBlob(bytes) }];
}));
assert.equal(pins['src/dependency-plan.mjs'].sha256, 'fea26b701e2e394c86309d4e2d1927c7743205b17210d1b50c8676faaeb27b10');
assert.equal(pins['courses/dependency-graphs-explorer.html'].sha256, '2a88659ac288a89dc1b1443b3a9deb5a2e28e61d78d71aac491e6f2f70e8e170');
const receipt = { purpose: 'Actual built offline companion → original downloaded course → unchanged learner/first-answer review/practice', startedAt: new Date().toISOString(), node: process.version, executablePath, playwrightPath, sourcePins: pins, checks: [], requests: [], offOriginAttempts: [], pageErrors: [], consoleErrors: [], downloadedCourse: null, passed: false };
const check = (name, details = {}) => receipt.checks.push({ name, passed: true, ...details });
let context, page;

try {
  const { chromium } = await import(playwrightPath);
  context = await chromium.launchPersistentContext(path.join(temporary, 'profile'), {
    executablePath, headless: true, acceptDownloads: true,
    viewport: { width: 1280, height: 1000 }, locale: 'en-GB', timezoneId: 'UTC',
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-background-networking', '--disable-component-update', '--disable-sync', '--no-first-run'],
  });
  receipt.browserVersion = context.browser().version();
  await context.route('**/*', async route => {
    const url = route.request().url();
    const protocol = new URL(url).protocol;
    if (protocol === 'file:' || protocol === 'data:' || protocol === 'blob:') return route.continue();
    receipt.offOriginAttempts.push({ url, method: route.request().method() });
    return route.abort('blockedbyclient');
  });
  context.on('request', request => receipt.requests.push({ url: request.url(), method: request.method(), type: request.resourceType() }));
  const observe = target => {
    target.setDefaultTimeout(10000);
    target.on('pageerror', error => receipt.pageErrors.push(String(error)));
    target.on('console', message => { if (message.type() === 'error') receipt.consoleErrors.push(message.text()); });
  };
  context.on('page', observe);
  page = await context.newPage();
  const response = await page.goto(pathToFileURL(path.join(source, 'courses/dependency-graphs-explorer.html')).href);
  const received = await response.body();
  assert.equal(sha256(received), pins['courses/dependency-graphs-explorer.html'].sha256);
  await page.locator('#plan-results').waitFor({ state: 'visible' });
  const ready = () => page.locator('#ready-jobs button').evaluateAll(buttons => buttons.map(button => button.dataset.completeJob));
  const history = () => page.locator('#completion-history li').allTextContents();
  assert.deepEqual(await ready(), ['A', 'B']);
  assert.deepEqual(await history(), []);
  check('Direct-file standalone source is exact; initial preview has no automatic completions', { deliveredBytes: received.length, deliveredSha256: sha256(received), initialReady: ['A', 'B'] });

  await page.getByRole('button', { name: 'Complete B', exact: true }).click();
  assert.deepEqual(await ready(), ['A']);
  assert.equal(await page.locator('#job-rows tr').evaluateAll(rows => rows.find(row => row.dataset.job === 'C').dataset.status), 'waiting');
  await page.getByRole('button', { name: 'Complete A', exact: true }).click();
  assert.deepEqual(await ready(), ['C']);
  await page.getByRole('button', { name: 'Complete C', exact: true }).click();
  await page.getByRole('button', { name: 'Complete D', exact: true }).click();
  assert.deepEqual(await history(), ['B', 'A', 'C', 'D']);
  assert.match(await page.locator('#ready-summary').innerText(), /plan is complete/);
  await page.locator('#undo-step').click();
  assert.deepEqual(await history(), ['B', 'A', 'C']);
  assert.deepEqual(await ready(), ['D']);
  await page.locator('#reset-plan').click();
  assert.deepEqual(await history(), []);
  assert.deepEqual(await ready(), ['A', 'B']);
  check('Ready-only alternate order, deterministic undo and graph-preserving reset', { completedOrder: ['B', 'A', 'C', 'D'], undoneReady: ['D'], resetReady: ['A', 'B'] });

  await page.locator('[data-example="changes"]').click();
  await page.locator('#inspect-job').selectOption('Raw');
  assert.equal(await page.locator('#reachable-jobs').innerText(), 'Clean, Chart, Summary');
  assert.deepEqual(await ready(), ['Raw', 'Glossary']);
  await page.locator('[data-example="cycle"]').click();
  assert.deepEqual(await ready(), ['D']);
  assert.equal(await page.locator('#blocked-jobs').innerText(), 'C');
  assert.match(await page.locator('#cycle-groups').innerText(), /A, B/);
  await page.getByRole('button', { name: 'Complete D', exact: true }).click();
  await page.getByRole('button', { name: 'Complete E', exact: true }).click();
  assert.deepEqual(await ready(), []);
  assert.deepEqual(await history(), ['D', 'E']);
  await page.locator('#possible-orders summary').click();
  assert.match(await page.locator('#orders-note').innerText(), /No complete order exists/);
  await page.screenshot({ path: path.join(output, 'cycle-plan-desktop.png'), fullPage: true });
  check('Course examples preserve direction, disconnected readiness and cycle-versus-descendant distinction', { changeReachability: ['Clean', 'Chart', 'Summary'], cycleMembers: ['A', 'B'], blockedOnly: ['C'], independentCompletions: ['D', 'E'] });

  await page.locator('#jobs-input').fill('Plan\nCook\nEat');
  await page.locator('#edges-input').fill('Plan -> Cook\nCook -> Eat');
  await page.locator('#preview-graph').click();
  assert.deepEqual(await ready(), ['Plan']);
  await page.getByRole('button', { name: 'Complete Plan', exact: true }).click();
  assert.deepEqual(await ready(), ['Cook']);
  assert.deepEqual(await history(), ['Plan']);
  check('An explicitly edited graph replaces the example and drives the native controls', { jobs: ['Plan', 'Cook', 'Eat'], currentHistory: ['Plan'], ready: ['Cook'] });

  const [download] = await Promise.all([page.waitForEvent('download'), page.locator('#download-course').click()]);
  const downloadedPath = await download.path();
  const downloaded = fs.readFileSync(downloadedPath);
  assert.equal(download.suggestedFilename(), 'dependency-graphs.json');
  assert.equal(downloaded.length, 12121);
  assert.equal(sha256(downloaded), pins['courses/dependency-graphs.json'].sha256);
  fs.writeFileSync(path.join(output, 'downloaded-dependency-graphs.json'), downloaded);
  const deck = JSON.parse(downloaded);
  receipt.downloadedCourse = { filename: download.suggestedFilename(), bytes: downloaded.length, sha256: sha256(downloaded), questions: deck.items.length };
  const [learner] = await Promise.all([context.waitForEvent('page'), page.getByRole('link', { name: 'Open the learner in another tab', exact: true }).click()]);
  await learner.waitForLoadState('load');
  assert.equal(learner.url(), pathToFileURL(path.join(source, 'demo.html')).href);
  await learner.locator('#deck-file').setInputFiles(downloadedPath);
  await learner.locator('#deck-preview-title').waitFor({ state: 'visible' });
  assert.equal(await learner.locator('#deck-preview-title').innerText(), deck.title);
  assert.match(await learner.locator('.deck-preview-count').innerText(), /12 questions · 4 concepts/);
  assert(await learner.locator('.deck-preview-attribution').innerText().then(text => text.includes(deck.attribution)));
  assert(await learner.locator('.deck-preview-license').innerText().then(text => text.includes(deck.license)));
  await learner.locator('#start-deck').click();
  await learner.locator('.question-card h2').waitFor();
  assert.deepEqual(await history(), ['Plan']);
  check('The real downloaded bytes enter the unchanged native picker by preview and explicit Start', { ...receipt.downloadedCourse, learnerBlob: pins['demo.html'].gitBlob, companionHistoryPreserved: ['Plan'] });

  const attempts = [];
  for (let index = 0; index < deck.items.length; index += 1) {
    const prompt = await learner.locator('.question-card h2').innerText();
    const item = deck.items.find(candidate => candidate.prompt === prompt);
    assert(item, 'Every actual displayed prompt belongs to the downloaded course');
    assert(!attempts.some(previous => previous.id === item.id));
    const choice = index % 3 === 0 ? (item.answer + 1) % item.options.length : item.answer;
    const button = learner.locator(`[data-choice="${choice}"]`);
    assert((await button.innerText()).includes(item.options[choice]));
    await button.click();
    const feedback = await learner.locator('#feedback-slot').innerText();
    assert(feedback.includes(item.explanation));
    assert(feedback.includes(item.transfer));
    attempts.push({ id: item.id, choice, correct: choice === item.answer });
    await learner.locator('#next-button').click();
  }
  await learner.locator('#first-try-summary').waitFor();
  const firstSummary = await learner.locator('#first-try-summary').innerText();
  assert.match(firstSummary, /8 of 12/);
  assert.equal(await learner.locator('.review-item').count(), 12);
  const firstMastery = await learner.locator('.mastery-row output').allTextContents();
  await learner.locator('#practice-button').click();
  const practiced = [];
  for (let index = 0; index < 4; index += 1) {
    const prompt = await learner.locator('.practice-card h2').innerText();
    const item = deck.items.find(candidate => candidate.prompt === prompt);
    assert(item);
    assert(attempts.some(answer => answer.id === item.id && !answer.correct));
    assert(!practiced.includes(item.id));
    await learner.locator(`[data-practice-choice="${item.answer}"]`).click();
    practiced.push(item.id);
    await learner.locator('#practice-next').click();
  }
  assert.match(await learner.locator('#practice-status').innerText(), /4 of 4 correctly/);
  assert.equal(await learner.locator('#first-try-summary').innerText(), firstSummary);
  assert.deepEqual(await learner.locator('.mastery-row output').allTextContents(), firstMastery);
  assert.deepEqual(await history(), ['Plan']);
  check('All12 real questions reach first-answer review and four missed-question practice without rewriting the first attempt', { attempts, firstCorrect: 8, firstTotal: 12, practiced, practiceCorrect: 4, unchangedFirstSummary: firstSummary, unchangedModelDisplays: firstMastery });

  const after = Object.fromEntries(sourceNames.map(name => [name, sha256(fs.readFileSync(path.join(source, name)))]));
  assert(Object.entries(pins).every(([name, pin]) => pin.sha256 === after[name]));
  assert.deepEqual(receipt.offOriginAttempts, []);
  assert.deepEqual(receipt.pageErrors, []);
  assert.deepEqual(receipt.consoleErrors, []);
  receipt.sourceUnchanged = true;
  receipt.passed = true;
} catch (error) {
  receipt.failure = { name: error.name, message: error.message, stack: error.stack };
  try { await page?.screenshot({ path: path.join(output, 'failure.png'), fullPage: true }); } catch {}
} finally {
  await context?.close();
  fs.rmSync(temporary, { recursive: true, force: true });
  receipt.privateProfileRemoved = true;
  receipt.finishedAt = new Date().toISOString();
  receipt.harnessSha256 = sha256(fs.readFileSync(new URL(import.meta.url)));
  fs.writeFileSync(path.join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ passed: receipt.passed, groups: receipt.checks.length, browser: receipt.browserVersion, receipt: path.join(output, 'receipt.json'), failure: receipt.failure, pageErrors: receipt.pageErrors, consoleErrors: receipt.consoleErrors, offOriginAttempts: receipt.offOriginAttempts }));
}
process.exitCode = receipt.passed ? 0 : 1;
