const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=__dirname,payload=JSON.parse(fs.readFileSync(path.join(root,'input.json'),'utf8'));
const out=path.join(root,'source');fs.mkdirSync(out);
const sources={};
for(const row of payload.sources){
 const bytes=Buffer.from(row.content,'utf8'),blob=crypto.createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');
 assert.equal(blob,row.gitBlob,row.path);
 const target=path.join(out,row.path);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx'});
 const actual=fs.readFileSync(target);assert.deepEqual(actual,bytes);
 sources[row.path]=crypto.createHash('sha256').update(actual).digest('hex');
}
fs.writeFileSync(path.join(root,'receive-browser-r1.mjs'),payload.receiver,{flag:'wx',encoding:'utf8'});
const receiver=fs.readFileSync(path.join(root,'receive-browser-r1.mjs'));
fs.writeFileSync(path.join(root,'expected.json'),JSON.stringify({sources,runtime:payload.runtime},null,2)+'\n',{flag:'wx'});
const report={source:'35ba3fe7a611395016fc5c808604ea1a815dc81b',node:process.version,files:sources,receiverSha256:crypto.createHash('sha256').update(receiver).digest('hex')};
fs.writeFileSync(path.join(root,'hydration.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
