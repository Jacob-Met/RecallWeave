// Independent pre-candidate oracle: enumerate complete weighted direction words;
// solve eventual boundary linear equations. No candidate imports or closed-form bias formula.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const R=path.dirname(fileURLToPath(import.meta.url));
const gcd=(a,b)=>{a=a<0n?-a:a;b=b<0n?-b:b;while(b){[a,b]=[b,a%b];}return a;};
class F{
 constructor(n=0n,d=1n){n=BigInt(n);d=BigInt(d);assert.notEqual(d,0n);if(d<0n){n=-n;d=-d;}const g=gcd(n,d);this.n=n/g;this.d=d/g;}
 add(x){return new F(this.n*x.d+x.n*this.d,this.d*x.d);}
 sub(x){return new F(this.n*x.d-x.n*this.d,this.d*x.d);}
 mul(x){return new F(this.n*x.n,this.d*x.d);}
 div(x){return new F(this.n*x.d,this.d*x.n);}
 toJSON(){return {numerator:String(this.n),denominator:String(this.d)};}
 toString(){return this.n+'/'+this.d;}
}
const zero=()=>new F(),one=()=>new F(1);
function eventual(input){
 const N=input.upper,p=new F(input.rightNumerator,input.rightDenominator),q=one().sub(p),width=N+1;
 const a=Array.from({length:width},()=>Array.from({length:width+2},zero));
 for(let i=0;i<=N;i++){
  a[i][i]=one();
  if(i===N)a[i][width]=one();
  if(i>0&&i<N){a[i][i-1]=zero().sub(q);a[i][i+1]=zero().sub(p);a[i][width+1]=one();}
 }
 for(let col=0;col<width;col++){
  const row=a.findIndex((r,i)=>i>=col&&r[col].n!==0n);assert.ok(row>=col);
  [a[col],a[row]]=[a[row],a[col]];const divisor=a[col][col];a[col]=a[col].map(v=>v.div(divisor));
  for(let i=0;i<width;i++)if(i!==col){const f=a[i][col];a[i]=a[i].map((v,j)=>v.sub(f.mul(a[col][j])));}
 }
 return a.map((row,start)=>({start,left:one().sub(row[width]),right:row[width],expectedSteps:row[width+1]}));
}
function edges(input){
 const p=new F(input.rightNumerator,input.rightDenominator),q=one().sub(p),result=[];
 for(let from=0;from<=input.upper;from++){
  if(from===0||from===input.upper)result.push({from,to:from,probability:one()});
  else result.push({from,to:from-1,probability:q},{from,to:from+1,probability:p});
 }
 return result;
}
function enumerate(input){
 const {upper:N,start:i,rightNumerator:a,rightDenominator:b,horizon:H}=input;
 assert.ok(H<=8,'Full-word enumeration intentionally bounded at8');
 const den=BigInt(b)**BigInt(H),es=edges(input),event=eventual(input);
 const counts=Array.from({length:H+1},()=>({distribution:Array(N+1).fill(0n),first:[0n,0n],survival:0n,truncated:0n,contributions:Array(es.length).fill(0n)}));
 for(let word=0;word<2**H;word++){
  let state=i,weight=1n,T=(i===0||i===N)?0:Infinity;const states=[i];
  for(let t=0;t<H;t++){
   const right=Boolean(word&(2**t));weight*=BigInt(right?a:b-a);
   if(state>0&&state<N)state+=right?1:-1;
   states.push(state);if(T===Infinity&&(state===0||state===N))T=t+1;
  }
  for(let t=0;t<=H;t++){
   const c=counts[t];c.distribution[states[t]]+=weight;
   if(T===t)c.first[states[t]===0?0:1]+=weight;
   if(T>t)c.survival+=weight;
   c.truncated+=BigInt(Math.min(T,t))*weight;
   if(t){const idx=es.findIndex(e=>e.from===states[t-1]&&e.to===states[t]);assert.ok(idx>=0);c.contributions[idx]+=weight;}
  }
 }
 const frames=counts.map((c,step)=>{
  const distribution=c.distribution.map(n=>new F(n,den)),truncated=new F(c.truncated,den);
  return {step,distribution,firstArrival:{left:new F(c.first[0],den),right:new F(c.first[1],den)},absorbed:{left:distribution[0],right:distribution[N]},survival:new F(c.survival,den),truncatedExpectedSteps:truncated,expectedExcessSteps:event[i].expectedSteps.sub(truncated),contributions:step?es.map((e,k)=>({...e,mass:new F(c.contributions[k],den)})):[]};
 });
 return {format:'recallweave-absorbing-walk/1',input:{...input},probabilities:{right:new F(a,b),left:new F(b-a,b)},eventual:event,frames};
}
function longFair(){
 const input={upper:3,start:1,rightNumerator:1,rightDenominator:2,horizon:30},event=eventual(input),es=edges(input),frames=[];
 let left=zero(),right=zero();
 for(let step=0;step<=30;step++){
  const survival=new F(1n,2n**BigInt(step));
  const firstLeft=step>0&&step%2===1?survival:zero(),firstRight=step>0&&step%2===0?survival:zero();
  left=left.add(firstLeft);right=right.add(firstRight);
  const distribution=[left,step%2===0?survival:zero(),step%2===1?survival:zero(),right];
  const truncated=new F(2).mul(one().sub(survival));
  frames.push({step,distribution,firstArrival:{left:firstLeft,right:firstRight},absorbed:{left,right},survival,truncatedExpectedSteps:truncated,expectedExcessSteps:new F(2).mul(survival),contributions:step?es.map(e=>({...e,mass:frames[step-1].distribution[e.from].mul(e.probability)})):[]});
 }
 return {format:'recallweave-absorbing-walk/1',input,probabilities:{right:new F(1,2),left:new F(1,2)},eventual:event,frames};
}
const specs=[
 ['one-interior-third',2,1,2,3,3],['fair-alternating-survival',3,1,1,2,4],
 ['right-bias',4,2,2,3,4],['left-bias',4,2,1,3,4],['unreduced-input',4,2,4,6,4],
 ['deterministic-right',5,2,1,1,6],['deterministic-left',5,2,0,1,6],
 ['left-endpoint-start',8,0,7,12,2],['right-endpoint-opposite-drift',8,8,0,12,2],
 ['horizon-zero',8,3,3,4,0],['wide-denominator',8,4,5,12,8],['wide-reflected-bias',8,4,7,12,8],
 ['original-percent-bridge',2,1,3,4,5],['original-fair-bridge',2,1,1,2,5]
];
const fixtures=specs.map(([name,upper,start,rightNumerator,rightDenominator,horizon])=>({name,analysis:enumerate({upper,start,rightNumerator,rightDenominator,horizon})}));
fixtures.push({name:'positive-fair-tail-at30',analysis:longFair()});
function strs(values){return values.map(x=>x.toString());}
const single=fixtures[0].analysis;
assert.deepEqual(strs(single.frames[1].distribution),['1/3','0/1','2/3']);
assert.deepEqual(strs(single.frames[3].distribution),['1/3','0/1','2/3']);assert.equal(single.frames[2].firstArrival.left.toString(),'0/1');
assert.equal(single.eventual[1].expectedSteps.toString(),'1/1');
const fair=fixtures[1].analysis;
const dist=[['0/1','1/1','0/1','0/1'],['1/2','0/1','1/2','0/1'],['1/2','1/4','0/1','1/4'],['5/8','0/1','1/8','1/4'],['5/8','1/16','0/1','5/16']];
fair.frames.forEach((f,i)=>assert.deepEqual(strs(f.distribution),dist[i]));
assert.deepEqual(strs(fair.frames.map(f=>f.truncatedExpectedSteps)),['0/1','1/1','3/2','7/4','15/8']);
const biased=fixtures[2].analysis;
assert.deepEqual(strs(biased.eventual.map(e=>e.right)),['0/1','8/15','4/5','14/15','1/1']);
assert.deepEqual(strs(biased.eventual.map(e=>e.expectedSteps)),['0/1','17/5','18/5','11/5','0/1']);
assert.deepEqual(strs(biased.frames[4].distribution),['13/81','0/1','16/81','0/1','52/81']);
assert.equal(biased.frames[4].truncatedExpectedSteps.toString(),'26/9');assert.equal(biased.frames[4].expectedExcessSteps.toString(),'32/45');
const tail=fixtures.at(-1).analysis.frames[30];assert.equal(tail.survival.toString(),'1/1073741824');assert.equal(tail.expectedExcessSteps.toString(),'1/536870912');
const output={frozenBeforeCandidate:true,method:'Complete weighted word enumeration H<=8; independent exact Gaussian boundary solve; separate derived fair tail identity for H30',fixtures};
const bytes=Buffer.from(JSON.stringify(output,null,2)+'\n');const target=path.join(R,'finite-walk-oracle-r1.json');assert.equal(fs.existsSync(target),false);fs.writeFileSync(target,bytes);
fs.writeFileSync(path.join(R,'oracle-generation-receipt.json'),JSON.stringify({at:new Date().toISOString(),fixtures:fixtures.length,frames:fixtures.reduce((n,x)=>n+x.analysis.frames.length,0),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),manualChecksPassed:true,node:process.version,candidateImported:false},null,2)+'\n');
console.log(fs.readFileSync(path.join(R,'oracle-generation-receipt.json'),'utf8'));
