import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root='/tmp/hamon-levenshtein-68094585a1c2';
const input=JSON.parse(fs.readFileSync(root+'/original-inputs.json','utf8'));
const project=root+'/baseline-source', evidence=root+'/baseline-evidence';
fs.mkdirSync(project); fs.mkdirSync(evidence);
const hash=b=>createHash('sha256').update(b).digest('hex');
const blob=b=>createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const pins=[];
for(const entry of input.entries){
  const bytes=Buffer.from(entry.content,'utf8');
  if(bytes.length!==entry.bytes||blob(bytes)!==entry.blob)throw new Error('Original transport mismatch: '+entry.path);
  const target=path.join(project,entry.path); fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx'});
  pins.push({path:entry.path,bytes:bytes.length,sha256:hash(bytes),blob:blob(bytes),mode:entry.mode});
}
const report={format:'recallweave-edit-distance-original/1',started:new Date().toISOString(),parent:input.parent,tree:input.tree,node:process.version,pid:process.pid,project,pins,newFeaturePresent:input.full_tree.some(e=>/^courses\/edit-distance/.test(e.path)),commands:[]};
fs.writeFileSync(evidence+'/source-pins.json',JSON.stringify(pins,null,2)+'\n',{flag:'wx'});
for(const [name,executable,args] of [
  ['shared-learner',process.execPath,['--test','tests/deck.test.mjs','tests/knowledge.test.mjs','tests/review.test.mjs','tests/session-export.test.mjs','tests/reflections.test.mjs']],
  ['original-demo-build','python3',['tools/make_demo.py']]
]){
  const started=new Date().toISOString();const r=spawnSync(executable,args,{cwd:project,encoding:'utf8',timeout:60000,maxBuffer:8*1024*1024});
  fs.writeFileSync(evidence+'/'+name+'.stdout.log',r.stdout??'',{flag:'wx'});fs.writeFileSync(evidence+'/'+name+'.stderr.log',r.stderr??'',{flag:'wx'});
  report.commands.push({name,executable,args,started,finished:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?String(r.error):null});
  if(r.status!==0)process.exitCode=1;
}
report.sourceAfter=pins.map(p=>{const b=fs.readFileSync(path.join(project,p.path));return {path:p.path,bytes:b.length,sha256:hash(b),blob:blob(b),mode:p.mode};});
report.sourceUnchanged=JSON.stringify(report.sourceAfter)===JSON.stringify(pins);
if(!report.sourceUnchanged||report.newFeaturePresent)process.exitCode=1;
report.status=process.exitCode?'failed':'passed';report.finished=new Date().toISOString();
fs.writeFileSync(evidence+'/receipt.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:report.status,commands:report.commands,sourceUnchanged:report.sourceUnchanged,files:pins.length,newFeaturePresent:report.newFeaturePresent}));
