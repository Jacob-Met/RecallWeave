import assert from 'node:assert/strict';
import fs from 'node:fs';
import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {withBrowser,sha,until,delay} from './browser-helpers.mjs';
const root='/home/jacob/recallweave-dc-circuits-bd1abdb2f886';
const qa='/tmp/recallweave-dc-receiving-bd1abdb2f886',output=join(qa,'candidate-v1');
const pins={
 'courses/dc-circuits-lab.html':'3329789a15f3544a9e57bdcb7359b0b5761f4df4f3ce949bb16cc994e3b8c796',
 'courses/dc-circuits.json':'cfe7a4586a4a97aa96356e9afe7fea5bc1e216a0aff70454476397c909058ccb',
 'src/dc-circuits-ui.mjs':'f236151d3fba828a28e64686045469744ec041872add220eddf068f64d05c4f3',
 'src/dc-circuits.mjs':'b8a94b617e2285f8e07229f256d8c2f1c1fcbe53a6e8045f1d816e74d7fb9ba8',
 'templates/dc-circuits-lab.html':'a1af554df93dae1d58f37fb1d5f2c13694eae3e5bd3905eee470a02796adcb8b',
 'tools/build-dc-circuits.mjs':'8e57f0f9d2e64ba7abd94483e62874f4777d132c82669e95cd667c2327168f59'
};
const snapshot=()=>Object.fromEntries(Object.keys(pins).map(p=>[p,sha(fs.readFileSync(join(root,p)))]));
const before=snapshot();assert.deepEqual(before,pins,'all source pins match the frozen candidate');
await mkdir(output,{recursive:true});
const course=await readFile(join(root,'courses/dc-circuits.json')),labURL=pathToFileURL(join(root,'courses/dc-circuits-lab.html')).href;
const expected=(v,a,b)=>({
 series:{equivalentResistance:a+b,sourceCurrent:v/(a+b),sourcePower:v*v/(a+b),resistors:[{resistance:a,voltage:v*a/(a+b),current:v/(a+b),power:v*v*a/((a+b)*(a+b))},{resistance:b,voltage:v*b/(a+b),current:v/(a+b),power:v*v*b/((a+b)*(a+b))}]},
 parallel:{equivalentResistance:a*b/(a+b),sourceCurrent:v/a+v/b,sourcePower:v*v/a+v*v/b,resistors:[{resistance:a,voltage:v,current:v/a,power:v*v/a},{resistance:b,voltage:v,current:v/b,power:v*v/b}]}
});
function numberClose(actual,expected,label,rounded=true){assert.ok(Number.isFinite(actual),label+' is a finite visible number');const target=rounded?Number(expected.toPrecision(6)):expected;assert.ok(Math.abs(actual-target)<=Math.max(1e-12,Math.abs(target)*1e-9),label+': expected '+target+', received '+actual);}
function verifyTables(s,v,a,b,connection){assert.equal(s.visible.results,true);assert.equal(s.csvDisabled,false);const e=expected(v,a,b);for(const mode of ['series','parallel'])for(const key of ['equivalentResistance','sourceCurrent','sourcePower'])numberClose(s.comparison[mode][key],e[mode][key],mode+' '+key);for(let n=0;n<2;n++)for(const key of ['resistance','voltage','current','power'])numberClose(s.resistors['R'+(n+1)][key],e[connection].resistors[n][key],'R'+(n+1)+' '+key);assert.equal(s.connection,connection);}
function containsUnitValues(text,unit,values){const re=new RegExp('([-+]?\\d*\\.?\\d+(?:e[-+]?\\d+)?)\\s*'+unit+'\\b','gi');const actual=[...text.matchAll(re)].map(m=>Number(m[1]));for(const value of values)assert.ok(actual.some(n=>Math.abs(n-Number(value.toPrecision(6)))<1e-9),'visible relationship includes '+value+' '+unit+': '+text);}
function pageState(){
 const visible=n=>!!n&&n.getClientRects().length>0&&!n.closest('[hidden]');
 const table=(id,attr)=>Object.fromEntries([...document.querySelectorAll(id+' tbody tr')].map(r=>[r.getAttribute(attr),Object.fromEntries([...r.querySelectorAll('[data-quantity]')].map(c=>[c.dataset.quantity,Number(c.textContent.replace(/[,\s]/g,''))]))]));
 return {inputs:Object.fromEntries(['source-voltage','resistance-1','resistance-2'].map(id=>[id,document.getElementById(id).value])),connection:document.querySelector('input[name="connection"]:checked').value,comparison:table('#comparison-table','data-connection'),resistors:table('#resistor-table','data-part'),visible:Object.fromEntries(['results','circuit-diagram','resistor-table','comparison-table','invalid-results'].map(id=>[id,visible(document.getElementById(id))])),csvDisabled:document.getElementById('download-comparison').disabled,courseDisabled:document.getElementById('download-course').disabled,allCellsCleared:[...document.querySelectorAll('#results [data-quantity]')].every(n=>n.textContent==='—'&&!n.hasAttribute('data-value')),drawingChildren:document.getElementById('circuit-drawing').children.length,arrows:[...document.querySelectorAll('.current-arrow')].filter(visible).length,connectionText:document.getElementById('connection-summary').textContent,powerText:document.getElementById('power-summary').textContent,comparisonNote:document.getElementById('comparison-note').textContent,status:document.getElementById('lab-status').textContent,ariaInvalid:Object.fromEntries(['source-voltage','resistance-1','resistance-2'].map(id=>[id,document.getElementById(id).getAttribute('aria-invalid')]))};
}
function pageLayout(){const rect=id=>{const r=document.getElementById(id).getBoundingClientRect();return{x:r.x,right:r.right,width:r.width,height:r.height}};return{width:innerWidth,pageWidth:document.documentElement.scrollWidth,bodyWidth:document.body.scrollWidth,inputs:Object.fromEntries(['source-voltage','resistance-1','resistance-2'].map(id=>[id,rect(id)])),diagram:rect('circuit-diagram'),tableWrappers:[...document.querySelectorAll('.table-scroll')].map(n=>({width:n.clientWidth,scrollWidth:n.scrollWidth}))};}
const report=await withBrowser({output,profileParent:'/home/jacob/towerops-json-draft-bd1abdb2f886-qa'},async api=>{
 const {report,command,evaluate,click,key,type,viewport,navigate,screenshot,check,downloads}=api;
 Object.assign(report,{kind:'independent-dc-direct-file-browser-receiving',candidateRoot:root,sourceBefore:before,sourceBase:execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),receiverSha256:sha(fs.readFileSync(new URL(import.meta.url))),helperSha256:sha(fs.readFileSync(join(qa,'browser-helpers.mjs'))),contracts:Object.fromEntries(['browser-contract.json','zero-voltage-supplement.json','ui-contract-supplement.json'].map(p=>[p,sha(fs.readFileSync(join(qa,p)))])),testedURL:labURL,downloadWitnesses:[],screenshots:[]});
 const state=()=>evaluate('('+pageState.toString()+')()');
 const edit=async(id,text)=>{if(text===''){await click('#'+id);await key('a',65,2);await key('Backspace',8);}else await type('#'+id,text);};
 const set=async(v,a,b)=>{for(const [id,value]of [['source-voltage',v],['resistance-1',a],['resistance-2',b]])await edit(id,String(value));};
 const select=mode=>click('input[name="connection"][value="'+mode+'"]');
 const remember=async name=>{const s=await state();report.observations.push({name,...s});return s;};
 const tabTo=async(id)=>{const visited=[];for(let n=0;n<35;n++){await key('Tab',9);const a=await evaluate('({id:document.activeElement.id,name:document.activeElement.name,value:document.activeElement.value,tag:document.activeElement.tagName})');visited.push(a);if(a.id===id){report.observations.push({name:'keyboard-route-'+id,visited});return;}}throw Error('Tab did not reach '+id);};
 const saveDownload=async(name,trigger)=>{
  const previous=new Set(await readdir(downloads)),start=report.downloadEvents.length;await trigger();
  await until(()=>report.downloadEvents.slice(start).some(e=>e.method==='Browser.downloadProgress'&&e.state==='completed'),'actual browser download '+name);
  const file=await until(async()=>{const files=(await readdir(downloads)).filter(x=>!previous.has(x)&&!x.endsWith('.crdownload'));return files.length===1?files[0]:false;},'downloaded file '+name);
  const bytes=await readFile(join(downloads,file)),witness=join(output,name);await copyFile(join(downloads,file),witness);
  report.downloadWitnesses.push({name,file,bytes:bytes.length,sha256:sha(bytes),witness,events:report.downloadEvents.slice(start)});return bytes;
 };
 const verifyCSV=(bytes,v,a,b)=>{
  const rows=bytes.toString('utf8').trim().split(/\r?\n/).map(s=>s.split(','));assert.equal(rows.length,3,'CSV header plus two actual data rows');
  const heads=rows[0].map(x=>x.toLowerCase().replace(/[^a-z0-9]/g,''));report.observations.push({name:'actual-csv',header:rows[0],rows:rows.slice(1)});
  const idx=names=>{const n=heads.findIndex(x=>names.includes(x));assert.ok(n>=0,'CSV has expected column '+names.join('/'));return n;};
  const mi=idx(['connection']),e=expected(v,a,b);
  for(const row of rows.slice(1)){const mode=row[mi];assert.ok(mode==='series'||mode==='parallel','CSV connection');for(const [names,value]of [[['voltagev','sourcevoltagev'],v],[['r1ohm','resistance1ohm'],a],[['r2ohm','resistance2ohm'],b],[['equivalentresistanceohm','equivalentresistance'],e[mode].equivalentResistance],[['sourcecurrenta','sourcecurrent'],e[mode].sourceCurrent],[['sourcepowerw','sourcepower'],e[mode].sourcePower]])numberClose(Number(row[idx(names)]),value,'raw CSV '+mode+' '+names[0],false);}
  assert.deepEqual(rows.slice(1).map(r=>r[mi]).sort(),['parallel','series']);
 };
 const invalid=async name=>{const s=await remember(name);for(const id of ['results','circuit-diagram','resistor-table','comparison-table'])assert.equal(s.visible[id],false,id+' hidden for invalid input');assert.equal(s.visible['invalid-results'],true);assert.equal(s.allCellsCleared,true);assert.equal(s.drawingChildren,0);assert.equal(s.csvDisabled,true);assert.equal(s.courseDisabled,false);assert.ok(s.status.trim());};
 await viewport(1280,1100);await navigate(labURL);await until(()=>evaluate('!!document.querySelector("#source-voltage")&&!document.querySelector("#results").hidden'),'actual standalone initial result');
 await check('direct file opens with correct default series and parallel values',async()=>{assert.equal(await evaluate('location.protocol'),'file:');verifyTables(await remember('initial-defaults'),12,4,8,'series');assert.ok((await state()).arrows>0);report.screenshots.push(await screenshot('desktop-default.png'));});
 await check('independent series values and displayed current voltage power relationships',async()=>{await set(12,100,200);await select('series');const s=await remember('known-series');verifyTables(s,12,100,200,'series');containsUnitValues(s.connectionText,'A',[.04]);containsUnitValues(s.connectionText,'V',[4,8,12]);containsUnitValues(s.powerText,'W',[.48,.16,.32]);});
 await check('independent parallel values and displayed current voltage power relationships',async()=>{await select('parallel');const s=await remember('known-parallel');verifyTables(s,12,100,200,'parallel');containsUnitValues(s.connectionText,'A',[.12,.06,.18]);containsUnitValues(s.connectionText,'V',[12]);containsUnitValues(s.powerText,'W',[2.16,1.44,.72]);await evaluate('document.querySelector(".workbench").scrollIntoView({block:"start"})');report.screenshots.push(await screenshot('desktop-parallel.png'));});
 await check('real resistor edit and topology roundtrip use current input values',async()=>{await edit('resistance-2','400');verifyTables(await remember('parallel-r2-changed'),12,100,400,'parallel');await select('series');verifyTables(await remember('roundtrip-series'),12,100,400,'series');await select('parallel');verifyTables(await remember('roundtrip-parallel'),12,100,400,'parallel');});
 await check('equal and unequal presets update the real circuit controls',async()=>{await click('#preset-equal');verifyTables(await remember('equal-preset'),12,6,6,'parallel');await click('#preset-unequal');verifyTables(await remember('unequal-preset'),12,4,8,'parallel');});
 await check('zero voltage keeps finite equivalent resistance with zero current power and no arrows',async()=>{await set(12,100,200);await click('#preset-zero');for(const mode of ['series','parallel']){await select(mode);const s=await remember('zero-'+mode);verifyTables(s,0,100,200,mode);assert.equal(s.arrows,0);assert.ok(!/NaN|Infinity/i.test(s.comparisonNote+s.connectionText+s.powerText));}});
 await check('blank and zero resistance clear stale results and disable comparison download',async()=>{await set(12,100,200);await edit('resistance-1','');await invalid('blank-resistance');const n=report.downloadEvents.length;await click('#download-comparison');await delay(300);assert.equal(report.downloadEvents.length,n,'disabled comparison creates no download');await edit('resistance-1','0');await invalid('zero-resistance');});
 await check('course download remains available during invalid input and exactly preserves original bytes',async()=>{const b=await saveDownload('course-invalid-state.json',()=>click('#download-course'));assert.ok(b.equals(course),'actual browser course download equals every original source byte');assert.equal(JSON.parse(b).title,JSON.parse(course).title);});
 await check('out of range and nonfinite edits clear results and valid input recovers',async()=>{await set(12,100,200);await edit('source-voltage','25');await invalid('above-voltage-limit');await edit('source-voltage','12');await edit('resistance-2','1001');await invalid('above-resistance-limit');await edit('resistance-2','200');await edit('source-voltage','1e999');await invalid('nonfinite-browser-input');await set(12,100,200);verifyTables(await remember('recovered-valid'),12,100,200,'parallel');assert.ok(Object.values((await state()).ariaInvalid).every(x=>x===null));});
 await check('actual comparison CSV contains both current unrounded solutions',async()=>{const b=await saveDownload('comparison-12v.csv',()=>click('#download-comparison'));verifyCSV(b,12,100,200);});
 await check('keyboard edits radio change visible focus and comparison download work',async()=>{
  await navigate(labURL);await until(()=>evaluate('document.querySelector("#source-voltage")?.value==="12"'),'fresh keyboard page');
  await tabTo('source-voltage');await key('a',65,2);await command('Input.insertText',{text:'6'});
  await key('Tab',9);assert.equal(await evaluate('document.activeElement.id'),'resistance-1');await key('a',65,2);await command('Input.insertText',{text:'100'});
  await key('Tab',9);assert.equal(await evaluate('document.activeElement.id'),'resistance-2');await key('a',65,2);await command('Input.insertText',{text:'200'});
  await key('Tab',9);assert.equal(await evaluate('document.activeElement.name'),'connection');await key('ArrowRight',39);verifyTables(await remember('keyboard-current-values'),6,100,200,'parallel');
  const focus=await evaluate('({tag:document.activeElement.tagName,value:document.activeElement.value,outline:getComputedStyle(document.activeElement).outlineStyle,width:getComputedStyle(document.activeElement).outlineWidth})');report.observations.push({name:'keyboard-visible-focus',...focus});assert.notEqual(focus.outline,'none');assert.ok(parseFloat(focus.width)>0);
  await tabTo('download-comparison');const b=await saveDownload('comparison-keyboard-6v.csv',()=>key('Enter',13));verifyCSV(b,6,100,200);
 });
 await check('keyboard course download preserves the same source bytes',async()=>{await tabTo('download-course');const b=await saveDownload('course-keyboard.json',()=>key('Enter',13));assert.ok(b.equals(course));});
 await check('390 pixel viewport retains reachable controls diagram tables and readable page width',async()=>{
  await viewport(390,1000);await click('#preset-unequal');await select('parallel');await evaluate('scrollTo(0,0)');report.screenshots.push(await screenshot('mobile-controls.png'));
  const layout=await evaluate('('+pageLayout.toString()+')()');report.observations.push({name:'mobile-layout',...layout});assert.ok(layout.pageWidth<=390&&layout.bodyWidth<=390,'no horizontal page overflow');for(const r of Object.values(layout.inputs))assert.ok(r.x>=0&&r.right<=390&&r.width>=40);assert.ok(layout.diagram.x>=0&&layout.diagram.right<=390);
  await evaluate('document.querySelector("#selected-connection").scrollIntoView({block:"start"})');report.screenshots.push(await screenshot('mobile-parallel.png'));await select('series');verifyTables(await remember('mobile-series'),12,4,8,'series');await evaluate('document.querySelector("#selected-connection").scrollIntoView({block:"start"})');report.screenshots.push(await screenshot('mobile-series.png'));
 });
 await check('direct file interactions need no HTTP requests and have no page exceptions',async()=>{assert.deepEqual(report.requests.filter(r=>/^https?:/i.test(r.url)),[]);assert.deepEqual(report.pageErrors,[]);});
});
report.sourceAfter=snapshot();report.sourceChanged=Object.keys(before).filter(p=>before[p]!==report.sourceAfter[p]);report.checks.push({name:'all six frozen source files remain unchanged',status:report.sourceChanged.length?'failed':'passed'});if(report.sourceChanged.length)report.status='failed';report.checkCount=report.checks.length;
await writeFile(join(output,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,passed:report.checks.filter(c=>c.status==='passed').length,failed:report.checks.filter(c=>c.status==='failed').map(c=>({name:c.name,error:c.error})),sourceChanged:report.sourceChanged,cleanup:report.cleanup,downloads:report.downloadWitnesses?.map(d=>({name:d.name,bytes:d.bytes,sha256:d.sha256})),report:join(output,'browser-report.json'),reportSha256:sha(await readFile(join(output,'browser-report.json')))}));
if(report.status!=='passed')process.exitCode=1;
