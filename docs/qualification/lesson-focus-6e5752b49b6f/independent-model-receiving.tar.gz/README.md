# Independent receiving: prerequisite-complete focused lessons

Receiver: `estate-6e5752b49b6f/root`, independent of the author of RecallWeave issue44.

## Qualified source and result

The model at source checkpoint `3904c2f384d7f8fd4225d6ffbc2f4c89e6eae0ed` (tree `aac3244fa7f55e393dc0e4de0cecffd82a88af66`, real base `5c6e5b4ee4b928b01466ffe1ff67ceeca44fb9cc`) is accepted for its declared pure planning and checked-file contract. Model SHA256: `82e362e82a185c18f771f675622bcef8c382b7832e9d95a6c5341fa96e051370`. The unchanged shared validator is blob `f0f8a4b234489c2388f427633f548d56c6ed4c03`, SHA256 `621438c166ec4bfafd9d87c698a1d46cb1722f4fb92dcbb8d9f52fce682c338b`.

All six independent groups passed in native Node24.19.0 on Linux x64. Both input modules remained byte-identical before and after the run. The full source review has no findings.

The receiver constructed seven different prerequisite graphs, including disconnected topics, branching/shared prerequisites, a dense DAG and dependencies divided between two questions for the same concept. It exercised every nonempty selection of each eight-concept source: **1,785 distinct choices**. Expected membership comes from a separately authored Boolean transitive-reachability matrix. Hand-derived controls check that oracle. Source concept and question order deliberately differ from prerequisite order and question grouping.

Every output retains the complete required concept set, every question for each retained concept, exact answer/option/prerequisite/explanation/transfer fields, literal attribution/license text, and source ordering. Inclusion counts and direct reasons are checked against retained source edges. Empty preview, malformed selections/titles and invalid graphs are checked independently. Outputs are deeply frozen and detached from subsequent mutation of source content or selection arrays.

Two separately constructed sources, ASCII and multibyte, each occupy exactly **262,144 UTF-8 bytes**. Both are admitted by the unchanged parser and exported with exact content bytes through compact fallback. A one-byte title increase refuses the oversized export. Eight deliberately corrupted output controls are rejected by the receiver, including missing questions, reordered content, changed answers/options/permission text and incorrect inclusion reasons.

## Evidence and limits

`receiving-r1.json` and `model-native-output.txt` are the actual successful output. `source/src/` contains the exact two modules exercised. `oracle-fixtures.mjs` was written from the shared deck contract before the production model was read. The receiver then uses the exported public API without replacing production logic.

The first receiver initialization exited before importing or invoking the candidate: passing `readFile` directly to `Array.map` accidentally supplied the array index as its options argument. `receiver-r0-options-error.mjs.txt` and `receiver-r0-failure.json` preserve that receiving-tool error. The one-argument callback correction did not alter product source or test expectations.

This packet qualifies the stated model and serialized files. It does not claim browser interaction, learner completion, later source composition, hosted CI, deployment, course accuracy, or field benefit. Those remain separate receiving gates with exact source provenance.

## Reproduce

From the extracted packet directory, using a compatible native Node runtime:

```sh
node receive-focus.mjs source /tmp/focus-receiving-new.json
```

This reruns the actual included source modules, writes a new receipt and leaves the preserved original receipt intact. The boundary fixtures are deterministically generated in memory; no dependency installation, network access or browser profile is required.
