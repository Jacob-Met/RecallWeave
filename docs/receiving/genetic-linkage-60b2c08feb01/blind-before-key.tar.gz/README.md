# Blind linkage-course receiving before key disclosure

The literal prompts/options packet1edf2bfe was fetched and hashed, then every answer and its reasoning were independently sealed in blind-solutions.json. The authored full-course identityc44bcdc9 had been reported by the author before solving, but its bytes, answer key, explanations and guide were not read. No model implementation was read.

The twelve zero-based answers are2,1,0,3,0,2,1,0,3,2,1,0. No material competing-answer ambiguity was found under the lab's declared equal-segregation and reciprocal-class symmetry. The gl-testcross-2 arithmetic uses that explicit global model; recombinant total alone would not establish parental equality in an unconstrained population.

receive-course.mjs was drafted and syntax-checked before prompt access. It will bind the eventual canonical course's exact prompts/options to these answers and test two deliberately wrong but schema-valid keys using the unchanged native validator. It has not been run against any course. Manual explanation/transfer review remains a separate pending gate.

The original independent math/expectations/calibration capsule is canonical208aa76f132fa8abc03cbc6d1ef1435b2cf99361 and remains unchanged. This packet adds blind-content receiving; it does not replay prior calibration or claim candidate acceptance. members.json hashes every other member.

No remote ref/PR/Actions, product-source mutation, installs, providers, hamon-ie or LA7 access.
