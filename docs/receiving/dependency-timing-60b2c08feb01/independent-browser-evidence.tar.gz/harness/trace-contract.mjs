import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

export const TRACE_ASSUMPTIONS = {
  edgeConvention: 'X -> Y means X must finish before Y can start',
  timeUnit: 'abstract time units',
  durationModel: 'deterministic nonnegative integers',
  durationRange: [0, 1000000],
  parallelism: 'unlimited',
  dependencyLag: 0,
  startTime: 0,
  latestTimeReference: 'earliest project finish',
  calendars: false,
  resourceLimits: false,
};
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export const gitBlob = bytes => createHash('sha1').update('blob ' + bytes.length + '\0').update(bytes).digest('hex');

const jobs = ['Finish', 'Right', '__proto__', 'Left', 'Detached'];
const edges = [['Right', 'Finish'], ['__proto__', 'Finish'], ['__proto__', 'Left'], ['Left', 'Finish'], ['__proto__', 'Right']];
const prerequisites = [['Right', '__proto__', 'Left'], ['__proto__'], [], ['__proto__'], []];
const graphAnalysis = {
  completed: [], ready: ['__proto__', 'Detached'], cycleComponents: [], cycleMembers: [], blockedByCycle: [],
  rows: jobs.map((job, i) => ({ job, prerequisites: [...prerequisites[i]], unmet: [...prerequisites[i]], status: prerequisites[i].length ? 'waiting' : 'ready' })),
  remaining: [...jobs], finished: false,
};
const tiedRows = [
  { job: 'Finish', duration: 3, earliestStart: 2, earliestFinish: 5, latestStart: 2, latestFinish: 5, totalSlack: 0, critical: true },
  { job: 'Right', duration: 2, earliestStart: 0, earliestFinish: 2, latestStart: 0, latestFinish: 2, totalSlack: 0, critical: true },
  { job: '__proto__', duration: 0, earliestStart: 0, earliestFinish: 0, latestStart: 0, latestFinish: 0, totalSlack: 0, critical: true },
  { job: 'Left', duration: 2, earliestStart: 0, earliestFinish: 2, latestStart: 0, latestFinish: 2, totalSlack: 0, critical: true },
  { job: 'Detached', duration: 0, earliestStart: 0, earliestFinish: 0, latestStart: 5, latestFinish: 5, totalSlack: 5, critical: false },
];
export function handCase(name) {
  if (name === 'tied' || name === 'right-one') {
    const rows = structuredClone(tiedRows);
    if (name === 'right-one') rows[1] = { job: 'Right', duration: 1, earliestStart: 0, earliestFinish: 1, latestStart: 1, latestFinish: 2, totalSlack: 1, critical: false };
    return {
      name, graph: { jobs: [...jobs], edges: structuredClone(edges) },
      durations: rows.map(({ job, duration }) => ({ job, duration })),
      graphAnalysis: structuredClone(graphAnalysis),
      timing: {
        projectDuration: 5, rows,
        criticalJobs: name === 'tied' ? ['Finish', 'Right', '__proto__', 'Left'] : ['Finish', '__proto__', 'Left'],
        criticalEdges: name === 'tied'
          ? [['Right', 'Finish'], ['__proto__', 'Right'], ['__proto__', 'Left'], ['Left', 'Finish']]
          : [['__proto__', 'Left'], ['Left', 'Finish']],
      },
    };
  }
  assert.equal(name, 'literal-zero');
  const zeroJobs = ['<b>零</b>', 'constructor', 'Tail'];
  const zeroEdges = [[zeroJobs[0], 'Tail'], ['constructor', 'Tail']];
  return {
    name, graph: { jobs: zeroJobs, edges: zeroEdges },
    durations: zeroJobs.map(job => ({ job, duration: 0 })),
    graphAnalysis: {
      completed: [], ready: zeroJobs.slice(0, 2), cycleComponents: [], cycleMembers: [], blockedByCycle: [],
      rows: zeroJobs.map((job, i) => ({ job, prerequisites: i === 2 ? zeroJobs.slice(0, 2) : [], unmet: i === 2 ? zeroJobs.slice(0, 2) : [], status: i === 2 ? 'waiting' : 'ready' })),
      remaining: [...zeroJobs], finished: false,
    },
    timing: {
      projectDuration: 0,
      rows: zeroJobs.map(job => ({ job, duration: 0, earliestStart: 0, earliestFinish: 0, latestStart: 0, latestFinish: 0, totalSlack: 0, critical: true })),
      criticalJobs: [...zeroJobs], criticalEdges: structuredClone(zeroEdges),
    },
  };
}
export function expectedTrace(testCase) {
  return {
    schema: 'recallweave-dependency-timing/1',
    assumptions: structuredClone(TRACE_ASSUMPTIONS),
    input: { graph: structuredClone(testCase.graph), durations: structuredClone(testCase.durations) },
    result: { graphAnalysis: structuredClone(testCase.graphAnalysis), timing: structuredClone(testCase.timing) },
  };
}
export function assertTraceBytes(bytes, testCase) {
  const raw = Buffer.from(bytes);
  const text = new TextDecoder('utf-8', { fatal: true }).decode(raw);
  assert(raw.equals(Buffer.from(text, 'utf8')), 'Trace must be exact UTF-8 without a BOM or lossy decoding');
  const parsed = JSON.parse(text);
  const expected = expectedTrace(testCase);
  assert.deepEqual(parsed, expected, 'Downloaded values must match the independent hand fixture');
  assert.equal(text, JSON.stringify(expected, null, 2) + '\n', 'Trace bytes must follow the agreed field order, two-space JSON and terminal LF');
  return { bytes: raw.length, sha256: sha256(raw), schema: parsed.schema, case: testCase.name, parsed };
}
