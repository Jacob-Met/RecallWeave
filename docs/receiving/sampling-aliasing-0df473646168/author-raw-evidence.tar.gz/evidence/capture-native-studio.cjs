const fs = require('node:fs/promises');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
async function main() {
  const destination = path.join(__dirname, 'native-studio-bounded');
  await fs.mkdir(destination);
  await fs.mkdir(path.join(destination, 'tmp'));
  process.env.TMPDIR = path.join(destination, 'tmp');
  const { chromium } = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'playwright'));
  const author = path.join(__dirname, 'native-author/author.html');
  const course = path.join(__dirname, 'browser-run02/downloaded-sampling-course.json');
  const digest = async file => crypto.createHash('sha256').update(await fs.readFile(file)).digest('hex');
  const before = { author: await digest(author), downloadedCourse: await digest(course) };
  const report = { purpose: 'Resolve only the ancillary full-page screenshot failure after all thirteen browser functional scenarios completed.', before, errors: [] };
  const browser = await chromium.launch({ executablePath: '/workspace/scratch/0c6c4d37eb0f/native-product-worker/browser-runtime/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  try {
    const page = await browser.newPage({ viewport: { width: 1280, height: 960 } });
    page.on('pageerror', error => report.errors.push(String(error)));
    await page.goto(pathToFileURL(author).href);
    await page.locator('#open-deck').setInputFiles(course);
    await page.locator('#open-preview').waitFor({ state: 'visible' });
    await page.locator('#replace-draft').click();
    await page.locator('#check-draft').click();
    await page.locator('#author-preview').waitFor({ state: 'visible' });
    await page.locator('#author-preview').scrollIntoViewIfNeeded();
    report.dimensions = await page.evaluate(() => ({ viewport: [innerWidth, innerHeight], document: [document.documentElement.scrollWidth, document.documentElement.scrollHeight] }));
    report.questions = await page.locator('#question-picker option').count();
    assert.equal(report.questions, 12);
    await page.screenshot({ path: path.join(destination, 'native-studio-viewport.png'), fullPage: false });
    report.after = { author: await digest(author), downloadedCourse: await digest(course) };
    assert.deepEqual(report.after, before);
    assert.deepEqual(report.errors, []);
    report.success = true;
  } catch (error) {
    report.success = false;
    report.failure = { message: error.message, stack: error.stack };
    process.exitCode = 1;
  } finally {
    await browser.close();
    await fs.writeFile(path.join(destination, 'receipt.json'), JSON.stringify(report, null, 2) + '\n');
    process.stdout.write(JSON.stringify(report) + '\n');
  }
}
main().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
