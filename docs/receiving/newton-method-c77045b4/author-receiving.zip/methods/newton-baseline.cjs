const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),git='C:\\Program Files\\Git\\cmd\\git.exe';
const run=args=>cp.execFileSync(git,['-C',root,...args],{encoding:'utf8',windowsHide:true}).trim();
const base=run(['rev-parse','HEAD']),tree=run(['rev-parse','HEAD^{tree}']),files=run(['ls-files']).split('\n');
if(base!=='567425f209cdf8e8cf9767faac9bfd3003af3e65'||tree!=='a877e5d5eb1953aa2389ea75ef7cad96da321c1a')throw new Error('Unexpected receiving base');
const matching=files.filter(f=>/newton/i.test(f));
if(matching.length)throw new Error('Capability already exists: '+matching.join(','));
const receipt={at:new Date().toISOString(),source:base,tree,trackedFiles:files.length,matchingPaths:matching,instructions:files.filter(f=>/(^|\/)(AGENTS|CLAUDE|CODEX_HANDOFF)\.md$/.test(f)),gitStatus:run(['status','--porcelain']),missingCapability:'No Newton method source, original course or tangent explorer exists in the complete current source tree.',expectedNewEntry:'courses/newton-method-explorer.html',entryExists:fs.existsSync(path.join(root,'courses/newton-method-explorer.html')),node:process.version,readmeSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'README.md'))).digest('hex')};
fs.mkdirSync(path.join(__dirname,'newton-receiving'),{recursive:true});fs.writeFileSync(path.join(__dirname,'newton-receiving','baseline-absence.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
