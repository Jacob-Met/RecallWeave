'use strict';
const fs=require('node:fs'),path=require('node:path'),c=require('node:crypto'),a=require('node:assert/strict');
const previous=path.join(__dirname,'..','course-comparison-source-receiving-root-r1');
const hash=b=>c.createHash('sha256').update(b).digest('hex');
const entries=[['intake-r1.json',48555,'e185d1a9fabef3a473f883efd2e5ef1cd9cad64b8878372345f9b94745d75e43'],['intake-r2.json',39225,'fbeeb2449cca6c2fada3a0b942c6df89085d8511897bb5df9e42be886a8a542b']];
const copied=[];for(const[name,bytes,sha256]of entries){const source=path.join(previous,name),destination=path.join(__dirname,name),b=fs.readFileSync(source);a.equal(b.length,bytes);a.equal(hash(b),sha256);a.ok(!fs.existsSync(destination));fs.writeFileSync(destination,b,{flag:'wx'});a.deepEqual(fs.readFileSync(destination),b);copied.push({source,destination,bytes,sha256});}
const receiver=fs.readFileSync(path.join(__dirname,'receive-renderer-r2.mjs'));a.equal(receiver.length,15455);a.equal(hash(receiver),'74381dc66562de16743d02fd2e399a353b6f29e8dd25c43f17a736794e0c7bd1');
const receipt={schema:'recall180-root-renderer-r2-staging/1',accepted:true,node:process.version,copied,receiver:{bytes:receiver.length,sha256:hash(receiver)},historicalInputsUnchanged:true};
fs.writeFileSync(path.join(__dirname,'staging.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
