import pathlib,json,datetime,subprocess,hashlib,os
R=pathlib.Path(__file__).resolve().parent
names=[26796,4768,5936,25504,29508,11204,28628,28336,14680,20236,2024]
command="$ids=@("+",".join(map(str,names))+"); @(Get-CimInstance Win32_Process | Where-Object {$ids -contains [int]$_.ProcessId} | Select-Object ProcessId,Name,CreationDate,CommandLine)|ConvertTo-Json -Depth 4 -Compress"
raw=subprocess.check_output(['powershell','-NoProfile','-Command',command],text=True,encoding='utf-8')
observed=json.loads(raw) if raw.strip() else []
receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),observer=os.getpid(),known=names,observed=observed,tmp_entries=[str(x) for x in (R/'browser-r1/tmp').rglob('*')],transport_note='read_process_output for historical shell28336 returned unrelated Household archive output and an unrelated numeric0. That result is not a sorting-network exit. Native own wrapper receipt records Node20236 exit1, normal browser close and unchanged source/donor. Historical PID numbers are not an identity after reuse.')
with (R/'AUTHOR-R1-DELAYED-CLOSURE.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
