# Independent explorer UI and build review

The final UI/template/builder source is accepted. One text-input contrast defect was found and repaired by the author: the neutral border changed from #8da89a (2.560908:1 against white) to #647f70 (4.364467:1). The first finding and the exact color-only final derivation are preserved separately.

`source-review.json` binds the final four source/output pins and states the limits. `input-manifest.json` and `fixture/` preserve the six inputs used by the independent build probe. That probe does not execute a browser or check arithmetic; it verifies deterministic composition, exact course text, script-delimiter/dollar/Unicode round trips, and refusal of a stale generated page. Its eleven assertions passed. The stale-check child intentionally exits one; its actual logs are retained.

To reproduce the bounded probe with an existing Node installation, extract the packet into a new directory and run:

```sh
node probe-build.mjs
```

The probe writes only its own fixture output and sample. It temporarily replaces only the copied course text and restores all six original fixture hashes. `fixture/courses/unit-conversion-explorer.html` is intentionally stale negative-control output, not a distributable product page.

The initial probe uses the v1 template. Final v2 acceptance mechanically verifies the one input-border replacement in both template and generated HTML; unchanged UI/builder/core/course/parser hashes are recorded. No repeat browser or arithmetic claim is made. Root authored tests were not inspected, and no product or hosted source was edited by the reviewer.
