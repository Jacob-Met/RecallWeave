import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { join, basename, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import puppeteer from '/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
import { receiveLearner } from './receive-course-learner.mjs';

const input = process.env.UNITS_BROWSER_INPUT;
const output = process.env.UNITS_BROWSER_OUTPUT;
const expectedManifest = process.env.UNITS_INPUT_MANIFEST_SHA256;
assert.ok(input && output && expectedManifest, 'explicit isolated input, output, and manifest pin required');
const sha = data => createHash('sha256').update(data).digest('hex');
const startedAt = new Date().toISOString();
await fs.mkdir(output, { recursive: false });
const run = {
  schema: 'hamon.recallweave.units.native-browser.v1',
  startedAt,
  inputManifestSHA256: expectedManifest,
  route: 'direct-file',
  networkPolicy: 'Every page HTTP/HTTPS request is blocked; file, blob, data and about requests are allowed.',
  nativeEnvironment: { node: process.version, platform: process.platform, architecture: process.arch },
  checks: [], blockedNetwork: [], pageErrors: [], consoleErrors: [], requestFailures: [], downloads: [],
};
let browser;
let page;
const profile = join(dirname(output), 'profile-' + basename(output));
async function verifyInputs() {
  const raw = await fs.readFile(join(input, 'input-manifest.json'));
  assert.equal(sha(raw), expectedManifest, 'frozen input manifest is exact');
  const manifest = JSON.parse(raw);
  for (const item of manifest.files) {
    const bytes = await fs.readFile(join(input, item.path));
    assert.equal(bytes.length, item.bytes, item.path + ' byte count');
    assert.equal(sha(bytes), item.sha256, item.path + ' SHA256');
  }
  return { fileCount: manifest.files.length, manifest };
}
async function check(name, action) {
  const start = new Date().toISOString();
  try {
    const evidence = await action();
    run.checks.push({ name, passed: true, startedAt: start, evidence });
  } catch (error) {
    run.checks.push({ name, passed: false, startedAt: start, error: String(error.stack || error) });
    throw error;
  }
}
async function fill(selector, value) {
  await page.click(selector);
  await page.keyboard.press('Home');
  await page.keyboard.down('Shift');
  await page.keyboard.press('End');
  await page.keyboard.up('Shift');
  await page.keyboard.press('Backspace');
  // Triple click selects the complete native text field on macOS as well.
  await page.click(selector, { clickCount: 3 });
  await page.keyboard.press('Backspace');
  if (value !== '') await page.type(selector, value);
  assert.equal(await page.$eval(selector, node => node.value), value);
}
async function setConversion(value, from, to, submit = 'keyboard') {
  await fill('#quantity', value);
  await fill('#from-unit', from);
  await fill('#to-unit', to);
  if (submit === 'keyboard') await page.keyboard.press('Enter');
  else await page.click('#conversion-form button[type="submit"]');
}
async function current() {
  return await page.evaluate(() => ({
    input: ['quantity', 'from-unit', 'to-unit'].map(id => document.getElementById(id).value),
    resultHidden: document.getElementById('conversion-result').hidden,
    resultText: document.getElementById('conversion-result').textContent,
    number: document.getElementById('converted-value')?.textContent || null,
    precision: document.getElementById('precision-notice')?.textContent || null,
    factor: document.getElementById('exact-factor')?.textContent || null,
    exact: document.getElementById('exact-result')?.textContent || null,
    status: document.getElementById('conversion-status').textContent,
    dimensionHidden: document.getElementById('dimension-panel').hidden,
    dimensionMatch: document.getElementById('dimension-badge').dataset.match || null,
    dimensions: [...document.querySelectorAll('#dimension-rows tr')].map(row =>
      [...row.querySelectorAll('td')].map(cell => Number(cell.textContent))),
    recordDisabled: document.getElementById('download-conversion').disabled,
    deckDisabled: document.getElementById('download-unit-deck').disabled,
    invalid: ['quantity', 'from-unit', 'to-unit'].map(id => document.getElementById(id).getAttribute('aria-invalid')),
  }));
}
async function valid(expected) {
  const actual = await current();
  assert.equal(actual.resultHidden, false, 'current result is visible');
  assert.equal(actual.recordDisabled, false, 'current result may be downloaded');
  assert.equal(actual.dimensionHidden, false);
  assert.equal(actual.dimensionMatch, 'true');
  assert.deepEqual(actual.dimensions, expected.dimensions.map(value => [value, value]));
  assert.ok(actual.factor.endsWith(' = ' + expected.factor), 'exact unit factor');
  assert.ok(actual.exact.endsWith(' = ' + expected.result), 'exact converted result');
  assert.equal(actual.number, expected.display, 'displayed result');
  assert.equal(actual.precision.includes('rounded to 12 significant digits'), expected.rounded);
  assert.ok(actual.status.length > 0);
  assert.deepEqual(actual.invalid, [null, null, null]);
  return actual;
}
async function refused({ mismatch = false, invalidField = null } = {}) {
  const actual = await current();
  assert.equal(actual.resultHidden, true, 'invalid current inputs retire the old result');
  assert.equal(actual.resultText, '', 'retired arithmetic is not left current in DOM');
  assert.equal(actual.number, null);
  assert.equal(actual.recordDisabled, true, 'retired result cannot be downloaded');
  assert.equal(actual.deckDisabled, false, 'lesson download remains independent of calculation');
  assert.ok(actual.status.length > 0, 'visible refusal reason');
  if (mismatch) {
    assert.equal(actual.dimensionHidden, false);
    assert.equal(actual.dimensionMatch, 'false');
    assert.notDeepEqual(actual.dimensions.map(row => row[0]), actual.dimensions.map(row => row[1]));
  }
  if (invalidField !== null) assert.equal(actual.invalid[invalidField], 'true');
  return actual;
}
async function download(downloadPage, selector, name) {
  const directory = join(output, 'downloads', name);
  await fs.mkdir(directory, { recursive: false });
  const cdp = await downloadPage.createCDPSession();
  try {
    await cdp.send('Page.setDownloadBehavior', { behavior: 'allow', downloadPath: directory });
    await downloadPage.click(selector);
    let filename;
    const deadline = Date.now() + 8000;
    while (Date.now() < deadline) {
      const files = await fs.readdir(directory);
      const finished = files.filter(file => !file.endsWith('.crdownload') && !file.endsWith('.tmp'));
      if (finished.length === 1 && files.length === 1) { filename = finished[0]; break; }
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    assert.ok(filename, 'an actual completed native download appears: ' + name);
    const path = join(directory, filename), bytes = await fs.readFile(path);
    const result = { path, name: filename, bytes: bytes.length, sha256: sha(bytes), text: bytes.toString('utf8') };
    run.downloads.push({ kind: name, path: path.slice(output.length + 1), name: filename, bytes: bytes.length, sha256: result.sha256 });
    if (selector === '#save-notes-button') await downloadPage.$eval('#first-try-summary', node => node.scrollIntoView({ block: 'start' }));
    return result;
  } finally {
    await cdp.detach();
  }
}
function assertRecord(record, expected) {
  assert.equal(record.format, 'recallweave-unit-conversion/1');
  assert.deepEqual(record.input, { value: expected.value, from: expected.from, to: expected.to });
  assert.deepEqual(record.from.dimensions, expected.dimensions);
  assert.deepEqual(record.to.dimensions, expected.dimensions);
  for (const [field, exact] of [['factor', expected.factor], ['result', expected.result]]) {
    const parts = exact.split('/');
    assert.deepEqual(record[field], { numerator: parts[0], denominator: parts[1] || '1', exact });
  }
  assert.deepEqual(record.display, { text: expected.display, rounded: expected.rounded, significant_digits: 12 });
}
try {
  run.sourceBefore = await verifyInputs();
  const source = join(input, 'source');
  const courseBytes = await fs.readFile(join(source, 'courses/units-and-dimensions.json'));
  assert.equal(sha(courseBytes), 'df0c8c8ba1f0061bbc73bcad0e9a62b257341b4bd5d6a7adbd6824820a02128e');
  const course = JSON.parse(courseBytes);
  const blindSolutions = JSON.parse(await fs.readFile(join(input, 'receiver/solutions-before-key-v1.json'), 'utf8'));
  await fs.mkdir(join(output, 'downloads'), { recursive: false });
  browser = await puppeteer.launch({
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    headless: true,
    userDataDir: profile,
    args: ['--no-first-run', '--no-default-browser-check', '--disable-background-networking'],
    defaultViewport: { width: 1280, height: 900, deviceScaleFactor: 1 },
  });
  run.nativeEnvironment.browser = await browser.version();
  page = await browser.newPage();
  await page.setRequestInterception(true);
  page.on('request', request => {
    if (/^https?:/i.test(request.url())) {
      run.blockedNetwork.push({ url: request.url(), method: request.method(), resourceType: request.resourceType() });
      request.abort('internetdisconnected').catch(() => {});
    } else request.continue().catch(() => {});
  });
  page.on('pageerror', error => run.pageErrors.push(String(error.stack || error)));
  page.on('console', message => { if (message.type() === 'error') run.consoleErrors.push(message.text()); });
  page.on('requestfailed', request => run.requestFailures.push({ url: request.url(), error: request.failure()?.errorText }));
  await page.goto(pathToFileURL(join(source, 'courses/unit-conversion-explorer.html')).href, { waitUntil: 'load' });
  await page.waitForSelector('#converted-value', { visible: true });
  await check('direct-file initial speed', () => valid({ dimensions: [1,0,-1], factor: '5/18', result: '20', display: '20', rounded: false }));
  const presets = [
    { name: 'area', dimensions: [2,0,0], factor: '100', result: '300', display: '300', rounded: false },
    { name: 'volume', dimensions: [3,0,0], factor: '1/1000', result: '1/4', display: '0.25', rounded: false },
    { name: 'density', dimensions: [-3,1,0], factor: '1000', result: '2500', display: '2500', rounded: false },
    { name: 'case', dimensions: [2,1,-2], factor: '1000000000', result: '4000000000', display: '4000000000', rounded: false },
  ];
  for (const item of presets) await check('pointer preset ' + item.name, async () => {
    await page.click('[data-preset="' + item.name + '"]');
    return await valid(item);
  });
  const repeating = { value: '1', from: 'km/h', to: 'm/s', dimensions: [1,0,-1], factor: '5/18', result: '5/18', display: '0.277777777778', rounded: true };
  await check('keyboard conversion separates rounded display and exact rational', async () => {
    await setConversion(repeating.value, repeating.from, repeating.to);
    const state = await valid(repeating);
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({ path: join(output, 'explorer-rounded-desktop.png'), fullPage: false });
    return state;
  });
  await check('actual exact conversion download', async () => {
    const file = await download(page, '#download-conversion', 'conversion-repeating');
    assert.equal(file.name, 'recallweave-unit-conversion-v1.json');
    const record = JSON.parse(file.text);
    assertRecord(record, repeating);
    return { file: run.downloads.at(-1), record };
  });
  await check('keyboard Unicode scaled square and pointer submit', async () => {
    await setConversion('2.5', 'cm²', 'm²', 'pointer');
    const state = await valid({ dimensions: [2,0,0], factor: '1/10000', result: '1/4000', display: '0.00025', rounded: false });
    assert.ok(state.resultText.includes('cm²'), 'admitted source spelling remains visible');
    return state;
  });
  await check('grouped power survives visible normalization', async () => {
    await setConversion('1', '(cm^2)^3', 'm^6');
    const state = await valid({ dimensions: [6,0,0], factor: '1/1000000000000', result: '1/1000000000000', display: '1e-12', rounded: false });
    assert.ok(state.resultText.includes('(cm^2)^3'), 'grouping is retained');
    return state;
  });
  await check('live edit replaces current result before export', async () => {
    await setConversion('36', 'km/h', 'm/s');
    await valid({ dimensions: [1,0,-1], factor: '5/18', result: '10', display: '10', rounded: false });
    await fill('#quantity', '72');
    const state = await valid({ dimensions: [1,0,-1], factor: '5/18', result: '20', display: '20', rounded: false });
    const file = await download(page, '#download-conversion', 'conversion-after-edit');
    const record = JSON.parse(file.text);
    assertRecord(record, { value: '72', from: 'km/h', to: 'm/s', dimensions: [1,0,-1], factor: '5/18', result: '20', display: '20', rounded: false });
    return { state, file: run.downloads.at(-1), record };
  });
  await check('pointer incompatible dimensions refuse conversion', async () => {
    await page.click('[data-preset="mismatch"]');
    const state = await refused({ mismatch: true });
    assert.deepEqual(state.dimensions, [[1,0], [0,0], [0,1]]);
    return state;
  });
  await check('zero quantity does not bypass incompatible dimensions', async () => {
    await fill('#quantity', '0');
    await page.keyboard.press('Enter');
    return await refused({ mismatch: true });
  });
  await check('invalid case retires a previously valid result', async () => {
    await page.click('[data-preset="speed"]');
    await fill('#from-unit', 'Km');
    return await refused({ invalidField: 1 });
  });
  await check('empty quantity retires a previously valid result', async () => {
    await page.click('[data-preset="speed"]');
    await fill('#quantity', '');
    return await refused({ invalidField: 0 });
  });
  let courseDownload;
  await check('actual lesson download remains usable while conversion is invalid', async () => {
    courseDownload = await download(page, '#download-unit-deck', 'units-lesson');
    assert.equal(courseDownload.name, 'units-and-dimensions.json');
    assert.equal(courseDownload.bytes, courseBytes.length);
    assert.equal(courseDownload.sha256, sha(courseBytes));
    assert.deepEqual(JSON.parse(courseDownload.text), course);
    return run.downloads.at(-1);
  });
  await check('phone viewport preserves readable current state and layout', async () => {
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
    await page.click('[data-preset="case"]');
    const state = await valid(presets.find(item => item.name === 'case'));
    const layout = await page.evaluate(() => ({ width: innerWidth, documentWidth: document.documentElement.scrollWidth, bodyWidth: document.body.scrollWidth }));
    assert.ok(layout.documentWidth <= layout.width + 1, 'no page-level horizontal overflow');
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({ path: join(output, 'explorer-phone-input.png'), fullPage: false });
    await page.$eval('#conversion-result', node => node.scrollIntoView({ block: 'start' }));
    await page.screenshot({ path: join(output, 'explorer-phone-result.png'), fullPage: false });
    return { state, layout };
  });
  await page.setViewport({ width: 1280, height: 900, deviceScaleFactor: 1, isMobile: false, hasTouch: false });
  await check('native downloaded lesson preview, cancellation, first answers, retries and saved notes', async () => {
    run.learner = await receiveLearner(page, {
      source, courseFile: courseDownload.path, course, blindSolutions, output, download,
    });
    return {
      nativePreview: true,
      cancellationPreservedLesson: run.learner.cancelPreservedExisting,
      firstAnswers: run.learner.firstAnswers.length,
      firstCorrect: run.learner.firstAnswers.filter(item => item.selected === item.correct).length,
      practiceAnswers: run.learner.practiceAnswers.length,
      firstStatePreservedAfterPractice: true,
      actualNotes: run.learner.notes,
    };
  });
  await check('offline execution and runtime error boundary', async () => {
    assert.deepEqual(run.blockedNetwork, [], 'no active HTTP/HTTPS dependency attempted by either direct-open page');
    assert.deepEqual(run.pageErrors, [], 'no unhandled runtime errors');
    return { blockedHTTPRequests: 0, pageErrors: 0, requestFailures: run.requestFailures, consoleErrors: run.consoleErrors };
  });
  run.passed = true;
} catch (error) {
  run.passed = false;
  run.error = String(error.stack || error);
  if (page) {
    try {
      run.failureURL = page.url();
      await page.screenshot({ path: join(output, 'failure.png'), fullPage: false });
    } catch (captureError) { run.failureCaptureError = String(captureError); }
  }
} finally {
  try { run.sourceAfter = await verifyInputs(); }
  catch (error) { run.passed = false; run.sourceAfterError = String(error.stack || error); }
  if (browser) await browser.close();
  await fs.rm(profile, { recursive: true, force: true });
  run.finishedAt = new Date().toISOString();
  run.checkCount = run.checks.length;
  run.passedChecks = run.checks.filter(item => item.passed).length;
  await fs.writeFile(join(output, 'browser-receiving.json'), JSON.stringify(run, null, 2) + '\n');
  console.log(JSON.stringify({ passed: run.passed, checkCount: run.checkCount, passedChecks: run.passedChecks, downloads: run.downloads.length, output, error: run.error || null }));
  process.exitCode = run.passed ? 0 : 1;
}
