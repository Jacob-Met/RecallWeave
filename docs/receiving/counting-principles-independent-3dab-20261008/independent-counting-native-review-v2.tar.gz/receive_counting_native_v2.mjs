import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';

const root = dirname(fileURLToPath(import.meta.url));
const hash = (bytes, algorithm = 'sha256') => createHash(algorithm).update(bytes).digest('hex');
function pin(path) {
  const bytes = readFileSync(join(root, path));
  return { path, mode: '100644', bytes: bytes.length, sha256: hash(bytes), gitBlob: hash(Buffer.concat([Buffer.from('blob ' + bytes.length + '\0'), bytes]), 'sha1') };
}
const paths = ['source/counting-principles.mjs', 'receive_counting_native_v2.mjs', 'PAGE-FIELD-CLARIFICATION.json', 'SOURCE_CUSTODY.json', 'blind-counting-oracle-v1.tar.gz', 'blind-oracle-v1/MANIFEST.json', 'blind-oracle-v1/blind-oracles.json', 'source/browser-source-v1-pins.json'];
const before = paths.map(pin);
assert.equal(before[0].bytes, 8160);
assert.equal(before[0].sha256, '7997430fe73448c67f7ee1bb58c76534606d2499c1cec2e44234039eb9e4f55b');
assert.equal(before[0].gitBlob, '08d9fc62931f80f3b14551018381db9da800d23f');
assert.equal(before[4].sha256, 'df0e6e43fb73d6ac723d99196cc5e0615ef89a16f2a51ea96dda290914b4e2b7');
assert.equal(before[5].sha256, 'f76b7443bb033b7bea4af302cb88b757fa0eee23757f30543e179b38001ed630');
assert.equal(before[6].sha256, 'cf5002ce1ee03c21901cde19c869256b255367e12d10410cae8da456c3a182d8');
assert.equal(before[7].sha256, '259201272faad03d8ad316848ad7c95cb092f5963b3263f6f40d994c08474a15');
const oracleManifest = JSON.parse(readFileSync(join(root, 'blind-oracle-v1/MANIFEST.json')));
for (const expected of oracleManifest.files) {
  const actual = pin('blind-oracle-v1/' + expected.path);
  assert.deepEqual({ ...actual, path: expected.path }, expected);
}
const oracle = JSON.parse(readFileSync(join(root, 'blind-oracle-v1/blind-oracles.json')));
const contract = JSON.parse(readFileSync(join(root, 'blind-oracle-v1/CONTRACT.json')));
const clarification = JSON.parse(readFileSync(join(root, 'PAGE-FIELD-CLARIFICATION.json')));
assert.equal(clarification.authorConfirmed, true);
assert.equal(clarification.mapping, 'String(argumentPageIndex + 1n)');
assert.equal(oracle.cases.length, 252);
const caseKey = value => [value.n, value.k, value.model].join(':');
const totals = new Map(oracle.cases.map(test => [caseKey(test.input), test.count]));
const startedUTC = new Date().toISOString();
const start = performance.now();
const core = await import(pathToFileURL(join(root, 'source/counting-principles.mjs')).href);
assert.equal(core.PAGE_SIZE, 24);
assert.deepEqual(core.MODELS.map(model => model.id), contract.models);
const counters = { cases: 0, countCases: 0, selectedPages: 0, selectedPageRows: 0, selectedOutcomes: 0, defaultPages: 0, rangeRefusals: 0, comparisonTotals: 0, impossibleCases: 0, zeroLengthCases: 0 };
const checks = { passed: 0, failed: 0 };
const failures = [];
const observations = [];
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  return value;
}
const digest = value => hash(Buffer.from(JSON.stringify(canonical(value))));
function check(name, context, action) {
  try { action(); checks.passed++; }
  catch (error) { checks.failed++; failures.push({ name, context, error: { name: error.name, message: error.message } }); }
}
const argument = spec => spec.kind === 'bigint' ? BigInt(spec.value) : spec.value;
function rowProjection(row) {
  assert.ok(row && typeof row === 'object' && !Array.isArray(row));
  assert.equal(typeof row.ordinal, 'string');
  assert.match(row.ordinal, /^[1-9][0-9]*$/);
  assert.ok(Array.isArray(row.labels) && row.labels.every(value => typeof value === 'string'));
  assert.ok(Array.isArray(row.typeCounts) && row.typeCounts.every(value => Number.isInteger(value) && value >= 0));
  assert.equal(typeof row.orderedRepresentations, 'string');
  assert.match(row.orderedRepresentations, /^[1-9][0-9]*$/);
  return { ordinal: row.ordinal, labels: [...row.labels], typeCounts: [...row.typeCounts], orderedRepresentations: row.orderedRepresentations };
}
function pageProjection(page) {
  for (const key of ['total', 'page', 'pageCount']) assert.equal(typeof page[key], 'string');
  assert.ok(page.firstOrdinal === null || typeof page.firstOrdinal === 'string');
  assert.ok(page.lastOrdinal === null || typeof page.lastOrdinal === 'string');
  assert.ok(Array.isArray(page.rows));
  return { total: page.total, page: page.page, pageCount: page.pageCount, firstOrdinal: page.firstOrdinal, lastOrdinal: page.lastOrdinal, rows: page.rows.map(rowProjection) };
}
for (const test of oracle.cases) {
  const input = Object.freeze({ ...test.input });
  const record = { input, count: null, pages: [], outcomeDigest: null, outcomeRefusals: 0, pageRefusals: 0 };
  const failuresBefore = checks.failed;
  check('exact BigInt count', input, () => {
    const actual = core.countOutcomes(input);
    assert.equal(typeof actual, 'bigint');
    assert.equal(actual, BigInt(test.count));
    record.count = actual.toString();
    counters.countCases++;
  });
  const outcomes = [];
  for (const expected of test.outcomes) {
    check('exact indexed row', { ...input, index: expected.argument.value }, () => {
      const actual = rowProjection(core.outcomeAt(input, argument(expected.argument)));
      assert.deepEqual(actual, expected.expectedRow);
      outcomes.push(actual);
      counters.selectedOutcomes++;
    });
  }
  record.outcomeDigest = digest(outcomes);
  for (const fixture of test.pages) {
    check('exact selected page and comparison totals', { ...input, pageIndex: fixture.argument.value }, () => {
      const actual = core.countingPage(input, argument(fixture.argument));
      const projection = pageProjection(actual);
      const expected = { ...fixture.expected, page: (BigInt(fixture.argument.value) + 1n).toString() };
      assert.deepEqual(projection, expected);
      assert.equal(actual.pageSize, 24);
      assert.deepEqual(actual.availableLabels, [...'ABCDEFGH'.slice(0, input.n)]);
      assert.equal(actual.emptySelection, input.k === 0);
      assert.equal(actual.impossible, test.count === '0');
      assert.equal(actual.ordered, input.model.startsWith('ordered-'));
      assert.equal(actual.reuse, input.model.endsWith('-reuse'));
      assert.deepEqual(actual.input, input);
      assert.deepEqual(actual.comparison.map(value => ({ id: value.id, total: value.total })), contract.models.map(model => ({ id: model, total: totals.get(caseKey({ n: input.n, k: input.k, model })) })));
      record.pages.push({
        argumentPageIndex: fixture.argument.value,
        frozenOraclePageIndex: fixture.expected.page,
        returnedDisplayPage: actual.page,
        total: actual.total, pageCount: actual.pageCount,
        firstOrdinal: actual.firstOrdinal, lastOrdinal: actual.lastOrdinal, rows: actual.rows.length,
        expectedProjectionSha256: digest(expected), actualProjectionSha256: digest(projection)
      });
      counters.selectedPages++;
      counters.selectedPageRows += actual.rows.length;
      counters.comparisonTotals += 4;
    });
  }
  check('default page equals explicit 0n', input, () => {
    assert.deepEqual(core.countingPage(input), core.countingPage(input, 0n));
    counters.defaultPages++;
  });
  for (const spec of test.invalidOutcomeArguments) {
    check('outcome index RangeError', { ...input, argument: spec }, () => {
      assert.throws(() => core.outcomeAt(input, argument(spec)), RangeError);
      counters.rangeRefusals++; record.outcomeRefusals++;
    });
  }
  for (const spec of test.invalidPageArguments) {
    check('page index RangeError', { ...input, argument: spec }, () => {
      assert.throws(() => core.countingPage(input, argument(spec)), RangeError);
      counters.rangeRefusals++; record.pageRefusals++;
    });
  }
  counters.cases++;
  counters.impossibleCases += test.count === '0' ? 1 : 0;
  counters.zeroLengthCases += input.k === 0 ? 1 : 0;
  record.passed = checks.failed === failuresBefore;
  observations.push(record);
}
check('complete frozen coverage', {}, () => {
  assert.deepEqual(counters, { cases: 252, countCases: 252, selectedPages: 391, selectedPageRows: 4986, selectedOutcomes: 962, defaultPages: 252, rangeRefusals: 4032, comparisonTotals: 1564, impossibleCases: 54, zeroLengthCases: 36 });
  assert.equal(counters.selectedPages, oracle.summary.selectedPages);
  assert.equal(counters.selectedPageRows, oracle.summary.selectedPageRows);
  assert.equal(counters.selectedOutcomes, oracle.summary.selectedOutcomeChecks);
  assert.equal(counters.rangeRefusals, oracle.summary.expectedRangeRefusals);
});
const after = paths.map(pin);
assert.deepEqual(after, before);
const report = {
  format: 'independent-counting-native-receiving-v2',
  status: failures.length ? 'failed' : 'passed',
  startedUTC, finishedUTC: new Date().toISOString(), elapsedMilliseconds: performance.now() - start,
  runtime: { node: process.version, v8: process.versions.v8, platform: process.platform, arch: process.arch, executable: process.execPath },
  sourcePinsBefore: before, sourcePinsAfter: after, sourcePinsUnchanged: true,
  blindOracleRegenerated: false,
  originalRunReconstructed: false,
  subject: 'New file-backed receiving run after volatile custody loss; distinct from the observed original Node24 run.',
  pageFieldClarification: clarification,
  checks, counters, failures, observations,
  limitations: ['Pure counting-core mathematics and API only; browser, course content, downloads and learner integration are separate reviewer scopes.', 'The exact original blind oracle is unchanged. Only the author-confirmed one-based returned page display is mapped.']
};
console.log(JSON.stringify(report));
process.exitCode = failures.length ? 1 : 0;
