import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { chromium } from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const dir=process.argv[2], input=JSON.parse(fs.readFileSync(path.join(dir,'input.json'),'utf8'));
const deck=JSON.parse(fs.readFileSync(path.join(dir,'critical-path-timing.json'),'utf8'));
const byPrompt=new Map(deck.items.map(x=>[x.prompt,x]));
const answers=new Map(input.solutions.map(x=>[x.id,x.answerIndex]));
const missed=new Set(['ct-early-1','ct-slack-4','ct-critical-3','ct-change-3']);
const sourcePaths=['demo.html','dependency-timing.html','critical-path-timing.json','receive-browser.mjs','input.json'];
function pin(buffer){return {bytes:buffer.length,sha256:crypto.createHash('sha256').update(buffer).digest('hex'),gitBlob:crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+buffer.length),Buffer.from([0]),buffer])).digest('hex')}}
const sourcePins=()=>Object.fromEntries(sourcePaths.map(p=>[p,pin(fs.readFileSync(path.join(dir,p)))]));
const receipt={schema:'critical-path-course-independent-browser/1',startedAt:new Date().toISOString(),node:process.version,sourceBefore:sourcePins(),groups:[],requests:[],browserErrors:[],notes:[],lesson:[],practice:[],snapshots:[],passed:false};
const rawDir=path.join(dir,'results');fs.mkdirSync(rawDir);
const check=(name,detail={})=>receipt.groups.push({name,passed:true,...detail});
const assertEq=(a,b,message)=>assert.deepEqual(a,b,message);
let browser;
const reflections={
 'ct-slack-4':'The first wait delays First to 3–4.\nThe separate second wait puts Second at 7–8, so Join finishes at 9.',
 'ct-critical-3':'Start and Done are critical, but their shortcut is not tight: 0 is not 2.',
 'ct-change-3':'X and Y form the cycle. Z is downstream; Free is independently ready.'
};
const application='I will use this model to separate parallel work from shared margin.\nStaffing and calendar limits need separate analysis.';
function expectedNotes(actual, rows, mastery, retries) {
 const stamp=actual.match(/^Saved: (.+)$/m)?.[1];assert.ok(stamp);assert.equal(new Date(stamp).toISOString(),stamp);
 const lines=['RecallWeave — study notes',deck.title,'Saved: '+stamp,'','FIRST SESSION',
 '12 of 16 connections correct on the first try.','This count describes this session; it is not a measure of your ability.','',
 'ESTIMATED MASTERY — MODEL STATE, NOT A GRADE','These estimates come from the demo’s learning model. They are not a validated assessment.',
 'Practice does not change the first-session estimates.',...deck.concepts.map(c=>c+': '+mastery[c]),'','PRACTICE'];
 if(retries===null)lines.push('Not started. 4 missed connections are available for practice.');
 else lines.push((retries.length===4?'Complete':'Paused')+': '+retries.length+' of 4 practice answers recorded; '+retries.filter(r=>r.choice===answers.get(r.id)).length+' correct on retry.');
 lines.push('Practice follows the explanations and is recorded separately from the first answers.','','REVIEW THE CONNECTIONS');
 rows.forEach((row,i)=>{
  const x=deck.items.find(x=>x.id===row.id),correct=answers.get(x.id),retry=retries?.find(r=>r.id===x.id);
  lines.push('',(i+1)+'. '+x.prompt,'Concept: '+x.concept,'Your first answer: '+x.options[row.choice],'First try: '+(row.choice===correct?'correct':'needs review'),
   'Correct answer: '+x.options[correct],'Explanation: '+x.explanation,'Apply the idea: '+x.transfer,'Your explanation — reflection, not scored:');
  lines.push(...(reflections[x.id]?reflections[x.id].split('\n').map(l=>'  > '+l):['  Not written.']));
  if(retry)lines.push('Practice answer: '+x.options[retry.choice],'Practice result: '+(retry.choice===correct?'correct on retry':'keep reviewing'));
  else if(row.choice!==correct)lines.push('Practice answer: not recorded.');
 });
 lines.push('','YOUR APPLICATION REFLECTION — NOT SCORED','Prompt: Choose one connection from this deck and explain how it relates to another idea in your own words.',
  ...application.split('\n').map(l=>'  > '+l),'','DECK ATTRIBUTION',deck.attribution,deck.license,'',
  'Saved from this browser session. The download does not upload the session or restore it after a refresh.');
 return lines.join('\n')+'\n';
}
try{
 assert.equal(receipt.sourceBefore['demo.html'].gitBlob,'ef7bc3e27e7f161d917ced6a457fad8822802f3f');
 assert.equal(receipt.sourceBefore['dependency-timing.html'].gitBlob,'a955954c7d7d900612ee8111cfd29c39febc1723');
 assert.equal(receipt.sourceBefore['critical-path-timing.json'].gitBlob,'49a84feea08ec76de711557e172ccbc6c5c744e9');
 browser=await chromium.launch({executablePath:'/workspace/scratch/3e50c5ad22c5/production/browser/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],env:{...process.env,TMPDIR:dir}});
 const context=await browser.newContext({viewport:{width:375,height:812},acceptDownloads:true});
 await context.addInitScript(()=>{window.__receiverStorageWrites=[];const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){window.__receiverStorageWrites.push({key:String(k)});return original.call(this,k,v);};});
 context.on('request',r=>receipt.requests.push({method:r.method(),url:r.url()}));
 context.on('page',p=>{p.on('pageerror',e=>receipt.browserErrors.push({type:'pageerror',message:String(e)}));p.on('console',m=>{if(m.type()==='error')receipt.browserErrors.push({type:'console',message:m.text()});});});
 const page=await context.newPage();await page.goto(pathToFileURL(path.join(dir,'demo.html')).href);
 const key=async(selector)=>{const el=page.locator(selector);await el.focus();assert.equal(await el.evaluate(el=>el===document.activeElement),true);await page.keyboard.press('Enter');};
 const initialSession=await page.locator('#session-content').innerHTML();
 await page.locator('#deck-file').setInputFiles(path.join(dir,'critical-path-timing.json'));
 await page.locator('#start-deck').waitFor({state:'visible'});
 assert.equal(await page.locator('#session-content').innerHTML(),initialSession);
 assert.equal(await page.locator('#deck-preview h3').textContent(),deck.title);
 assert.match(await page.locator('.deck-preview-count').textContent(),/16 questions.*4 concepts/);
 const previews=await page.locator('#deck-preview li strong').allTextContents();assertEq(previews,deck.items.map(x=>x.prompt));
 const meta=await page.locator('#deck-preview li p').allTextContents();assert.equal(meta.length,16);meta.forEach((t,i)=>{assert.ok(t.includes(deck.items[i].concept));for(const p of deck.items[i].prerequisites)assert.ok(t.includes(p));});
 await key('#start-deck');
 check('Current real file import, complete preview, unchanged prior lesson until keyboard Start',{previewCount:previews.length});
 for(let n=0;n<16;n++){
  const prompt=await page.locator('#session-content .question-card h2').textContent(), item=byPrompt.get(prompt);assert.ok(item,'Known literal prompt');assert.ok(!receipt.lesson.some(x=>x.id===item.id));
  const options=await page.locator('[data-choice]').evaluateAll(es=>es.map(e=>({index:Number(e.dataset.choice),text:[...e.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>n.textContent).join('')}))).then(es=>es.sort((a,b)=>a.index-b.index));assertEq(options.map(x=>x.text),item.options);
  const correct=answers.get(item.id),choice=missed.has(item.id)?(correct+1)%4:correct;
  await key('[data-choice="'+choice+'"]');
  const feedback=await page.locator('#feedback-slot .feedback').textContent();
  assert.ok(feedback.includes(item.explanation));assert.ok(feedback.includes(item.transfer));assert.ok(feedback.includes('Correct answer: '+item.options[correct]));assert.ok(feedback.includes('Your answer: '+item.options[choice]));
  assert.equal(await page.locator('[data-choice]:disabled').count(),4);
  receipt.lesson.push({id:item.id,choice,correct:choice===correct,prompt,optionIndices:options.map(x=>x.index),explanationVerified:true,transferVerified:true});
  await key('#next-button');
 }
 assert.match(await page.locator('#first-try-summary').textContent(),/12 of 16/);
 assert.equal(await page.locator('.review-item').count(),16);
 const readReview=async()=>page.locator('.review-item').evaluateAll(es=>es.map(e=>({prompt:e.querySelector('.review-prompt').textContent,answers:[...e.querySelectorAll('.review-answers dd')].map(d=>d.textContent),explanation:e.querySelector('.review-body > p').textContent,status:e.querySelector('.review-status').textContent})));
 const firstReview=await readReview();
 firstReview.forEach((r,i)=>{const x=deck.items.find(x=>x.id===receipt.lesson[i].id);assert.equal(r.prompt,x.prompt);assertEq(r.answers,[x.options[receipt.lesson[i].choice],x.options[answers.get(x.id)]]);assert.equal(r.explanation,x.explanation)});
 const mastery=Object.fromEntries(await page.locator('.mastery-row').evaluateAll(es=>es.map(e=>[e.querySelector('span').textContent,e.querySelector('output').textContent])));
 const originalMasteryHtml=await page.locator('.mastery-box').innerHTML();
 for(const [id,value] of Object.entries(reflections)){const textarea=page.locator('[data-reflection-item="'+id+'"]');await textarea.evaluate(el=>el.closest('details').open=true);await textarea.fill(value);}
 await page.locator('#application-reflection').fill(application);
 check('Sixteen distinct first answers and exact authored feedback; four independent misses',{correct:12,misses:[...missed],order:receipt.lesson.map(x=>x.id),mastery});
 async function saveNotes(label,retries){
  const pending=page.waitForEvent('download');await key('#save-notes-button');const download=await pending;
  assert.match(download.suggestedFilename(),/^recallweave-study-notes-\d{4}-\d{2}-\d{2}\.txt$/);
  const file=path.join(rawDir,label+'.txt');await download.saveAs(file);const actual=fs.readFileSync(file,'utf8'),expected=expectedNotes(actual,receipt.lesson,mastery,retries);
  fs.writeFileSync(path.join(rawDir,label+'-expected.txt'),expected);assert.equal(actual,expected,'Exact '+label+' study notes');
  receipt.notes.push({label,filename:download.suggestedFilename(),...pin(Buffer.from(actual)),practice:retries});
 }
 await saveNotes('before-practice',null);
 const retryOrder=receipt.lesson.filter(x=>missed.has(x.id)).map(x=>x.id);
 await key('#practice-button');
 for(let n=0;n<4;n++){
  const id=retryOrder[n],x=deck.items.find(x=>x.id===id);assert.equal(await page.locator('.practice-card h2').textContent(),x.prompt);
  const choice=id==='ct-change-3'?(answers.get(id)+1)%4:answers.get(id);await key('[data-practice-choice="'+choice+'"]');
  const feedback=await page.locator('#practice-feedback .feedback').textContent();assert.ok(feedback.includes(x.explanation));assert.ok(feedback.includes(x.transfer));
  receipt.practice.push({id,choice,correct:choice===answers.get(id)});
  if(n===0){
   await key('#back-to-review');assert.match(await page.locator('#practice-status').textContent(),/Practice paused: 1 of 4/);
   assertEq(await readReview(),firstReview);assert.equal(await page.locator('.mastery-box').innerHTML(),originalMasteryHtml);
   await saveNotes('paused-practice',receipt.practice);
   receipt.snapshots.push({name:'paused',firstReviewUnchanged:true,masteryUnchanged:true});
   await key('#practice-button');
  }else await key('#practice-next');
 }
 assert.match(await page.locator('#practice-status').textContent(),/3 of 4 correctly on retry/);assert.equal(await page.locator('#practice-button').count(),0);
 assertEq(await readReview(),firstReview);assert.equal(await page.locator('.mastery-box').innerHTML(),originalMasteryHtml);
 for(const [id,value] of Object.entries(reflections))assert.equal(await page.locator('[data-reflection-item="'+id+'"]').inputValue(),value);
 assert.equal(await page.locator('#application-reflection').inputValue(),application);
 await saveNotes('complete-practice',receipt.practice);
 check('Paused then resumed practice, with cycle retry still incorrect and original lesson/model preserved',{retryOrder,correctRetries:3,notes:receipt.notes.map(x=>({label:x.label,sha256:x.sha256})),noInventedSecondRound:true});
 await page.locator('#first-try-summary').scrollIntoViewIfNeeded();
 await page.screenshot({path:path.join(rawDir,'learner-375.png')});
 receipt.learnerStorageWrites=await page.evaluate(()=>window.__receiverStorageWrites);
 const companion=await context.newPage();await companion.goto(pathToFileURL(path.join(dir,'dependency-timing.html')).href);
 for(const id of ['C-milestone-shortcut','D-shared-slack']){
  const f=input.fixtures.find(x=>x.id===id);await companion.locator('#jobs-input').fill(f.jobs.join('\n'));await companion.locator('#edges-input').fill(f.edges.map(e=>e.join(' -> ')).join('\n'));
  for(let i=0;i<f.jobs.length;i++)await companion.locator('#duration-'+i).fill(String(f.durations[i]));
  await companion.locator('#calculate-timing').focus();await companion.keyboard.press('Enter');
  assert.equal((await companion.locator('#project-duration').textContent()).trim(),String(f.expected.duration));
  const rows=await companion.locator('#timing-rows tr').evaluateAll(es=>es.map(e=>({job:e.dataset.job,critical:e.dataset.critical,values:[...e.querySelectorAll('td[data-field]')].slice(0,6).map(td=>Number(td.textContent.replaceAll(',','')))})));
  assertEq(rows.map(x=>x.job),f.jobs);assertEq(rows.map(x=>x.values),f.expected.rows.map((r,i)=>[f.durations[i],...r]));
  const edges=await companion.locator('#critical-edges li').evaluateAll(es=>es.map(e=>[e.dataset.from,e.dataset.to]));assertEq(edges,f.expected.criticalEdges);
  if(id.startsWith('C')){
   const shortcut=companion.locator('#dependency-rows tr[data-from="Start"][data-to="Done"]');assert.match(await shortcut.textContent(),/Not a critical link/);
   assert.equal(await companion.locator('#timing-rows tr[data-job="Start"]').getAttribute('data-critical'),'true');assert.equal(await companion.locator('#timing-rows tr[data-job="Done"]').getAttribute('data-critical'),'true');
   await companion.locator('#timing-results').scrollIntoViewIfNeeded();await companion.screenshot({path:path.join(rawDir,'companion-C-375.png')});
  }
  check('Unchanged native timing companion receives '+id,{rows,criticalEdges:edges,projectDuration:f.expected.duration,extraWaitsEntered:false});
 }
 receipt.companionStorageWrites=await companion.evaluate(()=>window.__receiverStorageWrites);
 for(const p of [page,companion])assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1),true,'375px outer page width');
 assertEq(receipt.learnerStorageWrites,[]);assertEq(receipt.companionStorageWrites,[]);
 assertEq(receipt.browserErrors,[]);
 assert.equal(receipt.requests.length,2);assert.ok(receipt.requests.every(r=>r.method==='GET'&&r.url.startsWith(pathToFileURL(dir+'/').href)));
 check('375px keyboard flow, local-only reads, no persistent storage or browser errors',{fileGets:2,downloads:receipt.notes.length});
 receipt.passed=true;
}catch(error){receipt.error={message:error.message,stack:error.stack};process.exitCode=1;}
finally{
 if(browser)await browser.close();
 receipt.sourceAfter=sourcePins();
 try{assertEq(receipt.sourceAfter,receipt.sourceBefore);}catch(e){receipt.passed=false;receipt.sourceCustodyError=String(e);process.exitCode=1;}
 receipt.finishedAt=new Date().toISOString();
 fs.writeFileSync(path.join(rawDir,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({passed:receipt.passed,groups:receipt.groups.length,error:receipt.error,sourceCustody:JSON.stringify(receipt.sourceBefore)===JSON.stringify(receipt.sourceAfter)}));
}
