$ErrorActionPreference = 'Stop'
$root = 'D:/Hamon/receiving/recall-sorting-networks-root-db371a37f4c8'
$os = Get-CimInstance Win32_OperatingSystem
$c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='D:'"
$guard = [ordered]@{schema='recall253-root-native-guard-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;machine=[Environment]::MachineName;user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;boot=$os.LastBootUpTime.ToUniversalTime().ToString('o');freeC=[long]$c.FreeSpace;freeD=[long]$d.FreeSpace;freeMemory=[long]$os.FreePhysicalMemory*1024;floorC=1073741824;floorD=1073741824;floorMemory=2147483648}
$guard | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 "$root/ORIGINAL-CLOSURE-r1-GUARD.json"
if ($guard.machine -ne 'MSI' -or $guard.user -ne 'MSI\Veria' -or $guard.boot -ne '2026-10-04T04:03:32.5000000Z' -or $guard.freeC -lt $guard.floorC -or $guard.freeD -lt $guard.floorD -or $guard.freeMemory -lt $guard.floorMemory) { throw 'Identity, boot or resource guard refused' }

$all=@(Get-CimInstance Win32_Process)
$self=$PID
$chain=@()
$walk=$self
for($i=0;$i -lt 8;$i++){ $p=$all | Where-Object ProcessId -eq $walk | Select-Object -First 1; if(!$p){break};$chain+=([int]$p.ProcessId);$walk=[int]$p.ParentProcessId }
$known=@(14384,20664,25920,20744,29616,26416,13780,29624,24308,22560,14208,11904,18512,21292,7044,29452,24388)
$present=@($all | Where-Object {$_.ProcessId -in $known} | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,@{Name='CreatedUtc';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}})
$owned=@($all | Where-Object {$_.CommandLine -like "*$root*" -and $_.ProcessId -notin $chain} | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,@{Name='CreatedUtc';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}})
[ordered]@{at=[DateTime]::UtcNow.ToString('o');pid=$self;observerChain=$chain;knownPids=$known;currentlyPresentHistoricalNumbers=$present;ownedNamespace=$owned;browserReceiptClosed=$true;nativeChildExit=0;policy='Observe only. A reused number is not signaled or attributed to this run.'} | ConvertTo-Json -Depth 12 | Set-Content -Encoding UTF8 "$root/ORIGINAL-CLOSURE-r1.json"
if($owned.Count -ne 0){throw 'Owned namespace not empty'}
