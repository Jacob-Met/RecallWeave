# Independent receiving: cache replacement course and explorer

This packet accepts the exact RecallWeave cache course/explorer application at native commit cae47af5c2b200404dbcf2d698ce7465d57e8163, partial closure tree c070a05bf65cf36d0efc22b83d19c679a4430a18. The source custody has 47 files, including all original consumer inputs required by this receiving. It is not a complete canonical repository snapshot.

## Actual independent results

The exact new core passed 27,436 complete comparisons against the already frozen Python timestamp oracle, plus all 68 admission, copying, deep-freeze and golden controls. All result fields, retained steps, evictions, prefix counts and five-capacity comparisons agree after the explicitly documented two-field protocol clarification. The comparison domain was not expanded after the candidate arrived.

Three actual offline Chromium groups passed: retained prefix/navigation and real trace download; stale draft retirement/refusal/empty input; and exact course download into the unchanged original learner with preview, Cancel and explicit Start. The browser and all contexts were closed. All source bytes/modes remained unchanged. Actual reports, raw stdout/stderr, downloaded files and mobile captures are included.

Every one of the twelve course keys matches the answers frozen before the keys or implementation were read. The receiver read all explanations/transfer text and checked primary-source attribution after the independent derivation. The actual downloaded course passes the unchanged native parser; independent browser receiving answers its first question. Production's separate all-twelve browser run is not attributed to this receiver.

The artifact was independently decoded back to exact CSS, course text, validator, core, UI and original template. This source proof did not invoke the producer builder.

## Real history remains visible

The first executed core receiver expected a shape without policy.order metadata and failed. That actual log/result remains under core/original-shape. Production clarified two exact public values. The successor requires those constants and removes only those two fields from a copy before comparing the unchanged oracle. No algorithm, expected trace, input domain or product source changed to obtain acceptance.

Before any browser execution, the receiver corrected its own extra-welcome assumption after reading the actual unchanged learner callback: Start this deck immediately calls resetSession and renderQuestion. Exact-capacity Empty slot padding was also clarified. Original preparation harnesses and receipts are retained; these are not invented product failures.

## Source-only successors

Commit 393e57163bab6cd53e746ccee345dd5a4709972b adds the producer's test-only browser harness and receives the exact current README prefix plus the same append; the guide explicitly documents both order values. Application/course/artifact inputs are unchanged.

Commit 4fef132159fa1d880fb06e5c8e307e8c23932aae changes only README from that successor. Its native partial tree is 832968a1e27864c145e58b256df0069b81889d6c. All 47 other native leaves are exact. The receiver independently compared the full 1,518-leaf canonical manifest at 3e110dfb0aded80152afea685660105fed224e74 / a61061bd6442bceaaf0d6ceb21578b9fb75f0bb5: all 36 original consumer files and all new cache path boundaries remain intact. No tests were repeated for either documentary successor.

## Packet structure and replay

Read disposition.json and source-content-review.json first. dependencies.json binds the original oracle-packet and course-answers-packet by their exact manifests; those complete immutable packets are preserved separately and deliberately not duplicated here.

source-capsule.tar.gz contains only the 47 exact qualified native files. source-capsule.json lists their hashes and modes. Extract into a new owned directory if needed. Existing learner inputs used by the browser are the same bytes in this closure. Receiving harnesses and actual invocation wrappers are retained as .source files to keep them outside automatic test discovery. The recorded wrappers use the original owned paths and output names: inspect them, then use a new owned output path for any warranted replay. Do not overwrite these receipts or rerun unchanged suites merely to regenerate evidence.

The files.json manifest excludes itself and binds every other packet member. The sealing receipt outside the packet binds its manifest. This packet does not assert a final full publication tree, hosted CI, deployment, or installed integration; the publisher receives those boundaries separately.
