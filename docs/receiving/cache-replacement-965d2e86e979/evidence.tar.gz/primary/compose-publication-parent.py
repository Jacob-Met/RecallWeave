from pathlib import Path
import hashlib,json,subprocess,shutil
root=Path('/Users/me/hamon-recall-cache-965d2e86e979');src=root/'source';ev=root/'evidence';stage=root/'receiving-stage'
git=lambda *a:subprocess.check_output(['git','-C',str(src),*a],text=True).strip()
p=json.loads((ev/'publication-parent-input.json').read_text())
assert git('rev-parse','HEAD')==p['previousNativeHead'] and not git('status','--porcelain')
helpers=(ev/'receive-baseline.py').read_text().split('def gh',1)[1].split('assert len(p["full_leaves"])',1)[0]
exec('def gh'+helpers)
assert th(p['leaves'])==p['canonicalTree']
rows={x['path']:x for x in p['leaves']}
assert not any(path in rows for path in p['newPaths'])
before={path:hashlib.sha256((src/path).read_bytes()).hexdigest() for path in git('ls-files').splitlines()}
old=json.loads((ev/'baseline-source-custody.json').read_text())
for f in old['selected_files']:
 if f['path']=='README.md':continue
 assert rows[f['path']]['sha']==f['git_blob'] and rows[f['path']]['mode']==f['mode']
 assert before[f['path']]==f['sha256']
raw=p['readme']['content'].encode()
assert gh('blob',raw)==p['readme']['sha']==rows['README.md']['sha']
(src/'README.md').write_text(p['readme']['content']+p['readmeAddition'])
git('add','README.md');git('commit','-qm','Preserve current inheritance and dependency companion README')
current=git('rev-parse','HEAD')
leaves=[]
for line in git('ls-tree','-r','HEAD').splitlines():
 meta,path=line.split('\t',1);mode,kind,blob=meta.split();data=(src/path).read_bytes()
 leaves.append({'path':path,'mode':mode,'gitBlob':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
receipt={'canonicalParent':p['canonicalMain'],'canonicalTree':p['canonicalTree'],'canonicalLeaves':len(p['leaves']),'nativeHead':current,'nativeTree':git('rev-parse','HEAD^{tree}'),'application':p['qualifiedApplication'],'previousNativeHead':p['previousNativeHead'],'changedPaths':['README.md'],'preservedNativeFiles':len(before)-1,'allOtherNativeBytesExact':all(hashlib.sha256((src/path).read_bytes()).hexdigest()==sha for path,sha in before.items() if path!='README.md'),'readmeExactParentPlusAppend':(src/'README.md').read_text()==p['readme']['content']+p['readmeAddition'],'originalConsumerFilesPreserved':36,'newPathsPreviouslyAbsent':True,'files':leaves,'productTestsReexecuted':0,'reason':'Only additive README composition; all accepted runtime and consumer bytes remain exact.'}
(ev/'publication-parent-reception.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name in ['publication-parent-input.json','publication-parent-reception.json']:
 shutil.copyfile(ev/name,stage/'primary'/name)
(stage/'native-source.bundle').rename(stage/'qualified-source.bundle')
subprocess.run(['git','-C',str(src),'bundle','create',str(stage/'native-source.bundle'),'--all'],check=True,capture_output=True)
b=(stage/'native-source.bundle').read_bytes()
print(json.dumps({'head':current,'tree':receipt['nativeTree'],'files':len(leaves),'canonicalParent':p['canonicalMain'],'canonicalLeaves':len(p['leaves']),'preserved47':receipt['allOtherNativeBytesExact'],'bundleBytes':len(b),'bundleSha256':hashlib.sha256(b).hexdigest()}))
