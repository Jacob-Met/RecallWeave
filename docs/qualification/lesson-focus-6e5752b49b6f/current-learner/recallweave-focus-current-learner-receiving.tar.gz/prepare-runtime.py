from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'source'
OLD = HERE.parent / 'recallweave-focus-publication'
plan = json.loads((HERE / 'runtime-plan.json').read_text())
expected = {row['path']: row for row in plan['files']}
queue = ['index.html', 'demo.html', 'styles.css', 'data/deck.json', 'src/app.mjs']
visited, missing, rows = set(), [], []
while queue:
    name = queue.pop(0)
    if name in visited:
        continue
    visited.add(name)
    assert name in expected, name
    path = SOURCE / name
    if not path.exists():
        older = OLD / name
        if older.exists():
            data = older.read_bytes()
            digest = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            if digest == expected[name]['sha']:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        if not path.exists():
            missing.append(expected[name])
            continue
    data = path.read_bytes()
    digest = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert digest == expected[name]['sha'], name
    rows.append({'path': name, 'bytes': len(data), 'git_blob': digest, 'sha256': hashlib.sha256(data).hexdigest()})
    if name.endswith('.mjs'):
        imports = re.findall(r'^\s*import\s+(?:[^;]*?\s+from\s+)?[\'"]([^\'"]+)[\'"]\s*;', data.decode(), flags=re.MULTILINE)
        for imported in imports:
            assert imported.startswith('.'), (name, imported)
            target = (path.parent / imported).resolve()
            queue.append(target.relative_to(SOURCE.resolve()).as_posix())
record = {'commit': plan['commit'], 'tree': plan['tree'], 'parents': plan['parents'], 'source_root': str(SOURCE),
          'files': sorted(rows, key=lambda row: row['path']), 'missing': missing,
          'scope': 'Both actual learner entry points, default data/styles, and every recursively imported module reachable from the current app entry.'}
(HERE / 'runtime-source.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'received_files': len(rows), 'missing': missing}))
