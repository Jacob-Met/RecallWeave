import os,pathlib,subprocess,json,time,signal,shutil,hashlib,datetime
R=pathlib.Path(__file__).parent;O=R/'browser-wrapper-r3';O.mkdir()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def members(group):
 out=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   s=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(s[2])==group:out.append({'pid':int(p.name),'start':s[19]})
  except (OSError,ValueError,IndexError):pass
 return out
r={'started':now(),'wrapper':os.getpid(),'guard':{'free':shutil.disk_usage(R).free,'memory':int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024},'driverSha256':sha(R/'receive-browser-r3.mjs'),'observed':[]}
def save(): (O/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save();assert r['guard']['free']>=268435456 and r['guard']['memory']>=2147483648
T=O/'tmp';T.mkdir();C=O/'cache';C.mkdir();env=dict(os.environ,TMPDIR=str(T),TMP=str(T),TEMP=str(T),XDG_CACHE_HOME=str(C),PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD='1',DEBUG='pw:browser')
with (O/'browser.log').open('wb') as log:
 p=subprocess.Popen(['/usr/bin/node',str(R/'receive-browser-r3.mjs')],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
 r['node']=p.pid;r['launched']=now();save();seen={}
 deadline=time.monotonic()+180
 while p.poll() is None and time.monotonic()<deadline:
  for m in members(p.pid):seen[m['pid']]=m
  time.sleep(.25)
 r['timedOut']=p.poll() is None
 if r['timedOut']:os.killpg(p.pid,signal.SIGTERM)
 try:r['exit']=p.wait(timeout=15)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);r['forced']=True;r['exit']=p.wait(timeout=10)
 remaining=members(p.pid)
 if remaining:
  os.killpg(p.pid,signal.SIGTERM);time.sleep(2)
  if members(p.pid):os.killpg(p.pid,signal.SIGKILL);r['forcedDescendants']=True
 r['observed']=list(seen.values());r['remaining']=members(p.pid)
 if not r['remaining']:shutil.rmtree(T);shutil.rmtree(C)
 time.sleep(2);r['profileRemoved']=not T.exists();r['cacheRemoved']=not C.exists();r['delayedRemaining']=members(p.pid)
r['finished']=now();save();print(json.dumps(r))
