import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { expected, validHistory, allCompletions, histories, allThreeJobGraphs, boundaryGraphs } from './oracle.mjs';

const modulePath=process.argv[2], outputPath=process.argv[3];
if(!modulePath) throw Error('Pass the frozen author model path.');
const api=await import(pathToFileURL(modulePath));
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const counters={graphs:0,validHistories:0,invalidHistories:0,enumerations:0,completionChoices:0,reachabilityQueries:0,admissionCases:0};
const groups=[];
let caseContext=null;
function frozen(value) {
  if(value!==null && typeof value==='object') {
    assert.equal(Object.isFrozen(value),true,'returned structure must be frozen');
    for(const child of Object.values(value)) frozen(child);
  }
}
function setEqual(actual,wanted,label) {
  assert.ok(Array.isArray(actual),label+' is an array');
  assert.equal(new Set(actual).size,actual.length,label+' has no duplicates');
  assert.deepEqual([...actual].sort(),[...wanted].sort(),label);
}
function componentsEqual(actual,wanted) {
  assert.ok(Array.isArray(actual));
  const normalize=xs=>xs.map(group=>{
    assert.ok(Array.isArray(group),'each cycle component is an array');
    assert.equal(new Set(group).size,group.length);
    return JSON.stringify([...group].sort());
  }).sort();
  assert.deepEqual(normalize(actual),normalize(wanted),'SCC cycle components');
}
function throws(fn,label) { assert.throws(fn,undefined,label); }
function historyCheck(graph,history,limits=[1,2,12]) {
  const untouched=JSON.stringify(history);
  if(!validHistory(graph,history)) {
    counters.invalidHistories++;
    for(const [name,call] of [
      ['analyze',()=>api.analyzeGraph(graph,history)],
      ['enumerate',()=>api.enumerateCompletions(graph,history,1)],
      ['complete',()=>api.completeJob(graph,history,graph.jobs[0])],
      ['undo',()=>api.undoCompletion(graph,history)],
      ['reset',()=>api.resetCompletion(graph,history)],
    ]) throws(call,name+' rejects invalid ordered history');
    assert.equal(JSON.stringify(history),untouched);
    return;
  }
  counters.validHistories++;
  const want=expected(graph,history),got=api.analyzeGraph(graph,history);
  frozen(got);
  assert.deepEqual(got.completed,history,'completed prefix is retained in order');
  setEqual(got.ready,want.ready,'ready');
  setEqual(got.cycleMembers,want.cycleMembers,'cycle members');
  setEqual(got.blockedByCycle,want.blockedByCycle,'cycle descendants excluding members');
  componentsEqual(got.cycleComponents,want.cycleComponents);
  setEqual(got.remaining,want.remaining,'remaining');
  assert.equal(got.finished,want.finished);
  assert.equal(got.rows.length,graph.jobs.length);
  assert.equal(new Set(got.rows.map(r=>r.job)).size,graph.jobs.length);
  for(const row of want.rows) {
    const actual=got.rows.find(r=>r.job===row.name);
    assert.ok(actual,'one row per exact job');
    setEqual(actual.prerequisites,row.prerequisites,'direct prerequisites');
    setEqual(actual.unmet,row.unmet,'unmet direct prerequisites');
    const status=history.includes(row.name)?'complete':
      want.ready.includes(row.name)?'ready':
      want.cycleMembers.includes(row.name)?'cycle':
      want.blockedByCycle.includes(row.name)?'blocked':'waiting';
    assert.equal(actual.status,status,'job status');
  }
  for(const job of graph.jobs) {
    counters.completionChoices++;
    if(want.ready.includes(job)) {
      const next=api.completeJob(graph,history,job);frozen(next);
      assert.deepEqual(next,history.concat(job));assert.notEqual(next,history);
    } else throws(()=>api.completeJob(graph,history,job),'non-ready completion refused');
  }
  const undo=api.undoCompletion(graph,history),reset=api.resetCompletion(graph,history);
  frozen(undo);frozen(reset);
  assert.deepEqual(undo,history.slice(0,-1));assert.deepEqual(reset,[]);
  assert.notEqual(undo,history);assert.notEqual(reset,history);
  const orders=allCompletions(graph,history);
  for(const limit of limits) {
    counters.enumerations++;
    const result=api.enumerateCompletions(graph,history,limit);frozen(result);
    assert.deepEqual(result.orders,orders.slice(0,limit),'exact deterministic full orders');
    assert.equal(result.truncated,orders.length>limit,'true only after an extra full completion');
    assert.equal(result.limit,limit);
  }
  assert.equal(JSON.stringify(history),untouched);
  assert.equal(Object.isFrozen(history),false,'caller history was not frozen or changed');
}
function graphCheck(input,historyInputs) {
  counters.graphs++;
  const untouched=JSON.stringify(input),graph=api.validateGraph(input);frozen(graph);
  assert.deepEqual(graph.jobs,input.jobs);
  assert.deepEqual(graph.edges,input.edges);
  assert.notEqual(graph,input);
  const want=expected(graph);
  for(const job of graph.jobs) {
    counters.reachabilityQueries++;
    const actual=api.reachableFrom(graph,job);frozen(actual);
    setEqual(actual,want.reachability[job],'positive-length reachability');
  }
  throws(()=>api.reachableFrom(graph,'not a declared job'),'unknown reachability origin refused');
  throws(()=>api.completeJob(graph,[],'not a declared job'),'unknown completion refused');
  for(const history of historyInputs) {
    caseContext={graph:input,history};
    historyCheck(graph,history);
  }
  assert.equal(JSON.stringify(input),untouched);
  assert.equal(Object.isFrozen(input),false,'caller graph was not frozen');
  assert.equal(Object.isFrozen(input.jobs),false,'caller job list was not frozen');
  assert.equal(Object.isFrozen(input.edges),false,'caller edge list was not frozen');
  for(const edge of input.edges) assert.equal(Object.isFrozen(edge),false,'caller edge tuple was not frozen');
  return graph;
}
function group(name,fn) {
  const start=performance.now();
  try { fn();groups.push({name,passed:true,milliseconds:Math.round(performance.now()-start)}); }
  catch(error) { groups.push({name,passed:false,milliseconds:Math.round(performance.now()-start),case:caseContext,error:{name:error.name,message:error.message,stack:error.stack}}); }
}
group('Every three-job directed graph and every ordered prefix',()=>{
  for(const graph of allThreeJobGraphs()) graphCheck(graph,[...histories(graph.jobs)]);
});
group('Larger SCC, cap, prefix, literal-name and dependency boundaries',()=>{
  for(const {name,graph} of boundaryGraphs) {
    const all=allCompletions(graph),valid=[[]];
    if(all.length) {
      valid.push(all[0].slice(0,1),all[0].slice(0,-1),all[0].slice());
      if(all.length>1) valid.push(all.at(-1).slice(0,2));
    } else if(expected(graph).ready.length) valid.push([expected(graph).ready[0]]);
    valid.push([graph.jobs[0],graph.jobs[0]],['unknown']);
    caseContext={name};
    graphCheck(graph,valid);
  }
  const twelve={jobs:['D','C','B','A'],edges:[['A','B']]};
  assert.equal(allCompletions(twelve).length,12);
  graphCheck(twelve,[[]]);
  const fourIndependent=api.validateGraph({jobs:['D','C','B','A'],edges:[]});
  const all24=api.enumerateCompletions(fourIndependent,[],24);
  assert.deepEqual(all24.orders,allCompletions(fourIndependent));
  assert.equal(all24.truncated,false);assert.equal(all24.limit,24);
  const fiveIndependent=api.validateGraph({jobs:['E','D','C','B','A'],edges:[]});
  const beyond24=api.enumerateCompletions(fiveIndependent,[],24);
  assert.deepEqual(beyond24.orders,allCompletions(fiveIndependent).slice(0,24));
  assert.equal(beyond24.truncated,true);assert.equal(beyond24.limit,24);
  const denseJobs=['H','G','F','E','D','C','B','A'];
  graphCheck({jobs:denseJobs,edges:denseJobs.flatMap(a=>denseJobs.map(b=>[a,b]))},[[]]);
  const g=api.validateGraph({jobs:['A','B'],edges:[]});
  throws(()=>api.completeJob(g,['A','A'],'B'),'duplicate history refused even for an otherwise-ready different job');
  for(const bad of [0,-1,25,1.5,NaN,Infinity,'2',null]) {
    caseContext={badLimit:String(bad)};
    throws(()=>api.enumerateCompletions(g,[],bad),'limit admission');
  }
  for(const bad of [null,'A',{},[1],['A','A'],['missing']]) {
    caseContext={invalidHistory:bad};
    historyCheck(g,bad);
  }
});
group('Declared text and graph admission; frozen literal copies',()=>{
  function accepts(jobs,edges,wanted) {
    counters.admissionCases++;caseContext={jobs,edges};
    const got=api.parseGraph(jobs,edges);frozen(got);
    assert.deepEqual(got,wanted);
  }
  function refuses(jobs,edges) {
    counters.admissionCases++;caseContext={jobs,edges};
    throws(()=>api.parseGraph(jobs,edges),'invalid graph text refused');
  }
  accepts('  A \n\n a \n__proto__\nconstructor\n',' A -> a \n__proto__ → constructor\n',
    {jobs:['A','a','__proto__','constructor'],edges:[['A','a'],['__proto__','constructor']]});
  accepts('Self','Self → Self',{jobs:['Self'],edges:[['Self','Self']]});
  accepts('🛰'.repeat(32),'',{jobs:['🛰'.repeat(32)],edges:[]});
  accepts('<b>Plan</b>\nShip','<b>Plan</b> -> Ship',{jobs:['<b>Plan</b>','Ship'],edges:[['<b>Plan</b>','Ship']]});
  accepts('A'+' '.repeat(7999),'',{jobs:['A'],edges:[]});
  for(const [jobs,edges] of [
    ['', ''],['A\n A',''],['A\nB','A -> B\nA → B'],['A','A -> Missing'],
    ['A\nB','A -> B -> A'],['A\nB','A - B'],['->',''],['A→B',''],
    ['A\0B',''],['A\tB',''],['A\u007fB',''],['A\u0085B',''],['A\u2028B',''],['\ud800',''],
    ['🛰'.repeat(33),''],['A\nB\nC\nD\nE\nF\nG\nH\nI',''],['A'+' '.repeat(8192),''],
  ]) refuses(jobs,edges);
  for(const bad of [null,[],{}, {jobs:[],edges:[]},{jobs:['A'],edges:[['A','B']]},
    {jobs:['A','A'],edges:[]},{jobs:['A'],edges:[['A','A'],['A','A']]},
    {jobs:['A'],edges:[['A']]},{jobs:['A'],edges:'A -> A'}]) {
    counters.admissionCases++;caseContext={invalidGraph:bad};
    throws(()=>api.validateGraph(bad),'invalid graph object refused');
  }
});
const modelBytes=fs.readFileSync(modulePath);
const report={schema:'recallweave.graph-independent-model-receiving.v1',
  finished_at:new Date().toISOString(),passed:groups.every(g=>g.passed),model:{path:modulePath,sha256:digest(modelBytes)},
  oracle:{path:new URL('./oracle.mjs',import.meta.url).pathname,sha256:digest(fs.readFileSync(new URL('./oracle.mjs',import.meta.url)))},
  harness:{path:process.argv[1],sha256:digest(fs.readFileSync(process.argv[1]))},
  counters,groups,method:'Brute permutations and Boolean positive-path closure, authored before reading the product model; no shared algorithm implementation.',product_source_edits:false};
const text=JSON.stringify(report,null,2)+'\n';
if(outputPath)fs.writeFileSync(outputPath,text);
process.stdout.write(text);
process.exitCode=report.passed?0:1;
