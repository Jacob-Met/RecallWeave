import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {fileURLToPath,pathToFileURL} from 'node:url';
import {chromium} from '/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8/source/node_modules/playwright/index.mjs';
const R=path.dirname(fileURLToPath(import.meta.url)),O=path.join(R,'browser-r3'),sha=b=>createHash('sha256').update(b).digest('hex');
assert.equal(fs.existsSync(O),false);fs.mkdirSync(O);fs.mkdirSync(path.join(O,'downloads'));
const manifest=JSON.parse(fs.readFileSync(path.join(R,'candidate-runtime-manifest-r1.json'))).files;
const oracleBytes=fs.readFileSync(path.join(R,'finite-walk-oracle-r1.json'));assert.equal(sha(oracleBytes),'a931f2fad9a349ce18a8a1a7d5278588442569768095bc47c649b3a72380aef3');
const fixtures=JSON.parse(oracleBytes).fixtures,blind=JSON.parse(fs.readFileSync(path.join(R,'blind-course-answers-r1.json'))).answers,prompts=JSON.parse(fs.readFileSync(path.join(R,'blind-course-prompts-r1.json'))).items;
const errors=[],remote=[],downloads=[],checks=[],images=[];let browser;
const receipt={started:new Date().toISOString(),pid:process.pid,checks,downloads,images,errors,remote,packageSha256:'a928a859470c668f8e313d839f11d0f31e781aaa4367a03441d6bcb70eb70426'};
const save=()=>fs.writeFileSync(path.join(O,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
const mark=(name,detail={})=>{checks.push({name,at:new Date().toISOString(),...detail});save();console.log(name);};
const sources=()=>manifest.filter(e=>sha(fs.readFileSync(path.join(R,'source',e.path)))!==e.sha256).map(e=>e.path);
const frac=f=>f.denominator==='1'?f.numerator:f.numerator+'/'+f.denominator;
const rowTexts=async(p,s)=>p.locator(s+' tbody tr').evaluateAll(rows=>rows.map(r=>[...r.querySelectorAll('th,td')].map(c=>c.textContent.trim())));
async function snap(page,name,locator){const file=path.join(O,name+'.png');if(locator)await locator.screenshot({path:file});else await page.screenshot({path:file});const b=fs.readFileSync(file);images.push({path:name+'.png',bytes:b.length,sha256:sha(b)});save();}
async function download(page,selector,name,expected){const ev=page.waitForEvent('download',{timeout:15000});await page.locator(selector).click();const d=await ev;const file=path.join(O,'downloads',name);await d.saveAs(file);assert.equal(await d.failure(),null);const b=fs.readFileSync(file);if(expected)assert.deepEqual(b,expected);downloads.push({name,suggested:d.suggestedFilename(),bytes:b.length,sha256:sha(b)});save();return file;}
async function fields(page,input){for(const [key,value] of Object.entries(input))await page.locator('[name="'+key+'"]').fill(String(value));}
async function frame(page,analysis,index){const f=analysis.frames[index];assert.equal((await page.locator('#step-label').textContent()).trim(),'Step '+index+' of '+analysis.input.horizon);
const actual=await rowTexts(page,'#distribution-table');assert.deepEqual(actual.map(r=>r.slice(0,2)),f.distribution.map((v,i)=>[String(i),frac(v)]));
assert.equal((await page.locator('#first-left').textContent()).trim(),frac(f.firstArrival.left));assert.equal((await page.locator('#first-right').textContent()).trim(),frac(f.firstArrival.right));assert.equal((await page.locator('#survival').textContent()).trim(),frac(f.survival));
assert.deepEqual(await rowTexts(page,'#contribution-table'),f.contributions.map(e=>[e.from+' → '+e.to,frac(e.probability),frac(e.mass)]));
assert.deepEqual(await rowTexts(page,'#arrival-table'),analysis.frames.map(v=>[String(v.step),frac(v.firstArrival.left),frac(v.firstArrival.right),frac(v.absorbed.left),frac(v.absorbed.right),frac(v.survival)]));
assert.deepEqual(await rowTexts(page,'#eventual-table'),analysis.eventual.map(v=>[String(v.start),frac(v.left),frac(v.right),frac(v.expectedSteps)]));}
function watch(page){page.on('pageerror',e=>{errors.push(String(e));save();});page.on('request',r=>{if(/^https?:/.test(r.url())){remote.push(r.url());save();}});}
try{
assert.deepEqual(sources(),[]);save();
browser=await chromium.launch({executablePath:'/snap/bin/chromium',headless:true,chromiumSandbox:true,args:['--disable-gpu'],timeout:45000});
const context=await browser.newContext({viewport:{width:1280,height:900},acceptDownloads:true,offline:true});const learner=await context.newPage();watch(learner);learner.setDefaultTimeout(12000);
const course=path.join(R,'browser-r1/downloads/course-before.json');assert.equal(sha(fs.readFileSync(course)),'7f71684445984c744c9dd81f8538be2ea2e9f09c97435f658a4353a20a6a2e66');
await learner.goto(pathToFileURL(path.join(R,'portable/demo.html')).href);await learner.locator('#start-button').click();const originalPrompt=await learner.locator('.question-card h2').textContent(),originalProgress=await learner.locator('[role="progressbar"]').getAttribute('aria-valuenow');
await learner.locator('#deck-file').setInputFiles(course);await learner.locator('#start-deck').waitFor();assert.match(await learner.locator('.deck-preview-count').textContent(),/12 questions.*6 concepts/);assert.equal(await learner.locator('.question-card h2').textContent(),originalPrompt);assert.equal(await learner.locator('[role="progressbar"]').getAttribute('aria-valuenow'),originalProgress);
await learner.locator('#cancel-deck').click();assert.equal(await learner.locator('.question-card h2').textContent(),originalPrompt);await learner.locator('#deck-file').setInputFiles(course);await learner.locator('#start-deck').click();await learner.locator('.question-card h2').waitFor();
const observed=[];receipt.observedAnswers=observed;save();
for(let i=0;i<12;i++){
 const prompt=await learner.locator('.question-card h2').textContent();const item=prompts.find(x=>x.prompt===prompt);assert.ok(item,'known independently frozen prompt');assert.ok(!observed.some(x=>x.id===item.id));const answer=blind.find(x=>x.id===item.id).answer;const choice=item.id==='conditional-step'?(answer+1)%item.options.length:answer;
 await learner.locator('[data-choice="'+choice+'"]').click();assert.match(await learner.locator('#feedback-slot').textContent(),new RegExp(item.id==='conditional-step'?'Here’s the correction':'That connection holds'));
 observed.push({id:item.id,choice,independentAnswer:answer});save();await learner.locator('#next-button').click();
}
assert.equal(await learner.locator('.review-item').count(),12);assert.match(await learner.locator('#first-try-summary').textContent(),/11 of 12/);const firstSummary=await learner.locator('#first-try-summary').textContent(),mastery=await learner.locator('.mastery-box').textContent();
const missed=learner.locator('.review-item').filter({hasText:prompts.find(x=>x.id==='conditional-step').prompt});await missed.locator('summary').click();await missed.locator('textarea').fill('Incoming mass: 3/8 × 2/3 = 1/4. Literal <&> 日本語 🌊');
await learner.locator('#application-reflection').fill('A finite horizon is not an eventual stopping guarantee.');
mark('B5 actual downloaded course preview/cancel/explicit start and all12 independent answers',{observed});
await learner.locator('#practice-button').click();assert.equal(await learner.locator('.question-card h2').textContent(),prompts.find(x=>x.id==='conditional-step').prompt);await learner.locator('[data-practice-choice="2"]').click();await learner.locator('#practice-next').click();assert.equal(await learner.locator('#first-try-summary').textContent(),firstSummary);assert.equal(await learner.locator('.mastery-box').textContent(),mastery);assert.match(await learner.locator('#practice-status').textContent(),/1 of 1 correctly/);
const notes=await download(learner,'#save-notes-button','study-notes.txt');const noteText=fs.readFileSync(notes,'utf8');for(const item of prompts)assert.ok(noteText.includes(item.prompt),item.id);assert.ok(noteText.includes('Incoming mass: 3/8 × 2/3 = 1/4. Literal <&> 日本語 🌊'));assert.ok(noteText.includes('A finite horizon is not an eventual stopping guarantee.'));assert.ok(noteText.includes('Practice'));
mark('B6 separate correct practice preserves first answers and model estimates; actual study notes retain all12 prompts and literal reflections');
await snap(learner,'learner-review-after-practice',learner.locator('.result-card'));assert.deepEqual(errors,[]);assert.deepEqual(remote,[]);assert.deepEqual(sources(),[]);receipt.pass=true;await context.close();
}catch(e){receipt.pass=false;receipt.error={name:e.name,message:e.message,stack:e.stack};process.exitCode=1;}
finally{if(browser){try{await Promise.race([browser.close(),new Promise((_,reject)=>setTimeout(()=>reject(Error('close deadline')),20000))]);receipt.browserClosed=true;}catch(e){receipt.closeError=String(e);process.exitCode=1;}}receipt.sourceMismatches=sources();receipt.finished=new Date().toISOString();save();console.log(JSON.stringify({pass:receipt.pass,checks:checks.length,error:receipt.error,images}));}
